package com.adr.groupledger.security

import com.adr.groupledger.data.firebase.FirestoreSecurityAudit
import com.adr.groupledger.data.firebase.FirestoreSecurityAudit.AccessScope
import com.adr.groupledger.data.firebase.FirestoreSecurityAudit.CanonicalPath
import com.adr.groupledger.data.firebase.FirestoreSecurityAudit.RoleRequirement
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/**
 * Phase 11 — Task 8: Comprehensive Production Security Audit Test Suite.
 *
 * Verifies:
 * 1. Conformance of all 13 canonical Firestore paths and rejection of non-canonical paths.
 * 2. Multi-tenant isolation and group scoping rules.
 * 3. Validation and rejection of non-positive identifiers (<= 0L).
 * 4. Role and authenticated UID context enforcement across all write scopes.
 * 5. Complete coverage of cascading group teardown subcollections.
 */
class ProductionSecurityAuditTest {

    @Test
    fun verifyCanonicalPathsCountIsExactly13() {
        assertEquals(
            "Security Audit Requirement: Exactly 13 canonical paths must be recognized",
            13,
            CanonicalPath.values().size
        )
    }

    @Test
    fun verifyAll13CanonicalPathsMatchValidPaths() {
        val testPaths = listOf(
            "users/101" to CanonicalPath.USERS,
            "groups/202" to CanonicalPath.GROUPS,
            "groups/202/members/303" to CanonicalPath.GROUP_MEMBERS,
            "groups/202/payments/404" to CanonicalPath.GROUP_PAYMENTS,
            "groups/202/transactions/505" to CanonicalPath.GROUP_TRANSACTIONS,
            "groups/202/notices/606" to CanonicalPath.GROUP_NOTICES,
            "groups/202/loans/707" to CanonicalPath.GROUP_LOANS,
            "groups/202/messages/808" to CanonicalPath.GROUP_MESSAGES,
            "groups/202/preAuthorizedMembers/909" to CanonicalPath.GROUP_PRE_AUTH,
            "groups/202/pendingRequests/1001" to CanonicalPath.GROUP_PENDING_REQUESTS,
            "groups/202/feedbacks/1101" to CanonicalPath.GROUP_FEEDBACKS,
            "admin_users/admin_user_uid" to CanonicalPath.ADMIN_USERS,
            "app_config/version_info" to CanonicalPath.APP_CONFIG_VERSION
        )

        for ((path, expectedCanonical) in testPaths) {
            assertTrue("Path '$path' should be recognized as canonical", FirestoreSecurityAudit.isCanonicalPath(path))
            val matched = FirestoreSecurityAudit.matchCanonicalPath(path)
            assertNotNull("Path '$path' should match a canonical path enum", matched)
            assertEquals("Path '$path' mapped to wrong canonical enum", expectedCanonical, matched)
        }
    }

    @Test
    fun verifyNonCanonicalPathsAreRejected() {
        val nonCanonicalPaths = listOf(
            "users/101/joinRequests", // Deprecated non-canonical join requests
            "users/101/joinRequests/55",
            "payments/404", // Unscoped payments
            "transactions/505", // Unscoped transactions
            "members/303", // Unscoped members
            "notices/606", // Unscoped notices
            "loans/707", // Unscoped loans
            "random_collection/doc123",
            "groups/202/invalidSub/99",
            "app_config/some_other_doc",
            "system/metadata"
        )

        for (path in nonCanonicalPaths) {
            assertFalse("Path '$path' should NOT be canonical", FirestoreSecurityAudit.isCanonicalPath(path))
            assertNull("Path '$path' should not match any canonical enum", FirestoreSecurityAudit.matchCanonicalPath(path))
        }
    }

    @Test
    fun verifyIdValidationRejectsNonPositiveIds() {
        assertFalse(FirestoreSecurityAudit.isValidId(0L))
        assertFalse(FirestoreSecurityAudit.isValidId(-1L))
        assertFalse(FirestoreSecurityAudit.isValidId(-9999L))

        assertTrue(FirestoreSecurityAudit.isValidId(1L))
        assertTrue(FirestoreSecurityAudit.isValidId(42L))
        assertTrue(FirestoreSecurityAudit.isValidId(Long.MAX_VALUE))

        try {
            FirestoreSecurityAudit.validateId(0L, "groupId")
            fail("Expected IllegalArgumentException for id = 0")
        } catch (e: IllegalArgumentException) {
            assertTrue(e.message?.contains("groupId") == true)
        }

        try {
            FirestoreSecurityAudit.validateId(-5L, "memberId")
            fail("Expected IllegalArgumentException for id = -5")
        } catch (e: IllegalArgumentException) {
            assertTrue(e.message?.contains("memberId") == true)
        }
    }

    @Test
    fun verifyGroupScopingValidation() {
        // Positive groupId with valid group subcollection
        val validCheck = FirestoreSecurityAudit.validateGroupScoping(202L, "groups/202/payments/404")
        assertTrue(validCheck.isSuccess)

        // Non-positive groupId must fail
        val invalidGroupCheck = FirestoreSecurityAudit.validateGroupScoping(0L, "groups/0/payments/404")
        assertTrue(invalidGroupCheck.isFailure)

        val negativeGroupCheck = FirestoreSecurityAudit.validateGroupScoping(-1L, "groups/-1/payments/404")
        assertTrue(negativeGroupCheck.isFailure)

        // Path mismatch with groupId
        val mismatchCheck = FirestoreSecurityAudit.validateGroupScoping(202L, "groups/999/payments/404")
        assertTrue(mismatchCheck.isFailure)
    }

    @Test
    fun verifyBuildPathConstructsAccuratePaths() {
        val userPath = FirestoreSecurityAudit.buildPath(CanonicalPath.USERS, userId = 101L)
        assertEquals("users/101", userPath)

        val groupPath = FirestoreSecurityAudit.buildPath(CanonicalPath.GROUPS, groupId = 202L)
        assertEquals("groups/202", groupPath)

        val paymentPath = FirestoreSecurityAudit.buildPath(CanonicalPath.GROUP_PAYMENTS, groupId = 202L, documentId = 404L)
        assertEquals("groups/202/payments/404", paymentPath)

        val txPath = FirestoreSecurityAudit.buildPath(CanonicalPath.GROUP_TRANSACTIONS, groupId = 202L, documentId = 505L)
        assertEquals("groups/202/transactions/505", txPath)

        val noticePath = FirestoreSecurityAudit.buildPath(CanonicalPath.GROUP_NOTICES, groupId = 202L, documentId = 606L)
        assertEquals("groups/202/notices/606", noticePath)

        val loanPath = FirestoreSecurityAudit.buildPath(CanonicalPath.GROUP_LOANS, groupId = 202L, documentId = 707L)
        assertEquals("groups/202/loans/707", loanPath)

        val msgPath = FirestoreSecurityAudit.buildPath(CanonicalPath.GROUP_MESSAGES, groupId = 202L, documentId = 808L)
        assertEquals("groups/202/messages/808", msgPath)

        val preAuthPath = FirestoreSecurityAudit.buildPath(CanonicalPath.GROUP_PRE_AUTH, groupId = 202L, documentId = 909L)
        assertEquals("groups/202/preAuthorizedMembers/909", preAuthPath)

        val pendingPath = FirestoreSecurityAudit.buildPath(CanonicalPath.GROUP_PENDING_REQUESTS, groupId = 202L, documentId = 1001L)
        assertEquals("groups/202/pendingRequests/1001", pendingPath)

        val feedbackPath = FirestoreSecurityAudit.buildPath(CanonicalPath.GROUP_FEEDBACKS, groupId = 202L, documentId = 1101L)
        assertEquals("groups/202/feedbacks/1101", feedbackPath)

        val adminPath = FirestoreSecurityAudit.buildPath(CanonicalPath.ADMIN_USERS, stringDocId = "admin_uid_xyz")
        assertEquals("admin_users/admin_uid_xyz", adminPath)

        val appConfigPath = FirestoreSecurityAudit.buildPath(CanonicalPath.APP_CONFIG_VERSION)
        assertEquals("app_config/version_info", appConfigPath)
    }

    @Test
    fun verifyBuildPathRejectsInvalidIds() {
        try {
            FirestoreSecurityAudit.buildPath(CanonicalPath.GROUPS, groupId = 0L)
            fail("Expected exception for groupId = 0")
        } catch (e: IllegalArgumentException) {
            // Success
        }

        try {
            FirestoreSecurityAudit.buildPath(CanonicalPath.GROUP_PAYMENTS, groupId = 202L, documentId = 0L)
            fail("Expected exception for documentId = 0")
        } catch (e: IllegalArgumentException) {
            // Success
        }

        try {
            FirestoreSecurityAudit.buildPath(CanonicalPath.USERS, userId = -10L)
            fail("Expected exception for userId = -10")
        } catch (e: IllegalArgumentException) {
            // Success
        }
    }

    @Test
    fun verifyRoleRequirementsAcrossMutations() {
        // Group-scoped mutating subcollections require at least AUTHENTICATED_USER or GROUP_ADMIN
        for (canonical in CanonicalPath.values()) {
            when (canonical.scope) {
                AccessScope.GROUP_SCOPED -> {
                    assertTrue(
                        "Group scoped path $canonical must require valid auth role",
                        canonical.writeRole == RoleRequirement.AUTHENTICATED_USER ||
                                canonical.writeRole == RoleRequirement.GROUP_ADMIN ||
                                canonical.writeRole == RoleRequirement.GROUP_MEMBER
                    )
                }
                AccessScope.GLOBAL -> {
                    assertTrue(
                        "Global mutating path $canonical must require global admin",
                        canonical.writeRole == RoleRequirement.GLOBAL_ADMIN
                    )
                }
                AccessScope.USER_SCOPED -> {
                    assertEquals(RoleRequirement.AUTHENTICATED_USER, canonical.writeRole)
                }
            }
        }
    }

    @Test
    fun verifyGroupTeardownSubcollectionsCompleteness() {
        val teardownSubcollections = FirestoreSecurityAudit.getAllGroupSubcollections()

        val expectedSubcollections = listOf(
            "members",
            "payments",
            "transactions",
            "notices",
            "loans",
            "messages",
            "preAuthorizedMembers",
            "pendingRequests",
            "feedbacks"
        )

        for (expected in expectedSubcollections) {
            assertTrue(
                "Teardown subcollections must include '$expected'",
                teardownSubcollections.contains(expected)
            )
        }
    }
}
