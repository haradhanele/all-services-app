package com.adr.groupledger.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AppRegistration
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.BrightnessAuto
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.ui.components.GroupSwitcherModal
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.BorderLight
import com.adr.groupledger.ui.theme.BorderSubtle
import com.adr.groupledger.ui.theme.CardWhite
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.TextSlate400
import com.adr.groupledger.ui.theme.TextSlate500
import com.adr.groupledger.ui.theme.TextSlate800
import com.adr.groupledger.ui.viewmodel.SocietyViewModel

@Composable
fun MoreScreen(
    viewModel: SocietyViewModel,
    onNavigateToLoans: () -> Unit,
    onNavigateToInvestments: () -> Unit,
    onNavigateToFeedback: () -> Unit,
    onNavigateToLedger: () -> Unit,
    onNavigateToMonthly: () -> Unit,
    onNavigateToDues: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToBackup: () -> Unit,
    onNavigateToMyProfile: (Long) -> Unit,
    onNavigateToMembers: () -> Unit = {},
    onNavigateToAddMember: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val allGroups by viewModel.allGroups.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val userMemberships by viewModel.userMemberships.collectAsStateWithLifecycle()
    val currentUserRole by viewModel.currentUserRole.collectAsStateWithLifecycle()
    val loansWithVoting by viewModel.allLoansWithVotes.collectAsStateWithLifecycle()
    val members by viewModel.allActiveMembers.collectAsStateWithLifecycle()
    val currentMemberId by viewModel.currentMemberId.collectAsStateWithLifecycle()
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()

    // 1. Determine Account Status and Permissions
    val isSignedUpUser = currentUser?.isAccountCompleted == true
    val isGroupAdmin = currentUserRole.equals("ADMIN", ignoreCase = true) ||
            settings.createdByUserId == (currentUser?.id ?: 0L) ||
            isAdminUnlocked

    // Statistics counts
    val managedGroupsCount = remember(allGroups, userMemberships, currentUser) {
        val uid = currentUser?.id ?: 0L
        allGroups.count { g ->
            g.createdByUserId == uid || userMemberships.any { m -> m.groupId == g.id && m.role.equals("ADMIN", ignoreCase = true) }
        }
    }

    val joinedGroupsCount = remember(allGroups, userMemberships) {
        if (userMemberships.isNotEmpty()) userMemberships.size else allGroups.size
    }

    val pendingLoansCount = remember(loansWithVoting) {
        loansWithVoting.count { it.loan.status in listOf("VOTING", "SUBMITTED") }
    }

    val currentMember = remember(members, currentMemberId) {
        members.find { it.id == currentMemberId } ?: members.firstOrNull()
    }

    // Modal / Dialog States
    var showProfileModal by remember { mutableStateOf(false) }
    var showCompleteSignUpDialog by remember { mutableStateOf(false) }
    var showGroupJoiningCodeDialog by remember { mutableStateOf(false) }
    var showReadOnlyGroupSettingsDialog by remember { mutableStateOf(false) }
    var showGroupSwitcherModal by remember { mutableStateOf(false) }
    var showCreateGroupDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var showSignOutConfirm by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("more_screen"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // =================================================================
        // 1. MODERN USER PROFILE CARD (Replaces the old Admin Mode card)
        // =================================================================
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("user_profile_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Top Row: Avatar, Identity Info, Status Badge
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = IndigoPrimary.copy(alpha = 0.12f),
                                modifier = Modifier.size(48.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    val initial = (currentUser?.fullName ?: currentMember?.name ?: "U").take(1).uppercase()
                                    Text(
                                        text = initial,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 20.sp,
                                        color = IndigoPrimary
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = currentUser?.fullName ?: currentMember?.name ?: "User",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = TextSlate800,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )

                                    // Account Status Pill
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (isSignedUpUser) Emerald500.copy(alpha = 0.12f) else Amber500.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = if (isSignedUpUser) "Full Account" else "Join Code",
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSignedUpUser) Emerald500 else Amber500,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(2.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    // Current Group Role Tag
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (isGroupAdmin) IndigoPrimary.copy(alpha = 0.1f) else TextSlate400.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = if (isGroupAdmin) "Group Admin" else "Member",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (isGroupAdmin) IndigoPrimary else TextSlate500,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                        )
                                    }

                                    Text(
                                        text = currentUser?.phone?.ifBlank { currentUser?.email ?: "" } ?: "",
                                        fontSize = 11.5.sp,
                                        color = TextSlate400,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }

                        // View Profile Action Button
                        TextButton(
                            onClick = { showProfileModal = true },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("view_profile_btn")
                        ) {
                            Text("View Profile", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = IndigoPrimary)
                            Spacer(modifier = Modifier.width(2.dp))
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(14.dp), tint = IndigoPrimary)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = BorderSubtle, thickness = 0.75.dp)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Statistics Row: Groups I Manage vs Groups I Joined (MANDATORY EXACT TERMINOLOGY)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Stat Box 1: Groups I Manage
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = IndigoPrimary.copy(alpha = 0.06f),
                            border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.15f)),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { showGroupSwitcherModal = true }
                                .testTag("stat_groups_i_manage")
                        ) {
                            Column(
                                modifier = Modifier.padding(vertical = 10.dp, horizontal = 12.dp)
                            ) {
                                Text(
                                    text = "Groups I Manage",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = IndigoPrimary
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "$managedGroupsCount",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = IndigoPrimary
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (managedGroupsCount == 1) "group" else "groups",
                                        fontSize = 11.sp,
                                        color = TextSlate500
                                    )
                                }
                            }
                        }

                        // Stat Box 2: Groups I Joined
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            border = BorderStroke(1.dp, BorderSubtle),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { showGroupSwitcherModal = true }
                                .testTag("stat_groups_i_joined")
                        ) {
                            Column(
                                modifier = Modifier.padding(vertical = 10.dp, horizontal = 12.dp)
                            ) {
                                Text(
                                    text = "Groups I Joined",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = TextSlate800
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "$joinedGroupsCount",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextSlate800
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (joinedGroupsCount == 1) "group" else "groups",
                                        fontSize = 11.sp,
                                        color = TextSlate500
                                    )
                                }
                            }
                        }
                    }

                    // For join-by-code users, offer a helpful banner to complete sign up
                    if (!isSignedUpUser) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Amber500.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, Amber500.copy(alpha = 0.25f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showCompleteSignUpDialog = true }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        Icons.Default.AppRegistration,
                                        contentDescription = null,
                                        tint = Amber500,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Complete Sign Up to create your own groups",
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = TextSlate800
                                    )
                                }
                                Text(
                                    text = "Upgrade",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Amber500
                                )
                            }
                        }
                    }
                }
            }
        }

        // =================================================================
        // 2. MY GROUPS SECTION
        // =================================================================
        item {
            SectionHeader(title = "MY GROUPS")
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    // Option 1: Manage My Groups / Switch Active Group
                    MoreOptionRow(
                        icon = Icons.Default.Groups,
                        iconTint = IndigoPrimary,
                        title = "Manage & Switch Groups",
                        subtitle = "Active: ${settings.groupName} (${allGroups.size} accessible)",
                        badgeCount = allGroups.size,
                        onClick = { showGroupSwitcherModal = true }
                    )
                    MoreDivider()

                    // Option 2: Create New Group
                    if (isSignedUpUser) {
                        MoreOptionRow(
                            icon = Icons.Default.Add,
                            iconTint = Emerald500,
                            title = "Create New Group",
                            subtitle = "Start a new savings, welfare, or investment society",
                            onClick = { showCreateGroupDialog = true }
                        )
                    } else {
                        // Disabled / Locked for Join-Code user with clear explanation
                        MoreOptionRow(
                            icon = Icons.Default.Lock,
                            iconTint = TextSlate400,
                            title = "Create New Group",
                            subtitle = "Sign Up required: Complete registration to create groups",
                            isLockProtected = true,
                            onClick = { showCompleteSignUpDialog = true }
                        )
                    }
                    MoreDivider()

                    // Option 3: Join Group with Invite Code
                    MoreOptionRow(
                        icon = Icons.Default.QrCode,
                        iconTint = Amber500,
                        title = "Join Another Group with Code",
                        subtitle = "Enter an invite code to join another society",
                        onClick = { showGroupSwitcherModal = true }
                    )
                }
            }
        }

        // =================================================================
        // 3. MEMBER & GROUP MANAGEMENT SECTION (Visible to Group Admin only)
        // =================================================================
        if (isGroupAdmin) {
            item {
                SectionHeader(title = "MEMBER & GROUP MANAGEMENT")
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CardWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column {
                        MoreOptionRow(
                            icon = Icons.Default.Groups,
                            iconTint = IndigoPrimary,
                            title = "Manage Society Members",
                            subtitle = "View ${members.size} active members, update details and profiles",
                            onClick = onNavigateToMembers
                        )
                        MoreDivider()

                        MoreOptionRow(
                            icon = Icons.Default.GroupAdd,
                            iconTint = Emerald500,
                            title = "Add New Member",
                            subtitle = "Register a new member in ${settings.groupName}",
                            onClick = onNavigateToAddMember
                        )
                        MoreDivider()

                        MoreOptionRow(
                            icon = Icons.Default.Key,
                            iconTint = Amber500,
                            title = "Group Joining Code: ${settings.inviteCode}",
                            subtitle = "Share joining code with members or generate a new code",
                            onClick = { showGroupJoiningCodeDialog = true }
                        )
                    }
                }
            }
        }

        // =================================================================
        // 4. SETTINGS SECTION
        // =================================================================
        item {
            SectionHeader(title = "SETTINGS")
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    // Group Settings: Editable for Admin, Read-Only dialog for regular Member
                    if (isGroupAdmin) {
                        MoreOptionRow(
                            icon = Icons.Default.Settings,
                            iconTint = IndigoPrimary,
                            title = "Group Settings",
                            subtitle = "Society name, dues, fine rules, modules & contact info",
                            onClick = {
                                viewModel.requestAdminAction {
                                    onNavigateToSettings()
                                }
                            }
                        )
                    } else {
                        MoreOptionRow(
                            icon = Icons.Default.Visibility,
                            iconTint = IndigoPrimary,
                            title = "Group Details & Rules (Read-Only)",
                            subtitle = "View dues, due date, late fees & society policy",
                            onClick = { showReadOnlyGroupSettingsDialog = true }
                        )
                    }
                    MoreDivider()

                    // Theme & Appearance
                    MoreOptionRow(
                        icon = Icons.Default.Palette,
                        iconTint = Color(0xFF8B5CF6),
                        title = "App Theme & Appearance",
                        subtitle = "Current: ${settings.themeMode.replaceFirstChar { it.uppercase() }} mode",
                        onClick = { showThemeDialog = true }
                    )

                    // Security & PIN Lock (For Admin)
                    if (isGroupAdmin) {
                        MoreDivider()
                        MoreOptionRow(
                            icon = Icons.Default.Security,
                            iconTint = Amber500,
                            title = "Security & PIN Lock",
                            subtitle = if (settings.isPinLockEnabled) "PIN Lock active" else "PIN Lock disabled",
                            onClick = {
                                viewModel.requestAdminAction {
                                    onNavigateToSettings()
                                }
                            }
                        )
                    }
                }
            }
        }

        // =================================================================
        // 5. FINANCE & LEDGER SECTION
        // =================================================================
        item {
            SectionHeader(title = "FINANCE & LEDGER")
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    MoreOptionRow(
                        icon = Icons.AutoMirrored.Filled.MenuBook,
                        iconTint = IndigoPrimary,
                        title = "Transaction Ledger",
                        subtitle = "Complete chronological credit & debit audit trail",
                        onClick = onNavigateToLedger
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.Default.CalendarMonth,
                        iconTint = Emerald500,
                        title = "Monthly Collection Matrix",
                        subtitle = "Month-by-month member payment breakdown and status",
                        onClick = onNavigateToMonthly
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.Default.Payments,
                        iconTint = Rose500,
                        title = "Pending Dues & Reminders",
                        subtitle = "Track unpaid balances and trigger WhatsApp alerts",
                        onClick = onNavigateToDues
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.Default.Handshake,
                        iconTint = Amber500,
                        title = "Loans & 70% Voting",
                        subtitle = "Apply, view active loans and cast member approval votes",
                        badgeCount = if (pendingLoansCount > 0) pendingLoansCount else null,
                        onClick = onNavigateToLoans
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.Default.TrendingUp,
                        iconTint = Color(0xFF3B82F6),
                        title = "Investment Portfolio",
                        subtitle = "Track fixed deposits, land, community assets and returns",
                        onClick = onNavigateToInvestments
                    )
                }
            }
        }

        // =================================================================
        // 6. COMMUNITY & GOVERNANCE SECTION
        // =================================================================
        item {
            SectionHeader(title = "COMMUNITY & GOVERNANCE")
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    MoreOptionRow(
                        icon = Icons.Default.Feedback,
                        iconTint = Color(0xFF8B5CF6),
                        title = "Proposals, Suggestions & Complaints",
                        subtitle = "Submit society proposals and upvote community ideas",
                        onClick = onNavigateToFeedback
                    )
                }
            }
        }

        // =================================================================
        // 7. DATA & SYSTEM SECTION
        // =================================================================
        item {
            SectionHeader(title = "DATA & SYSTEM")
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    MoreOptionRow(
                        icon = Icons.Default.Backup,
                        iconTint = Emerald500,
                        title = "Backup & Restore Database",
                        subtitle = "Export or restore complete JSON database backup",
                        isLockProtected = !isGroupAdmin,
                        onClick = {
                            viewModel.requestAdminAction {
                                onNavigateToBackup()
                            }
                        }
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.Default.Info,
                        iconTint = TextSlate500,
                        title = "About App & Architecture",
                        subtitle = "Group Ledger v1.2.0 • Offline SQLite Engine & Cloud Sync",
                        onClick = {
                            Toast.makeText(
                                context,
                                "Group Ledger v1.2.0\nSecure Offline SQLite with Real-Time Cloud Firestore Sync",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    )
                }
            }
        }

        // =================================================================
        // 8. ACCOUNT SECTION
        // =================================================================
        item {
            SectionHeader(title = "ACCOUNT")
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    MoreOptionRow(
                        icon = Icons.Default.SwapHoriz,
                        iconTint = IndigoPrimary,
                        title = "Switch Profile / User Account",
                        subtitle = "Manage multiple profiles on this device",
                        onClick = { showGroupSwitcherModal = true }
                    )
                    MoreDivider()

                    // Distinct Red / Destructive Sign Out Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showSignOutConfirm = true }
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                            .testTag("sign_out_btn"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Rose500.copy(alpha = 0.12f),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Logout,
                                    contentDescription = "Sign Out",
                                    tint = Rose500,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Sign Out",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.5.sp,
                                color = Rose500
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Exit current session and return to welcome login screen",
                                fontSize = 12.sp,
                                color = TextSlate500
                            )
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = Rose500.copy(alpha = 0.6f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // App Info Footer
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "${settings.groupName} • v1.2.0",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp,
                    color = TextSlate500
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Encrypted Local Database & Cloud Firestore Sync",
                    fontSize = 11.sp,
                    color = TextSlate400
                )
            }
        }
    }

    // =================================================================
    // DIALOGS AND MODALS
    // =================================================================

    // 1. Profile Details & Edit Modal
    if (showProfileModal) {
        var editName by remember { mutableStateOf(currentUser?.fullName ?: currentMember?.name ?: "") }
        var editEmail by remember { mutableStateOf(currentUser?.email ?: "") }
        var editPhone by remember { mutableStateOf(currentUser?.phone ?: currentMember?.phone ?: "") }
        var isSaving by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showProfileModal = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AccountCircle, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("User Profile Details", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Account Type Badge
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSignedUpUser) Emerald500.copy(alpha = 0.1f) else Amber500.copy(alpha = 0.1f),
                        border = BorderStroke(1.dp, if (isSignedUpUser) Emerald500.copy(alpha = 0.3f) else Amber500.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isSignedUpUser) Icons.Default.VerifiedUser else Icons.Default.Key,
                                contentDescription = null,
                                tint = if (isSignedUpUser) Emerald500 else Amber500,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = if (isSignedUpUser) "Registered Full Account" else "Guest Join-Code Account",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.5.sp,
                                    color = if (isSignedUpUser) Emerald500 else Amber500
                                )
                                Text(
                                    text = if (isSignedUpUser) "Can create, manage, and join societies" else "Joined via code. Upgrade to create societies.",
                                    fontSize = 11.sp,
                                    color = TextSlate500
                                )
                            }
                        }
                    }

                    if (isSignedUpUser) {
                        OutlinedTextField(
                            value = editName,
                            onValueChange = { editName = it },
                            label = { Text("Full Name") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = editEmail,
                            onValueChange = { editEmail = it },
                            label = { Text("Email Address") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = editPhone,
                            onValueChange = { editPhone = it },
                            label = { Text("Phone Number") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        // Summary info for join-code user
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(text = "Name: ${currentUser?.fullName ?: "Member"}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(text = "Phone: ${currentUser?.phone?.ifBlank { "Not provided" } ?: "Not provided"}", fontSize = 12.sp, color = TextSlate500)
                            Text(text = "Active Group: ${settings.groupName}", fontSize = 12.sp, color = TextSlate500)
                        }

                        Button(
                            onClick = {
                                showProfileModal = false
                                showCompleteSignUpDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.AppRegistration, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Upgrade / Complete Sign Up", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            },
            confirmButton = {
                if (isSignedUpUser) {
                    Button(
                        onClick = {
                            isSaving = true
                            viewModel.updateUserProfile(
                                fullName = editName,
                                email = editEmail,
                                phone = editPhone,
                                onSuccess = {
                                    isSaving = false
                                    showProfileModal = false
                                },
                                onError = {
                                    isSaving = false
                                }
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                        enabled = !isSaving && editName.isNotBlank()
                    ) {
                        Text("Save Changes")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showProfileModal = false }) {
                    Text("Close")
                }
            }
        )
    }

    // 2. Complete Sign Up Dialog (For upgrading Join-Code users to Full Accounts)
    if (showCompleteSignUpDialog) {
        var suName by remember { mutableStateOf(currentUser?.fullName ?: "") }
        var suEmail by remember { mutableStateOf(if (currentUser?.email?.contains("@groupledger.org") == true) "" else (currentUser?.email ?: "")) }
        var suPassword by remember { mutableStateOf("") }
        var suPhone by remember { mutableStateOf(currentUser?.phone ?: "") }
        var suError by remember { mutableStateOf<String?>(null) }
        var suLoading by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { if (!suLoading) showCompleteSignUpDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AppRegistration, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Complete Your Registration", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Register with your email and password to create new societies and manage multiple groups as an administrator.",
                        fontSize = 12.5.sp,
                        color = TextSlate500
                    )

                    OutlinedTextField(
                        value = suName,
                        onValueChange = { suName = it },
                        label = { Text("Full Name *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = suEmail,
                        onValueChange = {
                            suEmail = it
                            suError = null
                        },
                        label = { Text("Email Address *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = suPassword,
                        onValueChange = {
                            suPassword = it
                            suError = null
                        },
                        label = { Text("Password (min 6 chars) *") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = suPhone,
                        onValueChange = { suPhone = it },
                        label = { Text("Phone Number") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    suError?.let {
                        Text(text = it, color = Rose500, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        suLoading = true
                        suError = null
                        viewModel.completeGuestSignUp(
                            fullName = suName,
                            email = suEmail,
                            password = suPassword,
                            phone = suPhone,
                            onSuccess = {
                                suLoading = false
                                showCompleteSignUpDialog = false
                            },
                            onError = { err ->
                                suLoading = false
                                suError = err
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                    enabled = !suLoading && suName.isNotBlank() && suEmail.isNotBlank() && suPassword.length >= 6
                ) {
                    Text(if (suLoading) "Registering..." else "Complete Sign Up")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showCompleteSignUpDialog = false },
                    enabled = !suLoading
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // 3. Group Joining Code Modal (For Admin to view, share, copy, regenerate)
    if (showGroupJoiningCodeDialog) {
        AlertDialog(
            onDismissRequest = { showGroupJoiningCodeDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Key, contentDescription = null, tint = Amber500, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Group Invitation Code", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Share this code with members so they can join '${settings.groupName}':",
                        fontSize = 13.sp,
                        color = TextSlate500,
                        textAlign = TextAlign.Center
                    )

                    // Code Banner
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = IndigoPrimary.copy(alpha = 0.08f),
                        border = BorderStroke(1.5.dp, IndigoPrimary.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = settings.inviteCode,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = IndigoPrimary,
                                letterSpacing = 2.sp
                            )
                        }
                    }

                    // Action buttons: Copy & Share
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(settings.inviteCode))
                                Toast.makeText(context, "Code copied: ${settings.inviteCode}", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Copy", fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(
                                        Intent.EXTRA_TEXT,
                                        "Join our society '${settings.groupName}' on Group Ledger using Invitation Code: ${settings.inviteCode}"
                                    )
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share Group Code"))
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Share", fontSize = 12.sp)
                        }
                    }

                    // Regenerate Code button
                    TextButton(
                        onClick = {
                            viewModel.regenerateGroupInviteCode()
                        }
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp), tint = TextSlate500)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Regenerate New Code", fontSize = 11.5.sp, color = TextSlate500)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showGroupJoiningCodeDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // 4. Read-Only Group Settings Modal (For regular members)
    if (showReadOnlyGroupSettingsDialog) {
        AlertDialog(
            onDismissRequest = { showReadOnlyGroupSettingsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Visibility, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Group Details & Rules", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
            },
            text = {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = IndigoPrimary.copy(alpha = 0.08f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Read-Only: These parameters are managed by your society administrator.",
                                    fontSize = 11.5.sp,
                                    color = IndigoPrimary,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }

                    item {
                        ReadOnlyDetailRow("Society Name", settings.groupName)
                    }
                    item {
                        ReadOnlyDetailRow("Subtitle", settings.groupSubtitle.ifBlank { "Monthly Savings & Contribution Society" })
                    }
                    item {
                        ReadOnlyDetailRow("Group Type", settings.groupType)
                    }
                    item {
                        ReadOnlyDetailRow("Monthly Dues", "${settings.currencySymbol}${settings.defaultContribution.toInt()} / member")
                    }
                    item {
                        ReadOnlyDetailRow("Frequency", settings.contributionFrequency)
                    }
                    item {
                        ReadOnlyDetailRow("Payment Due Day", "Day ${settings.dueDayOfMonth} of every month")
                    }
                    item {
                        ReadOnlyDetailRow(
                            "Late Fine Policy",
                            if (settings.isLateFeeEnabled) "${settings.currencySymbol}${settings.lateFineAmount.toInt()} after ${settings.gracePeriodDays} days grace period" else "No late fine enabled"
                        )
                    }
                    item {
                        ReadOnlyDetailRow("Society Admin", "${settings.adminName} • ${settings.adminPhone}")
                    }
                    item {
                        ReadOnlyDetailRow("Society Rules", settings.paymentRules)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showReadOnlyGroupSettingsDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // 5. Create Group Dialog (Directly accessible from My Groups for signed-up users)
    if (showCreateGroupDialog) {
        var gName by remember { mutableStateOf("") }
        var gSubtitle by remember { mutableStateOf("") }
        var gDues by remember { mutableStateOf("500") }
        var gCurrency by remember { mutableStateOf("₹") }
        var isCreating by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { if (!isCreating) showCreateGroupDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Create New Group", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "You will become the administrator of this new group with full management privileges.",
                        fontSize = 12.sp,
                        color = TextSlate500
                    )

                    OutlinedTextField(
                        value = gName,
                        onValueChange = { gName = it },
                        label = { Text("Group Name *") },
                        placeholder = { Text("e.g. Metro Welfare Society") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = gSubtitle,
                        onValueChange = { gSubtitle = it },
                        label = { Text("Purpose / Subtitle") },
                        placeholder = { Text("e.g. Monthly Savings & Emergency Fund") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = gDues,
                            onValueChange = { gDues = it },
                            label = { Text("Monthly Dues") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = gCurrency,
                            onValueChange = { gCurrency = it },
                            label = { Text("Currency") },
                            singleLine = true,
                            modifier = Modifier.width(80.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isCreating = true
                        val amount = gDues.toDoubleOrNull() ?: 0.0
                        viewModel.createNewGroup(
                            groupName = gName,
                            groupSubtitle = gSubtitle,
                            defaultContribution = amount,
                            currencySymbol = gCurrency,
                            onSuccess = {
                                isCreating = false
                                showCreateGroupDialog = false
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                    enabled = !isCreating && gName.isNotBlank()
                ) {
                    Text(if (isCreating) "Creating..." else "Create Group")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showCreateGroupDialog = false },
                    enabled = !isCreating
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // 6. Theme Selection Dialog
    if (showThemeDialog) {
        val currentTheme = settings.themeMode

        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Palette, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("App Theme Mode", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    listOf(
                        Triple("SYSTEM", "System Default", Icons.Default.BrightnessAuto),
                        Triple("LIGHT", "Light Theme", Icons.Default.LightMode),
                        Triple("DARK", "Dark Theme", Icons.Default.DarkMode)
                    ).forEach { (mode, label, icon) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    viewModel.setThemeMode(mode)
                                    showThemeDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = currentTheme.equals(mode, ignoreCase = true),
                                onClick = {
                                    viewModel.setThemeMode(mode)
                                    showThemeDialog = false
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = IndigoPrimary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp), tint = IndigoPrimary)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(label, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showThemeDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // 7. Sign Out Confirmation Dialog
    if (showSignOutConfirm) {
        AlertDialog(
            onDismissRequest = { showSignOutConfirm = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = Rose500, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Confirm Sign Out", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
            },
            text = {
                Text(
                    text = "Are you sure you want to sign out of '${settings.groupName}'? You can sign back in anytime using your registered email or invitation code.",
                    fontSize = 13.sp,
                    color = TextSlate500
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSignOutConfirm = false
                        viewModel.logout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Rose500)
                ) {
                    Text("Sign Out", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSignOutConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // 8. Group Switcher & Account Management Bottom Sheet Modal
    GroupSwitcherModal(
        viewModel = viewModel,
        isOpen = showGroupSwitcherModal,
        onDismiss = { showGroupSwitcherModal = false }
    )
}

// =================================================================
// REUSABLE UI HELPER COMPONENTS
// =================================================================

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        fontWeight = FontWeight.Bold,
        fontSize = 11.5.sp,
        color = TextSlate400,
        letterSpacing = 0.8.sp,
        modifier = Modifier.padding(start = 4.dp, top = 2.dp)
    )
}

@Composable
fun MoreOptionRow(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    badgeCount: Int? = null,
    isLockProtected: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = iconTint.copy(alpha = 0.12f),
            modifier = Modifier.size(40.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = TextSlate800
                )
                if (isLockProtected) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        Icons.Default.Lock,
                        contentDescription = "Protected",
                        tint = TextSlate400,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                fontSize = 11.5.sp,
                color = TextSlate500,
                lineHeight = 15.sp
            )
        }

        if (badgeCount != null && badgeCount > 0) {
            Surface(
                shape = CircleShape,
                color = Rose500,
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Text(
                    text = "$badgeCount",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.5.sp,
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
        }

        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = TextSlate400.copy(alpha = 0.7f),
            modifier = Modifier.size(15.dp)
        )
    }
}

@Composable
fun MoreDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(horizontal = 16.dp),
        thickness = 0.75.dp,
        color = BorderSubtle.copy(alpha = 0.6f)
    )
}

@Composable
private fun ReadOnlyDetailRow(label: String, value: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextSlate400
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = TextSlate800
        )
    }
}
