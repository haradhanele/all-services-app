package com.adr.groupledger.data.repository.carousel

import android.util.Log
import com.adr.groupledger.data.model.carousel.CarouselItem
import com.adr.groupledger.data.model.carousel.GLOBAL_GROUP_ID
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

/**
 * Phase 6: Cloud Firestore-backed implementation of [CarouselRepository].
 *
 * Persists and streams [CarouselItem] metadata and media references (Cloudinary CDN URLs)
 * using the top-level collection "carousel_items".
 *
 * ARCHITECTURAL PRINCIPLES:
 * 1. Source of Truth: Firestore stores slide metadata, scheduling bounds, priority, and Cloudinary URLs.
 * 2. Binary Media Separation: Binary media is never stored in Firestore; only references/metadata.
 * 3. Application Scope: Content defaults to [GLOBAL_GROUP_ID] (0L) for platform-wide reach.
 * 4. Reactive Streaming: Implements real-time snapshot listeners with coroutines [Flow].
 * 5. Fallback Resilience: Seamlessly falls back to [fallbackRepository] if Firestore is uninitialized.
 */
class FirestoreCarouselRepository(
    private val customFirestore: FirebaseFirestore? = null,
    private val fallbackRepository: CarouselRepository = InMemoryCarouselRepository.getInstance()
) : CarouselRepository {

    private val firestore: FirebaseFirestore?
        get() = customFirestore ?: try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.w(TAG, "FirebaseFirestore instance not available: ${e.message}")
            null
        }

    override fun getActiveCarouselItems(groupId: Long): Flow<List<CarouselItem>> {
        val db = firestore
        if (db == null) {
            Log.d(TAG, "Firestore unavailable; streaming active carousel items from fallback repository")
            return fallbackRepository.getActiveCarouselItems(groupId)
        }

        return callbackFlow {
            val collectionRef = db.collection(COLLECTION_CAROUSEL_ITEMS)
            // Query active items at the Firestore index level
            val query = collectionRef.whereEqualTo("isActive", true)

            val registration: ListenerRegistration = query.addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Error in active carousel snapshot listener: ${error.message}", error)
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    val now = System.currentTimeMillis()
                    val items = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { data -> CarouselItem.fromFirestoreMap(doc.id, data) }
                    }.filter { item ->
                        // Filter group scope and schedule bounds (startAt/endAt)
                        (item.groupId == groupId || item.groupId == GLOBAL_GROUP_ID) && item.isCurrentlyActive(now)
                    }.sortedByDescending { it.priority }

                    trySend(items)
                }
            }

            awaitClose {
                registration.remove()
            }
        }
    }

    override fun getAllCarouselItems(groupId: Long): Flow<List<CarouselItem>> {
        val db = firestore
        if (db == null) {
            Log.d(TAG, "Firestore unavailable; streaming all carousel items from fallback repository")
            return fallbackRepository.getAllCarouselItems(groupId)
        }

        return callbackFlow {
            val collectionRef = db.collection(COLLECTION_CAROUSEL_ITEMS)

            val registration: ListenerRegistration = collectionRef.addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Error in all carousel items snapshot listener: ${error.message}", error)
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    val items = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { data -> CarouselItem.fromFirestoreMap(doc.id, data) }
                    }.filter { item ->
                        groupId == GLOBAL_GROUP_ID || item.groupId == groupId || item.groupId == GLOBAL_GROUP_ID
                    }.sortedByDescending { it.priority }

                    trySend(items)
                }
            }

            awaitClose {
                registration.remove()
            }
        }
    }

    override suspend fun getCarouselItemById(id: String): CarouselItem? {
        val db = firestore ?: return fallbackRepository.getCarouselItemById(id)
        return try {
            val snapshot = db.collection(COLLECTION_CAROUSEL_ITEMS).document(id).get().await()
            if (snapshot.exists()) {
                snapshot.data?.let { data -> CarouselItem.fromFirestoreMap(snapshot.id, data) }
            } else {
                fallbackRepository.getCarouselItemById(id)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to get carousel item $id from Firestore", e)
            fallbackRepository.getCarouselItemById(id)
        }
    }

    override suspend fun saveCarouselItem(item: CarouselItem): Result<String> {
        val db = firestore
        if (db == null) {
            Log.d(TAG, "Firestore unavailable; persisting carousel item in fallback repository")
            return fallbackRepository.saveCarouselItem(item)
        }

        return try {
            val collectionRef = db.collection(COLLECTION_CAROUSEL_ITEMS)
            val finalId = if (item.id.isBlank()) {
                collectionRef.document().id
            } else {
                item.id
            }

            val now = System.currentTimeMillis()
            val itemToSave = item.copy(
                id = finalId,
                updatedAt = now,
                createdAt = if (item.createdAt <= 0L) now else item.createdAt
            )

            collectionRef.document(finalId)
                .set(itemToSave.toFirestoreMap(), SetOptions.merge())
                .await()

            // Keep fallback repository in sync for offline resilience
            fallbackRepository.saveCarouselItem(itemToSave)

            Log.i(TAG, "Successfully saved carousel item $finalId in Firestore collection $COLLECTION_CAROUSEL_ITEMS")
            Result.success(finalId)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save carousel item to Firestore", e)
            Result.failure(e)
        }
    }

    override suspend fun setItemActiveStatus(itemId: String, isActive: Boolean): Result<Unit> {
        val db = firestore ?: return fallbackRepository.setItemActiveStatus(itemId, isActive)

        return try {
            val now = System.currentTimeMillis()
            db.collection(COLLECTION_CAROUSEL_ITEMS).document(itemId)
                .update(
                    mapOf(
                        "isActive" to isActive,
                        "updatedAt" to now
                    )
                ).await()

            // Synchronize fallback repository
            fallbackRepository.setItemActiveStatus(itemId, isActive)

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update active status for $itemId in Firestore", e)
            Result.failure(e)
        }
    }

    override suspend fun deleteCarouselItem(itemId: String): Result<Unit> {
        val db = firestore ?: return fallbackRepository.deleteCarouselItem(itemId)

        return try {
            // Document deletion from Firestore metadata; Cloudinary assets remain safe
            db.collection(COLLECTION_CAROUSEL_ITEMS).document(itemId).delete().await()

            // Synchronize fallback repository
            fallbackRepository.deleteCarouselItem(itemId)

            Log.i(TAG, "Successfully deleted carousel document $itemId from Firestore")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to delete carousel item $itemId from Firestore", e)
            Result.failure(e)
        }
    }

    override suspend fun updateItemPriority(itemId: String, priority: Int): Result<Unit> {
        val db = firestore ?: return fallbackRepository.updateItemPriority(itemId, priority)

        return try {
            val now = System.currentTimeMillis()
            db.collection(COLLECTION_CAROUSEL_ITEMS).document(itemId)
                .update(
                    mapOf(
                        "priority" to priority,
                        "updatedAt" to now
                    )
                ).await()

            // Synchronize fallback repository
            fallbackRepository.updateItemPriority(itemId, priority)

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update priority for $itemId in Firestore", e)
            Result.failure(e)
        }
    }

    companion object {
        const val COLLECTION_CAROUSEL_ITEMS = "carousel_items"
        private const val TAG = "FirestoreCarouselRepo"

        @Volatile
        private var instance: FirestoreCarouselRepository? = null

        fun getInstance(
            firestore: FirebaseFirestore? = null,
            fallback: CarouselRepository = InMemoryCarouselRepository.getInstance()
        ): FirestoreCarouselRepository {
            return instance ?: synchronized(this) {
                instance ?: FirestoreCarouselRepository(
                    customFirestore = firestore,
                    fallbackRepository = fallback
                ).also { instance = it }
            }
        }

        /**
         * Resets or sets the instance for unit testing.
         */
        fun setInstanceForTesting(customInstance: FirestoreCarouselRepository?) {
            synchronized(this) {
                instance = customInstance
            }
        }
    }
}
