package com.adr.groupledger.utils

import com.adr.groupledger.data.model.ChitCycle
import com.adr.groupledger.data.model.ChitCycleStatus
import com.adr.groupledger.data.model.ChitFundConfig
import com.adr.groupledger.data.model.Payment
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Pure calculation engine for Chit Fund / BC (Bishi) mathematics and schedule planning.
 * Single source of truth for:
 * 1. Financial formulas (Pot, Chit Value, Max Bids, Dividends, Net Installments).
 * 2. Schedule generation (Safe monthly calendar math, weekly, daily frequencies).
 * 3. Cycle and auction lifecycle status resolution.
 */
object ChitCalculationEngine {

    /**
     * Calculates the total expected pot per round / cycle.
     * Formula: Total Expected Pot = Total Members * Monthly Contribution Amount
     */
    fun calculateExpectedPot(totalMembers: Int, contributionAmount: Double): Double {
        if (totalMembers <= 0 || contributionAmount <= 0.0) return 0.0
        return totalMembers * contributionAmount
    }

    /**
     * Calculates the total Chit Fund scheme valuation across all cycles.
     * For a typical Chit Fund: Total Value = Total Chits / Rounds * Expected Pot Per Round
     */
    fun calculateTotalChitValue(
        totalMembers: Int,
        totalCycles: Int,
        monthlyContribution: Double
    ): Double {
        if (totalMembers <= 0 || totalCycles <= 0 || monthlyContribution <= 0.0) return 0.0
        return totalMembers * monthlyContribution
    }

    /**
     * Validates whether a user-configured total value is mathematically consistent.
     */
    fun isTotalValueConsistent(
        configuredTotalValue: Double?,
        totalMembers: Int?,
        monthlyContribution: Double?
    ): Boolean {
        if (configuredTotalValue == null || configuredTotalValue <= 0.0) return true
        if (totalMembers == null || totalMembers <= 0) return true
        if (monthlyContribution == null || monthlyContribution <= 0.0) return true

        val expected = totalMembers * monthlyContribution
        val diff = kotlin.math.abs(configuredTotalValue - expected)
        return diff < 1.0 // Within 1 currency unit
    }

    /**
     * Cycle Metrics summary container.
     */
    data class CycleMetrics(
        val totalCycles: Int,
        val completedCycles: Int,
        val remainingCycles: Int,
        val cancelledCycles: Int,
        val currentCycleNumber: Int,
        val currentCycle: ChitCycle?,
        val nextAuctionCycle: ChitCycle?,
        val progressPercent: Int,
        val isAuctionLive: Boolean
    ) {
        val hasStartedOrCompletedCycles: Boolean
            get() = completedCycles > 0 || isAuctionLive || currentCycleNumber > 1
    }

    /**
     * Validation result container for Chit Fund configuration.
     */
    data class ValidationResult(
        val isValid: Boolean,
        val calculatedExpectedPot: Double,
        val calculatedTotalValue: Double,
        val warningMessage: String? = null
    )

    /**
     * Mathematical validation for Chit Fund scheme setup.
     */
    fun validateConfiguration(
        totalMembers: Int?,
        totalCycles: Int?,
        installmentAmount: Double?,
        totalChitValue: Double?
    ): ValidationResult {
        val members = totalMembers ?: 0
        val cycles = totalCycles ?: members
        val inst = installmentAmount ?: 0.0
        val expectedPot = members * inst
        val configuredVal = totalChitValue ?: expectedPot

        var warning: String? = null
        if (members > 0 && inst > 0.0 && configuredVal > 0.0) {
            val pot = members * inst
            if (kotlin.math.abs(configuredVal - pot) > 1.0) {
                warning = "Note: Total chit value (${configuredVal.toInt()}) differs from expected round contribution (${members} × ${inst.toInt()} = ${pot.toInt()})."
            }
        }

        return ValidationResult(
            isValid = members > 0 && cycles > 0 && inst > 0.0,
            calculatedExpectedPot = expectedPot,
            calculatedTotalValue = configuredVal,
            warningMessage = warning
        )
    }

    /**
     * Derives cycle counts, completion metrics, and the active/next auction cycle.
     * Inspects actual cycle statuses instead of assuming sequential linear index.
     */
    fun deriveCycleMetrics(
        cycles: List<ChitCycle>,
        configuredTotalCycles: Int?,
        currentChitNoOverride: Int? = null,
        nowMillis: Long = System.currentTimeMillis()
    ): CycleMetrics {
        val totalCount = configuredTotalCycles ?: cycles.size.takeIf { it > 0 } ?: 0

        val completedCount = cycles.count { it.status == ChitCycleStatus.COMPLETED }
        val cancelledCount = cycles.count { it.status == ChitCycleStatus.CANCELLED }

        // Find the active cycle with priority:
        // 1. Cycle currently marked or operating in AUCTION_OPEN
        // 2. Cycle currently in RESULT_PENDING or AUCTION_CLOSED
        // 3. Cycle in AUCTION_SCHEDULED or RESCHEDULED
        // 4. First UPCOMING cycle
        val operationalCycles = cycles.map { cycle ->
            val opStatus = cycle.deriveOperationalStatus(nowMillis)
            cycle.copy(status = opStatus)
        }

        val activeCycle = operationalCycles.firstOrNull { it.status == ChitCycleStatus.AUCTION_OPEN }
            ?: operationalCycles.firstOrNull { it.status in listOf(ChitCycleStatus.AUCTION_CLOSED, ChitCycleStatus.RESULT_PENDING) }
            ?: operationalCycles.firstOrNull { it.status in listOf(ChitCycleStatus.AUCTION_SCHEDULED, ChitCycleStatus.RESCHEDULED) }
            ?: operationalCycles.firstOrNull { it.status == ChitCycleStatus.UPCOMING }
            ?: operationalCycles.firstOrNull { !it.status.isTerminal() }

        val currentCycleNumber = currentChitNoOverride
            ?: activeCycle?.cycleNumber
            ?: (completedCount + 1).coerceAtMost(if (totalCount > 0) totalCount else 1)

        val remainingCount = if (totalCount > 0) {
            (totalCount - completedCount - cancelledCount).coerceAtLeast(0)
        } else {
            cycles.count { !it.status.isTerminal() }
        }

        val progressPercent = if (totalCount > 0) {
            ((completedCount.toDouble() / totalCount.toDouble()) * 100).roundToInt().coerceIn(0, 100)
        } else 0

        val isAuctionLive = activeCycle?.status == ChitCycleStatus.AUCTION_OPEN

        return CycleMetrics(
            totalCycles = totalCount,
            completedCycles = completedCount,
            remainingCycles = remainingCount,
            cancelledCycles = cancelledCount,
            currentCycleNumber = currentCycleNumber,
            currentCycle = activeCycle,
            nextAuctionCycle = activeCycle,
            progressPercent = progressPercent,
            isAuctionLive = isAuctionLive
        )
    }

    /**
     * Generates a safe, complete list of [ChitCycle] schedules for a Chit Fund scheme.
     * Preserves existing cycle data (winners, manual reschedules, status) if already present.
     *
     * Handles varying month lengths safely (e.g., Jan 31 -> Feb 28 -> Mar 31) without spillover.
     */
    fun generateOrUpdateCycleSchedule(
        existingCycles: List<ChitCycle>,
        totalCycles: Int,
        installmentAmount: Double,
        startDateMillis: Long?,
        frequency: String = "MONTHLY",
        auctionScheduleDay: Int? = null,
        auctionStartTime: String = "08:00 PM",
        auctionEndTime: String = "08:15 PM",
        auctionDurationMinutes: Int = 15
    ): List<ChitCycle> {
        if (totalCycles <= 0) return emptyList()

        val baseStartMillis = startDateMillis?.takeIf { it > 0L } ?: System.currentTimeMillis()
        val anchorCalendar = Calendar.getInstance().apply { timeInMillis = baseStartMillis }
        val anchorDayOfMonth = auctionScheduleDay?.takeIf { it in 1..31 } ?: anchorCalendar.get(Calendar.DAY_OF_MONTH)

        val existingMap = existingCycles.associateBy { it.cycleNumber }
        val updatedList = mutableListOf<ChitCycle>()

        for (cycleNo in 1..totalCycles) {
            val existing = existingMap[cycleNo]

            if (existing != null && (existing.status == ChitCycleStatus.COMPLETED || existing.isDateManuallyRescheduled)) {
                // Preserve completed or manually rescheduled cycles
                updatedList.add(
                    existing.copy(
                        installmentAmount = if (existing.installmentAmount > 0) existing.installmentAmount else installmentAmount,
                        auctionStartTime = existing.auctionStartTime ?: auctionStartTime,
                        auctionEndTime = existing.auctionEndTime ?: auctionEndTime,
                        auctionDurationMinutes = if (existing.auctionDurationMinutes > 0) existing.auctionDurationMinutes else auctionDurationMinutes
                    )
                )
            } else {
                // Calculate safe scheduled timestamp based on frequency
                val cycleCal = Calendar.getInstance().apply { timeInMillis = baseStartMillis }
                val step = cycleNo - 1

                when (frequency.uppercase(Locale.US)) {
                    "WEEKLY" -> {
                        cycleCal.add(Calendar.WEEK_OF_YEAR, step)
                    }
                    "DAILY" -> {
                        cycleCal.add(Calendar.DAY_OF_YEAR, step)
                    }
                    else -> {
                        // MONTHLY calculation with safe day-of-month anchoring
                        cycleCal.add(Calendar.MONTH, step)
                        val maxDaysInMonth = cycleCal.getActualMaximum(Calendar.DAY_OF_MONTH)
                        cycleCal.set(Calendar.DAY_OF_MONTH, anchorDayOfMonth.coerceAtMost(maxDaysInMonth))
                    }
                }

                // Default scheduled auction time to 8:00 PM on that day
                cycleCal.set(Calendar.HOUR_OF_DAY, 20)
                cycleCal.set(Calendar.MINUTE, 0)
                cycleCal.set(Calendar.SECOND, 0)
                cycleCal.set(Calendar.MILLISECOND, 0)

                val scheduledMillis = cycleCal.timeInMillis

                val defaultStatus = if (existing != null) existing.status else {
                    if (cycleNo == 1) ChitCycleStatus.AUCTION_SCHEDULED else ChitCycleStatus.UPCOMING
                }

                updatedList.add(
                    ChitCycle(
                        cycleNumber = cycleNo,
                        scheduledDateMillis = scheduledMillis,
                        installmentAmount = installmentAmount,
                        status = defaultStatus,
                        auctionDateMillis = scheduledMillis,
                        auctionStartTime = auctionStartTime,
                        auctionEndTime = auctionEndTime,
                        auctionDurationMinutes = auctionDurationMinutes,
                        isDateManuallyRescheduled = false,
                        winnerMemberId = existing?.winnerMemberId,
                        winnerMemberName = existing?.winnerMemberName,
                        winningBidAmount = existing?.winningBidAmount,
                        dividendPerMember = existing?.dividendPerMember,
                        notes = existing?.notes ?: "",
                        createdAtMillis = existing?.createdAtMillis ?: System.currentTimeMillis(),
                        updatedAtMillis = System.currentTimeMillis()
                    )
                )
            }
        }

        return updatedList
    }

    /**
     * Compatibility overload for cycle schedule generation.
     */
    fun generateOrUpdateCycles(
        totalCycles: Int,
        installmentAmount: Double,
        startDateMillis: Long?,
        frequency: String = "MONTHLY",
        existingCycles: List<ChitCycle> = emptyList(),
        auctionScheduleDay: Int? = null,
        auctionStartTime: String = "08:00 PM",
        auctionEndTime: String = "08:15 PM",
        auctionDurationMinutes: Int = 15
    ): List<ChitCycle> {
        return generateOrUpdateCycleSchedule(
            existingCycles = existingCycles,
            totalCycles = totalCycles,
            installmentAmount = installmentAmount,
            startDateMillis = startDateMillis,
            frequency = frequency,
            auctionScheduleDay = auctionScheduleDay,
            auctionStartTime = auctionStartTime,
            auctionEndTime = auctionEndTime,
            auctionDurationMinutes = auctionDurationMinutes
        )
    }

    /**
     * Formats duration in seconds into human-readable countdown string.
     */
    fun formatCountdown(secondsRemaining: Long): String {
        if (secondsRemaining <= 0L) return "00:00"
        val days = secondsRemaining / 86400
        val hours = (secondsRemaining % 86400) / 3600
        val minutes = (secondsRemaining % 3600) / 60
        val seconds = secondsRemaining % 60

        return when {
            days > 0 -> String.format(Locale.US, "%dd %02dh %02dm", days, hours, minutes)
            hours > 0 -> String.format(Locale.US, "%02dh %02dm %02ds", hours, minutes, seconds)
            else -> String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    // =========================================================================
    // PHASE B.3 — REAL BID ENGINE & ELIGIBILITY CALCULATIONS
    // =========================================================================

    /**
     * Calculates permissible discount bid bounds for an auction.
     * In Chit Funds, minimum discount is the foreman commission floor (default 5%)
     * and maximum discount is the statutory/safe ceiling (default 30% - 40%).
     */
    fun calculateDiscountBounds(
        totalPot: Double,
        minDiscountPercent: Double = 5.0,
        maxDiscountPercent: Double = 30.0
    ): Pair<Double, Double> {
        if (totalPot <= 0.0) return Pair(0.0, 0.0)
        val minDiscount = (totalPot * (minDiscountPercent / 100.0)).coerceAtLeast(0.0)
        val maxDiscount = (totalPot * (maxDiscountPercent / 100.0)).coerceAtLeast(minDiscount)
        return Pair(minDiscount, maxDiscount)
    }

    /**
     * Evaluates whether a group member is eligible to participate and submit bids in an auction.
     *
     * Strict rules:
     * 1. Member must not have already won a chit in earlier completed rounds.
     * 2. Member must not have outstanding unpaid dues/installments from prior cycles.
     */
    fun evaluateMemberEligibility(
        memberId: Long,
        memberName: String,
        allCycles: List<ChitCycle>,
        currentCycleNumber: Int,
        memberPayments: List<Payment>,
        monthlyInstallment: Double
    ): com.adr.groupledger.data.model.ChitMemberEligibility {
        // 1. Check prior won rounds
        val priorWonCycle = allCycles.firstOrNull {
            it.status == ChitCycleStatus.COMPLETED && it.winnerMemberId == memberId
        }

        if (priorWonCycle != null) {
            return com.adr.groupledger.data.model.ChitMemberEligibility(
                memberId = memberId,
                memberName = memberName,
                isEligible = false,
                reason = "Ineligible: Prized subscriber (Already won Round #${priorWonCycle.cycleNumber})",
                hasWonPriorRound = true,
                priorWonRoundNumber = priorWonCycle.cycleNumber
            )
        }

        // 2. Check pending dues from past completed months/cycles
        val unpaidDue = memberPayments.filter {
            it.memberId == memberId && (it.status == "UNPAID" || it.status == "PARTIAL")
        }.sumOf { it.dueAmount }

        if (unpaidDue > 0.0) {
            return com.adr.groupledger.data.model.ChitMemberEligibility(
                memberId = memberId,
                memberName = memberName,
                isEligible = false,
                reason = "Ineligible: Pending installment dues of ₹${unpaidDue.toInt()} must be cleared",
                hasPendingDues = true,
                pendingDuesAmount = unpaidDue
            )
        }

        return com.adr.groupledger.data.model.ChitMemberEligibility(
            memberId = memberId,
            memberName = memberName,
            isEligible = true,
            reason = "Eligible to participate in bidding"
        )
    }

    data class BidValidationResult(
        val isValid: Boolean,
        val status: com.adr.groupledger.data.model.ChitBidStatus,
        val errorMessage: String? = null
    )

    /**
     * Authoritative validator for bid submissions.
     * Validates auction open status, time window, member eligibility, discount bounds,
     * and minimum increment rules.
     */
    fun validateBidSubmission(
        bidAmount: Double,
        totalPot: Double,
        eligibility: com.adr.groupledger.data.model.ChitMemberEligibility,
        cycleStatus: ChitCycleStatus,
        nowMillis: Long,
        startEpoch: Long,
        endEpoch: Long,
        minDiscountPercent: Double = 5.0,
        maxDiscountPercent: Double = 30.0
    ): BidValidationResult {
        // 1. Verify Member Eligibility
        if (!eligibility.isEligible) {
            return BidValidationResult(
                isValid = false,
                status = com.adr.groupledger.data.model.ChitBidStatus.REJECTED,
                errorMessage = eligibility.reason
            )
        }

        // 2. Verify Cycle Operational Status
        if (cycleStatus != ChitCycleStatus.AUCTION_OPEN) {
            return BidValidationResult(
                isValid = false,
                status = com.adr.groupledger.data.model.ChitBidStatus.REJECTED,
                errorMessage = "Bidding is only permitted when auction status is AUCTION_OPEN"
            )
        }

        // 3. Verify Auction Time Window
        if (nowMillis < startEpoch) {
            return BidValidationResult(
                isValid = false,
                status = com.adr.groupledger.data.model.ChitBidStatus.REJECTED,
                errorMessage = "Auction has not started yet"
            )
        }

        if (nowMillis > endEpoch) {
            return BidValidationResult(
                isValid = false,
                status = com.adr.groupledger.data.model.ChitBidStatus.REJECTED,
                errorMessage = "Auction bidding window has closed"
            )
        }

        // 4. Verify Discount Bounds
        val (minDiscount, maxDiscount) = calculateDiscountBounds(totalPot, minDiscountPercent, maxDiscountPercent)

        if (bidAmount < minDiscount) {
            return BidValidationResult(
                isValid = false,
                status = com.adr.groupledger.data.model.ChitBidStatus.INVALID,
                errorMessage = "Bid discount cannot be less than minimum floor of ₹${minDiscount.toInt()} (${minDiscountPercent.toInt()}%)"
            )
        }

        if (bidAmount > maxDiscount) {
            return BidValidationResult(
                isValid = false,
                status = com.adr.groupledger.data.model.ChitBidStatus.INVALID,
                errorMessage = "Bid discount exceeds the maximum allowed cap of ₹${maxDiscount.toInt()} (${maxDiscountPercent.toInt()}%)"
            )
        }

        return BidValidationResult(
            isValid = true,
            status = com.adr.groupledger.data.model.ChitBidStatus.VALID,
            errorMessage = null
        )
    }

    /**
     * Determines the current highest valid discount bid in an auction.
     * In Chit Fund reverse bidding, the highest discount bid wins.
     * Ties are broken by earlier submission timestamp.
     */
    fun resolveHighestBid(bids: List<com.adr.groupledger.data.model.ChitBid>): com.adr.groupledger.data.model.ChitBid? {
        val validBids = bids.filter { it.status == com.adr.groupledger.data.model.ChitBidStatus.VALID || it.status == com.adr.groupledger.data.model.ChitBidStatus.SUBMITTED }
        return validBids.maxWithOrNull(
            compareBy<com.adr.groupledger.data.model.ChitBid> { it.bidAmount }
                .thenBy { -it.submittedAtMillis } // Earlier timestamp has priority on tie
        )
    }

    /**
     * Ranks all bids in descending order of discount amount, followed by earliest submission time.
     */
    fun rankBids(bids: List<com.adr.groupledger.data.model.ChitBid>): List<com.adr.groupledger.data.model.ChitBid> {
        return bids.sortedWith(
            compareByDescending<com.adr.groupledger.data.model.ChitBid> { it.status == com.adr.groupledger.data.model.ChitBidStatus.VALID }
                .thenByDescending { it.bidAmount }
                .thenBy { it.submittedAtMillis }
        )
    }

    /**
     * Computes the estimated financial outcome of an auction based on current highest discount bid.
     *
     * Prize Money = Total Pot - Winning Discount
     * Foreman Commission = Total Pot * 5%
     * Surplus Dividend Pool = Winning Discount - Foreman Commission
     * Dividend per non-prized member = Surplus Pool / Total Members
     * Net Next Installment = Base Installment - Dividend
     */
    fun calculateEstimatedPrizeAndDividend(
        totalPot: Double,
        highestDiscountBid: Double,
        totalMembers: Int,
        foremanCommissionPercent: Double = 5.0,
        monthlyInstallment: Double = 0.0
    ): com.adr.groupledger.data.model.EstimatedAuctionOutcome {
        val payout = (totalPot - highestDiscountBid).coerceAtLeast(0.0)
        val commission = (totalPot * (foremanCommissionPercent / 100.0)).coerceAtLeast(0.0)
        val surplus = (highestDiscountBid - commission).coerceAtLeast(0.0)
        val dividend = if (totalMembers > 0) surplus / totalMembers else 0.0
        val netInstallment = (monthlyInstallment - dividend).coerceAtLeast(0.0)

        return com.adr.groupledger.data.model.EstimatedAuctionOutcome(
            totalPot = totalPot,
            winningDiscountBid = highestDiscountBid,
            prizePayoutAmount = payout,
            foremanCommission = commission,
            surplusDividendPool = surplus,
            dividendPerMember = dividend,
            netNextInstallment = netInstallment
        )
    }

    /**
     * Phase B.4 Authoritative Auction Result & Winner Determination Engine.
     *
     * Flow:
     * 1. Inspect configured bidding rule. If undefined, marks RESULT_REQUIRES_RULE without unsafe assumptions.
     * 2. Filter strictly valid, on-time, deduplicated bids belonging to this auction cycle.
     * 3. Evaluate candidate winner deterministically under the verified rule.
     * 4. Enforce strict tie detection: If multiple bids share the winning discount, status becomes
     *    TIE_REQUIRES_ADMIN_REVIEW without automatic winner assignment.
     * 5. Compute full settlement preview without modifying balances or writing ledger records.
     */
    fun calculateAuthoritativeAuctionResult(
        cycle: ChitCycle,
        totalMembers: Int,
        auctionRule: String = "HIGHEST_DISCOUNT",
        foremanCommissionPercent: Double = 5.0
    ): com.adr.groupledger.data.model.ChitAuctionResult {
        val totalPot = totalMembers * cycle.installmentAmount

        // 1. Confirm bidding rule
        val normalizedRule = auctionRule.trim().uppercase(java.util.Locale.US)
        if (normalizedRule != "HIGHEST_DISCOUNT") {
            val emptyOutcome = calculateEstimatedPrizeAndDividend(
                totalPot = totalPot,
                highestDiscountBid = 0.0,
                totalMembers = totalMembers,
                foremanCommissionPercent = foremanCommissionPercent,
                monthlyInstallment = cycle.installmentAmount
            )
            return com.adr.groupledger.data.model.ChitAuctionResult(
                auctionId = "AUC-C${cycle.cycleNumber}",
                groupId = 1L,
                cycleNumber = cycle.cycleNumber,
                resultStatus = com.adr.groupledger.data.model.ChitAuctionResultStatus.RESULT_REQUIRES_RULE,
                ruleUsed = normalizedRule.ifBlank { "UNDEFINED" },
                ruleMissingReason = "Missing or unsupported bidding rule '${auctionRule.ifBlank { "(empty)" }}'. Configured rule must be 'HIGHEST_DISCOUNT'.",
                totalBidsCount = cycle.bids.size,
                validBidsCount = 0,
                estimatedOutcome = emptyOutcome,
                createdAtMillis = System.currentTimeMillis()
            )
        }

        // 2. Filter strictly valid, on-time bids
        val endEpoch = cycle.resolveAuctionEndEpoch()
        val validStatusBids = cycle.bids.filter {
            it.status == com.adr.groupledger.data.model.ChitBidStatus.VALID ||
            it.status == com.adr.groupledger.data.model.ChitBidStatus.SUBMITTED
        }

        // Allow bids submitted within the window or during open floor
        val onTimeBids = validStatusBids.filter {
            endEpoch <= 0L || it.submittedAtMillis <= (endEpoch + 60_000L) // 1-minute grace for network latency
        }

        // Deduplicate per member: take latest submission
        val deduplicatedBids = onTimeBids
            .groupBy { it.memberId }
            .map { entry -> entry.value.maxByOrNull { it.submittedAtMillis }!! }

        if (deduplicatedBids.isEmpty()) {
            val emptyOutcome = calculateEstimatedPrizeAndDividend(
                totalPot = totalPot,
                highestDiscountBid = 0.0,
                totalMembers = totalMembers,
                foremanCommissionPercent = foremanCommissionPercent,
                monthlyInstallment = cycle.installmentAmount
            )
            return com.adr.groupledger.data.model.ChitAuctionResult(
                auctionId = "AUC-C${cycle.cycleNumber}",
                groupId = 1L,
                cycleNumber = cycle.cycleNumber,
                resultStatus = com.adr.groupledger.data.model.ChitAuctionResultStatus.NO_VALID_BIDS,
                ruleUsed = "HIGHEST_DISCOUNT",
                totalBidsCount = cycle.bids.size,
                validBidsCount = 0,
                estimatedOutcome = emptyOutcome,
                createdAtMillis = System.currentTimeMillis()
            )
        }

        // 3. Reverse bidding: highest valid discount wins
        val maxDiscount = deduplicatedBids.maxOf { it.bidAmount }
        val topBids = deduplicatedBids.filter { kotlin.math.abs(it.bidAmount - maxDiscount) < 0.01 }

        // 4. Strict Tie Handling
        if (topBids.size > 1) {
            val outcome = calculateEstimatedPrizeAndDividend(
                totalPot = totalPot,
                highestDiscountBid = maxDiscount,
                totalMembers = totalMembers,
                foremanCommissionPercent = foremanCommissionPercent,
                monthlyInstallment = cycle.installmentAmount
            )
            return com.adr.groupledger.data.model.ChitAuctionResult(
                auctionId = topBids.first().auctionId.ifBlank { "AUC-C${cycle.cycleNumber}" },
                groupId = topBids.first().groupId,
                cycleNumber = cycle.cycleNumber,
                winningMemberId = null, // Tie: Admin MUST review and select
                winningBidId = null,
                winningBidAmount = maxDiscount,
                winningMemberName = null,
                resultStatus = com.adr.groupledger.data.model.ChitAuctionResultStatus.TIE_REQUIRES_ADMIN_REVIEW,
                createdAtMillis = System.currentTimeMillis(),
                isTie = true,
                tiedMemberIds = topBids.map { it.memberId },
                tiedMemberNames = topBids.map { it.memberName },
                totalBidsCount = cycle.bids.size,
                validBidsCount = deduplicatedBids.size,
                ruleUsed = "HIGHEST_DISCOUNT",
                estimatedOutcome = outcome
            )
        }

        // 5. Deterministic Single Winner Found
        val winningBid = topBids.first()
        val outcome = calculateEstimatedPrizeAndDividend(
            totalPot = totalPot,
            highestDiscountBid = winningBid.bidAmount,
            totalMembers = totalMembers,
            foremanCommissionPercent = foremanCommissionPercent,
            monthlyInstallment = cycle.installmentAmount
        )

        return com.adr.groupledger.data.model.ChitAuctionResult(
            auctionId = winningBid.auctionId.ifBlank { "AUC-C${cycle.cycleNumber}" },
            groupId = winningBid.groupId,
            cycleNumber = cycle.cycleNumber,
            winningMemberId = winningBid.memberId,
            winningBidId = winningBid.bidId,
            winningBidAmount = winningBid.bidAmount,
            winningMemberName = winningBid.memberName,
            resultStatus = com.adr.groupledger.data.model.ChitAuctionResultStatus.RESULT_CALCULATED,
            createdAtMillis = System.currentTimeMillis(),
            isTie = false,
            tiedMemberIds = emptyList(),
            tiedMemberNames = emptyList(),
            totalBidsCount = cycle.bids.size,
            validBidsCount = deduplicatedBids.size,
            ruleUsed = "HIGHEST_DISCOUNT",
            estimatedOutcome = outcome
        )
    }

    /**
     * Deterministic Result Preparation for a closed Chit Fund auction (Backward compatible helper).
     */
    fun prepareAuctionResult(
        cycle: ChitCycle,
        totalMembers: Int,
        foremanCommissionPercent: Double = 5.0
    ): com.adr.groupledger.data.model.ChitAuctionResultPreparation {
        val validBids = cycle.bids.filter {
            it.status == com.adr.groupledger.data.model.ChitBidStatus.VALID ||
            it.status == com.adr.groupledger.data.model.ChitBidStatus.SUBMITTED
        }

        val totalPot = totalMembers * cycle.installmentAmount

        if (validBids.isEmpty()) {
            val outcome = calculateEstimatedPrizeAndDividend(
                totalPot = totalPot,
                highestDiscountBid = 0.0,
                totalMembers = totalMembers,
                foremanCommissionPercent = foremanCommissionPercent,
                monthlyInstallment = cycle.installmentAmount
            )
            return com.adr.groupledger.data.model.ChitAuctionResultPreparation(
                auctionId = "AUC-C${cycle.cycleNumber}",
                groupId = 1L,
                cycleNumber = cycle.cycleNumber,
                totalBidsCount = cycle.bids.size,
                validBidsCount = 0,
                highestBidAmount = null,
                candidateWinnerMemberId = null,
                candidateWinnerMemberName = null,
                isTie = false,
                estimatedOutcome = outcome,
                preparedAtMillis = System.currentTimeMillis(),
                status = "NO_BIDS"
            )
        }

        // Reverse bidding: highest discount bid wins
        val maxDiscount = validBids.maxOf { it.bidAmount }
        val topBids = validBids.filter { kotlin.math.abs(it.bidAmount - maxDiscount) < 0.01 }
        val isTie = topBids.size > 1
        val tiedNames = if (isTie) topBids.map { it.memberName } else emptyList()

        // Deterministic candidate winner by earliest submission timestamp
        val winningBid = topBids.minByOrNull { it.submittedAtMillis } ?: topBids.first()

        val outcome = calculateEstimatedPrizeAndDividend(
            totalPot = totalPot,
            highestDiscountBid = winningBid.bidAmount,
            totalMembers = totalMembers,
            foremanCommissionPercent = foremanCommissionPercent,
            monthlyInstallment = cycle.installmentAmount
        )

        return com.adr.groupledger.data.model.ChitAuctionResultPreparation(
            auctionId = winningBid.auctionId.ifBlank { "AUC-C${cycle.cycleNumber}" },
            groupId = winningBid.groupId,
            cycleNumber = cycle.cycleNumber,
            totalBidsCount = cycle.bids.size,
            validBidsCount = validBids.size,
            highestBidAmount = winningBid.bidAmount,
            candidateWinnerMemberId = winningBid.memberId,
            candidateWinnerMemberName = winningBid.memberName,
            isTie = isTie,
            tiedMemberNames = tiedNames,
            tieResolutionMethod = if (isTie) "EARLIEST_TIMESTAMP" else "HIGHEST_DISCOUNT",
            estimatedOutcome = outcome,
            preparedAtMillis = System.currentTimeMillis(),
            status = "RESULT_PENDING"
        )
    }

    // =========================================================================
    // PHASE B.6 — REPORTING, HISTORY & LEDGER RECONCILIATION COMPUTATIONS
    // =========================================================================

    /**
     * Computes the high-level Chit Fund Report Overview from actual saved configuration,
     * cycles, payments, and ledger transactions.
     */
    fun computeChitFundReportOverview(
        config: ChitFundConfig,
        membersCount: Int,
        payments: List<Payment>,
        transactions: List<com.adr.groupledger.data.model.TransactionRecord> = emptyList()
    ): com.adr.groupledger.data.model.ChitFundReportOverview {
        val totalMembers = config.totalMembers ?: membersCount.coerceAtLeast(1)
        val cycles = config.cycles
        val totalCycles = config.totalChits ?: cycles.size.coerceAtLeast(1)
        val installment = config.monthlyInstallment ?: 5000.0
        val totalChitVal = config.totalValue ?: (totalMembers * totalCycles * installment)

        val completedCycles = cycles.filter {
            it.status == ChitCycleStatus.COMPLETED ||
            it.status == ChitCycleStatus.SETTLED ||
            it.auctionResult?.resultStatus == com.adr.groupledger.data.model.ChitAuctionResultStatus.SETTLED
        }

        val settledResults = cycles.mapNotNull { it.auctionResult }.filter {
            it.resultStatus == com.adr.groupledger.data.model.ChitAuctionResultStatus.SETTLED ||
            it.settlementPayoutTxnId != null
        }

        val pendingSettlementCycles = cycles.filter {
            it.status == ChitCycleStatus.RESULT_APPROVED ||
            it.status == ChitCycleStatus.SETTLEMENT_PENDING ||
            it.status == ChitCycleStatus.SETTLEMENT_PROCESSING ||
            it.auctionResult?.resultStatus in listOf(
                com.adr.groupledger.data.model.ChitAuctionResultStatus.RESULT_APPROVED,
                com.adr.groupledger.data.model.ChitAuctionResultStatus.SETTLEMENT_PENDING,
                com.adr.groupledger.data.model.ChitAuctionResultStatus.SETTLEMENT_PROCESSING
            )
        }

        val activeCycle = cycles.firstOrNull {
            it.status in listOf(
                ChitCycleStatus.AUCTION_SCHEDULED,
                ChitCycleStatus.AUCTION_OPEN,
                ChitCycleStatus.AUCTION_CLOSED,
                ChitCycleStatus.RESULT_PENDING,
                ChitCycleStatus.RESULT_CALCULATED,
                ChitCycleStatus.TIE_REQUIRES_ADMIN_REVIEW,
                ChitCycleStatus.RESULT_APPROVED,
                ChitCycleStatus.SETTLEMENT_PENDING,
                ChitCycleStatus.SETTLEMENT_PROCESSING,
                ChitCycleStatus.RESCHEDULED
            )
        } ?: cycles.firstOrNull { !it.status.isTerminal() } ?: cycles.firstOrNull()

        val totalApprovedPayments = payments.filter { it.isApproved }
        val totalContributions = totalApprovedPayments.sumOf { it.paidAmount }

        val totalDiscounts = settledResults.sumOf { it.winningBidAmount ?: 0.0 }
        val totalPrizePaid = settledResults.sumOf { it.estimatedOutcome?.prizePayoutAmount ?: 0.0 }
        val totalCommission = settledResults.sumOf { it.estimatedOutcome?.foremanCommission ?: 0.0 }
        val totalDividends = settledResults.sumOf { (it.estimatedOutcome?.dividendPerMember ?: 0.0) * totalMembers }

        val pendingSettlementAmount = pendingSettlementCycles.sumOf { c ->
            c.auctionResult?.estimatedOutcome?.prizePayoutAmount ?: 0.0
        }

        // Ledger check
        val ledgerPayoutTxns = transactions.filter {
            it.type == "CHIT_PRIZE_PAYOUT" || it.description.contains("Chit Fund Round", ignoreCase = true)
        }
        val isReconciled = settledResults.all { res ->
            res.settlementPayoutTxnId != null || ledgerPayoutTxns.any {
                it.txnNumber == res.settlementPayoutTxnId || it.description.contains("Round #${res.cycleNumber}")
            }
        }

        return com.adr.groupledger.data.model.ChitFundReportOverview(
            totalChitValue = totalChitVal,
            totalMembers = totalMembers,
            totalCycles = totalCycles,
            completedCyclesCount = completedCycles.size,
            currentCycleNumber = activeCycle?.cycleNumber ?: 1,
            remainingCyclesCount = (totalCycles - completedCycles.size).coerceAtLeast(0),
            totalContributionsCollected = totalContributions,
            totalAuctionDiscounts = totalDiscounts,
            totalSettledPrizeAmount = totalPrizePaid,
            totalForemanCommission = totalCommission,
            totalDividendsDistributed = totalDividends,
            pendingSettlementCount = pendingSettlementCycles.size,
            pendingSettlementAmount = pendingSettlementAmount,
            isAllReconciled = isReconciled,
            reconciliationMessage = if (isReconciled) {
                "All ${settledResults.size} settled rounds reconciled with Group Ledger"
            } else {
                "${settledResults.count { it.settlementPayoutTxnId == null }} settled rounds have pending ledger sync"
            }
        )
    }

    /**
     * Computes individual cycle report line items for Cycle History & Auction performance.
     */
    fun computeCycleReportItems(
        config: ChitFundConfig,
        membersCount: Int,
        payments: List<Payment>,
        transactions: List<com.adr.groupledger.data.model.TransactionRecord> = emptyList()
    ): List<com.adr.groupledger.data.model.ChitCycleReportItem> {
        val totalMembers = config.totalMembers ?: membersCount.coerceAtLeast(1)
        val defaultInst = config.monthlyInstallment ?: 5000.0

        return config.cycles.map { cycle ->
            val inst = cycle.installmentAmount.takeIf { it > 0 } ?: defaultInst
            val totalPot = totalMembers * inst
            val result = cycle.auctionResult
            val isSettled = cycle.status == ChitCycleStatus.SETTLED ||
                    result?.resultStatus == com.adr.groupledger.data.model.ChitAuctionResultStatus.SETTLED

            val outcome = result?.estimatedOutcome
            val validBids = cycle.bids.filter {
                it.status == com.adr.groupledger.data.model.ChitBidStatus.VALID ||
                it.status == com.adr.groupledger.data.model.ChitBidStatus.SUBMITTED
            }

            // Estimate payments for this cycle by date epoch
            val cal = Calendar.getInstance().apply {
                timeInMillis = cycle.auctionDateMillis ?: cycle.scheduledDateMillis
            }
            val cycleMonth = cal.get(Calendar.MONTH) + 1
            val cycleYear = cal.get(Calendar.YEAR)
            val cyclePayments = payments.filter { it.month == cycleMonth && it.year == cycleYear && it.isApproved }
            val collected = cyclePayments.sumOf { it.paidAmount }

            val isTxnLinked = result?.settlementPayoutTxnId != null ||
                    transactions.any {
                        it.txnNumber == result?.settlementPayoutTxnId ||
                        it.description.contains("Round #${cycle.cycleNumber}")
                    }

            com.adr.groupledger.data.model.ChitCycleReportItem(
                cycle = cycle,
                cycleNumber = cycle.cycleNumber,
                scheduledDateMillis = cycle.scheduledDateMillis,
                installmentAmount = inst,
                totalPot = totalPot,
                cycleStatus = cycle.status,
                winnerMemberId = result?.winningMemberId ?: cycle.winnerMemberId,
                winnerMemberName = result?.winningMemberName ?: cycle.winnerMemberName,
                winningBidAmount = result?.winningBidAmount ?: cycle.winningBidAmount,
                prizePayoutAmount = outcome?.prizePayoutAmount,
                foremanCommission = outcome?.foremanCommission,
                dividendPerMember = outcome?.dividendPerMember,
                settlementStatus = if (isSettled) "SETTLED" else result?.resultStatus?.displayName ?: cycle.status.displayName,
                payoutTxnRef = result?.settlementPayoutTxnId,
                commissionTxnRef = result?.settlementCommissionTxnId,
                bidsCount = cycle.bids.size,
                validBidsCount = validBids.size,
                totalCollectedForCycle = collected,
                totalExpectedForCycle = totalPot,
                isCycleReconciled = if (isSettled) isTxnLinked else true
            )
        }
    }

    /**
     * Computes member-wise Chit Fund ledger positions and financial summary.
     */
    fun computeMemberFinancialSummaries(
        config: ChitFundConfig,
        members: List<com.adr.groupledger.data.model.Member>,
        payments: List<Payment>
    ): List<com.adr.groupledger.data.model.ChitMemberFinancialSummary> {
        val settledResults = config.cycles.mapNotNull { it.auctionResult }.filter {
            it.resultStatus == com.adr.groupledger.data.model.ChitAuctionResultStatus.SETTLED ||
            it.settlementPayoutTxnId != null
        }

        val totalDividendPerMember = settledResults.sumOf { it.estimatedOutcome?.dividendPerMember ?: 0.0 }

        return members.map { member ->
            val memberPayments = payments.filter { it.memberId == member.id }
            val approvedPayments = memberPayments.filter { it.isApproved }
            val totalPaid = approvedPayments.sumOf { it.paidAmount }
            val totalDue = memberPayments.filter { !it.isApproved || it.status != "PAID" }.sumOf { it.dueAmount }

            val participatedCount = config.cycles.count { c ->
                c.bids.any { b -> b.memberId == member.id }
            }

            val wonCycles = settledResults.filter { it.winningMemberId == member.id }
            val wonCycleNumbers = wonCycles.map { it.cycleNumber }
            val totalPrizeWon = wonCycles.sumOf { it.estimatedOutcome?.prizePayoutAmount ?: 0.0 }

            // Net position: (Prize money won + Dividends earned) - Total installments paid
            val netPosition = (totalPrizeWon + totalDividendPerMember) - totalPaid

            com.adr.groupledger.data.model.ChitMemberFinancialSummary(
                member = member,
                totalPaidAmount = totalPaid,
                totalDueAmount = totalDue,
                totalDividendsEarned = totalDividendPerMember,
                participatedAuctionsCount = participatedCount,
                wonRounds = wonCycleNumbers,
                totalPrizeReceived = totalPrizeWon,
                netFinancialPosition = netPosition,
                paymentHistory = memberPayments.sortedByDescending { it.paymentDate }
            )
        }
    }

    // =========================================================================
    // PHASE B.7 — CONTRIBUTION, COLLECTION & MEMBER PAYMENT TRACKING
    // =========================================================================

    /**
     * Resolves the cycle month and year from scheduled or auction epoch.
     */
    fun resolveCycleMonthYear(cycle: ChitCycle): Pair<Int, Int> {
        val cal = Calendar.getInstance().apply {
            timeInMillis = cycle.auctionDateMillis ?: cycle.scheduledDateMillis
        }
        return Pair(cal.get(Calendar.MONTH) + 1, cal.get(Calendar.YEAR))
    }

    /**
     * Resolves the exact due date for a cycle given group settings and cycle schedule.
     */
    fun resolveCycleDueDateMillis(cycle: ChitCycle, settings: com.adr.groupledger.data.model.GroupSettings): Long {
        val (month, year) = resolveCycleMonthYear(cycle)
        val dueDay = settings.dueDayOfMonth.coerceIn(1, 28)
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month - 1)
            set(Calendar.DAY_OF_MONTH, dueDay)
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }
        return cal.timeInMillis
    }

    /**
     * Calculates late fine/penalty according to group settings.
     */
    fun calculateLateFine(
        dueDateMillis: Long,
        isFullyPaid: Boolean,
        settings: com.adr.groupledger.data.model.GroupSettings,
        nowMillis: Long = System.currentTimeMillis()
    ): Pair<Double, Int> {
        if (!settings.isLateFeeEnabled || settings.lateFineAmount <= 0.0 || isFullyPaid) {
            return Pair(0.0, 0)
        }

        val gracePeriodMs = settings.gracePeriodDays.coerceAtLeast(0) * 24L * 3600L * 1000L
        val effectiveDueDate = dueDateMillis + gracePeriodMs

        if (nowMillis > effectiveDueDate) {
            val overdueDays = ((nowMillis - effectiveDueDate) / (24L * 3600L * 1000L)).toInt().coerceAtLeast(1)
            return Pair(settings.lateFineAmount, overdueDays)
        }

        return Pair(0.0, 0)
    }

    /**
     * Resolves member-level contribution requirement for a specific cycle.
     */
    fun resolveRequiredContribution(
        cycle: ChitCycle,
        config: ChitFundConfig,
        settings: com.adr.groupledger.data.model.GroupSettings
    ): Double {
        if (cycle.installmentAmount > 0) return cycle.installmentAmount
        if (config.monthlyInstallment != null && config.monthlyInstallment > 0) return config.monthlyInstallment
        if (settings.defaultContribution > 0) return settings.defaultContribution
        return 5000.0
    }

    /**
     * Computes the collection summary for a specific Chit Fund cycle.
     */
    fun computeCycleCollectionSummary(
        cycle: ChitCycle,
        config: ChitFundConfig,
        settings: com.adr.groupledger.data.model.GroupSettings,
        members: List<com.adr.groupledger.data.model.Member>,
        payments: List<Payment>,
        nowMillis: Long = System.currentTimeMillis()
    ): com.adr.groupledger.data.model.ChitCycleCollectionSummary {
        val activeMembers = members.filter { it.isActive }
        val totalMembersCount = activeMembers.size.coerceAtLeast(1)
        val requiredPerMember = resolveRequiredContribution(cycle, config, settings)
        val totalExpected = totalMembersCount * requiredPerMember

        val (cycleMonth, cycleYear) = resolveCycleMonthYear(cycle)
        val dueDateMillis = resolveCycleDueDateMillis(cycle, settings)

        val cyclePayments = payments.filter {
            it.month == cycleMonth && it.year == cycleYear && it.isApproved
        }

        var paidCount = 0
        var partialCount = 0
        var pendingCount = 0
        var overdueCount = 0
        var totalFine = 0.0

        for (member in activeMembers) {
            val memberPayment = cyclePayments.find { it.memberId == member.id }
            val paid = memberPayment?.paidAmount ?: 0.0
            val isPaid = paid >= requiredPerMember && requiredPerMember > 0
            val isPartial = paid > 0 && paid < requiredPerMember

            val (fine, daysOverdue) = calculateLateFine(dueDateMillis, isPaid, settings, nowMillis)
            totalFine += fine

            when {
                isPaid -> paidCount++
                isPartial -> partialCount++
                daysOverdue > 0 -> overdueCount++
                else -> pendingCount++
            }
        }

        val totalCollected = cyclePayments.sumOf { it.paidAmount }
        val pendingCollection = (totalExpected - totalCollected).coerceAtLeast(0.0)
        val percentage = if (totalExpected > 0) ((totalCollected / totalExpected) * 100.0).toFloat().coerceIn(0f, 100f) else 0f

        // Reconciliation check
        val isReconciled = kotlin.math.abs(totalExpected - (totalMembersCount * requiredPerMember)) < 0.01 &&
                totalCollected <= totalExpected + 10.0 // allow minor rounding

        return com.adr.groupledger.data.model.ChitCycleCollectionSummary(
            cycleNumber = cycle.cycleNumber,
            scheduledDateMillis = cycle.auctionDateMillis ?: cycle.scheduledDateMillis,
            dueDateMillis = dueDateMillis,
            requiredContributionPerMember = requiredPerMember,
            totalEligibleMembers = totalMembersCount,
            totalExpectedCollection = totalExpected,
            totalCollectedAmount = totalCollected,
            pendingCollectionAmount = pendingCollection,
            collectionPercentage = percentage,
            paidMembersCount = paidCount,
            partialMembersCount = partialCount,
            pendingMembersCount = pendingCount,
            overdueMembersCount = overdueCount,
            totalFineApplicable = totalFine,
            isFullyCollected = pendingCollection <= 0.0 && paidCount == totalMembersCount,
            isReconciled = isReconciled,
            reconciliationMessage = if (isReconciled) "Collection reconciled with active members roster" else "Collection requires reconciliation review"
        )
    }

    /**
     * Computes individual member payment statuses for a specific cycle.
     */
    fun computeCycleMemberPaymentStatuses(
        cycle: ChitCycle,
        config: ChitFundConfig,
        settings: com.adr.groupledger.data.model.GroupSettings,
        members: List<com.adr.groupledger.data.model.Member>,
        payments: List<Payment>,
        nowMillis: Long = System.currentTimeMillis()
    ): List<com.adr.groupledger.data.model.ChitMemberPaymentStatus> {
        val (cycleMonth, cycleYear) = resolveCycleMonthYear(cycle)
        val dueDateMillis = resolveCycleDueDateMillis(cycle, settings)
        val defaultRequired = resolveRequiredContribution(cycle, config, settings)

        return members.map { member ->
            val required = member.monthlyContribution.takeIf { it > 0 } ?: defaultRequired
            val memberPayment = payments.find { it.memberId == member.id && it.month == cycleMonth && it.year == cycleYear }
            val isApproved = memberPayment?.isApproved == true
            val paid = if (isApproved) (memberPayment?.paidAmount ?: 0.0) else 0.0
            val remainingDue = (required - paid).coerceAtLeast(0.0)
            val isFullyPaid = paid >= required && required > 0

            val (fine, daysOverdue) = calculateLateFine(dueDateMillis, isFullyPaid, settings, nowMillis)

            val status = when {
                memberPayment?.isPendingApproval == true -> "PENDING_APPROVAL"
                memberPayment?.isRejected == true -> "REJECTED"
                isFullyPaid -> "PAID"
                paid > 0 -> "PARTIAL"
                daysOverdue > 0 -> "OVERDUE"
                else -> "PENDING"
            }

            com.adr.groupledger.data.model.ChitMemberPaymentStatus(
                member = member,
                cycleNumber = cycle.cycleNumber,
                month = cycleMonth,
                year = cycleYear,
                requiredAmount = required,
                paidAmount = paid,
                remainingDue = remainingDue,
                fineAmount = fine,
                totalDueWithFine = remainingDue + fine,
                dueDateMillis = dueDateMillis,
                isOverdue = daysOverdue > 0 && !isFullyPaid,
                daysOverdue = daysOverdue,
                paymentStatus = status,
                lastPaymentDate = memberPayment?.paymentDate,
                paymentMethod = memberPayment?.paymentMethod,
                transactionReference = memberPayment?.transactionReference,
                approvalStatus = memberPayment?.approvalStatus ?: "APPROVED",
                linkedPaymentId = memberPayment?.id,
                notes = memberPayment?.notes ?: ""
            )
        }
    }

    /**
     * Computes a member's comprehensive Chit Fund contribution profile across all cycles.
     */
    fun computeMyContributionProfile(
        memberId: Long,
        config: ChitFundConfig,
        settings: com.adr.groupledger.data.model.GroupSettings,
        members: List<com.adr.groupledger.data.model.Member>,
        payments: List<Payment>,
        nowMillis: Long = System.currentTimeMillis()
    ): com.adr.groupledger.data.model.ChitMyContributionProfile? {
        val member = members.find { it.id == memberId } ?: return null
        val cycles = config.cycles

        val cycleStatuses = cycles.map { cycle ->
            val statuses = computeCycleMemberPaymentStatuses(cycle, config, settings, listOf(member), payments, nowMillis)
            statuses.firstOrNull() ?: com.adr.groupledger.data.model.ChitMemberPaymentStatus(
                member = member,
                cycleNumber = cycle.cycleNumber,
                month = 1,
                year = 2026,
                requiredAmount = resolveRequiredContribution(cycle, config, settings),
                paidAmount = 0.0,
                remainingDue = resolveRequiredContribution(cycle, config, settings),
                fineAmount = 0.0,
                totalDueWithFine = resolveRequiredContribution(cycle, config, settings),
                dueDateMillis = resolveCycleDueDateMillis(cycle, settings),
                isOverdue = false,
                daysOverdue = 0,
                paymentStatus = "PENDING"
            )
        }

        val activeCycle = cycles.firstOrNull { !it.status.isTerminal() } ?: cycles.firstOrNull()
        val currentSummary = if (activeCycle != null) {
            computeCycleCollectionSummary(activeCycle, config, settings, members, payments, nowMillis)
        } else null

        val currentPaymentStatus = cycleStatuses.find { it.cycleNumber == activeCycle?.cycleNumber }

        val totalPaid = cycleStatuses.sumOf { it.paidAmount }
        val totalDue = cycleStatuses.sumOf { it.remainingDue }

        val settledResults = cycles.mapNotNull { it.auctionResult }.filter {
            it.resultStatus == com.adr.groupledger.data.model.ChitAuctionResultStatus.SETTLED ||
            it.settlementPayoutTxnId != null
        }
        val totalDividends = settledResults.sumOf { it.estimatedOutcome?.dividendPerMember ?: 0.0 }
        val wonPrizes = settledResults.filter { it.winningMemberId == memberId }.sumOf { it.estimatedOutcome?.prizePayoutAmount ?: 0.0 }
        val netStanding = (wonPrizes + totalDividends) - totalPaid

        return com.adr.groupledger.data.model.ChitMyContributionProfile(
            member = member,
            currentCycleSummary = currentSummary,
            currentCyclePaymentStatus = currentPaymentStatus,
            totalLifetimeContributionsPaid = totalPaid,
            totalLifetimeOutstandingDue = totalDue,
            totalDividendsReceived = totalDividends,
            netChitStanding = netStanding,
            cyclePaymentHistory = cycleStatuses.sortedByDescending { it.cycleNumber }
        )
    }
}


