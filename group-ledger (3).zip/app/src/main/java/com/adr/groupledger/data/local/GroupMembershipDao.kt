package com.adr.groupledger.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.adr.groupledger.data.model.GroupMembership
import kotlinx.coroutines.flow.Flow

@Dao
interface GroupMembershipDao {
    @Query("SELECT * FROM group_memberships WHERE userId = :userId AND isActive = 1 ORDER BY id ASC")
    fun getMembershipsForUserFlow(userId: Long): Flow<List<GroupMembership>>

    @Query("SELECT * FROM group_memberships WHERE userId = :userId AND isActive = 1 ORDER BY id ASC")
    suspend fun getMembershipsForUserDirect(userId: Long): List<GroupMembership>

    @Query("SELECT * FROM group_memberships WHERE groupId = :groupId AND isActive = 1")
    fun getMembershipsForGroupFlow(groupId: Long): Flow<List<GroupMembership>>

    @Query("SELECT * FROM group_memberships WHERE userId = :userId AND groupId = :groupId LIMIT 1")
    fun getMembershipFlow(userId: Long, groupId: Long): Flow<GroupMembership?>

    @Query("SELECT * FROM group_memberships WHERE userId = :userId AND groupId = :groupId LIMIT 1")
    suspend fun getMembershipDirect(userId: Long, groupId: Long): GroupMembership?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMembership(membership: GroupMembership): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemberships(memberships: List<GroupMembership>)

    @Update
    suspend fun updateMembership(membership: GroupMembership)

    @Delete
    suspend fun deleteMembership(membership: GroupMembership)

    @Query("DELETE FROM group_memberships WHERE userId = :userId AND groupId = :groupId")
    suspend fun deleteMembershipForUserAndGroup(userId: Long, groupId: Long)
}
