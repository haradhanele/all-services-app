package com.adr.groupledger.ui.theme

import androidx.compose.ui.graphics.Color

// High Density Primary Brand Palette - Indigo & Slate
val IndigoPrimary = Color(0xFF4F46E5) // Indigo-600
val IndigoOnPrimary = Color(0xFFFFFFFF)
val IndigoPrimaryContainer = Color(0xFFEEF2FF) // Indigo-50
val IndigoOnPrimaryContainer = Color(0xFF312E81) // Indigo-900

// Indigo Hero Card Gradients
val IndigoHeroDark = Color(0xFF1E1B4B) // Indigo-950
val IndigoHeroSurface = Color(0xFF312E81) // Indigo-900
val IndigoHeroGradientEnd = Color(0xFF3730A3) // Indigo-800
val IndigoHeroProgress = Color(0xFF818CF8) // Indigo-400
val IndigoHeroTrack = Color(0xFF4338CA) // Indigo-700
val IndigoHeroSubtext = Color(0xFFC7D2FE) // Indigo-200

// Secondary & Slate System
val SlateSecondary = Color(0xFF64748B) // Slate-500
val SlateOnSecondary = Color(0xFFFFFFFF)
val SlateSecondaryContainer = Color(0xFFF1F5F9) // Slate-100
val SlateOnSecondaryContainer = Color(0xFF1E293B) // Slate-800

val SlateTertiary = Color(0xFF0EA5E9) // Sky-500
val SlateOnTertiary = Color(0xFFFFFFFF)
val SlateTertiaryContainer = Color(0xFFE0F2FE)
val SlateOnTertiaryContainer = Color(0xFF0369A1)

// Neutral Canvas & Surface (High Density Clean Background)
val CanvasBackground = Color(0xFFF8F9FF)
val CardWhite = Color(0xFFFFFFFF)
val BorderLight = Color(0xFFF1F5F9)
val BorderSubtle = Color(0xFFE2E8F0)
val TextSlate800 = Color(0xFF1E293B)
val TextSlate500 = Color(0xFF64748B)
val TextSlate400 = Color(0xFF94A3B8)

// Status Color Tokens (High Density compact pill badges)
val StatusPaidBg = Color(0xFFECFDF5) // emerald-50
val StatusPaidText = Color(0xFF059669) // emerald-600
val StatusPaidBorder = Color(0xFFA7F3D0) // emerald-200

val StatusPartialBg = Color(0xFFFFFBEB) // amber-50
val StatusPartialText = Color(0xFFD97706) // amber-600
val StatusPartialBorder = Color(0xFFFDE68A) // amber-200

val StatusUnpaidBg = Color(0xFFFFF1F2) // rose-50
val StatusUnpaidText = Color(0xFFE11D48) // rose-600
val StatusUnpaidBorder = Color(0xFFFECDD3) // rose-200

// Generic accent tokens
val Rose500 = Color(0xFFF43F5E)
val Amber500 = Color(0xFFF59E0B)
val Emerald500 = Color(0xFF10B981)

// Compatibility aliases for existing imports
val EmeraldPrimary = IndigoPrimary
val EmeraldOnPrimary = IndigoOnPrimary
val EmeraldPrimaryContainer = IndigoPrimaryContainer
val EmeraldOnPrimaryContainer = IndigoOnPrimaryContainer

val TealSecondary = SlateSecondary
val TealOnSecondary = SlateOnSecondary
val TealSecondaryContainer = SlateSecondaryContainer
val TealOnSecondaryContainer = SlateOnSecondaryContainer

val GoldTertiary = StatusPartialText
val GoldOnTertiary = Color(0xFFFFFFFF)
val GoldTertiaryContainer = StatusPartialBg
val GoldOnTertiaryContainer = StatusPartialText

// Dark Theme Variants
val IndigoPrimaryDark = Color(0xFF818CF8)
val IndigoOnPrimaryDark = Color(0xFF1E1B4B)
val IndigoPrimaryContainerDark = Color(0xFF312E81)
val IndigoOnPrimaryContainerDark = Color(0xFFEEF2FF)

val SlateSecondaryDark = Color(0xFF94A3B8)
val SlateOnSecondaryDark = Color(0xFF0F172A)
val SlateSecondaryContainerDark = Color(0xFF334155)
val SlateOnSecondaryContainerDark = Color(0xFFF1F5F9)

val SlateTertiaryDark = Color(0xFF38BDF8)
val SlateOnTertiaryDark = Color(0xFF082F49)
val SlateTertiaryContainerDark = Color(0xFF0369A1)
val SlateOnTertiaryContainerDark = Color(0xFFE0F2FE)

