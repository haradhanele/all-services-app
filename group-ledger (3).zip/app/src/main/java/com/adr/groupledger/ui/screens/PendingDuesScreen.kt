package com.adr.groupledger.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.NotificationImportant
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.MemberWithMonthlyStatus
import com.adr.groupledger.ui.components.MemberAvatarView
import com.adr.groupledger.ui.components.MonthPickerBar
import com.adr.groupledger.ui.components.StatusBadge
import com.adr.groupledger.ui.theme.BorderLight
import com.adr.groupledger.ui.theme.BorderSubtle
import com.adr.groupledger.ui.theme.CardWhite
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.StatusPaidText
import com.adr.groupledger.ui.theme.StatusUnpaidBg
import com.adr.groupledger.ui.theme.StatusUnpaidBorder
import com.adr.groupledger.ui.theme.StatusUnpaidText
import com.adr.groupledger.ui.theme.TextSlate400
import com.adr.groupledger.ui.theme.TextSlate500
import com.adr.groupledger.ui.theme.TextSlate800
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.utils.CurrencyFormatter
import com.adr.groupledger.utils.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PendingDuesScreen(
    viewModel: SocietyViewModel,
    onNavigateToRecordPayment: (Long) -> Unit,
    onNavigateToMemberProfile: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()
    val membersList by viewModel.monthlyMembersList.collectAsStateWithLifecycle()
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()

    val pendingMembers = membersList.filter { it.status != "PAID" }
    val totalPendingAmount = pendingMembers.sumOf { it.dueAmount }

    var showExportMenu by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .testTag("pending_dues_screen")
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Month Picker Bar
            MonthPickerBar(
                selectedMonth = selectedMonth,
                selectedYear = selectedYear,
                onPrevClick = { viewModel.prevMonth() },
                onNextClick = { viewModel.nextMonth() },
                onMonthYearSelected = { m, y -> viewModel.selectMonthYear(m, y) }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Pending Summary Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StatusUnpaidBorder, RoundedCornerShape(16.dp))
                    .testTag("pending_dues_banner"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = StatusUnpaidBg
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.NotificationImportant,
                                contentDescription = null,
                                tint = StatusUnpaidText,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Pending Contributions",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = StatusUnpaidText
                            )
                        }

                        Box {
                            IconButton(
                                onClick = { showExportMenu = true },
                                modifier = Modifier.size(32.dp).testTag("export_pending_dues_btn")
                            ) {
                                Icon(Icons.Default.FileDownload, contentDescription = "Export", tint = StatusUnpaidText)
                            }
                            DropdownMenu(
                                expanded = showExportMenu,
                                onDismissRequest = { showExportMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Export Pending PDF") },
                                    leadingIcon = { Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = IndigoPrimary) },
                                    onClick = {
                                        showExportMenu = false
                                        viewModel.exportPendingDuesPdf(context)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Export Pending CSV") },
                                    leadingIcon = { Icon(Icons.Default.TableChart, contentDescription = null, tint = IndigoPrimary) },
                                    onClick = {
                                        showExportMenu = false
                                        viewModel.exportPendingDuesCsv(context)
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "UNPAID MEMBERS",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF9F1239),
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "${pendingMembers.size} members",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = StatusUnpaidText
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "TOTAL DUE",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF9F1239),
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = CurrencyFormatter.format(totalPendingAmount, settings.currencySymbol),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = StatusUnpaidText
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (pendingMembers.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = StatusPaidText,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "All Members Paid for ${DateUtils.getMonthName(selectedMonth)}!",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = StatusPaidText
                        )
                        Text(
                            text = "No pending dues found for this month.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSlate500
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(pendingMembers, key = { it.member.id }) { item ->
                        PendingDueMemberCard(
                            item = item,
                            currencySymbol = settings.currencySymbol,
                            onCardClick = { onNavigateToMemberProfile(item.member.id) },
                            onPayClick = { onNavigateToRecordPayment(item.member.id) },
                            onWhatsAppClick = {
                                viewModel.sendReminder(context, item.member, item.dueAmount, "WHATSAPP")
                            },
                            onSmsClick = {
                                viewModel.sendReminder(context, item.member, item.dueAmount, "SMS")
                            },
                            onShareClick = {
                                viewModel.sendReminder(context, item.member, item.dueAmount, "SHARE")
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PendingDueMemberCard(
    item: MemberWithMonthlyStatus,
    currencySymbol: String,
    onCardClick: () -> Unit,
    onPayClick: () -> Unit,
    onWhatsAppClick: () -> Unit,
    onSmsClick: () -> Unit,
    onShareClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, BorderLight, RoundedCornerShape(14.dp))
            .clickable(onClick = onCardClick)
            .testTag("pending_card_${item.member.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    MemberAvatarView(name = item.member.name, size = 42.dp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = item.member.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextSlate800
                        )
                        Text(
                            text = "${item.member.memberCode} • ${if (item.member.phone.isNotBlank()) item.member.phone else "No phone"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSlate500
                        )
                    }
                }

                StatusBadge(status = item.status, compact = true)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Due and expected values
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Due: ${CurrencyFormatter.format(item.dueAmount, currencySymbol)}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = StatusUnpaidText
                    )
                    if (item.paidAmount > 0) {
                        Text(
                            text = "Partially paid: ${CurrencyFormatter.format(item.paidAmount, currencySymbol)} of ${CurrencyFormatter.format(item.effectiveExpectedAmount, currencySymbol)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSlate500
                        )
                    }
                }

                // Record payment button
                Button(
                    onClick = onPayClick,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                    modifier = Modifier.testTag("pay_pending_btn_${item.member.id}")
                ) {
                    Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Pay Dues", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Reminder Actions (WhatsApp, SMS, Share)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onWhatsAppClick,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("whatsapp_reminder_btn_${item.member.id}"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = Color(0xFF059669)
                    )
                ) {
                    Icon(Icons.Default.Send, contentDescription = null, tint = Color(0xFF059669), modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("WhatsApp", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                }

                OutlinedButton(
                    onClick = onSmsClick,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("sms_reminder_btn_${item.member.id}"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = TextSlate800
                    )
                ) {
                    Icon(Icons.Default.Sms, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("SMS", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                }

                IconButton(
                    onClick = onShareClick,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = "Share reminder", tint = TextSlate400, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

