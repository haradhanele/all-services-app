package com.adr.groupledger.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.NotificationImportant
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PinDrop
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.MemberWithMonthlyStatus
import com.adr.groupledger.data.model.SocietyNotice
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.BorderLight
import com.adr.groupledger.ui.theme.BorderSubtle
import com.adr.groupledger.ui.theme.CardWhite
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.IndigoPrimaryContainer
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.TextSlate400
import com.adr.groupledger.ui.theme.TextSlate500
import com.adr.groupledger.ui.theme.TextSlate800
import com.adr.groupledger.ui.theme.appOutlinedTextFieldColors
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.utils.CurrencyFormatter
import com.adr.groupledger.utils.DateUtils
import com.adr.groupledger.utils.ReminderHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SocietyChatScreen(
    viewModel: SocietyViewModel,
    onNavigateToMemberProfile: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val notices by viewModel.notices.collectAsStateWithLifecycle()
    val membersList by viewModel.allActiveMembers.collectAsStateWithLifecycle()
    val groupSettings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val monthlyMembers by viewModel.monthlyMembersList.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) } // 0: Notices & Announcements, 1: Member WhatsApp Chat
    var showPostNoticeDialog by remember { mutableStateOf(false) }
    var selectedMemberForChat by remember { mutableStateOf<Member?>(null) }
    var memberSearchQuery by remember { mutableStateOf("") }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            if (selectedTabIndex == 0) {
                FloatingActionButton(
                    onClick = { showPostNoticeDialog = true },
                    containerColor = IndigoPrimary,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("post_notice_fab")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Post Notice")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Post Notice", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Header Tabs: Notice Board vs Member Chat
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = IndigoPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = IndigoPrimary,
                        height = 3.dp
                    )
                }
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Campaign,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Notice Board (${notices.size})",
                                fontWeight = if (selectedTabIndex == 0) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    },
                    modifier = Modifier.testTag("tab_notice_board")
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Chat,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Member Chat (${membersList.size})",
                                fontWeight = if (selectedTabIndex == 1) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    },
                    modifier = Modifier.testTag("tab_member_chat")
                )
            }

            if (selectedTabIndex == 0) {
                // Notice Board Tab
                NoticeBoardContent(
                    notices = notices,
                    onBroadcast = { notice -> viewModel.broadcastNotice(context, notice) },
                    onTogglePin = { notice -> viewModel.togglePinNotice(notice) },
                    onDelete = { notice -> viewModel.deleteNotice(notice) },
                    onQuickTemplate = { template ->
                        viewModel.postNotice(
                            title = template.title,
                            content = template.content,
                            category = template.category,
                            author = groupSettings.adminName.ifBlank { "Admin" },
                            isPinned = false
                        )
                    }
                )
            } else {
                // Member Direct WhatsApp / Chat Tab
                MemberChatContent(
                    searchQuery = memberSearchQuery,
                    onSearchQueryChange = { memberSearchQuery = it },
                    members = membersList.filter {
                        it.name.contains(memberSearchQuery, ignoreCase = true) ||
                                it.memberCode.contains(memberSearchQuery, ignoreCase = true) ||
                                it.phone.contains(memberSearchQuery, ignoreCase = true)
                    },
                    monthlyMembers = monthlyMembers,
                    groupSettings = groupSettings,
                    onSelectMember = { member -> selectedMemberForChat = member },
                    onNavigateToProfile = onNavigateToMemberProfile
                )
            }
        }
    }

    // Post Notice Dialog
    if (showPostNoticeDialog) {
        PostNoticeDialog(
            adminName = groupSettings.adminName,
            onDismiss = { showPostNoticeDialog = false },
            onPost = { title, content, category, isPinned ->
                viewModel.postNotice(
                    title = title,
                    content = content,
                    category = category,
                    author = groupSettings.adminName.ifBlank { "Admin" },
                    isPinned = isPinned
                )
                showPostNoticeDialog = false
            }
        )
    }

    // Member Custom Chat / Message Dialog
    selectedMemberForChat?.let { member ->
        val memberMonthly = monthlyMembers.find { it.member.id == member.id }
        val dueAmount = memberMonthly?.dueAmount ?: 0.0

        MemberQuickMessageDialog(
            member = member,
            dueAmount = dueAmount,
            groupSettings = groupSettings,
            onDismiss = { selectedMemberForChat = null },
            onSendMessage = { msg ->
                viewModel.sendCustomMemberMessage(context, member, msg)
                selectedMemberForChat = null
            }
        )
    }
}

@Composable
private fun NoticeBoardContent(
    notices: List<SocietyNotice>,
    onBroadcast: (SocietyNotice) -> Unit,
    onTogglePin: (SocietyNotice) -> Unit,
    onDelete: (SocietyNotice) -> Unit,
    onQuickTemplate: (NoticeTemplate) -> Unit
) {
    val templates = listOf(
        NoticeTemplate(
            title = "📢 Monthly Contribution Reminder",
            content = "Dear members, gentle reminder to deposit your monthly samiti contribution on or before 10th. Thank you!",
            category = "COLLECTION"
        ),
        NoticeTemplate(
            title = "🗓️ Society General Meeting (AGM)",
            content = "All members are requested to attend the general body meeting this Sunday at 6:00 PM to review fund statements.",
            category = "MEETING"
        ),
        NoticeTemplate(
            title = "✨ Fund Accounts & Audit Updated",
            content = "The monthly accounts & collection ledger has been updated. You can view your individual ledger in Member Profile.",
            category = "ANNOUNCEMENT"
        )
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Quick Notice Templates Row
        item {
            Column {
                Text(
                    text = "Quick Broadcast Templates",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    templates.forEach { template ->
                        OutlinedButton(
                            onClick = { onQuickTemplate(template) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Text(
                                text = template.title.take(18) + "..",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        if (notices.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Campaign,
                            contentDescription = null,
                            tint = IndigoPrimary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No Notices Published",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Tap '+ Post Notice' to broadcast announcements to all society members.",
                            color = TextSlate500,
                            fontSize = 13.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(notices, key = { it.id }) { notice ->
                NoticeItemCard(
                    notice = notice,
                    onBroadcast = { onBroadcast(notice) },
                    onTogglePin = { onTogglePin(notice) },
                    onDelete = { onDelete(notice) }
                )
            }
        }
    }
}

@Composable
private fun NoticeItemCard(
    notice: SocietyNotice,
    onBroadcast: () -> Unit,
    onTogglePin: () -> Unit,
    onDelete: () -> Unit
) {
    val categoryColor = when (notice.category) {
        "COLLECTION" -> Emerald500
        "MEETING" -> IndigoPrimary
        "ALERT" -> Rose500
        else -> Amber500
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("notice_card_${notice.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (notice.isPinned) 3.dp else 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header Row: Category Badge, Pinned icon, Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = categoryColor.copy(alpha = 0.12f)
                    ) {
                        Text(
                            text = notice.category,
                            color = categoryColor,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    if (notice.isPinned) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = CircleShape,
                            color = Amber500.copy(alpha = 0.15f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PushPin,
                                    contentDescription = "Pinned",
                                    tint = Amber500,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Text("Pinned", color = Amber500, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Text(
                    text = DateUtils.formatDisplayDate(notice.timestamp),
                    color = TextSlate400,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Notice Title
            Text(
                text = notice.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                fontSize = 16.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Notice Content
            Text(
                text = notice.content,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.5.sp,
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Footer Row: Author & Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "By ${notice.author}",
                    fontSize = 12.sp,
                    color = TextSlate500,
                    fontWeight = FontWeight.Medium
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onTogglePin,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = if (notice.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            contentDescription = "Pin Notice",
                            tint = if (notice.isPinned) Amber500 else TextSlate400,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Notice",
                            tint = Rose500.copy(alpha = 0.8f),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    Button(
                        onClick = onBroadcast,
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Emerald500
                        ),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Share WhatsApp", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun MemberChatContent(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    members: List<Member>,
    monthlyMembers: List<MemberWithMonthlyStatus>,
    groupSettings: GroupSettings,
    onSelectMember: (Member) -> Unit,
    onNavigateToProfile: (Long) -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Search Input
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("member_chat_search"),
                placeholder = { Text("Search member by name, code or phone...", fontSize = 13.sp) },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = TextSlate400)
                },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                },
                shape = RoundedCornerShape(14.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = IndigoPrimary,
                    unfocusedBorderColor = BorderSubtle
                )
            )
        }

        if (members.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No members found matching query", color = TextSlate500)
                }
            }
        } else {
            items(members, key = { it.id }) { member ->
                val monthly = monthlyMembers.find { it.member.id == member.id }
                val status = monthly?.status ?: "PAID"
                val due = monthly?.dueAmount ?: 0.0

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("member_chat_row_${member.id}"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Member Avatar
                        Surface(
                            shape = CircleShape,
                            color = IndigoPrimary.copy(alpha = 0.12f),
                            modifier = Modifier
                                .size(44.dp)
                                .clickable { onNavigateToProfile(member.id) }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = member.name.take(1).uppercase(),
                                    fontWeight = FontWeight.Bold,
                                    color = IndigoPrimary,
                                    fontSize = 18.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        // Member details
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = member.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = member.phone,
                                    fontSize = 12.sp,
                                    color = TextSlate500
                                )
                                if (due > 0.0) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Rose500.copy(alpha = 0.12f)
                                    ) {
                                        Text(
                                            text = "Due: ${CurrencyFormatter.format(due, groupSettings.currencySymbol)}",
                                            color = Rose500,
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Action Buttons: Call & WhatsApp
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (member.phone.isNotBlank()) {
                                IconButton(
                                    onClick = {
                                        val intent = Intent(Intent.ACTION_DIAL).apply {
                                            data = Uri.parse("tel:${member.phone}")
                                        }
                                        try {
                                            context.startActivity(intent)
                                        } catch (e: Exception) {}
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Call,
                                        contentDescription = "Call",
                                        tint = IndigoPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            Button(
                                onClick = { onSelectMember(member) },
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Emerald500
                                ),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Chat,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Chat", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PostNoticeDialog(
    adminName: String,
    onDismiss: () -> Unit,
    onPost: (title: String, content: String, category: String, isPinned: Boolean) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("ANNOUNCEMENT") } // "ANNOUNCEMENT", "COLLECTION", "MEETING", "ALERT"
    var isPinned by remember { mutableStateOf(false) }

    val categories = listOf("ANNOUNCEMENT", "COLLECTION", "MEETING", "ALERT")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Publish Society Notice", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Category Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 10.5.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = IndigoPrimary.copy(alpha = 0.15f),
                                selectedLabelColor = IndigoPrimary
                            )
                        )
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Notice Title") },
                    placeholder = { Text("e.g. Annual General Meeting (AGM)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = appOutlinedTextFieldColors()
                )

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Notice Details / Announcement") },
                    placeholder = { Text("Write details for the members...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp),
                    maxLines = 5,
                    shape = RoundedCornerShape(10.dp),
                    colors = appOutlinedTextFieldColors()
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { isPinned = !isPinned }
                        .padding(vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = if (isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                        contentDescription = null,
                        tint = if (isPinned) Amber500 else TextSlate400
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "Pin this notice to top of notice board",
                        fontSize = 13.sp,
                        fontWeight = if (isPinned) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onPost(title, content, selectedCategory, isPinned) },
                enabled = title.isNotBlank() && content.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
            ) {
                Text("Publish Notice")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun MemberQuickMessageDialog(
    member: Member,
    dueAmount: Double,
    groupSettings: GroupSettings,
    onDismiss: () -> Unit,
    onSendMessage: (String) -> Unit
) {
    var customMessage by remember {
        mutableStateOf(
            if (dueAmount > 0.0) {
                "Dear ${member.name},\nThis is a friendly reminder from ${groupSettings.groupName} that your monthly contribution of ${CurrencyFormatter.format(dueAmount, groupSettings.currencySymbol)} is pending. Kindly deposit at your earliest convenience. Thank you!"
            } else {
                "Dear ${member.name},\nThis is a notice and official communication regarding ${groupSettings.groupName}."
            }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Chat, contentDescription = null, tint = Emerald500)
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("Chat with ${member.name}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(member.phone, fontSize = 12.sp, color = TextSlate500)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Pre-filled WhatsApp Message:", fontSize = 12.sp, color = TextSlate500)

                OutlinedTextField(
                    value = customMessage,
                    onValueChange = { customMessage = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = appOutlinedTextFieldColors()
                )

                // Quick chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            customMessage = "Dear ${member.name},\nReminder for ${groupSettings.groupName} monthly contribution of ${CurrencyFormatter.format(dueAmount.coerceAtLeast(groupSettings.defaultContribution), groupSettings.currencySymbol)}. Kindly pay at earliest."
                        },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text("Dues Reminder", fontSize = 10.5.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            customMessage = "Dear ${member.name},\nThank you! We have received your monthly contribution for ${groupSettings.groupName}. Receipt generated."
                        },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text("Payment Received", fontSize = 10.5.sp)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSendMessage(customMessage) },
                colors = ButtonDefaults.buttonColors(containerColor = Emerald500)
            ) {
                Icon(imageVector = Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Open WhatsApp")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

data class NoticeTemplate(
    val title: String,
    val content: String,
    val category: String
)
