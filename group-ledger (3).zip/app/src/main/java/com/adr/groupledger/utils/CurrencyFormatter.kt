package com.adr.groupledger.utils

import java.text.DecimalFormat
import java.util.Locale

object CurrencyFormatter {
    private val standardFormat: DecimalFormat = DecimalFormat("#,##,##0.##")

    fun format(amount: Double, symbol: String = "₹"): String {
        val formatted = try {
            standardFormat.format(amount)
        } catch (e: Exception) {
            String.format(Locale.getDefault(), "%.2f", amount)
        }
        return "$symbol$formatted"
    }

    fun formatNumber(amount: Double): String {
        return try {
            standardFormat.format(amount)
        } catch (e: Exception) {
            String.format(Locale.getDefault(), "%.2f", amount)
        }
    }

    fun formatIndian(amount: Double): String {
        return formatNumber(amount)
    }
}
