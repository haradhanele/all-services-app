package com.adr.groupledger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.ui.navigation.SamitiApp
import com.adr.groupledger.ui.theme.MyApplicationTheme
import com.adr.groupledger.ui.viewmodel.SocietyViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: SocietyViewModel by viewModels {
        SocietyViewModel.provideFactory(application)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
            val isSystemDark = isSystemInDarkTheme()
            val isDark = when (settings.themeMode) {
                "DARK" -> true
                "LIGHT" -> false
                else -> isSystemDark
            }
            MyApplicationTheme(darkTheme = isDark) {
                SamitiApp(viewModel = viewModel)
            }
        }
    }
}

