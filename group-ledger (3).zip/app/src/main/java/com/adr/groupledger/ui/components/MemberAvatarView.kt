package com.adr.groupledger.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adr.groupledger.ui.theme.BorderLight

private data class AvatarPalette(val bg: Color, val text: Color)

private val HighDensityAvatarPalettes = listOf(
    AvatarPalette(Color(0xFFEEF2FF), Color(0xFF4338CA)), // Indigo
    AvatarPalette(Color(0xFFECFDF5), Color(0xFF047857)), // Emerald
    AvatarPalette(Color(0xFFFFFBEB), Color(0xFFB45309)), // Amber
    AvatarPalette(Color(0xFFFFF1F2), Color(0xFFBE123C)), // Rose
    AvatarPalette(Color(0xFFF0FDF4), Color(0xFF15803D)), // Green
    AvatarPalette(Color(0xFFF5F3FF), Color(0xFF6D28D9)), // Purple
    AvatarPalette(Color(0xFFF0F9FF), Color(0xFF0369A1))  // Sky
)

@Composable
fun MemberAvatarView(
    name: String,
    modifier: Modifier = Modifier,
    size: Dp = 42.dp,
    isActive: Boolean = true
) {
    val initials = name.trim().split(" ")
        .filter { it.isNotBlank() }
        .take(2)
        .map { it.first().uppercase() }
        .joinToString("")
        .ifEmpty { "M" }

    val index = (kotlin.math.abs(name.hashCode())) % HighDensityAvatarPalettes.size
    val palette = HighDensityAvatarPalettes[index]
    val shape = RoundedCornerShape(12.dp)

    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(if (isActive) palette.bg else Color(0xFFF1F5F9))
            .border(
                1.dp,
                if (isActive) palette.bg else BorderLight,
                shape
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = initials,
            color = if (isActive) palette.text else Color(0xFF94A3B8),
            fontWeight = FontWeight.Bold,
            fontSize = (size.value * 0.38f).sp
        )
    }
}

