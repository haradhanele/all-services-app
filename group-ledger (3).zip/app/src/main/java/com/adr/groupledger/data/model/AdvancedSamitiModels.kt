package com.adr.groupledger.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "loan_requests",
    indices = [
        Index(value = ["groupId", "requesterMemberId"])
    ]
)
data class LoanRequest(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val groupId: Long = 1,
    val requesterMemberId: Long,
    val requesterName: String,
    val requesterPhone: String = "",
    val requestedAmount: Double,
    val purpose: String, // "Business", "Medical", "Education", "Emergency", "Home Improvement", "Personal", "Other"
    val reason: String,
    val duration: Int, // e.g. 6
    val durationUnit: String = "Months", // "Months", "Days"
    val expectedRepaymentDate: Long,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val votingDeadline: Long = System.currentTimeMillis() + (48L * 3600L * 1000L), // Default 48 hours
    val status: String = "VOTING", // "DRAFT", "SUBMITTED", "VOTING", "APPROVED", "REJECTED", "CANCELLED", "DISBURSED", "ACTIVE", "PARTIALLY_REPAID", "FULLY_REPAID", "OVERDUE"
    val disbursedDate: Long? = null,
    val disbursedBy: String? = null,
    val repaidAmount: Double = 0.0,
    val remainingAmount: Double = requestedAmount
)

@Entity(
    tableName = "loan_votes",
    indices = [
        Index(value = ["loanRequestId", "memberId"], unique = true)
    ]
)
data class LoanVote(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val loanRequestId: Long,
    val memberId: Long,
    val memberName: String,
    val vote: String, // "APPROVE", "REJECT"
    val timestamp: Long = System.currentTimeMillis()
)

data class LoanWithVotingDetails(
    val loan: LoanRequest,
    val totalActiveMembers: Int,
    val eligibleVoters: Int,
    val requiredApprovals: Int,
    val approveCount: Int,
    val rejectCount: Int,
    val pendingCount: Int,
    val approvalPercentage: Float,
    val isApprovedThresholdReached: Boolean,
    val isVotingExpired: Boolean,
    val votes: List<LoanVote>,
    val userVote: LoanVote? = null
)

@Entity(
    tableName = "investments",
    indices = [
        Index(value = ["groupId", "type"])
    ]
)
data class InvestmentRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val groupId: Long = 1,
    val type: String, // "STOCK", "FD", "MUTUAL_FUND", "OTHER"
    val institution: String, // e.g. "State Bank of India", "Zerodha Broking", "Groww", "HDFC"
    val name: String, // e.g. "Fixed Deposit 7.5%", "Nifty 50 Index Fund", "ITC Equity Share"
    val principalAmount: Double,
    val currentValue: Double,
    val investmentDate: Long = System.currentTimeMillis(),
    val maturityDate: Long? = null,
    val expectedReturn: Double? = null,
    val status: String = "ACTIVE", // "ACTIVE", "MATURED", "LIQUIDATED", "DELETED"
    val isDeleted: Boolean = false,
    val deletedAt: Long? = null,
    val deletedBy: String = "",
    val notes: String = "",
    val lastUpdated: Long = System.currentTimeMillis()
) {
    val gainLoss: Double
        get() = currentValue - principalAmount

    val returnPercentage: Double
        get() = if (principalAmount > 0) ((currentValue - principalAmount) / principalAmount) * 100.0 else 0.0
}

@Entity(
    tableName = "group_feedbacks",
    indices = [
        Index(value = ["groupId", "type"])
    ]
)
data class GroupFeedback(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val groupId: Long = 1,
    val type: String, // "SUGGESTION", "PROPOSAL", "COMPLAINT"
    val memberId: Long,
    val memberName: String,
    val isAnonymous: Boolean = false,
    val subject: String,
    val description: String,
    val createdAt: Long = System.currentTimeMillis(),
    val status: String = "SUBMITTED", // "SUBMITTED", "UNDER_REVIEW", "DISCUSSING", "ACCEPTED", "REJECTED", "RESOLVED"
    val adminResponse: String = "",
    val requiresVoting: Boolean = false,
    val votingThresholdPercent: Int = 50 // 50 (Simple majority) or 70%
)

@Entity(
    tableName = "proposal_votes",
    indices = [
        Index(value = ["feedbackId", "memberId"], unique = true)
    ]
)
data class ProposalVote(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val feedbackId: Long,
    val memberId: Long,
    val memberName: String,
    val vote: String, // "AGREE", "DISAGREE"
    val timestamp: Long = System.currentTimeMillis()
)

data class FeedbackWithVotes(
    val feedback: GroupFeedback,
    val totalEligibleVoters: Int,
    val agreeCount: Int,
    val disagreeCount: Int,
    val pendingCount: Int,
    val agreePercentage: Float,
    val userVote: ProposalVote? = null
)

@Entity(
    tableName = "notifications",
    indices = [
        Index(value = ["groupId", "isRead"])
    ]
)
data class NotificationItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val groupId: Long = 1,
    val title: String,
    val message: String,
    val type: String, // "LOAN_REQUEST", "LOAN_VOTING", "LOAN_APPROVED", "LOAN_REJECTED", "LOAN_REPAYMENT", "CONTRIBUTION_REMINDER", "ANNOUNCEMENT", "PROPOSAL", "COMPLAINT", "INVESTMENT_UPDATE", "PAYMENT_APPROVAL", "PAYMENT_APPROVED", "PAYMENT_REJECTED"
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val relatedId: Long? = null,
    val actionRoute: String? = null
)

@Entity(
    tableName = "financial_transactions",
    indices = [
        Index(value = ["groupId", "date"])
    ]
)
data class TransactionRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val groupId: Long = 1,
    val txnNumber: String, // "TXN-2026-XXXX"
    val date: Long = System.currentTimeMillis(),
    val amount: Double,
    val type: String, // "CONTRIBUTION", "LOAN_DISBURSEMENT", "LOAN_REPAYMENT", "INVESTMENT_PURCHASE", "INVESTMENT_SALE", "FD_DEPOSIT", "FD_MATURITY", "INCOME", "EXPENSE", "ADJUSTMENT"
    val isCredit: Boolean, // true: inflow (adds cash), false: outflow (deducts cash)
    val description: String,
    val paymentMethod: String = "Cash", // Cash, UPI, Bank Transfer, Cheque, Online
    val relatedMemberId: Long? = null,
    val relatedMemberName: String? = null,
    val relatedLoanId: Long? = null,
    val relatedInvestmentId: Long? = null,
    val createdBy: String = "Admin"
)

@Entity(
    tableName = "audit_logs",
    indices = [
        Index(value = ["groupId", "timestamp"])
    ]
)
data class AuditLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val groupId: Long = 1,
    val actorName: String,
    val actorRole: String, // "Admin", "Treasurer", "Member"
    val action: String,
    val previousValue: String = "",
    val newValue: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val relatedRecord: String = ""
)

@Entity(
    tableName = "group_chat_messages",
    indices = [
        Index(value = ["groupId", "timestamp"])
    ]
)
data class GroupChatMessage(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val groupId: Long = 1,
    val senderId: Long,
    val senderName: String,
    val senderRole: String = "Member", // "Admin", "Treasurer", "President", "Member"
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isAnnouncement: Boolean = false,
    val isRead: Boolean = true
)

data class PendingPaymentApprovalItem(
    val payment: Payment,
    val member: Member
)

