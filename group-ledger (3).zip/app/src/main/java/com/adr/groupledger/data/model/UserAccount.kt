package com.adr.groupledger.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "user_accounts",
    indices = [
        Index(value = ["email"], unique = false)
    ]
)
data class UserAccount(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val email: String = "",
    val fullName: String,
    val phone: String = "",
    val passwordHash: String = "",
    val isAccountCompleted: Boolean = true, // true if email registered; false if quick invite join without email
    val avatarUri: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
