package com.adr.groupledger.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PriceCheck
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.LoanRequest
import com.adr.groupledger.data.model.LoanWithVotingDetails
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.BorderLight
import com.adr.groupledger.ui.theme.BorderSubtle
import com.adr.groupledger.ui.theme.CardWhite
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.TextSlate400
import com.adr.groupledger.ui.theme.TextSlate500
import com.adr.groupledger.ui.theme.TextSlate800
import com.adr.groupledger.ui.theme.appOutlinedTextFieldColors
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.utils.CurrencyFormatter
import com.adr.groupledger.utils.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoansScreen(
    viewModel: SocietyViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val loansWithVoting by viewModel.loansWithVoting.collectAsStateWithLifecycle()
    val activeMembers by viewModel.allActiveMembers.collectAsStateWithLifecycle()
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Active & Voting, 1: Disbursed / Active Loans, 2: Completed / All
    var showRequestLoanDialog by remember { mutableStateOf(false) }
    var selectedLoanForRepayment by remember { mutableStateOf<LoanRequest?>(null) }
    var selectedVoterMember by remember { mutableStateOf<Member?>(null) }

    // Ensure default voter is set to first active member
    if (selectedVoterMember == null && activeMembers.isNotEmpty()) {
        selectedVoterMember = activeMembers.firstOrNull()
    }

    val filteredLoans = remember(loansWithVoting, selectedTab) {
        when (selectedTab) {
            0 -> loansWithVoting.filter { it.loan.status in listOf("VOTING", "SUBMITTED", "APPROVED") }
            1 -> loansWithVoting.filter { it.loan.status in listOf("ACTIVE", "DISBURSED", "PARTIALLY_REPAID") }
            else -> loansWithVoting
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showRequestLoanDialog = true },
                containerColor = IndigoPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("request_loan_fab")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Request Loan")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Request Loan", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Voter selector banner (To simulate realistic member voting)
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = IndigoPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Acting Voter: ${selectedVoterMember?.name ?: "Select Member"}",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSlate800
                        )
                    }

                    // Selector
                    var expandedVoterMenu by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(
                            onClick = { expandedVoterMenu = true },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text("Switch Voter", fontSize = 11.sp)
                        }

                        androidx.compose.material3.DropdownMenu(
                            expanded = expandedVoterMenu,
                            onDismissRequest = { expandedVoterMenu = false }
                        ) {
                            activeMembers.forEach { member ->
                                DropdownMenuItem(
                                    text = { Text("${member.name} (${member.memberCode})", fontSize = 13.sp) },
                                    onClick = {
                                        selectedVoterMember = member
                                        expandedVoterMenu = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = IndigoPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = IndigoPrimary,
                        height = 3.dp
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Voting (${loansWithVoting.count { it.loan.status in listOf("VOTING", "APPROVED") }})") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Active Loans (${loansWithVoting.count { it.loan.status in listOf("ACTIVE", "PARTIALLY_REPAID") }})") }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("All (${loansWithVoting.size})") }
                )
            }

            if (filteredLoans.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Handshake,
                            contentDescription = null,
                            tint = TextSlate400,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No loan requests in this section",
                            fontWeight = FontWeight.SemiBold,
                            color = TextSlate500,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Members can request emergency or business loans subject to 70% general body approval.",
                            color = TextSlate400,
                            fontSize = 12.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(filteredLoans, key = { it.loan.id }) { item ->
                        LoanCardItem(
                            item = item,
                            currentVoter = selectedVoterMember,
                            currencySymbol = settings.currencySymbol,
                            onVote = { voteDecision ->
                                selectedVoterMember?.let { voter ->
                                    viewModel.castLoanVote(item.loan.id, voter.id, voter.name, voteDecision)
                                }
                            },
                            onDisburse = {
                                viewModel.requestAdminAction {
                                    viewModel.disburseLoan(item.loan.id, settings.adminName)
                                }
                            },
                            onRepay = {
                                selectedLoanForRepayment = item.loan
                            }
                        )
                    }
                }
            }
        }
    }

    // Dialogs
    if (showRequestLoanDialog) {
        RequestLoanDialog(
            activeMembers = activeMembers,
            currencySymbol = settings.currencySymbol,
            onDismiss = { showRequestLoanDialog = false },
            onSubmit = { requester, amount, purpose, reason, duration, unit, note ->
                viewModel.submitLoanRequest(
                    requesterMemberId = requester.id,
                    requesterName = requester.name,
                    requesterPhone = requester.phone,
                    amount = amount,
                    purpose = purpose,
                    reason = reason,
                    duration = duration,
                    durationUnit = unit,
                    note = note,
                    onSuccess = { showRequestLoanDialog = false }
                )
            }
        )
    }

    selectedLoanForRepayment?.let { loan ->
        RecordLoanRepaymentDialog(
            loan = loan,
            currencySymbol = settings.currencySymbol,
            onDismiss = { selectedLoanForRepayment = null },
            onSubmit = { amount, method, notes ->
                viewModel.recordLoanRepayment(loan.id, amount, method, notes)
                selectedLoanForRepayment = null
            }
        )
    }
}

@Composable
fun LoanCardItem(
    item: LoanWithVotingDetails,
    currentVoter: Member?,
    currencySymbol: String,
    onVote: (String) -> Unit,
    onDisburse: () -> Unit,
    onRepay: () -> Unit
) {
    val loan = item.loan
    val userVote = item.votes.find { it.memberId == currentVoter?.id }
    val isRequester = currentVoter?.id == loan.requesterMemberId

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Requester Name, Amount & Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = loan.requesterName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = TextSlate800
                    )
                    Text(
                        text = "Purpose: ${loan.purpose}",
                        fontSize = 12.sp,
                        color = TextSlate500
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "$currencySymbol${CurrencyFormatter.formatIndian(loan.requestedAmount)}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = IndigoPrimary
                    )
                    // Status Badge
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when (loan.status) {
                            "VOTING" -> Amber500.copy(alpha = 0.15f)
                            "APPROVED" -> Emerald500.copy(alpha = 0.15f)
                            "ACTIVE", "DISBURSED", "PARTIALLY_REPAID" -> IndigoPrimary.copy(alpha = 0.15f)
                            "FULLY_REPAID" -> Emerald500.copy(alpha = 0.15f)
                            "REJECTED" -> Rose500.copy(alpha = 0.15f)
                            else -> TextSlate400.copy(alpha = 0.15f)
                        }
                    ) {
                        Text(
                            text = when (loan.status) {
                                "VOTING" -> "VOTING (70% Rule)"
                                "APPROVED" -> "APPROVED"
                                "ACTIVE" -> "ACTIVE (DISBURSED)"
                                "PARTIALLY_REPAID" -> "PARTIALLY REPAID"
                                "FULLY_REPAID" -> "FULLY REPAID"
                                else -> loan.status
                            },
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (loan.status) {
                                "VOTING" -> Amber500
                                "APPROVED", "FULLY_REPAID" -> Emerald500
                                "ACTIVE", "DISBURSED", "PARTIALLY_REPAID" -> IndigoPrimary
                                "REJECTED" -> Rose500
                                else -> TextSlate500
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Reason & duration
            Text(
                text = "\"${loan.reason}\"",
                fontSize = 13.sp,
                color = TextSlate800,
                modifier = Modifier.padding(vertical = 2.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Duration: ${loan.duration} ${loan.durationUnit}",
                    fontSize = 11.5.sp,
                    color = TextSlate500
                )
                Text(
                    text = "Requested: ${DateUtils.formatDate(loan.createdAt)}",
                    fontSize = 11.5.sp,
                    color = TextSlate500
                )
            }

            // Voting Section (If in Voting state)
            if (loan.status == "VOTING") {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "70% Approval Progress",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextSlate800
                            )
                            Text(
                                text = "${item.approveCount}/${item.requiredApprovals} Approvals Needed (${item.approvalPercentage.toInt()}%)",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (item.isApprovedThresholdReached) Emerald500 else IndigoPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Progress Bar
                        LinearProgressIndicator(
                            progress = { (item.approveCount.toFloat() / item.requiredApprovals.toFloat()).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = if (item.isApprovedThresholdReached) Emerald500 else IndigoPrimary,
                            trackColor = BorderLight
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Votes: 👍 ${item.approveCount} Yes | 👎 ${item.rejectCount} No | ⏳ ${item.pendingCount} Pending",
                                fontSize = 11.sp,
                                color = TextSlate500
                            )
                        }

                        // Voting action for current member
                        Spacer(modifier = Modifier.height(10.dp))
                        if (isRequester) {
                            Text(
                                text = "ℹ️ Requester cannot vote on their own loan request (Rule 11).",
                                fontSize = 11.sp,
                                color = TextSlate500,
                                fontWeight = FontWeight.Medium
                            )
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = { onVote("APPROVE") },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (userVote?.vote == "APPROVE") Emerald500 else Emerald500.copy(alpha = 0.85f)
                                    ),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.ThumbUp, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (userVote?.vote == "APPROVE") "Approved ✓" else "Approve", fontSize = 12.5.sp)
                                }

                                OutlinedButton(
                                    onClick = { onVote("REJECT") },
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        contentColor = if (userVote?.vote == "REJECT") Rose500 else TextSlate800
                                    ),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.ThumbDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (userVote?.vote == "REJECT") "Rejected ✗" else "Reject", fontSize = 12.5.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Approved Action -> Disburse Button
            if (loan.status == "APPROVED") {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onDisburse,
                    colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.PriceCheck, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Disburse Funds ($currencySymbol${CurrencyFormatter.formatIndian(loan.requestedAmount)})", fontWeight = FontWeight.Bold)
                }
            }

            // Active / Repaying Loan Details
            if (loan.status in listOf("ACTIVE", "DISBURSED", "PARTIALLY_REPAID", "FULLY_REPAID")) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Repaid: $currencySymbol${CurrencyFormatter.formatIndian(loan.repaidAmount)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                            Text("Remaining: $currencySymbol${CurrencyFormatter.formatIndian(loan.remainingAmount)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (loan.remainingAmount > 0) Rose500 else Emerald500)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        val progress = if (loan.requestedAmount > 0) (loan.repaidAmount / loan.requestedAmount).toFloat() else 0f
                        LinearProgressIndicator(
                            progress = { progress.coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = Emerald500,
                            trackColor = BorderLight
                        )

                        if (loan.status != "FULLY_REPAID") {
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = onRepay,
                                colors = ButtonDefaults.buttonColors(containerColor = Emerald500),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Record Loan Repayment", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RequestLoanDialog(
    activeMembers: List<Member>,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onSubmit: (Member, Double, String, String, Int, String, String) -> Unit
) {
    var selectedMember by remember { mutableStateOf<Member?>(activeMembers.firstOrNull()) }
    var amountText by remember { mutableStateOf("") }
    var purpose by remember { mutableStateOf("Business Expansion") }
    var reason by remember { mutableStateOf("") }
    var durationText by remember { mutableStateOf("6") }
    var durationUnit by remember { mutableStateOf("Months") }
    var note by remember { mutableStateOf("") }

    var expandedMemberDropdown by remember { mutableStateOf(false) }
    var expandedPurposeDropdown by remember { mutableStateOf(false) }

    val purposeOptions = listOf("Business Expansion", "Medical Emergency", "Education / Fees", "Home Renovation", "Agriculture / Crops", "Personal Emergency", "Other")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Request Group Loan", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Member Selector
                ExposedDropdownMenuBox(
                    expanded = expandedMemberDropdown,
                    onExpandedChange = { expandedMemberDropdown = !expandedMemberDropdown }
                ) {
                    OutlinedTextField(
                        value = selectedMember?.name ?: "Select Member",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Borrower Member") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedMemberDropdown) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        colors = appOutlinedTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedMemberDropdown,
                        onDismissRequest = { expandedMemberDropdown = false }
                    ) {
                        activeMembers.forEach { m ->
                            DropdownMenuItem(
                                text = { Text("${m.name} (${m.memberCode})") },
                                onClick = {
                                    selectedMember = m
                                    expandedMemberDropdown = false
                                }
                            )
                        }
                    }
                }

                // Amount
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { c -> c.isDigit() } },
                    label = { Text("Loan Amount ($currencySymbol)") },
                    placeholder = { Text("e.g. 50000") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = appOutlinedTextFieldColors()
                )

                // Purpose
                ExposedDropdownMenuBox(
                    expanded = expandedPurposeDropdown,
                    onExpandedChange = { expandedPurposeDropdown = !expandedPurposeDropdown }
                ) {
                    OutlinedTextField(
                        value = purpose,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Purpose") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedPurposeDropdown) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        colors = appOutlinedTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedPurposeDropdown,
                        onDismissRequest = { expandedPurposeDropdown = false }
                    ) {
                        purposeOptions.forEach { p ->
                            DropdownMenuItem(
                                text = { Text(p) },
                                onClick = {
                                    purpose = p
                                    expandedPurposeDropdown = false
                                }
                            )
                        }
                    }
                }

                // Reason / Explanation
                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("Detailed Reason") },
                    placeholder = { Text("Explain purpose for group voting transparency") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth(),
                    colors = appOutlinedTextFieldColors()
                )

                // Duration
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = durationText,
                        onValueChange = { durationText = it.filter { c -> c.isDigit() } },
                        label = { Text("Duration") },
                        modifier = Modifier.weight(1f),
                        colors = appOutlinedTextFieldColors()
                    )
                    OutlinedTextField(
                        value = durationUnit,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Unit") },
                        modifier = Modifier.weight(1f),
                        colors = appOutlinedTextFieldColors()
                    )
                }

                Text(
                    text = "⚠️ Subject to 70% approval by all eligible members. Requester is excluded from voting.",
                    fontSize = 11.sp,
                    color = TextSlate500
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val m = selectedMember
                    val amt = amountText.toDoubleOrNull() ?: 0.0
                    val dur = durationText.toIntOrNull() ?: 1
                    if (m != null && amt > 0 && reason.isNotBlank()) {
                        onSubmit(m, amt, purpose, reason, dur, durationUnit, note)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
            ) {
                Text("Submit Request")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun RecordLoanRepaymentDialog(
    loan: LoanRequest,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onSubmit: (Double, String, String) -> Unit
) {
    var amountText by remember { mutableStateOf(loan.remainingAmount.toInt().toString()) }
    var paymentMethod by remember { mutableStateOf("UPI") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Loan Repayment", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Borrower: ${loan.requesterName}",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
                Text(
                    text = "Outstanding Balance: $currencySymbol${CurrencyFormatter.formatIndian(loan.remainingAmount)}",
                    color = Rose500,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { c -> c.isDigit() } },
                    label = { Text("Repayment Amount ($currencySymbol)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = appOutlinedTextFieldColors()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Cash", "UPI", "Bank Transfer").forEach { method ->
                        FilterChip(
                            selected = paymentMethod == method,
                            onClick = { paymentMethod = method },
                            label = { Text(method, fontSize = 11.5.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Reference (Optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = appOutlinedTextFieldColors()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull() ?: 0.0
                    if (amt > 0) onSubmit(amt, paymentMethod, notes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Emerald500)
            ) {
                Text("Confirm Repayment")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
