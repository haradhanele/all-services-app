package com.adr.groupledger.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.adr.groupledger.data.model.LoanRequest
import com.adr.groupledger.data.model.LoanVote
import kotlinx.coroutines.flow.Flow

@Dao
interface LoanDao {
    @Query("SELECT * FROM loan_requests WHERE groupId = :groupId ORDER BY createdAt DESC")
    fun getAllLoansFlow(groupId: Long): Flow<List<LoanRequest>>

    @Query("SELECT * FROM loan_requests WHERE id = :id")
    suspend fun getLoanById(id: Long): LoanRequest?

    @Query("SELECT * FROM loan_requests WHERE id = :id")
    fun getLoanByIdFlow(id: Long): Flow<LoanRequest?>

    @Query("SELECT * FROM loan_requests WHERE groupId = :groupId AND status IN ('SUBMITTED', 'VOTING') ORDER BY createdAt DESC")
    fun getPendingLoansFlow(groupId: Long): Flow<List<LoanRequest>>

    @Query("SELECT * FROM loan_requests WHERE groupId = :groupId AND (status = 'ACTIVE' OR status = 'DISBURSED' OR status = 'PARTIALLY_REPAID') ORDER BY createdAt DESC")
    fun getActiveLoansFlow(groupId: Long): Flow<List<LoanRequest>>

    @Query("SELECT * FROM loan_requests WHERE requesterMemberId = :memberId ORDER BY createdAt DESC")
    fun getLoansByMemberId(memberId: Long): Flow<List<LoanRequest>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoan(loan: LoanRequest): Long

    @Update
    suspend fun updateLoan(loan: LoanRequest)

    @Query("DELETE FROM loan_requests WHERE id = :id")
    suspend fun deleteLoanById(id: Long)

    // Votes
    @Query("SELECT * FROM loan_votes WHERE loanRequestId = :loanId")
    fun getVotesForLoanFlow(loanId: Long): Flow<List<LoanVote>>

    @Query("SELECT * FROM loan_votes WHERE loanRequestId = :loanId")
    suspend fun getVotesForLoan(loanId: Long): List<LoanVote>

    @Query("SELECT * FROM loan_votes WHERE loanRequestId = :loanId AND memberId = :memberId LIMIT 1")
    suspend fun getVote(loanId: Long, memberId: Long): LoanVote?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVote(vote: LoanVote): Long

    @Query("SELECT COUNT(*) FROM loan_votes WHERE loanRequestId = :loanId AND vote = 'APPROVE'")
    suspend fun getApproveCount(loanId: Long): Int

    @Query("SELECT COUNT(*) FROM loan_votes WHERE loanRequestId = :loanId AND vote = 'REJECT'")
    suspend fun getRejectCount(loanId: Long): Int

    @Query("DELETE FROM loan_votes WHERE loanRequestId = :loanId")
    suspend fun deleteVotesForLoan(loanId: Long)
}
