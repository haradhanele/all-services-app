package com.adr.groupledger.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.adr.groupledger.data.model.Member

object ReminderHelper {

    fun generateReminderText(
        member: Member,
        groupName: String,
        monthName: String,
        year: Int,
        dueAmount: Double,
        currencySymbol: String,
        adminName: String,
        adminPhone: String
    ): String {
        return "Dear ${member.name},\n\n" +
                "Warm greetings from *$groupName*.\n\n" +
                "This is a gentle reminder that your monthly contribution for *$monthName $year* of " +
                "*${CurrencyFormatter.format(dueAmount, currencySymbol)}* is pending.\n\n" +
                "Kindly make the payment at your earliest convenience. If you have already paid, please ignore this message.\n\n" +
                "Regards,\n" +
                "$adminName\n" +
                (if (adminPhone.isNotBlank()) "Contact: $adminPhone" else "")
    }

    fun sendWhatsAppReminder(
        context: Context,
        phoneNumber: String,
        message: String
    ) {
        val cleanPhone = phoneNumber.replace(Regex("[^0-9+]"), "")
        val formattedPhone = if (cleanPhone.startsWith("+")) {
            cleanPhone.substring(1)
        } else if (cleanPhone.length == 10) {
            "91$cleanPhone" // Default to India code if 10 digits
        } else {
            cleanPhone
        }

        val url = "https://api.whatsapp.com/send?phone=$formattedPhone&text=${Uri.encode(message)}"
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse(url)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback to general share intent if WhatsApp is not installed
            shareText(context, message, "Send Reminder via")
        }
    }

    fun sendSmsReminder(
        context: Context,
        phoneNumber: String,
        message: String
    ) {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:$phoneNumber")
            putExtra("sms_body", message)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            shareText(context, message, "Send SMS via")
        }
    }

    fun shareText(
        context: Context,
        text: String,
        title: String = "Share Reminder"
    ) {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, text)
            type = "text/plain"
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val shareIntent = Intent.createChooser(sendIntent, title).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(shareIntent)
        } catch (e: Exception) {
            Toast.makeText(context, "Unable to share message", Toast.LENGTH_SHORT).show()
        }
    }

    fun generateNoticeBroadcastText(
        groupName: String,
        title: String,
        content: String,
        author: String,
        adminPhone: String
    ): String {
        return "📢 *$groupName - Society Announcement*\n\n" +
                "*$title*\n\n" +
                "$content\n\n" +
                "━━━━━━━━━━━━━━━━━━\n" +
                "Issued by: $author\n" +
                (if (adminPhone.isNotBlank()) "Helpline: $adminPhone\n" else "") +
                "_Digital Samiti Community Portal_"
    }
}
