package com.adr.groupledger.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.MemberWithMonthlyStatus
import com.adr.groupledger.data.model.NotificationItem
import com.adr.groupledger.data.model.PendingPaymentApprovalItem
import com.adr.groupledger.data.model.SocietyNotice
import com.adr.groupledger.ui.components.PendingApprovalCard
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.BorderLight
import com.adr.groupledger.ui.theme.BorderSubtle
import com.adr.groupledger.ui.theme.CardWhite
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.IndigoPrimaryContainer
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.TextSlate400
import com.adr.groupledger.ui.theme.TextSlate500
import com.adr.groupledger.ui.theme.TextSlate800
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.utils.CurrencyFormatter
import com.adr.groupledger.utils.DateUtils
import com.adr.groupledger.utils.ReminderHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InboxScreen(
    viewModel: SocietyViewModel,
    onNavigateToRoute: (String) -> Unit,
    onNavigateToMemberProfile: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val notifications by viewModel.allNotifications.collectAsStateWithLifecycle()
    val unreadCount by viewModel.unreadNotificationsCount.collectAsStateWithLifecycle()
    val pendingApprovals by viewModel.pendingPaymentApprovals.collectAsStateWithLifecycle()
    val notices by viewModel.notices.collectAsStateWithLifecycle()
    val membersList by viewModel.allActiveMembers.collectAsStateWithLifecycle()
    val groupSettings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val monthlyMembers by viewModel.monthlyMembersList.collectAsStateWithLifecycle()
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) } // 0: Alerts, 1: Approvals, 2: Notices, 3: Direct Connect
    var showPostNoticeDialog by remember { mutableStateOf(false) }
    var memberSearchQuery by remember { mutableStateOf("") }
    var selectedMemberForChat by remember { mutableStateOf<Member?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("combined_inbox_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top Tab Row
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp
            ) {
                SecondaryTabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = IndigoPrimary,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Tab 0: Alerts & Activity
                    Tab(
                        selected = selectedTabIndex == 0,
                        onClick = { selectedTabIndex = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Alerts",
                                    fontWeight = if (selectedTabIndex == 0) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 12.5.sp
                                )
                                if (unreadCount > 0) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Surface(
                                        shape = CircleShape,
                                        color = Rose500,
                                        modifier = Modifier.size(17.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = if (unreadCount > 9) "9+" else "$unreadCount",
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    )

                    // Tab 1: Approvals
                    Tab(
                        selected = selectedTabIndex == 1,
                        onClick = { selectedTabIndex = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Approvals",
                                    fontWeight = if (selectedTabIndex == 1) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 12.5.sp
                                )
                                if (pendingApprovals.isNotEmpty()) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Surface(
                                        shape = CircleShape,
                                        color = Amber500,
                                        modifier = Modifier.size(17.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "${pendingApprovals.size}",
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    )

                    // Tab 2: Notices
                    Tab(
                        selected = selectedTabIndex == 2,
                        onClick = { selectedTabIndex = 2 },
                        text = {
                            Text(
                                text = "Notices (${notices.size})",
                                fontWeight = if (selectedTabIndex == 2) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 12.5.sp
                            )
                        }
                    )

                    // Tab 3: Direct Connect
                    Tab(
                        selected = selectedTabIndex == 3,
                        onClick = { selectedTabIndex = 3 },
                        text = {
                            Text(
                                text = "Members",
                                fontWeight = if (selectedTabIndex == 3) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 12.5.sp
                            )
                        }
                    )
                }
            }

            // Tab Content
            when (selectedTabIndex) {
                0 -> {
                    // 1. Alerts & Activity Notifications
                    InboxAlertsTab(
                        notifications = notifications,
                        unreadCount = unreadCount,
                        onMarkAllRead = { viewModel.markAllNotificationsRead() },
                        onNotificationClick = { item ->
                            viewModel.markNotificationRead(item.id)
                            item.actionRoute?.let { onNavigateToRoute(it) }
                        }
                    )
                }
                1 -> {
                    // 2. Pending Payment Approvals (Admin Workflow)
                    InboxApprovalsTab(
                        pendingApprovals = pendingApprovals,
                        currencySymbol = groupSettings.currencySymbol,
                        onApprove = { paymentId ->
                            if (isAdminUnlocked) {
                                viewModel.approvePayment(paymentId)
                            } else {
                                viewModel.requestAdminAction {
                                    viewModel.approvePayment(paymentId)
                                }
                            }
                        },
                        onReject = { paymentId, reason ->
                            if (isAdminUnlocked) {
                                viewModel.rejectPayment(paymentId, reason)
                            } else {
                                viewModel.requestAdminAction {
                                    viewModel.rejectPayment(paymentId, reason)
                                }
                            }
                        }
                    )
                }
                2 -> {
                    // 3. Society Notices & Broadcasts
                    InboxNoticesTab(
                        notices = notices,
                        onTogglePin = { notice -> viewModel.togglePinNotice(notice) },
                        onDeleteNotice = { notice -> viewModel.deleteNotice(notice) },
                        onShareNotice = { notice ->
                            ReminderHelper.shareText(
                                context,
                                "📢 *${notice.title}*\n\n${notice.content}\n\n— *${groupSettings.groupName}*",
                                "Share Society Notice"
                            )
                        }
                    )
                }
                3 -> {
                    // 4. Member WhatsApp & Direct Chat
                    InboxDirectConnectTab(
                        members = membersList,
                        monthlyMembers = monthlyMembers,
                        searchQuery = memberSearchQuery,
                        onSearchQueryChange = { memberSearchQuery = it },
                        onMemberClick = { member -> selectedMemberForChat = member },
                        onCallMember = { phone ->
                            if (phone.isNotBlank()) {
                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
                                context.startActivity(intent)
                            }
                        },
                        onNavigateToProfile = onNavigateToMemberProfile
                    )
                }
            }
        }

        // Floating Action Button for Posting Notice in Tab 2
        if (selectedTabIndex == 2) {
            FloatingActionButton(
                onClick = { showPostNoticeDialog = true },
                containerColor = IndigoPrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .testTag("post_notice_fab")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 16.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Post Notice")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("New Notice", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }

    // Post Notice Dialog
    if (showPostNoticeDialog) {
        PostNoticeDialog(
            groupName = groupSettings.groupName,
            onDismiss = { showPostNoticeDialog = false },
            onPost = { title, content, category, isPinned, shareToWhatsApp ->
                viewModel.postNotice(
                    title = title,
                    content = content,
                    category = category,
                    isPinned = isPinned,
                    author = if (isAdminUnlocked) "Society Admin" else "Society Member"
                )
                if (shareToWhatsApp) {
                    ReminderHelper.shareText(
                        context,
                        "📢 *NEW SOCIETY NOTICE*\n*${title.trim()}*\n\n${content.trim()}\n\n— *${groupSettings.groupName}*",
                        "Broadcast Notice"
                    )
                }
                showPostNoticeDialog = false
            }
        )
    }

    // Direct WhatsApp Chat Dialog
    selectedMemberForChat?.let { member ->
        val monthlyItem = monthlyMembers.find { it.member.id == member.id }
        val dueAmount = monthlyItem?.dueAmount ?: 0.0

        MemberChatActionDialog(
            member = member,
            groupName = groupSettings.groupName,
            currencySymbol = groupSettings.currencySymbol,
            dueAmount = dueAmount,
            adminName = groupSettings.adminName,
            adminPhone = groupSettings.adminPhone,
            onDismiss = { selectedMemberForChat = null },
            onSendWhatsApp = { text ->
                if (member.phone.isNotBlank()) {
                    ReminderHelper.sendWhatsAppReminder(context, member.phone, text)
                } else {
                    ReminderHelper.shareText(context, text, "Send Message")
                }
                selectedMemberForChat = null
            },
            onCall = {
                if (member.phone.isNotBlank()) {
                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${member.phone}"))
                    context.startActivity(intent)
                }
            }
        )
    }
}

// -------------------------------------------------------------
// Tab 0: Alerts & Activity
// -------------------------------------------------------------
@Composable
fun InboxAlertsTab(
    notifications: List<NotificationItem>,
    unreadCount: Int,
    onMarkAllRead: () -> Unit,
    onNotificationClick: (NotificationItem) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Activity & Notifications ($unreadCount Unread)",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = TextSlate800
                )

                if (unreadCount > 0) {
                    TextButton(
                        onClick = onMarkAllRead,
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Icon(imageVector = Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Mark all read", fontSize = 11.5.sp)
                    }
                }
            }
        }

        if (notifications.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Default.Notifications, contentDescription = null, tint = TextSlate400, modifier = Modifier.size(52.dp))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("No notifications yet", fontWeight = FontWeight.SemiBold, color = TextSlate500)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("You'll receive alerts for monthly dues, payment approvals, loan votes, and announcements here.", fontSize = 12.sp, color = TextSlate400, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(notifications, key = { it.id }) { item ->
                    InboxNotificationCardItem(
                        item = item,
                        onClick = { onNotificationClick(item) }
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Tab 1: Payment Approvals (Admin Verification Flow)
// -------------------------------------------------------------
@Composable
fun InboxApprovalsTab(
    pendingApprovals: List<PendingPaymentApprovalItem>,
    currencySymbol: String,
    onApprove: (Long) -> Unit,
    onReject: (Long, String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Pending Member Submissions (${pendingApprovals.size})",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = TextSlate800
                )
            }
        }

        if (pendingApprovals.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Default.VerifiedUser, contentDescription = null, tint = Emerald500, modifier = Modifier.size(56.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("All Clear! No Pending Approvals", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TextSlate800)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("When members submit payments, they will appear here for Admin review and verification.", fontSize = 12.sp, color = TextSlate500, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(pendingApprovals, key = { it.payment.id }) { item ->
                    PendingApprovalCard(
                        item = item,
                        currencySymbol = currencySymbol,
                        onApprove = onApprove,
                        onReject = onReject
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Tab 2: Notices & Announcements
// -------------------------------------------------------------
@Composable
fun InboxNoticesTab(
    notices: List<SocietyNotice>,
    onTogglePin: (SocietyNotice) -> Unit,
    onDeleteNotice: (SocietyNotice) -> Unit,
    onShareNotice: (SocietyNotice) -> Unit
) {
    if (notices.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Campaign, contentDescription = null, tint = TextSlate400, modifier = Modifier.size(56.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text("No notices posted yet", fontWeight = FontWeight.SemiBold, color = TextSlate500)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Tap 'New Notice' below to post an official society announcement.", fontSize = 12.sp, color = TextSlate400, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(notices, key = { it.id }) { notice ->
                NoticeCard(
                    notice = notice,
                    onTogglePin = { onTogglePin(notice) },
                    onDelete = { onDeleteNotice(notice) },
                    onShare = { onShareNotice(notice) }
                )
            }
        }
    }
}

@Composable
fun NoticeCard(
    notice: SocietyNotice,
    onTogglePin: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (notice.isPinned) Color(0xFFEEF2FF) else CardWhite
        ),
        border = BorderStroke(
            1.dp,
            if (notice.isPinned) IndigoPrimary.copy(alpha = 0.4f) else BorderLight
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (notice.isPinned) 2.dp else 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when (notice.category) {
                            "URGENT" -> Rose500.copy(alpha = 0.15f)
                            "PAYMENT" -> Amber500.copy(alpha = 0.15f)
                            "MEETING" -> IndigoPrimary.copy(alpha = 0.15f)
                            else -> Emerald500.copy(alpha = 0.15f)
                        }
                    ) {
                        Text(
                            text = notice.category,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (notice.category) {
                                "URGENT" -> Rose500
                                "PAYMENT" -> Amber500
                                "MEETING" -> IndigoPrimary
                                else -> Emerald500
                            },
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    if (notice.isPinned) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = IndigoPrimary.copy(alpha = 0.12f)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Icon(Icons.Default.PushPin, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(10.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text("PINNED", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                            }
                        }
                    }
                }

                Text(
                    text = DateUtils.formatDate(notice.timestamp),
                    fontSize = 11.sp,
                    color = TextSlate400
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = notice.title,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = TextSlate800
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = notice.content,
                fontSize = 13.sp,
                color = TextSlate500,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Posted by ${notice.author}",
                    fontSize = 11.sp,
                    color = TextSlate400
                )

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = onShare, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Share, contentDescription = "Share", tint = IndigoPrimary, modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onTogglePin, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (notice.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            contentDescription = "Pin",
                            tint = if (notice.isPinned) IndigoPrimary else TextSlate400,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Rose500, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Tab 3: Direct Connect & Member Directory
// -------------------------------------------------------------
@Composable
fun InboxDirectConnectTab(
    members: List<Member>,
    monthlyMembers: List<MemberWithMonthlyStatus>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onMemberClick: (Member) -> Unit,
    onCallMember: (String) -> Unit,
    onNavigateToProfile: (Long) -> Unit
) {
    val filteredMembers = remember(members, searchQuery) {
        if (searchQuery.isBlank()) members
        else members.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
                    it.phone.contains(searchQuery) ||
                    it.memberCode.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Search Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("Search member by name, code or phone...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSlate400) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("inbox_member_search"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = IndigoPrimary,
                    unfocusedBorderColor = BorderLight,
                    focusedContainerColor = CardWhite,
                    unfocusedContainerColor = CardWhite
                )
            )
        }

        if (filteredMembers.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = TextSlate400, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No members found", fontWeight = FontWeight.SemiBold, color = TextSlate500)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredMembers, key = { it.id }) { member ->
                    val monthlyItem = monthlyMembers.find { it.member.id == member.id }
                    val due = monthlyItem?.dueAmount ?: 0.0

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateToProfile(member.id) }
                            .testTag("direct_member_${member.id}"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = CardWhite),
                        border = BorderStroke(1.dp, BorderLight),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = IndigoPrimary.copy(alpha = 0.1f),
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = member.name.take(1).uppercase(),
                                            fontWeight = FontWeight.Bold,
                                            color = IndigoPrimary,
                                            fontSize = 16.sp
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = member.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = TextSlate800
                                    )
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = member.memberCode.ifEmpty { "ID: #${member.id}" },
                                            fontSize = 11.5.sp,
                                            color = TextSlate500
                                        )
                                        if (due > 0) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = Rose500.copy(alpha = 0.12f)
                                            ) {
                                                Text(
                                                    text = "Due: ₹${CurrencyFormatter.formatIndian(due)}",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Rose500,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // Quick WhatsApp Button
                            IconButton(
                                onClick = { onMemberClick(member) },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.Chat, contentDescription = "WhatsApp", tint = Color(0xFF059669), modifier = Modifier.size(20.dp))
                            }

                            // Quick Call Button
                            if (member.phone.isNotBlank()) {
                                IconButton(
                                    onClick = { onCallMember(member.phone) },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(Icons.Default.Call, contentDescription = "Call", tint = IndigoPrimary, modifier = Modifier.size(20.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Helper Card for Tab 0
// -------------------------------------------------------------
@Composable
private fun InboxNotificationCardItem(
    item: NotificationItem,
    onClick: () -> Unit
) {
    val isUnread = !item.isRead
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("notification_item_${item.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isUnread) IndigoPrimaryContainer.copy(alpha = 0.15f) else CardWhite
        ),
        border = BorderStroke(
            1.dp,
            if (isUnread) IndigoPrimary.copy(alpha = 0.35f) else BorderLight
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isUnread) 1.5.dp else 0.5.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = when (item.type) {
                    "PAYMENT_APPROVAL" -> Amber500.copy(alpha = 0.15f)
                    "LOAN_VOTE" -> Amber500.copy(alpha = 0.15f)
                    "DUE_REMINDER" -> Rose500.copy(alpha = 0.15f)
                    "NOTICE" -> IndigoPrimary.copy(alpha = 0.15f)
                    else -> Emerald500.copy(alpha = 0.15f)
                },
                modifier = Modifier.size(38.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = when (item.type) {
                            "PAYMENT_APPROVAL" -> Icons.Default.HourglassTop
                            "LOAN_VOTE" -> Icons.Default.Handshake
                            "DUE_REMINDER" -> Icons.Default.Warning
                            "NOTICE" -> Icons.Default.Campaign
                            else -> Icons.Default.CheckCircle
                        },
                        contentDescription = null,
                        tint = when (item.type) {
                            "PAYMENT_APPROVAL" -> Amber500
                            "LOAN_VOTE" -> Amber500
                            "DUE_REMINDER" -> Rose500
                            "NOTICE" -> IndigoPrimary
                            else -> Emerald500
                        },
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = item.title,
                        fontWeight = if (isUnread) FontWeight.Bold else FontWeight.SemiBold,
                        fontSize = 13.5.sp,
                        color = TextSlate800,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = DateUtils.formatDate(item.timestamp),
                        fontSize = 10.5.sp,
                        color = TextSlate400
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = item.message,
                    fontSize = 12.sp,
                    color = TextSlate500,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 16.sp
                )
            }

            if (isUnread) {
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(IndigoPrimary)
                )
            }
        }
    }
}

// -------------------------------------------------------------
// Dialogs
// -------------------------------------------------------------
@Composable
fun PostNoticeDialog(
    groupName: String,
    onDismiss: () -> Unit,
    onPost: (title: String, content: String, category: String, isPinned: Boolean, shareToWhatsApp: Boolean) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("GENERAL") } // GENERAL, URGENT, PAYMENT, MEETING
    var isPinned by remember { mutableStateOf(false) }
    var shareToWhatsApp by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Post Society Notice", fontWeight = FontWeight.Bold, fontSize = 17.sp)
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Notice Subject / Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Announcement Details") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Category:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextSlate500)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("GENERAL", "PAYMENT", "MEETING", "URGENT").forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = IndigoPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Pin to Top", fontSize = 13.sp, color = TextSlate800)
                    androidx.compose.material3.Switch(
                        checked = isPinned,
                        onCheckedChange = { isPinned = it }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Share to WhatsApp after posting", fontSize = 13.sp, color = TextSlate800)
                    androidx.compose.material3.Switch(
                        checked = shareToWhatsApp,
                        onCheckedChange = { shareToWhatsApp = it }
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && content.isNotBlank()) {
                        onPost(title, content, category, isPinned, shareToWhatsApp)
                    }
                },
                enabled = title.isNotBlank() && content.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
            ) {
                Text("Publish Notice")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun MemberChatActionDialog(
    member: Member,
    groupName: String,
    currencySymbol: String,
    dueAmount: Double,
    adminName: String,
    adminPhone: String,
    onDismiss: () -> Unit,
    onSendWhatsApp: (String) -> Unit,
    onCall: () -> Unit
) {
    var customMessage by remember {
        mutableStateOf(
            if (dueAmount > 0) {
                "Hello ${member.name}, this is a gentle reminder from $groupName regarding your pending society contribution of $currencySymbol${CurrencyFormatter.formatIndian(dueAmount)}. Kindly clear the dues at your earliest convenience. Thank you!"
            } else {
                "Hello ${member.name}, greeting from $groupName! We appreciate your timely contributions and active participation in the society."
            }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Connect with ${member.name}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(member.phone.ifBlank { "No phone number registered" }, fontSize = 12.sp, color = TextSlate400)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = customMessage,
                    onValueChange = { customMessage = it },
                    label = { Text("WhatsApp Message Text") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )

                if (member.phone.isNotBlank()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onCall,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Direct Call", fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSendWhatsApp(customMessage) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
            ) {
                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Send WhatsApp")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
