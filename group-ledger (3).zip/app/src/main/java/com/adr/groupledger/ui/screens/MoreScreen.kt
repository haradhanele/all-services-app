package com.adr.groupledger.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.ui.components.GroupSwitcherModal
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.BorderLight
import com.adr.groupledger.ui.theme.BorderSubtle
import com.adr.groupledger.ui.theme.CardWhite
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.TextSlate400
import com.adr.groupledger.ui.theme.TextSlate500
import com.adr.groupledger.ui.theme.TextSlate800
import com.adr.groupledger.ui.viewmodel.SocietyViewModel

@Composable
fun MoreScreen(
    viewModel: SocietyViewModel,
    onNavigateToLoans: () -> Unit,
    onNavigateToInvestments: () -> Unit,
    onNavigateToFeedback: () -> Unit,
    onNavigateToLedger: () -> Unit,
    onNavigateToMonthly: () -> Unit,
    onNavigateToDues: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToBackup: () -> Unit,
    onNavigateToMyProfile: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()
    val loansWithVoting by viewModel.allLoansWithVotes.collectAsStateWithLifecycle()
    val members by viewModel.allActiveMembers.collectAsStateWithLifecycle()
    val currentMemberId by viewModel.currentMemberId.collectAsStateWithLifecycle()
    val allGroups by viewModel.allGroups.collectAsStateWithLifecycle()

    val pendingLoansCount = remember(loansWithVoting) {
        loansWithVoting.count { it.loan.status in listOf("VOTING", "SUBMITTED") }
    }

    val currentMember = remember(members, currentMemberId) {
        members.find { it.id == currentMemberId } ?: members.firstOrNull()
    }

    var showMemberPicker by remember { mutableStateOf(false) }
    var showGroupSwitcher by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("more_screen"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. User & Role Identity Header Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("user_role_header_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                if (isAdminUnlocked) {
                                    listOf(Color(0xFF1E1B4B), Color(0xFF312E81), Color(0xFF4338CA))
                                } else {
                                    listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF334155))
                                }
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = if (isAdminUnlocked) Emerald500.copy(alpha = 0.2f) else IndigoPrimary.copy(alpha = 0.25f),
                                    modifier = Modifier.size(46.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = if (isAdminUnlocked) Icons.Default.AdminPanelSettings else Icons.Default.AccountCircle,
                                            contentDescription = null,
                                            tint = if (isAdminUnlocked) Emerald500 else Color.White,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = if (isAdminUnlocked) "Admin Mode" else (currentMember?.name ?: "Member Mode"),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp,
                                            color = Color.White
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (isAdminUnlocked) Emerald500.copy(alpha = 0.3f) else IndigoPrimary.copy(alpha = 0.4f)
                                        ) {
                                            Text(
                                                text = if (isAdminUnlocked) "ADMIN" else "MEMBER",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isAdminUnlocked) Emerald500 else Color(0xFFC7D2FE),
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = if (isAdminUnlocked) "Full access & management unlocked" else (currentMember?.phone?.ifBlank { "Personal account" } ?: "Limited to own profile"),
                                        fontSize = 12.sp,
                                        color = Color(0xFF94A3B8)
                                    )
                                }
                            }

                            // Admin Unlock / Lock button
                            if (isAdminUnlocked) {
                                TextButton(
                                    onClick = { viewModel.lockAdmin() },
                                    colors = androidx.compose.material3.ButtonDefaults.textButtonColors(
                                        contentColor = Rose500
                                    )
                                ) {
                                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Lock", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }
                            } else {
                                OutlinedButton(
                                    onClick = { viewModel.requestAdminAction { } },
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, Color(0xFF6366F1)),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
                                        contentColor = Color(0xFFC7D2FE)
                                    )
                                ) {
                                    Icon(Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Admin PIN", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Quick Multi-Group Badge row (Clickable to show Group List)
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color.White.copy(alpha = 0.10f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showGroupSwitcher = true }
                                .testTag("more_group_count_btn")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Groups,
                                        contentDescription = null,
                                        tint = if (isAdminUnlocked) Emerald500 else Color(0xFFC7D2FE),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "${settings.groupName} • ${allGroups.size} Group(s) Available",
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color.White
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "View List",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFC7D2FE)
                                    )
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Icon(
                                        Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = null,
                                        tint = Color(0xFFC7D2FE),
                                        modifier = Modifier.size(13.dp)
                                    )
                                }
                            }
                        }

                        // My Profile Quick Link for Member
                        if (currentMember != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color.White.copy(alpha = 0.08f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onNavigateToMyProfile(currentMember.id)
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.AccountCircle,
                                            contentDescription = null,
                                            tint = Color(0xFF818CF8),
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "View & Edit My Profile",
                                            fontSize = 12.5.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color.White
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        TextButton(
                                            onClick = { showMemberPicker = true },
                                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFF94A3B8))
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text("Switch", fontSize = 11.sp, color = Color(0xFF94A3B8))
                                        }
                                        Icon(
                                            Icons.AutoMirrored.Filled.ArrowForward,
                                            contentDescription = null,
                                            tint = Color(0xFF94A3B8),
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. Financial Management Tools
        item {
            Text(
                text = "FINANCIAL TOOLS",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = TextSlate400,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(start = 4.dp)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    MoreOptionRow(
                        icon = Icons.Default.Handshake,
                        iconTint = Amber500,
                        title = "Loans & 70% Voting",
                        subtitle = "Apply, view active loans and cast member approval votes",
                        badgeCount = if (pendingLoansCount > 0) pendingLoansCount else null,
                        onClick = onNavigateToLoans
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.Default.TrendingUp,
                        iconTint = Color(0xFF3B82F6),
                        title = "Investment Portfolio",
                        subtitle = "Track fixed deposits, land, community assets and returns",
                        onClick = onNavigateToInvestments
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.AutoMirrored.Filled.MenuBook,
                        iconTint = IndigoPrimary,
                        title = "Transaction Ledger",
                        subtitle = "Complete chronological credit/debit audit trail",
                        onClick = onNavigateToLedger
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.Default.CalendarMonth,
                        iconTint = Emerald500,
                        title = "Monthly Collection Matrix",
                        subtitle = "Month-by-month member payment breakdown",
                        onClick = onNavigateToMonthly
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.Default.Payments,
                        iconTint = Rose500,
                        title = "Pending Dues & Reminders",
                        subtitle = "Track unpaid balances and trigger WhatsApp alerts",
                        onClick = onNavigateToDues
                    )
                }
            }
        }

        // 3. Governance & Community
        item {
            Text(
                text = "COMMUNITY & GOVERNANCE",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = TextSlate400,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(start = 4.dp)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    MoreOptionRow(
                        icon = Icons.Default.Feedback,
                        iconTint = Color(0xFF8B5CF6),
                        title = "Proposals, Suggestions & Complaints",
                        subtitle = "Submit society proposals and upvote community ideas",
                        onClick = onNavigateToFeedback
                    )
                }
            }
        }

        // 4. Administration & Security
        item {
            Text(
                text = "SETTINGS & SYSTEM",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = TextSlate400,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(start = 4.dp)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    MoreOptionRow(
                        icon = Icons.Default.Groups,
                        iconTint = IndigoPrimary,
                        title = "Switch & Manage Groups (${allGroups.size})",
                        subtitle = "${settings.groupName} active • Tap to view group list & switch",
                        badgeCount = allGroups.size,
                        onClick = { showGroupSwitcher = true }
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.Default.Key,
                        iconTint = Amber500,
                        title = "Group Invite Code: ${settings.inviteCode}",
                        subtitle = "Generate new joining code or share with members",
                        isLockProtected = !isAdminUnlocked,
                        onClick = {
                            viewModel.requestAdminAction {
                                onNavigateToSettings()
                            }
                        }
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.Default.Settings,
                        iconTint = IndigoPrimary,
                        title = "Society Settings",
                        subtitle = "Group name, contribution amount, PIN & rules",
                        isLockProtected = !isAdminUnlocked,
                        onClick = {
                            viewModel.requestAdminAction {
                                onNavigateToSettings()
                            }
                        }
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.Default.Backup,
                        iconTint = Emerald500,
                        title = "Backup & Restore Database",
                        subtitle = "Export or restore complete JSON database backup",
                        isLockProtected = !isAdminUnlocked,
                        onClick = {
                            viewModel.requestAdminAction {
                                onNavigateToBackup()
                            }
                        }
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.AutoMirrored.Filled.Logout,
                        iconTint = Rose500,
                        title = "Sign Out / Switch Account",
                        subtitle = "Return to welcome screen and switch login profile",
                        onClick = {
                            viewModel.logout()
                        }
                    )
                }
            }
        }

        // 5. App Info Footer
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "${settings.groupName} • v1.2.0",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp,
                    color = TextSlate500
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "100% Offline & Secure Local Database",
                    fontSize = 11.sp,
                    color = TextSlate400
                )
            }
        }
    }

    // Switch Current Member Dialog
    if (showMemberPicker) {
        AlertDialog(
            onDismissRequest = { showMemberPicker = false },
            title = {
                Text("Select Your Member Profile", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Choose which member profile you represent on this device for self-service updates:",
                        fontSize = 13.sp,
                        color = TextSlate500,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    LazyColumn(
                        modifier = Modifier.height(260.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(members.size) { index ->
                            val member = members[index]
                            val isSelected = member.id == (currentMemberId ?: members.firstOrNull()?.id)
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) IndigoPrimary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, if (isSelected) IndigoPrimary else BorderLight),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.setCurrentMemberId(member.id)
                                        showMemberPicker = false
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = member.name,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            fontSize = 14.sp,
                                            color = if (isSelected) IndigoPrimary else TextSlate800
                                        )
                                        Text(
                                            text = member.phone.ifBlank { member.memberCode },
                                            fontSize = 11.5.sp,
                                            color = TextSlate400
                                        )
                                    }
                                    if (isSelected) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showMemberPicker = false }) {
                    Text("Close")
                }
            }
        )
    }

    GroupSwitcherModal(
        viewModel = viewModel,
        isOpen = showGroupSwitcher,
        onDismiss = { showGroupSwitcher = false }
    )
}

@Composable
fun MoreOptionRow(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    badgeCount: Int? = null,
    isLockProtected: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = iconTint.copy(alpha = 0.12f),
            modifier = Modifier.size(40.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.5.sp,
                    color = TextSlate800
                )
                if (isLockProtected) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        Icons.Default.Lock,
                        contentDescription = "Admin PIN Protected",
                        tint = TextSlate400,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = TextSlate500,
                lineHeight = 16.sp
            )
        }

        if (badgeCount != null && badgeCount > 0) {
            Surface(
                shape = CircleShape,
                color = Rose500,
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Text(
                    text = "$badgeCount",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = TextSlate400,
            modifier = Modifier.size(16.dp)
        )
    }
}

@Composable
fun MoreDivider() {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .padding(horizontal = 16.dp),
        color = BorderSubtle
    ) {}
}
