package com.adr.groupledger.ui.components

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adr.groupledger.ui.theme.CardWhite
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.TextSlate500
import com.adr.groupledger.ui.theme.TextSlate800

@Composable
fun ConfirmActionDialog(
    isOpen: Boolean,
    title: String,
    message: String,
    confirmButtonText: String = "Confirm",
    isDestructive: Boolean = false,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    if (!isOpen) return

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardWhite,
        shape = RoundedCornerShape(14.dp),
        icon = {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = null,
                tint = if (isDestructive) Rose500 else IndigoPrimary
            )
        },
        title = {
            Text(text = title, fontWeight = FontWeight.Bold, color = TextSlate800, fontSize = 16.sp)
        },
        text = {
            Text(text = message, style = MaterialTheme.typography.bodyMedium, color = TextSlate500, fontSize = 13.5.sp)
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm()
                    onDismiss()
                },
                colors = if (isDestructive) {
                    ButtonDefaults.buttonColors(containerColor = Rose500)
                } else {
                    ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("confirm_dialog_btn")
            ) {
                Text(confirmButtonText, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("dismiss_dialog_btn")
            ) {
                Text("Cancel", color = TextSlate500, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }
        }
    )
}

