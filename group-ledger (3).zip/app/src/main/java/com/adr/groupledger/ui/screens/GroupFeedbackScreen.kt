package com.adr.groupledger.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.FeedbackWithVotes
import com.adr.groupledger.data.model.GroupFeedback
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.BorderLight
import com.adr.groupledger.ui.theme.CardWhite
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.TextSlate400
import com.adr.groupledger.ui.theme.TextSlate500
import com.adr.groupledger.ui.theme.TextSlate800
import com.adr.groupledger.ui.theme.appOutlinedTextFieldColors
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.utils.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupFeedbackScreen(
    viewModel: SocietyViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val feedbacks by viewModel.feedbacksWithVotes.collectAsStateWithLifecycle()
    val activeMembers by viewModel.allActiveMembers.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: All, 1: Proposals, 2: Suggestions, 3: Complaints
    var showCreateDialog by remember { mutableStateOf(false) }
    var selectedVoterMember by remember { mutableStateOf<Member?>(activeMembers.firstOrNull()) }

    if (selectedVoterMember == null && activeMembers.isNotEmpty()) {
        selectedVoterMember = activeMembers.firstOrNull()
    }

    val filteredFeedbacks = remember(feedbacks, selectedTab) {
        when (selectedTab) {
            1 -> feedbacks.filter { it.feedback.type == "PROPOSAL" }
            2 -> feedbacks.filter { it.feedback.type == "SUGGESTION" }
            3 -> feedbacks.filter { it.feedback.type == "COMPLAINT" }
            else -> feedbacks
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = IndigoPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("submit_feedback_fab")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "New Entry")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("New Entry", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Voter Selector bar
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Acting Member: ${selectedVoterMember?.name ?: "Select"}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSlate800
                        )
                    }

                    var expandedMenu by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(
                            onClick = { expandedMenu = true },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("Switch", fontSize = 11.sp)
                        }

                        androidx.compose.material3.DropdownMenu(
                            expanded = expandedMenu,
                            onDismissRequest = { expandedMenu = false }
                        ) {
                            activeMembers.forEach { member ->
                                DropdownMenuItem(
                                    text = { Text(member.name, fontSize = 12.5.sp) },
                                    onClick = {
                                        selectedVoterMember = member
                                        expandedMenu = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Category Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = IndigoPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = IndigoPrimary,
                        height = 3.dp
                    )
                }
            ) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("All (${feedbacks.size})", fontSize = 12.sp) })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Proposals", fontSize = 12.sp) })
                Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Suggestions", fontSize = 12.sp) })
                Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("Complaints", fontSize = 12.sp) })
            }

            if (filteredFeedbacks.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.ChatBubbleOutline, contentDescription = null, tint = TextSlate400, modifier = Modifier.size(56.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No entries in this section", fontWeight = FontWeight.SemiBold, color = TextSlate500)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredFeedbacks, key = { it.feedback.id }) { item ->
                        FeedbackCardItem(
                            item = item,
                            currentVoter = selectedVoterMember,
                            onVote = { vote ->
                                selectedVoterMember?.let { voter ->
                                    viewModel.voteOnProposal(item.feedback.id, voter.id, voter.name, vote)
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateFeedbackDialog(
            activeMembers = activeMembers,
            onDismiss = { showCreateDialog = false },
            onSubmit = { type, member, isAnon, subject, desc, requiresVoting ->
                viewModel.submitFeedback(
                    type = type,
                    memberId = member.id,
                    memberName = member.name,
                    isAnonymous = isAnon,
                    subject = subject,
                    description = desc,
                    requiresVoting = requiresVoting,
                    onSuccess = { showCreateDialog = false }
                )
            }
        )
    }
}

@Composable
fun FeedbackCardItem(
    item: FeedbackWithVotes,
    currentVoter: Member?,
    onVote: (String) -> Unit
) {
    val fb = item.feedback

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite),
        border = BorderStroke(1.dp, BorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Type Badge
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = when (fb.type) {
                        "PROPOSAL" -> IndigoPrimary.copy(alpha = 0.12f)
                        "SUGGESTION" -> Amber500.copy(alpha = 0.12f)
                        else -> Rose500.copy(alpha = 0.12f)
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = when (fb.type) {
                                "PROPOSAL" -> Icons.Default.CheckCircle
                                "SUGGESTION" -> Icons.Default.Lightbulb
                                else -> Icons.Default.ReportProblem
                            },
                            contentDescription = null,
                            tint = when (fb.type) {
                                "PROPOSAL" -> IndigoPrimary
                                "SUGGESTION" -> Amber500
                                else -> Rose500
                            },
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = fb.type,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (fb.type) {
                                "PROPOSAL" -> IndigoPrimary
                                "SUGGESTION" -> Amber500
                                else -> Rose500
                            }
                        )
                    }
                }

                Text(
                    text = DateUtils.formatDate(fb.createdAt),
                    fontSize = 11.5.sp,
                    color = TextSlate500
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = fb.subject,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = TextSlate800
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = fb.description,
                fontSize = 13.sp,
                color = TextSlate800
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (fb.isAnonymous) {
                        Icon(imageVector = Icons.Default.VisibilityOff, contentDescription = null, tint = TextSlate400, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Anonymous", fontSize = 11.5.sp, color = TextSlate500, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                    } else {
                        Text("By: ${fb.memberName}", fontSize = 11.5.sp, color = TextSlate500)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = when (fb.status) {
                        "RESOLVED", "ACCEPTED" -> Emerald500.copy(alpha = 0.15f)
                        "REJECTED" -> Rose500.copy(alpha = 0.15f)
                        else -> Amber500.copy(alpha = 0.15f)
                    }
                ) {
                    Text(
                        text = fb.status,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (fb.status) {
                            "RESOLVED", "ACCEPTED" -> Emerald500
                            "REJECTED" -> Rose500
                            else -> Amber500
                        }
                    )
                }
            }

            // Voting Section for Proposals
            if (fb.requiresVoting || fb.type == "PROPOSAL") {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Group Voting: ${item.agreeCount} Agree | ${item.disagreeCount} Disagree", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                            Text("${item.agreePercentage.toInt()}%", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { (item.agreePercentage / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = IndigoPrimary,
                            trackColor = BorderLight
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { onVote("AGREE") },
                                colors = ButtonDefaults.buttonColors(containerColor = Emerald500),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Icon(imageVector = Icons.Default.ThumbUp, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Agree", fontSize = 12.sp)
                            }

                            OutlinedButton(
                                onClick = { onVote("DISAGREE") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Icon(imageVector = Icons.Default.ThumbDown, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Disagree", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            if (fb.adminResponse.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Emerald500.copy(alpha = 0.08f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Admin Response:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                        Text(fb.adminResponse, fontSize = 12.sp, color = TextSlate800)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateFeedbackDialog(
    activeMembers: List<Member>,
    onDismiss: () -> Unit,
    onSubmit: (String, Member, Boolean, String, String, Boolean) -> Unit
) {
    var type by remember { mutableStateOf("PROPOSAL") }
    var selectedMember by remember { mutableStateOf(activeMembers.firstOrNull()) }
    var isAnonymous by remember { mutableStateOf(false) }
    var subject by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var requiresVoting by remember { mutableStateOf(true) }

    var expandedMemberMenu by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Submit to Samiti", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("PROPOSAL", "SUGGESTION", "COMPLAINT").forEach { t ->
                        FilterChip(
                            selected = type == t,
                            onClick = {
                                type = t
                                requiresVoting = t == "PROPOSAL"
                            },
                            label = { Text(t, fontSize = 11.sp) }
                        )
                    }
                }

                // Member Selector
                ExposedDropdownMenuBox(
                    expanded = expandedMemberMenu,
                    onExpandedChange = { expandedMemberMenu = !expandedMemberMenu }
                ) {
                    OutlinedTextField(
                        value = selectedMember?.name ?: "Select Member",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Author Member") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedMemberMenu) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        colors = appOutlinedTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedMemberMenu,
                        onDismissRequest = { expandedMemberMenu = false }
                    ) {
                        activeMembers.forEach { m ->
                            DropdownMenuItem(
                                text = { Text(m.name) },
                                onClick = {
                                    selectedMember = m
                                    expandedMemberMenu = false
                                }
                            )
                        }
                    }
                }

                if (type == "COMPLAINT") {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Checkbox(checked = isAnonymous, onCheckedChange = { isAnonymous = it })
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Submit Anonymously", fontSize = 13.sp)
                    }
                }

                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject / Title") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = appOutlinedTextFieldColors()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Details & Reasoning") },
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth(),
                    colors = appOutlinedTextFieldColors()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val m = selectedMember
                    if (m != null && subject.isNotBlank() && description.isNotBlank()) {
                        onSubmit(type, m, isAnonymous, subject, description, requiresVoting)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
            ) {
                Text("Submit")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
