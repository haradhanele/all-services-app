package com.adr.groupledger.data.firebase

import android.content.Context
import android.util.Log
import com.adr.groupledger.data.model.GroupChatMessage
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.LoanRequest
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.Payment
import com.adr.groupledger.data.model.SocietyNotice
import com.adr.groupledger.data.model.TransactionRecord
import com.adr.groupledger.data.model.UserAccount
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

/**
 * FirebaseService provides real-time Firebase Authentication (Email & Password, Password Reset)
 * and Cloud Firestore real-time synchronization for Users, Groups, Members, and Ledger Transactions.
 */
class FirebaseService(private val context: Context) {

    private val TAG = "FirebaseService"

    private val auth: FirebaseAuth? by lazy {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }
            FirebaseAuth.getInstance()
        } catch (e: Exception) {
            Log.w(TAG, "FirebaseAuth initialization: ${e.message}")
            null
        }
    }

    private val firestore: FirebaseFirestore? by lazy {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.w(TAG, "FirebaseFirestore initialization: ${e.message}")
            null
        }
    }

    val isFirebaseAvailable: Boolean
        get() = auth != null && firestore != null

    val currentFirebaseUser: FirebaseUser?
        get() = auth?.currentUser

    // -------------------------------------------------------------
    // Firebase Authentication: Email & Password, Reset
    // -------------------------------------------------------------

    suspend fun signUpWithEmail(
        email: String,
        password: String,
        displayName: String
    ): Result<UserAccount> {
        val trimmedEmail = email.trim()
        val authInstance = auth
        if (authInstance == null) {
            val fallbackUser = UserAccount(
                fullName = displayName.trim(),
                email = trimmedEmail,
                phone = "",
                passwordHash = password,
                isAccountCompleted = true
            )
            return Result.success(fallbackUser)
        }

        return try {
            val result = authInstance.createUserWithEmailAndPassword(trimmedEmail, password).await()
            val firebaseUser = result.user

            if (firebaseUser != null && displayName.isNotBlank()) {
                try {
                    val profileUpdates = UserProfileChangeRequest.Builder()
                        .setDisplayName(displayName.trim())
                        .build()
                    firebaseUser.updateProfile(profileUpdates).await()
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to update Firebase display name: ${e.message}")
                }
            }

            val userAccount = UserAccount(
                id = (firebaseUser?.uid.hashCode().toLong() and 0x7FFFFFFFFFFFFFFFL).coerceAtLeast(1L),
                fullName = displayName.trim().ifBlank { firebaseUser?.displayName ?: "Member" },
                email = trimmedEmail,
                phone = firebaseUser?.phoneNumber ?: "",
                passwordHash = "FIREBASE_AUTH_SECURED",
                isAccountCompleted = true
            )

            // Save user profile to Cloud Firestore
            saveUser(userAccount)

            Result.success(userAccount)
        } catch (e: Exception) {
            Log.e(TAG, "Firebase signUp error", e)
            Result.failure(e)
        }
    }

    suspend fun signInWithEmail(
        email: String,
        password: String
    ): Result<UserAccount> {
        val trimmedEmail = email.trim()
        val authInstance = auth
        if (authInstance == null) {
            val fallbackUser = UserAccount(
                fullName = trimmedEmail.substringBefore("@").replaceFirstChar { it.uppercase() },
                email = trimmedEmail,
                passwordHash = password,
                isAccountCompleted = true
            )
            return Result.success(fallbackUser)
        }

        return try {
            val result = authInstance.signInWithEmailAndPassword(trimmedEmail, password).await()
            val firebaseUser = result.user

            val userAccount = UserAccount(
                id = (firebaseUser?.uid.hashCode().toLong() and 0x7FFFFFFFFFFFFFFFL).coerceAtLeast(1L),
                fullName = firebaseUser?.displayName ?: trimmedEmail.substringBefore("@").replaceFirstChar { it.uppercase() },
                email = firebaseUser?.email ?: trimmedEmail,
                phone = firebaseUser?.phoneNumber ?: "",
                passwordHash = "FIREBASE_AUTH_SECURED",
                isAccountCompleted = true
            )

            // Sync user profile to Cloud Firestore
            saveUser(userAccount)

            Result.success(userAccount)
        } catch (e: Exception) {
            Log.e(TAG, "Firebase signIn error", e)
            Result.failure(e)
        }
    }

    suspend fun sendPasswordResetEmail(email: String): Result<Unit> {
        val trimmedEmail = email.trim()
        val authInstance = auth
        if (authInstance == null) {
            return Result.success(Unit)
        }

        return try {
            authInstance.sendPasswordResetEmail(trimmedEmail).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Firebase sendPasswordResetEmail error", e)
            Result.failure(e)
        }
    }

    fun signOut() {
        try {
            auth?.signOut()
        } catch (e: Exception) {
            Log.w(TAG, "Sign out error", e)
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Users
    // -------------------------------------------------------------

    suspend fun saveUser(user: UserAccount) {
        val db = firestore ?: return
        try {
            val map = hashMapOf(
                "id" to user.id,
                "fullName" to user.fullName,
                "email" to user.email,
                "phone" to user.phone,
                "avatarUri" to user.avatarUri,
                "isAccountCompleted" to user.isAccountCompleted,
                "createdAt" to user.createdAt
            )
            db.collection("users").document(user.id.toString()).set(map, SetOptions.merge()).await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveUser error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Groups
    // -------------------------------------------------------------

    suspend fun saveGroup(group: GroupSettings) {
        val db = firestore ?: return
        try {
            val map = hashMapOf(
                "id" to group.id,
                "groupName" to group.groupName,
                "groupSubtitle" to group.groupSubtitle,
                "description" to group.description,
                "groupType" to group.groupType,
                "address" to group.address,
                "contactPhone" to group.contactPhone,
                "contactEmail" to group.contactEmail,
                "createdAt" to group.createdAt,
                "logoUri" to group.logoUri,
                "inviteCode" to group.inviteCode,
                "createdByUserId" to group.createdByUserId,
                "isContributionEnabled" to group.isContributionEnabled,
                "defaultContribution" to group.defaultContribution,
                "contributionFrequency" to group.contributionFrequency,
                "dueDayOfMonth" to group.dueDayOfMonth,
                "isLateFeeEnabled" to group.isLateFeeEnabled,
                "lateFineAmount" to group.lateFineAmount,
                "gracePeriodDays" to group.gracePeriodDays,
                "paymentRules" to group.paymentRules,
                "modulesConfigJson" to group.modulesConfigJson,
                "currencySymbol" to group.currencySymbol,
                "financialYearStartMonth" to group.financialYearStartMonth,
                "adminName" to group.adminName,
                "adminPhone" to group.adminPhone,
                "adminPin" to group.adminPin,
                "isPinLockEnabled" to group.isPinLockEnabled,
                "themeMode" to group.themeMode,
                "updatedAt" to System.currentTimeMillis()
            )
            db.collection("groups").document(group.id.toString()).set(map, SetOptions.merge()).await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveGroup error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Members
    // -------------------------------------------------------------

    suspend fun saveMember(member: Member) {
        val db = firestore ?: return
        try {
            val map = hashMapOf(
                "id" to member.id,
                "groupId" to member.groupId,
                "memberCode" to member.memberCode,
                "name" to member.name,
                "phone" to member.phone,
                "address" to member.address,
                "joinDate" to member.joinDate,
                "monthlyContribution" to member.monthlyContribution,
                "photoUri" to member.photoUri,
                "isActive" to member.isActive,
                "notes" to member.notes
            )
            db.collection("groups")
                .document(member.groupId.toString())
                .collection("members")
                .document(member.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveMember error: ${e.message}")
        }
    }

    suspend fun deleteMember(groupId: Long, memberId: Long) {
        val db = firestore ?: return
        try {
            db.collection("groups")
                .document(groupId.toString())
                .collection("members")
                .document(memberId.toString())
                .delete()
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore deleteMember error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Payments (Ledger Dues)
    // -------------------------------------------------------------

    suspend fun savePayment(payment: Payment) {
        val db = firestore ?: return
        try {
            val map = hashMapOf(
                "id" to payment.id,
                "groupId" to payment.groupId,
                "memberId" to payment.memberId,
                "month" to payment.month,
                "year" to payment.year,
                "expectedAmount" to payment.expectedAmount,
                "paidAmount" to payment.paidAmount,
                "dueAmount" to payment.dueAmount,
                "paymentDate" to payment.paymentDate,
                "paymentMethod" to payment.paymentMethod,
                "transactionReference" to payment.transactionReference,
                "notes" to payment.notes,
                "status" to payment.status,
                "approvalStatus" to payment.approvalStatus,
                "rejectionReason" to payment.rejectionReason,
                "approvedAt" to (payment.approvedAt ?: 0L),
                "approvedBy" to payment.approvedBy,
                "submittedAt" to payment.submittedAt
            )
            db.collection("groups")
                .document(payment.groupId.toString())
                .collection("payments")
                .document(payment.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore savePayment error: ${e.message}")
        }
    }

    suspend fun deletePayment(groupId: Long, paymentId: Long) {
        val db = firestore ?: return
        try {
            db.collection("groups")
                .document(groupId.toString())
                .collection("payments")
                .document(paymentId.toString())
                .delete()
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore deletePayment error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Transactions (Income / Expense Ledger)
    // -------------------------------------------------------------

    suspend fun saveTransaction(tx: TransactionRecord) {
        val db = firestore ?: return
        try {
            val map = hashMapOf(
                "id" to tx.id,
                "groupId" to tx.groupId,
                "txnNumber" to tx.txnNumber,
                "date" to tx.date,
                "amount" to tx.amount,
                "type" to tx.type,
                "isCredit" to tx.isCredit,
                "description" to tx.description,
                "paymentMethod" to tx.paymentMethod,
                "relatedMemberId" to (tx.relatedMemberId ?: 0L),
                "relatedMemberName" to (tx.relatedMemberName ?: ""),
                "relatedLoanId" to (tx.relatedLoanId ?: 0L),
                "relatedInvestmentId" to (tx.relatedInvestmentId ?: 0L),
                "createdBy" to tx.createdBy
            )
            db.collection("groups")
                .document(tx.groupId.toString())
                .collection("transactions")
                .document(tx.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveTransaction error: ${e.message}")
        }
    }

    suspend fun deleteTransaction(groupId: Long, txId: Long) {
        val db = firestore ?: return
        try {
            db.collection("groups")
                .document(groupId.toString())
                .collection("transactions")
                .document(txId.toString())
                .delete()
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore deleteTransaction error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Notices
    // -------------------------------------------------------------

    suspend fun saveNotice(notice: SocietyNotice) {
        val db = firestore ?: return
        try {
            val map = hashMapOf(
                "id" to notice.id,
                "groupId" to notice.groupId,
                "title" to notice.title,
                "content" to notice.content,
                "category" to notice.category,
                "author" to notice.author,
                "timestamp" to notice.timestamp,
                "isPinned" to notice.isPinned
            )
            db.collection("groups")
                .document(notice.groupId.toString())
                .collection("notices")
                .document(notice.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveNotice error: ${e.message}")
        }
    }

    suspend fun deleteNotice(groupId: Long, noticeId: Long) {
        val db = firestore ?: return
        try {
            db.collection("groups")
                .document(groupId.toString())
                .collection("notices")
                .document(noticeId.toString())
                .delete()
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore deleteNotice error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Loans
    // -------------------------------------------------------------

    suspend fun saveLoan(loan: LoanRequest) {
        val db = firestore ?: return
        try {
            val map = hashMapOf(
                "id" to loan.id,
                "groupId" to loan.groupId,
                "requesterMemberId" to loan.requesterMemberId,
                "requesterName" to loan.requesterName,
                "requesterPhone" to loan.requesterPhone,
                "requestedAmount" to loan.requestedAmount,
                "purpose" to loan.purpose,
                "reason" to loan.reason,
                "duration" to loan.duration,
                "durationUnit" to loan.durationUnit,
                "expectedRepaymentDate" to loan.expectedRepaymentDate,
                "note" to loan.note,
                "createdAt" to loan.createdAt,
                "votingDeadline" to loan.votingDeadline,
                "status" to loan.status,
                "disbursedDate" to (loan.disbursedDate ?: 0L),
                "disbursedBy" to (loan.disbursedBy ?: ""),
                "repaidAmount" to loan.repaidAmount,
                "remainingAmount" to loan.remainingAmount
            )
            db.collection("groups")
                .document(loan.groupId.toString())
                .collection("loans")
                .document(loan.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveLoan error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Chat Messages
    // -------------------------------------------------------------

    suspend fun saveChatMessage(msg: GroupChatMessage) {
        val db = firestore ?: return
        try {
            val map = hashMapOf(
                "id" to msg.id,
                "groupId" to msg.groupId,
                "senderId" to msg.senderId,
                "senderName" to msg.senderName,
                "senderRole" to msg.senderRole,
                "message" to msg.message,
                "timestamp" to msg.timestamp,
                "isAnnouncement" to msg.isAnnouncement,
                "isRead" to msg.isRead
            )
            db.collection("groups")
                .document(msg.groupId.toString())
                .collection("messages")
                .document(msg.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveChatMessage error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Real-Time Listeners for Cloud Firestore
    // -------------------------------------------------------------

    fun attachRealtimeSync(
        groupId: Long,
        onMembersReceived: (List<Member>) -> Unit,
        onPaymentsReceived: (List<Payment>) -> Unit,
        onTransactionsReceived: (List<TransactionRecord>) -> Unit,
        onNoticesReceived: (List<SocietyNotice>) -> Unit,
        onLoansReceived: (List<LoanRequest>) -> Unit,
        onMessagesReceived: (List<GroupChatMessage>) -> Unit,
        onGroupSettingsReceived: (GroupSettings) -> Unit
    ): () -> Unit {
        val db = firestore ?: return {}
        val registrations = mutableListOf<ListenerRegistration>()

        try {
            // 1. Group settings listener
            val groupReg = db.collection("groups").document(groupId.toString())
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null || !snapshot.exists()) return@addSnapshotListener
                    try {
                        val settings = GroupSettings(
                            id = snapshot.getLong("id") ?: groupId,
                            groupName = snapshot.getString("groupName") ?: "All services group",
                            groupSubtitle = snapshot.getString("groupSubtitle") ?: "Monthly Savings & Contribution Society",
                            description = snapshot.getString("description") ?: "",
                            groupType = snapshot.getString("groupType") ?: "Self-Help Group",
                            address = snapshot.getString("address") ?: "",
                            contactPhone = snapshot.getString("contactPhone") ?: "",
                            contactEmail = snapshot.getString("contactEmail") ?: "",
                            createdAt = snapshot.getLong("createdAt") ?: System.currentTimeMillis(),
                            logoUri = snapshot.getString("logoUri") ?: "",
                            inviteCode = snapshot.getString("inviteCode") ?: "SAMITI-${groupId}",
                            createdByUserId = snapshot.getLong("createdByUserId") ?: 1L,
                            isContributionEnabled = snapshot.getBoolean("isContributionEnabled") ?: true,
                            defaultContribution = snapshot.getDouble("defaultContribution") ?: 500.0,
                            contributionFrequency = snapshot.getString("contributionFrequency") ?: "MONTHLY",
                            dueDayOfMonth = (snapshot.getLong("dueDayOfMonth") ?: 10).toInt(),
                            isLateFeeEnabled = snapshot.getBoolean("isLateFeeEnabled") ?: false,
                            lateFineAmount = snapshot.getDouble("lateFineAmount") ?: 0.0,
                            gracePeriodDays = (snapshot.getLong("gracePeriodDays") ?: 5).toInt(),
                            paymentRules = snapshot.getString("paymentRules") ?: "",
                            modulesConfigJson = snapshot.getString("modulesConfigJson") ?: "",
                            currencySymbol = snapshot.getString("currencySymbol") ?: "₹",
                            financialYearStartMonth = (snapshot.getLong("financialYearStartMonth") ?: 4).toInt(),
                            adminName = snapshot.getString("adminName") ?: "Society Treasurer",
                            adminPhone = snapshot.getString("adminPhone") ?: "+91 98765 43210",
                            adminPin = snapshot.getString("adminPin") ?: "1234",
                            isPinLockEnabled = snapshot.getBoolean("isPinLockEnabled") ?: false,
                            themeMode = snapshot.getString("themeMode") ?: "SYSTEM"
                        )
                        onGroupSettingsReceived(settings)
                    } catch (e: Exception) {
                        Log.w(TAG, "Error parsing Firestore group settings", e)
                    }
                }
            registrations.add(groupReg)

            // 2. Members listener
            val membersReg = db.collection("groups").document(groupId.toString())
                .collection("members")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            Member(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                memberCode = doc.getString("memberCode") ?: "",
                                name = doc.getString("name") ?: "",
                                phone = doc.getString("phone") ?: "",
                                address = doc.getString("address") ?: "",
                                joinDate = doc.getLong("joinDate") ?: System.currentTimeMillis(),
                                monthlyContribution = doc.getDouble("monthlyContribution") ?: 0.0,
                                photoUri = doc.getString("photoUri") ?: "",
                                isActive = doc.getBoolean("isActive") ?: true,
                                notes = doc.getString("notes") ?: ""
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    if (list.isNotEmpty()) {
                        onMembersReceived(list)
                    }
                }
            registrations.add(membersReg)

            // 3. Payments listener
            val paymentsReg = db.collection("groups").document(groupId.toString())
                .collection("payments")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            Payment(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                memberId = doc.getLong("memberId") ?: 0L,
                                month = (doc.getLong("month") ?: 1).toInt(),
                                year = (doc.getLong("year") ?: 2026).toInt(),
                                expectedAmount = doc.getDouble("expectedAmount") ?: 0.0,
                                paidAmount = doc.getDouble("paidAmount") ?: 0.0,
                                dueAmount = doc.getDouble("dueAmount") ?: 0.0,
                                paymentDate = doc.getLong("paymentDate") ?: System.currentTimeMillis(),
                                paymentMethod = doc.getString("paymentMethod") ?: "Cash",
                                transactionReference = doc.getString("transactionReference") ?: "",
                                notes = doc.getString("notes") ?: "",
                                status = doc.getString("status") ?: "PAID",
                                approvalStatus = doc.getString("approvalStatus") ?: "APPROVED",
                                rejectionReason = doc.getString("rejectionReason") ?: "",
                                approvedAt = doc.getLong("approvedAt"),
                                approvedBy = doc.getString("approvedBy") ?: "",
                                submittedAt = doc.getLong("submittedAt") ?: System.currentTimeMillis()
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    if (list.isNotEmpty()) {
                        onPaymentsReceived(list)
                    }
                }
            registrations.add(paymentsReg)

            // 4. Transactions listener
            val txReg = db.collection("groups").document(groupId.toString())
                .collection("transactions")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            TransactionRecord(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                txnNumber = doc.getString("txnNumber") ?: "TXN-2026",
                                date = doc.getLong("date") ?: System.currentTimeMillis(),
                                amount = doc.getDouble("amount") ?: 0.0,
                                type = doc.getString("type") ?: "CONTRIBUTION",
                                isCredit = doc.getBoolean("isCredit") ?: true,
                                description = doc.getString("description") ?: "",
                                paymentMethod = doc.getString("paymentMethod") ?: "Cash",
                                relatedMemberId = doc.getLong("relatedMemberId"),
                                relatedMemberName = doc.getString("relatedMemberName"),
                                relatedLoanId = doc.getLong("relatedLoanId"),
                                relatedInvestmentId = doc.getLong("relatedInvestmentId"),
                                createdBy = doc.getString("createdBy") ?: "Admin"
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    if (list.isNotEmpty()) {
                        onTransactionsReceived(list)
                    }
                }
            registrations.add(txReg)

            // 5. Notices listener
            val noticesReg = db.collection("groups").document(groupId.toString())
                .collection("notices")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            SocietyNotice(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                title = doc.getString("title") ?: "",
                                content = doc.getString("content") ?: "",
                                category = doc.getString("category") ?: "ANNOUNCEMENT",
                                author = doc.getString("author") ?: "Admin",
                                timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis(),
                                isPinned = doc.getBoolean("isPinned") ?: false
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    if (list.isNotEmpty()) {
                        onNoticesReceived(list)
                    }
                }
            registrations.add(noticesReg)

            // 6. Loans listener
            val loansReg = db.collection("groups").document(groupId.toString())
                .collection("loans")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            LoanRequest(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                requesterMemberId = doc.getLong("requesterMemberId") ?: 0L,
                                requesterName = doc.getString("requesterName") ?: "",
                                requesterPhone = doc.getString("requesterPhone") ?: "",
                                requestedAmount = doc.getDouble("requestedAmount") ?: 0.0,
                                purpose = doc.getString("purpose") ?: "Emergency",
                                reason = doc.getString("reason") ?: "",
                                duration = (doc.getLong("duration") ?: 6).toInt(),
                                durationUnit = doc.getString("durationUnit") ?: "Months",
                                expectedRepaymentDate = doc.getLong("expectedRepaymentDate") ?: System.currentTimeMillis(),
                                note = doc.getString("note") ?: "",
                                createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis(),
                                votingDeadline = doc.getLong("votingDeadline") ?: System.currentTimeMillis(),
                                status = doc.getString("status") ?: "VOTING",
                                disbursedDate = doc.getLong("disbursedDate"),
                                disbursedBy = doc.getString("disbursedBy"),
                                repaidAmount = doc.getDouble("repaidAmount") ?: 0.0,
                                remainingAmount = doc.getDouble("remainingAmount") ?: 0.0
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    if (list.isNotEmpty()) {
                        onLoansReceived(list)
                    }
                }
            registrations.add(loansReg)

            // 7. Messages listener
            val messagesReg = db.collection("groups").document(groupId.toString())
                .collection("messages")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            GroupChatMessage(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                senderId = doc.getLong("senderId") ?: 1L,
                                senderName = doc.getString("senderName") ?: "Member",
                                senderRole = doc.getString("senderRole") ?: "Member",
                                message = doc.getString("message") ?: "",
                                timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis(),
                                isAnnouncement = doc.getBoolean("isAnnouncement") ?: false,
                                isRead = doc.getBoolean("isRead") ?: true
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    if (list.isNotEmpty()) {
                        onMessagesReceived(list)
                    }
                }
            registrations.add(messagesReg)

        } catch (e: Exception) {
            Log.w(TAG, "Error attaching Firestore listeners: ${e.message}")
        }

        return {
            registrations.forEach { it.remove() }
            registrations.clear()
        }
    }
}
