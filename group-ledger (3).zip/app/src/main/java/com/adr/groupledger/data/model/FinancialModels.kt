package com.adr.groupledger.data.model

data class MemberWithMonthlyStatus(
    val member: Member,
    val payment: Payment?,
    val effectiveExpectedAmount: Double,
    val paidAmount: Double,
    val dueAmount: Double,
    val status: String // "PAID", "PARTIAL", "UNPAID"
)

data class MemberFinancialProfile(
    val member: Member,
    val totalExpectedAllTime: Double,
    val totalPaidAllTime: Double,
    val totalDueAllTime: Double,
    val currentMonthStatus: String,
    val paymentHistory: List<MonthlyLedgerItem>
)

data class MonthlyLedgerItem(
    val month: Int,
    val year: Int,
    val monthName: String,
    val expectedAmount: Double,
    val paidAmount: Double,
    val dueAmount: Double,
    val status: String,
    val paymentDate: Long?,
    val paymentMethod: String?,
    val transactionRef: String?,
    val notes: String?
)

data class MonthlySummary(
    val month: Int,
    val year: Int,
    val monthName: String,
    val totalMembers: Int,
    val totalExpected: Double,
    val totalCollected: Double,
    val totalDue: Double,
    val paidCount: Int,
    val partialCount: Int,
    val unpaidCount: Int,
    val collectionPercentage: Float
)

data class OverallGroupFinancials(
    val totalMembers: Int,
    val activeMembers: Int,
    val totalCollectedAllTime: Double,
    val totalDueAllTime: Double,
    val currentMonthCollected: Double,
    val currentMonthDue: Double,
    val currentMonthPaidCount: Int,
    val currentMonthUnpaidCount: Int,
    val currentMonthPartialCount: Int,
    val previousMonthCollected: Double,
    val monthlyTrends: List<MonthlyTrendPoint>,
    // Comprehensive Samiti Accounting Fields
    val totalGroupAssets: Double = 0.0,
    val availableInHandBalance: Double = 0.0,
    val bankBalance: Double = 0.0,
    val cashBalance: Double = 0.0,
    val loansGivenTotal: Double = 0.0,
    val outstandingLoans: Double = 0.0,
    val totalInvestmentsValue: Double = 0.0,
    val fixedDepositValue: Double = 0.0,
    val mutualFundsValue: Double = 0.0,
    val stockMarketValue: Double = 0.0,
    val otherInvestmentsValue: Double = 0.0,
    val pendingLoanRequestsCount: Int = 0,
    val unreadNotificationsCount: Int = 0,
    val totalExpenses: Double = 0.0,
    val assetAllocations: List<AssetAllocationItem> = emptyList()
)

data class AssetAllocationItem(
    val category: String,
    val amount: Double,
    val percentage: Float,
    val colorHex: Long
)

data class MonthlyTrendPoint(
    val month: Int,
    val year: Int,
    val label: String, // e.g. "Aug"
    val collected: Double,
    val expected: Double
)

data class RecentTransaction(
    val paymentId: Long,
    val memberId: Long,
    val memberName: String,
    val memberCode: String,
    val month: Int,
    val year: Int,
    val amount: Double,
    val paymentDate: Long,
    val paymentMethod: String,
    val status: String
)
