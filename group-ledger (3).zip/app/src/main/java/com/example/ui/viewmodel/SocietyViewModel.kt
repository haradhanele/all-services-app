package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.FeedbackWithVotes
import com.example.data.model.GroupChatMessage
import com.example.data.model.GroupFeedback
import com.example.data.model.GroupMembership
import com.example.data.model.GroupSettings
import com.example.data.model.HomeModuleConfig
import com.example.data.model.InvestmentRecord
import com.example.data.model.LoanRequest
import com.example.data.model.LoanWithVotingDetails
import com.example.data.model.Member
import com.example.data.model.MemberFinancialProfile
import com.example.data.model.MemberWithMonthlyStatus
import com.example.data.model.MonthlySummary
import com.example.data.model.NotificationItem
import com.example.data.model.OverallGroupFinancials
import com.example.data.model.Payment
import com.example.data.model.PendingPaymentApprovalItem
import com.example.data.model.RecentTransaction
import com.example.data.model.SocietyNotice
import com.example.data.model.TransactionRecord
import com.example.data.model.UserAccount
import com.example.data.repository.SocietyRepository
import com.example.utils.CurrencyFormatter
import com.example.utils.DateUtils
import com.example.utils.ReminderHelper
import com.example.utils.ReportExporter
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.util.Calendar

@OptIn(ExperimentalCoroutinesApi::class)
class SocietyViewModel(
    application: Application,
    private val repository: SocietyRepository
) : AndroidViewModel(application) {

    // -------------------------------------------------------------
    // Authentication & Entry Session State (Mock / Modular Local Auth)
    // -------------------------------------------------------------
    private val authPrefs = application.getSharedPreferences("app_auth_session", Context.MODE_PRIVATE)

    private val _isAuthenticated = MutableStateFlow(authPrefs.getBoolean("is_authenticated", false))
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()

    private val _authLoading = MutableStateFlow(false)
    val authLoading: StateFlow<Boolean> = _authLoading.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    // Multi-Group & User Session State
    private val _currentUserId = MutableStateFlow<Long>(authPrefs.getLong("saved_user_id", 1L))
    val currentUserId: StateFlow<Long> = _currentUserId.asStateFlow()

    private val _currentGroupId = MutableStateFlow<Long>(authPrefs.getLong("saved_group_id", 1L))
    val currentGroupId: StateFlow<Long> = _currentGroupId.asStateFlow()

    val allUsers: StateFlow<List<UserAccount>> = repository.getAllUsersFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val currentUser: StateFlow<UserAccount?> = _currentUserId
        .flatMapLatest { id -> repository.getUserByIdFlow(id) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    val userMemberships: StateFlow<List<GroupMembership>> = _currentUserId
        .flatMapLatest { id -> repository.getMembershipsForUserFlow(id) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allGroups: StateFlow<List<GroupSettings>> = repository.getAllGroupsFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Current Group Settings flow
    val groupSettings: StateFlow<GroupSettings> = _currentGroupId
        .flatMapLatest { gid ->
            repository.getGroupSettingsFlow(gid).map { it ?: GroupSettings(id = gid) }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = GroupSettings()
        )

    // Current Group Home Page Module Configurations flow
    val homeModules: StateFlow<List<HomeModuleConfig>> = groupSettings
        .map { settings ->
            HomeModuleConfig.parseModulesJson(settings.modulesConfigJson)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = HomeModuleConfig.getDefaultModules()
        )

    // Current User's Role in Active Group
    val currentUserRole: StateFlow<String> = combine(_currentUserId, _currentGroupId, userMemberships) { uid, gid, memberships ->
        memberships.find { it.groupId == gid }?.role ?: "MEMBER"
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = "ADMIN"
    )

    // Current selected month & year for Monthly view & reports
    private val calendar = Calendar.getInstance()
    private val _selectedMonth = MutableStateFlow(calendar.get(Calendar.MONTH) + 1)
    val selectedMonth: StateFlow<Int> = _selectedMonth.asStateFlow()

    private val _selectedYear = MutableStateFlow(calendar.get(Calendar.YEAR))
    val selectedYear: StateFlow<Int> = _selectedYear.asStateFlow()

    // Member search and status filter
    private val _memberSearchQuery = MutableStateFlow("")
    val memberSearchQuery: StateFlow<String> = _memberSearchQuery.asStateFlow()

    private val _statusFilter = MutableStateFlow("ALL") // "ALL", "PAID", "PARTIAL", "UNPAID", "PENDING"
    val statusFilter: StateFlow<String> = _statusFilter.asStateFlow()

    // Admin authentication state
    private val _isAdminUnlocked = MutableStateFlow(false)
    val isAdminUnlocked: StateFlow<Boolean> = _isAdminUnlocked.asStateFlow()

    private val _showPinDialog = MutableStateFlow(false)
    val showPinDialog: StateFlow<Boolean> = _showPinDialog.asStateFlow()

    private var pendingAdminAction: (() -> Unit)? = null

    // Selected member for profile inspection
    private val _selectedMemberId = MutableStateFlow<Long?>(null)
    val selectedMemberId: StateFlow<Long?> = _selectedMemberId.asStateFlow()

    // Toast message trigger
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    // -------------------------------------------------------------
    // Scoped Data Streams by Current Group ID
    // -------------------------------------------------------------
    val allMembers: StateFlow<List<Member>> = _currentGroupId
        .flatMapLatest { gid -> repository.getAllMembers(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val activeMembers: StateFlow<List<Member>> = _currentGroupId
        .flatMapLatest { gid -> repository.getActiveMembers(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allActiveMembers: StateFlow<List<Member>> get() = activeMembers

    val allPayments: StateFlow<List<Payment>> = _currentGroupId
        .flatMapLatest { gid -> repository.getAllPayments(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val pendingPaymentApprovals: StateFlow<List<PendingPaymentApprovalItem>> = _currentGroupId
        .flatMapLatest { gid -> repository.getPendingPaymentApprovals(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val overallFinancials: StateFlow<OverallGroupFinancials> = _currentGroupId
        .flatMapLatest { gid -> repository.getComprehensiveFinancials(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = OverallGroupFinancials(
                totalMembers = 0,
                activeMembers = 0,
                totalCollectedAllTime = 0.0,
                totalDueAllTime = 0.0,
                currentMonthCollected = 0.0,
                currentMonthDue = 0.0,
                currentMonthPaidCount = 0,
                currentMonthUnpaidCount = 0,
                currentMonthPartialCount = 0,
                previousMonthCollected = 0.0,
                monthlyTrends = emptyList()
            )
        )

    val currentMonthSummary: StateFlow<MonthlySummary> = combine(
        _selectedMonth,
        _selectedYear,
        allPayments,
        activeMembers,
        groupSettings
    ) { month, year, payments, members, settings ->
        val defExp = settings.defaultContribution
        val mPayments = payments.filter { it.month == month && it.year == year }
        val mApprovedPayments = mPayments.filter { it.isApproved }
        val totalMembers = members.size
        val totalExpected = members.sumOf { if (it.monthlyContribution > 0) it.monthlyContribution else defExp }
        val totalCollected = mApprovedPayments.sumOf { it.paidAmount }
        val totalDue = (totalExpected - totalCollected).coerceAtLeast(0.0)

        val paidCount = mApprovedPayments.count { it.status == "PAID" }
        val partialCount = mApprovedPayments.count { it.status == "PARTIAL" }
        val unpaidCount = (totalMembers - (paidCount + partialCount)).coerceAtLeast(0)
        val collectionPercentage = if (totalExpected > 0) ((totalCollected / totalExpected) * 100).toFloat() else 0f

        MonthlySummary(
            month = month,
            year = year,
            monthName = DateUtils.getMonthName(month),
            totalMembers = totalMembers,
            totalExpected = totalExpected,
            totalCollected = totalCollected,
            totalDue = totalDue,
            paidCount = paidCount,
            partialCount = partialCount,
            unpaidCount = unpaidCount,
            collectionPercentage = collectionPercentage
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = MonthlySummary(
            month = calendar.get(Calendar.MONTH) + 1,
            year = calendar.get(Calendar.YEAR),
            monthName = DateUtils.getMonthName(calendar.get(Calendar.MONTH) + 1),
            totalMembers = 0,
            totalExpected = 0.0,
            totalCollected = 0.0,
            totalDue = 0.0,
            paidCount = 0,
            partialCount = 0,
            unpaidCount = 0,
            collectionPercentage = 0f
        )
    )

    val membersWithMonthlyStatus: StateFlow<List<MemberWithMonthlyStatus>> = combine(
        _selectedMonth,
        _selectedYear,
        activeMembers,
        allPayments,
        groupSettings
    ) { month, year, members, payments, settings ->
        val defaultExp = settings.defaultContribution
        val mPayments = payments.filter { it.month == month && it.year == year }.associateBy { it.memberId }

        members.map { member ->
            val payment = mPayments[member.id]
            val expected = if (member.monthlyContribution > 0) member.monthlyContribution else defaultExp

            val displayStatus = when {
                payment == null -> "UNPAID"
                payment.isPendingApproval -> "PENDING_APPROVAL"
                payment.isRejected -> "REJECTED"
                else -> payment.status
            }

            val paid = if (payment != null && payment.isApproved) payment.paidAmount else 0.0
            val due = if (payment != null && payment.isApproved) payment.dueAmount else expected

            MemberWithMonthlyStatus(
                member = member,
                payment = payment,
                effectiveExpectedAmount = expected,
                paidAmount = paid,
                dueAmount = due,
                status = displayStatus
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val monthlyMembersList: StateFlow<List<MemberWithMonthlyStatus>> get() = membersWithMonthlyStatus

    val filteredMembersWithStatus: StateFlow<List<MemberWithMonthlyStatus>> = combine(
        membersWithMonthlyStatus,
        _memberSearchQuery,
        _statusFilter
    ) { list, query, filter ->
        list.filter { item ->
            val matchesQuery = query.isBlank() ||
                    item.member.name.contains(query, ignoreCase = true) ||
                    item.member.memberCode.contains(query, ignoreCase = true) ||
                    item.member.phone.contains(query)

            val matchesFilter = when (filter) {
                "PAID" -> item.status == "PAID"
                "PARTIAL" -> item.status == "PARTIAL"
                "UNPAID" -> item.status == "UNPAID" || item.status == "REJECTED"
                "PENDING" -> item.status == "PENDING_APPROVAL"
                else -> true
            }

            matchesQuery && matchesFilter
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val pendingDuesList: StateFlow<List<MemberWithMonthlyStatus>> = membersWithMonthlyStatus
        .flatMapLatest { list ->
            MutableStateFlow(list.filter { it.status in listOf("UNPAID", "PARTIAL", "REJECTED") && it.dueAmount > 0 })
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val recentTransactions: StateFlow<List<RecentTransaction>> = _currentGroupId
        .flatMapLatest { gid -> repository.getRecentTransactions(gid, 10) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allLoansWithVotes: StateFlow<List<LoanWithVotingDetails>> = _currentGroupId
        .flatMapLatest { gid -> repository.getLoansWithVotingDetails(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val loansWithVoting: StateFlow<List<LoanWithVotingDetails>> get() = allLoansWithVotes

    val allInvestments: StateFlow<List<InvestmentRecord>> = _currentGroupId
        .flatMapLatest { gid -> repository.getAllInvestments(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allFeedbacksWithVotes: StateFlow<List<FeedbackWithVotes>> = _currentGroupId
        .flatMapLatest { gid -> repository.getFeedbacksWithVotes(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val feedbacksWithVotes: StateFlow<List<FeedbackWithVotes>> get() = allFeedbacksWithVotes

    val allNotifications: StateFlow<List<NotificationItem>> = _currentGroupId
        .flatMapLatest { gid -> repository.getAllNotifications(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val unreadNotificationsCount: StateFlow<Int> = _currentGroupId
        .flatMapLatest { gid -> repository.getUnreadNotificationsCount(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    val allTransactions: StateFlow<List<TransactionRecord>> = _currentGroupId
        .flatMapLatest { gid -> repository.getAllTransactions(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val notices: StateFlow<List<SocietyNotice>> = _currentGroupId
        .flatMapLatest { gid -> repository.getNotices(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val chatMessages: StateFlow<List<GroupChatMessage>> = _currentGroupId
        .flatMapLatest { gid -> repository.getChatMessages(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val memberProfile: StateFlow<MemberFinancialProfile?> = _selectedMemberId
        .flatMapLatest { id ->
            if (id != null) repository.getMemberFinancialProfile(id) else MutableStateFlow(null)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    val selectedMemberProfile: StateFlow<MemberFinancialProfile?> get() = memberProfile

    // -------------------------------------------------------------
    // User & Group Switching / Creation Functions
    // -------------------------------------------------------------
    fun switchUser(userId: Long) {
        _currentUserId.value = userId
        _isAdminUnlocked.value = false
        _currentMemberId.value = null
        viewModelScope.launch {
            val memberships = repository.getMembershipsForUserDirect(userId)
            if (memberships.isNotEmpty()) {
                val matching = memberships.find { it.groupId == _currentGroupId.value }
                if (matching != null) {
                    _currentMemberId.value = matching.memberIdInGroup
                } else {
                    _currentGroupId.value = memberships.first().groupId
                    _currentMemberId.value = memberships.first().memberIdInGroup
                }
            }
            _userMessage.value = "Switched user account"
        }
    }

    fun switchGroup(groupId: Long) {
        _currentGroupId.value = groupId
        _isAdminUnlocked.value = false
        _selectedMemberId.value = null
        viewModelScope.launch {
            val membership = repository.getMembershipDirect(_currentUserId.value, groupId)
            _currentMemberId.value = membership?.memberIdInGroup
            val group = repository.getGroupSettings(groupId)
            if (group != null) {
                _userMessage.value = "Switched to ${group.groupName}"
            }
        }
    }

    fun registerNewUserAccount(
        fullName: String,
        email: String,
        phone: String,
        onSuccess: (Long) -> Unit
    ) {
        viewModelScope.launch {
            if (fullName.isBlank() || phone.isBlank()) {
                _userMessage.value = "Full Name and Phone Number are required"
                return@launch
            }
            val existing = if (email.isNotBlank()) repository.getUserByEmail(email) else null
            if (existing != null) {
                _userMessage.value = "Account already exists with this email. Switched to existing account."
                switchUser(existing.id)
                onSuccess(existing.id)
                return@launch
            }
            val newUser = UserAccount(
                fullName = fullName.trim(),
                email = email.trim(),
                phone = phone.trim()
            )
            val newUserId = repository.createUserAccount(newUser)
            switchUser(newUserId)
            _userMessage.value = "Account created successfully!"
            onSuccess(newUserId)
        }
    }

    fun createNewGroup(
        groupName: String,
        groupSubtitle: String,
        defaultContribution: Double,
        currencySymbol: String,
        onSuccess: (GroupSettings) -> Unit
    ) {
        viewModelScope.launch {
            if (groupName.isBlank()) {
                _userMessage.value = "Group name cannot be empty"
                return@launch
            }
            val user = repository.getUserById(_currentUserId.value) ?: UserAccount(id = _currentUserId.value, fullName = "Admin User")
            val newGroup = repository.createGroup(
                groupName = groupName.trim(),
                groupSubtitle = groupSubtitle.trim(),
                defaultContribution = defaultContribution,
                currencySymbol = currencySymbol.trim().ifBlank { "₹" },
                creatorUser = user
            )
            switchGroup(newGroup.id)
            _isAdminUnlocked.value = true
            _userMessage.value = "New group '${newGroup.groupName}' created! Invite Code: ${newGroup.inviteCode}"
            onSuccess(newGroup)
        }
    }

    fun regenerateGroupInviteCode(onSuccess: (String) -> Unit = {}) {
        viewModelScope.launch {
            val currentGroup = groupSettings.value
            val user = currentUser.value?.fullName ?: currentGroup.adminName
            val newCode = repository.regenerateGroupInviteCode(currentGroup.id, user)
            if (newCode.isNotBlank()) {
                _userMessage.value = "New Invitation Code generated: $newCode"
                onSuccess(newCode)
            }
        }
    }

    fun joinGroupByInviteCode(
        inviteCode: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            if (inviteCode.isBlank()) {
                _userMessage.value = "Please enter an invite code"
                onError("Please enter an invite code")
                return@launch
            }
            val user = repository.getUserById(_currentUserId.value)
            if (user == null) {
                _userMessage.value = "Please select or set up a user profile first."
                onError("No active user profile")
                return@launch
            }
            val (success, message) = repository.joinGroupByInviteCode(inviteCode, user)
            if (success) {
                _userMessage.value = message
                val memberships = repository.getMembershipsForUserDirect(user.id)
                if (memberships.isNotEmpty()) {
                    val lastJoined = memberships.last()
                    switchGroup(lastJoined.groupId)
                }
                onSuccess()
            } else {
                _userMessage.value = message
                onError(message)
            }
        }
    }

    // -------------------------------------------------------------
    // App Entry, Sign Up & Invitation Code Authentication Logic
    // -------------------------------------------------------------
    fun clearAuthError() {
        _authError.value = null
    }

    fun signUpWithEmail(
        fullName: String,
        email: String,
        password: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val trimmedName = fullName.trim()
        val trimmedEmail = email.trim()

        if (trimmedName.isBlank()) {
            val err = "Full name cannot be empty"
            _authError.value = err
            onError(err)
            return
        }
        if (trimmedEmail.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(trimmedEmail).matches()) {
            val err = "Please enter a valid email address"
            _authError.value = err
            onError(err)
            return
        }
        if (password.length < 6) {
            val err = "Password must be at least 6 characters"
            _authError.value = err
            onError(err)
            return
        }

        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            try {
                // Short simulated latency for smooth UX
                kotlinx.coroutines.delay(600)

                val existing = repository.getUserByEmail(trimmedEmail)
                val userId = if (existing != null) {
                    existing.id
                } else {
                    val newAccount = UserAccount(
                        fullName = trimmedName,
                        email = trimmedEmail,
                        phone = "",
                        passwordHash = password,
                        isAccountCompleted = true
                    )
                    repository.createUserAccount(newAccount)
                }

                _currentUserId.value = userId

                // Ensure user has at least one active group membership
                val memberships = repository.getMembershipsForUserDirect(userId)
                val groupId = if (memberships.isNotEmpty()) {
                    memberships.first().groupId
                } else {
                    val allGroups = repository.getAllGroupsDirect()
                    if (allGroups.isNotEmpty()) {
                        val defaultGroup = allGroups.first()
                        val user = repository.getUserById(userId) ?: UserAccount(id = userId, fullName = trimmedName)
                        repository.joinGroupByInviteCode(defaultGroup.inviteCode, user)
                        defaultGroup.id
                    } else {
                        1L
                    }
                }

                _currentGroupId.value = groupId
                val membership = repository.getMembershipDirect(userId, groupId)
                _currentMemberId.value = membership?.memberIdInGroup

                authPrefs.edit()
                    .putBoolean("is_authenticated", true)
                    .putLong("saved_user_id", userId)
                    .putLong("saved_group_id", groupId)
                    .apply()

                _isAuthenticated.value = true
                _authLoading.value = false
                _userMessage.value = "Account created successfully! Welcome, $trimmedName"
                onSuccess()
            } catch (e: Exception) {
                _authLoading.value = false
                val err = e.message ?: "Failed to create account. Please try again."
                _authError.value = err
                onError(err)
            }
        }
    }

    fun loginWithEmail(
        email: String,
        password: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val trimmedEmail = email.trim()

        if (trimmedEmail.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(trimmedEmail).matches()) {
            val err = "Please enter a valid email address"
            _authError.value = err
            onError(err)
            return
        }
        if (password.isBlank()) {
            val err = "Password cannot be empty"
            _authError.value = err
            onError(err)
            return
        }

        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            try {
                // Short simulated latency for smooth UX
                kotlinx.coroutines.delay(500)

                var user = repository.getUserByEmail(trimmedEmail)
                if (user == null) {
                    // Frictionless mock account for testing
                    val newAccount = UserAccount(
                        fullName = trimmedEmail.substringBefore("@").replace(".", " ")
                            .replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() },
                        email = trimmedEmail,
                        phone = "+91 98300 ${10000 + (System.currentTimeMillis() % 90000)}",
                        passwordHash = password,
                        isAccountCompleted = true
                    )
                    val newUid = repository.createUserAccount(newAccount)
                    user = newAccount.copy(id = newUid)
                }

                _currentUserId.value = user.id
                val memberships = repository.getMembershipsForUserDirect(user.id)
                val groupId = if (memberships.isNotEmpty()) {
                    memberships.first().groupId
                } else {
                    1L
                }
                _currentGroupId.value = groupId
                val membership = repository.getMembershipDirect(user.id, groupId)
                _currentMemberId.value = membership?.memberIdInGroup

                authPrefs.edit()
                    .putBoolean("is_authenticated", true)
                    .putLong("saved_user_id", user.id)
                    .putLong("saved_group_id", groupId)
                    .apply()

                _isAuthenticated.value = true
                _authLoading.value = false
                _userMessage.value = "Welcome back, ${user.fullName}!"
                onSuccess()
            } catch (e: Exception) {
                _authLoading.value = false
                val err = e.message ?: "Login failed. Please check credentials."
                _authError.value = err
                onError(err)
            }
        }
    }

    fun joinWithInviteCodeDirect(
        inviteCode: String,
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val trimmed = inviteCode.trim().uppercase()
        if (trimmed.isBlank()) {
            val err = "Please enter an invitation code"
            _authError.value = err
            onError(err)
            return
        }

        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            try {
                // Simulated verification delay
                kotlinx.coroutines.delay(600)

                val group = repository.getOrResolveGroupByInviteCode(trimmed)
                if (group == null) {
                    _authLoading.value = false
                    val err = "Invalid invitation code. Please check the code and try again."
                    _authError.value = err
                    onError(err)
                    return@launch
                }

                // Associate user account
                var user = repository.getUserById(_currentUserId.value)
                if (user == null) {
                    val suffix = (System.currentTimeMillis() % 1000).toString()
                    val newAccount = UserAccount(
                        fullName = "Member #$suffix",
                        email = "member$suffix@groupledger.org",
                        phone = "+91 98300 ${10000 + (System.currentTimeMillis() % 90000)}",
                        isAccountCompleted = false
                    )
                    val newUid = repository.createUserAccount(newAccount)
                    _currentUserId.value = newUid
                    user = newAccount.copy(id = newUid)
                }

                // Join group
                val (joined, msg) = repository.joinGroupByInviteCode(group.inviteCode, user)

                _currentGroupId.value = group.id
                val membership = repository.getMembershipDirect(user.id, group.id)
                _currentMemberId.value = membership?.memberIdInGroup

                authPrefs.edit()
                    .putBoolean("is_authenticated", true)
                    .putLong("saved_user_id", user.id)
                    .putLong("saved_group_id", group.id)
                    .apply()

                _isAuthenticated.value = true
                _authLoading.value = false
                _userMessage.value = "Successfully joined ${group.groupName}!"
                onSuccess(group.groupName)
            } catch (e: Exception) {
                _authLoading.value = false
                val err = e.message ?: "Invalid invitation code. Please check the code and try again."
                _authError.value = err
                onError(err)
            }
        }
    }

    fun logout() {
        authPrefs.edit().putBoolean("is_authenticated", false).apply()
        _isAuthenticated.value = false
        _userMessage.value = "Logged out successfully"
    }

    fun selectMember(id: Long) {
        _selectedMemberId.value = id
    }

    fun selectMonthYear(month: Int, year: Int) {
        _selectedMonth.value = month
        _selectedYear.value = year
    }

    fun prevMonth() {
        if (_selectedMonth.value == 1) {
            _selectedMonth.value = 12
            _selectedYear.value -= 1
        } else {
            _selectedMonth.value -= 1
        }
    }

    fun nextMonth() {
        if (_selectedMonth.value == 12) {
            _selectedMonth.value = 1
            _selectedYear.value += 1
        } else {
            _selectedMonth.value += 1
        }
    }

    fun setSearchQuery(query: String) {
        _memberSearchQuery.value = query
    }

    fun setStatusFilter(filter: String) {
        _statusFilter.value = filter
    }

    fun setSelectedMemberId(id: Long?) {
        _selectedMemberId.value = id
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun showToast(msg: String) {
        _userMessage.value = msg
    }

    // -------------------------------------------------------------
    // Admin Security Actions
    // -------------------------------------------------------------
    fun requestAdminAction(onUnlocked: () -> Unit) {
        val isRoleAdmin = currentUserRole.value == "ADMIN"
        if (_isAdminUnlocked.value || isRoleAdmin) {
            _isAdminUnlocked.value = true
            onUnlocked()
        } else {
            pendingAdminAction = onUnlocked
            _showPinDialog.value = true
        }
    }

    fun dismissPinDialog() {
        _showPinDialog.value = false
        pendingAdminAction = null
    }

    fun verifyPin(pin: String): Boolean {
        val currentPin = groupSettings.value.adminPin
        if (pin == currentPin || (currentPin.isBlank() && pin == "1234")) {
            _isAdminUnlocked.value = true
            _showPinDialog.value = false
            pendingAdminAction?.invoke()
            pendingAdminAction = null
            return true
        }
        return false
    }

    // Current Logged-in / Selected Member Profile Identity (for self-service permission)
    private val _currentMemberId = MutableStateFlow<Long?>(null)
    val currentMemberId: StateFlow<Long?> = _currentMemberId.asStateFlow()

    fun setCurrentMemberId(id: Long?) {
        _currentMemberId.value = id
    }

    fun canEditMember(targetMemberId: Long): Boolean {
        if (_isAdminUnlocked.value || currentUserRole.value == "ADMIN") return true
        val currentId = _currentMemberId.value
        return currentId != null && currentId == targetMemberId
    }

    fun isCurrentMember(targetMemberId: Long): Boolean {
        val currentId = _currentMemberId.value
        return currentId != null && currentId == targetMemberId
    }

    fun lockAdmin() {
        _isAdminUnlocked.value = false
    }

    // -------------------------------------------------------------
    // Member Operations
    // -------------------------------------------------------------
    fun saveMember(
        id: Long = 0L,
        memberCode: String,
        name: String,
        phone: String,
        address: String,
        monthlyContribution: Double,
        photoUri: String = "",
        isActive: Boolean = true,
        notes: String = "",
        onSuccess: () -> Unit
    ) {
        val member = Member(
            id = id,
            groupId = _currentGroupId.value,
            memberCode = memberCode.trim().ifBlank { "M-${System.currentTimeMillis() % 10000}" },
            name = name.trim(),
            phone = phone.trim(),
            address = address.trim(),
            monthlyContribution = monthlyContribution,
            photoUri = photoUri,
            isActive = isActive,
            notes = notes.trim()
        )
        saveMember(member, onSuccess)
    }

    fun saveMember(member: Member, onSuccess: () -> Unit) {
        viewModelScope.launch {
            if (member.name.isBlank()) {
                _userMessage.value = "Member name cannot be empty"
                return@launch
            }

            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            val isSelf = (_currentMemberId.value != null && _currentMemberId.value == member.id)

            val memberWithGroup = member.copy(groupId = _currentGroupId.value)

            if (member.id == 0L) {
                if (!isAdmin) {
                    _userMessage.value = "Permission Denied: Only Admin can add new members"
                    return@launch
                }
                val newId = repository.insertMember(memberWithGroup)
                if (_currentMemberId.value == null) {
                    _currentMemberId.value = newId
                }
                _userMessage.value = "Member added successfully"
                onSuccess()
            } else {
                if (!isAdmin && !isSelf) {
                    _userMessage.value = "Permission Denied: Members can only edit their own profile"
                    return@launch
                }

                if (!isAdmin && isSelf) {
                    val existing = repository.getMemberById(member.id)
                    if (existing != null) {
                        val sanitized = memberWithGroup.copy(
                            memberCode = existing.memberCode,
                            monthlyContribution = existing.monthlyContribution,
                            isActive = existing.isActive,
                            joinDate = existing.joinDate
                        )
                        repository.updateMember(sanitized)
                        _userMessage.value = "Your profile has been updated"
                        onSuccess()
                        return@launch
                    }
                }

                repository.updateMember(memberWithGroup)
                _userMessage.value = "Member updated successfully"
                onSuccess()
            }
        }
    }

    fun deleteMember(member: Member, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can delete members"
                return@launch
            }
            repository.deleteMember(member)
            _userMessage.value = "Member deleted successfully"
            onSuccess()
        }
    }

    // -------------------------------------------------------------
    // Payment Submission & Approval Operations
    // -------------------------------------------------------------
    fun submitPayment(
        memberId: Long,
        month: Int,
        year: Int,
        expectedAmount: Double,
        paidAmount: Double,
        paymentDate: Long,
        paymentMethod: String,
        transactionRef: String,
        notes: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val member = repository.getMemberById(memberId)
            val memberName = member?.name ?: "Member #$memberId"
            val gid = _currentGroupId.value

            val payment = Payment(
                groupId = gid,
                memberId = memberId,
                month = month,
                year = year,
                expectedAmount = expectedAmount,
                paidAmount = paidAmount,
                dueAmount = (expectedAmount - paidAmount).coerceAtLeast(0.0),
                paymentDate = paymentDate,
                paymentMethod = paymentMethod,
                transactionReference = transactionRef.trim(),
                notes = notes.trim(),
                status = "PENDING_APPROVAL",
                approvalStatus = "PENDING_APPROVAL",
                submittedAt = System.currentTimeMillis()
            )

            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (isAdmin) {
                repository.recordPayment(payment, groupSettings.value.adminName)
                _userMessage.value = "Payment confirmed & recorded: ₹${CurrencyFormatter.formatIndian(paidAmount)}"
            } else {
                repository.submitPaymentForApproval(payment, memberName)
                _userMessage.value = "Payment submitted for Admin Approval. It will reflect in confirmed totals once verified."
            }
            onSuccess()
        }
    }

    fun recordPayment(
        memberId: Long,
        month: Int,
        year: Int,
        expectedAmount: Double,
        paidAmount: Double,
        paymentDate: Long,
        paymentMethod: String,
        transactionRef: String,
        notes: String,
        onSuccess: () -> Unit
    ) {
        submitPayment(
            memberId = memberId,
            month = month,
            year = year,
            expectedAmount = expectedAmount,
            paidAmount = paidAmount,
            paymentDate = paymentDate,
            paymentMethod = paymentMethod,
            transactionRef = transactionRef,
            notes = notes,
            onSuccess = onSuccess
        )
    }

    fun approvePayment(paymentId: Long, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                requestAdminAction {
                    approvePayment(paymentId, onSuccess)
                }
                return@launch
            }
            val success = repository.approvePayment(paymentId, groupSettings.value.adminName)
            if (success) {
                _userMessage.value = "Payment verified and approved successfully!"
                onSuccess()
            } else {
                _userMessage.value = "Failed to approve payment."
            }
        }
    }

    fun rejectPayment(paymentId: Long, reason: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                requestAdminAction {
                    rejectPayment(paymentId, reason, onSuccess)
                }
                return@launch
            }
            val success = repository.rejectPayment(paymentId, groupSettings.value.adminName, reason)
            if (success) {
                _userMessage.value = "Payment has been rejected."
                onSuccess()
            } else {
                _userMessage.value = "Failed to reject payment."
            }
        }
    }

    fun quickMarkPaid(
        memberId: Long,
        month: Int,
        year: Int,
        amount: Double,
        paymentMethod: String = "Cash",
        reference: String = "",
        notes: String = ""
    ) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                requestAdminAction {
                    quickMarkPaid(memberId, month, year, amount, paymentMethod, reference, notes)
                }
                return@launch
            }
            repository.quickMarkPaid(
                groupId = _currentGroupId.value,
                memberId = memberId,
                month = month,
                year = year,
                amount = amount,
                paymentMethod = paymentMethod,
                adminName = groupSettings.value.adminName
            )
            _userMessage.value = "Marked as Paid: ₹${CurrencyFormatter.formatIndian(amount)}"
        }
    }

    // -------------------------------------------------------------
    // Settings & Configuration
    // -------------------------------------------------------------
    fun updateSettings(settings: GroupSettings, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Admin authentication required"
                return@launch
            }
            repository.updateSettings(settings.copy(id = _currentGroupId.value))
            _userMessage.value = "Settings updated successfully"
            onSuccess()
        }
    }

    fun updateGroupSettings(settings: GroupSettings, onSuccess: () -> Unit = {}) {
        updateSettings(settings, onSuccess)
    }

    // Module Configuration & Management
    fun saveModulesConfig(modules: List<HomeModuleConfig>, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can modify Home modules"
                return@launch
            }
            val json = HomeModuleConfig.serializeModules(modules)
            val current = groupSettings.value
            val updated = current.copy(modulesConfigJson = json)
            repository.updateSettings(updated)
            _userMessage.value = "Home module settings updated"
            onSuccess()
        }
    }

    fun toggleModule(key: String, isEnabled: Boolean) {
        val currentModules = homeModules.value.toMutableList()
        val index = currentModules.indexOfFirst { it.key == key }
        if (index != -1) {
            currentModules[index] = currentModules[index].copy(isEnabled = isEnabled)
            saveModulesConfig(currentModules)
        }
    }

    fun renameModule(key: String, newName: String) {
        val currentModules = homeModules.value.toMutableList()
        val index = currentModules.indexOfFirst { it.key == key }
        if (index != -1) {
            currentModules[index] = currentModules[index].copy(customName = newName.trim())
            saveModulesConfig(currentModules)
        }
    }

    fun moveModule(key: String, direction: Int) {
        val currentModules = homeModules.value.sortedBy { it.orderIndex }.toMutableList()
        val index = currentModules.indexOfFirst { it.key == key }
        if (index == -1) return
        val targetIndex = index + direction
        if (targetIndex in 0 until currentModules.size) {
            val item = currentModules.removeAt(index)
            currentModules.add(targetIndex, item)
            // Re-assign indices
            val reordered = currentModules.mapIndexed { idx, mod -> mod.copy(orderIndex = idx) }
            saveModulesConfig(reordered)
        }
    }

    fun addCustomModule(name: String, description: String, iconName: String, onSuccess: () -> Unit = {}) {
        if (name.isBlank()) {
            _userMessage.value = "Module name cannot be empty"
            return
        }
        val currentModules = homeModules.value.sortedBy { it.orderIndex }.toMutableList()
        val newKey = "custom_" + System.currentTimeMillis()
        val maxOrder = currentModules.maxOfOrNull { it.orderIndex } ?: 0
        val newModule = HomeModuleConfig(
            key = newKey,
            defaultName = name.trim(),
            customName = name.trim(),
            description = description.trim(),
            iconName = iconName.ifBlank { "payments" },
            isEnabled = true,
            orderIndex = maxOrder + 1,
            isCustom = true
        )
        currentModules.add(newModule)
        saveModulesConfig(currentModules) {
            _userMessage.value = "Custom module '$name' added to Home Page"
            onSuccess()
        }
    }

    fun deleteCustomModule(key: String, onSuccess: () -> Unit = {}) {
        val currentModules = homeModules.value.toMutableList()
        val item = currentModules.find { it.key == key }
        if (item != null && item.isCustom) {
            currentModules.removeAll { it.key == key }
            val reindexed = currentModules.mapIndexed { idx, mod -> mod.copy(orderIndex = idx) }
            saveModulesConfig(reindexed) {
                _userMessage.value = "Custom module removed"
                onSuccess()
            }
        }
    }

    fun resetModulesToDefault(onSuccess: () -> Unit = {}) {
        val defaults = HomeModuleConfig.getDefaultModules()
        saveModulesConfig(defaults) {
            _userMessage.value = "Home modules reset to standard order & layout"
            onSuccess()
        }
    }

    fun getModuleDisplayName(key: String, fallback: String): String {
        val mod = homeModules.value.find { it.key == key }
        return mod?.getDisplayName() ?: fallback
    }

    fun resetToDemoData(onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            _userMessage.value = "Data reset to default"
            onSuccess()
        }
    }

    // -------------------------------------------------------------
    // Notices Operations
    // -------------------------------------------------------------
    fun postNotice(title: String, content: String, category: String, author: String, isPinned: Boolean, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            if (title.isBlank() || content.isBlank()) {
                _userMessage.value = "Title and Content are required"
                return@launch
            }
            val notice = SocietyNotice(
                groupId = _currentGroupId.value,
                title = title.trim(),
                content = content.trim(),
                category = category,
                author = if (author.isBlank()) "Admin" else author.trim(),
                isPinned = isPinned
            )
            repository.addNotice(notice)
            _userMessage.value = "Notice published successfully"
            onSuccess()
        }
    }

    fun togglePinNotice(notice: SocietyNotice) {
        viewModelScope.launch {
            repository.updateNotice(notice.copy(isPinned = !notice.isPinned))
            _userMessage.value = if (!notice.isPinned) "Notice pinned to top" else "Notice unpinned"
        }
    }

    fun deleteNotice(notice: SocietyNotice) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can delete notices"
                return@launch
            }
            repository.deleteNotice(notice)
            _userMessage.value = "Notice removed"
        }
    }

    fun broadcastNotice(context: Context, notice: SocietyNotice) {
        val settings = groupSettings.value
        val text = ReminderHelper.generateNoticeBroadcastText(
            groupName = settings.groupName,
            title = notice.title,
            content = notice.content,
            author = notice.author,
            adminPhone = settings.adminPhone
        )
        ReminderHelper.shareText(context, text, "Broadcast Notice")
    }

    // -------------------------------------------------------------
    // Loans & 70% Voting Actions
    // -------------------------------------------------------------
    fun submitLoanRequest(
        requesterMemberId: Long,
        requesterName: String,
        requesterPhone: String,
        amount: Double,
        purpose: String,
        reason: String,
        duration: Int,
        durationUnit: String,
        note: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            if (amount <= 0) {
                _userMessage.value = "Please enter a valid loan amount"
                return@launch
            }
            if (reason.isBlank()) {
                _userMessage.value = "Please specify reason for loan request"
                return@launch
            }
            val durationMillis = if (durationUnit == "Days") duration * 86400000L else duration * 30L * 86400000L
            val loan = LoanRequest(
                groupId = _currentGroupId.value,
                requesterMemberId = requesterMemberId,
                requesterName = requesterName,
                requesterPhone = requesterPhone,
                requestedAmount = amount,
                purpose = purpose,
                reason = reason,
                duration = duration,
                durationUnit = durationUnit,
                expectedRepaymentDate = System.currentTimeMillis() + durationMillis,
                note = note,
                votingDeadline = System.currentTimeMillis() + (48L * 3600000L),
                status = "VOTING",
                remainingAmount = amount
            )
            repository.submitLoanRequest(loan)
            _userMessage.value = "Loan request submitted for group 70% voting approval"
            onSuccess()
        }
    }

    fun castLoanVote(loanId: Long, memberId: Long, memberName: String, vote: String) {
        viewModelScope.launch {
            val success = repository.voteOnLoan(loanId, memberId, memberName, vote)
            if (success) {
                _userMessage.value = "Vote recorded ($vote)"
            } else {
                _userMessage.value = "Unable to record vote (Check voting rules / deadline)"
            }
        }
    }

    fun disburseLoan(loanId: Long, adminName: String) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can disburse loans"
                return@launch
            }
            val success = repository.disburseLoan(loanId, adminName)
            if (success) {
                _userMessage.value = "Loan disbursed successfully. Funds deducted from group cash balance."
            } else {
                _userMessage.value = "Disbursement failed. Ensure loan is approved."
            }
        }
    }

    fun recordLoanRepayment(loanId: Long, amount: Double, paymentMethod: String, notes: String) {
        viewModelScope.launch {
            if (amount <= 0) {
                _userMessage.value = "Please enter a valid repayment amount"
                return@launch
            }
            val success = repository.recordLoanRepayment(loanId, amount, paymentMethod, notes, groupSettings.value.adminName)
            if (success) {
                _userMessage.value = "Loan repayment of ₹${amount.toInt()} recorded. Balance updated."
            } else {
                _userMessage.value = "Failed to record loan repayment"
            }
        }
    }

    // -------------------------------------------------------------
    // Investments Actions (Including Admin Soft Delete with Confirmation)
    // -------------------------------------------------------------
    fun addInvestment(
        type: String,
        institution: String,
        name: String,
        principal: Double,
        currentValue: Double,
        notes: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can record investments"
                return@launch
            }
            if (principal <= 0 || name.isBlank()) {
                _userMessage.value = "Please provide name and valid principal amount"
                return@launch
            }
            val inv = InvestmentRecord(
                groupId = _currentGroupId.value,
                type = type,
                institution = institution.trim(),
                name = name.trim(),
                principalAmount = principal,
                currentValue = if (currentValue > 0) currentValue else principal,
                notes = notes.trim()
            )
            repository.addInvestment(inv)
            _userMessage.value = "Investment recorded: ₹${CurrencyFormatter.formatIndian(principal)}"
            onSuccess()
        }
    }

    fun updateInvestmentValue(investment: InvestmentRecord, newValue: Double) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can update investments"
                return@launch
            }
            repository.updateInvestment(investment.copy(currentValue = newValue))
            _userMessage.value = "Investment valuation updated to ₹${CurrencyFormatter.formatIndian(newValue)}"
        }
    }

    fun deleteInvestment(investmentId: Long, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can delete investments"
                return@launch
            }
            val success = repository.deleteInvestment(investmentId, groupSettings.value.adminName)
            if (success) {
                _userMessage.value = "Investment archived and removed from active portfolio."
                onSuccess()
            } else {
                _userMessage.value = "Failed to delete investment."
            }
        }
    }

    // -------------------------------------------------------------
    // Group Feedback (Suggestions, Proposals, Complaints)
    // -------------------------------------------------------------
    fun submitFeedback(
        type: String,
        memberId: Long,
        memberName: String,
        isAnonymous: Boolean,
        subject: String,
        description: String,
        requiresVoting: Boolean,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            if (subject.isBlank() || description.isBlank()) {
                _userMessage.value = "Subject and Description are required"
                return@launch
            }
            val fb = GroupFeedback(
                groupId = _currentGroupId.value,
                type = type,
                memberId = memberId,
                memberName = if (isAnonymous) "Anonymous Member" else memberName,
                isAnonymous = isAnonymous,
                subject = subject.trim(),
                description = description.trim(),
                requiresVoting = requiresVoting,
                votingThresholdPercent = 70
            )
            repository.submitFeedback(fb)
            _userMessage.value = "$type submitted successfully"
            onSuccess()
        }
    }

    fun voteOnProposal(feedbackId: Long, memberId: Long, memberName: String, vote: String) {
        viewModelScope.launch {
            repository.voteOnProposal(feedbackId, memberId, memberName, vote)
            _userMessage.value = "Proposal vote recorded ($vote)"
        }
    }

    // -------------------------------------------------------------
    // Notifications & Chat Actions
    // -------------------------------------------------------------
    fun markNotificationRead(id: Long) {
        viewModelScope.launch { repository.markNotificationRead(id) }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsRead(_currentGroupId.value)
            _userMessage.value = "All notifications marked as read"
        }
    }

    fun sendChatMessage(senderId: Long, senderName: String, senderRole: String, message: String, isAnnouncement: Boolean) {
        viewModelScope.launch {
            if (message.isBlank()) return@launch
            val chat = GroupChatMessage(
                groupId = _currentGroupId.value,
                senderId = senderId,
                senderName = senderName,
                senderRole = senderRole,
                message = message.trim(),
                isAnnouncement = isAnnouncement
            )
            repository.sendChatMessage(chat)
        }
    }

    // -------------------------------------------------------------
    // Reminders & Communication
    // -------------------------------------------------------------
    fun sendReminder(context: Context, member: Member, dueAmount: Double, month: Int, year: Int) {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(month)
        val text = ReminderHelper.generateReminderText(
            member = member,
            groupName = settings.groupName,
            monthName = monthName,
            year = year,
            dueAmount = dueAmount,
            currencySymbol = settings.currencySymbol,
            adminName = settings.adminName,
            adminPhone = settings.adminPhone
        )
        if (member.phone.isNotBlank()) {
            ReminderHelper.sendWhatsAppReminder(context, member.phone, text)
        } else {
            ReminderHelper.shareText(context, text, "Send Reminder")
        }
    }

    fun sendReminder(context: Context, member: Member, dueAmount: Double, channelOrMonth: String = "WHATSAPP") {
        if (channelOrMonth.equals("WHATSAPP", ignoreCase = true) || channelOrMonth.equals("SMS", ignoreCase = true) || channelOrMonth.equals("SHARE", ignoreCase = true)) {
            val settings = groupSettings.value
            val monthName = DateUtils.getMonthName(_selectedMonth.value)
            val year = _selectedYear.value
            val text = ReminderHelper.generateReminderText(
                member = member,
                groupName = settings.groupName,
                monthName = monthName,
                year = year,
                dueAmount = dueAmount,
                currencySymbol = settings.currencySymbol,
                adminName = settings.adminName,
                adminPhone = settings.adminPhone
            )
            when (channelOrMonth.uppercase()) {
                "WHATSAPP" -> {
                    if (member.phone.isNotBlank()) {
                        ReminderHelper.sendWhatsAppReminder(context, member.phone, text)
                    } else {
                        ReminderHelper.shareText(context, text, "Send Reminder")
                    }
                }
                "SMS" -> {
                    ReminderHelper.sendSmsReminder(context, member.phone, text)
                }
                else -> {
                    ReminderHelper.shareText(context, text, "Send Reminder")
                }
            }
        } else {
            val monthInt = DateUtils.parseMonthName(channelOrMonth)
            sendReminder(context, member, dueAmount, monthInt, _selectedYear.value)
        }
    }

    fun sendReminder(context: Context, member: Member, dueAmount: Double, monthName: String, year: Int) {
        val monthInt = DateUtils.parseMonthName(monthName)
        sendReminder(context, member, dueAmount, monthInt, year)
    }

    fun sendCustomMemberMessage(context: Context, member: Member, message: String) {
        if (member.phone.isNotBlank()) {
            ReminderHelper.sendWhatsAppReminder(context, member.phone, message)
        } else {
            ReminderHelper.shareText(context, message, "Send Message to ${member.name}")
        }
    }

    // -------------------------------------------------------------
    // Report Exporting (PDF / CSV)
    // -------------------------------------------------------------
    fun exportMonthlyReportPdf(context: Context, month: Int = _selectedMonth.value, year: Int = _selectedYear.value) {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(month)
        val list = membersWithMonthlyStatus.value
        val summary = currentMonthSummary.value

        val headers = listOf("Code", "Name", "Expected", "Paid", "Due", "Status")
        val rows = list.map { item ->
            listOf(
                item.member.memberCode,
                item.member.name,
                "₹${item.effectiveExpectedAmount.toInt()}",
                "₹${item.paidAmount.toInt()}",
                "₹${item.dueAmount.toInt()}",
                item.status
            )
        }
        val summaryMap = mapOf(
            "Total Expected" to "₹${summary.totalExpected.toInt()}",
            "Total Collected" to "₹${summary.totalCollected.toInt()}",
            "Total Due" to "₹${summary.totalDue.toInt()}",
            "Collection" to "${summary.collectionPercentage.toInt()}%"
        )

        val file = ReportExporter.generatePdfReport(
            context = context,
            settings = settings,
            reportTitle = "Monthly Collection Report",
            subtitle = "$monthName $year",
            headers = headers,
            rows = rows,
            summaryMap = summaryMap
        )
        if (file != null) {
            ReportExporter.shareFile(context, file, "application/pdf", "Share Monthly Report")
        } else {
            Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportPendingDuesPdf(context: Context, month: Int = _selectedMonth.value, year: Int = _selectedYear.value) {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(month)
        val list = pendingDuesList.value
        val totalDue = list.sumOf { it.dueAmount }

        val headers = listOf("Code", "Name", "Phone", "Expected", "Paid", "Due")
        val rows = list.map { item ->
            listOf(
                item.member.memberCode,
                item.member.name,
                item.member.phone,
                "₹${item.effectiveExpectedAmount.toInt()}",
                "₹${item.paidAmount.toInt()}",
                "₹${item.dueAmount.toInt()}"
            )
        }
        val summaryMap = mapOf(
            "Pending Members" to "${list.size}",
            "Total Outstanding" to "₹${totalDue.toInt()}"
        )

        val file = ReportExporter.generatePdfReport(
            context = context,
            settings = settings,
            reportTitle = "Pending Dues Report",
            subtitle = "$monthName $year",
            headers = headers,
            rows = rows,
            summaryMap = summaryMap
        )
        if (file != null) {
            ReportExporter.shareFile(context, file, "application/pdf", "Share Pending Dues")
        } else {
            Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportMemberLedgerPdf(context: Context, profile: MemberFinancialProfile) {
        val settings = groupSettings.value
        val headers = listOf("Month/Year", "Expected", "Paid", "Due", "Status", "Date")
        val rows = profile.paymentHistory.map { item ->
            listOf(
                "${item.monthName} ${item.year}",
                "₹${item.expectedAmount.toInt()}",
                "₹${item.paidAmount.toInt()}",
                "₹${item.dueAmount.toInt()}",
                item.status,
                if (item.paymentDate != null && item.paymentDate > 0) DateUtils.formatDisplayDate(item.paymentDate) else "-"
            )
        }
        val summaryMap = mapOf(
            "Member" to profile.member.name,
            "Total Paid" to "₹${profile.totalPaidAllTime.toInt()}",
            "Total Due" to "₹${profile.totalDueAllTime.toInt()}"
        )

        val file = ReportExporter.generatePdfReport(
            context = context,
            settings = settings,
            reportTitle = "Member Statement",
            subtitle = "${profile.member.name} (${profile.member.memberCode})",
            headers = headers,
            rows = rows,
            summaryMap = summaryMap
        )
        if (file != null) {
            ReportExporter.shareFile(context, file, "application/pdf", "Share Member Statement")
        } else {
            Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportMemberLedgerPdf(context: Context, memberId: Long) {
        val profile = memberProfile.value ?: return
        exportMemberLedgerPdf(context, profile)
    }

    fun exportMonthlyReportCsv(context: Context, month: Int = _selectedMonth.value, year: Int = _selectedYear.value) {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(month)
        val file = ReportExporter.exportMonthlyCsv(context, settings, monthName, year, membersWithMonthlyStatus.value)
        if (file != null) {
            ReportExporter.shareFile(context, file, "text/csv", "Share Monthly CSV")
        } else {
            Toast.makeText(context, "Failed to export CSV", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportPendingDuesCsv(context: Context, month: Int = _selectedMonth.value, year: Int = _selectedYear.value) {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(month)
        val file = ReportExporter.exportPendingDuesCsv(context, settings, monthName, year, pendingDuesList.value)
        if (file != null) {
            ReportExporter.shareFile(context, file, "text/csv", "Share Pending Dues CSV")
        } else {
            Toast.makeText(context, "Failed to export CSV", Toast.LENGTH_SHORT).show()
        }
    }

    // -------------------------------------------------------------
    // Backup & Restore
    // -------------------------------------------------------------
    fun exportBackupJson(context: Context) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can export system backup"
                return@launch
            }
            try {
                val jsonString = repository.exportDataAsJson(_currentGroupId.value)
                val file = File(context.cacheDir, "GroupLedger_Backup_${_currentGroupId.value}_${System.currentTimeMillis()}.json")
                file.writeText(jsonString)
                ReportExporter.shareFile(context, file, "application/json", "Share Backup File")
            } catch (e: Exception) {
                _userMessage.value = "Backup export failed: ${e.message}"
            }
        }
    }

    fun restoreBackupJson(context: Context, uri: Uri, onSuccess: (Boolean) -> Unit) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can restore system backup"
                return@launch
            }
            try {
                val content = context.contentResolver.openInputStream(uri)?.use { stream ->
                    stream.bufferedReader().readText()
                } ?: ""
                val success = repository.restoreDataFromJson(_currentGroupId.value, content)
                if (success) {
                    _userMessage.value = "Data restored successfully!"
                } else {
                    _userMessage.value = "Failed to restore data. Invalid file format."
                }
                onSuccess(success)
            } catch (e: Exception) {
                _userMessage.value = "Restore error: ${e.message}"
                onSuccess(false)
            }
        }
    }

    fun restoreBackupJson(jsonString: String, onSuccess: (Boolean) -> Unit) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can restore system backup"
                return@launch
            }
            try {
                val success = repository.restoreDataFromJson(_currentGroupId.value, jsonString)
                if (success) {
                    _userMessage.value = "Data restored successfully!"
                } else {
                    _userMessage.value = "Failed to restore data. Invalid file format."
                }
                onSuccess(success)
            } catch (e: Exception) {
                _userMessage.value = "Restore error: ${e.message}"
                onSuccess(false)
            }
        }
    }

    companion object {
        fun provideFactory(application: Application): ViewModelProvider.Factory {
            val database = AppDatabase.getDatabase(application)
            val repository = SocietyRepository(
                userAccountDao = database.userAccountDao(),
                groupMembershipDao = database.groupMembershipDao(),
                memberDao = database.memberDao(),
                paymentDao = database.paymentDao(),
                groupSettingsDao = database.groupSettingsDao(),
                noticeDao = database.noticeDao(),
                loanDao = database.loanDao(),
                investmentDao = database.investmentDao(),
                feedbackDao = database.feedbackDao(),
                notificationDao = database.notificationDao(),
                transactionDao = database.transactionDao(),
                auditLogDao = database.auditLogDao(),
                chatMessageDao = database.chatMessageDao()
            )
            return SocietyViewModelFactory(application, repository)
        }
    }
}

class SocietyViewModelFactory(
    private val application: Application,
    private val repository: SocietyRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SocietyViewModel::class.java)) {
            return SocietyViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
