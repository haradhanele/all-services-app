package com.example.data.model

import org.json.JSONArray
import org.json.JSONObject

/**
 * Model representing a Home Page module / card configuration for a Group.
 * Supports enabling/disabling, custom renaming while keeping internal key stable,
 * custom icons, custom ordering, and admin-added custom modules.
 */
data class HomeModuleConfig(
    val key: String,
    val defaultName: String,
    val customName: String = "",
    val description: String = "",
    val iconName: String = "payments",
    val isEnabled: Boolean = true,
    val orderIndex: Int = 0,
    val isCustom: Boolean = false
) {
    /**
     * Returns custom display name if set by Admin, otherwise the default name.
     */
    fun getDisplayName(): String = if (customName.isNotBlank()) customName else defaultName

    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("key", key)
            put("defaultName", defaultName)
            put("customName", customName)
            put("description", description)
            put("iconName", iconName)
            put("isEnabled", isEnabled)
            put("orderIndex", orderIndex)
            put("isCustom", isCustom)
        }
    }

    companion object {
        fun fromJson(obj: JSONObject): HomeModuleConfig {
            return HomeModuleConfig(
                key = obj.optString("key", "module"),
                defaultName = obj.optString("defaultName", "Module"),
                customName = obj.optString("customName", ""),
                description = obj.optString("description", ""),
                iconName = obj.optString("iconName", "payments"),
                isEnabled = obj.optBoolean("isEnabled", true),
                orderIndex = obj.optInt("orderIndex", 0),
                isCustom = obj.optBoolean("isCustom", false)
            )
        }

        /**
         * Recommended default module set for newly created groups or factory reset.
         */
        fun getDefaultModules(): List<HomeModuleConfig> {
            return listOf(
                // 1. Contribution (Enabled)
                HomeModuleConfig(
                    key = "contribution",
                    defaultName = "Contribution",
                    description = "Collect & Record",
                    iconName = "payments",
                    isEnabled = true,
                    orderIndex = 0
                ),
                // 2. Members (Enabled)
                HomeModuleConfig(
                    key = "members",
                    defaultName = "Members",
                    description = "Directory & Profiles",
                    iconName = "group",
                    isEnabled = true,
                    orderIndex = 1
                ),
                // 3. Expenses (Enabled)
                HomeModuleConfig(
                    key = "expenses",
                    defaultName = "Expenses",
                    description = "Track Outflow",
                    iconName = "receipt_long",
                    isEnabled = true,
                    orderIndex = 2
                ),
                // 4. Income (Enabled)
                HomeModuleConfig(
                    key = "income",
                    defaultName = "Income",
                    description = "Track Inflow",
                    iconName = "account_balance",
                    isEnabled = true,
                    orderIndex = 3
                ),
                // 5. Meetings (Enabled)
                HomeModuleConfig(
                    key = "meeting",
                    defaultName = "Meetings",
                    description = "Society Chat & AGM",
                    iconName = "chat",
                    isEnabled = true,
                    orderIndex = 4
                ),
                // 6. Notice / Announcement (Enabled)
                HomeModuleConfig(
                    key = "notice",
                    defaultName = "Notice",
                    description = "Announcements",
                    iconName = "campaign",
                    isEnabled = true,
                    orderIndex = 5
                ),
                // 7. Suggestions (Enabled)
                HomeModuleConfig(
                    key = "suggestion",
                    defaultName = "Suggestion",
                    description = "Member Ideas",
                    iconName = "lightbulb",
                    isEnabled = true,
                    orderIndex = 6
                ),
                // 8. Complaints (Enabled)
                HomeModuleConfig(
                    key = "complaint",
                    defaultName = "Complaint",
                    description = "Issue Resolution",
                    iconName = "report_problem",
                    isEnabled = true,
                    orderIndex = 7
                ),
                // 9. Help (Enabled)
                HomeModuleConfig(
                    key = "help",
                    defaultName = "Help",
                    description = "Support Desk",
                    iconName = "help",
                    isEnabled = true,
                    orderIndex = 8
                ),
                // 10. Events (Enabled)
                HomeModuleConfig(
                    key = "events",
                    defaultName = "Events",
                    description = "Upcoming Gatherings",
                    iconName = "event",
                    isEnabled = true,
                    orderIndex = 9
                ),
                // 11. Investment (Enabled)
                HomeModuleConfig(
                    key = "investment",
                    defaultName = "Investment",
                    description = "FD & Mutual Funds",
                    iconName = "trending_up",
                    isEnabled = true,
                    orderIndex = 10
                ),
                // 12. Loans (Enabled)
                HomeModuleConfig(
                    key = "loan",
                    defaultName = "Loans",
                    description = "70% Approval Voting",
                    iconName = "handshake",
                    isEnabled = true,
                    orderIndex = 11
                ),
                // 13. Savings (Optional)
                HomeModuleConfig(
                    key = "savings",
                    defaultName = "Savings",
                    description = "Reserve Funds",
                    iconName = "savings",
                    isEnabled = false,
                    orderIndex = 12
                ),
                // 14. Attendance (Optional)
                HomeModuleConfig(
                    key = "attendance",
                    defaultName = "Attendance",
                    description = "Meeting Records",
                    iconName = "check_circle",
                    isEnabled = false,
                    orderIndex = 13
                ),
                // 15. Proposal (Optional)
                HomeModuleConfig(
                    key = "proposal",
                    defaultName = "Proposal",
                    description = "General Voting",
                    iconName = "assignment",
                    isEnabled = false,
                    orderIndex = 14
                ),
                // 16. Reports (Optional)
                HomeModuleConfig(
                    key = "reports",
                    defaultName = "Reports",
                    description = "Audit & Statements",
                    iconName = "pie_chart",
                    isEnabled = false,
                    orderIndex = 15
                )
            )
        }

        fun parseModulesJson(jsonStr: String): List<HomeModuleConfig> {
            if (jsonStr.isBlank()) {
                return getDefaultModules()
            }
            return try {
                val array = JSONArray(jsonStr)
                val list = mutableListOf<HomeModuleConfig>()
                for (i in 0 until array.length()) {
                    list.add(fromJson(array.getJSONObject(i)))
                }

                // Ensure all default keys exist if any missing from older database records
                val existingKeys = list.map { it.key }.toSet()
                val defaults = getDefaultModules()
                var maxOrder = list.maxOfOrNull { it.orderIndex } ?: 0
                for (def in defaults) {
                    if (!existingKeys.contains(def.key)) {
                        maxOrder++
                        list.add(def.copy(orderIndex = maxOrder))
                    }
                }
                list.sortedBy { it.orderIndex }
            } catch (e: Exception) {
                getDefaultModules()
            }
        }

        fun serializeModules(modules: List<HomeModuleConfig>): String {
            val array = JSONArray()
            modules.sortedBy { it.orderIndex }.forEach {
                array.put(it.toJson())
            }
            return array.toString()
        }
    }
}
