package com.adr.groupledger.data.repository

import android.util.Log
import com.adr.groupledger.data.firebase.FirebaseService
import com.adr.groupledger.data.local.AuditLogDao
import com.adr.groupledger.data.local.ChatMessageDao
import com.adr.groupledger.data.local.FeedbackDao
import com.adr.groupledger.data.local.GroupJoinRequestDao
import com.adr.groupledger.data.local.GroupMembershipDao
import com.adr.groupledger.data.local.GroupSettingsDao
import com.adr.groupledger.data.local.InvestmentDao
import com.adr.groupledger.data.local.LoanDao
import com.adr.groupledger.data.local.MemberDao
import com.adr.groupledger.data.local.NoticeDao
import com.adr.groupledger.data.local.NotificationDao
import com.adr.groupledger.data.local.PaymentDao
import com.adr.groupledger.data.local.PreAuthorizedMemberDao
import com.adr.groupledger.data.local.TransactionDao
import com.adr.groupledger.data.local.UserAccountDao
import com.adr.groupledger.data.model.AssetAllocationItem
import com.adr.groupledger.data.model.AuditLog
import com.adr.groupledger.data.model.ChitAuctionResult
import com.adr.groupledger.data.model.ChitAuctionResultStatus
import com.adr.groupledger.data.model.ChitCycle
import com.adr.groupledger.data.model.ChitCycleStatus
import com.adr.groupledger.data.model.ChitFundConfig
import com.adr.groupledger.data.model.CsvImportRecord
import com.adr.groupledger.data.model.CsvImportResult
import com.adr.groupledger.data.model.FeedbackWithVotes
import com.adr.groupledger.data.model.GroupChatMessage
import com.adr.groupledger.data.model.GroupFeedback
import com.adr.groupledger.data.model.GroupJoinRequest
import com.adr.groupledger.data.model.GroupMembership
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.InvestmentRecord
import com.adr.groupledger.data.model.LoanRequest
import com.adr.groupledger.data.model.LoanVote
import com.adr.groupledger.data.model.LoanWithVotingDetails
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.MemberFinancialProfile
import com.adr.groupledger.data.model.MonthlyLedgerItem
import com.adr.groupledger.data.model.MonthlyTrendPoint
import com.adr.groupledger.data.model.NotificationItem
import com.adr.groupledger.data.model.OverallGroupFinancials
import com.adr.groupledger.data.model.Payment
import com.adr.groupledger.data.model.PendingPaymentApprovalItem
import com.adr.groupledger.data.model.PreAuthorizedMember
import com.adr.groupledger.data.model.ProposalVote
import com.adr.groupledger.data.model.RecentTransaction
import com.adr.groupledger.data.model.SocietyNotice
import com.adr.groupledger.data.model.TransactionRecord
import com.adr.groupledger.data.model.UserAccount
import com.adr.groupledger.utils.ChitCalculationEngine
import com.adr.groupledger.utils.DateUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.UUID
import kotlin.math.ceil

sealed class GroupJoinResult {
    data class Success(val group: GroupSettings, val message: String, val isPreApproved: Boolean) : GroupJoinResult()
    data class Pending(val group: GroupSettings, val message: String, val request: GroupJoinRequest) : GroupJoinResult()
    data class AlreadyMember(val group: GroupSettings, val message: String) : GroupJoinResult()
    data class Error(val message: String) : GroupJoinResult()
}

private const val TAG = "SocietyRepository"

class SocietyRepository(
    private val userAccountDao: UserAccountDao,
    private val groupMembershipDao: GroupMembershipDao,
    private val memberDao: MemberDao,
    private val paymentDao: PaymentDao,
    private val groupSettingsDao: GroupSettingsDao,
    private val noticeDao: NoticeDao,
    private val loanDao: LoanDao,
    private val investmentDao: InvestmentDao,
    private val feedbackDao: FeedbackDao,
    private val notificationDao: NotificationDao,
    private val transactionDao: TransactionDao,
    private val auditLogDao: AuditLogDao,
    private val chatMessageDao: ChatMessageDao,
    private val preAuthorizedMemberDao: PreAuthorizedMemberDao,
    private val groupJoinRequestDao: GroupJoinRequestDao,
    val firebaseService: FirebaseService? = null
) {
    // -------------------------------------------------------------
    // User Accounts & Multi-Group Architecture
    // -------------------------------------------------------------
    fun getAllUsersFlow(): Flow<List<UserAccount>> = userAccountDao.getAllUsersFlow()

    fun getUserByIdFlow(userId: Long): Flow<UserAccount?> = userAccountDao.getUserByIdFlow(userId)

    suspend fun getUserById(userId: Long): UserAccount? = withContext(Dispatchers.IO) {
        userAccountDao.getUserById(userId)
    }

    suspend fun getUserByEmail(email: String): UserAccount? = withContext(Dispatchers.IO) {
        userAccountDao.getUserByEmail(email.trim())
    }

    suspend fun getUserByPhone(phone: String): UserAccount? = withContext(Dispatchers.IO) {
        userAccountDao.getUserByPhone(phone.trim())
    }

    suspend fun createUserAccount(user: UserAccount): Long = withContext(Dispatchers.IO) {
        val id = userAccountDao.insertUser(user)
        val created = user.copy(id = id)
        firebaseService?.saveUser(created)
        id
    }

    suspend fun updateUserAccount(user: UserAccount) = withContext(Dispatchers.IO) {
        userAccountDao.updateUser(user)
        firebaseService?.saveUser(user)
    }

    fun getMembershipsForUserFlow(userId: Long): Flow<List<GroupMembership>> =
        groupMembershipDao.getMembershipsForUserFlow(userId)

    suspend fun getMembershipsForUserDirect(userId: Long): List<GroupMembership> = withContext(Dispatchers.IO) {
        groupMembershipDao.getMembershipsForUserDirect(userId)
    }

    fun getMembershipFlow(userId: Long, groupId: Long): Flow<GroupMembership?> =
        groupMembershipDao.getMembershipFlow(userId, groupId)

    suspend fun getMembershipDirect(userId: Long, groupId: Long): GroupMembership? = withContext(Dispatchers.IO) {
        groupMembershipDao.getMembershipDirect(userId, groupId)
    }

    fun getAllGroupsFlow(): Flow<List<GroupSettings>> = groupSettingsDao.getAllGroupsFlow()

    suspend fun getAllGroupsDirect(): List<GroupSettings> = withContext(Dispatchers.IO) {
        groupSettingsDao.getAllGroupsDirect()
    }

    /**
     * Phase 11 — Task 5: Resolves groups owned/created by the user using Firebase Auth UID
     * with fallback to internal numeric userId.
     */
    suspend fun getGroupsForUser(user: UserAccount, authUid: String? = null): List<GroupSettings> = withContext(Dispatchers.IO) {
        val resolvedUid = authUid?.takeIf { it.isNotBlank() }
            ?: firebaseService?.currentFirebaseUser?.uid
            ?: user.id.toString()
        groupSettingsDao.getGroupsByOwner(resolvedUid, user.id)
    }

    fun getGroupSettingsFlow(groupId: Long): Flow<GroupSettings?> = groupSettingsDao.getSettingsFlow(groupId)

    suspend fun getGroupSettings(groupId: Long): GroupSettings? = withContext(Dispatchers.IO) {
        groupSettingsDao.getSettings(groupId)
    }

    suspend fun createGroup(
        groupName: String,
        groupSubtitle: String = "",
        groupType: String = "Self-Help Group",
        description: String = "",
        address: String = "",
        contactPhone: String = "",
        contactEmail: String = "",
        isContributionEnabled: Boolean = true,
        defaultContribution: Double = 500.0,
        currencySymbol: String = "₹",
        contributionFrequency: String = "MONTHLY",
        dueDayOfMonth: Int = 10,
        isLateFeeEnabled: Boolean = false,
        lateFineAmount: Double = 0.0,
        gracePeriodDays: Int = 5,
        paymentRules: String = "Contribution is due by the 10th of every month.",
        modulesConfigJson: String = "",
        inviteCode: String = "",
        adminPin: String = "1234",
        isPinLockEnabled: Boolean = false,
        creatorUser: UserAccount
    ): GroupSettings = withContext(Dispatchers.IO) {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val actualInviteCode = inviteCode.ifBlank { (1..6).map { chars.random() }.joinToString("") }
        val currentAuthUid = firebaseService?.currentFirebaseUser?.uid
            ?.takeIf { it.isNotBlank() } ?: creatorUser.id.toString()
        val newGroup = GroupSettings(
            id = 0,
            groupName = groupName,
            groupSubtitle = groupSubtitle,
            description = description,
            groupType = groupType,
            address = address,
            contactPhone = contactPhone,
            contactEmail = contactEmail,
            inviteCode = actualInviteCode,
            createdByUserId = creatorUser.id,
            ownerUid = currentAuthUid,
            isContributionEnabled = isContributionEnabled,
            defaultContribution = defaultContribution,
            currencySymbol = currencySymbol,
            contributionFrequency = contributionFrequency,
            dueDayOfMonth = dueDayOfMonth,
            isLateFeeEnabled = isLateFeeEnabled,
            lateFineAmount = lateFineAmount,
            gracePeriodDays = gracePeriodDays,
            paymentRules = paymentRules,
            modulesConfigJson = modulesConfigJson,
            financialYearStartMonth = 4,
            adminName = creatorUser.fullName,
            adminPhone = creatorUser.phone,
            adminPin = adminPin,
            isPinLockEnabled = isPinLockEnabled
        )
        val newGroupId = groupSettingsDao.insertOrUpdate(newGroup)
        val created = newGroup.copy(id = newGroupId)

        // Phase 11 — Task 4: Enforce strict sequential ordering
        // Step 1: Write and await parent group settings FIRST before writing any subcollection records
        firebaseService?.saveGroup(created)

        // Automatically add creator as default Admin Member in this group (Requirement 9)
        // Strictly scoped to the newly created group's unique ID (newGroupId)
        val adminMember = Member(
            groupId = newGroupId,
            memberCode = "ADM-01",
            name = creatorUser.fullName.ifBlank { "Group Admin" },
            phone = creatorUser.phone,
            email = creatorUser.email,
            address = "Group Administrator",
            joinDate = System.currentTimeMillis(),
            monthlyContribution = defaultContribution,
            isActive = true,
            isClaimed = true,
            linkedUid = creatorUser.id.toString(),
            notes = "Group Creator & Administrator"
        )
        val adminMemberId = memberDao.insertMember(adminMember)
        val savedAdminMember = adminMember.copy(id = adminMemberId)

        // Step 2: Only after step 1 has committed, write the initial admin member record into Firestore
        firebaseService?.saveMember(savedAdminMember)

        // Add creator as Admin Membership linked to this member
        val membership = GroupMembership(
            userId = creatorUser.id,
            groupId = newGroupId,
            role = "ADMIN",
            memberIdInGroup = adminMemberId
        )
        groupMembershipDao.insertMembership(membership)

        // Seed welcome notice
        noticeDao.insertNotice(
            SocietyNotice(
                groupId = newGroupId,
                title = "🎉 Welcome to $groupName",
                content = "Group created by ${creatorUser.fullName}. Share 6-character invite code $inviteCode with members to join.",
                category = "ANNOUNCEMENT",
                author = creatorUser.fullName,
                isPinned = true
            )
        )

        // Log audit
        auditLogDao.insertAuditLog(
            AuditLog(
                groupId = newGroupId,
                actorName = creatorUser.fullName,
                actorRole = "Admin",
                action = "GROUP_CREATED",
                newValue = groupName,
                relatedRecord = "Invite code: $inviteCode"
            )
        )

        created
    }

    suspend fun updateGroup(group: GroupSettings): Boolean = withContext(Dispatchers.IO) {
        try {
            groupSettingsDao.insertOrUpdate(group)
            firebaseService?.saveGroup(group)
            auditLogDao.insertAuditLog(
                AuditLog(
                    groupId = group.id,
                    actorName = group.adminName,
                    actorRole = "Admin",
                    action = "GROUP_SETTINGS_UPDATED",
                    newValue = group.groupName,
                    relatedRecord = "Updated group profile & settings"
                )
            )
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun regenerateGroupInviteCode(groupId: Long, adminName: String): String = withContext(Dispatchers.IO) {
        val settings = groupSettingsDao.getSettings(groupId) ?: return@withContext ""
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val newCode = (1..6).map { chars.random() }.joinToString("")
        val updated = settings.copy(inviteCode = newCode)
        groupSettingsDao.insertOrUpdate(updated)
        firebaseService?.saveGroup(updated)

        // Log notice and audit log
        noticeDao.insertNotice(
            SocietyNotice(
                groupId = groupId,
                title = "🔑 New Invite Code Generated",
                content = "Admin $adminName generated a new group joining invitation code: $newCode. Share this code with members to join.",
                category = "ANNOUNCEMENT",
                author = adminName,
                isPinned = false
            )
        )

        auditLogDao.insertAuditLog(
            AuditLog(
                groupId = groupId,
                actorName = adminName,
                actorRole = "Admin",
                action = "INVITE_CODE_REGENERATED",
                newValue = newCode,
                relatedRecord = "Old code: ${settings.inviteCode}"
            )
        )

        newCode
    }

    suspend fun deleteGroup(groupId: Long, requesterAuthUid: String = ""): Boolean = withContext(Dispatchers.IO) {
        try {
            val group = groupSettingsDao.getGroupById(groupId)
            val effectiveAuthUid = requesterAuthUid.ifBlank {
                firebaseService?.currentFirebaseUser?.uid ?: group?.ownerUid ?: group?.creatorUid ?: group?.createdByUserId?.toString() ?: ""
            }

            // If effectiveAuthUid is present, verify authorization
            if (group != null && effectiveAuthUid.isNotBlank()) {
                val authCheck = firebaseService?.verifyGroupDeletionAuthorization(group, effectiveAuthUid)
                if (authCheck != null && authCheck.isFailure) {
                    Log.w(TAG, "deleteGroup unauthorized: ${authCheck.exceptionOrNull()?.message}")
                    return@withContext false
                }
            }

            // 1. Delete group and all subcollections completely from Cloud Firestore
            if (effectiveAuthUid.isNotBlank()) {
                val remoteResult = firebaseService?.deleteGroupCompletely(groupId, effectiveAuthUid)
                if (remoteResult != null && remoteResult.isFailure) {
                    Log.w(TAG, "Remote deleteGroupCompletely failed or unauthorized: ${remoteResult.exceptionOrNull()?.message}")
                    // If unauthorized, do not proceed with local deletion
                    if (remoteResult.exceptionOrNull() is SecurityException) {
                        return@withContext false
                    }
                }
            }

            // 2. Cascade delete all associated local records in Room database
            memberDao.deleteMembersForGroup(groupId)
            paymentDao.deletePaymentsForGroup(groupId)
            loanDao.deleteLoansForGroup(groupId)
            investmentDao.deleteInvestmentsForGroup(groupId)
            transactionDao.deleteTransactionsForGroup(groupId)
            feedbackDao.deleteFeedbacksForGroup(groupId)
            chatMessageDao.clearChat(groupId)
            noticeDao.deleteNoticesForGroup(groupId)
            notificationDao.clearAllNotifications(groupId)
            auditLogDao.deleteAuditLogsForGroup(groupId)
            preAuthorizedMemberDao.deleteByGroupId(groupId)
            groupJoinRequestDao.deleteByGroupId(groupId)
            groupMembershipDao.deleteMembershipsForGroup(groupId)
            groupSettingsDao.deleteGroup(groupId)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun getOrResolveGroupByInviteCode(inviteCode: String): GroupSettings? = withContext(Dispatchers.IO) {
        val trimmed = inviteCode.trim().uppercase()
        val local = groupSettingsDao.getGroupByInviteCode(trimmed)
        if (local != null) return@withContext local

        // Fallback: check Firebase Firestore
        val remote = firebaseService?.findGroupByInviteCode(trimmed)
        if (remote != null) {
            groupSettingsDao.insertOrUpdate(remote)
            return@withContext remote
        }
        null
    }

    // -------------------------------------------------------------
    // Hybrid Pre-Authorization & Admin Approval Join Flow
    // -------------------------------------------------------------

    suspend fun joinGroupByInviteCode(inviteCode: String, user: UserAccount): GroupJoinResult = withContext(Dispatchers.IO) {
        val trimmedCode = inviteCode.trim().uppercase()
        if (trimmedCode.length < 4) {
            return@withContext GroupJoinResult.Error("Please enter a valid group invitation code.")
        }

        val group = getOrResolveGroupByInviteCode(trimmedCode)
            ?: return@withContext GroupJoinResult.Error("Invalid invitation code. Please check the code and try again.")

        val existingMembership = groupMembershipDao.getMembershipDirect(user.id, group.id)
        if (existingMembership != null && existingMembership.isActive) {
            return@withContext GroupJoinResult.AlreadyMember(group, "You are already an active member of ${group.groupName}.")
        }

        // 1. Verification Check: Check if logged-in user's email matches pre-authorized list
        val userEmail = user.email.trim().lowercase()
        var preAuthRecord = preAuthorizedMemberDao.getUnclaimedByEmail(group.id, userEmail)
        
        // If not found locally, query Firestore
        if (preAuthRecord == null && firebaseService != null) {
            val remotePreAuthList = firebaseService.getPreAuthorizedMembers(group.id)
            syncFromFirestorePreAuthorized(remotePreAuthList)
            preAuthRecord = remotePreAuthList.firstOrNull { 
                it.email.trim().equals(userEmail, ignoreCase = true) && it.status.equals("unclaimed", ignoreCase = true)
            }
        }

        if (preAuthRecord != null) {
            // SCENARIO A: Pre-authorized Match -> Instant Auto Join
            val existingMembers = memberDao.getAllMembersDirect(group.id)
            val memberCode = "MBR-${existingMembers.size + 1}"
            val memberName = if (preAuthRecord.name.isNotBlank()) preAuthRecord.name else user.fullName
            val memberPhone = if (preAuthRecord.phone.isNotBlank()) preAuthRecord.phone else user.phone
            val newMember = Member(
                groupId = group.id,
                memberCode = memberCode,
                name = memberName,
                phone = memberPhone,
                monthlyContribution = group.defaultContribution,
                joinDate = System.currentTimeMillis(),
                isActive = true
            )
            val newMemberId = memberDao.insertMember(newMember)
            firebaseService?.saveMember(newMember.copy(id = newMemberId))

            val membership = GroupMembership(
                userId = user.id,
                groupId = group.id,
                role = "MEMBER",
                memberIdInGroup = newMemberId
            )
            groupMembershipDao.insertMembership(membership)

            // Update pre-auth entry to claimed
            val claimantUid = firebaseService?.currentFirebaseUser?.uid ?: user.id.toString()
            val updatedPreAuth = preAuthRecord.copy(
                status = "claimed",
                claimedAt = System.currentTimeMillis(),
                claimedUserId = user.id,
                claimedUid = claimantUid
            )
            preAuthorizedMemberDao.insertOrUpdate(updatedPreAuth)
            firebaseService?.claimPreAuthorizedMember(
                groupId = group.id,
                preAuthId = preAuthRecord.id,
                claimantAuthUid = claimantUid,
                claimantUserId = user.id,
                memberToProvision = newMember.copy(id = newMemberId)
            )

            // Audit log & notice
            auditLogDao.insertAuditLog(
                AuditLog(
                    groupId = group.id,
                    actorName = user.fullName,
                    actorRole = "Member",
                    action = "PRE_AUTH_JOINED",
                    newValue = "${user.fullName} ($memberCode)",
                    relatedRecord = "Pre-authorized email match: $userEmail"
                )
            )

            noticeDao.insertNotice(
                SocietyNotice(
                    groupId = group.id,
                    title = "👋 Welcome ${user.fullName}",
                    content = "${user.fullName} has joined the group via pre-authorized invitation.",
                    category = "ANNOUNCEMENT",
                    author = "System",
                    isPinned = false
                )
            )

            return@withContext GroupJoinResult.Success(
                group = group,
                message = "Welcome to ${group.groupName}! You were pre-authorized by the admin and have joined directly.",
                isPreApproved = true
            )
        } else {
            // SCENARIO B: Unknown user / Not pre-authorized -> Create Pending Request for Admin Approval
            val existingPending = groupJoinRequestDao.getUserPendingRequestForGroup(user.id, group.id)
            if (existingPending != null && existingPending.status == "PENDING") {
                return@withContext GroupJoinResult.Pending(
                    group = group,
                    message = "You have already submitted a join request for ${group.groupName}. It is currently waiting for admin approval.",
                    request = existingPending
                )
            }

            val joinRequest = GroupJoinRequest(
                id = 0,
                groupId = group.id,
                groupName = group.groupName,
                userId = user.id,
                name = user.fullName,
                email = userEmail,
                phone = user.phone,
                requestedAt = System.currentTimeMillis(),
                status = "PENDING"
            )
            val reqId = groupJoinRequestDao.insertRequest(joinRequest)
            val savedRequest = joinRequest.copy(id = reqId)
            firebaseService?.saveJoinRequest(savedRequest)

            auditLogDao.insertAuditLog(
                AuditLog(
                    groupId = group.id,
                    actorName = user.fullName,
                    actorRole = "Applicant",
                    action = "JOIN_REQUEST_SUBMITTED",
                    newValue = "${user.fullName} ($userEmail)",
                    relatedRecord = "Awaiting Admin Approval"
                )
            )

            return@withContext GroupJoinResult.Pending(
                group = group,
                message = "Your request to join ${group.groupName} has been submitted! The group admin will review and approve your membership.",
                request = savedRequest
            )
        }
    }

    suspend fun verifyInviteCode(inviteCode: String): GroupSettings? = withContext(Dispatchers.IO) {
        val trimmed = inviteCode.trim().uppercase()
        if (trimmed.length < 3) return@withContext null
        getOrResolveGroupByInviteCode(trimmed)
    }

    suspend fun claimAndJoinGroupByDetails(
        group: GroupSettings,
        user: UserAccount,
        inputName: String,
        inputContact: String,
        authUid: String
    ): GroupJoinResult = withContext(Dispatchers.IO) {
        val cleanName = inputName.trim()
        val cleanContact = inputContact.trim().lowercase()
        val cleanContactDigits = inputContact.filter { it.isDigit() }.takeLast(10)

        if (cleanName.isBlank()) {
            return@withContext GroupJoinResult.Error("Please enter your name.")
        }
        if (cleanContact.isBlank()) {
            return@withContext GroupJoinResult.Error("Please enter your phone number or email ID.")
        }

        // 1. Check if user is already an active member of this group
        val existingMembership = groupMembershipDao.getMembershipDirect(user.id, group.id)
        if (existingMembership != null && existingMembership.isActive) {
            return@withContext GroupJoinResult.AlreadyMember(group, "You are already a member of ${group.groupName}.")
        }

        // 2. Fetch all members and pre-authorized members of this group (local + remote)
        if (firebaseService != null) {
            try {
                val remoteMembers = firebaseService.getMembers(group.id)
                if (remoteMembers.isNotEmpty()) {
                    syncFromFirestoreMembers(remoteMembers)
                }
            } catch (e: Exception) {
                // log or ignore network glitch
            }
            try {
                val remotePreAuth = firebaseService.getPreAuthorizedMembers(group.id)
                if (remotePreAuth.isNotEmpty()) {
                    syncFromFirestorePreAuthorized(remotePreAuth)
                }
            } catch (e: Exception) {
                // log or ignore
            }
        }

        val preAuthList = preAuthorizedMemberDao.getPreAuthorizedMembersDirect(group.id)
        val allMembers = memberDao.getAllMembersDirect(group.id)

        val normInputPhone = inputContact.filter { it.isDigit() }.let { if (it.length >= 10) it.takeLast(10) else it.trimStart('0') }

        fun isPhoneMatch(storedPhone: String): Boolean {
            val normStored = storedPhone.filter { it.isDigit() }.let { if (it.length >= 10) it.takeLast(10) else it.trimStart('0') }
            if (normInputPhone.isBlank() || normStored.isBlank()) return false
            if (normInputPhone == normStored) return true
            if (normInputPhone.length >= 8 && normStored.length >= 8 && (normInputPhone.endsWith(normStored) || normStored.endsWith(normInputPhone))) return true
            return false
        }

        fun isNameMatch(storedName: String): Boolean {
            val cStored = storedName.trim().lowercase().replace(Regex("\\s+"), " ")
            val cInput = cleanName.lowercase().replace(Regex("\\s+"), " ")
            if (cStored.isBlank() || cInput.isBlank()) return false
            if (cStored == cInput) return true
            if (cStored.length >= 3 && cInput.length >= 3 && (cStored.contains(cInput) || cInput.contains(cStored))) return true
            return false
        }

        // Matching strategy against pre-added / pre-authorized members:
        var matchedPreAuth: PreAuthorizedMember? = null
        for (p in preAuthList) {
            val pEmail = p.email.trim().lowercase()
            val pName = p.name.trim()

            val nameMatches = isNameMatch(pName)
            val emailMatches = cleanContact.isNotBlank() && pEmail.isNotBlank() && cleanContact == pEmail
            val phoneMatches = isPhoneMatch(p.phone)

            val isMatch = (nameMatches && (emailMatches || phoneMatches)) ||
                    (nameMatches && pEmail.isBlank() && p.phone.isBlank()) ||
                    ((emailMatches || phoneMatches) && (nameMatches || pName.isBlank()))

            if (isMatch) {
                matchedPreAuth = p
                break
            }
        }

        var matchedMember: Member? = null
        if (matchedPreAuth == null) {
            for (m in allMembers) {
                if (m.isClaimed && m.linkedUid.isNotBlank() && m.linkedUid != authUid) continue
                val mEmail = m.email.trim().lowercase()
                val mName = m.name.trim()

                val nameMatches = isNameMatch(mName)
                val emailMatches = cleanContact.isNotBlank() && mEmail.isNotBlank() && cleanContact == mEmail
                val phoneMatches = isPhoneMatch(m.phone)

                val isMatch = (nameMatches && (emailMatches || phoneMatches)) ||
                        (nameMatches && mEmail.isBlank() && m.phone.isBlank()) ||
                        ((emailMatches || phoneMatches) && (nameMatches || mName.isBlank()))

                if (isMatch) {
                    matchedMember = m
                    break
                }
            }
        }

        if (matchedPreAuth == null && matchedMember == null) {
            return@withContext GroupJoinResult.Error("No pre-authorized member found with these details in this group.")
        }

        // Found match! Claim member profile and link UID
        val memberId: Long
        val finalMemberName = matchedPreAuth?.name?.ifBlank { cleanName } ?: matchedMember?.name ?: cleanName

        if (matchedMember != null) {
            memberId = matchedMember.id
            val updatedMember = matchedMember.copy(
                isClaimed = true,
                linkedUid = authUid,
                name = cleanName.ifBlank { matchedMember.name },
                email = if (cleanContact.contains("@")) cleanContact else matchedMember.email,
                phone = if (!cleanContact.contains("@")) inputContact.trim() else matchedMember.phone
            )
            memberDao.updateMember(updatedMember)
            firebaseService?.saveMember(updatedMember)
        } else {
            val existingInGroup = memberDao.getAllMembersDirect(group.id)
            val newMember = Member(
                groupId = group.id,
                memberCode = "MBR-${existingInGroup.size + 1}",
                name = finalMemberName,
                email = if (cleanContact.contains("@")) cleanContact else (matchedPreAuth?.email ?: ""),
                phone = if (!cleanContact.contains("@")) inputContact.trim() else (matchedPreAuth?.phone ?: ""),
                monthlyContribution = group.defaultContribution,
                joinDate = System.currentTimeMillis(),
                isActive = true,
                isClaimed = true,
                linkedUid = authUid
            )
            memberId = memberDao.insertMember(newMember)
            firebaseService?.saveMember(newMember.copy(id = memberId))
        }

        if (matchedPreAuth != null) {
            val claimantUid = authUid.ifBlank { firebaseService?.currentFirebaseUser?.uid ?: user.id.toString() }
            val updatedPreAuth = matchedPreAuth.copy(
                status = "claimed",
                claimedAt = System.currentTimeMillis(),
                claimedUserId = user.id,
                claimedUid = claimantUid
            )
            preAuthorizedMemberDao.insertOrUpdate(updatedPreAuth)
            firebaseService?.claimPreAuthorizedMember(
                groupId = group.id,
                preAuthId = matchedPreAuth.id,
                claimantAuthUid = claimantUid,
                claimantUserId = user.id
            )
        }

        // Create membership
        val membership = GroupMembership(
            userId = user.id,
            groupId = group.id,
            role = "MEMBER",
            memberIdInGroup = memberId,
            isActive = true
        )
        groupMembershipDao.insertMembership(membership)

        // Audit Log
        auditLogDao.insertAuditLog(
            AuditLog(
                groupId = group.id,
                actorName = cleanName,
                actorRole = "Member",
                action = "INVITE_CODE_CLAIMED",
                newValue = "$cleanName claimed profile in ${group.groupName}",
                relatedRecord = "Contact: $inputContact"
            )
        )

        // Notice
        noticeDao.insertNotice(
            SocietyNotice(
                groupId = group.id,
                title = "👋 Welcome $cleanName",
                content = "$cleanName has successfully claimed their member profile and joined ${group.groupName}.",
                category = "ANNOUNCEMENT",
                author = "System",
                isPinned = false
            )
        )

        GroupJoinResult.Success(
            group = group,
            message = "Welcome to ${group.groupName}! You have successfully claimed your member profile.",
            isPreApproved = true
        )
    }

    suspend fun matchAndClaimOfflineMembers(
        user: UserAccount,
        authUid: String,
        targetGroupId: Long? = null
    ): List<GroupSettings> = withContext(Dispatchers.IO) {
        val claimedGroups = mutableListOf<GroupSettings>()
        val cleanName = user.fullName.trim()
        val cleanEmail = user.email.trim().lowercase()
        val cleanPhoneDigits = user.phone.filter { it.isDigit() }.takeLast(10)

        // 1. Check Cloud Firestore ONLY if a specific verified target group is provided
        if (firebaseService != null && targetGroupId != null) {
            val remoteMatches = firebaseService.autoMatchAndClaimUnclaimedMembers(
                userId = user.id,
                authUid = authUid,
                userName = cleanName,
                userEmail = cleanEmail,
                userPhone = user.phone,
                targetGroupId = targetGroupId
            )
            for (match in remoteMatches) {
                val group = groupSettingsDao.getSettings(match.groupId) ?: continue
                if (!claimedGroups.any { it.id == group.id }) {
                    claimedGroups.add(group)
                }
                val existing = groupMembershipDao.getMembershipDirect(user.id, group.id)
                if (existing == null) {
                    groupMembershipDao.insertMembership(
                        GroupMembership(
                            userId = user.id,
                            groupId = group.id,
                            role = "MEMBER",
                            memberIdInGroup = match.memberId,
                            isActive = true
                        )
                    )
                }
            }
        }

        // 2. Check local unclaimed members in Room (scoped to device local storage)
        val allLocalUnclaimed = memberDao.getUnclaimedMembersDirect()
        val localUnclaimed = if (targetGroupId != null) {
            allLocalUnclaimed.filter { it.groupId == targetGroupId }
        } else {
            allLocalUnclaimed
        }
        for (m in localUnclaimed) {
            val mPhoneDigits = m.phone.filter { it.isDigit() }.takeLast(10)
            val isMatch = (cleanEmail.isNotBlank() && cleanEmail == m.email.trim().lowercase()) ||
                    (cleanPhoneDigits.length >= 10 && cleanPhoneDigits == mPhoneDigits) ||
                    (cleanName.isNotBlank() && cleanName.equals(m.name.trim(), ignoreCase = true))

            if (isMatch) {
                val updated = m.copy(
                    isClaimed = true,
                    linkedUid = authUid,
                    email = if (m.email.isBlank()) user.email else m.email,
                    phone = if (m.phone.isBlank()) user.phone else m.phone
                )
                memberDao.updateMember(updated)
                firebaseService?.saveMember(updated)

                val group = groupSettingsDao.getSettings(m.groupId)
                if (group != null && !claimedGroups.any { it.id == group.id }) {
                    claimedGroups.add(group)
                }

                val existing = groupMembershipDao.getMembershipDirect(user.id, m.groupId)
                if (existing == null) {
                    groupMembershipDao.insertMembership(
                        GroupMembership(
                            userId = user.id,
                            groupId = m.groupId,
                            role = "MEMBER",
                            memberIdInGroup = m.id,
                            isActive = true
                        )
                    )
                }
            }
        }

        // 3. Check local preAuthorizedMemberDao
        val allGroups = groupSettingsDao.getAllGroupsDirect()
        for (g in allGroups) {
            val preAuthList = preAuthorizedMemberDao.getPreAuthorizedMembersDirect(g.id)
            for (p in preAuthList) {
                if (p.status.equals("claimed", ignoreCase = true)) continue
                val pPhoneDigits = p.phone.filter { it.isDigit() }.takeLast(10)
                val isMatch = (cleanEmail.isNotBlank() && cleanEmail == p.email.trim().lowercase()) ||
                        (cleanPhoneDigits.length >= 10 && cleanPhoneDigits == pPhoneDigits) ||
                        (cleanName.isNotBlank() && cleanName.equals(p.name.trim(), ignoreCase = true))

                if (isMatch) {
                    val updatedP = p.copy(
                        status = "claimed",
                        claimedAt = System.currentTimeMillis(),
                        claimedUserId = user.id
                    )
                    preAuthorizedMemberDao.insertOrUpdate(updatedP)
                    firebaseService?.savePreAuthorizedMember(updatedP)

                    val existingMembers = memberDao.getAllMembersDirect(g.id)
                    val member = existingMembers.firstOrNull { it.phone == p.phone || it.email == p.email || it.name.equals(p.name, ignoreCase = true) }
                    val memberId = if (member != null) {
                        val upMem = member.copy(isClaimed = true, linkedUid = authUid)
                        memberDao.updateMember(upMem)
                        firebaseService?.saveMember(upMem)
                        member.id
                    } else {
                        val newM = Member(
                            groupId = g.id,
                            memberCode = "MBR-${existingMembers.size + 1}",
                            name = p.name.ifBlank { user.fullName },
                            email = p.email.ifBlank { user.email },
                            phone = p.phone.ifBlank { user.phone },
                            monthlyContribution = g.defaultContribution,
                            isClaimed = true,
                            linkedUid = authUid,
                            isActive = true
                        )
                        val nId = memberDao.insertMember(newM)
                        firebaseService?.saveMember(newM.copy(id = nId))
                        nId
                    }

                    if (!claimedGroups.any { it.id == g.id }) {
                        claimedGroups.add(g)
                    }

                    val existing = groupMembershipDao.getMembershipDirect(user.id, g.id)
                    if (existing == null) {
                        groupMembershipDao.insertMembership(
                            GroupMembership(
                                userId = user.id,
                                groupId = g.id,
                                role = "MEMBER",
                                memberIdInGroup = memberId,
                                isActive = true
                            )
                        )
                    }
                }
            }
        }

        claimedGroups
    }

    // -------------------------------------------------------------
    // Pre-Authorized Members Management (Admin Side)
    // -------------------------------------------------------------

    fun getPreAuthorizedMembersFlow(groupId: Long): Flow<List<PreAuthorizedMember>> =
        preAuthorizedMemberDao.getPreAuthorizedMembersFlow(groupId)

    suspend fun getPreAuthorizedMembersDirect(groupId: Long): List<PreAuthorizedMember> = withContext(Dispatchers.IO) {
        preAuthorizedMemberDao.getPreAuthorizedMembersDirect(groupId)
    }

    suspend fun addPreAuthorizedMember(
        groupId: Long,
        name: String,
        email: String,
        phone: String = "",
        adminName: String = "Admin"
    ): Result<PreAuthorizedMember> = withContext(Dispatchers.IO) {
        val trimmedEmail = email.trim().lowercase()
        val trimmedName = name.trim()

        if (trimmedName.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Member name cannot be empty."))
        }
        if (trimmedEmail.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(trimmedEmail).matches()) {
            return@withContext Result.failure(IllegalArgumentException("Please enter a valid email address."))
        }

        val preAuth = PreAuthorizedMember(
            id = 0,
            groupId = groupId,
            name = trimmedName,
            email = trimmedEmail,
            phone = phone.trim(),
            status = "unclaimed",
            addedAt = System.currentTimeMillis()
        )
        val id = preAuthorizedMemberDao.insertOrUpdate(preAuth)
        val created = preAuth.copy(id = id)
        firebaseService?.savePreAuthorizedMember(created)

        auditLogDao.insertAuditLog(
            AuditLog(
                groupId = groupId,
                actorName = adminName,
                actorRole = "Admin",
                action = "PRE_AUTH_MEMBER_ADDED",
                newValue = "$trimmedName ($trimmedEmail)",
                relatedRecord = "Pre-authorization created"
            )
        )

        Result.success(created)
    }

    suspend fun deletePreAuthorizedMember(groupId: Long, memberId: Long, adminName: String = "Admin"): Boolean = withContext(Dispatchers.IO) {
        try {
            preAuthorizedMemberDao.deleteById(memberId)
            firebaseService?.deletePreAuthorizedMember(groupId, memberId)
            auditLogDao.insertAuditLog(
                AuditLog(
                    groupId = groupId,
                    actorName = adminName,
                    actorRole = "Admin",
                    action = "PRE_AUTH_MEMBER_REMOVED",
                    newValue = "ID: $memberId",
                    relatedRecord = "Pre-authorization deleted"
                )
            )
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    // -------------------------------------------------------------
    // Join Requests & Admin Approval Management
    // -------------------------------------------------------------

    fun getPendingJoinRequestsFlow(groupId: Long): Flow<List<GroupJoinRequest>> =
        groupJoinRequestDao.getPendingRequestsFlow(groupId)

    fun getAllJoinRequestsFlow(groupId: Long): Flow<List<GroupJoinRequest>> =
        groupJoinRequestDao.getAllRequestsFlow(groupId)

    fun getUserJoinRequestsFlow(userId: Long): Flow<List<GroupJoinRequest>> =
        groupJoinRequestDao.getUserRequestsFlow(userId)

    fun getUserPendingRequestsFlow(userId: Long): Flow<List<GroupJoinRequest>> =
        groupJoinRequestDao.getUserRequestsFlow(userId)

    suspend fun approveJoinRequest(requestId: Long, adminName: String = "Admin"): Boolean = withContext(Dispatchers.IO) {
        try {
            val req = groupJoinRequestDao.getRequestById(requestId) ?: return@withContext false
            val group = groupSettingsDao.getSettings(req.groupId) ?: return@withContext false

            val existing = groupMembershipDao.getMembershipDirect(req.userId, req.groupId)
            if (existing != null && existing.isActive) {
                val updatedReq = req.copy(
                    status = "APPROVED",
                    processedAt = System.currentTimeMillis(),
                    processedBy = adminName
                )
                groupJoinRequestDao.insertRequest(updatedReq)
                firebaseService?.saveJoinRequest(updatedReq)
                return@withContext true
            }

            val members = memberDao.getAllMembersDirect(req.groupId)
            val memberCode = "MBR-${members.size + 1}"
            val newMember = Member(
                groupId = req.groupId,
                memberCode = memberCode,
                name = req.name,
                phone = req.phone,
                monthlyContribution = group.defaultContribution,
                joinDate = System.currentTimeMillis(),
                isActive = true
            )
            val memberId = memberDao.insertMember(newMember)
            val savedMember = newMember.copy(id = memberId)
            firebaseService?.saveMember(savedMember)

            val membership = GroupMembership(
                userId = req.userId,
                groupId = req.groupId,
                role = "MEMBER",
                memberIdInGroup = memberId
            )
            groupMembershipDao.insertMembership(membership)

            val approvedReq = req.copy(
                status = "APPROVED",
                processedAt = System.currentTimeMillis(),
                processedBy = adminName
            )
            groupJoinRequestDao.insertRequest(approvedReq)
            firebaseService?.saveJoinRequest(approvedReq)

            auditLogDao.insertAuditLog(
                AuditLog(
                    groupId = req.groupId,
                    actorName = adminName,
                    actorRole = "Admin",
                    action = "JOIN_REQUEST_APPROVED",
                    newValue = "${req.name} (${req.email})",
                    relatedRecord = "Approved by Admin"
                )
            )

            noticeDao.insertNotice(
                SocietyNotice(
                    groupId = req.groupId,
                    title = "🎉 New Member Approved: ${req.name}",
                    content = "${req.name} has been approved by $adminName and is now a member of the group.",
                    category = "ANNOUNCEMENT",
                    author = adminName,
                    isPinned = false
                )
            )

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun rejectJoinRequest(requestId: Long, adminName: String = "Admin", reason: String = ""): Boolean = withContext(Dispatchers.IO) {
        try {
            val req = groupJoinRequestDao.getRequestById(requestId) ?: return@withContext false
            val rejectedReq = req.copy(
                status = "REJECTED",
                processedAt = System.currentTimeMillis(),
                processedBy = adminName
            )
            groupJoinRequestDao.insertRequest(rejectedReq)
            firebaseService?.saveJoinRequest(rejectedReq)

            auditLogDao.insertAuditLog(
                AuditLog(
                    groupId = req.groupId,
                    actorName = adminName,
                    actorRole = "Admin",
                    action = "JOIN_REQUEST_REJECTED",
                    newValue = "${req.name} (${req.email})",
                    relatedRecord = if (reason.isNotBlank()) "Reason: $reason" else "Rejected by Admin"
                )
            )

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun approveJoinRequest(request: GroupJoinRequest, adminUser: UserAccount): Result<Member> = withContext(Dispatchers.IO) {
        try {
            val group = groupSettingsDao.getSettings(request.groupId)
                ?: return@withContext Result.failure(IllegalStateException("Group not found."))

            // Check if already a member
            val existing = groupMembershipDao.getMembershipDirect(request.userId, request.groupId)
            if (existing != null && existing.isActive) {
                val updatedReq = request.copy(
                    status = "APPROVED",
                    processedAt = System.currentTimeMillis(),
                    processedBy = adminUser.fullName
                )
                groupJoinRequestDao.insertRequest(updatedReq)
                firebaseService?.saveJoinRequest(updatedReq)
                return@withContext Result.failure(IllegalStateException("User is already a member."))
            }

            // Create Member profile
            val members = memberDao.getAllMembersDirect(request.groupId)
            val memberCode = "MBR-${members.size + 1}"
            val newMember = Member(
                groupId = request.groupId,
                memberCode = memberCode,
                name = request.name,
                phone = request.phone,
                monthlyContribution = group.defaultContribution,
                joinDate = System.currentTimeMillis(),
                isActive = true
            )
            val memberId = memberDao.insertMember(newMember)
            val savedMember = newMember.copy(id = memberId)
            firebaseService?.saveMember(savedMember)

            // Create Membership
            val membership = GroupMembership(
                userId = request.userId,
                groupId = request.groupId,
                role = "MEMBER",
                memberIdInGroup = memberId
            )
            groupMembershipDao.insertMembership(membership)

            // Update Join Request
            val approvedReq = request.copy(
                status = "APPROVED",
                processedAt = System.currentTimeMillis(),
                processedBy = adminUser.fullName
            )
            groupJoinRequestDao.insertRequest(approvedReq)
            firebaseService?.saveJoinRequest(approvedReq)

            // Audit Log & Notice
            auditLogDao.insertAuditLog(
                AuditLog(
                    groupId = request.groupId,
                    actorName = adminUser.fullName,
                    actorRole = "Admin",
                    action = "JOIN_REQUEST_APPROVED",
                    newValue = "${request.name} (${request.email})",
                    relatedRecord = "Approved by Admin"
                )
            )

            noticeDao.insertNotice(
                SocietyNotice(
                    groupId = request.groupId,
                    title = "🎉 New Member Approved: ${request.name}",
                    content = "${request.name} has been approved by ${adminUser.fullName} and is now a member of the group.",
                    category = "ANNOUNCEMENT",
                    author = adminUser.fullName,
                    isPinned = false
                )
            )

            Result.success(savedMember)
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure(e)
        }
    }

    suspend fun rejectJoinRequest(request: GroupJoinRequest, adminUser: UserAccount, reason: String = ""): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val rejectedReq = request.copy(
                status = "REJECTED",
                processedAt = System.currentTimeMillis(),
                processedBy = adminUser.fullName
            )
            groupJoinRequestDao.insertRequest(rejectedReq)
            firebaseService?.saveJoinRequest(rejectedReq)

            auditLogDao.insertAuditLog(
                AuditLog(
                    groupId = request.groupId,
                    actorName = adminUser.fullName,
                    actorRole = "Admin",
                    action = "JOIN_REQUEST_REJECTED",
                    newValue = "${request.name} (${request.email})",
                    relatedRecord = if (reason.isNotBlank()) "Reason: $reason" else "Rejected by Admin"
                )
            )

            Result.success(Unit)
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure(e)
        }
    }

    // -------------------------------------------------------------
    // Scoped Data Streams by Group ID
    // -------------------------------------------------------------
    fun getAllMembers(groupId: Long): Flow<List<Member>> = memberDao.getAllMembers(groupId)
    suspend fun getAllMembersDirect(groupId: Long): List<Member> = withContext(Dispatchers.IO) { memberDao.getAllMembersDirect(groupId) }
    fun getActiveMembers(groupId: Long): Flow<List<Member>> = memberDao.getActiveMembers(groupId)
    fun getAllPayments(groupId: Long): Flow<List<Payment>> = paymentDao.getAllPayments(groupId)
    suspend fun getAllPaymentsDirect(groupId: Long): List<Payment> = withContext(Dispatchers.IO) { paymentDao.getAllPaymentsDirect(groupId) }
    fun getNotices(groupId: Long): Flow<List<SocietyNotice>> = noticeDao.getAllNotices(groupId)
    fun getAllLoans(groupId: Long): Flow<List<LoanRequest>> = loanDao.getAllLoansFlow(groupId)
    fun getAllInvestments(groupId: Long): Flow<List<InvestmentRecord>> = investmentDao.getAllInvestmentsFlow(groupId)
    fun getAllFeedbacks(groupId: Long): Flow<List<GroupFeedback>> = feedbackDao.getAllFeedbacksFlow(groupId)
    fun getAllNotifications(groupId: Long): Flow<List<NotificationItem>> = notificationDao.getAllNotificationsFlow(groupId)
    fun getUnreadNotificationsCount(groupId: Long): Flow<Int> = notificationDao.getUnreadCountFlow(groupId)
    fun getAllTransactions(groupId: Long): Flow<List<TransactionRecord>> = transactionDao.getAllTransactionsFlow(groupId)
    fun getChatMessages(groupId: Long): Flow<List<GroupChatMessage>> = chatMessageDao.getAllMessagesFlow(groupId)
    fun getAuditLogs(groupId: Long): Flow<List<AuditLog>> = auditLogDao.getAllAuditLogsFlow(groupId)

    fun getPendingPaymentApprovals(groupId: Long): Flow<List<PendingPaymentApprovalItem>> = combine(
        paymentDao.getPendingApprovalPayments(groupId),
        memberDao.getAllMembers(groupId)
    ) { pendingPayments, members ->
        val membersMap = members.associateBy { it.id }
        pendingPayments.map { payment ->
            val member = membersMap[payment.memberId] ?: Member(
                id = payment.memberId,
                groupId = groupId,
                name = "Member #${payment.memberId}",
                memberCode = "M-${payment.memberId}"
            )
            PendingPaymentApprovalItem(
                payment = payment,
                member = member
            )
        }
    }.flowOn(Dispatchers.IO)

    private fun generateTxnNumber(): String {
        val year = Calendar.getInstance().get(Calendar.YEAR)
        val rand = (1000..9999).random()
        return "TXN-$year-$rand"
    }

    private suspend fun logAudit(
        groupId: Long,
        actorName: String = "Admin",
        actorRole: String = "Admin",
        action: String,
        prev: String = "",
        newVal: String = "",
        record: String = ""
    ) {
        auditLogDao.insertAuditLog(
            AuditLog(
                groupId = groupId,
                actorName = actorName,
                actorRole = actorRole,
                action = action,
                previousValue = prev,
                newValue = newVal,
                relatedRecord = record
            )
        )
    }

    // -------------------------------------------------------------
    // Member Operations
    // -------------------------------------------------------------
    suspend fun getMemberById(id: Long): Member? = withContext(Dispatchers.IO) {
        memberDao.getMemberById(id)
    }

    fun getMemberByIdFlow(id: Long): Flow<Member?> = memberDao.getMemberByIdFlow(id)

    suspend fun insertMember(member: Member): Long = withContext(Dispatchers.IO) {
        val id = memberDao.insertMember(member)
        val created = member.copy(id = id)
        firebaseService?.saveMember(created)
        logAudit(
            groupId = member.groupId,
            action = "MEMBER_ADDED",
            newVal = "${member.name} (${member.memberCode})",
            record = "Member ID: $id"
        )
        id
    }

    suspend fun updateMember(member: Member) = withContext(Dispatchers.IO) {
        memberDao.updateMember(member)
        firebaseService?.saveMember(member)
        logAudit(
            groupId = member.groupId,
            action = "MEMBER_UPDATED",
            newVal = member.name,
            record = "Member ID: ${member.id}"
        )
    }

    suspend fun deleteMember(member: Member) = withContext(Dispatchers.IO) {
        memberDao.deleteMember(member)
        paymentDao.deletePaymentsByMemberId(member.id)
        // Clean up group membership and pending join requests for this member
        if (member.linkedUid.isNotBlank()) {
            val user = if (member.email.isNotBlank()) userAccountDao.getUserByEmail(member.email) else null
            if (user != null) {
                groupMembershipDao.deleteMembershipForUserAndGroup(user.id, member.groupId)
                groupJoinRequestDao.deleteByGroupAndUser(member.groupId, user.id)
            }
        }
        firebaseService?.deleteMember(member.groupId, member.id, member.linkedUid)
        logAudit(
            groupId = member.groupId,
            action = "MEMBER_DELETED",
            prev = member.name,
            record = "Member ID: ${member.id}"
        )
    }

    /**
     * Phase 11 — Task 7: Voluntary member departure from a group.
     */
    suspend fun leaveGroup(groupId: Long, userId: Long, authUid: String = ""): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val effectiveAuthUid = authUid.ifBlank {
                firebaseService?.currentFirebaseUser?.uid ?: userId.toString()
            }
            val members = memberDao.getMembersForGroupSync(groupId)
            val user = userAccountDao.getUserById(userId)
            val matchingMember = members.find { it.linkedUid.isNotBlank() && it.linkedUid == effectiveAuthUid }
                ?: members.find { it.email.isNotBlank() && user?.email?.isNotBlank() == true && it.email.equals(user.email, ignoreCase = true) }

            if (matchingMember != null) {
                deleteMember(matchingMember)
            } else {
                groupMembershipDao.deleteMembershipForUserAndGroup(userId, groupId)
                groupJoinRequestDao.deleteByGroupAndUser(groupId, userId)
                firebaseService?.removeMemberFromGroup(groupId, 0L, effectiveAuthUid)
            }
            Result.success(true)
        } catch (e: Exception) {
            Log.e(TAG, "Error leaving group $groupId for user $userId: ${e.message}", e)
            Result.failure(e)
        }
    }

    // -------------------------------------------------------------
    // Payment & Approval Workflow Operations
    // -------------------------------------------------------------
    suspend fun submitPaymentForApproval(payment: Payment, memberName: String): Long = withContext(Dispatchers.IO) {
        val pendingPayment = payment.copy(
            approvalStatus = "PENDING_APPROVAL",
            status = "PENDING_APPROVAL",
            submittedAt = System.currentTimeMillis()
        )
        val existing = paymentDao.getPayment(payment.memberId, payment.month, payment.year)
        val id = if (existing != null) {
            val updated = pendingPayment.copy(id = existing.id, groupId = payment.groupId)
            paymentDao.updatePayment(updated)
            firebaseService?.savePayment(updated)
            existing.id
        } else {
            val newId = paymentDao.insertPayment(pendingPayment)
            firebaseService?.savePayment(pendingPayment.copy(id = newId))
            newId
        }

        notificationDao.insertNotification(
            NotificationItem(
                groupId = payment.groupId,
                title = "Payment Approval Request",
                message = "$memberName submitted payment of ₹${payment.paidAmount.toInt()} for ${DateUtils.getMonthName(payment.month)} ${payment.year}. Tap to review.",
                type = "PAYMENT_APPROVAL",
                relatedId = id,
                actionRoute = "monthly"
            )
        )

        logAudit(
            groupId = payment.groupId,
            actorName = memberName,
            actorRole = "Member",
            action = "PAYMENT_SUBMITTED_FOR_APPROVAL",
            newVal = "₹${payment.paidAmount.toInt()} (${payment.paymentMethod})",
            record = "$memberName - ${DateUtils.getMonthName(payment.month)} ${payment.year}"
        )
        id
    }

    suspend fun approvePayment(paymentId: Long, adminName: String): Boolean = withContext(Dispatchers.IO) {
        val payment = paymentDao.getPaymentById(paymentId) ?: return@withContext false
        val member = memberDao.getMemberById(payment.memberId)
        val memberName = member?.name ?: "Member #${payment.memberId}"

        val calculatedStatus = Payment.calculateStatus(payment.expectedAmount, payment.paidAmount)
        val calculatedDue = (payment.expectedAmount - payment.paidAmount).coerceAtLeast(0.0)

        val approvedPayment = payment.copy(
            approvalStatus = "APPROVED",
            status = calculatedStatus,
            dueAmount = calculatedDue,
            approvedAt = System.currentTimeMillis(),
            approvedBy = adminName,
            rejectionReason = ""
        )
        paymentDao.updatePayment(approvedPayment)
        firebaseService?.savePayment(approvedPayment)

        if (payment.paidAmount > 0) {
            val tx = TransactionRecord(
                groupId = payment.groupId,
                txnNumber = generateTxnNumber(),
                date = approvedPayment.paymentDate,
                amount = approvedPayment.paidAmount,
                type = "CONTRIBUTION",
                isCredit = true,
                description = "Monthly contribution for ${DateUtils.getMonthName(payment.month)} ${payment.year} from $memberName (Approved by $adminName)",
                paymentMethod = payment.paymentMethod,
                relatedMemberId = payment.memberId,
                relatedMemberName = memberName,
                createdBy = adminName
            )
            val txId = transactionDao.insertTransaction(tx)
            firebaseService?.saveTransaction(tx.copy(id = txId))
        }

        notificationDao.insertNotification(
            NotificationItem(
                groupId = payment.groupId,
                title = "Payment Approved",
                message = "Your contribution payment of ₹${payment.paidAmount.toInt()} for ${DateUtils.getMonthName(payment.month)} ${payment.year} has been approved.",
                type = "PAYMENT_APPROVED",
                relatedId = paymentId,
                actionRoute = "member/${payment.memberId}"
            )
        )

        logAudit(
            groupId = payment.groupId,
            actorName = adminName,
            actorRole = "Admin",
            action = "PAYMENT_APPROVED",
            newVal = "₹${payment.paidAmount.toInt()} for $memberName",
            record = "Payment ID: $paymentId"
        )
        true
    }

    suspend fun rejectPayment(paymentId: Long, adminName: String, reason: String): Boolean = withContext(Dispatchers.IO) {
        val payment = paymentDao.getPaymentById(paymentId) ?: return@withContext false
        val member = memberDao.getMemberById(payment.memberId)
        val memberName = member?.name ?: "Member #${payment.memberId}"

        val rejectedPayment = payment.copy(
            approvalStatus = "REJECTED",
            status = "REJECTED",
            rejectionReason = reason.ifBlank { "Payment could not be verified." }
        )
        paymentDao.updatePayment(rejectedPayment)
        firebaseService?.savePayment(rejectedPayment)

        notificationDao.insertNotification(
            NotificationItem(
                groupId = payment.groupId,
                title = "Payment Rejected",
                message = "Payment of ₹${payment.paidAmount.toInt()} for ${DateUtils.getMonthName(payment.month)} ${payment.year} was rejected: ${rejectedPayment.rejectionReason}. Please resubmit.",
                type = "PAYMENT_REJECTED",
                relatedId = paymentId,
                actionRoute = "member/${payment.memberId}"
            )
        )

        logAudit(
            groupId = payment.groupId,
            actorName = adminName,
            actorRole = "Admin",
            action = "PAYMENT_REJECTED",
            newVal = "Reason: ${rejectedPayment.rejectionReason}",
            record = "Payment ID: $paymentId ($memberName)"
        )
        true
    }

    suspend fun recordPayment(payment: Payment, adminName: String = "Admin"): Long = withContext(Dispatchers.IO) {
        val approvedPayment = payment.copy(
            approvalStatus = "APPROVED",
            status = Payment.calculateStatus(payment.expectedAmount, payment.paidAmount),
            approvedAt = System.currentTimeMillis(),
            approvedBy = adminName
        )
        val existing = paymentDao.getPayment(payment.memberId, payment.month, payment.year)
        val id = if (existing != null) {
            val updated = approvedPayment.copy(id = existing.id, groupId = payment.groupId)
            paymentDao.updatePayment(updated)
            firebaseService?.savePayment(updated)
            existing.id
        } else {
            val newId = paymentDao.insertPayment(approvedPayment)
            firebaseService?.savePayment(approvedPayment.copy(id = newId))
            newId
        }

        val member = memberDao.getMemberById(payment.memberId)
        val memberName = member?.name ?: "Member #${payment.memberId}"

        if (payment.paidAmount > 0) {
            val tx = TransactionRecord(
                groupId = payment.groupId,
                txnNumber = generateTxnNumber(),
                date = payment.paymentDate,
                amount = payment.paidAmount,
                type = "CONTRIBUTION",
                isCredit = true,
                description = "Monthly contribution for ${DateUtils.getMonthName(payment.month)} ${payment.year} from $memberName",
                paymentMethod = payment.paymentMethod,
                relatedMemberId = payment.memberId,
                relatedMemberName = memberName,
                createdBy = adminName
            )
            val txId = transactionDao.insertTransaction(tx)
            firebaseService?.saveTransaction(tx.copy(id = txId))
        }

        logAudit(
            groupId = payment.groupId,
            actorName = adminName,
            actorRole = "Admin",
            action = "PAYMENT_RECORDED",
            newVal = "₹${payment.paidAmount.toInt()} (${payment.status})",
            record = "$memberName - ${DateUtils.getMonthName(payment.month)} ${payment.year}"
        )
        id
    }

    suspend fun quickMarkPaid(
        groupId: Long,
        memberId: Long,
        month: Int,
        year: Int,
        amount: Double,
        paymentMethod: String = "Cash",
        adminName: String = "Admin"
    ) = withContext(Dispatchers.IO) {
        val member = memberDao.getMemberById(memberId) ?: return@withContext
        val expected = if (member.monthlyContribution > 0) member.monthlyContribution else 500.0
        val due = (expected - amount).coerceAtLeast(0.0)
        val status = if (due <= 0.0) "PAID" else if (amount > 0) "PARTIAL" else "UNPAID"

        val payment = Payment(
            groupId = groupId,
            memberId = memberId,
            month = month,
            year = year,
            expectedAmount = expected,
            paidAmount = amount,
            dueAmount = due,
            paymentDate = System.currentTimeMillis(),
            paymentMethod = paymentMethod,
            transactionReference = "REC-${System.currentTimeMillis() % 10000}",
            notes = "Quick entry",
            status = status,
            approvalStatus = "APPROVED",
            approvedAt = System.currentTimeMillis(),
            approvedBy = adminName
        )
        recordPayment(payment, adminName)
    }

    suspend fun recordBatchPayments(payments: List<Payment>, adminName: String = "Admin"): Int = withContext(Dispatchers.IO) {
        var count = 0
        for (payment in payments) {
            recordPayment(payment, adminName)
            count++
        }
        count
    }

    suspend fun importCsvRecords(
        groupId: Long,
        records: List<CsvImportRecord>,
        adminName: String = "Admin"
    ): CsvImportResult = withContext(Dispatchers.IO) {
        val existingMembers = memberDao.getAllMembersDirect(groupId).toMutableList()
        var membersCreated = 0
        var paymentsRecorded = 0
        val errors = mutableListOf<String>()
        val settings = groupSettingsDao.getSettings(groupId)
        val defaultExpected = settings?.defaultContribution ?: 500.0

        for ((index, record) in records.withIndex()) {
            try {
                if (record.memberName.isBlank()) continue

                // 1. Match or create member
                var member = existingMembers.find {
                    (record.phone.isNotBlank() && it.phone.trim() == record.phone.trim()) ||
                    it.name.trim().equals(record.memberName.trim(), ignoreCase = true)
                }

                if (member == null) {
                    val code = "MBR-${existingMembers.size + 1}"
                    val newMember = Member(
                        groupId = groupId,
                        memberCode = code,
                        name = record.memberName.trim(),
                        phone = record.phone.trim(),
                        monthlyContribution = defaultExpected,
                        joinDate = System.currentTimeMillis(),
                        isActive = true
                    )
                    val newId = memberDao.insertMember(newMember)
                    val saved = newMember.copy(id = newId)
                    existingMembers.add(saved)
                    firebaseService?.saveMember(saved)
                    member = saved
                    membersCreated++
                }

                // 2. Record payment
                if (record.month in 1..12 && record.amount >= 0) {
                    val due = (defaultExpected - record.amount).coerceAtLeast(0.0)
                    val calculatedStatus = if (record.status.isNotBlank()) record.status else Payment.calculateStatus(defaultExpected, record.amount)
                    val payment = Payment(
                        groupId = groupId,
                        memberId = member.id,
                        month = record.month,
                        year = if (record.year in 2000..2100) record.year else Calendar.getInstance().get(Calendar.YEAR),
                        expectedAmount = defaultExpected,
                        paidAmount = record.amount,
                        dueAmount = due,
                        paymentDate = System.currentTimeMillis(),
                        paymentMethod = "CSV_IMPORT",
                        transactionReference = "CSV-${System.currentTimeMillis() % 100000}",
                        notes = "Bulk CSV import",
                        status = calculatedStatus,
                        approvalStatus = "APPROVED",
                        approvedAt = System.currentTimeMillis(),
                        approvedBy = adminName
                    )
                    recordPayment(payment, adminName)
                    paymentsRecorded++
                }
            } catch (e: Exception) {
                errors.add("Row ${index + 1} (${record.memberName}): ${e.message}")
            }
        }

        CsvImportResult(
            totalRows = records.size,
            membersCreated = membersCreated,
            paymentsRecorded = paymentsRecorded,
            errors = errors
        )
    }

    suspend fun getPayment(memberId: Long, month: Int, year: Int): Payment? = withContext(Dispatchers.IO) {
        paymentDao.getPayment(memberId, month, year)
    }

    fun getPaymentFlow(memberId: Long, month: Int, year: Int): Flow<Payment?> =
        paymentDao.getPaymentFlow(memberId, month, year)

    // -------------------------------------------------------------
    // Loans & 70% Voting Operations
    // -------------------------------------------------------------
    fun getLoansWithVotingDetails(groupId: Long): Flow<List<LoanWithVotingDetails>> = combine(
        loanDao.getAllLoansFlow(groupId),
        memberDao.getActiveMembers(groupId)
    ) { loans, activeMembersList ->
        val totalActive = activeMembersList.size
        loans.map { loan ->
            val votes = loanDao.getVotesForLoan(loan.id)
            val eligible = (totalActive - 1).coerceAtLeast(1)
            val required = ceil(eligible * 0.70).toInt()
            val approves = votes.count { it.vote == "APPROVE" }
            val rejects = votes.count { it.vote == "REJECT" }
            val pending = (eligible - (approves + rejects)).coerceAtLeast(0)
            val pct = if (eligible > 0) ((approves.toFloat() / eligible.toFloat()) * 100f) else 0f
            val isThresholdReached = approves >= required
            val isExpired = System.currentTimeMillis() > loan.votingDeadline

            LoanWithVotingDetails(
                loan = loan,
                totalActiveMembers = totalActive,
                eligibleVoters = eligible,
                requiredApprovals = required,
                approveCount = approves,
                rejectCount = rejects,
                pendingCount = pending,
                approvalPercentage = pct,
                isApprovedThresholdReached = isThresholdReached,
                isVotingExpired = isExpired,
                votes = votes,
                userVote = null
            )
        }
    }.flowOn(Dispatchers.IO)

    suspend fun submitLoanRequest(loan: LoanRequest): Long = withContext(Dispatchers.IO) {
        val id = loanDao.insertLoan(loan)
        val created = loan.copy(id = id)
        firebaseService?.saveLoan(created)
        notificationDao.insertNotification(
            NotificationItem(
                groupId = loan.groupId,
                title = "New Group Loan Request",
                message = "${loan.requesterName} requested ₹${loan.requestedAmount.toInt()} for ${loan.purpose}. Tap to vote.",
                type = "LOAN_VOTING",
                relatedId = id,
                actionRoute = "loans"
            )
        )
        logAudit(
            groupId = loan.groupId,
            actorName = loan.requesterName,
            actorRole = "Member",
            action = "LOAN_REQUESTED",
            newVal = "₹${loan.requestedAmount.toInt()} - ${loan.purpose}",
            record = "Loan ID: $id"
        )
        id
    }

    suspend fun voteOnLoan(loanId: Long, memberId: Long, memberName: String, vote: String): Boolean = withContext(Dispatchers.IO) {
        val loan = loanDao.getLoanById(loanId) ?: return@withContext false
        if (loan.status != "VOTING" && loan.status != "SUBMITTED") return@withContext false

        loanDao.insertVote(
            LoanVote(
                loanRequestId = loanId,
                memberId = memberId,
                memberName = memberName,
                vote = vote
            )
        )

        val votes = loanDao.getVotesForLoan(loanId)
        val activeCount = memberDao.getActiveMemberCountDirect(loan.groupId)
        val eligible = (activeCount - 1).coerceAtLeast(1)
        val required = ceil(eligible * 0.70).toInt()
        val approves = votes.count { it.vote == "APPROVE" }
        val rejects = votes.count { it.vote == "REJECT" }

        if (approves >= required && loan.status == "VOTING") {
            loanDao.updateLoan(loan.copy(status = "APPROVED"))
            notificationDao.insertNotification(
                NotificationItem(
                    groupId = loan.groupId,
                    title = "Loan Approved by 70% Majority!",
                    message = "Loan for ${loan.requesterName} (₹${loan.requestedAmount.toInt()}) has reached 70% approval.",
                    type = "LOAN_APPROVED",
                    relatedId = loanId,
                    actionRoute = "loans"
                )
            )
            logAudit(
                groupId = loan.groupId,
                action = "LOAN_APPROVED_BY_VOTE",
                newVal = "70% Quorum Reached",
                record = "Loan ID: $loanId"
            )
        } else if (rejects > (eligible - required) && loan.status == "VOTING") {
            loanDao.updateLoan(loan.copy(status = "REJECTED"))
            logAudit(
                groupId = loan.groupId,
                action = "LOAN_REJECTED_BY_VOTE",
                record = "Loan ID: $loanId"
            )
        }
        true
    }

    suspend fun disburseLoan(loanId: Long, adminName: String): Boolean = withContext(Dispatchers.IO) {
        val loan = loanDao.getLoanById(loanId) ?: return@withContext false
        val updated = loan.copy(
            status = "ACTIVE",
            disbursedDate = System.currentTimeMillis(),
            disbursedBy = adminName
        )
        loanDao.updateLoan(updated)

        transactionDao.insertTransaction(
            TransactionRecord(
                groupId = loan.groupId,
                txnNumber = generateTxnNumber(),
                date = System.currentTimeMillis(),
                amount = loan.requestedAmount,
                type = "LOAN_DISBURSEMENT",
                isCredit = false,
                description = "Loan disbursed to ${loan.requesterName} for ${loan.purpose}",
                paymentMethod = "Bank Transfer",
                relatedMemberId = loan.requesterMemberId,
                relatedMemberName = loan.requesterName,
                relatedLoanId = loan.id,
                createdBy = adminName
            )
        )
        logAudit(
            groupId = loan.groupId,
            actorName = adminName,
            actorRole = "Admin",
            action = "LOAN_DISBURSED",
            newVal = "₹${loan.requestedAmount.toInt()}",
            record = "Loan ID: $loanId"
        )
        true
    }

    suspend fun recordLoanRepayment(
        loanId: Long,
        amount: Double,
        paymentMethod: String,
        notes: String,
        adminName: String
    ): Boolean = withContext(Dispatchers.IO) {
        val loan = loanDao.getLoanById(loanId) ?: return@withContext false
        val newRepaid = loan.repaidAmount + amount
        val newRemaining = (loan.requestedAmount - newRepaid).coerceAtLeast(0.0)
        val newStatus = if (newRemaining <= 0.0) "FULLY_REPAID" else "PARTIALLY_REPAID"

        loanDao.updateLoan(
            loan.copy(
                repaidAmount = newRepaid,
                remainingAmount = newRemaining,
                status = newStatus
            )
        )

        transactionDao.insertTransaction(
            TransactionRecord(
                groupId = loan.groupId,
                txnNumber = generateTxnNumber(),
                date = System.currentTimeMillis(),
                amount = amount,
                type = "LOAN_REPAYMENT",
                isCredit = true,
                description = "Loan repayment from ${loan.requesterName} ($notes)",
                paymentMethod = paymentMethod,
                relatedMemberId = loan.requesterMemberId,
                relatedMemberName = loan.requesterName,
                relatedLoanId = loan.id,
                createdBy = adminName
            )
        )
        logAudit(
            groupId = loan.groupId,
            actorName = adminName,
            actorRole = "Treasurer",
            action = "LOAN_REPAYMENT",
            newVal = "₹${amount.toInt()}",
            record = "Loan ID: $loanId"
        )
        true
    }

    // -------------------------------------------------------------
    // Investments & Deletion Functionality
    // -------------------------------------------------------------
    suspend fun addInvestment(investment: InvestmentRecord): Long = withContext(Dispatchers.IO) {
        val id = investmentDao.insertInvestment(investment)
        transactionDao.insertTransaction(
            TransactionRecord(
                groupId = investment.groupId,
                txnNumber = generateTxnNumber(),
                date = investment.investmentDate,
                amount = investment.principalAmount,
                type = "INVESTMENT_PURCHASE",
                isCredit = false,
                description = "Investment placed: ${investment.name} (${investment.institution})",
                paymentMethod = "Bank Transfer",
                relatedInvestmentId = id,
                createdBy = "Admin"
            )
        )
        logAudit(
            groupId = investment.groupId,
            action = "INVESTMENT_ADDED",
            newVal = "${investment.name} - ₹${investment.principalAmount.toInt()}",
            record = "Investment ID: $id"
        )
        id
    }

    suspend fun updateInvestment(investment: InvestmentRecord) = withContext(Dispatchers.IO) {
        investmentDao.updateInvestment(investment.copy(lastUpdated = System.currentTimeMillis()))
        logAudit(
            groupId = investment.groupId,
            action = "INVESTMENT_VALUATION_UPDATED",
            newVal = "₹${investment.currentValue.toInt()}",
            record = investment.name
        )
    }

    suspend fun deleteInvestment(investmentId: Long, adminName: String): Boolean = withContext(Dispatchers.IO) {
        val investment = investmentDao.getInvestmentById(investmentId) ?: return@withContext false
        investmentDao.softDeleteInvestment(investmentId, adminName)
        logAudit(
            groupId = investment.groupId,
            actorName = adminName,
            actorRole = "Admin",
            action = "INVESTMENT_DELETED",
            prev = "${investment.name} (₹${investment.principalAmount.toInt()})",
            record = "Investment ID: $investmentId"
        )
        true
    }

    // -------------------------------------------------------------
    // Feedback & Proposals
    // -------------------------------------------------------------
    fun getFeedbacksWithVotes(groupId: Long): Flow<List<FeedbackWithVotes>> = combine(
        feedbackDao.getAllFeedbacksFlow(groupId),
        memberDao.getActiveMembers(groupId)
    ) { feedbacks, activeMembersList ->
        val totalActive = activeMembersList.size
        feedbacks.map { fb ->
            val votes = feedbackDao.getVotesForProposal(fb.id)
            val agrees = votes.count { it.vote == "AGREE" }
            val disagrees = votes.count { it.vote == "DISAGREE" }
            val pending = (totalActive - (agrees + disagrees)).coerceAtLeast(0)
            val pct = if (totalActive > 0) ((agrees.toFloat() / totalActive.toFloat()) * 100f) else 0f

            FeedbackWithVotes(
                feedback = fb,
                totalEligibleVoters = totalActive,
                agreeCount = agrees,
                disagreeCount = disagrees,
                pendingCount = pending,
                agreePercentage = pct,
                userVote = null
            )
        }
    }.flowOn(Dispatchers.IO)

    suspend fun submitFeedback(feedback: GroupFeedback): Long = withContext(Dispatchers.IO) {
        val id = feedbackDao.insertFeedback(feedback)
        firebaseService?.saveFeedback(feedback.copy(id = id))
        if (feedback.requiresVoting) {
            notificationDao.insertNotification(
                NotificationItem(
                    groupId = feedback.groupId,
                    title = "New Proposal for Group Voting",
                    message = "${feedback.subject}. Cast your vote.",
                    type = "PROPOSAL",
                    relatedId = id,
                    actionRoute = "feedback"
                )
            )
        }
        id
    }

    suspend fun voteOnProposal(feedbackId: Long, memberId: Long, memberName: String, vote: String) = withContext(Dispatchers.IO) {
        feedbackDao.insertProposalVote(
            ProposalVote(
                feedbackId = feedbackId,
                memberId = memberId,
                memberName = memberName,
                vote = vote
            )
        )
    }

    suspend fun toggleSupportFeedback(feedbackId: Long, memberId: Long, memberName: String): Boolean = withContext(Dispatchers.IO) {
        val existing = feedbackDao.getUserVote(feedbackId, memberId)
        if (existing != null && existing.vote == "AGREE") {
            feedbackDao.deleteProposalVote(feedbackId, memberId)
            false
        } else {
            feedbackDao.insertProposalVote(
                ProposalVote(
                    feedbackId = feedbackId,
                    memberId = memberId,
                    memberName = memberName,
                    vote = "AGREE"
                )
            )
            true
        }
    }

    suspend fun getUserVoteForFeedback(feedbackId: Long, memberId: Long): ProposalVote? = withContext(Dispatchers.IO) {
        feedbackDao.getUserVote(feedbackId, memberId)
    }

    // -------------------------------------------------------------
    // Comprehensive Financial Aggregations
    // -------------------------------------------------------------
    fun getComprehensiveFinancials(groupId: Long): Flow<OverallGroupFinancials> = combine(
        memberDao.getAllMembers(groupId),
        paymentDao.getAllPayments(groupId),
        investmentDao.getAllInvestmentsFlow(groupId),
        loanDao.getAllLoansFlow(groupId),
        notificationDao.getUnreadCountFlow(groupId)
    ) { members, allPaymentsList, investments, loans, unreadCount ->
        val activeMembers = members.filter { it.isActive }
        val totalMembersCount = members.size
        val activeMembersCount = activeMembers.size

        val approvedPayments = allPaymentsList.filter { it.isApproved }

        val totalCollectedAllTime = approvedPayments.sumOf { it.paidAmount }
        val totalDueAllTime = allPaymentsList.filter { !it.isApproved }.sumOf { it.expectedAmount } +
                approvedPayments.sumOf { it.dueAmount }

        val cal = Calendar.getInstance()
        val curMonth = cal.get(Calendar.MONTH) + 1
        val curYear = cal.get(Calendar.YEAR)

        val curMonthApprovedPayments = approvedPayments.filter { it.month == curMonth && it.year == curYear }
        val curMonthAllPayments = allPaymentsList.filter { it.month == curMonth && it.year == curYear }

        val curCollected = curMonthApprovedPayments.sumOf { it.paidAmount }
        val curDue = curMonthAllPayments.filter { !it.isApproved }.sumOf { it.expectedAmount } +
                curMonthApprovedPayments.sumOf { it.dueAmount }
        val curPaidCount = curMonthApprovedPayments.count { it.status == "PAID" }
        val curUnpaidCount = curMonthAllPayments.count { it.status == "UNPAID" || it.status == "REJECTED" }
        val curPartialCount = curMonthApprovedPayments.count { it.status == "PARTIAL" }

        val prevMonth = if (curMonth == 1) 12 else curMonth - 1
        val prevYear = if (curMonth == 1) curYear - 1 else curYear
        val prevCollected = approvedPayments.filter { it.month == prevMonth && it.year == prevYear }.sumOf { it.paidAmount }

        val trends = mutableListOf<MonthlyTrendPoint>()
        for (i in 5 downTo 0) {
            val tCal = Calendar.getInstance().apply { add(Calendar.MONTH, -i) }
            val tm = tCal.get(Calendar.MONTH) + 1
            val ty = tCal.get(Calendar.YEAR)
            val tApproved = approvedPayments.filter { it.month == tm && it.year == ty }
            val tAll = allPaymentsList.filter { it.month == tm && it.year == ty }
            trends.add(
                MonthlyTrendPoint(
                    month = tm,
                    year = ty,
                    label = DateUtils.getMonthShortName(tm),
                    collected = tApproved.sumOf { it.paidAmount },
                    expected = tAll.sumOf { it.expectedAmount }.coerceAtLeast(tApproved.sumOf { it.paidAmount })
                )
            )
        }

        val activeInvestments = investments.filter { it.status == "ACTIVE" && !it.isDeleted }
        val totalInvestmentsVal = activeInvestments.sumOf { it.currentValue }
        val fdVal = activeInvestments.filter { it.type == "FD" }.sumOf { it.currentValue }
        val mfVal = activeInvestments.filter { it.type == "MUTUAL_FUND" }.sumOf { it.currentValue }
        val stockVal = activeInvestments.filter { it.type == "STOCK" }.sumOf { it.currentValue }
        val otherInvVal = activeInvestments.filter { it.type !in listOf("FD", "MUTUAL_FUND", "STOCK") }.sumOf { it.currentValue }

        val activeLoans = loans.filter { it.status in listOf("ACTIVE", "DISBURSED", "PARTIALLY_REPAID") }
        val loansGivenTotal = loans.filter { it.status in listOf("ACTIVE", "DISBURSED", "PARTIALLY_REPAID", "FULLY_REPAID") }.sumOf { it.requestedAmount }
        val outstandingLoans = activeLoans.sumOf { it.remainingAmount }
        val pendingLoansCount = loans.count { it.status in listOf("SUBMITTED", "VOTING") }

        val totalLoanRepayments = loans.sumOf { it.repaidAmount }
        val totalInvestedPrincipal = activeInvestments.sumOf { it.principalAmount }
        val totalLoansOutflow = activeLoans.sumOf { it.requestedAmount }

        val availableBalance = (totalCollectedAllTime + totalLoanRepayments - totalInvestedPrincipal - totalLoansOutflow).coerceAtLeast(0.0)
        val bankBalance = availableBalance * 0.75
        val cashBalance = availableBalance * 0.25

        val totalGroupAssets = availableBalance + totalInvestmentsVal + outstandingLoans

        val assetItems = mutableListOf<AssetAllocationItem>()
        if (totalGroupAssets > 0) {
            assetItems.add(
                AssetAllocationItem(
                    category = "Bank & Cash",
                    amount = availableBalance,
                    percentage = ((availableBalance / totalGroupAssets) * 100).toFloat(),
                    colorHex = 0xFF4F46E5
                )
            )
            if (totalInvestmentsVal > 0) {
                assetItems.add(
                    AssetAllocationItem(
                        category = "Investments & FDs",
                        amount = totalInvestmentsVal,
                        percentage = ((totalInvestmentsVal / totalGroupAssets) * 100).toFloat(),
                        colorHex = 0xFF10B981
                    )
                )
            }
            if (outstandingLoans > 0) {
                assetItems.add(
                    AssetAllocationItem(
                        category = "Active Loans",
                        amount = outstandingLoans,
                        percentage = ((outstandingLoans / totalGroupAssets) * 100).toFloat(),
                        colorHex = 0xFFF59E0B
                    )
                )
            }
        }

        OverallGroupFinancials(
            totalMembers = totalMembersCount,
            activeMembers = activeMembersCount,
            totalCollectedAllTime = totalCollectedAllTime,
            totalDueAllTime = totalDueAllTime,
            currentMonthCollected = curCollected,
            currentMonthDue = curDue,
            currentMonthPaidCount = curPaidCount,
            currentMonthUnpaidCount = curUnpaidCount,
            currentMonthPartialCount = curPartialCount,
            previousMonthCollected = prevCollected,
            monthlyTrends = trends,
            totalGroupAssets = totalGroupAssets,
            availableInHandBalance = availableBalance,
            bankBalance = bankBalance,
            cashBalance = cashBalance,
            loansGivenTotal = loansGivenTotal,
            outstandingLoans = outstandingLoans,
            totalInvestmentsValue = totalInvestmentsVal,
            fixedDepositValue = fdVal,
            mutualFundsValue = mfVal,
            stockMarketValue = stockVal,
            otherInvestmentsValue = otherInvVal,
            pendingLoanRequestsCount = pendingLoansCount,
            unreadNotificationsCount = unreadCount,
            totalExpenses = totalLoansOutflow + totalInvestedPrincipal,
            assetAllocations = assetItems
        )
    }.flowOn(Dispatchers.IO)

    // Member Financial Profile
    fun getMemberFinancialProfile(memberId: Long): Flow<MemberFinancialProfile?> = combine(
        memberDao.getMemberByIdFlow(memberId),
        paymentDao.getPaymentsForMember(memberId)
    ) { member, payments ->
        if (member == null) return@combine null

        val settings = groupSettingsDao.getSettings(member.groupId)
        val defaultExp = settings?.defaultContribution ?: 500.0
        val expPerMonth = if (member.monthlyContribution > 0) member.monthlyContribution else defaultExp

        val approvedPayments = payments.filter { it.isApproved }
        val totalExpected = payments.sumOf { it.expectedAmount }.coerceAtLeast(expPerMonth)
        val totalPaid = approvedPayments.sumOf { it.paidAmount }
        val totalDue = (totalExpected - totalPaid).coerceAtLeast(0.0)

        val cal = Calendar.getInstance()
        val curMonth = cal.get(Calendar.MONTH) + 1
        val curYear = cal.get(Calendar.YEAR)
        val curPay = payments.find { it.month == curMonth && it.year == curYear }
        val curStatus = when {
            curPay == null -> "UNPAID"
            curPay.isPendingApproval -> "PENDING_APPROVAL"
            curPay.isRejected -> "REJECTED"
            else -> curPay.status
        }

        val history = payments.sortedWith(compareByDescending<Payment> { it.year }.thenByDescending { it.month })
            .map { p ->
                val displayStatus = when {
                    p.isPendingApproval -> "PENDING_APPROVAL"
                    p.isRejected -> "REJECTED"
                    else -> p.status
                }
                MonthlyLedgerItem(
                    month = p.month,
                    year = p.year,
                    monthName = DateUtils.getMonthName(p.month),
                    expectedAmount = p.expectedAmount,
                    paidAmount = if (p.isApproved) p.paidAmount else 0.0,
                    dueAmount = if (p.isApproved) p.dueAmount else p.expectedAmount,
                    status = displayStatus,
                    paymentDate = p.paymentDate,
                    paymentMethod = p.paymentMethod,
                    transactionRef = p.transactionReference,
                    notes = if (p.isRejected && p.rejectionReason.isNotBlank()) "Rejected: ${p.rejectionReason}" else p.notes
                )
            }

        MemberFinancialProfile(
            member = member,
            totalExpectedAllTime = totalExpected,
            totalPaidAllTime = totalPaid,
            totalDueAllTime = totalDue,
            currentMonthStatus = curStatus,
            paymentHistory = history
        )
    }.flowOn(Dispatchers.IO)

    fun getRecentTransactions(groupId: Long, limit: Int): Flow<List<RecentTransaction>> = combine(
        paymentDao.getAllPayments(groupId),
        memberDao.getAllMembers(groupId)
    ) { payments, members ->
        val membersMap = members.associateBy { it.id }
        payments.filter { it.paidAmount > 0 && it.isApproved }
            .sortedByDescending { it.paymentDate }
            .take(limit)
            .map { p ->
                val m = membersMap[p.memberId]
                RecentTransaction(
                    paymentId = p.id,
                    memberId = p.memberId,
                    memberName = m?.name ?: "Member #${p.memberId}",
                    memberCode = m?.memberCode ?: "M-${p.memberId}",
                    month = p.month,
                    year = p.year,
                    amount = p.paidAmount,
                    paymentDate = p.paymentDate,
                    paymentMethod = p.paymentMethod,
                    status = p.status
                )
            }
    }.flowOn(Dispatchers.IO)

    // Settings
    suspend fun updateSettings(settings: GroupSettings) = withContext(Dispatchers.IO) {
        groupSettingsDao.insertOrUpdate(settings)
        firebaseService?.saveGroup(settings)
        logAudit(
            groupId = settings.id,
            action = "SETTINGS_UPDATED",
            record = "Group Name: ${settings.groupName}"
        )
    }

    // Notices
    suspend fun addNotice(notice: SocietyNotice): Long = withContext(Dispatchers.IO) {
        val id = noticeDao.insertNotice(notice)
        val created = notice.copy(id = id)
        firebaseService?.saveNotice(created)
        notificationDao.insertNotification(
            NotificationItem(
                groupId = notice.groupId,
                title = notice.title,
                message = notice.content.take(60),
                type = "ANNOUNCEMENT",
                relatedId = id,
                actionRoute = "chat"
            )
        )
        id
    }

    suspend fun updateNotice(notice: SocietyNotice) = withContext(Dispatchers.IO) {
        noticeDao.updateNotice(notice)
        firebaseService?.saveNotice(notice)
    }

    suspend fun deleteNotice(notice: SocietyNotice) = withContext(Dispatchers.IO) {
        noticeDao.deleteNotice(notice)
        firebaseService?.deleteNotice(notice.groupId, notice.id)
    }

    suspend fun voteOnNoticePoll(noticeId: Long, memberId: Long, option: String) = withContext(Dispatchers.IO) {
        val notice = noticeDao.getNoticeById(noticeId) ?: return@withContext
        val votesMap = try {
            val obj = org.json.JSONObject(notice.pollVotesJson)
            val map = mutableMapOf<String, String>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                map[k] = obj.getString(k)
            }
            map
        } catch (e: Exception) {
            mutableMapOf<String, String>()
        }
        votesMap[memberId.toString()] = option
        val newObj = org.json.JSONObject()
        votesMap.forEach { (k, v) -> newObj.put(k, v) }
        val updated = notice.copy(pollVotesJson = newObj.toString())
        noticeDao.updateNotice(updated)
        firebaseService?.voteOnNoticePoll(notice.groupId, noticeId, memberId, option)
    }

    // Notifications & Chat
    suspend fun insertNotification(notification: NotificationItem): Long = withContext(Dispatchers.IO) {
        notificationDao.insertNotification(notification)
    }

    suspend fun markNotificationRead(id: Long) = withContext(Dispatchers.IO) {
        notificationDao.markAsRead(id)
    }

    suspend fun markAllNotificationsRead(groupId: Long) = withContext(Dispatchers.IO) {
        notificationDao.markAllAsRead(groupId)
    }

    suspend fun sendChatMessage(chat: GroupChatMessage): Long = withContext(Dispatchers.IO) {
        val id = chatMessageDao.insertMessage(chat)
        val created = chat.copy(id = id)
        firebaseService?.saveChatMessage(created)
        id
    }

    // -------------------------------------------------------------
    // Real-Time Cloud Firestore Sync Helpers
    // -------------------------------------------------------------
    suspend fun syncFromFirestoreMembers(members: List<Member>) = withContext(Dispatchers.IO) {
        if (members.isNotEmpty()) {
            memberDao.insertMembers(members)
        }
    }

    suspend fun syncFromFirestorePayments(payments: List<Payment>) = withContext(Dispatchers.IO) {
        if (payments.isNotEmpty()) {
            paymentDao.insertPayments(payments)
        }
    }

    suspend fun syncFromFirestoreTransactions(transactions: List<TransactionRecord>) = withContext(Dispatchers.IO) {
        if (transactions.isNotEmpty()) {
            transactionDao.insertTransactions(transactions)
        }
    }

    suspend fun syncFromFirestoreNotices(notices: List<SocietyNotice>) = withContext(Dispatchers.IO) {
        for (n in notices) {
            noticeDao.insertNotice(n)
        }
    }

    suspend fun syncFromFirestoreLoans(loans: List<LoanRequest>) = withContext(Dispatchers.IO) {
        for (l in loans) {
            loanDao.insertLoan(l)
        }
    }

    suspend fun syncFromFirestoreMessages(messages: List<GroupChatMessage>) = withContext(Dispatchers.IO) {
        if (messages.isNotEmpty()) {
            chatMessageDao.insertMessages(messages)
        }
    }

    suspend fun syncFromFirestoreGroupSettings(settings: GroupSettings) = withContext(Dispatchers.IO) {
        groupSettingsDao.insertOrUpdate(settings)
    }

    suspend fun syncFromFirestorePreAuthorized(list: List<PreAuthorizedMember>) = withContext(Dispatchers.IO) {
        for (item in list) {
            preAuthorizedMemberDao.insertOrUpdate(item)
        }
    }

    suspend fun syncFromFirestorePendingRequests(list: List<GroupJoinRequest>) = withContext(Dispatchers.IO) {
        for (item in list) {
            groupJoinRequestDao.insertRequest(item)
        }
    }

    // -------------------------------------------------------------
    // Direct Server-Side Refresh (Pull-to-Refresh via Source.SERVER)
    // -------------------------------------------------------------

    suspend fun refreshDashboardFromServer(groupId: Long) = withContext(Dispatchers.IO) {
        val fb = firebaseService ?: return@withContext
        try {
            val settings = fb.getGroupSettingsFromServer(groupId)
            if (settings != null) {
                groupSettingsDao.insertOrUpdate(settings)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to refresh group settings from server: ${e.message}")
        }

        try {
            val members = fb.getMembersFromServer(groupId)
            if (members.isNotEmpty()) {
                memberDao.insertMembers(members)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to refresh members from server: ${e.message}")
        }

        try {
            val payments = fb.getPaymentsFromServer(groupId)
            if (payments.isNotEmpty()) {
                paymentDao.insertPayments(payments)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to refresh payments from server: ${e.message}")
        }

        try {
            val txs = fb.getTransactionsFromServer(groupId)
            if (txs.isNotEmpty()) {
                transactionDao.insertTransactions(txs)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to refresh transactions from server: ${e.message}")
        }

        try {
            val notices = fb.getNoticesFromServer(groupId)
            if (notices.isNotEmpty()) {
                for (n in notices) {
                    noticeDao.insertNotice(n)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to refresh notices from server: ${e.message}")
        }
    }

    suspend fun refreshNoticesFromServer(groupId: Long) = withContext(Dispatchers.IO) {
        val fb = firebaseService ?: return@withContext
        try {
            val notices = fb.getNoticesFromServer(groupId)
            if (notices.isNotEmpty()) {
                for (n in notices) {
                    noticeDao.insertNotice(n)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to refresh notices from server: ${e.message}")
        }
    }

    suspend fun refreshFeedbacksFromServer(groupId: Long) = withContext(Dispatchers.IO) {
        val fb = firebaseService ?: return@withContext
        try {
            val feedbacks = fb.getFeedbacksFromServer(groupId)
            if (feedbacks.isNotEmpty()) {
                feedbackDao.insertFeedbacks(feedbacks)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to refresh feedbacks from server: ${e.message}")
        }
    }

    // Backup & Restore for Group
    suspend fun exportDataAsJson(groupId: Long): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        val members = memberDao.getAllMembersDirect(groupId)
        val payments = paymentDao.getAllPaymentsDirect(groupId)
        val settings = groupSettingsDao.getSettings(groupId)

        val mArr = JSONArray()
        members.forEach { m ->
            mArr.put(
                JSONObject().apply {
                    put("id", m.id)
                    put("groupId", m.groupId)
                    put("memberCode", m.memberCode)
                    put("name", m.name)
                    put("phone", m.phone)
                    put("address", m.address)
                    put("joinDate", m.joinDate)
                    put("monthlyContribution", m.monthlyContribution)
                    put("photoUri", m.photoUri)
                    put("isActive", m.isActive)
                    put("notes", m.notes)
                }
            )
        }
        root.put("members", mArr)

        val pArr = JSONArray()
        payments.forEach { p ->
            pArr.put(
                JSONObject().apply {
                    put("id", p.id)
                    put("groupId", p.groupId)
                    put("memberId", p.memberId)
                    put("month", p.month)
                    put("year", p.year)
                    put("expectedAmount", p.expectedAmount)
                    put("paidAmount", p.paidAmount)
                    put("dueAmount", p.dueAmount)
                    put("paymentDate", p.paymentDate)
                    put("paymentMethod", p.paymentMethod)
                    put("transactionReference", p.transactionReference)
                    put("notes", p.notes)
                    put("status", p.status)
                    put("approvalStatus", p.approvalStatus)
                    put("rejectionReason", p.rejectionReason)
                }
            )
        }
        root.put("payments", pArr)

        settings?.let { s ->
            root.put(
                "settings",
                JSONObject().apply {
                    put("id", s.id)
                    put("groupName", s.groupName)
                    put("groupSubtitle", s.groupSubtitle)
                    put("inviteCode", s.inviteCode)
                    put("defaultContribution", s.defaultContribution)
                    put("currencySymbol", s.currencySymbol)
                    put("adminName", s.adminName)
                    put("adminPhone", s.adminPhone)
                    put("paymentRules", s.paymentRules)
                }
            )
        }
        root.toString(2)
    }

    suspend fun restoreDataFromJson(groupId: Long, jsonString: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonString)
            if (root.has("members")) {
                val mArr = root.getJSONArray("members")
                val restoredMembers = mutableListOf<Member>()
                for (i in 0 until mArr.length()) {
                    val obj = mArr.getJSONObject(i)
                    restoredMembers.add(
                        Member(
                            id = obj.optLong("id", 0),
                            groupId = groupId,
                            memberCode = obj.optString("memberCode", "M-$i"),
                            name = obj.optString("name", "Member"),
                            phone = obj.optString("phone", ""),
                            address = obj.optString("address", ""),
                            joinDate = obj.optLong("joinDate", System.currentTimeMillis()),
                            monthlyContribution = obj.optDouble("monthlyContribution", 500.0),
                            photoUri = obj.optString("photoUri", ""),
                            isActive = obj.optBoolean("isActive", true),
                            notes = obj.optString("notes", "")
                        )
                    )
                }
                if (restoredMembers.isNotEmpty()) {
                    memberDao.insertMembers(restoredMembers)
                }
            }

            if (root.has("payments")) {
                val pArr = root.getJSONArray("payments")
                val restoredPayments = mutableListOf<Payment>()
                for (i in 0 until pArr.length()) {
                    val obj = pArr.getJSONObject(i)
                    restoredPayments.add(
                        Payment(
                            id = obj.optLong("id", 0),
                            groupId = groupId,
                            memberId = obj.optLong("memberId", 1),
                            month = obj.optInt("month", 1),
                            year = obj.optInt("year", 2026),
                            expectedAmount = obj.optDouble("expectedAmount", 500.0),
                            paidAmount = obj.optDouble("paidAmount", 500.0),
                            dueAmount = obj.optDouble("dueAmount", 0.0),
                            paymentDate = obj.optLong("paymentDate", System.currentTimeMillis()),
                            paymentMethod = obj.optString("paymentMethod", "Cash"),
                            transactionReference = obj.optString("transactionReference", ""),
                            notes = obj.optString("notes", ""),
                            status = obj.optString("status", "PAID"),
                            approvalStatus = obj.optString("approvalStatus", "APPROVED"),
                            rejectionReason = obj.optString("rejectionReason", "")
                        )
                    )
                }
                if (restoredPayments.isNotEmpty()) {
                    paymentDao.insertPayments(restoredPayments)
                }
            }

            if (root.has("settings")) {
                val sObj = root.getJSONObject("settings")
                val settings = GroupSettings(
                    id = groupId,
                    groupName = sObj.optString("groupName", "All services group"),
                    groupSubtitle = sObj.optString("groupSubtitle", "Community Monthly Contribution & Savings Society"),
                    inviteCode = sObj.optString("inviteCode", "SAMITI-101"),
                    defaultContribution = sObj.optDouble("defaultContribution", 500.0),
                    currencySymbol = sObj.optString("currencySymbol", "₹"),
                    adminName = sObj.optString("adminName", "Admin"),
                    adminPhone = sObj.optString("adminPhone", ""),
                    paymentRules = sObj.optString("paymentRules", "")
                )
                groupSettingsDao.insertOrUpdate(settings)
            }
            logAudit(groupId = groupId, action = "BACKUP_RESTORED", record = "JSON Import Successful")
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Phase B.5 — Connects an approved Chit Fund Auction Result to the existing Group Ledger.
     * Generates immutable TransactionRecords for Prize Payout and Foreman Commission,
     * updates Member payment expectations with the earned dividend, and marks the cycle as SETTLED.
     */
    data class ChitSettlementResult(
        val success: Boolean,
        val message: String,
        val payoutTxnId: String? = null,
        val commissionTxnId: String? = null,
        val prizeAmount: Double = 0.0,
        val commissionAmount: Double = 0.0,
        val dividendPerMember: Double = 0.0,
        val winnerName: String? = null
    )

    suspend fun settleChitAuction(
        groupId: Long,
        cycleNumber: Int,
        adminName: String,
        adminMemberId: Long?,
        paymentMethod: String = "Bank Transfer",
        settlementNotes: String = ""
    ): ChitSettlementResult = withContext(Dispatchers.IO) {
        try {
            val settings = groupSettingsDao.getSettings(groupId)
                ?: return@withContext ChitSettlementResult(false, "Group settings not found.")

            val chitConfig = ChitFundConfig.parseFromSettings(settings)
            val cycles = chitConfig.cycles.toMutableList()
            val targetIdx = cycles.indexOfFirst { it.cycleNumber == cycleNumber }
            if (targetIdx == -1) {
                return@withContext ChitSettlementResult(false, "Round #$cycleNumber not found.")
            }

            val targetCycle = cycles[targetIdx]

            // Idempotency: Check if already settled
            if (targetCycle.status == ChitCycleStatus.SETTLED ||
                targetCycle.auctionResult?.resultStatus == ChitAuctionResultStatus.SETTLED) {
                return@withContext ChitSettlementResult(
                    success = true,
                    message = "Round #$cycleNumber is already settled. Ledger records are intact.",
                    payoutTxnId = targetCycle.auctionResult?.settlementPayoutTxnId,
                    commissionTxnId = targetCycle.auctionResult?.settlementCommissionTxnId,
                    prizeAmount = targetCycle.auctionResult?.estimatedOutcome?.prizePayoutAmount ?: 0.0,
                    commissionAmount = targetCycle.auctionResult?.estimatedOutcome?.foremanCommission ?: 0.0,
                    dividendPerMember = targetCycle.dividendPerMember ?: 0.0,
                    winnerName = targetCycle.winnerMemberName
                )
            }

            // Prerequisite check: Must be APPROVED or SETTLEMENT_PENDING
            val currentResult = targetCycle.auctionResult
            if (targetCycle.status != ChitCycleStatus.RESULT_APPROVED &&
                targetCycle.status != ChitCycleStatus.SETTLEMENT_PENDING &&
                currentResult?.resultStatus != ChitAuctionResultStatus.RESULT_APPROVED &&
                currentResult?.resultStatus != ChitAuctionResultStatus.SETTLEMENT_PENDING) {
                return@withContext ChitSettlementResult(
                    false,
                    "Cannot settle: Round #$cycleNumber result must be Approved by Group Admin before settlement."
                )
            }

            val winnerMemberId = targetCycle.winnerMemberId ?: currentResult?.winningMemberId
            if (winnerMemberId == null) {
                return@withContext ChitSettlementResult(
                    false,
                    "Cannot settle: No winner has been declared or tie is unresolved for Round #$cycleNumber."
                )
            }

            val totalMembers = chitConfig.totalMembers ?: memberDao.getActiveMemberCountDirect(groupId).coerceAtLeast(1)
            val outcome = currentResult?.estimatedOutcome ?: ChitCalculationEngine.calculateEstimatedPrizeAndDividend(
                totalPot = totalMembers * targetCycle.installmentAmount,
                highestDiscountBid = targetCycle.winningBidAmount ?: 0.0,
                totalMembers = totalMembers,
                foremanCommissionPercent = 5.0,
                monthlyInstallment = targetCycle.installmentAmount
            )

            val winnerMember = memberDao.getMemberById(winnerMemberId)
            val winnerName = winnerMember?.name ?: targetCycle.winnerMemberName ?: "Member #$winnerMemberId"

            val nowMillis = System.currentTimeMillis()
            val payoutTxnRef = "CHIT-PAYOUT-G${groupId}-C${cycleNumber}"
            val commissionTxnRef = "CHIT-COMMISSION-G${groupId}-C${cycleNumber}"

            // 1. Record Prize Payout Transaction in Group Ledger (Cash outflow / Debit)
            val payoutTxn = TransactionRecord(
                groupId = groupId,
                txnNumber = payoutTxnRef,
                date = nowMillis,
                amount = outcome.prizePayoutAmount,
                type = "EXPENSE",
                isCredit = false,
                description = "Chit Fund Round #$cycleNumber Prize Payout to $winnerName (Gross Pot: ₹${outcome.totalPot.toInt()}, Discount Bid: ₹${outcome.winningDiscountBid.toInt()})",
                paymentMethod = paymentMethod,
                relatedMemberId = winnerMemberId,
                relatedMemberName = winnerName,
                createdBy = adminName
            )
            val payoutTxnId = transactionDao.insertTransaction(payoutTxn)
            firebaseService?.saveTransaction(payoutTxn.copy(id = payoutTxnId))

            // 2. Record Foreman Commission Transaction in Group Ledger (Income / Credit)
            val commissionTxn = TransactionRecord(
                groupId = groupId,
                txnNumber = commissionTxnRef,
                date = nowMillis,
                amount = outcome.foremanCommission,
                type = "INCOME",
                isCredit = true,
                description = "Chit Fund Round #$cycleNumber Foreman Commission / Group Admin Fee (5% of ₹${outcome.totalPot.toInt()})",
                paymentMethod = paymentMethod,
                createdBy = adminName
            )
            val commissionTxnId = transactionDao.insertTransaction(commissionTxn)
            firebaseService?.saveTransaction(commissionTxn.copy(id = commissionTxnId))

            // 3. Member Contribution Accounting (Adjust net monthly installment with dividend per member)
            val cal = Calendar.getInstance().apply { timeInMillis = targetCycle.scheduledDateMillis }
            val cycleMonth = cal.get(Calendar.MONTH) + 1
            val cycleYear = cal.get(Calendar.YEAR)
            val netExpectedAmount = (targetCycle.installmentAmount - outcome.dividendPerMember).coerceAtLeast(0.0)

            val allMembers = memberDao.getAllMembersDirect(groupId)
            for (m in allMembers) {
                val existingPayment = paymentDao.getPayment(m.id, cycleMonth, cycleYear)
                val notesText = "Round #$cycleNumber Chit: Dividend ₹${outcome.dividendPerMember.toInt()} applied"
                if (existingPayment != null) {
                    val updatedPayment = existingPayment.copy(
                        expectedAmount = netExpectedAmount,
                        dueAmount = (netExpectedAmount - existingPayment.paidAmount).coerceAtLeast(0.0),
                        status = Payment.calculateStatus(netExpectedAmount, existingPayment.paidAmount),
                        notes = if (existingPayment.notes.isBlank()) notesText else "${existingPayment.notes} | $notesText"
                    )
                    paymentDao.updatePayment(updatedPayment)
                    firebaseService?.savePayment(updatedPayment)
                } else {
                    val newPayment = Payment(
                        groupId = groupId,
                        memberId = m.id,
                        month = cycleMonth,
                        year = cycleYear,
                        expectedAmount = netExpectedAmount,
                        paidAmount = 0.0,
                        dueAmount = netExpectedAmount,
                        paymentMethod = "Cash",
                        notes = notesText,
                        status = "UNPAID",
                        approvalStatus = "APPROVED"
                    )
                    val pId = paymentDao.insertPayment(newPayment)
                    firebaseService?.savePayment(newPayment.copy(id = pId))
                }
            }

            // 4. Audit Log
            logAudit(
                groupId = groupId,
                actorName = adminName,
                actorRole = "Admin",
                action = "CHIT_AUCTION_SETTLED",
                newVal = "Prize: ₹${outcome.prizePayoutAmount.toInt()} to $winnerName, Comm: ₹${outcome.foremanCommission.toInt()}, Div: ₹${outcome.dividendPerMember.toInt()}/m",
                record = "Round #$cycleNumber Settlement"
            )

            // 5. Notification
            notificationDao.insertNotification(
                NotificationItem(
                    groupId = groupId,
                    title = "Chit Round #$cycleNumber Settled 🎉",
                    message = "$winnerName won Round #$cycleNumber (₹${outcome.prizePayoutAmount.toInt()} prize payout). Dividend ₹${outcome.dividendPerMember.toInt()} per member applied to this round.",
                    type = "ANNOUNCEMENT",
                    actionRoute = "auction_result_review/$cycleNumber"
                )
            )

            // 6. Update Chit Cycle & Result Status to SETTLED
            val finalResult = (currentResult ?: ChitAuctionResult(cycleNumber = cycleNumber)).copy(
                winningMemberId = winnerMemberId,
                winningMemberName = winnerName,
                winningBidAmount = targetCycle.winningBidAmount ?: outcome.winningDiscountBid,
                resultStatus = ChitAuctionResultStatus.SETTLED,
                settledAtMillis = nowMillis,
                settledByMemberId = adminMemberId,
                settledByMemberName = adminName,
                settlementPayoutTxnId = payoutTxnRef,
                settlementCommissionTxnId = commissionTxnRef,
                settlementNotes = settlementNotes.ifBlank { "Settled and posted to Group Ledger" },
                estimatedOutcome = outcome
            )

            val settledCycle = targetCycle.copy(
                status = ChitCycleStatus.SETTLED,
                winnerMemberId = winnerMemberId,
                winnerMemberName = winnerName,
                winningBidAmount = targetCycle.winningBidAmount ?: outcome.winningDiscountBid,
                dividendPerMember = outcome.dividendPerMember,
                auctionResult = finalResult,
                updatedAtMillis = nowMillis
            )

            cycles[targetIdx] = settledCycle
            val updatedConfig = chitConfig.copy(cycles = cycles)
            val updatedSettings = ChitFundConfig.encodeIntoSettings(settings, updatedConfig)
            groupSettingsDao.insertOrUpdate(updatedSettings)
            firebaseService?.saveGroup(updatedSettings)

            ChitSettlementResult(
                success = true,
                message = "Round #$cycleNumber successfully settled! Prize Payout (₹${outcome.prizePayoutAmount.toInt()}) and Commission (₹${outcome.foremanCommission.toInt()}) committed to Group Ledger.",
                payoutTxnId = payoutTxnRef,
                commissionTxnId = commissionTxnRef,
                prizeAmount = outcome.prizePayoutAmount,
                commissionAmount = outcome.foremanCommission,
                dividendPerMember = outcome.dividendPerMember,
                winnerName = winnerName
            )
        } catch (e: Exception) {
            e.printStackTrace()
            ChitSettlementResult(
                success = false,
                message = "Settlement failed: ${e.message ?: "Unknown error"}"
            )
        }
    }
}
