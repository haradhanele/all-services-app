package com.adr.groupledger.ui.home

import android.util.Log
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.HomeModuleConfig
import com.adr.groupledger.ui.screens.demo.GroupCategory
import org.json.JSONArray
import org.json.JSONObject

/**
 * Resolver responsible for determining the active [GroupCategory] and [subCategory]
 * for a given [GroupSettings] instance, with multi-level fallback safety.
 */
object HomeTemplateResolver {

    private const val TAG = "HomeTemplateResolver"

    /**
     * Resolves the (Category, SubCategory) pair from [GroupSettings].
     * Never throws; always returns a valid fallback.
     */
    fun resolve(settings: GroupSettings?): Pair<GroupCategory, String> {
        if (settings == null) {
            return Pair(GroupCategory.COMMUNITY_FUND, "Monthly Community Collection")
        }

        // 1. Try parsing from modulesConfigJson if stored as structured metadata
        val jsonMeta = parseFromModulesJson(settings.modulesConfigJson)
        if (jsonMeta != null) {
            val matchedCategory = GroupCategory.entries.find {
                it.id.equals(jsonMeta.first, ignoreCase = true) ||
                it.title.equals(jsonMeta.first, ignoreCase = true) ||
                it.name.equals(jsonMeta.first, ignoreCase = true)
            }
            if (matchedCategory != null) {
                val candidateSub = jsonMeta.second.trim()
                val validatedSub = if (candidateSub.isNotBlank() && matchedCategory.subCategories.any { it.equals(candidateSub, ignoreCase = true) }) {
                    matchedCategory.subCategories.first { it.equals(candidateSub, ignoreCase = true) }
                } else if (candidateSub.isNotBlank() && matchedCategory.subCategories.any { it.contains(candidateSub, ignoreCase = true) || candidateSub.contains(it, ignoreCase = true) }) {
                    matchedCategory.subCategories.first { it.contains(candidateSub, ignoreCase = true) || candidateSub.contains(it, ignoreCase = true) }
                } else {
                    matchedCategory.subCategories.firstOrNull() ?: "General"
                }
                return Pair(matchedCategory, validatedSub)
            }
        }

        // 1b. Check if modulesConfigJson has embedded chitConfig
        if (settings.modulesConfigJson.contains("\"chitConfig\"")) {
            return Pair(GroupCategory.SAVINGS_CREDIT_CHIT, "Chit Fund / BC")
        }

        // 2. Try matching from groupType
        val groupType = settings.groupType.trim()
        val fromGroupType = matchCategoryFromString(groupType)
        if (fromGroupType != null) {
            val sub = matchSubCategoryFromString(fromGroupType, settings.groupSubtitle, groupType, settings.groupName)
            return Pair(fromGroupType, sub)
        }

        // 3. Try matching from groupSubtitle or groupName
        val fromSubtitle = matchCategoryFromString(settings.groupSubtitle)
        if (fromSubtitle != null) {
            val sub = matchSubCategoryFromString(fromSubtitle, settings.groupSubtitle, settings.groupName)
            return Pair(fromSubtitle, sub)
        }

        val fromName = matchCategoryFromString(settings.groupName)
        if (fromName != null) {
            val sub = matchSubCategoryFromString(fromName, settings.groupName, settings.groupSubtitle)
            return Pair(fromName, sub)
        }

        // 4. Default Level 3 Fallback
        Log.d(TAG, "No category matched for groupType '${settings.groupType}'. Using default Community Fund.")
        return Pair(GroupCategory.COMMUNITY_FUND, "Monthly Community Collection")
    }

    private fun parseFromModulesJson(jsonStr: String): Pair<String, String>? {
        if (jsonStr.isBlank() || !jsonStr.trim().startsWith("{")) return null
        return try {
            val obj = JSONObject(jsonStr)
            val cat = obj.optString("category", "").ifBlank {
                obj.optString("categoryId", "").ifBlank {
                    obj.optString("category_id", "")
                }
            }
            val sub = obj.optString("subCategory", "").ifBlank {
                obj.optString("subcategory", "").ifBlank {
                    obj.optString("sub_category", "")
                }
            }
            if (cat.isNotBlank()) Pair(cat, sub) else null
        } catch (e: Exception) {
            null
        }
    }

    private fun matchCategoryFromString(text: String): GroupCategory? {
        if (text.isBlank()) return null
        val trimmed = text.trim()

        // 1. Direct match with Title, ID, or Enum Name
        GroupCategory.entries.find {
            it.title.equals(trimmed, ignoreCase = true) ||
            it.id.equals(trimmed, ignoreCase = true) ||
            it.name.equals(trimmed, ignoreCase = true)
        }?.let { return it }

        val lower = trimmed.lowercase()

        return when {
            // Chit Fund / Savings & Credit
            lower.contains("chit fund") || lower.contains("chit") || lower.contains("shg") ||
            lower.contains("self-help") || lower.contains("credit") || lower.contains("rotating") ->
                GroupCategory.SAVINGS_CREDIT_CHIT

            // Puja / Festival
            lower.contains("puja") || lower.contains("festival") || lower.contains("chanda") ||
            lower.contains("pandal") || lower.contains("navratri") || lower.contains("durga") ||
            lower.contains("ganesh") || lower.contains("temple") || lower.contains("utsav") ->
                GroupCategory.PUJA_FESTIVAL

            // Sports & Cultural
            lower.contains("sports") || lower.contains("cultural") || lower.contains("club") ||
            lower.contains("cricket") || lower.contains("football") || lower.contains("tournament") ->
                GroupCategory.SPORTS_CULTURAL

            // Events, Trips & Mess
            lower.contains("trip") || lower.contains("tour") || lower.contains("travel") ||
            lower.contains("mess") || lower.contains("picnic") || lower.contains("outing") ||
            lower.contains("wedding") || lower.contains("reunion") ->
                GroupCategory.EVENTS_TRIPS

            // Family & Friends
            lower.contains("family") || lower.contains("friends") || lower.contains("shared pool") ||
            lower.contains("flatmates") || lower.contains("roommates") ->
                GroupCategory.FAMILY_FRIENDS

            // Welfare & NGO
            lower.contains("welfare") || lower.contains("ngo") || lower.contains("charity") ||
            lower.contains("relief") || lower.contains("donation") || lower.contains("foundation") ->
                GroupCategory.WELFARE_NGO

            // Housing & Apartment
            lower.contains("housing") || lower.contains("apartment") || lower.contains("flat") ||
            lower.contains("residents") || (lower.contains("society") && lower.contains("maintenance")) ->
                GroupCategory.HOUSING_APARTMENT

            // Business & Partnership
            lower.contains("business") || lower.contains("partnership") || lower.contains("venture") ||
            lower.contains("equity") || lower.contains("partner") || lower.contains("enterprise") ->
                GroupCategory.BUSINESS_PARTNERSHIP

            // Community Fund
            lower.contains("community fund") || lower.contains("community") || lower.contains("samiti") ||
            lower.contains("society") ->
                GroupCategory.COMMUNITY_FUND

            else -> null
        }
    }

    private fun matchSubCategoryFromString(category: GroupCategory, vararg candidates: String): String {
        for (cand in candidates) {
            if (cand.isBlank()) continue
            val lower = cand.lowercase().trim()

            // 1. Exact match with any subcategory
            category.subCategories.find { it.equals(lower, ignoreCase = true) }?.let { return it }

            // 2. Either contains the other
            category.subCategories.find {
                it.contains(lower, ignoreCase = true) || lower.contains(it.lowercase())
            }?.let { return it }
        }

        // Specific defaults based on category heuristics
        val combined = candidates.joinToString(" ").lowercase()
        if (category == GroupCategory.SAVINGS_CREDIT_CHIT) {
            if (combined.contains("chit") || combined.contains("bc")) return "Chit Fund / BC"
            if (combined.contains("rotating")) return "Rotating Savings Group"
            if (combined.contains("shg") || combined.contains("self-help")) return "Self-Help Group (SHG)"
        } else if (category == GroupCategory.PUJA_FESTIVAL) {
            if (combined.contains("temple")) return "Temple / Religious Institution Fund"
            if (combined.contains("celebration")) return "Community Celebration Fund"
            if (combined.contains("chanda") || combined.contains("event")) return "Festival Event Fund"
        } else if (category == GroupCategory.COMMUNITY_FUND) {
            if (combined.contains("support") || combined.contains("assistance")) return "Member Support Fund"
            if (combined.contains("emergency")) return "Emergency Fund"
            if (combined.contains("pool") || combined.contains("savings")) return "Savings Pool"
            return "Monthly Community Collection"
        }

        return category.subCategories.firstOrNull() ?: "General"
    }

    /**
     * Encodes the category and subCategory into the [GroupSettings.modulesConfigJson]
     * without altering any database tables or existing Room schema.
     */
    fun encodeCategoryIntoSettings(
        settings: GroupSettings,
        category: GroupCategory,
        subCategory: String
    ): GroupSettings {
        val existingModules = HomeModuleConfig.parseModulesJson(settings.modulesConfigJson)

        val jsonObject = try {
            if (settings.modulesConfigJson.trim().startsWith("{")) {
                JSONObject(settings.modulesConfigJson)
            } else {
                JSONObject()
            }
        } catch (e: Exception) {
            JSONObject()
        }

        val validatedSub = if (category.subCategories.any { it.equals(subCategory, ignoreCase = true) }) {
            category.subCategories.first { it.equals(subCategory, ignoreCase = true) }
        } else if (category.subCategories.any { it.contains(subCategory, ignoreCase = true) || subCategory.contains(it, ignoreCase = true) }) {
            category.subCategories.first { it.contains(subCategory, ignoreCase = true) || subCategory.contains(it, ignoreCase = true) }
        } else {
            category.subCategories.firstOrNull() ?: "General"
        }

        jsonObject.put("category", category.id)
        jsonObject.put("subCategory", validatedSub)

        val modulesArray = JSONArray()
        existingModules.forEach { modulesArray.put(it.toJson()) }
        jsonObject.put("modules", modulesArray)

        if (category == GroupCategory.SAVINGS_CREDIT_CHIT &&
            (validatedSub.contains("Chit", ignoreCase = true) || validatedSub.contains("BC", ignoreCase = true) || validatedSub.contains("Rotating", ignoreCase = true))) {
            if (!jsonObject.has("chitConfig")) {
                val chitCfg = com.adr.groupledger.data.model.ChitFundConfig.parseFromSettings(settings)
                jsonObject.put("chitConfig", chitCfg.toJson())
            }
        }

        return settings.copy(
            modulesConfigJson = jsonObject.toString(),
            groupType = category.title
        )
    }
}
