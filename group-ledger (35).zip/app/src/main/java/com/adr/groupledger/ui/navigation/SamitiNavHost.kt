package com.adr.groupledger.ui.navigation

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.NotificationImportant
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Inbox
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.adr.groupledger.ui.components.AdminPinDialog
import com.adr.groupledger.ui.screens.AddEditMemberScreen
import com.adr.groupledger.ui.screens.AdminControlScreen
import com.adr.groupledger.ui.screens.ExceptionCenterScreen
import com.adr.groupledger.ui.screens.AuctionDetailsScreen
import com.adr.groupledger.ui.screens.AuctionResultReviewScreen
import com.adr.groupledger.ui.screens.BackupRestoreScreen
import com.adr.groupledger.ui.screens.ChitCollectionTrackerScreen
import com.adr.groupledger.ui.screens.ChitMemberContributionScreen
import com.adr.groupledger.ui.screens.CreateNewGroupScreen
import com.adr.groupledger.ui.screens.DashboardScreen
import com.adr.groupledger.ui.screens.GroupFeedbackScreen
import com.adr.groupledger.ui.screens.InboxScreen
import com.adr.groupledger.ui.screens.InvestmentsScreen
import com.adr.groupledger.ui.screens.LoansScreen
import com.adr.groupledger.ui.screens.MemberProfileScreen
import com.adr.groupledger.ui.screens.MembersScreen
import com.adr.groupledger.ui.screens.MonthlyManagementScreen
import com.adr.groupledger.ui.screens.MoreScreen
import com.adr.groupledger.ui.screens.NotificationsScreen
import com.adr.groupledger.ui.screens.PendingDuesScreen
import com.adr.groupledger.ui.screens.RecordPaymentScreen
import com.adr.groupledger.ui.screens.ReportsScreen
import com.adr.groupledger.ui.screens.SettingsScreen
import com.adr.groupledger.ui.screens.SocietyChatScreen
import com.adr.groupledger.ui.screens.TransactionLedgerScreen
import com.adr.groupledger.ui.screens.UserProfileDetailsScreen
import com.adr.groupledger.ui.screens.demo.DemoGroupSetupScreen
import com.adr.groupledger.ui.screens.demo.DemoHomeScreen
import com.adr.groupledger.ui.screens.demo.GroupCategory
import com.adr.groupledger.ui.screens.carousel.AddEditCarouselItemScreen
import com.adr.groupledger.ui.screens.carousel.AdminContentManagementScreen
import com.adr.groupledger.ui.screens.splash.SplashScreen
import com.adr.groupledger.ui.screens.auth.EmailRegisterScreen
import com.adr.groupledger.ui.screens.auth.JoinByInviteCodeScreen
import com.adr.groupledger.ui.screens.auth.LoginScreen
import com.adr.groupledger.ui.screens.auth.SignUpMethodScreen
import com.adr.groupledger.ui.screens.auth.WelcomeEntryScreen
import com.adr.groupledger.ui.theme.BorderLight
import com.adr.groupledger.ui.theme.CardWhite
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.TextSlate400
import com.adr.groupledger.ui.theme.TextSlate500
import com.adr.groupledger.ui.theme.TextSlate800
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import kotlinx.coroutines.launch

sealed class Screen(val route: String, val title: String, val selectedIcon: ImageVector, val unselectedIcon: ImageVector) {
    data object Home : Screen("home", "Home", Icons.Filled.Home, Icons.Outlined.Home)
    data object Inbox : Screen("inbox", "Inbox", Icons.Filled.Inbox, Icons.Outlined.Inbox)
    data object Members : Screen("members", "Member", Icons.Filled.Group, Icons.Outlined.Group)
    data object Reports : Screen("reports", "Report", Icons.Filled.ReceiptLong, Icons.Outlined.ReceiptLong)
    data object More : Screen("more", "More", Icons.Filled.MoreHoriz, Icons.Outlined.MoreHoriz)
}

val bottomNavItems = listOf(
    Screen.Home,
    Screen.Inbox,
    Screen.Members,
    Screen.Reports,
    Screen.More
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SamitiApp(
    viewModel: SocietyViewModel,
    modifier: Modifier = Modifier,
    navController: NavHostController = rememberNavController()
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val homeListState = rememberLazyListState()

    val isAuthenticated by viewModel.isAuthenticated.collectAsStateWithLifecycle()
    val userMessage by viewModel.userMessage.collectAsStateWithLifecycle()
    val showPinDialog by viewModel.showPinDialog.collectAsStateWithLifecycle()
    val monthSummary by viewModel.currentMonthSummary.collectAsStateWithLifecycle()
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val inboxBadgeCount by viewModel.inboxBadgeCount.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()

    // Show Toast for user message
    LaunchedEffect(userMessage) {
        userMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearUserMessage()
        }
    }

    var isSplashFinished by rememberSaveable { mutableStateOf(false) }

    if (!isSplashFinished) {
        SplashScreen(
            onSplashFinished = {
                isSplashFinished = true
            },
            modifier = modifier
        )
        return
    }

    if (!isAuthenticated) {
        val authNavController = rememberNavController()
        NavHost(
            navController = authNavController,
            startDestination = "auth_welcome",
            modifier = modifier
        ) {
            composable("auth_welcome") {
                WelcomeEntryScreen(
                    onNavigateToSignUp = {
                        authNavController.navigate("auth_signup_methods")
                    },
                    onNavigateToInviteCode = {
                        authNavController.navigate("auth_invite_code")
                    },
                    onNavigateToLogin = {
                        authNavController.navigate("auth_login")
                    }
                )
            }

            composable("auth_signup_methods") {
                SignUpMethodScreen(
                    viewModel = viewModel,
                    onNavigateBack = {
                        authNavController.popBackStack()
                    },
                    onNavigateToEmailSignUp = {
                        authNavController.navigate("auth_email_register")
                    },
                    onNavigateToLogin = {
                        authNavController.navigate("auth_login")
                    },
                    onSignUpSuccess = {
                        // Handled via isAuthenticated StateFlow
                    }
                )
            }

            composable("auth_email_register") {
                EmailRegisterScreen(
                    viewModel = viewModel,
                    onNavigateBack = {
                        authNavController.popBackStack()
                    },
                    onNavigateToLogin = {
                        authNavController.navigate("auth_login")
                    },
                    onRegistrationSuccess = {
                        // Handled via isAuthenticated StateFlow
                    }
                )
            }

            composable("auth_login") {
                LoginScreen(
                    viewModel = viewModel,
                    onNavigateBack = {
                        authNavController.popBackStack()
                    },
                    onNavigateToSignUp = {
                        authNavController.navigate("auth_signup_methods")
                    },
                    onLoginSuccess = {
                        // Handled via isAuthenticated StateFlow
                    }
                )
            }

            composable("auth_invite_code") {
                JoinByInviteCodeScreen(
                    viewModel = viewModel,
                    onNavigateBack = {
                        authNavController.popBackStack()
                    },
                    onJoinSuccess = { groupName ->
                        // Handled via isAuthenticated StateFlow
                    }
                )
            }
        }
    } else {
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry?.destination?.route
        val isTopLevelDestination = bottomNavItems.any { it.route == currentRoute }

        Scaffold(
            topBar = {
            if (isTopLevelDestination) {
                TopAppBar(
                    title = {
                        val currentScreen = bottomNavItems.find { it.route == currentRoute }
                        if (currentScreen == Screen.Home) {
                            val greetingName = currentUser?.fullName?.takeIf { it.isNotBlank() } ?: "User"
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { navController.navigate(Screen.More.route) }
                                    .padding(vertical = 4.dp, horizontal = 4.dp)
                            ) {
                                Text(
                                    text = "Hi..$greetingName!",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        } else {
                            Text(
                                text = when (currentScreen) {
                                    Screen.Inbox -> "Inbox & Notices"
                                    Screen.Members -> "Society Members"
                                    Screen.Reports -> "Reports & Analytics"
                                    Screen.More -> "More & Administration"
                                    else -> "Group Ledger"
                                },
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    },
                    actions = {
                        if (currentRoute == Screen.Home.route) {
                            IconButton(
                                onClick = {
                                    navController.navigate("notifications")
                                },
                                modifier = Modifier.testTag("home_notification_btn")
                            ) {
                                if (inboxBadgeCount > 0) {
                                    BadgedBox(
                                        badge = {
                                            Badge(
                                                containerColor = Rose500,
                                                contentColor = Color.White
                                            ) {
                                                Text("$inboxBadgeCount", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Notifications,
                                            contentDescription = "Notifications",
                                            tint = IndigoPrimary
                                        )
                                    }
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Notifications,
                                        contentDescription = "Notifications",
                                        tint = IndigoPrimary
                                    )
                                }
                            }
                        } else if (currentRoute == Screen.Reports.route) {
                            var showExportMenu by remember { mutableStateOf(false) }
                            val context = LocalContext.current

                            Box {
                                IconButton(
                                    onClick = { showExportMenu = true },
                                    modifier = Modifier.testTag("export_report_top_bar_btn")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FileDownload,
                                        contentDescription = "Export Report",
                                        tint = IndigoPrimary
                                    )
                                }

                                DropdownMenu(
                                    expanded = showExportMenu,
                                    onDismissRequest = { showExportMenu = false },
                                    modifier = Modifier.testTag("export_report_dropdown_menu")
                                ) {
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                "Export PDF",
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 13.5.sp
                                            )
                                        },
                                        leadingIcon = {
                                            Icon(
                                                imageVector = Icons.Default.PictureAsPdf,
                                                contentDescription = null,
                                                tint = IndigoPrimary,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        },
                                        onClick = {
                                            showExportMenu = false
                                            viewModel.exportCurrentReportPdf(context)
                                        },
                                        modifier = Modifier.testTag("export_pdf_menu_item")
                                    )
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                "Export CSV",
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 13.5.sp
                                            )
                                        },
                                        leadingIcon = {
                                            Icon(
                                                imageVector = Icons.Default.TableChart,
                                                contentDescription = null,
                                                tint = IndigoPrimary,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        },
                                        onClick = {
                                            showExportMenu = false
                                            viewModel.exportCurrentReportCsv(context)
                                        },
                                        modifier = Modifier.testTag("export_csv_menu_item")
                                    )
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        },
        bottomBar = {
            if (isTopLevelDestination) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 1.dp
                ) {
                    bottomNavItems.forEach { screen ->
                        val selected = currentRoute == screen.route

                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                if (currentRoute != screen.route) {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                } else if (screen == Screen.Home) {
                                    coroutineScope.launch {
                                        homeListState.animateScrollToItem(0)
                                    }
                                }
                            },
                            icon = {
                                if (screen == Screen.Inbox && inboxBadgeCount > 0) {
                                    BadgedBox(
                                        badge = {
                                            Badge(
                                                containerColor = Rose500,
                                                contentColor = Color.White
                                            ) {
                                                Text("$inboxBadgeCount", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (selected) screen.selectedIcon else screen.unselectedIcon,
                                            contentDescription = screen.title
                                        )
                                    }
                                } else {
                                    Icon(
                                        imageVector = if (selected) screen.selectedIcon else screen.unselectedIcon,
                                        contentDescription = screen.title
                                    )
                                }
                            },
                            label = {
                                Text(
                                    text = screen.title,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 11.sp
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = IndigoPrimary,
                                selectedTextColor = IndigoPrimary,
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                indicatorColor = IndigoPrimary.copy(alpha = 0.12f)
                            ),
                            modifier = Modifier.testTag("nav_item_${screen.route}")
                        )
                    }
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            // 1. Home / Dashboard Screen
            composable(Screen.Home.route) {
                DashboardScreen(
                    viewModel = viewModel,
                    listState = homeListState,
                    onNavigateToMembers = { navController.navigate(Screen.Members.route) },
                    onNavigateToMonthly = { navController.navigate("monthly") },
                    onNavigateToDues = { navController.navigate("dues") },
                    onNavigateToReports = { navController.navigate(Screen.Reports.route) },
                    onNavigateToRecordPayment = { navController.navigate("record_payment/0") },
                    onNavigateToAddMember = { navController.navigate("add_member") },
                    onNavigateToMemberProfile = { id -> navController.navigate("member_profile/$id") },
                    onNavigateToLoans = { navController.navigate("loans") },
                    onNavigateToInvestments = { navController.navigate("investments") },
                    onNavigateToFeedback = { navController.navigate("feedback") },
                    onNavigateToLedger = { navController.navigate("ledger") },
                    onNavigateToInbox = { navController.navigate(Screen.Inbox.route) },
                    onNavigateToAuctionDetails = { cycleNo -> navController.navigate("auction_details/${cycleNo ?: 0}") },
                    onNavigateToChitMyContribution = { navController.navigate("chit_my_contribution") },
                    onNavigateToChitCollection = { cycleNo ->
                        if (cycleNo != null && cycleNo > 0) {
                            navController.navigate("chit_collection/$cycleNo")
                        } else {
                            navController.navigate("chit_collection")
                        }
                    }
                )
            }

            // 2. Inbox (Combined Chat, Notices, Alerts & Reminders)
            composable(Screen.Inbox.route) {
                InboxScreen(
                    viewModel = viewModel,
                    onNavigateToRoute = { route -> navController.navigate(route) },
                    onNavigateToMemberProfile = { id -> navController.navigate("member_profile/$id") }
                )
            }

            // 3. Members List Screen
            composable(Screen.Members.route) {
                MembersScreen(
                    viewModel = viewModel,
                    onNavigateToAddMember = { navController.navigate("add_member") },
                    onNavigateToEditMember = { id -> navController.navigate("edit_member/$id") },
                    onNavigateToProfile = { id -> navController.navigate("member_profile/$id") },
                    onNavigateToRecordPayment = { id -> navController.navigate("record_payment/$id") }
                )
            }

            // 4. Reports Screen
            composable(Screen.Reports.route) {
                ReportsScreen(
                    viewModel = viewModel,
                    onNavigateToLedger = { navController.navigate("ledger") },
                    onNavigateToAuction = { cycleNumber -> navController.navigate("auction_details/$cycleNumber") },
                    onNavigateToAuctionReview = { cycleNumber -> navController.navigate("auction_result_review/$cycleNumber") },
                    onNavigateToMember = { memberId -> navController.navigate("member_profile/$memberId") }
                )
            }

            // 5. More Screen (Loans, Investments, Feedback, Ledger, Settings, Backup, Profile)
            composable(Screen.More.route) {
                MoreScreen(
                    viewModel = viewModel,
                    onNavigateToLoans = { navController.navigate("loans") },
                    onNavigateToInvestments = { navController.navigate("investments") },
                    onNavigateToFeedback = { navController.navigate("feedback") },
                    onNavigateToLedger = { navController.navigate("ledger") },
                    onNavigateToMonthly = { navController.navigate("monthly") },
                    onNavigateToDues = { navController.navigate("dues") },
                    onNavigateToSettings = {
                        viewModel.requestAdminAction {
                            navController.navigate("settings")
                        }
                    },
                    onNavigateToBackup = {
                        viewModel.requestAdminAction {
                            navController.navigate("backup_restore")
                        }
                    },
                    onNavigateToMyProfile = { id -> navController.navigate("member_profile/$id") },
                    onNavigateToMembers = { navController.navigate(Screen.Members.route) },
                    onNavigateToAddMember = { navController.navigate("add_member") },
                    onNavigateToCreateGroup = { navController.navigate("create_group") },
                    onNavigateToEditGroup = { groupId -> navController.navigate("edit_group/$groupId") },
                    onNavigateToUserProfile = { navController.navigate("user_profile") },
                    onNavigateToContentManagement = { navController.navigate("admin_content_management") },
                    onNavigateToDemoSetup = { navController.navigate("demo_group_setup") },
                    onNavigateToAdminControl = {
                        viewModel.requestAdminAction {
                            navController.navigate("admin_control")
                        }
                    },
                    onNavigateToExceptions = {
                        viewModel.requestAdminAction {
                            navController.navigate("admin_exceptions")
                        }
                    }
                )
            }

            // 6. Loans & 70% Voting Screen
            composable("loans") {
                LoansScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // 7. Group Investments Portfolio Screen
            composable("investments") {
                InvestmentsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // 8. Proposals, Suggestions & Complaints Screen (Redirected to Tab 3 Community of Communication Hub)
            composable("feedback") {
                InboxScreen(
                    viewModel = viewModel,
                    onNavigateToRoute = { route -> navController.navigate(route) },
                    onNavigateToMemberProfile = { id -> navController.navigate("member_profile/$id") },
                    initialTab = 2,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // Admin Control & Governance
            composable("admin_control") {
                AdminControlScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToExceptions = { navController.navigate("admin_exceptions") }
                )
            }

            // Exception & Reconciliation Center
            composable("admin_exceptions") {
                ExceptionCenterScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // 9. Full Financial Transactions Ledger Screen
            composable("ledger") {
                TransactionLedgerScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // 10. Monthly Management Screen
            composable("monthly") {
                MonthlyManagementScreen(
                    viewModel = viewModel,
                    onNavigateToMemberProfile = { id -> navController.navigate("member_profile/$id") },
                    onNavigateToRecordPayment = { id -> navController.navigate("record_payment/$id") }
                )
            }

            // 11. Pending Dues Screen
            composable("dues") {
                PendingDuesScreen(
                    viewModel = viewModel,
                    onNavigateToRecordPayment = { id -> navController.navigate("record_payment/$id") },
                    onNavigateToMemberProfile = { id -> navController.navigate("member_profile/$id") }
                )
            }

            // 12. Add Member Screen
            composable("add_member") {
                AddEditMemberScreen(
                    memberId = 0L,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // 13. Edit Member Screen
            composable(
                route = "edit_member/{memberId}",
                arguments = listOf(navArgument("memberId") { type = NavType.LongType })
            ) { backStackEntry ->
                val memberId = backStackEntry.arguments?.getLong("memberId") ?: 0L
                AddEditMemberScreen(
                    memberId = memberId,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // 14. Member Profile Screen
            composable(
                route = "member_profile/{memberId}",
                arguments = listOf(navArgument("memberId") { type = NavType.LongType })
            ) { backStackEntry ->
                val memberId = backStackEntry.arguments?.getLong("memberId") ?: 0L
                MemberProfileScreen(
                    memberId = memberId,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToEdit = { id -> navController.navigate("edit_member/$id") },
                    onNavigateToRecordPayment = { id -> navController.navigate("record_payment/$id") }
                )
            }

            // 15. Record Payment Screen
            composable(
                route = "record_payment/{memberId}",
                arguments = listOf(navArgument("memberId") { type = NavType.LongType })
            ) { backStackEntry ->
                val memberId = backStackEntry.arguments?.getLong("memberId") ?: 0L
                RecordPaymentScreen(
                    preselectedMemberId = memberId,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // 16. Settings Screen
            composable("settings") {
                SettingsScreen(
                    viewModel = viewModel,
                    onNavigateToBackup = { navController.navigate("backup_restore") },
                    onNavigateToDemoSetup = { navController.navigate("demo_group_setup") }
                )
            }

            // 17. Backup & Restore Screen
            composable("backup_restore") {
                BackupRestoreScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // 18. Notifications Screen
            composable("notifications") {
                NotificationsScreen(
                    viewModel = viewModel,
                    onNavigateToRoute = { route -> navController.navigate(route) }
                )
            }

            // 19. Create Group Screen (Matching AddEditMemberScreen design)
            composable("create_group") {
                CreateNewGroupScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("edit_group/{groupId}") { backStackEntry ->
                val groupId = backStackEntry.arguments?.getString("groupId")?.toLongOrNull()
                CreateNewGroupScreen(
                    viewModel = viewModel,
                    editGroupId = groupId,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // 20. User Profile Details Screen (Matching AddEditMemberScreen design)
            composable("user_profile") {
                UserProfileDetailsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // 21. Admin Carousel Content Studio Screen (Platform-Level Carousel Management)
            composable("admin_content_management") {
                AdminContentManagementScreen(
                    societyViewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToCreate = { navController.navigate("add_edit_carousel/0") },
                    onNavigateToEdit = { carouselId -> navController.navigate("add_edit_carousel/$carouselId") }
                )
            }

            // 22. Add / Edit Carousel Slide Screen
            composable(
                route = "add_edit_carousel/{carouselId}",
                arguments = listOf(navArgument("carouselId") { type = NavType.StringType })
            ) { backStackEntry ->
                val carouselId = backStackEntry.arguments?.getString("carouselId") ?: "0"
                AddEditCarouselItemScreen(
                    carouselId = carouselId,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // 23. Group Setup & Multi-Category Settings Demo
            composable("demo_group_setup") {
                DemoGroupSetupScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onFinishDemo = { navController.popBackStack() },
                    onFinishSetup = { groupId ->
                        navController.navigate("home") {
                            popUpTo("home") { inclusive = true }
                        }
                    },
                    onNavigateToDemoHome = { category, subCategory, groupName ->
                        val encodedCat = java.net.URLEncoder.encode(category.name, "UTF-8")
                        val encodedSub = java.net.URLEncoder.encode(subCategory, "UTF-8")
                        val encodedName = java.net.URLEncoder.encode(groupName, "UTF-8")
                        navController.navigate("demo_group_home?categoryId=$encodedCat&subCategory=$encodedSub&groupName=$encodedName")
                    }
                )
            }

            // 24. Category-Aware Home Page Preview Demo
            composable(
                route = "demo_group_home?categoryId={categoryId}&subCategory={subCategory}&groupName={groupName}",
                arguments = listOf(
                    navArgument("categoryId") {
                        type = NavType.StringType
                        nullable = true
                        defaultValue = null
                    },
                    navArgument("subCategory") {
                        type = NavType.StringType
                        nullable = true
                        defaultValue = null
                    },
                    navArgument("groupName") {
                        type = NavType.StringType
                        nullable = true
                        defaultValue = null
                    }
                )
            ) { backStackEntry ->
                val rawCat = backStackEntry.arguments?.getString("categoryId")
                val rawSub = backStackEntry.arguments?.getString("subCategory")
                val rawName = backStackEntry.arguments?.getString("groupName")

                val cat = rawCat?.let {
                    val decoded = java.net.URLDecoder.decode(it, "UTF-8")
                    GroupCategory.entries.find { c ->
                        c.name.equals(decoded, ignoreCase = true) ||
                        c.id.equals(decoded, ignoreCase = true) ||
                        c.title.equals(decoded, ignoreCase = true)
                    }
                } ?: GroupCategory.SAVINGS_CREDIT_CHIT

                val sub = rawSub?.let { java.net.URLDecoder.decode(it, "UTF-8") } ?: "Chit Fund / BC"
                val name = rawName?.let { java.net.URLDecoder.decode(it, "UTF-8") } ?: "All services group"

                DemoHomeScreen(
                    initialCategory = cat,
                    initialSubCategory = sub,
                    initialGroupName = name,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToSetup = {
                        navController.navigate("demo_group_setup") {
                            launchSingleTop = true
                        }
                    }
                )
            }

            // 25. Chit Fund Auction Details & Scheduling Screen
            composable("auction_details") {
                AuctionDetailsScreen(
                    cycleNumber = null,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToResultReview = { cycleNo ->
                        navController.navigate("auction_result_review/$cycleNo")
                    }
                )
            }

            composable(
                route = "auction_details/{cycleNumber}",
                arguments = listOf(navArgument("cycleNumber") { type = NavType.IntType })
            ) { backStackEntry ->
                val cycleNum = backStackEntry.arguments?.getInt("cycleNumber")
                AuctionDetailsScreen(
                    cycleNumber = if (cycleNum != null && cycleNum > 0) cycleNum else null,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToResultReview = { cycleNo ->
                        navController.navigate("auction_result_review/$cycleNo")
                    }
                )
            }

            // 26. Phase B.4 & B.5 — Chit Fund Auction Result, Winner Determination & Financial Settlement Screen
            composable(
                route = "auction_result_review/{cycleNumber}",
                arguments = listOf(navArgument("cycleNumber") { type = NavType.IntType })
            ) { backStackEntry ->
                val cycleNum = backStackEntry.arguments?.getInt("cycleNumber") ?: 1
                AuctionResultReviewScreen(
                    cycleNumber = cycleNum,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToLedger = { navController.navigate("ledger") }
                )
            }

            // 27. Phase B.7 — Chit Fund Member Contribution Screen
            composable("chit_my_contribution") {
                ChitMemberContributionScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // 28. Phase B.7 — Chit Fund Admin Collection Tracker Screen
            composable("chit_collection") {
                ChitCollectionTrackerScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToMemberProfile = { memberId -> navController.navigate("member_profile/$memberId") }
                )
            }

            composable(
                route = "chit_collection/{cycleNumber}",
                arguments = listOf(navArgument("cycleNumber") { type = NavType.IntType })
            ) { backStackEntry ->
                val cycleNum = backStackEntry.arguments?.getInt("cycleNumber")
                ChitCollectionTrackerScreen(
                    viewModel = viewModel,
                    initialCycleNumber = cycleNum,
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToMemberProfile = { memberId -> navController.navigate("member_profile/$memberId") }
                )
            }
        }
    }

    // Admin PIN Security Dialog
    AdminPinDialog(
        isOpen = showPinDialog,
        onDismiss = { viewModel.dismissPinDialog() },
        onVerify = { pin ->
            viewModel.verifyPin(pin)
        }
    )
    }
}
