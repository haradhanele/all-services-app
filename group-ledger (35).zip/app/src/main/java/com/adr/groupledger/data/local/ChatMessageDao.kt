package com.adr.groupledger.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.adr.groupledger.data.model.GroupChatMessage
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM group_chat_messages WHERE groupId = :groupId ORDER BY timestamp ASC")
    fun getAllMessagesFlow(groupId: Long): Flow<List<GroupChatMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: GroupChatMessage): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessages(messages: List<GroupChatMessage>)

    @Query("DELETE FROM group_chat_messages WHERE id = :id")
    suspend fun deleteMessageById(id: Long)

    @Query("DELETE FROM group_chat_messages WHERE groupId = :groupId")
    suspend fun clearChat(groupId: Long)
}
