package com.adr.groupledger.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.MemberWithMonthlyStatus
import com.adr.groupledger.ui.components.MemberAvatarView
import com.adr.groupledger.ui.components.MonthPickerBar
import com.adr.groupledger.ui.components.StatusBadge
import com.adr.groupledger.ui.theme.BorderLight
import com.adr.groupledger.ui.theme.BorderSubtle
import com.adr.groupledger.ui.theme.CardWhite
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.StatusPaidText
import com.adr.groupledger.ui.theme.StatusUnpaidText
import com.adr.groupledger.ui.theme.TextSlate400
import com.adr.groupledger.ui.theme.TextSlate500
import com.adr.groupledger.ui.theme.TextSlate800
import com.adr.groupledger.ui.theme.appOutlinedTextFieldColors
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.utils.CurrencyFormatter
import com.adr.groupledger.utils.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonthlyManagementScreen(
    viewModel: SocietyViewModel,
    onNavigateToMemberProfile: (Long) -> Unit,
    onNavigateToRecordPayment: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()
    val summary by viewModel.currentMonthSummary.collectAsStateWithLifecycle()
    val membersList by viewModel.monthlyMembersList.collectAsStateWithLifecycle()
    val statusFilter by viewModel.statusFilter.collectAsStateWithLifecycle()
    val searchQuery by viewModel.memberSearchQuery.collectAsStateWithLifecycle()
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()

    var showExportMenu by remember { mutableStateOf(false) }

    // Quick Payment Sheet State
    var quickPayMember by remember { mutableStateOf<MemberWithMonthlyStatus?>(null) }

    Scaffold(
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 14.dp)
                .testTag("monthly_management_screen")
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Month Picker Bar
            MonthPickerBar(
                selectedMonth = selectedMonth,
                selectedYear = selectedYear,
                onPrevClick = { viewModel.prevMonth() },
                onNextClick = { viewModel.nextMonth() },
                onMonthYearSelected = { m, y -> viewModel.selectMonthYear(m, y) }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Month Summary Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderLight, RoundedCornerShape(12.dp))
                    .testTag("monthly_collection_summary_card"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = CardWhite
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${DateUtils.getMonthName(selectedMonth)} Financial Status",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextSlate800,
                            fontSize = 13.5.sp
                        )

                        Box {
                            IconButton(
                                onClick = { showExportMenu = true },
                                modifier = Modifier.size(28.dp).testTag("export_month_report_btn")
                            ) {
                                Icon(Icons.Default.FileDownload, contentDescription = "Export Report", tint = IndigoPrimary, modifier = Modifier.size(17.dp))
                            }
                            DropdownMenu(
                                expanded = showExportMenu,
                                onDismissRequest = { showExportMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Export PDF Report") },
                                    leadingIcon = { Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = IndigoPrimary) },
                                    onClick = {
                                        showExportMenu = false
                                        viewModel.exportMonthlyReportPdf(context)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Export CSV Spreadsheet") },
                                    leadingIcon = { Icon(Icons.Default.TableChart, contentDescription = null, tint = IndigoPrimary) },
                                    onClick = {
                                        showExportMenu = false
                                        viewModel.exportMonthlyReportCsv(context)
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("EXPECTED", style = MaterialTheme.typography.labelSmall, color = TextSlate400, fontWeight = FontWeight.Bold, fontSize = 9.sp, letterSpacing = 0.5.sp)
                            Text(
                                text = CurrencyFormatter.format(summary.totalExpected, settings.currencySymbol),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextSlate800,
                                fontSize = 13.5.sp
                            )
                        }
                        Column {
                            Text("COLLECTED", style = MaterialTheme.typography.labelSmall, color = TextSlate400, fontWeight = FontWeight.Bold, fontSize = 9.sp, letterSpacing = 0.5.sp)
                            Text(
                                text = CurrencyFormatter.format(summary.totalCollected, settings.currencySymbol),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = StatusPaidText,
                                fontSize = 13.5.sp
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("PENDING DUES", style = MaterialTheme.typography.labelSmall, color = TextSlate400, fontWeight = FontWeight.Bold, fontSize = 9.sp, letterSpacing = 0.5.sp)
                            Text(
                                text = CurrencyFormatter.format(summary.totalDue, settings.currencySymbol),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = StatusUnpaidText,
                                fontSize = 13.5.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("monthly_search_input"),
                placeholder = { Text("Search members in this month...", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.5.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp)) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setSearchQuery("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                colors = appOutlinedTextFieldColors()
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Filter Chips (All, Paid, Partial, Unpaid)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    "ALL" to "All (${summary.totalMembers})",
                    "PAID" to "Paid (${summary.paidCount})",
                    "PARTIAL" to "Partial (${summary.partialCount})",
                    "UNPAID" to "Unpaid (${summary.unpaidCount})"
                ).forEach { (key, label) ->
                    val isSelected = statusFilter == key
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.setStatusFilter(key) },
                        label = { Text(label, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium, fontSize = 11.5.sp) },
                        shape = RoundedCornerShape(8.dp),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = IndigoPrimary,
                            selectedLabelColor = Color.White,
                            containerColor = CardWhite,
                            labelColor = TextSlate800
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) IndigoPrimary else BorderSubtle
                        ),
                        modifier = Modifier.testTag("filter_chip_$key")
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Members Table / List
            if (membersList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No members match filter",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSlate500
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(membersList, key = { it.member.id }) { item ->
                        MonthlyMemberRowItem(
                            item = item,
                            currencySymbol = settings.currencySymbol,
                            onCardClick = { onNavigateToMemberProfile(item.member.id) },
                            onQuickPayClick = {
                                if (item.status == "PAID") {
                                    onNavigateToRecordPayment(item.member.id)
                                } else {
                                    quickPayMember = item
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    // Quick Payment Bottom Sheet
    if (quickPayMember != null) {
        val memberItem = quickPayMember!!
        var quickAmount by remember { mutableStateOf(memberItem.dueAmount.toString()) }
        var quickMethod by remember { mutableStateOf("Cash") }
        var quickRef by remember { mutableStateOf("") }
        var quickNotes by remember { mutableStateOf("Monthly contribution") }

        ModalBottomSheet(
            onDismissRequest = { quickPayMember = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = CardWhite
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
                    .padding(bottom = 32.dp)
                    .testTag("quick_payment_sheet"),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    MemberAvatarView(name = memberItem.member.name, size = 48.dp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = memberItem.member.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextSlate800
                        )
                        Text(
                            text = "Month: ${DateUtils.getMonthName(selectedMonth)} $selectedYear • Due: ${CurrencyFormatter.format(memberItem.dueAmount, settings.currencySymbol)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSlate500
                        )
                    }
                }

                // Amount Input
                OutlinedTextField(
                    value = quickAmount,
                    onValueChange = { quickAmount = it },
                    label = { Text("Payment Amount (${settings.currencySymbol})") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("quick_pay_amount_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                // Method Selector Chips
                Text("Payment Method", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = TextSlate800)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Cash", "UPI", "Bank Transfer", "Cheque").forEach { method ->
                        val isSelected = quickMethod == method
                        FilterChip(
                            selected = isSelected,
                            onClick = { quickMethod = method },
                            label = { Text(method) },
                            shape = RoundedCornerShape(8.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = IndigoPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                // Reference / ID
                OutlinedTextField(
                    value = quickRef,
                    onValueChange = { quickRef = it },
                    label = { Text("Reference / UPI Txn ID (Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                // Submit Button
                Button(
                    onClick = {
                        val amount = quickAmount.toDoubleOrNull() ?: memberItem.dueAmount
                        viewModel.quickMarkPaid(
                            memberId = memberItem.member.id,
                            month = selectedMonth,
                            year = selectedYear,
                            amount = amount,
                            paymentMethod = quickMethod,
                            reference = quickRef.trim(),
                            notes = quickNotes.trim()
                        )
                        quickPayMember = null
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("submit_quick_pay_btn"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Confirm Payment", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        }
    }
}

@Composable
fun MonthlyMemberRowItem(
    item: MemberWithMonthlyStatus,
    currencySymbol: String,
    onCardClick: () -> Unit,
    onQuickPayClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, BorderLight, RoundedCornerShape(10.dp))
            .clickable(onClick = onCardClick)
            .testTag("month_member_row_${item.member.id}"),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    MemberAvatarView(name = item.member.name, size = 34.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = item.member.name,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = TextSlate800
                        )
                        Text(
                            text = item.member.memberCode.ifEmpty { "ID: ${item.member.id}" },
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSlate400,
                            fontSize = 10.5.sp
                        )
                    }
                }

                StatusBadge(status = item.status, compact = true)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Breakdown (Expected, Paid, Due)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Column {
                        Text("EXPECTED", style = MaterialTheme.typography.labelSmall, color = TextSlate400, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = CurrencyFormatter.format(item.effectiveExpectedAmount, currencySymbol),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.5.sp,
                            color = TextSlate800
                        )
                    }
                    Column {
                        Text("PAID", style = MaterialTheme.typography.labelSmall, color = TextSlate400, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = CurrencyFormatter.format(item.paidAmount, currencySymbol),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            color = if (item.paidAmount > 0) StatusPaidText else TextSlate800
                        )
                    }
                    if (item.dueAmount > 0) {
                        Column {
                            Text("DUE", style = MaterialTheme.typography.labelSmall, color = TextSlate400, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = CurrencyFormatter.format(item.dueAmount, currencySymbol),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp,
                                color = StatusUnpaidText
                            )
                        }
                    }
                }

                // Quick Pay / Action button
                Surface(
                    onClick = onQuickPayClick,
                    shape = RoundedCornerShape(6.dp),
                    color = if (item.status == "PAID") Color(0xFFF1F5F9) else IndigoPrimary,
                    modifier = Modifier.testTag("action_btn_${item.member.id}")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = if (item.status == "PAID") Icons.Default.Check else Icons.Default.Payments,
                            contentDescription = null,
                            tint = if (item.status == "PAID") IndigoPrimary else Color.White,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = if (item.status == "PAID") "Details" else "Pay Dues",
                            color = if (item.status == "PAID") IndigoPrimary else Color.White,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

