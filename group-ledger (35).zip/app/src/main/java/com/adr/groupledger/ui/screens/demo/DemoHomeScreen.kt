package com.adr.groupledger.ui.screens.demo

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Preview
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.adr.groupledger.data.model.ChitFundConfig
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.HomeModuleConfig
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.MemberWithMonthlyStatus
import com.adr.groupledger.data.model.MonthlySummary
import com.adr.groupledger.data.model.OverallGroupFinancials
import com.adr.groupledger.data.model.SocietyNotice
import com.adr.groupledger.data.model.carousel.CarouselItem
import com.adr.groupledger.ui.components.HomeNotificationItem
import com.adr.groupledger.ui.components.NotificationType
import com.adr.groupledger.ui.home.HomeTemplateContext
import com.adr.groupledger.ui.home.HomeTemplateResolver
import com.adr.groupledger.ui.home.template.HomeTemplateRegistry
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import java.util.Calendar

/**
 * Phase D.0.5: Restored Clean Group Setup Home Preview.
 *
 * Isolated visual preview displaying the selected (Category, Sub-Category)
 * without extra template-switching or creation buttons inside the preview topbar.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DemoHomeScreen(
    initialCategory: GroupCategory = GroupCategory.SAVINGS_CREDIT_CHIT,
    initialSubCategory: String = "Chit Fund / BC",
    initialGroupName: String = "All services group",
    onNavigateBack: () -> Unit = {},
    onNavigateToSetup: () -> Unit = {},
    viewModel: SocietyViewModel? = null,
    modifier: Modifier = Modifier
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val resolvedViewModel: SocietyViewModel = viewModel ?: run {
        val app = context.applicationContext as android.app.Application
        androidx.lifecycle.viewmodel.compose.viewModel(
            factory = SocietyViewModel.provideFactory(app)
        )
    }

    val selectedCategory by remember(initialCategory) { mutableStateOf(initialCategory) }
    val selectedSubCategory by remember(initialSubCategory) { mutableStateOf(initialSubCategory) }
    val groupName by remember(initialGroupName) { mutableStateOf(initialGroupName) }

    // 1. Construct representative GroupSettings encoded with the selected Category & Sub-Category
    val previewSettings = remember(selectedCategory, selectedSubCategory, groupName) {
        val base = GroupSettings(
            id = 9999L,
            groupName = groupName.ifBlank { selectedCategory.title },
            groupSubtitle = selectedSubCategory,
            groupType = selectedCategory.title,
            defaultContribution = if (selectedCategory == GroupCategory.SAVINGS_CREDIT_CHIT) 5000.0 else 500.0,
            isContributionEnabled = true,
            dueDayOfMonth = 10,
            adminName = "Group Admin",
            adminPhone = "+91 98765 43210"
        )
        // If Chit Fund, seed a structured preview ChitFundConfig
        val withChit = if (selectedCategory == GroupCategory.SAVINGS_CREDIT_CHIT &&
            (selectedSubCategory.contains("Chit", ignoreCase = true) || selectedSubCategory.contains("BC", ignoreCase = true))) {
            val sampleChit = ChitFundConfig(
                totalMembers = 10,
                monthlyInstallment = 5000.0,
                totalChits = 10,
                currentChitNo = 1,
                totalValue = 50000.0,
                frequency = "MONTHLY",
                auctionScheduleDay = 10,
                auctionTime = "08:00 PM",
                auctionDurationMinutes = 15,
                biddingVisibility = "OPEN",
                auctionRule = "HIGHEST_DISCOUNT"
            )
            ChitFundConfig.encodeIntoSettings(base, sampleChit)
        } else {
            base
        }
        HomeTemplateResolver.encodeCategoryIntoSettings(withChit, selectedCategory, selectedSubCategory)
    }

    // 2. Resolve (Category, SubCategory) and production HomeTemplate via SINGLE SOURCE OF TRUTH
    val (resolvedCategory, resolvedSubCategory) = remember(previewSettings) {
        HomeTemplateResolver.resolve(previewSettings)
    }

    val template = remember(resolvedCategory, resolvedSubCategory) {
        HomeTemplateRegistry.resolve(resolvedCategory, resolvedSubCategory)
    }

    // 3. Build realistic preview data for template rendering
    val cal = Calendar.getInstance()
    val currentMonth = cal.get(Calendar.MONTH) + 1
    val currentYear = cal.get(Calendar.YEAR)

    val previewFinancials = remember(selectedCategory) {
        val mult = if (selectedCategory == GroupCategory.SAVINGS_CREDIT_CHIT) 10.0 else 1.0
        OverallGroupFinancials(
            totalMembers = 10,
            activeMembers = 10,
            totalCollectedAllTime = 45000.0 * mult,
            totalDueAllTime = 5000.0 * mult,
            currentMonthCollected = 45000.0 * mult,
            currentMonthDue = 5000.0 * mult,
            currentMonthPaidCount = 9,
            currentMonthUnpaidCount = 1,
            currentMonthPartialCount = 0,
            previousMonthCollected = 40000.0 * mult,
            monthlyTrends = emptyList(),
            totalGroupAssets = 75000.0 * mult,
            availableInHandBalance = 12500.0 * mult,
            bankBalance = 62500.0 * mult,
            cashBalance = 12500.0 * mult
        )
    }

    val previewMonthSummary = remember(selectedCategory) {
        val mult = if (selectedCategory == GroupCategory.SAVINGS_CREDIT_CHIT) 10.0 else 1.0
        MonthlySummary(
            month = currentMonth,
            year = currentYear,
            monthName = "October",
            totalMembers = 10,
            totalExpected = 50000.0 * mult,
            totalCollected = 45000.0 * mult,
            totalDue = 5000.0 * mult,
            paidCount = 9,
            partialCount = 0,
            unpaidCount = 1,
            collectionPercentage = 90.0f
        )
    }

    val previewMembers = remember {
        listOf(
            Member(id = 1L, groupId = 9999L, name = "Rahul Sharma", phone = "9876543210", isActive = true),
            Member(id = 2L, groupId = 9999L, name = "Amit Verma", phone = "9876543211", isActive = true),
            Member(id = 3L, groupId = 9999L, name = "Sunil Roy", phone = "9876543212", isActive = true),
            Member(id = 4L, groupId = 9999L, name = "Deepak Patel", phone = "9876543213", isActive = true),
            Member(id = 5L, groupId = 9999L, name = "Pooja Das", phone = "9876543214", isActive = true)
        )
    }

    val previewMonthlyStatus = remember(previewMembers, selectedCategory) {
        val defaultAmount = if (selectedCategory == GroupCategory.SAVINGS_CREDIT_CHIT) 5000.0 else 500.0
        previewMembers.mapIndexed { idx, m ->
            MemberWithMonthlyStatus(
                member = m,
                payment = null,
                effectiveExpectedAmount = defaultAmount,
                paidAmount = if (idx == 4) 0.0 else defaultAmount,
                dueAmount = if (idx == 4) defaultAmount else 0.0,
                status = if (idx == 4) "UNPAID" else "PAID"
            )
        }
    }

    val previewNotifications = remember(resolvedCategory) {
        listOf(
            HomeNotificationItem(
                id = "prev-notif-1",
                type = NotificationType.NOTICE,
                title = "Setup Preview Mode",
                description = "Displaying interactive live preview for ${resolvedCategory.title} (${resolvedSubCategory})",
                categoryLabel = "Preview",
                accentColor = Emerald500,
                icon = Icons.Default.Preview,
                priority = 1,
                onClick = {}
            )
        )
    }

    val previewCarouselItems = remember {
        listOf(
            CarouselItem(
                id = "prev-car-1",
                title = "Welcome to Group Ledger",
                message = "Automated accounting, collections & member transparent ledger.",
                priority = 10
            )
        )
    }

    val previewListState = rememberLazyListState()

    // 4. Construct production-grade HomeTemplateContext
    val previewContext = remember(
        resolvedViewModel, previewSettings, resolvedCategory, resolvedSubCategory, previewFinancials,
        previewMonthSummary, previewMonthlyStatus, previewNotifications, previewCarouselItems
    ) {
        HomeTemplateContext(
            viewModel = resolvedViewModel,
            settings = previewSettings,
            category = resolvedCategory,
            subCategory = resolvedSubCategory,
            financials = previewFinancials,
            selectedMonth = currentMonth,
            selectedYear = currentYear,
            monthSummary = previewMonthSummary,
            recentTxns = emptyList(),
            isAdminUnlocked = true,
            loansWithVoting = emptyList(),
            pendingApprovals = emptyList(),
            feedbacksWithVotes = emptyList(),
            notices = listOf(
                SocietyNotice(
                    id = 1L,
                    groupId = 9999L,
                    title = "✨ Welcome to ${previewSettings.groupName}",
                    content = "The group ledger and monthly collection schedule have been initialized.",
                    category = "ANNOUNCEMENT",
                    author = "Admin"
                )
            ),
            homeModules = HomeModuleConfig.getDefaultModules(),
            activeCarouselItems = previewCarouselItems,
            notifications = previewNotifications,
            isRefreshing = false,
            listState = previewListState,
            membersWithMonthlyStatus = previewMonthlyStatus,
            currentUserMember = previewMembers.firstOrNull(),
            currentUserMonthlyStatus = previewMonthlyStatus.firstOrNull(),
            totalActiveMembersCount = previewMembers.size,
            onNavigateToMembers = onNavigateToSetup,
            onNavigateToMonthly = onNavigateToSetup,
            onNavigateToDues = onNavigateToSetup,
            onNavigateToReports = onNavigateToSetup,
            onNavigateToRecordPayment = onNavigateToSetup,
            onNavigateToAddMember = onNavigateToSetup,
            onNavigateToMemberProfile = { _ -> onNavigateToSetup() },
            onNavigateToLoans = onNavigateToSetup,
            onNavigateToInvestments = onNavigateToSetup,
            onNavigateToFeedback = onNavigateToSetup,
            onNavigateToLedger = onNavigateToSetup,
            onNavigateToInbox = onNavigateToSetup,
            onNavigateToAuctionDetails = { _ -> onNavigateToSetup() },
            onNavigateToChitMyContribution = onNavigateToSetup,
            onNavigateToChitCollection = { _ -> onNavigateToSetup() },
            onCategoryChangeRequest = null
        )
    }

    Scaffold(
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 3.dp,
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onNavigateBack,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("demo_home_back_btn")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back to Setup",
                                tint = IndigoPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Emerald500.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "LIVE SETUP PREVIEW",
                                        color = Emerald500,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = template.displayName,
                                    fontSize = 11.5.sp,
                                    color = IndigoPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Text(
                                text = resolvedCategory.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // Sub-category badge bar
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Sub-Category: ",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = resolvedSubCategory,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        },
        modifier = modifier
            .fillMaxSize()
            .testTag("demo_home_screen_unified")
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            if (resolvedCategory == GroupCategory.SAVINGS_CREDIT_CHIT &&
                (resolvedSubCategory.contains("Chit", ignoreCase = true) || resolvedSubCategory.contains("BC", ignoreCase = true))) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                ) {
                    ChitFundDashboardContent(
                        groupName = groupName.ifBlank { "Shakti Chit Fund" }
                    )
                }
            } else {
                template.Render(context = previewContext)
            }
        }
    }
}
