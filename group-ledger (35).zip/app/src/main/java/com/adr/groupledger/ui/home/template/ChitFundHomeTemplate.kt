package com.adr.groupledger.ui.home.template

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.adr.groupledger.data.model.ChitFundConfig
import com.adr.groupledger.ui.components.SamitiPullToRefreshBox
import com.adr.groupledger.ui.home.HomeTemplateContext
import com.adr.groupledger.ui.home.components.ChitFundConfigDialog
import com.adr.groupledger.ui.screens.demo.ChitFundDashboardContent
import com.adr.groupledger.utils.ChitCalculationEngine
import com.adr.groupledger.utils.CurrencyFormatter

/**
 * Level 1: Sub-category specialized template for Chit Fund / BC.
 *
 * Fully integrated with real group settings, membership roster,
 * monthly installment summaries, and configured auction cycles,
 * while utilizing the unified ChitFundDashboardContent visual design.
 */
object ChitFundHomeTemplate : GroupHomeTemplate {

    override val templateId: String = "chit_fund_home"
    override val displayName: String = "Chit Fund Home Template"

    @Composable
    override fun Render(context: HomeTemplateContext) {
        val curr = context.settings.currencySymbol.ifBlank { "₹" }
        var showConfigDialog by remember { mutableStateOf(false) }

        // 1. Resolve Chit Fund Configuration from Settings JSON & fallback fields
        val chitConfig = remember(context.settings.modulesConfigJson, context.settings.defaultContribution, context.settings.dueDayOfMonth) {
            ChitFundConfig.parseFromSettings(context.settings)
        }

        // 2. Derive Real Member Counts
        val totalMembers = context.monthSummary?.totalMembers
            ?: context.totalActiveMembersCount.takeIf { it > 0 }
            ?: context.financials.activeMembers.takeIf { it > 0 }
            ?: context.financials.totalMembers

        val paidMembers = context.monthSummary?.paidCount ?: context.financials.currentMonthPaidCount
        val partialMembers = context.monthSummary?.partialCount ?: context.financials.currentMonthPartialCount
        val pendingMembers = context.monthSummary?.unpaidCount ?: context.financials.currentMonthUnpaidCount

        // 3. Resolve Financial Metrics & Cycle Progress from Calculation Engine
        val monthlyInstallment = chitConfig.monthlyInstallment
            ?: context.settings.defaultContribution.takeIf { it > 0.0 } ?: 5000.0

        val totalMembersCalculated = chitConfig.totalMembers
            ?: totalMembers.takeIf { it > 0 }
            ?: chitConfig.totalChits
            ?: 20

        val totalChits = chitConfig.totalChits
            ?: if (totalMembersCalculated > 0) totalMembersCalculated else 20

        val currentChitNo = chitConfig.currentChitNo ?: 1

        val cycleMetrics = remember(chitConfig.cycles, totalChits, currentChitNo) {
            ChitCalculationEngine.deriveCycleMetrics(
                cycles = chitConfig.cycles,
                configuredTotalCycles = totalChits,
                currentChitNoOverride = currentChitNo
            )
        }

        val totalValue = chitConfig.totalValue
            ?: (totalMembersCalculated * monthlyInstallment)

        // Expected vs Collected for current period
        val expectedAmount = context.monthSummary?.totalExpected
            ?: (totalMembersCalculated * monthlyInstallment)

        val collectedAmount = context.monthSummary?.totalCollected
            ?: context.financials.currentMonthCollected

        val pendingAmount = (expectedAmount - collectedAmount).coerceAtLeast(0.0)

        // Auction date & schedule text
        val auctionScheduleText = remember(chitConfig, context.settings) {
            val day = chitConfig.auctionScheduleDay ?: context.settings.dueDayOfMonth.takeIf { it in 1..31 } ?: 28
            val time = chitConfig.auctionTime?.ifBlank { "08:00 PM" } ?: "08:00 PM"
            "${day}th of month, $time"
        }

        val auctionTimeText = chitConfig.auctionTime?.ifBlank { "08:00 PM" } ?: "08:00 PM"

        val currentUserMonthlyStatus = context.currentUserMonthlyStatus
        val userPaid = currentUserMonthlyStatus?.status.equals("PAID", ignoreCase = true)
        val userDividend = 0.0
        val effectivePayable = (monthlyInstallment - userDividend).coerceAtLeast(0.0)

        SamitiPullToRefreshBox(
            isRefreshing = context.isRefreshing,
            onRefresh = { context.viewModel.refreshDashboard() },
            modifier = Modifier.fillMaxSize()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                ChitFundDashboardContent(
                    groupName = context.settings.groupName.ifBlank { "Chit Fund Group" },
                    groupSubtitle = context.settings.groupSubtitle,
                    categoryTitle = context.category.title,
                    subCategory = context.subCategory,
                    isAdminUnlocked = context.isAdminUnlocked,
                    isPreviewMode = false,
                    totalChitValueText = "$curr${CurrencyFormatter.formatIndian(totalValue)}",
                    currentChitNo = cycleMetrics.currentCycleNumber,
                    totalChits = cycleMetrics.totalCycles.takeIf { it > 0 } ?: totalChits,
                    completedChits = cycleMetrics.completedCycles,
                    monthlyInstallmentText = "$curr${CurrencyFormatter.formatIndian(monthlyInstallment)}",
                    totalMembers = totalMembersCalculated,
                    cycleFrequency = chitConfig.frequency.ifBlank { "Monthly" },
                    startDateText = "January 2026",
                    expectedEndDateText = "August 2027",
                    auctionDateText = auctionScheduleText ?: "28 September 2026",
                    auctionTimeText = auctionTimeText,
                    expectedAmountText = "$curr${CurrencyFormatter.formatIndian(expectedAmount)}",
                    collectedAmountText = "$curr${CurrencyFormatter.formatIndian(collectedAmount)}",
                    pendingAmountText = "$curr${CurrencyFormatter.formatIndian(pendingAmount)}",
                    progressPercent = cycleMetrics.progressPercent.toFloat(),
                    paidMembersCount = paidMembers,
                    partialMembersCount = partialMembers,
                    pendingMembersCount = pendingMembers,
                    currentUserMemberName = context.currentUserMember?.name ?: "Member",
                    currentUserPaid = userPaid,
                    dividendSavingsText = "$curr${CurrencyFormatter.formatIndian(userDividend)}",
                    effectivePayableText = "$curr${CurrencyFormatter.formatIndian(effectivePayable)}",
                    onNavigateToAuctionRoom = {
                        context.onNavigateToAuctionDetails?.invoke(cycleMetrics.currentCycleNumber)
                            ?: context.onNavigateToInbox()
                    },
                    onNavigateToRecordPayment = {
                        context.onNavigateToChitMyContribution?.invoke()
                            ?: context.onNavigateToRecordPayment()
                    },
                    onNavigateToMembers = {
                        context.onNavigateToChitCollection?.invoke(cycleMetrics.currentCycleNumber)
                            ?: context.onNavigateToMembers()
                    },
                    onConfigureClick = if (context.isAdminUnlocked) { { showConfigDialog = true } } else null,
                    onNavigateToPassbook = {
                        context.onNavigateToAuctionDetails?.invoke(cycleMetrics.currentCycleNumber)
                            ?: context.onNavigateToInbox()
                    }
                )
            }
        }

        // Admin Chit Scheme Configuration Dialog
        if (showConfigDialog) {
            ChitFundConfigDialog(
                currentConfig = chitConfig,
                currencySymbol = curr,
                onDismiss = { showConfigDialog = false },
                onSave = { updatedConfig ->
                    val updatedSettings = ChitFundConfig.encodeIntoSettings(context.settings, updatedConfig)
                    context.viewModel.updateGroupSettings(updatedSettings)
                    showConfigDialog = false
                }
            )
        }
    }
}
