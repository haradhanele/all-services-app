package com.adr.groupledger.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import org.json.JSONArray
import org.json.JSONObject
import com.adr.groupledger.data.model.ChitFundConfig
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.HomeModuleConfig
import com.adr.groupledger.ui.components.ChitFundSettingsSection
import com.adr.groupledger.ui.components.ConfirmActionDialog
import com.adr.groupledger.ui.components.GroupCategorySelectorSection
import com.adr.groupledger.ui.home.HomeTemplateResolver
import com.adr.groupledger.ui.screens.demo.GroupCategory
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.appOutlinedTextFieldColors
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.utils.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateNewGroupScreen(
    viewModel: SocietyViewModel,
    onNavigateBack: () -> Unit,
    editGroupId: Long? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val allGroups by viewModel.allGroups.collectAsStateWithLifecycle()
    val activeGroupSettings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()

    val isEditMode = editGroupId != null && editGroupId > 0
    val targetEditGroup = remember(allGroups, activeGroupSettings, editGroupId) {
        if (isEditMode) {
            allGroups.find { it.id == editGroupId } ?: activeGroupSettings
        } else {
            null
        }
    }

    val isSignedUpUser = currentUser?.isAccountCompleted == true
    var showAccountCompletionGateModal by remember { mutableStateOf(!isEditMode && currentUser != null && !isSignedUpUser) }

    // Group Profile States
    var groupName by remember { mutableStateOf("") }
    var groupSubtitle by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var groupType by remember { mutableStateOf("Self-Help Group") }
    var address by remember { mutableStateOf("") }
    var contactPhone by remember { mutableStateOf("") }
    var contactEmail by remember { mutableStateOf("") }
    var currencySymbol by remember { mutableStateOf("₹") }

    val initialCatSub = remember(targetEditGroup) {
        HomeTemplateResolver.resolve(targetEditGroup)
    }
    var selectedCategory by remember { mutableStateOf(initialCatSub.first) }
    var selectedSubCategory by remember { mutableStateOf(initialCatSub.second) }
    var chitConfig by remember {
        mutableStateOf(
            if (targetEditGroup != null) ChitFundConfig.parseFromSettings(targetEditGroup)
            else ChitFundConfig(
                totalValue = 50000.0,
                totalChits = 20,
                monthlyInstallment = 2500.0,
                currentChitNo = 1,
                auctionScheduleDay = 15,
                auctionTime = "08:00 PM",
                auctionDurationMinutes = 60
            )
        )
    }

    val isChitFund = selectedCategory == GroupCategory.SAVINGS_CREDIT_CHIT &&
        (selectedSubCategory.contains("Chit", ignoreCase = true) || selectedSubCategory.contains("Rotating", ignoreCase = true))

    // Contribution States
    var isContributionEnabled by remember { mutableStateOf(true) }
    var defaultContribution by remember { mutableStateOf("500") }
    var contributionFrequency by remember { mutableStateOf("MONTHLY") }
    var dueDayOfMonth by remember { mutableStateOf("10") }
    var isLateFeeEnabled by remember { mutableStateOf(false) }
    var lateFineAmount by remember { mutableStateOf("50") }
    var gracePeriodDays by remember { mutableStateOf("5") }
    var paymentRules by remember { mutableStateOf("Contribution is due by the 10th of every month.") }

    // Invite Code State
    val chars = remember { "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" }
    var inviteCode by remember {
        mutableStateOf(
            targetEditGroup?.inviteCode?.takeIf { it.isNotBlank() }
                ?: (1..6).map { chars.random() }.joinToString("")
        )
    }

    // Home Modules Config State
    var homeModules by remember {
        mutableStateOf(
            if (targetEditGroup != null && targetEditGroup.modulesConfigJson.isNotBlank()) {
                HomeModuleConfig.parseModulesJson(targetEditGroup.modulesConfigJson)
            } else {
                HomeModuleConfig.getDefaultModules()
            }
        )
    }

    // UI Dialog States
    var showResetModulesConfirm by remember { mutableStateOf(false) }
    var renamingModule by remember { mutableStateOf<HomeModuleConfig?>(null) }
    var renameInputText by remember { mutableStateOf("") }
    var showAddCustomModuleDialog by remember { mutableStateOf(false) }
    var isSaving by remember { mutableStateOf(false) }

    // Populate initial fields
    LaunchedEffect(targetEditGroup, isEditMode) {
        if (isEditMode && targetEditGroup != null) {
            groupName = targetEditGroup.groupName
            groupSubtitle = targetEditGroup.groupSubtitle
            description = targetEditGroup.description
            groupType = targetEditGroup.groupType.ifBlank { "Self-Help Group" }
            address = targetEditGroup.address
            contactPhone = targetEditGroup.contactPhone
            contactEmail = targetEditGroup.contactEmail
            currencySymbol = targetEditGroup.currencySymbol.ifBlank { "₹" }

            val (cat, sub) = HomeTemplateResolver.resolve(targetEditGroup)
            selectedCategory = cat
            selectedSubCategory = sub
            chitConfig = ChitFundConfig.parseFromSettings(targetEditGroup)

            isContributionEnabled = targetEditGroup.isContributionEnabled
            defaultContribution = if (targetEditGroup.defaultContribution <= 0.0) "00" else targetEditGroup.defaultContribution.toInt().toString()
            contributionFrequency = targetEditGroup.contributionFrequency.ifBlank { "MONTHLY" }
            dueDayOfMonth = targetEditGroup.dueDayOfMonth.toString()
            isLateFeeEnabled = targetEditGroup.isLateFeeEnabled
            lateFineAmount = targetEditGroup.lateFineAmount.toInt().toString()
            gracePeriodDays = targetEditGroup.gracePeriodDays.toString()
            paymentRules = targetEditGroup.paymentRules

            inviteCode = targetEditGroup.inviteCode
            homeModules = HomeModuleConfig.parseModulesJson(targetEditGroup.modulesConfigJson)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isEditMode) "Edit Group Settings" else "Create New Group",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("create_group_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .testTag("create_new_group_screen"),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp)
        ) {
            // 1. Group Header Card (Neumorphic Dark Container)
            item {
                Text(
                    text = if (isEditMode) "Active Group Profile" else "New Group / Society Setup",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                        .testTag("group_header_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = IndigoPrimary.copy(alpha = 0.12f),
                                    modifier = Modifier.size(42.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Groups,
                                            contentDescription = null,
                                            tint = IndigoPrimary,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (groupName.isNotBlank()) groupName else if (isEditMode) "Group Settings" else "New Samiti / Society",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = if (groupSubtitle.isNotBlank()) groupSubtitle else "Configure ledger, contribution rules & home modules",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = IndigoPrimary.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = groupType.ifBlank { "Society" },
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = IndigoPrimary,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isEditMode) "Group ID: #${targetEditGroup?.id ?: 0}" else "Status: Ready to initialize",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "Code: $inviteCode",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = IndigoPrimary
                                )
                            }
                        }
                    }
                }
            }

            // 2. Group Profile Settings Section
            item {
                Text(
                    text = "Group Profile Settings",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = groupName,
                            onValueChange = { groupName = it },
                            label = { Text("Group / Society Name *") },
                            leadingIcon = { Icon(Icons.Default.AccountBalance, contentDescription = null, tint = IndigoPrimary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("settings_group_name_input"),
                            shape = RoundedCornerShape(10.dp),
                            colors = appOutlinedTextFieldColors()
                        )

                        OutlinedTextField(
                            value = groupSubtitle,
                            onValueChange = { groupSubtitle = it },
                            label = { Text("Tagline / Subtitle") },
                            placeholder = { Text("e.g. Monthly Savings & Welfare Society") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("settings_group_subtitle_input"),
                            shape = RoundedCornerShape(10.dp),
                            colors = appOutlinedTextFieldColors()
                        )

                        // Group Category & Sub-Category (Single Source of Truth)
                        GroupCategorySelectorSection(
                            selectedCategory = selectedCategory,
                            selectedSubCategory = selectedSubCategory,
                            onCategoryChanged = { cat, sub ->
                                selectedCategory = cat
                                selectedSubCategory = sub
                                groupType = cat.title
                            }
                        )

                        OutlinedTextField(
                            value = description,
                            onValueChange = { description = it },
                            label = { Text("Short Description / About") },
                            placeholder = { Text("Purpose and background of this samiti / group...") },
                            leadingIcon = { Icon(Icons.Default.Notes, contentDescription = null, tint = IndigoPrimary) },
                            minLines = 2,
                            maxLines = 3,
                            modifier = Modifier.fillMaxWidth().testTag("settings_description_input"),
                            shape = RoundedCornerShape(10.dp),
                            colors = appOutlinedTextFieldColors()
                        )

                        OutlinedTextField(
                            value = address,
                            onValueChange = { address = it },
                            label = { Text("Location / Address") },
                            placeholder = { Text("e.g. Village/Town, District, State") },
                            leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = IndigoPrimary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("settings_address_input"),
                            shape = RoundedCornerShape(10.dp),
                            colors = appOutlinedTextFieldColors()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = contactPhone,
                                onValueChange = { contactPhone = it },
                                label = { Text("Contact Phone") },
                                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = IndigoPrimary) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                modifier = Modifier.weight(1f).testTag("settings_contact_phone_input"),
                                shape = RoundedCornerShape(10.dp),
                                colors = appOutlinedTextFieldColors()
                            )

                            OutlinedTextField(
                                value = contactEmail,
                                onValueChange = { contactEmail = it },
                                label = { Text("Contact Email") },
                                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = IndigoPrimary) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                singleLine = true,
                                modifier = Modifier.weight(1f).testTag("settings_contact_email_input"),
                                shape = RoundedCornerShape(10.dp),
                                colors = appOutlinedTextFieldColors()
                            )
                        }

                        if (isEditMode && targetEditGroup != null && targetEditGroup.createdAt > 0) {
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Established: ${DateUtils.formatDate(targetEditGroup.createdAt)}",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 2.1 Conditional Chit Fund & Auction Settings (Shown only for Chit Fund sub-category)
            if (isChitFund) {
                item {
                    Text(
                        text = "Chit Fund Scheme & Auction Configuration",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    ChitFundSettingsSection(
                        chitConfig = chitConfig,
                        currencySymbol = currencySymbol.ifBlank { "₹" },
                        isAdmin = true,
                        onConfigChanged = { updatedCfg ->
                            chitConfig = updatedCfg
                            if (updatedCfg.monthlyInstallment != null && updatedCfg.monthlyInstallment > 0) {
                                defaultContribution = updatedCfg.monthlyInstallment.toInt().toString()
                            }
                            if (updatedCfg.auctionScheduleDay != null && updatedCfg.auctionScheduleDay in 1..31) {
                                dueDayOfMonth = updatedCfg.auctionScheduleDay.toString()
                            }
                            if (updatedCfg.frequency.isNotBlank()) {
                                contributionFrequency = updatedCfg.frequency
                            }
                        }
                    )
                }
            }

            // 3. Contribution Configuration Settings Section
            item {
                Text(
                    text = "Contribution Configuration",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Enable/Disable Contribution toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Enable Group Contribution",
                                    fontWeight = FontWeight.SemiBold,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (isContributionEnabled) "Active • Monthly/Periodic collections enabled" else "Disabled • Society does not collect regular dues",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (isContributionEnabled) Emerald500 else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = isContributionEnabled,
                                onCheckedChange = { isContributionEnabled = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = IndigoPrimary, checkedTrackColor = IndigoPrimary.copy(alpha = 0.3f)),
                                modifier = Modifier.testTag("settings_contribution_switch")
                            )
                        }

                        if (isContributionEnabled) {
                            OutlinedTextField(
                                value = defaultContribution,
                                onValueChange = { defaultContribution = it },
                                label = { Text("Contribution Amount (₹) *") },
                                leadingIcon = { Icon(Icons.Default.Payment, contentDescription = null, tint = IndigoPrimary) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("settings_default_contribution_input"),
                                shape = RoundedCornerShape(10.dp),
                                colors = appOutlinedTextFieldColors()
                            )

                            // Frequency Selector
                            Column {
                                Text(
                                    text = "Collection Frequency",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                val frequencies = listOf("MONTHLY", "WEEKLY", "YEARLY", "CUSTOM")
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    frequencies.forEach { freq ->
                                        val isSelected = contributionFrequency == freq
                                        FilterChip(
                                            selected = isSelected,
                                            onClick = { contributionFrequency = freq },
                                            label = { Text(freq.lowercase().replaceFirstChar { it.uppercase() }, fontSize = 12.sp) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = IndigoPrimary,
                                                selectedLabelColor = Color.White
                                            ),
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }

                            // Due Day of Month
                            OutlinedTextField(
                                value = dueDayOfMonth,
                                onValueChange = { if (it.length <= 2) dueDayOfMonth = it },
                                label = { Text("Payment Due Day (1 - 31)") },
                                placeholder = { Text("e.g. 10") },
                                leadingIcon = { Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = IndigoPrimary) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("settings_due_day_input"),
                                shape = RoundedCornerShape(10.dp),
                                colors = appOutlinedTextFieldColors()
                            )

                            // Late Fine / Missed Penalty Settings
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "Late Fee / Missed Penalty",
                                                fontWeight = FontWeight.SemiBold,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "Apply fine for delayed payments after grace period",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Switch(
                                            checked = isLateFeeEnabled,
                                            onCheckedChange = { isLateFeeEnabled = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = IndigoPrimary, checkedTrackColor = IndigoPrimary.copy(alpha = 0.3f))
                                        )
                                    }

                                    if (isLateFeeEnabled) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            OutlinedTextField(
                                                value = lateFineAmount,
                                                onValueChange = { lateFineAmount = it },
                                                label = { Text("Fine Amount (₹)") },
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                singleLine = true,
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                colors = appOutlinedTextFieldColors()
                                            )

                                            OutlinedTextField(
                                                value = gracePeriodDays,
                                                onValueChange = { gracePeriodDays = it },
                                                label = { Text("Grace Period (Days)") },
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                singleLine = true,
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                colors = appOutlinedTextFieldColors()
                                            )
                                        }
                                    }
                                }
                            }

                            // Payment Rules Description
                            OutlinedTextField(
                                value = paymentRules,
                                onValueChange = { paymentRules = it },
                                label = { Text("Group Rules & Contribution Notes") },
                                placeholder = { Text("Describe due dates, bank transfer rules, fine exemptions, etc.") },
                                leadingIcon = { Icon(Icons.Default.Notes, contentDescription = null, tint = IndigoPrimary) },
                                minLines = 2,
                                maxLines = 4,
                                modifier = Modifier.fillMaxWidth().testTag("settings_rules_input"),
                                shape = RoundedCornerShape(10.dp),
                                colors = appOutlinedTextFieldColors()
                            )
                        }
                    }
                }
            }

            // 4. Home Page Modules & Services Carousel Management (Group Specific)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Home Modules & Services",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Enable, rename, and reorder cards on the Home Dashboard for this group",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))

                // Module Action Buttons: Add Custom Module & Reset
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { showAddCustomModuleDialog = true },
                        modifier = Modifier.weight(1f).height(40.dp).testTag("add_custom_module_btn"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Custom Card", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { showResetModulesConfirm = true },
                        modifier = Modifier.weight(1f).height(40.dp).testTag("reset_modules_btn"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Reset Modules", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))

                // List of Modules
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        val sortedModules = homeModules.sortedBy { it.orderIndex }
                        sortedModules.forEachIndexed { index, mod ->
                            val isFirst = index == 0
                            val isLast = index == sortedModules.size - 1

                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("module_item_${mod.key}"),
                                shape = RoundedCornerShape(10.dp),
                                color = if (mod.isEnabled) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.12f),
                                border = BorderStroke(1.dp, if (mod.isEnabled) IndigoPrimary.copy(alpha = 0.25f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    // Icon & Title & Tag
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Surface(
                                            shape = CircleShape,
                                            color = if (mod.isEnabled) IndigoPrimary.copy(alpha = 0.12f) else Color.Gray.copy(alpha = 0.12f),
                                            modifier = Modifier.size(34.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = resolveLocalModuleIcon(mod.iconName),
                                                    contentDescription = null,
                                                    tint = if (mod.isEnabled) IndigoPrimary else Color.Gray,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = mod.getDisplayName(),
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.5.sp,
                                                    color = if (mod.isEnabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                if (mod.customName.isNotBlank() && mod.customName != mod.defaultName) {
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        text = "(${mod.defaultName})",
                                                        fontSize = 10.5.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text(
                                                    text = mod.description.ifBlank { "Home module" },
                                                    fontSize = 10.5.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1
                                                )
                                                if (mod.isCustom) {
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = Emerald500.copy(alpha = 0.15f)
                                                    ) {
                                                        Text("Custom", fontSize = 9.sp, color = Emerald500, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    // Action Controls: Move Up/Down, Rename, Toggle Switch, Delete (if custom)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        // Move Up
                                        IconButton(
                                            onClick = {
                                                if (!isFirst) {
                                                    val currentIdx = mod.orderIndex
                                                    val prevMod = sortedModules[index - 1]
                                                    val prevIdx = prevMod.orderIndex
                                                    homeModules = homeModules.map {
                                                        when (it.key) {
                                                            mod.key -> it.copy(orderIndex = prevIdx)
                                                            prevMod.key -> it.copy(orderIndex = currentIdx)
                                                            else -> it
                                                        }
                                                    }
                                                    if (isEditMode) {
                                                        viewModel.moveModule(mod.key, -1)
                                                    }
                                                }
                                            },
                                            enabled = !isFirst,
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.ArrowUpward,
                                                contentDescription = "Move Up",
                                                tint = if (!isFirst) IndigoPrimary else Color.LightGray,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }

                                        // Move Down
                                        IconButton(
                                            onClick = {
                                                if (!isLast) {
                                                    val currentIdx = mod.orderIndex
                                                    val nextMod = sortedModules[index + 1]
                                                    val nextIdx = nextMod.orderIndex
                                                    homeModules = homeModules.map {
                                                        when (it.key) {
                                                            mod.key -> it.copy(orderIndex = nextIdx)
                                                            nextMod.key -> it.copy(orderIndex = currentIdx)
                                                            else -> it
                                                        }
                                                    }
                                                    if (isEditMode) {
                                                        viewModel.moveModule(mod.key, 1)
                                                    }
                                                }
                                            },
                                            enabled = !isLast,
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.ArrowDownward,
                                                contentDescription = "Move Down",
                                                tint = if (!isLast) IndigoPrimary else Color.LightGray,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }

                                        // Rename Button
                                        IconButton(
                                            onClick = {
                                                renamingModule = mod
                                                renameInputText = mod.customName.ifBlank { mod.defaultName }
                                            },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Edit,
                                                contentDescription = "Rename",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(15.dp)
                                            )
                                        }

                                        // Delete if Custom
                                        if (mod.isCustom) {
                                            IconButton(
                                                onClick = {
                                                    homeModules = homeModules.filter { it.key != mod.key }
                                                    if (isEditMode) {
                                                        viewModel.deleteCustomModule(mod.key)
                                                    }
                                                },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(
                                                    Icons.Default.Delete,
                                                    contentDescription = "Delete",
                                                    tint = Rose500,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(4.dp))

                                        // Enable/Disable Switch
                                        Switch(
                                            checked = mod.isEnabled,
                                            onCheckedChange = { isChecked ->
                                                homeModules = homeModules.map {
                                                    if (it.key == mod.key) it.copy(isEnabled = isChecked) else it
                                                }
                                                if (isEditMode) {
                                                    viewModel.toggleModule(mod.key, isChecked)
                                                }
                                            },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = IndigoPrimary,
                                                checkedTrackColor = IndigoPrimary.copy(alpha = 0.3f)
                                            ),
                                            modifier = Modifier.size(36.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 5. Group Invitation & Joining Code Card
            item {
                Text(
                    text = "Group Invitation & Joining Code",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                        .testTag("settings_invite_code_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Key,
                                    contentDescription = null,
                                    tint = IndigoPrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "Current Invitation Code",
                                        fontWeight = FontWeight.SemiBold,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Share this code for members to join this group",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        // Monospace Invitation Code Display Box
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = IndigoPrimary.copy(alpha = 0.08f),
                            border = BorderStroke(1.5.dp, IndigoPrimary.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = inviteCode,
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        color = IndigoPrimary,
                                        letterSpacing = 2.sp
                                    )
                                    Text(
                                        text = "Active & valid for registration",
                                        fontSize = 11.sp,
                                        color = Emerald500,
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    IconButton(
                                        onClick = {
                                            clipboardManager.setText(AnnotatedString(inviteCode))
                                            Toast.makeText(context, "Invite code copied to clipboard", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.testTag("copy_invite_code_btn")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ContentCopy,
                                            contentDescription = "Copy Code",
                                            tint = IndigoPrimary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            val shareIntent = Intent().apply {
                                                action = Intent.ACTION_SEND
                                                putExtra(
                                                    Intent.EXTRA_TEXT,
                                                    "Join our '${groupName.ifBlank { "Society" }}' on the Samiti App using Invitation Code: $inviteCode"
                                                )
                                                type = "text/plain"
                                            }
                                            context.startActivity(Intent.createChooser(shareIntent, "Share Group Invite Code"))
                                        },
                                        modifier = Modifier.testTag("share_invite_code_btn")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Share,
                                            contentDescription = "Share Code",
                                            tint = IndigoPrimary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }

                        OutlinedButton(
                            onClick = {
                                val freshCode = (1..6).map { chars.random() }.joinToString("")
                                inviteCode = freshCode
                                if (isEditMode) {
                                    viewModel.regenerateGroupInviteCode { newCode ->
                                        inviteCode = newCode
                                        Toast.makeText(context, "New invitation code generated: $newCode", Toast.LENGTH_LONG).show()
                                    }
                                } else {
                                    Toast.makeText(context, "New invitation code generated: $freshCode", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(42.dp)
                                .testTag("generate_new_invite_code_btn"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = IndigoPrimary)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Generate New Invitation Code",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // 6. Save / Create Primary Button
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        if (groupName.isBlank()) {
                            Toast.makeText(context, "Please enter a valid group name", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        val amount = if (isChitFund && (chitConfig.monthlyInstallment ?: 0.0) > 0.0) {
                            chitConfig.monthlyInstallment ?: (defaultContribution.toDoubleOrNull() ?: 500.0)
                        } else {
                            defaultContribution.toDoubleOrNull() ?: 500.0
                        }
                        val dueDay = if (isChitFund && chitConfig.auctionScheduleDay != null && chitConfig.auctionScheduleDay in 1..31) {
                            chitConfig.auctionScheduleDay!!
                        } else {
                            dueDayOfMonth.toIntOrNull()?.coerceIn(1, 31) ?: 10
                        }
                        val fineAmt = lateFineAmount.toDoubleOrNull() ?: 50.0
                        val graceDays = gracePeriodDays.toIntOrNull() ?: 5

                        // Construct modulesConfigJson with explicit category, subCategory, modules and chitConfig
                        val jsonObject = try {
                            if (targetEditGroup != null && targetEditGroup.modulesConfigJson.trim().startsWith("{")) {
                                JSONObject(targetEditGroup.modulesConfigJson)
                            } else {
                                JSONObject()
                            }
                        } catch (e: Exception) {
                            JSONObject()
                        }
                        jsonObject.put("category", selectedCategory.id)
                        jsonObject.put("subCategory", selectedSubCategory)
                        val modulesArray = JSONArray()
                        homeModules.sortedBy { it.orderIndex }.forEach { modulesArray.put(it.toJson()) }
                        jsonObject.put("modules", modulesArray)
                        if (isChitFund) {
                            val syncedChitConfig = chitConfig.copy(
                                monthlyInstallment = amount,
                                auctionScheduleDay = dueDay
                            )
                            jsonObject.put("chitConfig", syncedChitConfig.toJson())
                        }
                        val serializedModules = jsonObject.toString()

                        isSaving = true

                        if (isEditMode && targetEditGroup != null) {
                            val updated = targetEditGroup.copy(
                                groupName = groupName.trim(),
                                groupSubtitle = groupSubtitle.trim(),
                                description = description.trim(),
                                groupType = selectedCategory.title,
                                address = address.trim(),
                                contactPhone = contactPhone.trim(),
                                contactEmail = contactEmail.trim(),
                                inviteCode = inviteCode.trim(),
                                isContributionEnabled = isContributionEnabled,
                                defaultContribution = amount,
                                currencySymbol = currencySymbol.trim().ifBlank { "₹" },
                                contributionFrequency = contributionFrequency.trim().ifBlank { "MONTHLY" },
                                dueDayOfMonth = dueDay,
                                isLateFeeEnabled = isLateFeeEnabled,
                                lateFineAmount = fineAmt,
                                gracePeriodDays = graceDays,
                                paymentRules = paymentRules.trim(),
                                modulesConfigJson = serializedModules
                            )
                            viewModel.updateSpecificGroup(updated) {
                                isSaving = false
                                Toast.makeText(context, "Group '${groupName.trim()}' settings updated successfully!", Toast.LENGTH_SHORT).show()
                                onNavigateBack()
                            }
                        } else {
                            viewModel.createNewGroup(
                                groupName = groupName.trim(),
                                groupSubtitle = groupSubtitle.trim(),
                                groupType = selectedCategory.title,
                                description = description.trim(),
                                address = address.trim(),
                                contactPhone = contactPhone.trim(),
                                contactEmail = contactEmail.trim(),
                                isContributionEnabled = isContributionEnabled,
                                defaultContribution = amount,
                                currencySymbol = currencySymbol.trim().ifBlank { "₹" },
                                contributionFrequency = contributionFrequency.trim().ifBlank { "MONTHLY" },
                                dueDayOfMonth = dueDay,
                                isLateFeeEnabled = isLateFeeEnabled,
                                lateFineAmount = fineAmt,
                                gracePeriodDays = graceDays,
                                paymentRules = paymentRules.trim(),
                                modulesConfigJson = serializedModules,
                                inviteCode = inviteCode.trim(),
                                onSuccess = {
                                    isSaving = false
                                    Toast.makeText(context, "Group '${groupName.trim()}' created successfully!", Toast.LENGTH_SHORT).show()
                                    onNavigateBack()
                                }
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("save_group_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                    enabled = !isSaving
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (isEditMode) "Saving Changes..." else "Creating Group...",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    } else {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isEditMode) "Save All Settings" else "Create Group & Initialize Ledger",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }

        // Rename Module Dialog
        if (renamingModule != null) {
            AlertDialog(
                onDismissRequest = { renamingModule = null },
                title = { Text("Rename Home Module", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                text = {
                    Column {
                        Text(
                            text = "Set a custom display name for '${renamingModule?.defaultName}'",
                            fontSize = 12.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = renameInputText,
                            onValueChange = { renameInputText = it },
                            label = { Text("Display Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = appOutlinedTextFieldColors()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            renamingModule?.let { target ->
                                val newName = renameInputText.trim()
                                homeModules = homeModules.map {
                                    if (it.key == target.key) it.copy(customName = newName) else it
                                }
                                if (isEditMode) {
                                    viewModel.renameModule(target.key, newName)
                                }
                            }
                            renamingModule = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                    ) {
                        Text("Rename")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { renamingModule = null }) {
                        Text("Cancel")
                    }
                }
            )
        }

        // Add Custom Module Dialog
        if (showAddCustomModuleDialog) {
            var customName by remember { mutableStateOf("") }
            var customDesc by remember { mutableStateOf("") }
            var selectedIcon by remember { mutableStateOf("star") }

            val availableIcons = listOf(
                "star" to "Star",
                "celebration" to "Events",
                "store" to "Store / Bazaar",
                "work" to "Projects",
                "auto_awesome" to "Special",
                "receipt_long" to "Receipt",
                "chat" to "Discussion",
                "campaign" to "Announcement",
                "lightbulb" to "Idea",
                "help" to "Support",
                "savings" to "Reserve",
                "assignment" to "Task"
            )

            AlertDialog(
                onDismissRequest = { showAddCustomModuleDialog = false },
                title = { Text("Add Custom Home Module", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = customName,
                            onValueChange = { customName = it },
                            label = { Text("Card Name *") },
                            placeholder = { Text("e.g. Welfare Fund, Projects...") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = appOutlinedTextFieldColors()
                        )

                        OutlinedTextField(
                            value = customDesc,
                            onValueChange = { customDesc = it },
                            label = { Text("Short Subtitle / Description") },
                            placeholder = { Text("e.g. Community Welfare Schemes") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = appOutlinedTextFieldColors()
                        )

                        Text("Select Card Icon:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            availableIcons.forEach { (iconKey, label) ->
                                val isSel = selectedIcon == iconKey
                                FilterChip(
                                    selected = isSel,
                                    onClick = { selectedIcon = iconKey },
                                    leadingIcon = {
                                        Icon(resolveLocalModuleIcon(iconKey), contentDescription = null, modifier = Modifier.size(16.dp))
                                    },
                                    label = { Text(label, fontSize = 11.5.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = IndigoPrimary,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (customName.isNotBlank()) {
                                val key = "custom_${System.currentTimeMillis()}"
                                val newMod = HomeModuleConfig(
                                    key = key,
                                    defaultName = customName.trim(),
                                    customName = customName.trim(),
                                    description = customDesc.trim(),
                                    iconName = selectedIcon,
                                    isEnabled = true,
                                    orderIndex = (homeModules.maxOfOrNull { it.orderIndex } ?: 0) + 1,
                                    isCustom = true
                                )
                                homeModules = homeModules + newMod
                                if (isEditMode) {
                                    viewModel.addCustomModule(customName.trim(), customDesc.trim(), selectedIcon)
                                }
                                showAddCustomModuleDialog = false
                            } else {
                                Toast.makeText(context, "Please enter a card name", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                    ) {
                        Text("Add to Home")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddCustomModuleDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }

        // Reset Modules Confirm Dialog
        ConfirmActionDialog(
            isOpen = showResetModulesConfirm,
            title = "Reset Home Modules",
            message = "This will restore the standard default home modules order and visibility for this group.",
            confirmButtonText = "Reset Layout",
            isDestructive = false,
            onConfirm = {
                homeModules = HomeModuleConfig.getDefaultModules()
                if (isEditMode) {
                    viewModel.resetModulesToDefault()
                }
                showResetModulesConfirm = false
            },
            onDismiss = { showResetModulesConfirm = false }
        )

        // Gate modal for non-completed account users
        if (showAccountCompletionGateModal) {
            AlertDialog(
                onDismissRequest = {
                    showAccountCompletionGateModal = false
                    onNavigateBack()
                },
                title = { Text("Sign-up Required", fontWeight = FontWeight.Bold) },
                text = {
                    Text("To create and manage your own groups as an Admin, please complete the user sign-up registration first.")
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showAccountCompletionGateModal = false
                            onNavigateBack()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                    ) {
                        Text("Understood")
                    }
                }
            )
        }
    }
}

private fun resolveLocalModuleIcon(iconName: String): ImageVector {
    return when (iconName.lowercase()) {
        "payments" -> Icons.Default.Payments
        "group" -> Icons.Default.Groups
        "receipt_long" -> Icons.Default.ReceiptLong
        "account_balance" -> Icons.Default.AccountBalance
        "chat" -> Icons.Default.Chat
        "campaign" -> Icons.Default.Campaign
        "lightbulb" -> Icons.Default.Lightbulb
        "report_problem" -> Icons.Default.ReportProblem
        "help" -> Icons.Default.Help
        "event", "celebration" -> Icons.Default.Celebration
        "trending_up" -> Icons.Default.TrendingUp
        "handshake" -> Icons.Default.Handshake
        "savings" -> Icons.Default.Savings
        "check_circle" -> Icons.Default.CheckCircle
        "assignment" -> Icons.Default.Assignment
        "pie_chart" -> Icons.Default.PieChart
        "star" -> Icons.Default.Star
        "store" -> Icons.Default.Store
        "work" -> Icons.Default.Work
        "auto_awesome" -> Icons.Default.AutoAwesome
        else -> Icons.Default.Groups
    }
}
