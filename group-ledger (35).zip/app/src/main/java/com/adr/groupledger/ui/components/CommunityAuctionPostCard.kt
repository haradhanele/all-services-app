package com.adr.groupledger.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adr.groupledger.data.model.ChitAuctionCallStage
import com.adr.groupledger.data.model.ChitAuctionPostData
import com.adr.groupledger.data.model.ChitAuctionRules
import com.adr.groupledger.data.model.SocietyNotice
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoHeroDark
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.utils.ChitCalculationEngine
import com.adr.groupledger.utils.CurrencyFormatter
import com.adr.groupledger.utils.DateUtils
import org.json.JSONObject

/**
 * Phase D.0.1: Community Post based Chit Fund Auction Container.
 *
 * Embeds structured, authoritative Chit Fund Auction interaction right inside the
 * Community Post / Notice stream without creating an unnecessary disconnected Live Auction system.
 */
@Composable
fun CommunityAuctionPostCard(
    notice: SocietyNotice,
    isAdmin: Boolean = false,
    activeMemberId: Long = 1L,
    activeMemberName: String = "Member",
    onTogglePin: () -> Unit = {},
    onDelete: (() -> Unit)? = null,
    onNavigateToAuctionFloor: ((Int) -> Unit)? = null,
    onSubmitBid: ((cycleNo: Int, bidAmount: Double) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    // 1. Parse structured auction metadata from notice JSON or fallback heuristics
    val auctionData = remember(notice.pollVotesJson, notice.content) {
        val parsed = try {
            if (notice.pollVotesJson.isNotBlank() && notice.pollVotesJson.startsWith("{")) {
                ChitAuctionPostData.fromJson(JSONObject(notice.pollVotesJson))
            } else null
        } catch (e: Exception) {
            null
        }

        parsed ?: ChitAuctionPostData(
            cycleNumber = 1,
            totalChitValue = 50000.0,
            monthlyInstallment = 5000.0,
            currentHighestBid = 7000.0,
            minNextBid = 7500.0,
            callStage = ChitAuctionCallStage.OPEN,
            timeRemainingSeconds = 600L,
            bidsCount = 5,
            latestBidderName = "Sunil Roy",
            isAuctionLive = true
        )
    }

    var bidInputText by remember { mutableStateOf("") }
    var bidErrorMessage by remember { mutableStateOf<String?>(null) }
    var bidSuccessMessage by remember { mutableStateOf<String?>(null) }
    var showBidHistory by remember { mutableStateOf(false) }

    val callStageColor = when (auctionData.callStage) {
        ChitAuctionCallStage.OPEN -> Emerald500
        ChitAuctionCallStage.FIRST_CALL -> Amber500
        ChitAuctionCallStage.SECOND_CALL -> Amber500
        ChitAuctionCallStage.FINAL_CALL -> Rose500
        ChitAuctionCallStage.CLOSED -> Color(0xFF64748B)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("community_auction_post_${notice.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            1.5.dp,
            if (auctionData.isAuctionLive && auctionData.callStage.isBiddingAllowed) IndigoPrimary.copy(alpha = 0.6f)
            else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            // Gradient Header for Auction Post
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Color(0xFF1E1B4B),
                                Color(0xFF312E81),
                                Color(0xFF3730A3)
                            )
                        )
                    )
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Emerald500.copy(alpha = 0.25f),
                                border = BorderStroke(1.dp, Emerald500.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Gavel,
                                        contentDescription = null,
                                        tint = Emerald500,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "CHIT AUCTION",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Emerald500
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = callStageColor.copy(alpha = 0.25f),
                                border = BorderStroke(1.dp, callStageColor.copy(alpha = 0.6f))
                            ) {
                                Text(
                                    text = auctionData.callStage.displayName.uppercase(),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = callStageColor,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Text(
                            text = DateUtils.formatDisplayDate(notice.timestamp),
                            color = Color(0xFFA5B4FC),
                            fontSize = 11.sp
                        )
                    }

                    // Notice Title
                    Text(
                        text = notice.title.ifBlank { "🔨 Chit Fund Live Auction • Cycle #${auctionData.cycleNumber}" },
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }

            // Post Content & Metrics Body
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Notice text content
                if (notice.content.isNotBlank()) {
                    Text(
                        text = notice.content,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.5.sp,
                        lineHeight = 19.sp
                    )
                }

                // 3 Financial Metric Cards (Total Chit Value, Highest Bid / Discount, Min Next Bid)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("Chit Value", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                CurrencyFormatter.format(auctionData.totalChitValue),
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Emerald500.copy(alpha = 0.1f),
                        border = BorderStroke(1.dp, Emerald500.copy(alpha = 0.3f)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("Highest Bid (Disc)", fontSize = 10.5.sp, color = Emerald500)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                CurrencyFormatter.format(auctionData.currentHighestBid),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Emerald500
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = IndigoPrimary.copy(alpha = 0.1f),
                        border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.3f)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("Min Next Bid", fontSize = 10.5.sp, color = IndigoPrimary)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                CurrencyFormatter.format(auctionData.minNextBid),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = IndigoPrimary
                            )
                        }
                    }
                }

                // Winner Payout & Dividend estimation pill
                val winnerPayout = (auctionData.totalChitValue - auctionData.currentHighestBid).coerceAtLeast(0.0)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Winner Payout: ${CurrencyFormatter.format(winnerPayout)}",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (auctionData.latestBidderName.isNotBlank()) {
                            Text(
                                text = "Leader: ${auctionData.latestBidderName}",
                                fontSize = 11.5.sp,
                                color = Emerald500,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // Interactive Bid Action Section (if auction is open)
                if (auctionData.isAuctionLive && auctionData.callStage.isBiddingAllowed) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Submit Auction Bid (Discount)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.5.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Quick bid min increment chip
                            OutlinedButton(
                                onClick = {
                                    val nextBid = auctionData.minNextBid
                                    val rules = ChitAuctionRules(
                                        openingBid = 0.0,
                                        minBidIncrement = 500.0,
                                        currentCallStage = auctionData.callStage
                                    )
                                    val validation = ChitCalculationEngine.validateBidSubmission(
                                        bidAmount = nextBid,
                                        currentHighestBid = auctionData.currentHighestBid,
                                        rules = rules
                                    )
                                    if (validation.isValid) {
                                        bidErrorMessage = null
                                        bidSuccessMessage = "Bid ₹${nextBid.toInt()} placed successfully!"
                                        onSubmitBid?.invoke(auctionData.cycleNumber, nextBid)
                                    } else {
                                        bidErrorMessage = validation.reason
                                    }
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                                    .testTag("quick_bid_min_btn"),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                                border = BorderStroke(1.dp, Emerald500.copy(alpha = 0.6f))
                            ) {
                                Icon(Icons.Default.TrendingUp, contentDescription = null, tint = Emerald500, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "+₹500 (₹${auctionData.minNextBid.toInt()})",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Emerald500
                                )
                            }

                            // Custom bid input
                            OutlinedTextField(
                                value = bidInputText,
                                onValueChange = {
                                    bidInputText = it
                                    bidErrorMessage = null
                                    bidSuccessMessage = null
                                },
                                placeholder = { Text("₹ Amount", fontSize = 11.sp) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("custom_bid_input"),
                                leadingIcon = {
                                    Icon(Icons.Default.CurrencyRupee, contentDescription = null, modifier = Modifier.size(13.dp))
                                }
                            )

                            Button(
                                onClick = {
                                    val amount = bidInputText.toDoubleOrNull()
                                    if (amount == null || amount <= 0) {
                                        bidErrorMessage = "Enter a valid bid amount"
                                        return@Button
                                    }
                                    val rules = ChitAuctionRules(
                                        openingBid = 0.0,
                                        minBidIncrement = 500.0,
                                        currentCallStage = auctionData.callStage
                                    )
                                    val validation = ChitCalculationEngine.validateBidSubmission(
                                        bidAmount = amount,
                                        currentHighestBid = auctionData.currentHighestBid,
                                        rules = rules
                                    )
                                    if (validation.isValid) {
                                        bidErrorMessage = null
                                        bidSuccessMessage = "Bid of ₹${amount.toInt()} placed!"
                                        bidInputText = ""
                                        onSubmitBid?.invoke(auctionData.cycleNumber, amount)
                                    } else {
                                        bidErrorMessage = validation.reason
                                    }
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                                modifier = Modifier
                                    .height(38.dp)
                                    .testTag("submit_custom_bid_btn"),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp)
                            ) {
                                Text("Bid", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Feedback message
                        bidErrorMessage?.let { err ->
                            Text(text = "⚠️ $err", color = Rose500, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        }
                        bidSuccessMessage?.let { succ ->
                            Text(text = "✓ $succ", color = Emerald500, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF64748B).copy(alpha = 0.1f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Bidding floor is closed for this cycle.",
                                fontSize = 12.sp,
                                color = Color(0xFF64748B),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // Action Bar: Bidding Floor Link, Pin Toggle, Delete
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = { onNavigateToAuctionFloor?.invoke(auctionData.cycleNumber) },
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                        modifier = Modifier.testTag("open_auction_floor_btn")
                    ) {
                        Text(
                            text = "Open Full Bidding Floor",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = IndigoPrimary
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(13.dp))
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onTogglePin,
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(
                                imageVector = if (notice.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                                contentDescription = "Pin Post",
                                tint = if (notice.isPinned) Amber500 else Color(0xFF94A3B8),
                                modifier = Modifier.size(17.dp)
                            )
                        }

                        if (isAdmin && onDelete != null) {
                            IconButton(
                                onClick = onDelete,
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete Post",
                                    tint = Color(0xFF94A3B8),
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
