package com.adr.groupledger.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.HomeModuleConfig
import com.adr.groupledger.data.model.UpdateCheckStatus
import com.adr.groupledger.ui.components.AppUpdateDialog
import com.adr.groupledger.ui.components.HomeNotificationItem
import com.adr.groupledger.ui.components.NotificationType
import com.adr.groupledger.ui.home.HomeTemplateContext
import com.adr.groupledger.ui.home.HomeTemplateResolver
import com.adr.groupledger.ui.home.template.HomeTemplateRegistry
import com.adr.groupledger.ui.viewmodel.SocietyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: SocietyViewModel,
    onNavigateToMembers: () -> Unit,
    onNavigateToMonthly: () -> Unit,
    onNavigateToDues: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToRecordPayment: () -> Unit,
    onNavigateToAddMember: () -> Unit,
    onNavigateToMemberProfile: (Long) -> Unit,
    onNavigateToLoans: () -> Unit = {},
    onNavigateToInvestments: () -> Unit = {},
    onNavigateToFeedback: () -> Unit = {},
    onNavigateToLedger: () -> Unit = {},
    onNavigateToInbox: () -> Unit = {},
    onNavigateToAuctionDetails: ((Int?) -> Unit)? = null,
    onNavigateToChitMyContribution: (() -> Unit)? = null,
    onNavigateToChitCollection: ((Int?) -> Unit)? = null,
    listState: LazyListState = rememberLazyListState(),
    modifier: Modifier = Modifier
) {
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val financials by viewModel.overallFinancials.collectAsStateWithLifecycle()
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()
    val monthSummary by viewModel.currentMonthSummary.collectAsStateWithLifecycle()
    val recentTxns by viewModel.allTransactions.collectAsStateWithLifecycle()
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()
    val loansWithVoting by viewModel.allLoansWithVotes.collectAsStateWithLifecycle()
    val pendingApprovals by viewModel.pendingPaymentApprovals.collectAsStateWithLifecycle()
    val feedbacksWithVotes by viewModel.allFeedbacksWithVotes.collectAsStateWithLifecycle()
    val notices by viewModel.notices.collectAsStateWithLifecycle()
    val homeModules by viewModel.homeModules.collectAsStateWithLifecycle()
    val updateStatus by viewModel.updateStatus.collectAsStateWithLifecycle()
    val isUpdateBannerDismissed by viewModel.isUpdateBannerDismissed.collectAsStateWithLifecycle()
    val activeCarouselItems by viewModel.activeCarouselItems.collectAsStateWithLifecycle()
    val isRefreshing by viewModel.isDashboardRefreshing.collectAsStateWithLifecycle()
    val membersWithMonthlyStatus by viewModel.membersWithMonthlyStatus.collectAsStateWithLifecycle()
    val activeMembers by viewModel.activeMembers.collectAsStateWithLifecycle()
    val userMemberships by viewModel.userMemberships.collectAsStateWithLifecycle()
    val currentUserId by viewModel.currentUserId.collectAsStateWithLifecycle()

    var showAppUpdateDialog by remember { mutableStateOf(false) }

    val homeNotifications = remember(loansWithVoting, pendingApprovals, feedbacksWithVotes, notices, updateStatus, isUpdateBannerDismissed) {
        val items = mutableListOf<HomeNotificationItem>()

        // 0. In-App Update Service Notification
        if (updateStatus is UpdateCheckStatus.UpdateAvailable && !isUpdateBannerDismissed) {
            val updateInfo = (updateStatus as UpdateCheckStatus.UpdateAvailable).updateInfo
            items.add(
                HomeNotificationItem(
                    id = "system_app_update",
                    type = NotificationType.SYSTEM_UPDATE,
                    title = "App Update: v${updateInfo.versionName} Ready",
                    description = updateInfo.title.ifBlank { "A software update is ready. Tap to download & install." },
                    categoryLabel = if (updateInfo.isMandatory) "Mandatory Update" else "Software Update",
                    accentColor = Color(0xFF6366F1),
                    icon = Icons.Default.SystemUpdate,
                    priority = 0,
                    onClick = { showAppUpdateDialog = true }
                )
            )
        }

        // 1. Pending Loan Requests
        val pendingLoans = loansWithVoting.filter { it.loan.status in listOf("VOTING", "SUBMITTED") }
        if (pendingLoans.isNotEmpty()) {
            val count = pendingLoans.size
            items.add(
                HomeNotificationItem(
                    id = "loan_requests_pending",
                    type = NotificationType.LOAN_REQUEST,
                    title = if (count == 1) "1 Loan Request(s) Awaiting Vote" else "$count Loan Request(s) Awaiting Vote",
                    description = "70% approval rule active. Tap to vote now.",
                    categoryLabel = "Loan Request",
                    accentColor = Color(0xFFF97316),
                    icon = Icons.Default.Handshake,
                    priority = 1,
                    onClick = onNavigateToLoans
                )
            )
        }

        // 2. Pending Payment Submissions
        if (pendingApprovals.isNotEmpty()) {
            val count = pendingApprovals.size
            items.add(
                HomeNotificationItem(
                    id = "pending_approvals",
                    type = NotificationType.PENDING_PAYMENT,
                    title = if (count == 1) "1 Payment Submission Awaiting Approval" else "$count Payment Submission(s) Awaiting Approval",
                    description = "Tap to review receipt and confirm or reject.",
                    categoryLabel = "Payment Pending",
                    accentColor = Color(0xFFF59E0B),
                    icon = Icons.Default.HourglassTop,
                    priority = 2,
                    onClick = onNavigateToInbox
                )
            )
        }

        // 3. Active Complaints
        val activeComplaints = feedbacksWithVotes.filter {
            it.feedback.type == "COMPLAINT" && it.feedback.status in listOf("SUBMITTED", "UNDER_REVIEW", "DISCUSSING")
        }
        activeComplaints.take(2).forEach { item ->
            items.add(
                HomeNotificationItem(
                    id = "complaint_${item.feedback.id}",
                    type = NotificationType.COMPLAINT,
                    title = item.feedback.subject.ifBlank { "New Complaint" },
                    description = item.feedback.description.ifBlank { "A complaint requires attention. Tap to view." },
                    categoryLabel = "Complaint",
                    accentColor = Color(0xFFEF4444),
                    icon = Icons.Default.ReportProblem,
                    priority = 3,
                    onClick = onNavigateToFeedback
                )
            )
        }

        // 4. Active Proposals
        val activeProposals = feedbacksWithVotes.filter {
            it.feedback.type == "PROPOSAL" && it.feedback.status in listOf("SUBMITTED", "UNDER_REVIEW", "DISCUSSING")
        }
        activeProposals.take(2).forEach { item ->
            items.add(
                HomeNotificationItem(
                    id = "proposal_${item.feedback.id}",
                    type = NotificationType.PROPOSAL,
                    title = item.feedback.subject.ifBlank { "New Proposal Available" },
                    description = if (item.feedback.requiresVoting) {
                        "Proposal voting active (${item.agreePercentage.toInt()}% agreed). Tap to vote."
                    } else {
                        item.feedback.description.ifBlank { "A new proposal requires your attention." }
                    },
                    categoryLabel = "Proposal",
                    accentColor = Color(0xFF8B5CF6),
                    icon = Icons.Default.Assignment,
                    priority = 4,
                    onClick = onNavigateToFeedback
                )
            )
        }

        // 5. Active Suggestions
        val activeSuggestions = feedbacksWithVotes.filter {
            it.feedback.type == "SUGGESTION" && it.feedback.status in listOf("SUBMITTED", "UNDER_REVIEW", "DISCUSSING")
        }
        activeSuggestions.take(2).forEach { item ->
            items.add(
                HomeNotificationItem(
                    id = "suggestion_${item.feedback.id}",
                    type = NotificationType.SUGGESTION,
                    title = item.feedback.subject.ifBlank { "New Suggestion Available" },
                    description = item.feedback.description.ifBlank { "A new notice has been posted. Tap to view." },
                    categoryLabel = "Suggestion",
                    accentColor = Color(0xFF2563EB),
                    icon = Icons.Default.Lightbulb,
                    priority = 5,
                    onClick = onNavigateToFeedback
                )
            )
        }

        // 6. Society Notices / Announcements
        notices.take(2).forEach { notice ->
            items.add(
                HomeNotificationItem(
                    id = "notice_${notice.id}",
                    type = NotificationType.NOTICE,
                    title = notice.title.ifBlank { "Society Notice" },
                    description = notice.content.ifBlank { "A new notice has been posted. Tap to view." },
                    categoryLabel = "Notice",
                    accentColor = Color(0xFF10B981),
                    icon = Icons.Default.Campaign,
                    priority = 6,
                    onClick = onNavigateToInbox
                )
            )
        }

        items.distinctBy { it.id }.sortedBy { it.priority }
    }

    val (category, subCategory) = remember(settings) {
        HomeTemplateResolver.resolve(settings)
    }

    val template = remember(category, subCategory) {
        HomeTemplateRegistry.resolve(category, subCategory)
    }

    val myMembership = remember(userMemberships, settings.id) {
        userMemberships.find { it.groupId == settings.id }
    }
    val myMemberId = myMembership?.memberIdInGroup ?: currentUserId
    val myMemberStatus = remember(membersWithMonthlyStatus, myMemberId, settings.ownerUid) {
        membersWithMonthlyStatus.find {
            it.member.id == myMemberId ||
            (it.member.linkedUid.isNotBlank() && it.member.linkedUid == settings.ownerUid)
        }
    }
    val myMember = remember(myMemberStatus, activeMembers, myMemberId) {
        myMemberStatus?.member ?: activeMembers.find { it.id == myMemberId }
    }

    val templateContext = HomeTemplateContext(
        viewModel = viewModel,
        settings = settings,
        category = category,
        subCategory = subCategory,
        financials = financials,
        selectedMonth = selectedMonth,
        selectedYear = selectedYear,
        monthSummary = monthSummary,
        recentTxns = recentTxns,
        isAdminUnlocked = isAdminUnlocked,
        loansWithVoting = loansWithVoting,
        pendingApprovals = pendingApprovals,
        feedbacksWithVotes = feedbacksWithVotes,
        notices = notices,
        homeModules = homeModules,
        activeCarouselItems = activeCarouselItems,
        notifications = homeNotifications,
        isRefreshing = isRefreshing,
        listState = listState,
        membersWithMonthlyStatus = membersWithMonthlyStatus,
        currentUserMember = myMember,
        currentUserMonthlyStatus = myMemberStatus,
        totalActiveMembersCount = activeMembers.size,
        onNavigateToMembers = onNavigateToMembers,
        onNavigateToMonthly = onNavigateToMonthly,
        onNavigateToDues = onNavigateToDues,
        onNavigateToReports = onNavigateToReports,
        onNavigateToRecordPayment = onNavigateToRecordPayment,
        onNavigateToAddMember = onNavigateToAddMember,
        onNavigateToMemberProfile = onNavigateToMemberProfile,
        onNavigateToLoans = onNavigateToLoans,
        onNavigateToInvestments = onNavigateToInvestments,
        onNavigateToFeedback = onNavigateToFeedback,
        onNavigateToLedger = onNavigateToLedger,
        onNavigateToInbox = onNavigateToInbox,
        onNavigateToAuctionDetails = onNavigateToAuctionDetails,
        onNavigateToChitMyContribution = onNavigateToChitMyContribution,
        onNavigateToChitCollection = onNavigateToChitCollection
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        key(settings.id, category.id, subCategory) {
            template.Render(templateContext)
        }
    }

    if (showAppUpdateDialog) {
        (updateStatus as? UpdateCheckStatus.UpdateAvailable)?.let { avail ->
            AppUpdateDialog(
                viewModel = viewModel,
                updateStatus = updateStatus,
                currentVersionName = avail.updateInfo.versionName.ifBlank { "1.2.0" },
                currentVersionCode = avail.updateInfo.versionCode,
                lastCheckedTime = System.currentTimeMillis(),
                isAdmin = isAdminUnlocked,
                onDismissRequest = {
                    showAppUpdateDialog = false
                    viewModel.dismissUpdateBanner()
                }
            )
        }
    }
}

/**
 * Resolves icon for customizable Home modules.
 */
fun resolveModuleIcon(iconName: String): androidx.compose.ui.graphics.vector.ImageVector {
    return when (iconName) {
        "payments" -> Icons.Default.Payments
        "group" -> Icons.Default.Group
        "pending_actions" -> Icons.Default.HourglassTop
        "assessment" -> Icons.Default.PieChart
        "point_of_sale" -> Icons.Default.Payments
        "volunteer_activism" -> Icons.Default.Handshake
        "savings" -> Icons.Default.Savings
        "feedback" -> Icons.Default.Feedback
        "menu_book" -> Icons.Default.Assignment
        "campaign" -> Icons.Default.Campaign
        "calculate" -> Icons.Default.PieChart
        "settings" -> Icons.Default.Assignment
        "star" -> Icons.Default.Star
        "celebration" -> Icons.Default.Event
        "store" -> Icons.Default.AccountBalance
        "work" -> Icons.Default.Assignment
        "auto_awesome" -> Icons.Default.Star
        "receipt_long" -> Icons.Default.ReceiptLong
        "chat" -> Icons.Default.Feedback
        "lightbulb" -> Icons.Default.Lightbulb
        "help" -> Icons.Default.Help
        "assignment" -> Icons.Default.Assignment
        else -> Icons.Default.Assignment
    }
}
