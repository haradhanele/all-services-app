package com.adr.groupledger.ui.screens

import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.MonthlyLedgerItem
import com.adr.groupledger.ui.components.ConfirmActionDialog
import com.adr.groupledger.ui.components.MemberAvatarView
import com.adr.groupledger.ui.components.StatusBadge
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.StatusPaidBg
import com.adr.groupledger.ui.theme.StatusPaidText
import com.adr.groupledger.ui.theme.StatusPartialBg
import com.adr.groupledger.ui.theme.StatusPartialText
import com.adr.groupledger.ui.theme.StatusUnpaidBg
import com.adr.groupledger.ui.theme.StatusUnpaidText
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.utils.CurrencyFormatter
import com.adr.groupledger.utils.DateUtils
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemberProfileScreen(
    memberId: Long,
    viewModel: SocietyViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToEdit: (Long) -> Unit,
    onNavigateToRecordPayment: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val profile by viewModel.selectedMemberProfile.collectAsStateWithLifecycle()

    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()
    val currentMemberId by viewModel.currentMemberId.collectAsStateWithLifecycle()
    val isSelf = (currentMemberId != null && currentMemberId == memberId)

    var showMenu by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableIntStateOf(0) } // 0: All, 1: Paid, 2: Unpaid/Due
    var selectedYearFilter by remember { mutableStateOf<Int?>(null) } // null = All years

    LaunchedEffect(memberId) {
        viewModel.selectMember(memberId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = profile?.member?.name ?: "Member Profile",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (isSelf) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = IndigoPrimary.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "YOU",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = IndigoPrimary,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = profile?.member?.memberCode?.ifEmpty { "ID #${memberId}" } ?: "Member Details",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.5.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("back_button")) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            profile?.let { viewModel.exportMemberLedgerPdf(context, it) }
                        },
                        modifier = Modifier.testTag("export_member_pdf_top_btn")
                    ) {
                        Icon(
                            Icons.Default.PictureAsPdf,
                            contentDescription = "Export PDF",
                            tint = IndigoPrimary
                        )
                    }

                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.testTag("member_profile_menu")
                    ) {
                        Icon(
                            Icons.Default.MoreVert,
                            contentDescription = "Options",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text(if (isSelf) "Edit My Profile" else "Edit Member Profile") },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = IndigoPrimary) },
                            onClick = {
                                showMenu = false
                                if (isAdminUnlocked || isSelf) {
                                    onNavigateToEdit(memberId)
                                } else {
                                    viewModel.requestAdminAction {
                                        onNavigateToEdit(memberId)
                                    }
                                }
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Export Account Ledger (PDF)") },
                            leadingIcon = { Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = IndigoPrimary) },
                            onClick = {
                                showMenu = false
                                profile?.let { viewModel.exportMemberLedgerPdf(context, it) }
                            }
                        )
                        profile?.let { prof ->
                            if (prof.member.phone.isNotBlank()) {
                                DropdownMenuItem(
                                    text = { Text("Share Statement via WhatsApp") },
                                    leadingIcon = { Icon(Icons.Default.Send, contentDescription = null, tint = Color(0xFF059669)) },
                                    onClick = {
                                        showMenu = false
                                        viewModel.sendReminder(context, prof.member, prof.totalDueAllTime, "WHATSAPP")
                                    }
                                )
                            }
                        }
                        DropdownMenuItem(
                            text = { Text("Delete Member", color = MaterialTheme.colorScheme.error) },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                            onClick = {
                                showMenu = false
                                if (isAdminUnlocked) {
                                    showDeleteConfirm = true
                                } else {
                                    viewModel.requestAdminAction {
                                        showDeleteConfirm = true
                                    }
                                }
                            }
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        if (profile == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Loading member profile...",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            val prof = profile!!
            val member = prof.member
            val effectiveMonthly = if (member.monthlyContribution > 0) member.monthlyContribution else settings.defaultContribution

            // All years available in member ledger history
            val availableYears = remember(prof.paymentHistory) {
                prof.paymentHistory.map { it.year }.distinct().sortedDescending()
            }

            // Filter history by year and tab
            val filteredByYearHistory = remember(prof.paymentHistory, selectedYearFilter) {
                if (selectedYearFilter == null) prof.paymentHistory
                else prof.paymentHistory.filter { it.year == selectedYearFilter }
            }

            val displayedHistory = remember(filteredByYearHistory, selectedTab) {
                when (selectedTab) {
                    1 -> filteredByYearHistory.filter { it.status == "PAID" }
                    2 -> filteredByYearHistory.filter { it.status == "UNPAID" || it.status == "PARTIAL" }
                    else -> filteredByYearHistory
                }
            }

            val totalPaidMonthsCount = remember(prof.paymentHistory) {
                prof.paymentHistory.count { it.status == "PAID" }
            }
            val totalUnpaidMonthsCount = remember(prof.paymentHistory) {
                prof.paymentHistory.count { it.status == "UNPAID" || it.status == "PARTIAL" }
            }
            val totalMonthsCount = prof.paymentHistory.size

            val paymentRatePercent = if (prof.totalExpectedAllTime > 0) {
                ((prof.totalPaidAllTime / prof.totalExpectedAllTime) * 100).toInt().coerceIn(0, 100)
            } else 100

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 14.dp)
                    .testTag("member_profile_screen"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 1. Member Profile Details Header Card
                item {
                    Spacer(modifier = Modifier.height(2.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                            .testTag("member_profile_header_card"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                MemberAvatarView(name = member.name, size = 48.dp, isActive = member.isActive)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = member.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        fontSize = 15.sp
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = IndigoPrimary.copy(alpha = 0.08f)
                                        ) {
                                            Text(
                                                text = member.memberCode.ifEmpty { "ID: #${member.id}" },
                                                color = IndigoPrimary,
                                                fontSize = 10.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }

                                        if (!member.isActive) {
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = MaterialTheme.colorScheme.surfaceContainerHigh
                                            ) {
                                                Text(
                                                    text = "Inactive",
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                                )
                                            }
                                        }

                                        StatusBadge(status = prof.currentMonthStatus, compact = true)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Contact details and Info List
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                // Phone with quick action buttons
                                if (member.phone.isNotBlank()) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(
                                                Icons.Default.Phone,
                                                contentDescription = "Phone",
                                                modifier = Modifier.size(13.dp),
                                                tint = IndigoPrimary
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = member.phone,
                                                style = MaterialTheme.typography.bodySmall,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                fontSize = 12.sp
                                            )
                                        }

                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Surface(
                                                onClick = {
                                                    val intent = Intent(Intent.ACTION_DIAL).apply {
                                                        data = Uri.parse("tel:${member.phone}")
                                                    }
                                                    context.startActivity(intent)
                                                },
                                                shape = RoundedCornerShape(5.dp),
                                                color = IndigoPrimary.copy(alpha = 0.1f)
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Icon(Icons.Default.Call, contentDescription = "Call", tint = IndigoPrimary, modifier = Modifier.size(11.dp))
                                                    Spacer(modifier = Modifier.width(3.dp))
                                                    Text("Call", color = IndigoPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }

                                            Surface(
                                                onClick = {
                                                    viewModel.sendReminder(context, member, prof.totalDueAllTime, "WHATSAPP")
                                                },
                                                shape = RoundedCornerShape(5.dp),
                                                color = Color(0xFF10B981).copy(alpha = 0.12f)
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Icon(Icons.Default.Send, contentDescription = "WhatsApp", tint = Color(0xFF059669), modifier = Modifier.size(11.dp))
                                                    Spacer(modifier = Modifier.width(3.dp))
                                                    Text("WhatsApp", color = Color(0xFF059669), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }

                                // Address
                                if (member.address.isNotBlank()) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.LocationOn,
                                            contentDescription = null,
                                            modifier = Modifier.size(13.dp),
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = member.address,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 11.5.sp
                                        )
                                    }
                                }

                                // Join Date & Contribution Rate
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.CalendarMonth,
                                            contentDescription = null,
                                            modifier = Modifier.size(13.dp),
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Joined ${DateUtils.formatDisplayDate(member.joinDate)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 11.sp
                                        )
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(5.dp),
                                        color = MaterialTheme.colorScheme.surfaceContainerHigh
                                    ) {
                                        Text(
                                            text = "Fee: ${CurrencyFormatter.format(effectiveMonthly, "₹")}/mo",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold,
                                            color = IndigoPrimary,
                                            fontSize = 10.5.sp,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                // Date of Birth Row
                                val canEditDob = isAdminUnlocked || isSelf
                                val dobCalendar = remember(member.dateOfBirth) {
                                    Calendar.getInstance().apply {
                                        if (member.dateOfBirth.isNotBlank()) {
                                            val parts = member.dateOfBirth.split("-", "/")
                                            if (parts.size == 3) {
                                                val y = parts[0].toIntOrNull() ?: 1995
                                                val m = parts[1].toIntOrNull() ?: 1
                                                val d = parts[2].toIntOrNull() ?: 1
                                                set(y, m - 1, d, 0, 0, 0)
                                            }
                                        } else {
                                            set(1995, Calendar.JANUARY, 1, 0, 0, 0)
                                        }
                                    }
                                }
                                val profileDobDialog = remember(member.id, member.dateOfBirth) {
                                    DatePickerDialog(
                                        context,
                                        { _, y, m, d ->
                                            val mm = String.format("%02d", m + 1)
                                            val dd = String.format("%02d", d)
                                            viewModel.updateMemberDateOfBirth(member.id, "$y-$mm-$dd")
                                        },
                                        dobCalendar.get(Calendar.YEAR),
                                        dobCalendar.get(Calendar.MONTH),
                                        dobCalendar.get(Calendar.DAY_OF_MONTH)
                                    ).apply {
                                        datePicker.maxDate = System.currentTimeMillis()
                                    }
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .then(
                                            if (canEditDob) {
                                                Modifier.clickable { profileDobDialog.show() }
                                            } else Modifier
                                        )
                                        .testTag("member_profile_dob_row"),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.Cake,
                                            contentDescription = "Date of Birth",
                                            modifier = Modifier.size(13.dp),
                                            tint = IndigoPrimary
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (member.dateOfBirth.isNotBlank()) {
                                                "DOB: ${DateUtils.formatDobDisplay(member.dateOfBirth)}"
                                            } else {
                                                "Date of Birth: Not set"
                                            },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 11.sp
                                        )
                                    }

                                    if (canEditDob) {
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = IndigoPrimary.copy(alpha = 0.08f)
                                        ) {
                                            Text(
                                                text = if (member.dateOfBirth.isNotBlank()) "Change" else "Set",
                                                color = IndigoPrimary,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 2. Financial Metrics Cards Grid
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Total Paid Card
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
                                    .testTag("metric_total_paid"),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = "TOTAL PAID",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 8.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 0.5.sp
                                        )
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusPaidText, modifier = Modifier.size(12.dp))
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = CurrencyFormatter.format(prof.totalPaidAllTime, "₹"),
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = StatusPaidText,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = "$totalPaidMonthsCount months paid",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 9.5.sp
                                    )
                                }
                            }

                            // Total Due Card
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
                                    .testTag("metric_total_due"),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = "TOTAL DUES",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 8.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 0.5.sp
                                        )
                                        Icon(
                                            if (prof.totalDueAllTime > 0) Icons.Default.ErrorOutline else Icons.Default.Check,
                                            contentDescription = null,
                                            tint = if (prof.totalDueAllTime > 0) StatusUnpaidText else StatusPaidText,
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = CurrencyFormatter.format(prof.totalDueAllTime, "₹"),
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (prof.totalDueAllTime > 0) StatusUnpaidText else StatusPaidText,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = if (prof.totalDueAllTime > 0) "$totalUnpaidMonthsCount pending" else "All cleared! ✨",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 9.5.sp
                                    )
                                }
                            }

                            // Expected Card
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp)),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = "EXPECTED",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 0.5.sp
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = CurrencyFormatter.format(prof.totalExpectedAllTime, "₹"),
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = "$totalMonthsCount total",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 9.5.sp
                                    )
                                }
                            }
                        }

                        // Settlement Progress Bar
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Contribution Clearance Rate",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "$paymentRatePercent% Paid",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = if (paymentRatePercent >= 80) StatusPaidText else StatusUnpaidText
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                LinearProgressIndicator(
                                    progress = { paymentRatePercent / 100f },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(5.dp)
                                        .clip(RoundedCornerShape(3.dp)),
                                    color = if (paymentRatePercent >= 80) StatusPaidText else IndigoPrimary,
                                    trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                                )
                            }
                        }
                    }
                }

                // 3. Quick Action Buttons
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onNavigateToRecordPayment(member.id) },
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .testTag("record_payment_for_member_btn"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                        ) {
                            Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(5.dp))
                            Text("Record Payment", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        if (member.phone.isNotBlank()) {
                            OutlinedButton(
                                onClick = {
                                    viewModel.sendReminder(context, member, prof.totalDueAllTime, "WHATSAPP")
                                },
                                modifier = Modifier
                                    .height(40.dp)
                                    .testTag("send_whatsapp_reminder_btn"),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = Color(0xFF059669)
                                )
                            ) {
                                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(13.dp), tint = Color(0xFF059669))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("WhatsApp", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            }
                        }
                    }
                }

                // 4. Month-Wise Payment Breakdown Header & Filter Section
                item {
                    Spacer(modifier = Modifier.height(2.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp)),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.ReceiptLong,
                                        contentDescription = null,
                                        tint = IndigoPrimary,
                                        modifier = Modifier.size(17.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Month-Wise Paid & Unpaid Status",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.5.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                IconButton(
                                    onClick = { viewModel.exportMemberLedgerPdf(context, prof) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        Icons.Default.PictureAsPdf,
                                        contentDescription = "Export PDF",
                                        tint = IndigoPrimary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Year Filter Chips (if multiple years exist)
                            if (availableYears.size > 1) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    FilterChip(
                                        selected = selectedYearFilter == null,
                                        onClick = { selectedYearFilter = null },
                                        label = { Text("All Years", fontSize = 11.sp, fontWeight = if (selectedYearFilter == null) FontWeight.Bold else FontWeight.Normal) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = IndigoPrimary,
                                            selectedLabelColor = Color.White,
                                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                            labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )
                                    availableYears.forEach { yr ->
                                        val isYrSelected = selectedYearFilter == yr
                                        FilterChip(
                                            selected = isYrSelected,
                                            onClick = { selectedYearFilter = yr },
                                            label = { Text("$yr", fontSize = 11.sp, fontWeight = if (isYrSelected) FontWeight.Bold else FontWeight.Normal) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = IndigoPrimary,
                                                selectedLabelColor = Color.White,
                                                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                                labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                            }

                            // Status Filter Tabs: All, Paid, Unpaid/Due
                            TabRow(
                                selectedTabIndex = selectedTab,
                                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                contentColor = IndigoPrimary,
                                indicator = { tabPositions ->
                                    TabRowDefaults.SecondaryIndicator(
                                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                                        color = IndigoPrimary,
                                        height = 2.5.dp
                                    )
                                },
                                modifier = Modifier.clip(RoundedCornerShape(6.dp))
                            ) {
                                Tab(
                                    selected = selectedTab == 0,
                                    onClick = { selectedTab = 0 },
                                    text = {
                                        Text(
                                            text = "All ($totalMonthsCount)",
                                            fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Medium,
                                            fontSize = 11.5.sp
                                        )
                                    }
                                )
                                Tab(
                                    selected = selectedTab == 1,
                                    onClick = { selectedTab = 1 },
                                    text = {
                                        Text(
                                            text = "Paid ($totalPaidMonthsCount)",
                                            fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Medium,
                                            color = if (selectedTab == 1) StatusPaidText else MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 11.5.sp
                                        )
                                    }
                                )
                                Tab(
                                    selected = selectedTab == 2,
                                    onClick = { selectedTab = 2 },
                                    text = {
                                        Text(
                                            text = "Unpaid ($totalUnpaidMonthsCount)",
                                            fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Medium,
                                            color = if (selectedTab == 2) StatusUnpaidText else MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 11.5.sp
                                        )
                                    }
                                )
                            }
                        }
                    }
                }

                // 5. Month-wise Status Items List
                if (displayedHistory.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 20.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                    modifier = Modifier.size(30.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = when (selectedTab) {
                                        1 -> "No paid records found in selected period"
                                        2 -> "Great! No unpaid dues for this period 🎉"
                                        else -> "No monthly records found"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    items(displayedHistory, key = { "${it.month}_${it.year}" }) { item ->
                        MonthStatusCard(
                            item = item,
                            member = member,
                            onPayNowClick = {
                                viewModel.selectMonthYear(item.month, item.year)
                                onNavigateToRecordPayment(member.id)
                            },
                            onSendReminderClick = {
                                viewModel.sendReminder(context, member, item.dueAmount, "WHATSAPP")
                            },
                            onShareReceiptClick = {
                                viewModel.exportMemberLedgerPdf(context, prof)
                            }
                        )
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }

            // Delete confirmation dialog
            ConfirmActionDialog(
                isOpen = showDeleteConfirm,
                title = "Delete Member",
                message = "Are you sure you want to delete '${member.name}'? This will permanently remove this member and their payment records.",
                confirmButtonText = "Delete Member",
                isDestructive = true,
                onConfirm = {
                    viewModel.deleteMember(member) {
                        onNavigateBack()
                    }
                },
                onDismiss = { showDeleteConfirm = false }
            )
        }
    }
}

@Composable
fun MonthStatusCard(
    item: MonthlyLedgerItem,
    member: Member,
    onPayNowClick: () -> Unit,
    onSendReminderClick: () -> Unit,
    onShareReceiptClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isPaid = item.status == "PAID"
    val isPartial = item.status == "PARTIAL"
    val isUnpaid = item.status == "UNPAID"

    val borderColor = when {
        isPaid -> StatusPaidText.copy(alpha = 0.3f)
        isPartial -> StatusPartialText.copy(alpha = 0.3f)
        else -> StatusUnpaidText.copy(alpha = 0.3f)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, borderColor, RoundedCornerShape(10.dp))
            .testTag("month_ledger_card_${item.month}_${item.year}"),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            // Header Row: Month Name & Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = when {
                            isPaid -> StatusPaidBg
                            isPartial -> StatusPartialBg
                            else -> StatusUnpaidBg
                        },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = when {
                                    isPaid -> Icons.Default.Check
                                    isPartial -> Icons.Default.Info
                                    else -> Icons.Default.ErrorOutline
                                },
                                contentDescription = null,
                                tint = when {
                                    isPaid -> StatusPaidText
                                    isPartial -> StatusPartialText
                                    else -> StatusUnpaidText
                                },
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${item.monthName} ${item.year}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                StatusBadge(status = item.status, compact = true)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Amount breakdown row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Expected", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 9.sp)
                    Text(
                        text = CurrencyFormatter.format(item.expectedAmount, "₹"),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Column {
                    Text("Paid Amount", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 9.sp)
                    Text(
                        text = CurrencyFormatter.format(item.paidAmount, "₹"),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.5.sp,
                        color = if (item.paidAmount > 0) StatusPaidText else MaterialTheme.colorScheme.onSurface
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("Due Balance", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 9.sp)
                    Text(
                        text = CurrencyFormatter.format(item.dueAmount, "₹"),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.5.sp,
                        color = if (item.dueAmount > 0) StatusUnpaidText else StatusPaidText
                    )
                }
            }

            // Payment metadata (if paid or partial)
            if (item.paymentDate != null && item.paymentDate > 0) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Paid on ${DateUtils.formatDisplayDate(item.paymentDate)} via ${item.paymentMethod ?: "Cash"}" +
                                (if (!item.transactionRef.isNullOrBlank()) " (Ref: ${item.transactionRef})" else ""),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 10.sp
                    )
                }
            }

            // Action row if Unpaid or Partial
            if (isUnpaid || isPartial) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (member.phone.isNotBlank()) {
                        OutlinedButton(
                            onClick = onSendReminderClick,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .height(30.dp)
                                .padding(end = 6.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF059669))
                        ) {
                            Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(11.dp), tint = Color(0xFF059669))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("Remind", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = onPayNowClick,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .height(30.dp)
                            .testTag("pay_month_${item.month}_${item.year}_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                    ) {
                        Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("Pay This Month", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
