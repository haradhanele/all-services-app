package com.adr.groupledger.data.model

import org.json.JSONObject

/**
 * Phase D.0 / D.0.1: Chit Fund Auction Call Stages.
 *
 * Timed auction calling stages:
 * OPEN -> FIRST_CALL -> SECOND_CALL -> FINAL_CALL -> CLOSED
 */
enum class ChitAuctionCallStage(val displayName: String) {
    OPEN("Auction Open"),
    FIRST_CALL("First Call"),
    SECOND_CALL("Second Call"),
    FINAL_CALL("Final Call"),
    CLOSED("Auction Closed");

    val isBiddingAllowed: Boolean
        get() = this != CLOSED
}

/**
 * Phase D.0 / D.0.1: Chit Fund Discount Distribution Rules.
 *
 * Allows group-specific configuration for handling winning bid discount:
 * - Option A: Divide equally among all members.
 * - Option B: Foreman commission + surplus dividend.
 * - Option C: Future cycle / game adjustment.
 * - Option D: Custom group-specific rule.
 */
enum class DiscountDistributionRule(val displayName: String, val description: String) {
    DIVIDE_EQUALLY_ALL_MEMBERS(
        displayName = "Divide Equally Among All Members",
        description = "Entire discount is divided equally among all group members (Option A)"
    ),
    FOREMAN_COMMISSION_AND_DIVIDEND(
        displayName = "Foreman Commission + Member Dividend",
        description = "Foreman takes commission percentage, remaining surplus divided as dividend (Option B)"
    ),
    FUTURE_CYCLE_ADJUSTMENT(
        displayName = "Future Cycle Adjustment",
        description = "Discount is carried forward and adjusted in upcoming cycle / game (Option C)"
    ),
    CUSTOM_GROUP_RULE(
        displayName = "Custom Group Specific Rule",
        description = "Handled per custom group bylaws and manual adjustment (Option D)"
    )
}

/**
 * Extensible Group-Specific Chit Fund Auction Rules Configuration.
 */
data class ChitAuctionRules(
    val openingBid: Double = 0.0,
    val minBidIncrement: Double = 500.0,
    val currentCallStage: ChitAuctionCallStage = ChitAuctionCallStage.OPEN,
    val discountDistributionRule: DiscountDistributionRule = DiscountDistributionRule.DIVIDE_EQUALLY_ALL_MEMBERS,
    val auctionDurationMinutes: Int = 60,
    val firstCallSeconds: Int = 120,
    val secondCallSeconds: Int = 60,
    val finalCallSeconds: Int = 30,
    val foremanCommissionPercent: Double = 5.0
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("openingBid", openingBid)
            put("minBidIncrement", minBidIncrement)
            put("currentCallStage", currentCallStage.name)
            put("discountDistributionRule", discountDistributionRule.name)
            put("auctionDurationMinutes", auctionDurationMinutes)
            put("firstCallSeconds", firstCallSeconds)
            put("secondCallSeconds", secondCallSeconds)
            put("finalCallSeconds", finalCallSeconds)
            put("foremanCommissionPercent", foremanCommissionPercent)
        }
    }

    companion object {
        fun fromJson(json: JSONObject?): ChitAuctionRules {
            if (json == null) return ChitAuctionRules()
            return ChitAuctionRules(
                openingBid = json.optDouble("openingBid", 0.0),
                minBidIncrement = json.optDouble("minBidIncrement", 500.0),
                currentCallStage = try {
                    ChitAuctionCallStage.valueOf(json.optString("currentCallStage", ChitAuctionCallStage.OPEN.name))
                } catch (e: Exception) {
                    ChitAuctionCallStage.OPEN
                },
                discountDistributionRule = try {
                    DiscountDistributionRule.valueOf(
                        json.optString("discountDistributionRule", DiscountDistributionRule.DIVIDE_EQUALLY_ALL_MEMBERS.name)
                    )
                } catch (e: Exception) {
                    DiscountDistributionRule.DIVIDE_EQUALLY_ALL_MEMBERS
                },
                auctionDurationMinutes = json.optInt("auctionDurationMinutes", 60),
                firstCallSeconds = json.optInt("firstCallSeconds", 120),
                secondCallSeconds = json.optInt("secondCallSeconds", 60),
                finalCallSeconds = json.optInt("finalCallSeconds", 30),
                foremanCommissionPercent = json.optDouble("foremanCommissionPercent", 5.0)
            )
        }
    }
}

/**
 * Result of bid validation against auction rules.
 */
data class BidValidationResult(
    val isValid: Boolean,
    val reason: String = "",
    val requiredMinimumNextBid: Double = 0.0
)

/**
 * Result of auction settlement calculation.
 */
data class ChitAuctionSettlement(
    val totalChitValue: Double,
    val winningBidAmount: Double,
    val winnerPrizeAmount: Double,
    val discountAmount: Double,
    val foremanCommission: Double,
    val totalDividendPool: Double,
    val dividendPerMember: Double,
    val netNextInstallment: Double,
    val distributionRule: DiscountDistributionRule
)

/**
 * Structured presentation payload embedded in a Community Post for Chit Fund Auction.
 */
data class ChitAuctionPostData(
    val cycleNumber: Int,
    val totalChitValue: Double,
    val monthlyInstallment: Double,
    val currentHighestBid: Double,
    val minNextBid: Double,
    val callStage: ChitAuctionCallStage,
    val timeRemainingSeconds: Long,
    val bidsCount: Int,
    val latestBidderName: String = "",
    val isAuctionLive: Boolean = true
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("cycleNumber", cycleNumber)
            put("totalChitValue", totalChitValue)
            put("monthlyInstallment", monthlyInstallment)
            put("currentHighestBid", currentHighestBid)
            put("minNextBid", minNextBid)
            put("callStage", callStage.name)
            put("timeRemainingSeconds", timeRemainingSeconds)
            put("bidsCount", bidsCount)
            put("latestBidderName", latestBidderName)
            put("isAuctionLive", isAuctionLive)
        }
    }

    companion object {
        fun fromJson(json: JSONObject?): ChitAuctionPostData? {
            if (json == null) return null
            return ChitAuctionPostData(
                cycleNumber = json.optInt("cycleNumber", 1),
                totalChitValue = json.optDouble("totalChitValue", 0.0),
                monthlyInstallment = json.optDouble("monthlyInstallment", 0.0),
                currentHighestBid = json.optDouble("currentHighestBid", 0.0),
                minNextBid = json.optDouble("minNextBid", 0.0),
                callStage = try {
                    ChitAuctionCallStage.valueOf(json.optString("callStage", ChitAuctionCallStage.OPEN.name))
                } catch (e: Exception) {
                    ChitAuctionCallStage.OPEN
                },
                timeRemainingSeconds = json.optLong("timeRemainingSeconds", 0L),
                bidsCount = json.optInt("bidsCount", 0),
                latestBidderName = json.optString("latestBidderName", ""),
                isAuctionLive = json.optBoolean("isAuctionLive", true)
            )
        }
    }
}
