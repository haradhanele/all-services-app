package com.adr.groupledger.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "group_settings")
data class GroupSettings(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    // 1. Group Profile Settings
    val groupName: String = "All services group",
    val groupSubtitle: String = "Monthly Savings & Contribution Society",
    val description: String = "",
    val groupType: String = "Self-Help Group", // e.g. "Self-Help Group", "Society", "Welfare Club", "Investment Club", "Housing Society", "Sports / Youth Club", "Other"
    val address: String = "",
    val contactPhone: String = "",
    val contactEmail: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val logoUri: String = "",
    val inviteCode: String = "SAMITI-101",
    val createdByUserId: Long = 1,

    // 2. Contribution Configuration Settings
    val isContributionEnabled: Boolean = true,
    val defaultContribution: Double = 500.0,
    val contributionFrequency: String = "MONTHLY", // "MONTHLY", "WEEKLY", "YEARLY", "CUSTOM"
    val dueDayOfMonth: Int = 10,
    val isLateFeeEnabled: Boolean = false,
    val lateFineAmount: Double = 0.0,
    val gracePeriodDays: Int = 5,
    val paymentRules: String = "Monthly contribution is due on or before the 10th of every calendar month. Pending balances roll over.",

    // 3. Home Page Modules Config (JSON format)
    val modulesConfigJson: String = "",

    // 4. Financial & Admin & Security
    val currencySymbol: String = "₹",
    val financialYearStartMonth: Int = 4, // April
    val adminName: String = "Society Treasurer",
    val adminPhone: String = "+91 98765 43210",
    val adminPin: String = "1234",
    val isPinLockEnabled: Boolean = false,
    val themeMode: String = "SYSTEM" // "SYSTEM", "LIGHT", "DARK"
)

