package com.adr.groupledger.data.repository

import com.adr.groupledger.data.firebase.FirebaseService
import com.adr.groupledger.data.local.AuditLogDao
import com.adr.groupledger.data.local.ChatMessageDao
import com.adr.groupledger.data.local.FeedbackDao
import com.adr.groupledger.data.local.GroupMembershipDao
import com.adr.groupledger.data.local.GroupSettingsDao
import com.adr.groupledger.data.local.InvestmentDao
import com.adr.groupledger.data.local.LoanDao
import com.adr.groupledger.data.local.MemberDao
import com.adr.groupledger.data.local.NoticeDao
import com.adr.groupledger.data.local.NotificationDao
import com.adr.groupledger.data.local.PaymentDao
import com.adr.groupledger.data.local.TransactionDao
import com.adr.groupledger.data.local.UserAccountDao
import com.adr.groupledger.data.model.AssetAllocationItem
import com.adr.groupledger.data.model.AuditLog
import com.adr.groupledger.data.model.FeedbackWithVotes
import com.adr.groupledger.data.model.GroupChatMessage
import com.adr.groupledger.data.model.GroupFeedback
import com.adr.groupledger.data.model.GroupMembership
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.InvestmentRecord
import com.adr.groupledger.data.model.LoanRequest
import com.adr.groupledger.data.model.LoanVote
import com.adr.groupledger.data.model.LoanWithVotingDetails
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.MemberFinancialProfile
import com.adr.groupledger.data.model.MonthlyLedgerItem
import com.adr.groupledger.data.model.MonthlyTrendPoint
import com.adr.groupledger.data.model.NotificationItem
import com.adr.groupledger.data.model.OverallGroupFinancials
import com.adr.groupledger.data.model.Payment
import com.adr.groupledger.data.model.PendingPaymentApprovalItem
import com.adr.groupledger.data.model.ProposalVote
import com.adr.groupledger.data.model.RecentTransaction
import com.adr.groupledger.data.model.SocietyNotice
import com.adr.groupledger.data.model.TransactionRecord
import com.adr.groupledger.data.model.UserAccount
import com.adr.groupledger.utils.DateUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.UUID
import kotlin.math.ceil

class SocietyRepository(
    private val userAccountDao: UserAccountDao,
    private val groupMembershipDao: GroupMembershipDao,
    private val memberDao: MemberDao,
    private val paymentDao: PaymentDao,
    private val groupSettingsDao: GroupSettingsDao,
    private val noticeDao: NoticeDao,
    private val loanDao: LoanDao,
    private val investmentDao: InvestmentDao,
    private val feedbackDao: FeedbackDao,
    private val notificationDao: NotificationDao,
    private val transactionDao: TransactionDao,
    private val auditLogDao: AuditLogDao,
    private val chatMessageDao: ChatMessageDao,
    val firebaseService: FirebaseService? = null
) {
    // -------------------------------------------------------------
    // User Accounts & Multi-Group Architecture
    // -------------------------------------------------------------
    fun getAllUsersFlow(): Flow<List<UserAccount>> = userAccountDao.getAllUsersFlow()

    fun getUserByIdFlow(userId: Long): Flow<UserAccount?> = userAccountDao.getUserByIdFlow(userId)

    suspend fun getUserById(userId: Long): UserAccount? = withContext(Dispatchers.IO) {
        userAccountDao.getUserById(userId)
    }

    suspend fun getUserByEmail(email: String): UserAccount? = withContext(Dispatchers.IO) {
        userAccountDao.getUserByEmail(email.trim())
    }

    suspend fun createUserAccount(user: UserAccount): Long = withContext(Dispatchers.IO) {
        val id = userAccountDao.insertUser(user)
        val created = user.copy(id = id)
        firebaseService?.saveUser(created)
        id
    }

    suspend fun updateUserAccount(user: UserAccount) = withContext(Dispatchers.IO) {
        userAccountDao.updateUser(user)
        firebaseService?.saveUser(user)
    }

    fun getMembershipsForUserFlow(userId: Long): Flow<List<GroupMembership>> =
        groupMembershipDao.getMembershipsForUserFlow(userId)

    suspend fun getMembershipsForUserDirect(userId: Long): List<GroupMembership> = withContext(Dispatchers.IO) {
        groupMembershipDao.getMembershipsForUserDirect(userId)
    }

    fun getMembershipFlow(userId: Long, groupId: Long): Flow<GroupMembership?> =
        groupMembershipDao.getMembershipFlow(userId, groupId)

    suspend fun getMembershipDirect(userId: Long, groupId: Long): GroupMembership? = withContext(Dispatchers.IO) {
        groupMembershipDao.getMembershipDirect(userId, groupId)
    }

    fun getAllGroupsFlow(): Flow<List<GroupSettings>> = groupSettingsDao.getAllGroupsFlow()

    suspend fun getAllGroupsDirect(): List<GroupSettings> = withContext(Dispatchers.IO) {
        groupSettingsDao.getAllGroupsDirect()
    }

    fun getGroupSettingsFlow(groupId: Long): Flow<GroupSettings?> = groupSettingsDao.getSettingsFlow(groupId)

    suspend fun getGroupSettings(groupId: Long): GroupSettings? = withContext(Dispatchers.IO) {
        groupSettingsDao.getSettings(groupId)
    }

    suspend fun createGroup(
        groupName: String,
        groupSubtitle: String = "",
        groupType: String = "Self-Help Group",
        defaultContribution: Double = 500.0,
        currencySymbol: String = "₹",
        contributionFrequency: String = "MONTHLY",
        dueDayOfMonth: Int = 10,
        isLateFeeEnabled: Boolean = false,
        lateFineAmount: Double = 0.0,
        gracePeriodDays: Int = 5,
        paymentRules: String = "Contribution is due by the 10th of every month.",
        adminPin: String = "1234",
        isPinLockEnabled: Boolean = false,
        creatorUser: UserAccount
    ): GroupSettings = withContext(Dispatchers.IO) {
        val inviteCode = "GRP-" + UUID.randomUUID().toString().take(6).uppercase()
        val newGroup = GroupSettings(
            id = 0,
            groupName = groupName,
            groupSubtitle = groupSubtitle,
            groupType = groupType,
            inviteCode = inviteCode,
            createdByUserId = creatorUser.id,
            defaultContribution = defaultContribution,
            currencySymbol = currencySymbol,
            contributionFrequency = contributionFrequency,
            dueDayOfMonth = dueDayOfMonth,
            isLateFeeEnabled = isLateFeeEnabled,
            lateFineAmount = lateFineAmount,
            gracePeriodDays = gracePeriodDays,
            paymentRules = paymentRules,
            financialYearStartMonth = 4,
            adminName = creatorUser.fullName,
            adminPhone = creatorUser.phone,
            adminPin = adminPin,
            isPinLockEnabled = isPinLockEnabled
        )
        val newGroupId = groupSettingsDao.insertOrUpdate(newGroup)

        // Add creator as Admin Membership
        val membership = GroupMembership(
            userId = creatorUser.id,
            groupId = newGroupId,
            role = "ADMIN",
            memberIdInGroup = null
        )
        groupMembershipDao.insertMembership(membership)

        // Seed welcome notice
        noticeDao.insertNotice(
            SocietyNotice(
                groupId = newGroupId,
                title = "🎉 Welcome to $groupName",
                content = "Group created by ${creatorUser.fullName}. Share invite code $inviteCode with members to join.",
                category = "ANNOUNCEMENT",
                author = creatorUser.fullName,
                isPinned = true
            )
        )

        // Log audit
        auditLogDao.insertAuditLog(
            AuditLog(
                groupId = newGroupId,
                actorName = creatorUser.fullName,
                actorRole = "Admin",
                action = "GROUP_CREATED",
                newValue = groupName,
                relatedRecord = "Invite code: $inviteCode"
            )
        )

        val created = newGroup.copy(id = newGroupId)
        firebaseService?.saveGroup(created)
        created
    }

    suspend fun regenerateGroupInviteCode(groupId: Long, adminName: String): String = withContext(Dispatchers.IO) {
        val settings = groupSettingsDao.getSettings(groupId) ?: return@withContext ""
        val newCode = "GRP-" + UUID.randomUUID().toString().replace("-", "").take(6).uppercase()
        val updated = settings.copy(inviteCode = newCode)
        groupSettingsDao.insertOrUpdate(updated)

        // Log notice and audit log
        noticeDao.insertNotice(
            SocietyNotice(
                groupId = groupId,
                title = "🔑 New Invite Code Generated",
                content = "Admin $adminName generated a new group joining invitation code: $newCode. Share this code with members to join.",
                category = "ANNOUNCEMENT",
                author = adminName,
                isPinned = false
            )
        )

        auditLogDao.insertAuditLog(
            AuditLog(
                groupId = groupId,
                actorName = adminName,
                actorRole = "Admin",
                action = "INVITE_CODE_REGENERATED",
                newValue = newCode,
                relatedRecord = "Old code: ${settings.inviteCode}"
            )
        )

        newCode
    }

    suspend fun getOrResolveGroupByInviteCode(inviteCode: String): GroupSettings? = withContext(Dispatchers.IO) {
        val trimmed = inviteCode.trim().uppercase()
        groupSettingsDao.getGroupByInviteCode(trimmed)
    }

    suspend fun joinGroupByInviteCode(inviteCode: String, user: UserAccount): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val trimmedCode = inviteCode.trim().uppercase()
        val group = getOrResolveGroupByInviteCode(trimmedCode)
            ?: return@withContext Pair(false, "Invalid invitation code. Please check the code and try again.")

        val existingMembership = groupMembershipDao.getMembershipDirect(user.id, group.id)
        if (existingMembership != null && existingMembership.isActive) {
            return@withContext Pair(true, "You are already a member of ${group.groupName}.")
        }

        // Check if member profile already exists in this group for this phone/name or create one
        val existingMembers = memberDao.getAllMembersDirect(group.id)
        val memberCode = "MBR-${existingMembers.size + 1}"
        val newMember = Member(
            groupId = group.id,
            memberCode = memberCode,
            name = user.fullName,
            phone = user.phone,
            monthlyContribution = group.defaultContribution,
            joinDate = System.currentTimeMillis(),
            isActive = true
        )
        val newMemberId = memberDao.insertMember(newMember)

        val membership = GroupMembership(
            userId = user.id,
            groupId = group.id,
            role = "MEMBER",
            memberIdInGroup = newMemberId
        )
        groupMembershipDao.insertMembership(membership)

        // Audit log
        auditLogDao.insertAuditLog(
            AuditLog(
                groupId = group.id,
                actorName = user.fullName,
                actorRole = "Member",
                action = "MEMBER_JOINED_VIA_CODE",
                newValue = "${user.fullName} ($memberCode)",
                relatedRecord = "User ID: ${user.id}"
            )
        )

        Pair(true, "Successfully joined ${group.groupName}!")
    }

    // -------------------------------------------------------------
    // Scoped Data Streams by Group ID
    // -------------------------------------------------------------
    fun getAllMembers(groupId: Long): Flow<List<Member>> = memberDao.getAllMembers(groupId)
    fun getActiveMembers(groupId: Long): Flow<List<Member>> = memberDao.getActiveMembers(groupId)
    fun getAllPayments(groupId: Long): Flow<List<Payment>> = paymentDao.getAllPayments(groupId)
    fun getNotices(groupId: Long): Flow<List<SocietyNotice>> = noticeDao.getAllNotices(groupId)
    fun getAllLoans(groupId: Long): Flow<List<LoanRequest>> = loanDao.getAllLoansFlow(groupId)
    fun getAllInvestments(groupId: Long): Flow<List<InvestmentRecord>> = investmentDao.getAllInvestmentsFlow(groupId)
    fun getAllFeedbacks(groupId: Long): Flow<List<GroupFeedback>> = feedbackDao.getAllFeedbacksFlow(groupId)
    fun getAllNotifications(groupId: Long): Flow<List<NotificationItem>> = notificationDao.getAllNotificationsFlow(groupId)
    fun getUnreadNotificationsCount(groupId: Long): Flow<Int> = notificationDao.getUnreadCountFlow(groupId)
    fun getAllTransactions(groupId: Long): Flow<List<TransactionRecord>> = transactionDao.getAllTransactionsFlow(groupId)
    fun getChatMessages(groupId: Long): Flow<List<GroupChatMessage>> = chatMessageDao.getAllMessagesFlow(groupId)
    fun getAuditLogs(groupId: Long): Flow<List<AuditLog>> = auditLogDao.getAllAuditLogsFlow(groupId)

    fun getPendingPaymentApprovals(groupId: Long): Flow<List<PendingPaymentApprovalItem>> = combine(
        paymentDao.getPendingApprovalPayments(groupId),
        memberDao.getAllMembers(groupId)
    ) { pendingPayments, members ->
        val membersMap = members.associateBy { it.id }
        pendingPayments.map { payment ->
            val member = membersMap[payment.memberId] ?: Member(
                id = payment.memberId,
                groupId = groupId,
                name = "Member #${payment.memberId}",
                memberCode = "M-${payment.memberId}"
            )
            PendingPaymentApprovalItem(
                payment = payment,
                member = member
            )
        }
    }.flowOn(Dispatchers.IO)

    private fun generateTxnNumber(): String {
        val year = Calendar.getInstance().get(Calendar.YEAR)
        val rand = (1000..9999).random()
        return "TXN-$year-$rand"
    }

    private suspend fun logAudit(
        groupId: Long,
        actorName: String = "Admin",
        actorRole: String = "Admin",
        action: String,
        prev: String = "",
        newVal: String = "",
        record: String = ""
    ) {
        auditLogDao.insertAuditLog(
            AuditLog(
                groupId = groupId,
                actorName = actorName,
                actorRole = actorRole,
                action = action,
                previousValue = prev,
                newValue = newVal,
                relatedRecord = record
            )
        )
    }

    // -------------------------------------------------------------
    // Member Operations
    // -------------------------------------------------------------
    suspend fun getMemberById(id: Long): Member? = withContext(Dispatchers.IO) {
        memberDao.getMemberById(id)
    }

    fun getMemberByIdFlow(id: Long): Flow<Member?> = memberDao.getMemberByIdFlow(id)

    suspend fun insertMember(member: Member): Long = withContext(Dispatchers.IO) {
        val id = memberDao.insertMember(member)
        val created = member.copy(id = id)
        firebaseService?.saveMember(created)
        logAudit(
            groupId = member.groupId,
            action = "MEMBER_ADDED",
            newVal = "${member.name} (${member.memberCode})",
            record = "Member ID: $id"
        )
        id
    }

    suspend fun updateMember(member: Member) = withContext(Dispatchers.IO) {
        memberDao.updateMember(member)
        firebaseService?.saveMember(member)
        logAudit(
            groupId = member.groupId,
            action = "MEMBER_UPDATED",
            newVal = member.name,
            record = "Member ID: ${member.id}"
        )
    }

    suspend fun deleteMember(member: Member) = withContext(Dispatchers.IO) {
        memberDao.deleteMember(member)
        paymentDao.deletePaymentsByMemberId(member.id)
        firebaseService?.deleteMember(member.groupId, member.id)
        logAudit(
            groupId = member.groupId,
            action = "MEMBER_DELETED",
            prev = member.name,
            record = "Member ID: ${member.id}"
        )
    }

    // -------------------------------------------------------------
    // Payment & Approval Workflow Operations
    // -------------------------------------------------------------
    suspend fun submitPaymentForApproval(payment: Payment, memberName: String): Long = withContext(Dispatchers.IO) {
        val pendingPayment = payment.copy(
            approvalStatus = "PENDING_APPROVAL",
            status = "PENDING_APPROVAL",
            submittedAt = System.currentTimeMillis()
        )
        val existing = paymentDao.getPayment(payment.memberId, payment.month, payment.year)
        val id = if (existing != null) {
            val updated = pendingPayment.copy(id = existing.id, groupId = payment.groupId)
            paymentDao.updatePayment(updated)
            firebaseService?.savePayment(updated)
            existing.id
        } else {
            val newId = paymentDao.insertPayment(pendingPayment)
            firebaseService?.savePayment(pendingPayment.copy(id = newId))
            newId
        }

        notificationDao.insertNotification(
            NotificationItem(
                groupId = payment.groupId,
                title = "Payment Approval Request",
                message = "$memberName submitted payment of ₹${payment.paidAmount.toInt()} for ${DateUtils.getMonthName(payment.month)} ${payment.year}. Tap to review.",
                type = "PAYMENT_APPROVAL",
                relatedId = id,
                actionRoute = "monthly"
            )
        )

        logAudit(
            groupId = payment.groupId,
            actorName = memberName,
            actorRole = "Member",
            action = "PAYMENT_SUBMITTED_FOR_APPROVAL",
            newVal = "₹${payment.paidAmount.toInt()} (${payment.paymentMethod})",
            record = "$memberName - ${DateUtils.getMonthName(payment.month)} ${payment.year}"
        )
        id
    }

    suspend fun approvePayment(paymentId: Long, adminName: String): Boolean = withContext(Dispatchers.IO) {
        val payment = paymentDao.getPaymentById(paymentId) ?: return@withContext false
        val member = memberDao.getMemberById(payment.memberId)
        val memberName = member?.name ?: "Member #${payment.memberId}"

        val calculatedStatus = Payment.calculateStatus(payment.expectedAmount, payment.paidAmount)
        val calculatedDue = (payment.expectedAmount - payment.paidAmount).coerceAtLeast(0.0)

        val approvedPayment = payment.copy(
            approvalStatus = "APPROVED",
            status = calculatedStatus,
            dueAmount = calculatedDue,
            approvedAt = System.currentTimeMillis(),
            approvedBy = adminName,
            rejectionReason = ""
        )
        paymentDao.updatePayment(approvedPayment)
        firebaseService?.savePayment(approvedPayment)

        if (payment.paidAmount > 0) {
            val tx = TransactionRecord(
                groupId = payment.groupId,
                txnNumber = generateTxnNumber(),
                date = approvedPayment.paymentDate,
                amount = approvedPayment.paidAmount,
                type = "CONTRIBUTION",
                isCredit = true,
                description = "Monthly contribution for ${DateUtils.getMonthName(payment.month)} ${payment.year} from $memberName (Approved by $adminName)",
                paymentMethod = payment.paymentMethod,
                relatedMemberId = payment.memberId,
                relatedMemberName = memberName,
                createdBy = adminName
            )
            val txId = transactionDao.insertTransaction(tx)
            firebaseService?.saveTransaction(tx.copy(id = txId))
        }

        notificationDao.insertNotification(
            NotificationItem(
                groupId = payment.groupId,
                title = "Payment Approved",
                message = "Your contribution payment of ₹${payment.paidAmount.toInt()} for ${DateUtils.getMonthName(payment.month)} ${payment.year} has been approved.",
                type = "PAYMENT_APPROVED",
                relatedId = paymentId,
                actionRoute = "member/${payment.memberId}"
            )
        )

        logAudit(
            groupId = payment.groupId,
            actorName = adminName,
            actorRole = "Admin",
            action = "PAYMENT_APPROVED",
            newVal = "₹${payment.paidAmount.toInt()} for $memberName",
            record = "Payment ID: $paymentId"
        )
        true
    }

    suspend fun rejectPayment(paymentId: Long, adminName: String, reason: String): Boolean = withContext(Dispatchers.IO) {
        val payment = paymentDao.getPaymentById(paymentId) ?: return@withContext false
        val member = memberDao.getMemberById(payment.memberId)
        val memberName = member?.name ?: "Member #${payment.memberId}"

        val rejectedPayment = payment.copy(
            approvalStatus = "REJECTED",
            status = "REJECTED",
            rejectionReason = reason.ifBlank { "Payment could not be verified." }
        )
        paymentDao.updatePayment(rejectedPayment)
        firebaseService?.savePayment(rejectedPayment)

        notificationDao.insertNotification(
            NotificationItem(
                groupId = payment.groupId,
                title = "Payment Rejected",
                message = "Payment of ₹${payment.paidAmount.toInt()} for ${DateUtils.getMonthName(payment.month)} ${payment.year} was rejected: ${rejectedPayment.rejectionReason}. Please resubmit.",
                type = "PAYMENT_REJECTED",
                relatedId = paymentId,
                actionRoute = "member/${payment.memberId}"
            )
        )

        logAudit(
            groupId = payment.groupId,
            actorName = adminName,
            actorRole = "Admin",
            action = "PAYMENT_REJECTED",
            newVal = "Reason: ${rejectedPayment.rejectionReason}",
            record = "Payment ID: $paymentId ($memberName)"
        )
        true
    }

    suspend fun recordPayment(payment: Payment, adminName: String = "Admin"): Long = withContext(Dispatchers.IO) {
        val approvedPayment = payment.copy(
            approvalStatus = "APPROVED",
            status = Payment.calculateStatus(payment.expectedAmount, payment.paidAmount),
            approvedAt = System.currentTimeMillis(),
            approvedBy = adminName
        )
        val existing = paymentDao.getPayment(payment.memberId, payment.month, payment.year)
        val id = if (existing != null) {
            val updated = approvedPayment.copy(id = existing.id, groupId = payment.groupId)
            paymentDao.updatePayment(updated)
            firebaseService?.savePayment(updated)
            existing.id
        } else {
            val newId = paymentDao.insertPayment(approvedPayment)
            firebaseService?.savePayment(approvedPayment.copy(id = newId))
            newId
        }

        val member = memberDao.getMemberById(payment.memberId)
        val memberName = member?.name ?: "Member #${payment.memberId}"

        if (payment.paidAmount > 0) {
            val tx = TransactionRecord(
                groupId = payment.groupId,
                txnNumber = generateTxnNumber(),
                date = payment.paymentDate,
                amount = payment.paidAmount,
                type = "CONTRIBUTION",
                isCredit = true,
                description = "Monthly contribution for ${DateUtils.getMonthName(payment.month)} ${payment.year} from $memberName",
                paymentMethod = payment.paymentMethod,
                relatedMemberId = payment.memberId,
                relatedMemberName = memberName,
                createdBy = adminName
            )
            val txId = transactionDao.insertTransaction(tx)
            firebaseService?.saveTransaction(tx.copy(id = txId))
        }

        logAudit(
            groupId = payment.groupId,
            actorName = adminName,
            actorRole = "Admin",
            action = "PAYMENT_RECORDED",
            newVal = "₹${payment.paidAmount.toInt()} (${payment.status})",
            record = "$memberName - ${DateUtils.getMonthName(payment.month)} ${payment.year}"
        )
        id
    }

    suspend fun quickMarkPaid(
        groupId: Long,
        memberId: Long,
        month: Int,
        year: Int,
        amount: Double,
        paymentMethod: String = "Cash",
        adminName: String = "Admin"
    ) = withContext(Dispatchers.IO) {
        val member = memberDao.getMemberById(memberId) ?: return@withContext
        val expected = if (member.monthlyContribution > 0) member.monthlyContribution else 500.0
        val due = (expected - amount).coerceAtLeast(0.0)
        val status = if (due <= 0.0) "PAID" else if (amount > 0) "PARTIAL" else "UNPAID"

        val payment = Payment(
            groupId = groupId,
            memberId = memberId,
            month = month,
            year = year,
            expectedAmount = expected,
            paidAmount = amount,
            dueAmount = due,
            paymentDate = System.currentTimeMillis(),
            paymentMethod = paymentMethod,
            transactionReference = "REC-${System.currentTimeMillis() % 10000}",
            notes = "Quick entry",
            status = status,
            approvalStatus = "APPROVED",
            approvedAt = System.currentTimeMillis(),
            approvedBy = adminName
        )
        recordPayment(payment, adminName)
    }

    // -------------------------------------------------------------
    // Loans & 70% Voting Operations
    // -------------------------------------------------------------
    fun getLoansWithVotingDetails(groupId: Long): Flow<List<LoanWithVotingDetails>> = combine(
        loanDao.getAllLoansFlow(groupId),
        memberDao.getActiveMembers(groupId)
    ) { loans, activeMembersList ->
        val totalActive = activeMembersList.size
        loans.map { loan ->
            val votes = loanDao.getVotesForLoan(loan.id)
            val eligible = (totalActive - 1).coerceAtLeast(1)
            val required = ceil(eligible * 0.70).toInt()
            val approves = votes.count { it.vote == "APPROVE" }
            val rejects = votes.count { it.vote == "REJECT" }
            val pending = (eligible - (approves + rejects)).coerceAtLeast(0)
            val pct = if (eligible > 0) ((approves.toFloat() / eligible.toFloat()) * 100f) else 0f
            val isThresholdReached = approves >= required
            val isExpired = System.currentTimeMillis() > loan.votingDeadline

            LoanWithVotingDetails(
                loan = loan,
                totalActiveMembers = totalActive,
                eligibleVoters = eligible,
                requiredApprovals = required,
                approveCount = approves,
                rejectCount = rejects,
                pendingCount = pending,
                approvalPercentage = pct,
                isApprovedThresholdReached = isThresholdReached,
                isVotingExpired = isExpired,
                votes = votes,
                userVote = null
            )
        }
    }.flowOn(Dispatchers.IO)

    suspend fun submitLoanRequest(loan: LoanRequest): Long = withContext(Dispatchers.IO) {
        val id = loanDao.insertLoan(loan)
        val created = loan.copy(id = id)
        firebaseService?.saveLoan(created)
        notificationDao.insertNotification(
            NotificationItem(
                groupId = loan.groupId,
                title = "New Group Loan Request",
                message = "${loan.requesterName} requested ₹${loan.requestedAmount.toInt()} for ${loan.purpose}. Tap to vote.",
                type = "LOAN_VOTING",
                relatedId = id,
                actionRoute = "loans"
            )
        )
        logAudit(
            groupId = loan.groupId,
            actorName = loan.requesterName,
            actorRole = "Member",
            action = "LOAN_REQUESTED",
            newVal = "₹${loan.requestedAmount.toInt()} - ${loan.purpose}",
            record = "Loan ID: $id"
        )
        id
    }

    suspend fun voteOnLoan(loanId: Long, memberId: Long, memberName: String, vote: String): Boolean = withContext(Dispatchers.IO) {
        val loan = loanDao.getLoanById(loanId) ?: return@withContext false
        if (loan.status != "VOTING" && loan.status != "SUBMITTED") return@withContext false

        loanDao.insertVote(
            LoanVote(
                loanRequestId = loanId,
                memberId = memberId,
                memberName = memberName,
                vote = vote
            )
        )

        val votes = loanDao.getVotesForLoan(loanId)
        val activeCount = memberDao.getActiveMemberCountDirect(loan.groupId)
        val eligible = (activeCount - 1).coerceAtLeast(1)
        val required = ceil(eligible * 0.70).toInt()
        val approves = votes.count { it.vote == "APPROVE" }
        val rejects = votes.count { it.vote == "REJECT" }

        if (approves >= required && loan.status == "VOTING") {
            loanDao.updateLoan(loan.copy(status = "APPROVED"))
            notificationDao.insertNotification(
                NotificationItem(
                    groupId = loan.groupId,
                    title = "Loan Approved by 70% Majority!",
                    message = "Loan for ${loan.requesterName} (₹${loan.requestedAmount.toInt()}) has reached 70% approval.",
                    type = "LOAN_APPROVED",
                    relatedId = loanId,
                    actionRoute = "loans"
                )
            )
            logAudit(
                groupId = loan.groupId,
                action = "LOAN_APPROVED_BY_VOTE",
                newVal = "70% Quorum Reached",
                record = "Loan ID: $loanId"
            )
        } else if (rejects > (eligible - required) && loan.status == "VOTING") {
            loanDao.updateLoan(loan.copy(status = "REJECTED"))
            logAudit(
                groupId = loan.groupId,
                action = "LOAN_REJECTED_BY_VOTE",
                record = "Loan ID: $loanId"
            )
        }
        true
    }

    suspend fun disburseLoan(loanId: Long, adminName: String): Boolean = withContext(Dispatchers.IO) {
        val loan = loanDao.getLoanById(loanId) ?: return@withContext false
        val updated = loan.copy(
            status = "ACTIVE",
            disbursedDate = System.currentTimeMillis(),
            disbursedBy = adminName
        )
        loanDao.updateLoan(updated)

        transactionDao.insertTransaction(
            TransactionRecord(
                groupId = loan.groupId,
                txnNumber = generateTxnNumber(),
                date = System.currentTimeMillis(),
                amount = loan.requestedAmount,
                type = "LOAN_DISBURSEMENT",
                isCredit = false,
                description = "Loan disbursed to ${loan.requesterName} for ${loan.purpose}",
                paymentMethod = "Bank Transfer",
                relatedMemberId = loan.requesterMemberId,
                relatedMemberName = loan.requesterName,
                relatedLoanId = loan.id,
                createdBy = adminName
            )
        )
        logAudit(
            groupId = loan.groupId,
            actorName = adminName,
            actorRole = "Admin",
            action = "LOAN_DISBURSED",
            newVal = "₹${loan.requestedAmount.toInt()}",
            record = "Loan ID: $loanId"
        )
        true
    }

    suspend fun recordLoanRepayment(
        loanId: Long,
        amount: Double,
        paymentMethod: String,
        notes: String,
        adminName: String
    ): Boolean = withContext(Dispatchers.IO) {
        val loan = loanDao.getLoanById(loanId) ?: return@withContext false
        val newRepaid = loan.repaidAmount + amount
        val newRemaining = (loan.requestedAmount - newRepaid).coerceAtLeast(0.0)
        val newStatus = if (newRemaining <= 0.0) "FULLY_REPAID" else "PARTIALLY_REPAID"

        loanDao.updateLoan(
            loan.copy(
                repaidAmount = newRepaid,
                remainingAmount = newRemaining,
                status = newStatus
            )
        )

        transactionDao.insertTransaction(
            TransactionRecord(
                groupId = loan.groupId,
                txnNumber = generateTxnNumber(),
                date = System.currentTimeMillis(),
                amount = amount,
                type = "LOAN_REPAYMENT",
                isCredit = true,
                description = "Loan repayment from ${loan.requesterName} ($notes)",
                paymentMethod = paymentMethod,
                relatedMemberId = loan.requesterMemberId,
                relatedMemberName = loan.requesterName,
                relatedLoanId = loan.id,
                createdBy = adminName
            )
        )
        logAudit(
            groupId = loan.groupId,
            actorName = adminName,
            actorRole = "Treasurer",
            action = "LOAN_REPAYMENT",
            newVal = "₹${amount.toInt()}",
            record = "Loan ID: $loanId"
        )
        true
    }

    // -------------------------------------------------------------
    // Investments & Deletion Functionality
    // -------------------------------------------------------------
    suspend fun addInvestment(investment: InvestmentRecord): Long = withContext(Dispatchers.IO) {
        val id = investmentDao.insertInvestment(investment)
        transactionDao.insertTransaction(
            TransactionRecord(
                groupId = investment.groupId,
                txnNumber = generateTxnNumber(),
                date = investment.investmentDate,
                amount = investment.principalAmount,
                type = "INVESTMENT_PURCHASE",
                isCredit = false,
                description = "Investment placed: ${investment.name} (${investment.institution})",
                paymentMethod = "Bank Transfer",
                relatedInvestmentId = id,
                createdBy = "Admin"
            )
        )
        logAudit(
            groupId = investment.groupId,
            action = "INVESTMENT_ADDED",
            newVal = "${investment.name} - ₹${investment.principalAmount.toInt()}",
            record = "Investment ID: $id"
        )
        id
    }

    suspend fun updateInvestment(investment: InvestmentRecord) = withContext(Dispatchers.IO) {
        investmentDao.updateInvestment(investment.copy(lastUpdated = System.currentTimeMillis()))
        logAudit(
            groupId = investment.groupId,
            action = "INVESTMENT_VALUATION_UPDATED",
            newVal = "₹${investment.currentValue.toInt()}",
            record = investment.name
        )
    }

    suspend fun deleteInvestment(investmentId: Long, adminName: String): Boolean = withContext(Dispatchers.IO) {
        val investment = investmentDao.getInvestmentById(investmentId) ?: return@withContext false
        investmentDao.softDeleteInvestment(investmentId, adminName)
        logAudit(
            groupId = investment.groupId,
            actorName = adminName,
            actorRole = "Admin",
            action = "INVESTMENT_DELETED",
            prev = "${investment.name} (₹${investment.principalAmount.toInt()})",
            record = "Investment ID: $investmentId"
        )
        true
    }

    // -------------------------------------------------------------
    // Feedback & Proposals
    // -------------------------------------------------------------
    fun getFeedbacksWithVotes(groupId: Long): Flow<List<FeedbackWithVotes>> = combine(
        feedbackDao.getAllFeedbacksFlow(groupId),
        memberDao.getActiveMembers(groupId)
    ) { feedbacks, activeMembersList ->
        val totalActive = activeMembersList.size
        feedbacks.map { fb ->
            val votes = feedbackDao.getVotesForProposal(fb.id)
            val agrees = votes.count { it.vote == "AGREE" }
            val disagrees = votes.count { it.vote == "DISAGREE" }
            val pending = (totalActive - (agrees + disagrees)).coerceAtLeast(0)
            val pct = if (totalActive > 0) ((agrees.toFloat() / totalActive.toFloat()) * 100f) else 0f

            FeedbackWithVotes(
                feedback = fb,
                totalEligibleVoters = totalActive,
                agreeCount = agrees,
                disagreeCount = disagrees,
                pendingCount = pending,
                agreePercentage = pct,
                userVote = null
            )
        }
    }.flowOn(Dispatchers.IO)

    suspend fun submitFeedback(feedback: GroupFeedback): Long = withContext(Dispatchers.IO) {
        val id = feedbackDao.insertFeedback(feedback)
        if (feedback.requiresVoting) {
            notificationDao.insertNotification(
                NotificationItem(
                    groupId = feedback.groupId,
                    title = "New Proposal for Group Voting",
                    message = "${feedback.subject}. Cast your vote.",
                    type = "PROPOSAL",
                    relatedId = id,
                    actionRoute = "feedback"
                )
            )
        }
        id
    }

    suspend fun voteOnProposal(feedbackId: Long, memberId: Long, memberName: String, vote: String) = withContext(Dispatchers.IO) {
        feedbackDao.insertProposalVote(
            ProposalVote(
                feedbackId = feedbackId,
                memberId = memberId,
                memberName = memberName,
                vote = vote
            )
        )
    }

    // -------------------------------------------------------------
    // Comprehensive Financial Aggregations
    // -------------------------------------------------------------
    fun getComprehensiveFinancials(groupId: Long): Flow<OverallGroupFinancials> = combine(
        memberDao.getAllMembers(groupId),
        paymentDao.getAllPayments(groupId),
        investmentDao.getAllInvestmentsFlow(groupId),
        loanDao.getAllLoansFlow(groupId),
        notificationDao.getUnreadCountFlow(groupId)
    ) { members, allPaymentsList, investments, loans, unreadCount ->
        val activeMembers = members.filter { it.isActive }
        val totalMembersCount = members.size
        val activeMembersCount = activeMembers.size

        val approvedPayments = allPaymentsList.filter { it.isApproved }

        val totalCollectedAllTime = approvedPayments.sumOf { it.paidAmount }
        val totalDueAllTime = allPaymentsList.filter { !it.isApproved }.sumOf { it.expectedAmount } +
                approvedPayments.sumOf { it.dueAmount }

        val cal = Calendar.getInstance()
        val curMonth = cal.get(Calendar.MONTH) + 1
        val curYear = cal.get(Calendar.YEAR)

        val curMonthApprovedPayments = approvedPayments.filter { it.month == curMonth && it.year == curYear }
        val curMonthAllPayments = allPaymentsList.filter { it.month == curMonth && it.year == curYear }

        val curCollected = curMonthApprovedPayments.sumOf { it.paidAmount }
        val curDue = curMonthAllPayments.filter { !it.isApproved }.sumOf { it.expectedAmount } +
                curMonthApprovedPayments.sumOf { it.dueAmount }
        val curPaidCount = curMonthApprovedPayments.count { it.status == "PAID" }
        val curUnpaidCount = curMonthAllPayments.count { it.status == "UNPAID" || it.status == "REJECTED" }
        val curPartialCount = curMonthApprovedPayments.count { it.status == "PARTIAL" }

        val prevMonth = if (curMonth == 1) 12 else curMonth - 1
        val prevYear = if (curMonth == 1) curYear - 1 else curYear
        val prevCollected = approvedPayments.filter { it.month == prevMonth && it.year == prevYear }.sumOf { it.paidAmount }

        val trends = mutableListOf<MonthlyTrendPoint>()
        for (i in 5 downTo 0) {
            val tCal = Calendar.getInstance().apply { add(Calendar.MONTH, -i) }
            val tm = tCal.get(Calendar.MONTH) + 1
            val ty = tCal.get(Calendar.YEAR)
            val tApproved = approvedPayments.filter { it.month == tm && it.year == ty }
            val tAll = allPaymentsList.filter { it.month == tm && it.year == ty }
            trends.add(
                MonthlyTrendPoint(
                    month = tm,
                    year = ty,
                    label = DateUtils.getMonthShortName(tm),
                    collected = tApproved.sumOf { it.paidAmount },
                    expected = tAll.sumOf { it.expectedAmount }.coerceAtLeast(tApproved.sumOf { it.paidAmount })
                )
            )
        }

        val activeInvestments = investments.filter { it.status == "ACTIVE" && !it.isDeleted }
        val totalInvestmentsVal = activeInvestments.sumOf { it.currentValue }
        val fdVal = activeInvestments.filter { it.type == "FD" }.sumOf { it.currentValue }
        val mfVal = activeInvestments.filter { it.type == "MUTUAL_FUND" }.sumOf { it.currentValue }
        val stockVal = activeInvestments.filter { it.type == "STOCK" }.sumOf { it.currentValue }
        val otherInvVal = activeInvestments.filter { it.type !in listOf("FD", "MUTUAL_FUND", "STOCK") }.sumOf { it.currentValue }

        val activeLoans = loans.filter { it.status in listOf("ACTIVE", "DISBURSED", "PARTIALLY_REPAID") }
        val loansGivenTotal = loans.filter { it.status in listOf("ACTIVE", "DISBURSED", "PARTIALLY_REPAID", "FULLY_REPAID") }.sumOf { it.requestedAmount }
        val outstandingLoans = activeLoans.sumOf { it.remainingAmount }
        val pendingLoansCount = loans.count { it.status in listOf("SUBMITTED", "VOTING") }

        val totalLoanRepayments = loans.sumOf { it.repaidAmount }
        val totalInvestedPrincipal = activeInvestments.sumOf { it.principalAmount }
        val totalLoansOutflow = activeLoans.sumOf { it.requestedAmount }

        val availableBalance = (totalCollectedAllTime + totalLoanRepayments - totalInvestedPrincipal - totalLoansOutflow).coerceAtLeast(15000.0)
        val bankBalance = availableBalance * 0.75
        val cashBalance = availableBalance * 0.25

        val totalGroupAssets = availableBalance + totalInvestmentsVal + outstandingLoans

        val assetItems = mutableListOf<AssetAllocationItem>()
        if (totalGroupAssets > 0) {
            assetItems.add(
                AssetAllocationItem(
                    category = "Bank & Cash",
                    amount = availableBalance,
                    percentage = ((availableBalance / totalGroupAssets) * 100).toFloat(),
                    colorHex = 0xFF4F46E5
                )
            )
            if (totalInvestmentsVal > 0) {
                assetItems.add(
                    AssetAllocationItem(
                        category = "Investments & FDs",
                        amount = totalInvestmentsVal,
                        percentage = ((totalInvestmentsVal / totalGroupAssets) * 100).toFloat(),
                        colorHex = 0xFF10B981
                    )
                )
            }
            if (outstandingLoans > 0) {
                assetItems.add(
                    AssetAllocationItem(
                        category = "Active Loans",
                        amount = outstandingLoans,
                        percentage = ((outstandingLoans / totalGroupAssets) * 100).toFloat(),
                        colorHex = 0xFFF59E0B
                    )
                )
            }
        }

        OverallGroupFinancials(
            totalMembers = totalMembersCount,
            activeMembers = activeMembersCount,
            totalCollectedAllTime = totalCollectedAllTime,
            totalDueAllTime = totalDueAllTime,
            currentMonthCollected = curCollected,
            currentMonthDue = curDue,
            currentMonthPaidCount = curPaidCount,
            currentMonthUnpaidCount = curUnpaidCount,
            currentMonthPartialCount = curPartialCount,
            previousMonthCollected = prevCollected,
            monthlyTrends = trends,
            totalGroupAssets = totalGroupAssets,
            availableInHandBalance = availableBalance,
            bankBalance = bankBalance,
            cashBalance = cashBalance,
            loansGivenTotal = loansGivenTotal,
            outstandingLoans = outstandingLoans,
            totalInvestmentsValue = totalInvestmentsVal,
            fixedDepositValue = fdVal,
            mutualFundsValue = mfVal,
            stockMarketValue = stockVal,
            otherInvestmentsValue = otherInvVal,
            pendingLoanRequestsCount = pendingLoansCount,
            unreadNotificationsCount = unreadCount,
            totalExpenses = totalLoansOutflow + totalInvestedPrincipal,
            assetAllocations = assetItems
        )
    }.flowOn(Dispatchers.IO)

    // Member Financial Profile
    fun getMemberFinancialProfile(memberId: Long): Flow<MemberFinancialProfile?> = combine(
        memberDao.getMemberByIdFlow(memberId),
        paymentDao.getPaymentsForMember(memberId)
    ) { member, payments ->
        if (member == null) return@combine null

        val settings = groupSettingsDao.getSettings(member.groupId)
        val defaultExp = settings?.defaultContribution ?: 500.0
        val expPerMonth = if (member.monthlyContribution > 0) member.monthlyContribution else defaultExp

        val approvedPayments = payments.filter { it.isApproved }
        val totalExpected = payments.sumOf { it.expectedAmount }.coerceAtLeast(expPerMonth)
        val totalPaid = approvedPayments.sumOf { it.paidAmount }
        val totalDue = (totalExpected - totalPaid).coerceAtLeast(0.0)

        val cal = Calendar.getInstance()
        val curMonth = cal.get(Calendar.MONTH) + 1
        val curYear = cal.get(Calendar.YEAR)
        val curPay = payments.find { it.month == curMonth && it.year == curYear }
        val curStatus = when {
            curPay == null -> "UNPAID"
            curPay.isPendingApproval -> "PENDING_APPROVAL"
            curPay.isRejected -> "REJECTED"
            else -> curPay.status
        }

        val history = payments.sortedWith(compareByDescending<Payment> { it.year }.thenByDescending { it.month })
            .map { p ->
                val displayStatus = when {
                    p.isPendingApproval -> "PENDING_APPROVAL"
                    p.isRejected -> "REJECTED"
                    else -> p.status
                }
                MonthlyLedgerItem(
                    month = p.month,
                    year = p.year,
                    monthName = DateUtils.getMonthName(p.month),
                    expectedAmount = p.expectedAmount,
                    paidAmount = if (p.isApproved) p.paidAmount else 0.0,
                    dueAmount = if (p.isApproved) p.dueAmount else p.expectedAmount,
                    status = displayStatus,
                    paymentDate = p.paymentDate,
                    paymentMethod = p.paymentMethod,
                    transactionRef = p.transactionReference,
                    notes = if (p.isRejected && p.rejectionReason.isNotBlank()) "Rejected: ${p.rejectionReason}" else p.notes
                )
            }

        MemberFinancialProfile(
            member = member,
            totalExpectedAllTime = totalExpected,
            totalPaidAllTime = totalPaid,
            totalDueAllTime = totalDue,
            currentMonthStatus = curStatus,
            paymentHistory = history
        )
    }.flowOn(Dispatchers.IO)

    fun getRecentTransactions(groupId: Long, limit: Int): Flow<List<RecentTransaction>> = combine(
        paymentDao.getAllPayments(groupId),
        memberDao.getAllMembers(groupId)
    ) { payments, members ->
        val membersMap = members.associateBy { it.id }
        payments.filter { it.paidAmount > 0 && it.isApproved }
            .sortedByDescending { it.paymentDate }
            .take(limit)
            .map { p ->
                val m = membersMap[p.memberId]
                RecentTransaction(
                    paymentId = p.id,
                    memberId = p.memberId,
                    memberName = m?.name ?: "Member #${p.memberId}",
                    memberCode = m?.memberCode ?: "M-${p.memberId}",
                    month = p.month,
                    year = p.year,
                    amount = p.paidAmount,
                    paymentDate = p.paymentDate,
                    paymentMethod = p.paymentMethod,
                    status = p.status
                )
            }
    }.flowOn(Dispatchers.IO)

    // Settings
    suspend fun updateSettings(settings: GroupSettings) = withContext(Dispatchers.IO) {
        groupSettingsDao.insertOrUpdate(settings)
        firebaseService?.saveGroup(settings)
        logAudit(
            groupId = settings.id,
            action = "SETTINGS_UPDATED",
            record = "Group Name: ${settings.groupName}"
        )
    }

    // Notices
    suspend fun addNotice(notice: SocietyNotice): Long = withContext(Dispatchers.IO) {
        val id = noticeDao.insertNotice(notice)
        val created = notice.copy(id = id)
        firebaseService?.saveNotice(created)
        notificationDao.insertNotification(
            NotificationItem(
                groupId = notice.groupId,
                title = notice.title,
                message = notice.content.take(60),
                type = "ANNOUNCEMENT",
                relatedId = id,
                actionRoute = "chat"
            )
        )
        id
    }

    suspend fun updateNotice(notice: SocietyNotice) = withContext(Dispatchers.IO) {
        noticeDao.updateNotice(notice)
        firebaseService?.saveNotice(notice)
    }

    suspend fun deleteNotice(notice: SocietyNotice) = withContext(Dispatchers.IO) {
        noticeDao.deleteNotice(notice)
        firebaseService?.deleteNotice(notice.groupId, notice.id)
    }

    // Notifications & Chat
    suspend fun markNotificationRead(id: Long) = withContext(Dispatchers.IO) {
        notificationDao.markAsRead(id)
    }

    suspend fun markAllNotificationsRead(groupId: Long) = withContext(Dispatchers.IO) {
        notificationDao.markAllAsRead(groupId)
    }

    suspend fun sendChatMessage(chat: GroupChatMessage): Long = withContext(Dispatchers.IO) {
        val id = chatMessageDao.insertMessage(chat)
        val created = chat.copy(id = id)
        firebaseService?.saveChatMessage(created)
        id
    }

    // -------------------------------------------------------------
    // Real-Time Cloud Firestore Sync Helpers
    // -------------------------------------------------------------
    suspend fun syncFromFirestoreMembers(members: List<Member>) = withContext(Dispatchers.IO) {
        if (members.isNotEmpty()) {
            memberDao.insertMembers(members)
        }
    }

    suspend fun syncFromFirestorePayments(payments: List<Payment>) = withContext(Dispatchers.IO) {
        if (payments.isNotEmpty()) {
            paymentDao.insertPayments(payments)
        }
    }

    suspend fun syncFromFirestoreTransactions(transactions: List<TransactionRecord>) = withContext(Dispatchers.IO) {
        if (transactions.isNotEmpty()) {
            transactionDao.insertTransactions(transactions)
        }
    }

    suspend fun syncFromFirestoreNotices(notices: List<SocietyNotice>) = withContext(Dispatchers.IO) {
        for (n in notices) {
            noticeDao.insertNotice(n)
        }
    }

    suspend fun syncFromFirestoreLoans(loans: List<LoanRequest>) = withContext(Dispatchers.IO) {
        for (l in loans) {
            loanDao.insertLoan(l)
        }
    }

    suspend fun syncFromFirestoreMessages(messages: List<GroupChatMessage>) = withContext(Dispatchers.IO) {
        if (messages.isNotEmpty()) {
            chatMessageDao.insertMessages(messages)
        }
    }

    suspend fun syncFromFirestoreGroupSettings(settings: GroupSettings) = withContext(Dispatchers.IO) {
        groupSettingsDao.insertOrUpdate(settings)
    }

    // Backup & Restore for Group
    suspend fun exportDataAsJson(groupId: Long): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        val members = memberDao.getAllMembersDirect(groupId)
        val payments = paymentDao.getAllPaymentsDirect(groupId)
        val settings = groupSettingsDao.getSettings(groupId)

        val mArr = JSONArray()
        members.forEach { m ->
            mArr.put(
                JSONObject().apply {
                    put("id", m.id)
                    put("groupId", m.groupId)
                    put("memberCode", m.memberCode)
                    put("name", m.name)
                    put("phone", m.phone)
                    put("address", m.address)
                    put("joinDate", m.joinDate)
                    put("monthlyContribution", m.monthlyContribution)
                    put("photoUri", m.photoUri)
                    put("isActive", m.isActive)
                    put("notes", m.notes)
                }
            )
        }
        root.put("members", mArr)

        val pArr = JSONArray()
        payments.forEach { p ->
            pArr.put(
                JSONObject().apply {
                    put("id", p.id)
                    put("groupId", p.groupId)
                    put("memberId", p.memberId)
                    put("month", p.month)
                    put("year", p.year)
                    put("expectedAmount", p.expectedAmount)
                    put("paidAmount", p.paidAmount)
                    put("dueAmount", p.dueAmount)
                    put("paymentDate", p.paymentDate)
                    put("paymentMethod", p.paymentMethod)
                    put("transactionReference", p.transactionReference)
                    put("notes", p.notes)
                    put("status", p.status)
                    put("approvalStatus", p.approvalStatus)
                    put("rejectionReason", p.rejectionReason)
                }
            )
        }
        root.put("payments", pArr)

        settings?.let { s ->
            root.put(
                "settings",
                JSONObject().apply {
                    put("id", s.id)
                    put("groupName", s.groupName)
                    put("groupSubtitle", s.groupSubtitle)
                    put("inviteCode", s.inviteCode)
                    put("defaultContribution", s.defaultContribution)
                    put("currencySymbol", s.currencySymbol)
                    put("adminName", s.adminName)
                    put("adminPhone", s.adminPhone)
                    put("paymentRules", s.paymentRules)
                }
            )
        }
        root.toString(2)
    }

    suspend fun restoreDataFromJson(groupId: Long, jsonString: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonString)
            if (root.has("members")) {
                val mArr = root.getJSONArray("members")
                val restoredMembers = mutableListOf<Member>()
                for (i in 0 until mArr.length()) {
                    val obj = mArr.getJSONObject(i)
                    restoredMembers.add(
                        Member(
                            id = obj.optLong("id", 0),
                            groupId = groupId,
                            memberCode = obj.optString("memberCode", "M-$i"),
                            name = obj.optString("name", "Member"),
                            phone = obj.optString("phone", ""),
                            address = obj.optString("address", ""),
                            joinDate = obj.optLong("joinDate", System.currentTimeMillis()),
                            monthlyContribution = obj.optDouble("monthlyContribution", 500.0),
                            photoUri = obj.optString("photoUri", ""),
                            isActive = obj.optBoolean("isActive", true),
                            notes = obj.optString("notes", "")
                        )
                    )
                }
                if (restoredMembers.isNotEmpty()) {
                    memberDao.insertMembers(restoredMembers)
                }
            }

            if (root.has("payments")) {
                val pArr = root.getJSONArray("payments")
                val restoredPayments = mutableListOf<Payment>()
                for (i in 0 until pArr.length()) {
                    val obj = pArr.getJSONObject(i)
                    restoredPayments.add(
                        Payment(
                            id = obj.optLong("id", 0),
                            groupId = groupId,
                            memberId = obj.optLong("memberId", 1),
                            month = obj.optInt("month", 1),
                            year = obj.optInt("year", 2026),
                            expectedAmount = obj.optDouble("expectedAmount", 500.0),
                            paidAmount = obj.optDouble("paidAmount", 500.0),
                            dueAmount = obj.optDouble("dueAmount", 0.0),
                            paymentDate = obj.optLong("paymentDate", System.currentTimeMillis()),
                            paymentMethod = obj.optString("paymentMethod", "Cash"),
                            transactionReference = obj.optString("transactionReference", ""),
                            notes = obj.optString("notes", ""),
                            status = obj.optString("status", "PAID"),
                            approvalStatus = obj.optString("approvalStatus", "APPROVED"),
                            rejectionReason = obj.optString("rejectionReason", "")
                        )
                    )
                }
                if (restoredPayments.isNotEmpty()) {
                    paymentDao.insertPayments(restoredPayments)
                }
            }

            if (root.has("settings")) {
                val sObj = root.getJSONObject("settings")
                val settings = GroupSettings(
                    id = groupId,
                    groupName = sObj.optString("groupName", "All services group"),
                    groupSubtitle = sObj.optString("groupSubtitle", "Community Monthly Contribution & Savings Society"),
                    inviteCode = sObj.optString("inviteCode", "SAMITI-101"),
                    defaultContribution = sObj.optDouble("defaultContribution", 500.0),
                    currencySymbol = sObj.optString("currencySymbol", "₹"),
                    adminName = sObj.optString("adminName", "Admin"),
                    adminPhone = sObj.optString("adminPhone", ""),
                    paymentRules = sObj.optString("paymentRules", "")
                )
                groupSettingsDao.insertOrUpdate(settings)
            }
            logAudit(groupId = groupId, action = "BACKUP_RESTORED", record = "JSON Import Successful")
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
