package com.adr.groupledger.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AppRegistration
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.BrightnessAuto
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.appOutlinedTextFieldColors
import com.adr.groupledger.ui.viewmodel.SocietyViewModel

@Composable
fun MoreScreen(
    viewModel: SocietyViewModel,
    onNavigateToLoans: () -> Unit,
    onNavigateToInvestments: () -> Unit,
    onNavigateToFeedback: () -> Unit,
    onNavigateToLedger: () -> Unit,
    onNavigateToMonthly: () -> Unit,
    onNavigateToDues: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToBackup: () -> Unit,
    onNavigateToMyProfile: (Long) -> Unit,
    onNavigateToMembers: () -> Unit = {},
    onNavigateToAddMember: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val allGroups by viewModel.allGroups.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val userMemberships by viewModel.userMemberships.collectAsStateWithLifecycle()
    val currentUserRole by viewModel.currentUserRole.collectAsStateWithLifecycle()
    val loansWithVoting by viewModel.allLoansWithVotes.collectAsStateWithLifecycle()
    val members by viewModel.allActiveMembers.collectAsStateWithLifecycle()
    val currentMemberId by viewModel.currentMemberId.collectAsStateWithLifecycle()
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()

    val currentUserId by viewModel.currentUserId.collectAsStateWithLifecycle()

    // 1. Determine Account Status and Permissions
    val isSignedUpUser = currentUser?.isAccountCompleted == true
    val effectiveUserId = currentUser?.id ?: currentUserId

    // Groups I Manage List: Created by this user OR where user role is ADMIN
    val managedGroups = remember(allGroups, userMemberships, currentUser, currentUserId) {
        val uid = currentUser?.id ?: currentUserId
        val userPhone = currentUser?.phone?.trim().orEmpty()
        val userEmail = currentUser?.email?.trim().orEmpty()
        val userName = currentUser?.fullName?.trim().orEmpty()

        allGroups.filter { g ->
            g.createdByUserId == uid ||
            userMemberships.any { m -> m.groupId == g.id && m.role.equals("ADMIN", ignoreCase = true) } ||
            (userPhone.isNotBlank() && g.adminPhone.isNotBlank() && g.adminPhone.trim() == userPhone) ||
            (userEmail.isNotBlank() && g.contactEmail.isNotBlank() && g.contactEmail.trim().equals(userEmail, ignoreCase = true)) ||
            (userName.isNotBlank() && g.adminName.isNotBlank() && g.adminName.trim().equals(userName, ignoreCase = true))
        }.distinctBy { it.id }
    }

    // Groups I Joined List: Where user is a non-admin member
    val joinedGroups = remember(allGroups, userMemberships, currentUser, currentUserId, managedGroups) {
        val managedIds = managedGroups.map { it.id }.toSet()
        allGroups.filter { g ->
            g.id !in managedIds &&
            userMemberships.any { m -> m.groupId == g.id && !m.role.equals("ADMIN", ignoreCase = true) }
        }.distinctBy { it.id }
    }

    val isGroupAdmin = currentUserRole.equals("ADMIN", ignoreCase = true) ||
            settings.createdByUserId == effectiveUserId ||
            managedGroups.any { it.id == settings.id } ||
            isAdminUnlocked

    val pendingLoansCount = remember(loansWithVoting) {
        loansWithVoting.count { it.loan.status in listOf("VOTING", "SUBMITTED") }
    }

    val currentMember = remember(members, currentMemberId) {
        members.find { it.id == currentMemberId } ?: members.firstOrNull()
    }

    // Modal / Dialog States
    var showProfileModal by remember { mutableStateOf(false) }
    var showCompleteSignUpDialog by remember { mutableStateOf(false) }
    var showGroupJoiningCodeDialog by remember { mutableStateOf(false) }
    var showReadOnlyGroupSettingsDialog by remember { mutableStateOf(false) }
    var showManagedGroupsDialog by remember { mutableStateOf(false) }
    var showJoinedGroupsDialog by remember { mutableStateOf(false) }
    var showCreateGroupDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var showSignOutConfirm by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("more_screen"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // =================================================================
        // 1. COMPACT, BEAUTIFUL USER PROFILE CARD
        // =================================================================
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("user_profile_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                ) {
                    // Top Row: Avatar, Identity Info, Status Badge & View Profile
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                modifier = Modifier.size(38.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    val initial = (currentUser?.fullName ?: currentMember?.name ?: "U").take(1).uppercase()
                                    Text(
                                        text = initial,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = currentUser?.fullName ?: currentMember?.name ?: "User",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.5.sp,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )

                                    // Account Status Pill
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (isSignedUpUser) Emerald500.copy(alpha = 0.12f) else Amber500.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = if (isSignedUpUser) "Full Account" else "Join Code",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSignedUpUser) Emerald500 else Amber500,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(1.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    // Current Group Role Tag
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (isGroupAdmin) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.12f)
                                    ) {
                                        Text(
                                            text = if (isGroupAdmin) "Group Admin" else "Member",
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (isGroupAdmin) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }

                                    val contact = currentUser?.phone?.ifBlank { currentUser?.email ?: "" } ?: ""
                                    if (contact.isNotBlank()) {
                                        Text(
                                            text = contact,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }

                        // View Profile Action Button
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                            modifier = Modifier
                                .clickable { showProfileModal = true }
                                .testTag("view_profile_btn")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Profile",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = null,
                                    modifier = Modifier.size(12.dp),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f), thickness = 0.75.dp)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Statistics Row: Groups I Manage vs Groups I Joined (CLICKABLE TO VIEW LISTS)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Stat Box 1: Groups I Manage (Indigo / Brand Theme)
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { showManagedGroupsDialog = true }
                                .testTag("stat_groups_i_manage")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = "Groups I Manage",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.height(1.dp))
                                    Row(verticalAlignment = Alignment.Bottom) {
                                        Text(
                                            text = "${managedGroups.size}",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (managedGroups.size == 1) "group" else "groups",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Icon(
                                    imageVector = Icons.Default.AdminPanelSettings,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        // Stat Box 2: Groups I Joined (Emerald Theme - DISTINCT COLOR)
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Emerald500.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, Emerald500.copy(alpha = 0.25f)),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { showJoinedGroupsDialog = true }
                                .testTag("stat_groups_i_joined")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = "Groups I Joined",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Emerald500
                                    )
                                    Spacer(modifier = Modifier.height(1.dp))
                                    Row(verticalAlignment = Alignment.Bottom) {
                                        Text(
                                            text = "${joinedGroups.size}",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Emerald500
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (joinedGroups.size == 1) "group" else "groups",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Icon(
                                    imageVector = Icons.Default.Group,
                                    contentDescription = null,
                                    tint = Emerald500,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    // Managed Groups List Container in Profile Card (Shows all created groups 1, 2, 3...)
                    if (managedGroups.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.04f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)),
                            modifier = Modifier.fillMaxWidth().testTag("profile_managed_groups_list_card")
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "My Managed Groups (${managedGroups.size})",
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "Tap to switch active group",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                managedGroups.forEachIndexed { index, group ->
                                    val isActive = group.id == settings.id
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface,
                                        border = BorderStroke(
                                            1.dp,
                                            if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                if (!isActive) {
                                                    viewModel.switchGroup(group.id)
                                                    Toast.makeText(context, "Switched to ${group.groupName}", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                            .testTag("profile_managed_group_item_$index")
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 8.dp, vertical = 7.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            // Number 1, 2, 3 badge
                                            Surface(
                                                shape = CircleShape,
                                                color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Text(
                                                        text = "${index + 1}",
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 11.sp,
                                                        color = if (isActive) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }

                                            Spacer(modifier = Modifier.width(8.dp))

                                            Column(modifier = Modifier.weight(1f)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(
                                                        text = group.groupName,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 12.5.sp,
                                                        color = MaterialTheme.colorScheme.onSurface,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis,
                                                        modifier = Modifier.weight(1f, fill = false)
                                                    )
                                                    if (isActive) {
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Surface(
                                                            shape = RoundedCornerShape(4.dp),
                                                            color = Emerald500.copy(alpha = 0.15f)
                                                        ) {
                                                            Text(
                                                                text = "Active",
                                                                fontSize = 9.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = Emerald500,
                                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                            )
                                                        }
                                                    }
                                                }
                                                Text(
                                                    text = "ID #${group.id} • Code: ${group.inviteCode} • ${group.groupType.ifBlank { "Society" }}",
                                                    fontSize = 10.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }

                                            Icon(
                                                imageVector = if (isActive) Icons.Default.CheckCircle else Icons.AutoMirrored.Filled.ArrowForward,
                                                contentDescription = null,
                                                tint = if (isActive) Emerald500 else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Selected Active Group Box (Clickable to switch or view groups)
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (managedGroups.isNotEmpty()) {
                                    showManagedGroupsDialog = true
                                } else if (joinedGroups.isNotEmpty()) {
                                    showJoinedGroupsDialog = true
                                } else {
                                    showCreateGroupDialog = true
                                }
                            }
                            .testTag("selected_active_group_box")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Groups,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Selected Active Group",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = settings.groupName,
                                        fontSize = 13.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "ID #${settings.id} • ${settings.groupType.ifBlank { "Society" }} • Code: ${settings.inviteCode}",
                                        fontSize = 10.5.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // For join-by-code users, offer a helpful banner to complete sign up
                    if (!isSignedUpUser) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Amber500.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, Amber500.copy(alpha = 0.25f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showCompleteSignUpDialog = true }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        Icons.Default.AppRegistration,
                                        contentDescription = null,
                                        tint = Amber500,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Complete Sign Up to create your own groups",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                Text(
                                    text = "Upgrade",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Amber500
                                )
                            }
                        }
                    }
                }
            }
        }

        // =================================================================
        // 2. MY GROUPS SECTION (Cleaned up as instructed)
        // =================================================================
        item {
            SectionHeader(title = "MY GROUPS")
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    // Create New Group
                    if (isSignedUpUser) {
                        MoreOptionRow(
                            icon = Icons.Default.Add,
                            iconTint = Emerald500,
                            title = "Create New Group",
                            subtitle = "Start a new savings, welfare, or investment society",
                            onClick = { showCreateGroupDialog = true }
                        )
                    } else {
                        // Protected for Join-Code user with clear explanation
                        MoreOptionRow(
                            icon = Icons.Default.Lock,
                            iconTint = MaterialTheme.colorScheme.onSurfaceVariant,
                            title = "Create New Group",
                            subtitle = "Sign Up required: Complete registration to create groups",
                            isLockProtected = true,
                            onClick = { showCompleteSignUpDialog = true }
                        )
                    }
                }
            }
        }

        // =================================================================
        // 3. MEMBER & GROUP MANAGEMENT SECTION (Visible to Group Admin only)
        // =================================================================
        if (isGroupAdmin) {
            item {
                SectionHeader(title = "MEMBER & GROUP MANAGEMENT")
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column {
                        MoreOptionRow(
                            icon = Icons.Default.Groups,
                            iconTint = MaterialTheme.colorScheme.primary,
                            title = "Manage Society Members",
                            subtitle = "View ${members.size} active members, update details and profiles",
                            onClick = onNavigateToMembers
                        )
                        MoreDivider()

                        MoreOptionRow(
                            icon = Icons.Default.GroupAdd,
                            iconTint = Emerald500,
                            title = "Add New Member",
                            subtitle = "Register a new member in ${settings.groupName}",
                            onClick = onNavigateToAddMember
                        )
                        MoreDivider()

                        MoreOptionRow(
                            icon = Icons.Default.Key,
                            iconTint = Amber500,
                            title = "Group Joining Code: ${settings.inviteCode}",
                            subtitle = "Share joining code with members or generate a new code",
                            onClick = { showGroupJoiningCodeDialog = true }
                        )
                    }
                }
            }
        }

        // =================================================================
        // 4. SETTINGS SECTION
        // =================================================================
        item {
            SectionHeader(title = "SETTINGS")
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    // Group Settings: Editable for Admin, Read-Only dialog for regular Member
                    if (isGroupAdmin) {
                        MoreOptionRow(
                            icon = Icons.Default.Settings,
                            iconTint = MaterialTheme.colorScheme.primary,
                            title = "Group Settings",
                            subtitle = "Society name, dues, fine rules, modules & contact info",
                            onClick = {
                                viewModel.requestAdminAction {
                                    onNavigateToSettings()
                                }
                            }
                        )
                    } else {
                        MoreOptionRow(
                            icon = Icons.Default.Visibility,
                            iconTint = MaterialTheme.colorScheme.primary,
                            title = "Group Details & Rules (Read-Only)",
                            subtitle = "View dues, due date, late fees & society policy",
                            onClick = { showReadOnlyGroupSettingsDialog = true }
                        )
                    }
                    MoreDivider()

                    // Theme & Appearance
                    MoreOptionRow(
                        icon = Icons.Default.Palette,
                        iconTint = Color(0xFF8B5CF6),
                        title = "App Theme & Appearance",
                        subtitle = "Current: ${settings.themeMode.replaceFirstChar { it.uppercase() }} mode",
                        onClick = { showThemeDialog = true }
                    )
                }
            }
        }

        // =================================================================
        // 5. FINANCE & LEDGER SECTION
        // =================================================================
        item {
            SectionHeader(title = "FINANCE & LEDGER")
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    MoreOptionRow(
                        icon = Icons.AutoMirrored.Filled.MenuBook,
                        iconTint = MaterialTheme.colorScheme.primary,
                        title = "Transaction Ledger",
                        subtitle = "Complete chronological credit & debit audit trail",
                        onClick = onNavigateToLedger
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.Default.CalendarMonth,
                        iconTint = Emerald500,
                        title = "Monthly Collection Matrix",
                        subtitle = "Month-by-month member payment breakdown and status",
                        onClick = onNavigateToMonthly
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.Default.Payments,
                        iconTint = Rose500,
                        title = "Pending Dues & Reminders",
                        subtitle = "Track unpaid balances and trigger WhatsApp alerts",
                        onClick = onNavigateToDues
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.Default.Handshake,
                        iconTint = Amber500,
                        title = "Loans & 70% Voting",
                        subtitle = "Apply, view active loans and cast member approval votes",
                        badgeCount = if (pendingLoansCount > 0) pendingLoansCount else null,
                        onClick = onNavigateToLoans
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.Default.TrendingUp,
                        iconTint = Color(0xFF3B82F6),
                        title = "Investment Portfolio",
                        subtitle = "Track fixed deposits, land, community assets and returns",
                        onClick = onNavigateToInvestments
                    )
                }
            }
        }

        // =================================================================
        // 6. COMMUNITY & GOVERNANCE SECTION
        // =================================================================
        item {
            SectionHeader(title = "COMMUNITY & GOVERNANCE")
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    MoreOptionRow(
                        icon = Icons.Default.Feedback,
                        iconTint = Color(0xFF8B5CF6),
                        title = "Proposals, Suggestions & Complaints",
                        subtitle = "Submit society proposals and upvote community ideas",
                        onClick = onNavigateToFeedback
                    )
                }
            }
        }

        // =================================================================
        // 7. DATA & SYSTEM SECTION
        // =================================================================
        item {
            SectionHeader(title = "DATA & SYSTEM")
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    MoreOptionRow(
                        icon = Icons.Default.Backup,
                        iconTint = Emerald500,
                        title = "Backup & Restore Database",
                        subtitle = "Export or restore complete JSON database backup",
                        isLockProtected = !isGroupAdmin,
                        onClick = {
                            viewModel.requestAdminAction {
                                onNavigateToBackup()
                            }
                        }
                    )
                }
            }
        }

        // =================================================================
        // 8. ACCOUNT SECTION (Cleaned up as instructed)
        // =================================================================
        item {
            SectionHeader(title = "ACCOUNT")
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    // Distinct Red / Destructive Sign Out Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showSignOutConfirm = true }
                            .padding(horizontal = 16.dp, vertical = 13.dp)
                            .testTag("sign_out_btn"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Rose500.copy(alpha = 0.12f),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Logout,
                                    contentDescription = "Sign Out",
                                    tint = Rose500,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Sign Out",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Rose500
                            )
                            Spacer(modifier = Modifier.height(1.dp))
                            Text(
                                text = "Exit current session and return to welcome login screen",
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = Rose500.copy(alpha = 0.6f),
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }
        }

        // App Info Footer
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "${settings.groupName} • v1.2.0",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Encrypted Local Database & Cloud Firestore Sync",
                    fontSize = 10.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }
    }

    // =================================================================
    // DIALOGS AND MODALS
    // =================================================================

    // 1. GROUPS I MANAGE DIALOG (Indigo / Brand theme)
    if (showManagedGroupsDialog) {
        AlertDialog(
            onDismissRequest = { showManagedGroupsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Groups I Manage", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                        Text("${managedGroups.size} managed societies", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(320.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (managedGroups.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.AdminPanelSettings,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "No groups managed yet",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (isSignedUpUser) "Create a group to start managing" else "Complete sign up to create groups",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            itemsIndexed(managedGroups) { index, group ->
                                val isActive = group.id == settings.id
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewModel.switchGroup(group.id)
                                            showManagedGroupsDialog = false
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // Numbering 1, 2, 3...
                                        Surface(
                                            shape = CircleShape,
                                            color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                            modifier = Modifier.size(26.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = "${index + 1}",
                                                    fontSize = 11.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isActive) Color.White else MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(10.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = group.groupName,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.5.sp,
                                                    color = MaterialTheme.colorScheme.onSurface,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                if (isActive) {
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = MaterialTheme.colorScheme.primary
                                                    ) {
                                                        Text(
                                                            text = "Active",
                                                            fontSize = 9.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color.White,
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                        )
                                                    }
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "Code: ${group.inviteCode} • Admin: ${group.adminName}",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                            contentDescription = "Switch",
                                            tint = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                if (isSignedUpUser) {
                    Button(
                        onClick = {
                            showManagedGroupsDialog = false
                            showCreateGroupDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Create New Group", fontSize = 12.sp)
                    }
                } else {
                    Button(
                        onClick = {
                            showManagedGroupsDialog = false
                            showCompleteSignUpDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Amber500)
                    ) {
                        Text("Upgrade Account", fontSize = 12.sp)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showManagedGroupsDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // 2. GROUPS I JOINED DIALOG (Emerald Theme - DISTINCT COLOR)
    if (showJoinedGroupsDialog) {
        AlertDialog(
            onDismissRequest = { showJoinedGroupsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = Emerald500.copy(alpha = 0.15f),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Group,
                                contentDescription = null,
                                tint = Emerald500,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Groups I Joined", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                        Text("${joinedGroups.size} joined societies (Member)", fontSize = 11.sp, color = Emerald500)
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(320.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (joinedGroups.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.Groups,
                                    contentDescription = null,
                                    tint = Emerald500.copy(alpha = 0.4f),
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "No other joined groups",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "You can join societies using the invitation code shared by the society administrator.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            itemsIndexed(joinedGroups) { index, group ->
                                val isActive = group.id == settings.id
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isActive) Emerald500.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isActive) Emerald500 else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewModel.switchGroup(group.id)
                                            showJoinedGroupsDialog = false
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // Numbering 1, 2, 3...
                                        Surface(
                                            shape = CircleShape,
                                            color = if (isActive) Emerald500 else Emerald500.copy(alpha = 0.15f),
                                            modifier = Modifier.size(26.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = "${index + 1}",
                                                    fontSize = 11.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isActive) Color.White else Emerald500
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(10.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = group.groupName,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.5.sp,
                                                    color = MaterialTheme.colorScheme.onSurface,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                if (isActive) {
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = Emerald500
                                                    ) {
                                                        Text(
                                                            text = "Active",
                                                            fontSize = 9.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color.White,
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                        )
                                                    }
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "Admin: ${group.adminName} • Dues: ${group.currencySymbol}${group.defaultContribution.toInt()}",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                            contentDescription = "Switch",
                                            tint = if (isActive) Emerald500 else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showJoinedGroupsDialog = false }) {
                    Text("Close", color = Emerald500)
                }
            }
        )
    }

    // 3. Profile Details & Edit Modal
    if (showProfileModal) {
        var editName by remember { mutableStateOf(currentUser?.fullName ?: currentMember?.name ?: "") }
        var editEmail by remember { mutableStateOf(currentUser?.email ?: "") }
        var editPhone by remember { mutableStateOf(currentUser?.phone ?: currentMember?.phone ?: "") }
        var isSaving by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showProfileModal = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AccountCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("User Profile Details", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Account Type Badge
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSignedUpUser) Emerald500.copy(alpha = 0.1f) else Amber500.copy(alpha = 0.1f),
                        border = BorderStroke(1.dp, if (isSignedUpUser) Emerald500.copy(alpha = 0.3f) else Amber500.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isSignedUpUser) Icons.Default.VerifiedUser else Icons.Default.Key,
                                contentDescription = null,
                                tint = if (isSignedUpUser) Emerald500 else Amber500,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = if (isSignedUpUser) "Registered Full Account" else "Guest Join-Code Account",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.5.sp,
                                    color = if (isSignedUpUser) Emerald500 else Amber500
                                )
                                Text(
                                    text = if (isSignedUpUser) "Can create, manage, and join societies" else "Joined via code. Upgrade to create societies.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    if (isSignedUpUser) {
                        OutlinedTextField(
                            value = editName,
                            onValueChange = { editName = it },
                            label = { Text("Full Name") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                            colors = appOutlinedTextFieldColors(),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = editEmail,
                            onValueChange = { editEmail = it },
                            label = { Text("Email Address") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                            colors = appOutlinedTextFieldColors(),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = editPhone,
                            onValueChange = { editPhone = it },
                            label = { Text("Phone Number") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            colors = appOutlinedTextFieldColors(),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        // Summary info for join-code user
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(text = "Name: ${currentUser?.fullName ?: "Member"}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                            Text(text = "Phone: ${currentUser?.phone?.ifBlank { "Not provided" } ?: "Not provided"}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = "Active Group: ${settings.groupName}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        Button(
                            onClick = {
                                showProfileModal = false
                                showCompleteSignUpDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.AppRegistration, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Upgrade / Complete Sign Up", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            },
            confirmButton = {
                if (isSignedUpUser) {
                    Button(
                        onClick = {
                            isSaving = true
                            viewModel.updateUserProfile(
                                fullName = editName,
                                email = editEmail,
                                phone = editPhone,
                                onSuccess = {
                                    isSaving = false
                                    showProfileModal = false
                                },
                                onError = {
                                    isSaving = false
                                }
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        enabled = !isSaving && editName.isNotBlank()
                    ) {
                        Text("Save Changes")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showProfileModal = false }) {
                    Text("Close")
                }
            }
        )
    }

    // 4. Complete Sign Up Dialog (For upgrading Join-Code users to Full Accounts)
    if (showCompleteSignUpDialog) {
        var suName by remember { mutableStateOf(currentUser?.fullName ?: "") }
        var suEmail by remember { mutableStateOf(if (currentUser?.email?.contains("@groupledger.org") == true) "" else (currentUser?.email ?: "")) }
        var suPassword by remember { mutableStateOf("") }
        var suPhone by remember { mutableStateOf(currentUser?.phone ?: "") }
        var suError by remember { mutableStateOf<String?>(null) }
        var suLoading by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { if (!suLoading) showCompleteSignUpDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AppRegistration, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Complete Your Registration", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Create a password and complete your profile so you can create and administer your own groups.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    suError?.let { err ->
                        Text(text = err, color = Rose500, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }

                    OutlinedTextField(
                        value = suName,
                        onValueChange = { suName = it },
                        label = { Text("Full Name *") },
                        colors = appOutlinedTextFieldColors(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = suEmail,
                        onValueChange = { suEmail = it },
                        label = { Text("Email Address *") },
                        colors = appOutlinedTextFieldColors(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = suPhone,
                        onValueChange = { suPhone = it },
                        label = { Text("Phone Number") },
                        colors = appOutlinedTextFieldColors(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = suPassword,
                        onValueChange = { suPassword = it },
                        label = { Text("Create Password (min 6 chars) *") },
                        visualTransformation = PasswordVisualTransformation(),
                        colors = appOutlinedTextFieldColors(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (suName.isBlank() || suEmail.isBlank() || suPassword.length < 6) {
                            suError = "Please fill in all required fields (password minimum 6 chars)"
                            return@Button
                        }
                        suLoading = true
                        suError = null
                        viewModel.completeGuestSignUp(
                            fullName = suName,
                            email = suEmail,
                            password = suPassword,
                            phone = suPhone,
                            onSuccess = {
                                suLoading = false
                                showCompleteSignUpDialog = false
                            },
                            onError = { err: String ->
                                suLoading = false
                                suError = err
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    enabled = !suLoading
                ) {
                    Text(if (suLoading) "Upgrading..." else "Complete Registration")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showCompleteSignUpDialog = false },
                    enabled = !suLoading
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // 5. Group Joining Code Modal (For Admins to share & regenerate)
    if (showGroupJoiningCodeDialog) {
        val inviteCode = settings.inviteCode
        var copied by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showGroupJoiningCodeDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Key, contentDescription = null, tint = Amber500, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Group Joining Code", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Share this 6-character code with new members so they can join '${settings.groupName}'.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )

                    // Big Display Box for Code
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = inviteCode,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 6.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    // Action Buttons: Copy & Share
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(inviteCode))
                                copied = true
                                Toast.makeText(context, "Code copied: $inviteCode", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(if (copied) Icons.Default.Check else Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (copied) "Copied!" else "Copy Code", fontSize = 12.5.sp)
                        }

                        Button(
                            onClick = {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(
                                        Intent.EXTRA_TEXT,
                                        "Join our society '${settings.groupName}' on Group Ledger!\n\nYour Joining Code: $inviteCode\n\nEnter this code in the app to join our group."
                                    )
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share Joining Code"))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Emerald500),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share Code", fontSize = 12.5.sp)
                        }
                    }

                    // Regenerate Code Option
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable {
                                viewModel.regenerateGroupInviteCode()
                            }
                            .padding(vertical = 6.dp, horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Regenerate New Code", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showGroupJoiningCodeDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // 6. Read-Only Group Settings Modal (For regular members)
    if (showReadOnlyGroupSettingsDialog) {
        AlertDialog(
            onDismissRequest = { showReadOnlyGroupSettingsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Visibility, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Group Details & Rules", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            },
            text = {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Read-Only: These parameters are managed by your society administrator.",
                                    fontSize = 11.5.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }

                    item { ReadOnlyDetailRow("Society Name", settings.groupName) }
                    item { ReadOnlyDetailRow("Subtitle", settings.groupSubtitle.ifBlank { "Monthly Savings & Contribution Society" }) }
                    item { ReadOnlyDetailRow("Group Type", settings.groupType) }
                    item { ReadOnlyDetailRow("Monthly Dues", "${settings.currencySymbol}${settings.defaultContribution.toInt()} / member") }
                    item { ReadOnlyDetailRow("Frequency", settings.contributionFrequency) }
                    item { ReadOnlyDetailRow("Payment Due Day", "Day ${settings.dueDayOfMonth} of every month") }
                    item {
                        ReadOnlyDetailRow(
                            "Late Fine Policy",
                            if (settings.isLateFeeEnabled) "${settings.currencySymbol}${settings.lateFineAmount.toInt()} after ${settings.gracePeriodDays} days grace period" else "No late fine enabled"
                        )
                    }
                    item { ReadOnlyDetailRow("Society Admin", "${settings.adminName} • ${settings.adminPhone}") }
                    item { ReadOnlyDetailRow("Society Rules", settings.paymentRules) }
                }
            },
            confirmButton = {
                TextButton(onClick = { showReadOnlyGroupSettingsDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // 6. Groups I Manage Dialog (Numbered List 1, 2, 3...)
    if (showManagedGroupsDialog) {
        AlertDialog(
            onDismissRequest = { showManagedGroupsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Groups I Manage (${managedGroups.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Created by you or admin access",
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 420.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (managedGroups.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "No managed groups found. Create a new group to get started.",
                                fontSize = 12.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        managedGroups.forEachIndexed { index, group ->
                            val isActive = group.id == settings.id
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (!isActive) {
                                            viewModel.switchGroup(group.id)
                                            Toast.makeText(context, "Switched to ${group.groupName}", Toast.LENGTH_SHORT).show()
                                        }
                                        showManagedGroupsDialog = false
                                    },
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                ),
                                border = BorderStroke(
                                    1.dp,
                                    if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Number Badge: 1, 2, 3...
                                    Surface(
                                        shape = CircleShape,
                                        color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "${index + 1}",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = if (isActive) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(10.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = group.groupName,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.5.sp,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f, fill = false)
                                            )
                                            if (isActive) {
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = Emerald500.copy(alpha = 0.15f)
                                                ) {
                                                    Text(
                                                        text = "Active",
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Emerald500,
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                    )
                                                }
                                            }
                                        }
                                        Text(
                                            text = group.groupSubtitle.ifBlank { "Code: ${group.inviteCode} • Dues: ${group.currencySymbol}${group.defaultContribution.toInt()}" },
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Button(
                        onClick = {
                            showManagedGroupsDialog = false
                            showCreateGroupDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Create Another Group", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showManagedGroupsDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // 7. Groups I Joined Dialog (Numbered List 1, 2, 3...)
    if (showJoinedGroupsDialog) {
        AlertDialog(
            onDismissRequest = { showJoinedGroupsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = Emerald500.copy(alpha = 0.12f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.Groups,
                                contentDescription = null,
                                tint = Emerald500,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Groups I Joined (${joinedGroups.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Societies where you are a member",
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 420.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (joinedGroups.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "No joined groups found. You can join a group using an invitation code.",
                                fontSize = 12.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        joinedGroups.forEachIndexed { index, group ->
                            val isActive = group.id == settings.id
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (!isActive) {
                                            viewModel.switchGroup(group.id)
                                            Toast.makeText(context, "Switched to ${group.groupName}", Toast.LENGTH_SHORT).show()
                                        }
                                        showJoinedGroupsDialog = false
                                    },
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isActive) Emerald500.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                ),
                                border = BorderStroke(
                                    1.dp,
                                    if (isActive) Emerald500 else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Number Badge: 1, 2, 3...
                                    Surface(
                                        shape = CircleShape,
                                        color = if (isActive) Emerald500 else MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "${index + 1}",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = if (isActive) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(10.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = group.groupName,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.5.sp,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f, fill = false)
                                            )
                                            if (isActive) {
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = Emerald500.copy(alpha = 0.15f)
                                                ) {
                                                    Text(
                                                        text = "Active",
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Emerald500,
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                    )
                                                }
                                            }
                                        }
                                        Text(
                                            text = group.groupSubtitle.ifBlank { "Admin: ${group.adminName} • Dues: ${group.currencySymbol}${group.defaultContribution.toInt()}" },
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = if (isActive) Emerald500 else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showJoinedGroupsDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // 8. Create Group Dialog (With All Default Option Settings in a clean list)
    if (showCreateGroupDialog) {
        var gName by remember { mutableStateOf("") }
        var gSubtitle by remember { mutableStateOf("") }
        var gType by remember { mutableStateOf("Self-Help Group") }
        var gDues by remember { mutableStateOf("500") }
        var gCurrency by remember { mutableStateOf("₹") }
        var gFrequency by remember { mutableStateOf("MONTHLY") }
        var gDueDay by remember { mutableStateOf("10") }
        var gLateFee by remember { mutableStateOf(false) }
        var gLateFineAmount by remember { mutableStateOf("50") }
        var gGracePeriod by remember { mutableStateOf("5") }
        var gRules by remember { mutableStateOf("Monthly contribution is due by the 10th of every month. Unpaid dues carry over to next cycle.") }
        var gAdminPin by remember { mutableStateOf("1234") }
        var gPinLock by remember { mutableStateOf(false) }
        var isCreating by remember { mutableStateOf(false) }
        var validationError by remember { mutableStateOf<String?>(null) }

        val groupTypes = listOf(
            "Self-Help Group",
            "Welfare Society",
            "Apartment / Housing Society",
            "Festival / Puja Samiti",
            "Savings & Credit Circle",
            "Sports & Cultural Club",
            "Other Community Group"
        )

        AlertDialog(
            onDismissRequest = { if (!isCreating) showCreateGroupDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.Add,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            "Create New Society / Group",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            "Set up all initial default options",
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 440.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    validationError?.let { err ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Rose500.copy(alpha = 0.1f),
                            border = BorderStroke(1.dp, Rose500.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = err,
                                color = Rose500,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    // Section 1: Basic Information
                    SectionHeader("1. BASIC INFORMATION")

                    OutlinedTextField(
                        value = gName,
                        onValueChange = {
                            gName = it
                            validationError = null
                        },
                        label = { Text("Group Name *") },
                        placeholder = { Text("e.g. Metro Welfare Samiti") },
                        colors = appOutlinedTextFieldColors(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = gSubtitle,
                        onValueChange = { gSubtitle = it },
                        label = { Text("Purpose / Subtitle") },
                        placeholder = { Text("e.g. Monthly Savings & Emergency Fund") },
                        colors = appOutlinedTextFieldColors(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Group Type Selector
                    Column {
                        Text("Group Type", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("Self-Help Group", "Welfare Society", "Savings Circle").forEach { type ->
                                val isSelected = gType == type
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    border = BorderStroke(1.dp, if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { gType = type }
                                ) {
                                    Box(
                                        modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = type,
                                            fontSize = 10.5.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Section 2: Financial Parameters
                    SectionHeader("2. FINANCIAL SETTINGS & DUES")

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = gDues,
                            onValueChange = { gDues = it },
                            label = { Text("Default Dues *") },
                            colors = appOutlinedTextFieldColors(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = gCurrency,
                            onValueChange = { gCurrency = it },
                            label = { Text("Currency") },
                            colors = appOutlinedTextFieldColors(),
                            singleLine = true,
                            modifier = Modifier.width(80.dp)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = gDueDay,
                            onValueChange = { gDueDay = it },
                            label = { Text("Payment Due Day") },
                            placeholder = { Text("1-28") },
                            colors = appOutlinedTextFieldColors(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = gFrequency,
                            onValueChange = { gFrequency = it },
                            label = { Text("Frequency") },
                            colors = appOutlinedTextFieldColors(),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Section 3: Late Fine Policy
                    SectionHeader("3. LATE FINE & PENALTY POLICY")

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Enable Late Fine", fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurface)
                                    Text("Apply automatic fine on overdue dues", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(
                                    checked = gLateFee,
                                    onCheckedChange = { gLateFee = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.primary)
                                )
                            }

                            if (gLateFee) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = gLateFineAmount,
                                        onValueChange = { gLateFineAmount = it },
                                        label = { Text("Fine Amount") },
                                        colors = appOutlinedTextFieldColors(),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        modifier = Modifier.weight(1f)
                                    )

                                    OutlinedTextField(
                                        value = gGracePeriod,
                                        onValueChange = { gGracePeriod = it },
                                        label = { Text("Grace Days") },
                                        colors = appOutlinedTextFieldColors(),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }

                    // Section 4: Admin PIN & Security
                    SectionHeader("4. ADMIN SECURITY & PIN")

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = gAdminPin,
                            onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) gAdminPin = it },
                            label = { Text("Admin PIN (4-digits)") },
                            colors = appOutlinedTextFieldColors(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Require PIN For Admin Actions", fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurface)
                                Text("Protects settings, backup, and member deletion", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(
                                checked = gPinLock,
                                onCheckedChange = { gPinLock = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.primary)
                            )
                        }
                    }

                    // Section 5: Group Rules Note
                    SectionHeader("5. GROUP RULES & TERMS")

                    OutlinedTextField(
                        value = gRules,
                        onValueChange = { gRules = it },
                        label = { Text("Rules & Guidelines") },
                        colors = appOutlinedTextFieldColors(),
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (gName.isBlank()) {
                            validationError = "Please enter a Group Name"
                            return@Button
                        }
                        isCreating = true
                        validationError = null
                        val amount = gDues.toDoubleOrNull() ?: 500.0
                        val fineAmt = gLateFineAmount.toDoubleOrNull() ?: 50.0
                        val graceDays = gGracePeriod.toIntOrNull() ?: 5
                        val dueDay = gDueDay.toIntOrNull() ?: 10

                        viewModel.createNewGroup(
                            groupName = gName.trim(),
                            groupSubtitle = gSubtitle.trim(),
                            groupType = gType,
                            defaultContribution = amount,
                            currencySymbol = gCurrency.trim().ifBlank { "₹" },
                            contributionFrequency = gFrequency.trim().ifBlank { "MONTHLY" },
                            dueDayOfMonth = dueDay,
                            isLateFeeEnabled = gLateFee,
                            lateFineAmount = fineAmt,
                            gracePeriodDays = graceDays,
                            adminPin = gAdminPin.trim().ifBlank { "1234" },
                            isPinLockEnabled = gPinLock,
                            paymentRules = gRules.trim(),
                            onSuccess = {
                                isCreating = false
                                showCreateGroupDialog = false
                                Toast.makeText(context, "Group '${gName.trim()}' created successfully!", Toast.LENGTH_SHORT).show()
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    enabled = !isCreating && gName.isNotBlank()
                ) {
                    Text(if (isCreating) "Creating..." else "Create Group")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showCreateGroupDialog = false },
                    enabled = !isCreating
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // 8. Theme Selection Dialog
    if (showThemeDialog) {
        val currentTheme = settings.themeMode

        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Palette, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("App Theme Mode", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    listOf(
                        Triple("SYSTEM", "System Default", Icons.Default.BrightnessAuto),
                        Triple("LIGHT", "Light Theme", Icons.Default.LightMode),
                        Triple("DARK", "Dark Theme", Icons.Default.DarkMode)
                    ).forEach { (mode, label, icon) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    viewModel.setThemeMode(mode)
                                    showThemeDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = currentTheme.equals(mode, ignoreCase = true),
                                onClick = {
                                    viewModel.setThemeMode(mode)
                                    showThemeDialog = false
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.primary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(label, fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showThemeDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // 9. Sign Out Confirmation Dialog
    if (showSignOutConfirm) {
        AlertDialog(
            onDismissRequest = { showSignOutConfirm = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = Rose500, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Confirm Sign Out", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            },
            text = {
                Text(
                    text = "Are you sure you want to sign out of '${settings.groupName}'? You can sign back in anytime using your registered email or invitation code.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSignOutConfirm = false
                        viewModel.logout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Rose500)
                ) {
                    Text("Sign Out", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSignOutConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

// =================================================================
// REUSABLE UI HELPER COMPONENTS
// =================================================================

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        letterSpacing = 0.8.sp,
        modifier = Modifier.padding(start = 4.dp, top = 2.dp)
    )
}

@Composable
fun MoreOptionRow(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    badgeCount: Int? = null,
    isLockProtected: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = iconTint.copy(alpha = 0.12f),
            modifier = Modifier.size(38.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.5.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (isLockProtected) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        Icons.Default.Lock,
                        contentDescription = "Protected",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(1.dp))
            Text(
                text = subtitle,
                fontSize = 11.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 15.sp
            )
        }

        if (badgeCount != null && badgeCount > 0) {
            Surface(
                shape = CircleShape,
                color = Rose500,
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Text(
                    text = "$badgeCount",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
        }

        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier.size(15.dp)
        )
    }
}

@Composable
fun MoreDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(horizontal = 16.dp),
        thickness = 0.75.dp,
        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
    )
}

@Composable
private fun ReadOnlyDetailRow(label: String, value: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
