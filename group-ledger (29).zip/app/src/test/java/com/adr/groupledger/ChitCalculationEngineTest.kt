package com.adr.groupledger

import com.adr.groupledger.data.model.ChitCycle
import com.adr.groupledger.data.model.ChitCycleStatus
import com.adr.groupledger.utils.ChitCalculationEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class ChitCalculationEngineTest {

    @Test
    fun testGenerateMonthlyScheduleSafeMonthEnd() {
        // Start date: January 31st
        val cal = Calendar.getInstance().apply {
            set(2026, Calendar.JANUARY, 31, 20, 0, 0)
        }
        val startMillis = cal.timeInMillis

        val cycles = ChitCalculationEngine.generateOrUpdateCycleSchedule(
            existingCycles = emptyList(),
            totalCycles = 3,
            installmentAmount = 5000.0,
            startDateMillis = startMillis,
            frequency = "MONTHLY",
            auctionScheduleDay = 31,
            auctionStartTime = "08:00 PM",
            auctionEndTime = "08:15 PM",
            auctionDurationMinutes = 15
        )

        assertEquals(3, cycles.size)
        assertEquals(1, cycles[0].cycleNumber)
        assertEquals(2, cycles[1].cycleNumber)
        assertEquals(3, cycles[2].cycleNumber)

        // Verify cycle 2 is February and doesn't spill into March
        val febCal = Calendar.getInstance().apply { timeInMillis = cycles[1].scheduledDateMillis }
        assertEquals(Calendar.FEBRUARY, febCal.get(Calendar.MONTH))
        assertEquals(28, febCal.get(Calendar.DAY_OF_MONTH))

        // Verify cycle 3 is March 31
        val marCal = Calendar.getInstance().apply { timeInMillis = cycles[2].scheduledDateMillis }
        assertEquals(Calendar.MARCH, marCal.get(Calendar.MONTH))
        assertEquals(31, marCal.get(Calendar.DAY_OF_MONTH))
    }

    @Test
    fun testCycleStatusTransitions() {
        // Valid transitions
        assertTrue(ChitCycleStatus.UPCOMING.canTransitionTo(ChitCycleStatus.AUCTION_SCHEDULED))
        assertTrue(ChitCycleStatus.AUCTION_SCHEDULED.canTransitionTo(ChitCycleStatus.AUCTION_OPEN))
        assertTrue(ChitCycleStatus.AUCTION_OPEN.canTransitionTo(ChitCycleStatus.AUCTION_CLOSED))
        assertTrue(ChitCycleStatus.AUCTION_CLOSED.canTransitionTo(ChitCycleStatus.RESULT_PENDING))
        assertTrue(ChitCycleStatus.RESULT_PENDING.canTransitionTo(ChitCycleStatus.COMPLETED))

        // Rescheduling allowed for non-terminal states
        assertTrue(ChitCycleStatus.UPCOMING.canTransitionTo(ChitCycleStatus.RESCHEDULED))
        assertTrue(ChitCycleStatus.AUCTION_SCHEDULED.canTransitionTo(ChitCycleStatus.RESCHEDULED))

        // Completed cycles cannot transition to active/open/rescheduled
        assertFalse(ChitCycleStatus.COMPLETED.canTransitionTo(ChitCycleStatus.UPCOMING))
        assertFalse(ChitCycleStatus.COMPLETED.canTransitionTo(ChitCycleStatus.AUCTION_OPEN))
        assertFalse(ChitCycleStatus.COMPLETED.canTransitionTo(ChitCycleStatus.RESCHEDULED))
        assertTrue(ChitCycleStatus.COMPLETED.isTerminal())
    }

    @Test
    fun testDeriveOperationalStatus() {
        val cal = Calendar.getInstance().apply {
            set(2026, Calendar.OCTOBER, 5, 20, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startMillis = cal.timeInMillis // 08:00 PM
        val nowDuring = startMillis + 5 * 60 * 1000L // 08:05 PM (during 15 min window)
        val nowBefore = startMillis - 60 * 1000L // 07:59 PM (before auction)
        val nowAfter = startMillis + 20 * 60 * 1000L // 08:20 PM (after auction)

        val cycle = ChitCycle(
            cycleNumber = 1,
            scheduledDateMillis = startMillis,
            auctionDateMillis = startMillis,
            status = ChitCycleStatus.AUCTION_SCHEDULED,
            auctionStartTime = "08:00 PM",
            auctionEndTime = "08:15 PM",
            auctionDurationMinutes = 15
        )

        // During auction window -> AUCTION_OPEN
        val currentStatus = cycle.deriveOperationalStatus(nowDuring)
        assertEquals(ChitCycleStatus.AUCTION_OPEN, currentStatus)

        // Before auction window -> AUCTION_SCHEDULED
        val beforeStatus = cycle.deriveOperationalStatus(nowBefore)
        assertEquals(ChitCycleStatus.AUCTION_SCHEDULED, beforeStatus)

        // After auction window -> AUCTION_CLOSED
        val afterStatus = cycle.deriveOperationalStatus(nowAfter)
        assertEquals(ChitCycleStatus.AUCTION_CLOSED, afterStatus)
    }

    @Test
    fun testCycleMetricsCalculation() {
        val cycle1 = ChitCycle(cycleNumber = 1, status = ChitCycleStatus.COMPLETED)
        val cycle2 = ChitCycle(cycleNumber = 2, status = ChitCycleStatus.AUCTION_SCHEDULED)
        val cycle3 = ChitCycle(cycleNumber = 3, status = ChitCycleStatus.UPCOMING)

        val metrics = ChitCalculationEngine.deriveCycleMetrics(
            cycles = listOf(cycle1, cycle2, cycle3),
            configuredTotalCycles = 3
        )

        assertEquals(3, metrics.totalCycles)
        assertEquals(1, metrics.completedCycles)
        assertEquals(2, metrics.remainingCycles)
        assertEquals(2, metrics.currentCycleNumber)
        assertEquals(33, metrics.progressPercent)
        assertTrue(metrics.hasStartedOrCompletedCycles)
    }

    @Test
    fun testCountdownFormatting() {
        assertEquals("02:30", ChitCalculationEngine.formatCountdown(150))
        assertEquals("01h 15m 30s", ChitCalculationEngine.formatCountdown(4530))
        assertEquals("2d 03h 20m", ChitCalculationEngine.formatCountdown(184800))
    }
}
