package com.adr.groupledger.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.NotificationImportant
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import com.adr.groupledger.ui.components.SamitiPullToRefreshBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.HomeModuleConfig
import com.adr.groupledger.data.model.TransactionRecord
import com.adr.groupledger.data.model.UpdateCheckStatus
import com.adr.groupledger.ui.components.AppUpdateDialog
import com.adr.groupledger.ui.components.HomeNotificationCarousel
import com.adr.groupledger.ui.components.HomeNotificationItem
import com.adr.groupledger.ui.components.HomeScreenCarousel
import com.adr.groupledger.ui.components.MemberAvatarView
import com.adr.groupledger.ui.components.MonthPickerBar
import com.adr.groupledger.ui.components.NotificationType
import com.adr.groupledger.ui.components.StatMetricCard
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.BorderLight
import com.adr.groupledger.ui.theme.BorderSubtle
import com.adr.groupledger.ui.theme.CardWhite
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoHeroDark
import com.adr.groupledger.ui.theme.IndigoHeroGradientEnd
import com.adr.groupledger.ui.theme.IndigoHeroProgress
import com.adr.groupledger.ui.theme.IndigoHeroSubtext
import com.adr.groupledger.ui.theme.IndigoHeroSurface
import com.adr.groupledger.ui.theme.IndigoHeroTrack
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.StatusPaidText
import com.adr.groupledger.ui.theme.StatusPartialText
import com.adr.groupledger.ui.theme.StatusUnpaidText
import com.adr.groupledger.ui.theme.TextSlate400
import com.adr.groupledger.ui.theme.TextSlate500
import com.adr.groupledger.ui.theme.TextSlate800
import com.adr.groupledger.ui.home.HomeTemplateContext
import com.adr.groupledger.ui.home.HomeTemplateResolver
import com.adr.groupledger.ui.home.components.CategoryChangeDialog
import com.adr.groupledger.ui.home.template.HomeTemplateRegistry
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.utils.CurrencyFormatter
import com.adr.groupledger.utils.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: SocietyViewModel,
    onNavigateToMembers: () -> Unit,
    onNavigateToMonthly: () -> Unit,
    onNavigateToDues: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToRecordPayment: () -> Unit,
    onNavigateToAddMember: () -> Unit,
    onNavigateToMemberProfile: (Long) -> Unit,
    onNavigateToLoans: () -> Unit = {},
    onNavigateToInvestments: () -> Unit = {},
    onNavigateToFeedback: () -> Unit = {},
    onNavigateToLedger: () -> Unit = {},
    onNavigateToInbox: () -> Unit = {},
    onNavigateToAuctionDetails: ((Int?) -> Unit)? = null,
    listState: LazyListState = rememberLazyListState(),
    modifier: Modifier = Modifier
) {
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val financials by viewModel.overallFinancials.collectAsStateWithLifecycle()
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()
    val monthSummary by viewModel.currentMonthSummary.collectAsStateWithLifecycle()
    val recentTxns by viewModel.allTransactions.collectAsStateWithLifecycle()
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()
    val loansWithVoting by viewModel.allLoansWithVotes.collectAsStateWithLifecycle()
    val pendingApprovals by viewModel.pendingPaymentApprovals.collectAsStateWithLifecycle()
    val feedbacksWithVotes by viewModel.allFeedbacksWithVotes.collectAsStateWithLifecycle()
    val notices by viewModel.notices.collectAsStateWithLifecycle()
    val homeModules by viewModel.homeModules.collectAsStateWithLifecycle()
    val updateStatus by viewModel.updateStatus.collectAsStateWithLifecycle()
    val isUpdateBannerDismissed by viewModel.isUpdateBannerDismissed.collectAsStateWithLifecycle()
    val lastCheckedTime by viewModel.lastUpdateCheckTime.collectAsStateWithLifecycle()
    val activeCarouselItems by viewModel.activeCarouselItems.collectAsStateWithLifecycle()
    val isRefreshing by viewModel.isDashboardRefreshing.collectAsStateWithLifecycle()
    val membersWithMonthlyStatus by viewModel.membersWithMonthlyStatus.collectAsStateWithLifecycle()
    val activeMembers by viewModel.activeMembers.collectAsStateWithLifecycle()
    val userMemberships by viewModel.userMemberships.collectAsStateWithLifecycle()
    val currentUserId by viewModel.currentUserId.collectAsStateWithLifecycle()

    var customModuleDetail by remember { mutableStateOf<HomeModuleConfig?>(null) }
    var showAppUpdateDialog by remember { mutableStateOf(false) }

    val enabledModules = remember(homeModules) {
        homeModules.filter { it.isEnabled }.sortedBy { it.orderIndex }
    }

    val homeNotifications = remember(loansWithVoting, pendingApprovals, feedbacksWithVotes, notices, updateStatus, isUpdateBannerDismissed) {
        val items = mutableListOf<HomeNotificationItem>()

        // 0. In-App Update Service Notification (Indigo Accent: Color(0xFF6366F1))
        if (updateStatus is UpdateCheckStatus.UpdateAvailable && !isUpdateBannerDismissed) {
            val updateInfo = (updateStatus as UpdateCheckStatus.UpdateAvailable).updateInfo
            items.add(
                HomeNotificationItem(
                    id = "system_app_update",
                    type = NotificationType.SYSTEM_UPDATE,
                    title = "App Update: v${updateInfo.versionName} Ready",
                    description = updateInfo.title.ifBlank { "A software update is ready. Tap to download & install." },
                    categoryLabel = if (updateInfo.isMandatory) "Mandatory Update" else "Software Update",
                    accentColor = Color(0xFF6366F1),
                    icon = Icons.Default.SystemUpdate,
                    priority = 0,
                    onClick = { showAppUpdateDialog = true }
                )
            )
        }

        // 1. Pending Loan Requests (Orange Accent: Color(0xFFF97316))
        val pendingLoans = loansWithVoting.filter { it.loan.status in listOf("VOTING", "SUBMITTED") }
        if (pendingLoans.isNotEmpty()) {
            val count = pendingLoans.size
            items.add(
                HomeNotificationItem(
                    id = "loan_requests_pending",
                    type = NotificationType.LOAN_REQUEST,
                    title = if (count == 1) "1 Loan Request(s) Awaiting Vote" else "$count Loan Request(s) Awaiting Vote",
                    description = "70% approval rule active. Tap to vote now.",
                    categoryLabel = "Loan Request",
                    accentColor = Color(0xFFF97316),
                    icon = Icons.Default.Handshake,
                    priority = 1,
                    onClick = onNavigateToLoans
                )
            )
        }

        // 2. Pending Payment Submissions (Amber Accent: Color(0xFFF59E0B))
        if (pendingApprovals.isNotEmpty()) {
            val count = pendingApprovals.size
            items.add(
                HomeNotificationItem(
                    id = "pending_approvals",
                    type = NotificationType.PENDING_PAYMENT,
                    title = if (count == 1) "1 Payment Submission Awaiting Approval" else "$count Payment Submission(s) Awaiting Approval",
                    description = "Tap to review receipt and confirm or reject.",
                    categoryLabel = "Payment Pending",
                    accentColor = Color(0xFFF59E0B),
                    icon = Icons.Default.HourglassTop,
                    priority = 2,
                    onClick = onNavigateToInbox
                )
            )
        }

        // 3. Active Complaints (Red Accent: Color(0xFFEF4444))
        val activeComplaints = feedbacksWithVotes.filter {
            it.feedback.type == "COMPLAINT" && it.feedback.status in listOf("SUBMITTED", "UNDER_REVIEW", "DISCUSSING")
        }
        activeComplaints.take(2).forEach { item ->
            items.add(
                HomeNotificationItem(
                    id = "complaint_${item.feedback.id}",
                    type = NotificationType.COMPLAINT,
                    title = item.feedback.subject.ifBlank { "New Complaint" },
                    description = item.feedback.description.ifBlank { "A complaint requires attention. Tap to view." },
                    categoryLabel = "Complaint",
                    accentColor = Color(0xFFEF4444),
                    icon = Icons.Default.ReportProblem,
                    priority = 3,
                    onClick = onNavigateToFeedback
                )
            )
        }

        // 4. Active Proposals (Purple Accent: Color(0xFF8B5CF6))
        val activeProposals = feedbacksWithVotes.filter {
            it.feedback.type == "PROPOSAL" && it.feedback.status in listOf("SUBMITTED", "UNDER_REVIEW", "DISCUSSING")
        }
        activeProposals.take(2).forEach { item ->
            items.add(
                HomeNotificationItem(
                    id = "proposal_${item.feedback.id}",
                    type = NotificationType.PROPOSAL,
                    title = item.feedback.subject.ifBlank { "New Proposal Available" },
                    description = if (item.feedback.requiresVoting) {
                        "Proposal voting active (${item.agreePercentage.toInt()}% agreed). Tap to vote."
                    } else {
                        item.feedback.description.ifBlank { "A new proposal requires your attention." }
                    },
                    categoryLabel = "Proposal",
                    accentColor = Color(0xFF8B5CF6),
                    icon = Icons.Default.Assignment,
                    priority = 4,
                    onClick = onNavigateToFeedback
                )
            )
        }

        // 5. Active Suggestions (Blue Accent: Color(0xFF2563EB))
        val activeSuggestions = feedbacksWithVotes.filter {
            it.feedback.type == "SUGGESTION" && it.feedback.status in listOf("SUBMITTED", "UNDER_REVIEW", "DISCUSSING")
        }
        activeSuggestions.take(2).forEach { item ->
            items.add(
                HomeNotificationItem(
                    id = "suggestion_${item.feedback.id}",
                    type = NotificationType.SUGGESTION,
                    title = item.feedback.subject.ifBlank { "New Suggestion Available" },
                    description = item.feedback.description.ifBlank { "A new notice has been posted. Tap to view." },
                    categoryLabel = "Suggestion",
                    accentColor = Color(0xFF2563EB),
                    icon = Icons.Default.Lightbulb,
                    priority = 5,
                    onClick = onNavigateToFeedback
                )
            )
        }

        // 6. Society Notices / Announcements (Green Accent: Color(0xFF10B981))
        notices.take(2).forEach { notice ->
            items.add(
                HomeNotificationItem(
                    id = "notice_${notice.id}",
                    type = NotificationType.NOTICE,
                    title = notice.title.ifBlank { "Society Notice" },
                    description = notice.content.ifBlank { "A new notice has been posted. Tap to view." },
                    categoryLabel = "Notice",
                    accentColor = Color(0xFF10B981),
                    icon = Icons.Default.Campaign,
                    priority = 6,
                    onClick = onNavigateToInbox
                )
            )
        }

        items.distinctBy { it.id }.sortedBy { it.priority }
    }

    val (category, subCategory) = remember(settings) {
        HomeTemplateResolver.resolve(settings)
    }

    var showCategorySelectorDialog by remember { mutableStateOf(false) }

    val template = remember(category, subCategory) {
        HomeTemplateRegistry.resolve(category, subCategory)
    }

    val myMembership = remember(userMemberships, settings.id) {
        userMemberships.find { it.groupId == settings.id }
    }
    val myMemberId = myMembership?.memberIdInGroup ?: currentUserId
    val myMemberStatus = remember(membersWithMonthlyStatus, myMemberId, settings.ownerUid) {
        membersWithMonthlyStatus.find {
            it.member.id == myMemberId ||
            (it.member.linkedUid.isNotBlank() && it.member.linkedUid == settings.ownerUid)
        }
    }
    val myMember = remember(myMemberStatus, activeMembers, myMemberId) {
        myMemberStatus?.member ?: activeMembers.find { it.id == myMemberId }
    }

    val templateContext = HomeTemplateContext(
        viewModel = viewModel,
        settings = settings,
        category = category,
        subCategory = subCategory,
        financials = financials,
        selectedMonth = selectedMonth,
        selectedYear = selectedYear,
        monthSummary = monthSummary,
        recentTxns = recentTxns,
        isAdminUnlocked = isAdminUnlocked,
        loansWithVoting = loansWithVoting,
        pendingApprovals = pendingApprovals,
        feedbacksWithVotes = feedbacksWithVotes,
        notices = notices,
        homeModules = homeModules,
        activeCarouselItems = activeCarouselItems,
        notifications = homeNotifications,
        isRefreshing = isRefreshing,
        listState = listState,
        membersWithMonthlyStatus = membersWithMonthlyStatus,
        currentUserMember = myMember,
        currentUserMonthlyStatus = myMemberStatus,
        totalActiveMembersCount = activeMembers.size,
        onNavigateToMembers = onNavigateToMembers,
        onNavigateToMonthly = onNavigateToMonthly,
        onNavigateToDues = onNavigateToDues,
        onNavigateToReports = onNavigateToReports,
        onNavigateToRecordPayment = onNavigateToRecordPayment,
        onNavigateToAddMember = onNavigateToAddMember,
        onNavigateToMemberProfile = onNavigateToMemberProfile,
        onNavigateToLoans = onNavigateToLoans,
        onNavigateToInvestments = onNavigateToInvestments,
        onNavigateToFeedback = onNavigateToFeedback,
        onNavigateToLedger = onNavigateToLedger,
        onNavigateToInbox = onNavigateToInbox,
        onNavigateToAuctionDetails = onNavigateToAuctionDetails,
        onCategoryChangeRequest = { _, _ -> showCategorySelectorDialog = true }
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        template.Render(templateContext)
    }

    if (showCategorySelectorDialog) {
        CategoryChangeDialog(
            currentCategory = category,
            currentSubCategory = subCategory,
            onDismiss = { showCategorySelectorDialog = false },
            onConfirm = { newCat, newSub ->
                showCategorySelectorDialog = false
                viewModel.updateGroupCategoryAndSubCategory(newCat, newSub)
            }
        )
    }

    if (false) {
        SamitiPullToRefreshBox(
            isRefreshing = isRefreshing,
            onRefresh = { viewModel.refreshDashboard() },
            modifier = modifier.fillMaxSize()
        ) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .testTag("dashboard_screen"),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
        // 1. Group Society Header Banner (Total Assets & In-Hand Cash/Bank)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dashboard_header_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    Color(0xFF1E1B4B),
                                    Color(0xFF312E81),
                                    Color(0xFF3730A3)
                                )
                            )
                        )
                        .padding(14.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = settings.groupName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 17.sp
                                )
                                if (settings.groupSubtitle.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(1.dp))
                                    Text(
                                        text = settings.groupSubtitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = IndigoHeroSubtext,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            // Admin status pill
                            Surface(
                                shape = CircleShape,
                                color = Color.White.copy(alpha = 0.15f),
                                modifier = Modifier.padding(start = 6.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isAdminUnlocked) Icons.Default.LockOpen else Icons.Default.Lock,
                                        contentDescription = "Admin Security",
                                        tint = Color.White,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = if (isAdminUnlocked) "Admin Active" else "Protected",
                                        color = Color.White,
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Total Group Assets & In-Hand Balance
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "TOTAL GROUP ASSETS",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = IndigoHeroSubtext,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = "${settings.currencySymbol}${CurrencyFormatter.formatIndian(financials.totalGroupAssets)}",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 19.sp
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "DUE AMOUNT",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = IndigoHeroSubtext,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = "${settings.currencySymbol}${CurrencyFormatter.formatIndian(financials.totalDueAllTime + financials.outstandingLoans)}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFFCA5A5),
                                    fontSize = 16.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Sub-metrics row (Investment, Expenses, In-Hand Balance)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color.White.copy(alpha = 0.10f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Investment", fontSize = 9.5.sp, color = IndigoHeroSubtext)
                                    Text("${settings.currencySymbol}${CurrencyFormatter.formatIndian(financials.totalInvestmentsValue)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Expenses", fontSize = 9.5.sp, color = IndigoHeroSubtext)
                                    Text("${settings.currencySymbol}${CurrencyFormatter.formatIndian(financials.totalExpenses)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("In-Hand Balance", fontSize = 9.5.sp, color = IndigoHeroSubtext)
                                    Text("${settings.currencySymbol}${CurrencyFormatter.formatIndian(financials.availableInHandBalance)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFA7F3D0))
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. Smart Auto-Rotating Notification & Announcement Carousel (If Any)
        if (homeNotifications.isNotEmpty()) {
            item {
                HomeNotificationCarousel(
                    notifications = homeNotifications,
                    rotationIntervalMs = 4000L
                )
            }
        }

        // 3. Quick Actions Carousel (Configurable per Group)
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Services & Actions",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(horizontal = 1.dp, vertical = 1.dp)
                ) {
                    if (enabledModules.isEmpty()) {
                        item {
                            ActionCarouselCard(
                                title = "Contribution",
                                subtitle = "Collect & Record",
                                icon = Icons.Default.Payments,
                                isPrimary = true,
                                onClick = onNavigateToRecordPayment,
                                testTag = "quick_record_pay_btn"
                            )
                        }
                    } else {
                        items(enabledModules.size) { index ->
                            val mod = enabledModules[index]
                            val isPrimary = index == 0
                            val modIcon = resolveModuleIcon(mod.iconName)
                            val title = mod.getDisplayName()
                            val subtitle = mod.description.ifBlank { "Open ${mod.getDisplayName()}" }
                            
                            ActionCarouselCard(
                                title = title,
                                subtitle = subtitle,
                                icon = modIcon,
                                isPrimary = isPrimary,
                                onClick = {
                                    when (mod.key) {
                                        "contribution" -> onNavigateToRecordPayment()
                                        "investment" -> onNavigateToInvestments()
                                        "loan" -> onNavigateToLoans()
                                        "suggestion", "complaint", "help", "proposal" -> onNavigateToFeedback()
                                        "members" -> onNavigateToMembers()
                                        "expenses", "income" -> onNavigateToLedger()
                                        "meeting", "events", "notice" -> onNavigateToInbox()
                                        "savings" -> onNavigateToInvestments()
                                        "attendance" -> onNavigateToMonthly()
                                        "reports" -> onNavigateToReports()
                                        else -> {
                                            customModuleDetail = mod
                                        }
                                    }
                                },
                                testTag = "quick_module_${mod.key}_btn"
                            )
                        }
                    }
                }
            }
        }

        // 4. Current Month Overview Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                    .testTag("current_month_summary_card"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
            ) {
                Column(modifier = Modifier.padding(13.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${DateUtils.getMonthName(selectedMonth)} $selectedYear Contributions",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        TextButton(
                            onClick = onNavigateToMonthly,
                            modifier = Modifier.testTag("view_month_details_btn")
                        ) {
                            Text("Manage", color = IndigoPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Spacer(modifier = Modifier.width(2.dp))
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(13.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Progress bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Collection Target (${monthSummary.collectionPercentage.toInt()}%)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "${settings.currencySymbol}${CurrencyFormatter.formatIndian(monthSummary.totalCollected)} / ${settings.currencySymbol}${CurrencyFormatter.formatIndian(monthSummary.totalExpected)}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 11.5.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(5.dp))

                    LinearProgressIndicator(
                        progress = { (monthSummary.collectionPercentage / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(CircleShape),
                        color = IndigoPrimary,
                        trackColor = IndigoPrimary.copy(alpha = 0.12f)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Paid vs Pending count row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(StatusPaidText))
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(text = "${monthSummary.paidCount} Paid", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface, fontSize = 12.sp)
                        }

                        if (monthSummary.partialCount > 0) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(StatusPartialText))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(text = "${monthSummary.partialCount} Partial", fontWeight = FontWeight.SemiBold, color = StatusPartialText, fontSize = 12.sp)
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(StatusUnpaidText))
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(text = "${monthSummary.unpaidCount} Pending", fontWeight = FontWeight.SemiBold, color = StatusUnpaidText, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // 5. Group Asset Allocation Breakdown Bar
        if (financials.assetAllocations.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                ) {
                    Column(modifier = Modifier.padding(13.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Group Asset Portfolio",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${settings.currencySymbol}${CurrencyFormatter.formatIndian(financials.totalGroupAssets)}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = IndigoPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Segmented bar
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(7.dp)
                                .clip(RoundedCornerShape(4.dp))
                        ) {
                            financials.assetAllocations.forEach { item ->
                                Box(
                                    modifier = Modifier
                                        .weight(item.percentage.coerceAtLeast(1f))
                                        .fillMaxSize()
                                        .background(Color(item.colorHex))
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Labels grid
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            financials.assetAllocations.forEach { item ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(7.dp)
                                                .clip(CircleShape)
                                                .background(Color(item.colorHex))
                                        )
                                        Spacer(modifier = Modifier.width(5.dp))
                                        Text(text = item.category, fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurface)
                                    }
                                    Text(
                                        text = "${settings.currencySymbol}${CurrencyFormatter.formatIndian(item.amount)} (${item.percentage.toInt()}%)",
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 5.5 Backend-Driven Dynamic Home Screen Carousel & Birthday Greetings
        // Positioned BELOW Group Asset Portfolio AND ABOVE Collection Trends
        if (activeCarouselItems.isNotEmpty()) {
            item {
                HomeScreenCarousel(
                    items = activeCarouselItems,
                    onNavigateToRoute = { route ->
                        when (route.lowercase()) {
                            "members" -> onNavigateToMembers()
                            "monthly" -> onNavigateToMonthly()
                            "dues" -> onNavigateToDues()
                            "reports" -> onNavigateToReports()
                            "record_payment", "record_payment/0" -> onNavigateToRecordPayment()
                            "loans" -> onNavigateToLoans()
                            "investments" -> onNavigateToInvestments()
                            "feedback" -> onNavigateToFeedback()
                            "ledger" -> onNavigateToLedger()
                            "inbox" -> onNavigateToInbox()
                        }
                    },
                    onNavigateToScreen = { screen ->
                        when (screen.lowercase()) {
                            "members" -> onNavigateToMembers()
                            "monthly" -> onNavigateToMonthly()
                            "dues" -> onNavigateToDues()
                            "reports" -> onNavigateToReports()
                            "record_payment", "payment" -> onNavigateToRecordPayment()
                            "loans", "loan" -> onNavigateToLoans()
                            "investments", "investment" -> onNavigateToInvestments()
                            "feedback", "suggestions", "complaints", "proposals" -> onNavigateToFeedback()
                            "ledger" -> onNavigateToLedger()
                            "inbox" -> onNavigateToInbox()
                        }
                    }
                )
            }
        }

        // 6. Recent Transactions Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Financial Activity Ledger",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                TextButton(onClick = onNavigateToLedger) {
                    Text("View Full Ledger", color = IndigoPrimary, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (recentTxns.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No financial transactions recorded yet",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            items(recentTxns.take(2)) { txn ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp)),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = if (txn.isCredit) Emerald500.copy(alpha = 0.12f) else Rose500.copy(alpha = 0.12f),
                                modifier = Modifier.size(30.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (txn.isCredit) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                        contentDescription = null,
                                        tint = if (txn.isCredit) Emerald500 else Rose500,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = txn.description,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.5.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${DateUtils.formatDate(txn.date)} • ${txn.paymentMethod}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 10.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Text(
                            text = "${if (txn.isCredit) "+" else "-"}${settings.currencySymbol}${CurrencyFormatter.formatIndian(txn.amount)}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (txn.isCredit) Emerald500 else Rose500
                        )
                    }
                }
            }
        }
    }
    }
    }

    // Custom Module Click Details Dialog
    if (customModuleDetail != null) {
        val mod = customModuleDetail!!
        AlertDialog(
            onDismissRequest = { customModuleDetail = null },
            icon = {
                Surface(
                    shape = CircleShape,
                    color = IndigoPrimary.copy(alpha = 0.12f),
                    modifier = Modifier.size(48.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = resolveModuleIcon(mod.iconName),
                            contentDescription = mod.getDisplayName(),
                            tint = IndigoPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            },
            title = {
                Text(
                    text = mod.getDisplayName(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (mod.description.isNotBlank()) mod.description else "Custom service module configured for ${settings.groupName}.",
                        fontSize = 13.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "• Group: ${settings.groupName}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "• Status: Active Service Module",
                                fontSize = 12.sp,
                                color = Emerald500
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { customModuleDetail = null },
                    modifier = Modifier.testTag("close_custom_module_btn")
                ) {
                    Text("Close", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    if (showAppUpdateDialog) {
        AppUpdateDialog(
            viewModel = viewModel,
            updateStatus = updateStatus,
            currentVersionName = viewModel.currentVersionName,
            currentVersionCode = viewModel.currentVersionCode,
            lastCheckedTime = lastCheckedTime,
            isAdmin = isAdminUnlocked,
            onDismissRequest = { showAppUpdateDialog = false }
        )
    }
}

fun resolveModuleIcon(iconName: String): ImageVector {
    return when (iconName.lowercase()) {
        "payments", "contribution", "money" -> Icons.Default.Payments
        "group", "members" -> Icons.Default.Group
        "receipt_long", "expenses" -> Icons.Default.ReceiptLong
        "account_balance", "income", "bank" -> Icons.Default.AccountBalance
        "chat", "meeting" -> Icons.Default.Chat
        "campaign", "notice" -> Icons.Default.Campaign
        "lightbulb", "suggestion", "ideas" -> Icons.Default.Lightbulb
        "report_problem", "complaint" -> Icons.Default.ReportProblem
        "help", "support" -> Icons.Default.Help
        "event", "events", "calendar" -> Icons.Default.Event
        "trending_up", "investment" -> Icons.Default.TrendingUp
        "handshake", "loan", "loans" -> Icons.Default.Handshake
        "savings" -> Icons.Default.Savings
        "check_circle", "attendance" -> Icons.Default.CheckCircle
        "assignment", "proposal" -> Icons.Default.Assignment
        "pie_chart", "reports" -> Icons.Default.PieChart
        "star" -> Icons.Default.Star
        "celebration" -> Icons.Default.Celebration
        "store" -> Icons.Default.Store
        "work" -> Icons.Default.Work
        "auto_awesome" -> Icons.Default.AutoAwesome
        else -> Icons.Default.Payments
    }
}

@Composable
fun ActionCarouselCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    isPrimary: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "action_carousel_card"
) {
    Card(
        modifier = modifier
            .width(115.dp)
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isPrimary) IndigoPrimary else MaterialTheme.colorScheme.surface
        ),
        border = if (isPrimary) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isPrimary) 2.dp else 0.5.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.Start,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = if (isPrimary) Color.White.copy(alpha = 0.2f) else IndigoPrimary.copy(alpha = 0.1f),
                modifier = Modifier.size(30.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = if (isPrimary) Color.White else IndigoPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = if (isPrimary) Color.White else MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    maxLines = 1
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isPrimary) IndigoHeroSubtext else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 9.5.sp,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun QuickActionButton(
    title: String,
    icon: ImageVector,
    backgroundColor: Color,
    textColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    borderColor: Color? = null,
    testTag: String = "quick_action_btn"
) {
    Card(
        modifier = modifier
            .then(
                if (borderColor != null) Modifier.border(1.dp, borderColor, RoundedCornerShape(10.dp))
                    .clickable(onClick = onClick)
                else Modifier.clickable(onClick = onClick)
            )
            .testTag(testTag),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 9.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = textColor,
                modifier = Modifier.size(17.dp)
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = textColor,
                fontWeight = FontWeight.SemiBold,
                fontSize = 10.sp
            )
        }
    }
}
