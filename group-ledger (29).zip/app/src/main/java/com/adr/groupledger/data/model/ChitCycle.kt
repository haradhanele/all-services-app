package com.adr.groupledger.data.model

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Lifecycle status of an individual Chit Fund cycle / round.
 * Strictly models transitions:
 * UPCOMING -> AUCTION_SCHEDULED -> AUCTION_OPEN -> AUCTION_CLOSED -> RESULT_PENDING -> COMPLETED
 * along with RESCHEDULED and CANCELLED.
 */
enum class ChitCycleStatus(val displayName: String) {
    UPCOMING("Upcoming"),
    AUCTION_SCHEDULED("Auction Scheduled"),
    AUCTION_OPEN("Auction Live"),
    AUCTION_CLOSED("Auction Closed"),
    RESULT_PENDING("Result Pending"),
    COMPLETED("Completed"),
    RESCHEDULED("Rescheduled"),
    CANCELLED("Cancelled");

    fun isTerminal(): Boolean {
        return this == COMPLETED || this == CANCELLED
    }

    /**
     * Enforces valid state transition rules for cycle auctions.
     */
    fun canTransitionTo(target: ChitCycleStatus): Boolean {
        if (this == target) return true
        if (this == COMPLETED) return false // Completed cycles cannot be changed

        return when (this) {
            UPCOMING -> target in listOf(AUCTION_SCHEDULED, AUCTION_OPEN, RESCHEDULED, CANCELLED)
            AUCTION_SCHEDULED -> target in listOf(AUCTION_OPEN, AUCTION_CLOSED, RESCHEDULED, CANCELLED)
            AUCTION_OPEN -> target in listOf(AUCTION_CLOSED, RESULT_PENDING, CANCELLED)
            AUCTION_CLOSED -> target in listOf(RESULT_PENDING, COMPLETED, CANCELLED, AUCTION_OPEN)
            RESULT_PENDING -> target in listOf(COMPLETED, AUCTION_CLOSED, CANCELLED)
            RESCHEDULED -> target in listOf(AUCTION_SCHEDULED, AUCTION_OPEN, CANCELLED)
            CANCELLED -> target in listOf(UPCOMING, AUCTION_SCHEDULED) // Reopening if admin corrects
            COMPLETED -> false
        }
    }

    companion object {
        fun fromString(value: String?): ChitCycleStatus {
            if (value.isNullOrBlank()) return UPCOMING
            val normalized = value.trim().uppercase(Locale.US)
            return entries.find { it.name == normalized }
                ?: when (normalized) {
                    "ACTIVE", "CURRENT", "SCHEDULED" -> AUCTION_SCHEDULED
                    "OPEN", "LIVE", "AUCTION_LIVE" -> AUCTION_OPEN
                    "BID_SUBMISSION_CLOSED", "BID_CLOSED", "CLOSED" -> AUCTION_CLOSED
                    "REVIEW", "PROCESSING", "RESULT_PROCESSING", "PENDING_RESULT" -> RESULT_PENDING
                    "DONE", "FINISHED", "PAID" -> COMPLETED
                    "RESCHEDULE", "POSTPONED", "DEFERRED" -> RESCHEDULED
                    "CANCEL", "VOID" -> CANCELLED
                    else -> UPCOMING
                }
        }
    }
}

/**
 * Represents a single Chit Fund Round / Cycle.
 * Provides the schedule, time window, status, and audit metadata.
 */
data class ChitCycle(
    val cycleNumber: Int,
    val scheduledDateMillis: Long = System.currentTimeMillis(),
    val installmentAmount: Double = 0.0,
    val status: ChitCycleStatus = ChitCycleStatus.UPCOMING,
    val auctionDateMillis: Long? = null,
    val auctionStartTime: String? = "08:00 PM",
    val auctionEndTime: String? = "08:15 PM",
    val auctionDurationMinutes: Int = 15,
    val isDateManuallyRescheduled: Boolean = false,
    val rescheduleReason: String? = null,
    val originalDateMillis: Long? = null,
    val winnerMemberId: Long? = null,
    val winnerMemberName: String? = null,
    val winningBidAmount: Double? = null,
    val dividendPerMember: Double? = null,
    val notes: String = "",
    val createdAtMillis: Long = System.currentTimeMillis(),
    val updatedAtMillis: Long = System.currentTimeMillis()
) {
    val netInstallmentAmount: Double
        get() = (installmentAmount - (dividendPerMember ?: 0.0)).coerceAtLeast(0.0)

    val scheduledDate: String
        get() {
            return try {
                val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
                sdf.format(Date(auctionDateMillis ?: scheduledDateMillis))
            } catch (e: Exception) {
                "Scheduled"
            }
        }

    val displayAuctionWindow: String
        get() {
            val start = auctionStartTime?.ifBlank { "08:00 PM" } ?: "08:00 PM"
            val end = auctionEndTime?.ifBlank { "08:15 PM" } ?: "08:15 PM"
            return "$start – $end"
        }

    /**
     * Resolves the exact auction start epoch in milliseconds.
     */
    fun resolveAuctionStartEpoch(): Long {
        val baseDate = auctionDateMillis ?: scheduledDateMillis
        return parseTimeToEpoch(baseDate, auctionStartTime ?: "08:00 PM")
    }

    /**
     * Resolves the exact auction end epoch in milliseconds.
     */
    fun resolveAuctionEndEpoch(): Long {
        val startEpoch = resolveAuctionStartEpoch()
        if (!auctionEndTime.isNullOrBlank()) {
            val baseDate = auctionDateMillis ?: scheduledDateMillis
            val endEpoch = parseTimeToEpoch(baseDate, auctionEndTime)
            if (endEpoch > startEpoch) return endEpoch
        }
        val durationMs = (if (auctionDurationMinutes > 0) auctionDurationMinutes else 15) * 60 * 1000L
        return startEpoch + durationMs
    }

    /**
     * Derives current operational status based on current epoch and configured time window.
     * Preserves terminal states (COMPLETED, CANCELLED) and explicit states.
     */
    fun deriveOperationalStatus(nowMillis: Long = System.currentTimeMillis()): ChitCycleStatus {
        if (status.isTerminal()) return status
        if (status == ChitCycleStatus.RESCHEDULED && nowMillis < resolveAuctionStartEpoch()) {
            return ChitCycleStatus.RESCHEDULED
        }

        val start = resolveAuctionStartEpoch()
        val end = resolveAuctionEndEpoch()

        return when {
            nowMillis < start -> if (isDateManuallyRescheduled) ChitCycleStatus.RESCHEDULED else ChitCycleStatus.AUCTION_SCHEDULED
            nowMillis in start..end -> ChitCycleStatus.AUCTION_OPEN
            nowMillis > end -> ChitCycleStatus.AUCTION_CLOSED
            else -> status
        }
    }

    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("cycleNumber", cycleNumber)
            put("scheduledDateMillis", scheduledDateMillis)
            put("installmentAmount", installmentAmount)
            put("status", status.name)
            auctionDateMillis?.let { put("auctionDateMillis", it) }
            auctionStartTime?.let { put("auctionStartTime", it) }
            auctionEndTime?.let { put("auctionEndTime", it) }
            put("auctionDurationMinutes", auctionDurationMinutes)
            put("isDateManuallyRescheduled", isDateManuallyRescheduled)
            rescheduleReason?.let { put("rescheduleReason", it) }
            originalDateMillis?.let { put("originalDateMillis", it) }
            winnerMemberId?.let { put("winnerMemberId", it) }
            winnerMemberName?.let { put("winnerMemberName", it) }
            winningBidAmount?.let { put("winningBidAmount", it) }
            dividendPerMember?.let { put("dividendPerMember", it) }
            if (notes.isNotBlank()) put("notes", notes)
            put("createdAtMillis", createdAtMillis)
            put("updatedAtMillis", updatedAtMillis)
        }
    }

    companion object {
        fun fromJson(json: JSONObject): ChitCycle {
            val scheduled = json.optLong("scheduledDateMillis", System.currentTimeMillis())
            return ChitCycle(
                cycleNumber = json.optInt("cycleNumber", 1),
                scheduledDateMillis = scheduled,
                installmentAmount = json.optDouble("installmentAmount", 0.0),
                status = ChitCycleStatus.fromString(json.optString("status")),
                auctionDateMillis = if (json.has("auctionDateMillis")) json.optLong("auctionDateMillis") else scheduled,
                auctionStartTime = json.optString("auctionStartTime", "08:00 PM").takeIf { it.isNotBlank() },
                auctionEndTime = json.optString("auctionEndTime", "08:15 PM").takeIf { it.isNotBlank() },
                auctionDurationMinutes = json.optInt("auctionDurationMinutes", 15),
                isDateManuallyRescheduled = json.optBoolean("isDateManuallyRescheduled", false),
                rescheduleReason = if (json.has("rescheduleReason")) json.optString("rescheduleReason") else null,
                originalDateMillis = if (json.has("originalDateMillis")) json.optLong("originalDateMillis") else null,
                winnerMemberId = if (json.has("winnerMemberId")) json.optLong("winnerMemberId") else null,
                winnerMemberName = if (json.has("winnerMemberName")) json.optString("winnerMemberName") else null,
                winningBidAmount = if (json.has("winningBidAmount")) json.optDouble("winningBidAmount") else null,
                dividendPerMember = if (json.has("dividendPerMember")) json.optDouble("dividendPerMember") else null,
                notes = json.optString("notes", ""),
                createdAtMillis = json.optLong("createdAtMillis", System.currentTimeMillis()),
                updatedAtMillis = json.optLong("updatedAtMillis", System.currentTimeMillis())
            )
        }

        fun parseArray(jsonArray: JSONArray?): List<ChitCycle> {
            if (jsonArray == null) return emptyList()
            val list = mutableListOf<ChitCycle>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.optJSONObject(i) ?: continue
                list.add(fromJson(obj))
            }
            return list
        }

        fun serializeList(cycles: List<ChitCycle>): JSONArray {
            val array = JSONArray()
            cycles.forEach { array.put(it.toJson()) }
            return array
        }

        private fun parseTimeToEpoch(baseDateMillis: Long, timeStr: String): Long {
            val cal = Calendar.getInstance().apply {
                timeInMillis = baseDateMillis
            }
            try {
                // Parse patterns like "08:00 PM", "8:00 PM", "20:00"
                val cleaned = timeStr.trim().uppercase(Locale.US)
                val isPm = cleaned.endsWith("PM")
                val isAm = cleaned.endsWith("AM")
                val numPart = cleaned.replace("AM", "").replace("PM", "").trim()
                val parts = numPart.split(":")
                var hour = parts[0].trim().toIntOrNull() ?: 20
                val min = if (parts.size > 1) parts[1].trim().toIntOrNull() ?: 0 else 0

                if (isPm && hour < 12) hour += 12
                if (isAm && hour == 12) hour = 0

                cal.set(Calendar.HOUR_OF_DAY, hour)
                cal.set(Calendar.MINUTE, min)
                cal.set(Calendar.SECOND, 0)
                cal.set(Calendar.MILLISECOND, 0)
            } catch (e: Exception) {
                cal.set(Calendar.HOUR_OF_DAY, 20)
                cal.set(Calendar.MINUTE, 0)
                cal.set(Calendar.SECOND, 0)
                cal.set(Calendar.MILLISECOND, 0)
            }
            return cal.timeInMillis
        }
    }
}
