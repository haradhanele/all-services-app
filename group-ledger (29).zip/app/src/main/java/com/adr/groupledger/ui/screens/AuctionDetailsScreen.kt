package com.adr.groupledger.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.EditCalendar
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DividerDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.ChitCycle
import com.adr.groupledger.data.model.ChitCycleStatus
import com.adr.groupledger.data.model.ChitFundConfig
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.utils.ChitCalculationEngine
import com.adr.groupledger.utils.CurrencyFormatter
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Phase B.2 — Chit Fund Auction & Cycle Details Screen.
 * Displays authoritative schedule, live dynamic countdown, scheme rules,
 * eligibility criteria, and Group Admin rescheduling controls.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuctionDetailsScreen(
    cycleNumber: Int?,
    viewModel: SocietyViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()
    val currentUserRole by viewModel.currentUserRole.collectAsStateWithLifecycle()
    val isGroupAdmin = isAdminUnlocked || currentUserRole.equals("ADMIN", ignoreCase = true)

    val chitConfig = remember(settings) { ChitFundConfig.parseFromSettings(settings) }
    val curr = settings.currencySymbol.ifBlank { "₹" }

    // Resolve target cycle
    val targetCycleNumber = cycleNumber ?: chitConfig.currentChitNo ?: 1
    val cycle = remember(chitConfig.cycles, targetCycleNumber) {
        chitConfig.cycles.find { it.cycleNumber == targetCycleNumber }
            ?: ChitCycle(
                cycleNumber = targetCycleNumber,
                scheduledDateMillis = chitConfig.resolveNextAuctionEpoch(settings) ?: System.currentTimeMillis(),
                installmentAmount = chitConfig.monthlyInstallment ?: settings.defaultContribution,
                status = ChitCycleStatus.AUCTION_SCHEDULED,
                auctionStartTime = chitConfig.auctionTime ?: "08:00 PM"
            )
    }

    var showRescheduleDialog by remember { mutableStateOf(false) }
    var showLiveAuctionDialog by remember { mutableStateOf(false) }

    // Live dynamic status and countdown resolution
    var operationalStatus by remember(cycle) { mutableStateOf(cycle.deriveOperationalStatus()) }
    var secondsRemaining by remember(cycle, operationalStatus) {
        val now = System.currentTimeMillis()
        val startEpoch = cycle.resolveAuctionStartEpoch()
        val endEpoch = cycle.resolveAuctionEndEpoch()
        val diff = when {
            now < startEpoch -> (startEpoch - now) / 1000L
            now in startEpoch..endEpoch -> (endEpoch - now) / 1000L
            else -> 0L
        }
        mutableLongStateOf(diff.coerceAtLeast(0L))
    }

    LaunchedEffect(cycle) {
        while (true) {
            val now = System.currentTimeMillis()
            val startEpoch = cycle.resolveAuctionStartEpoch()
            val endEpoch = cycle.resolveAuctionEndEpoch()
            operationalStatus = cycle.deriveOperationalStatus(now)

            val diff = when {
                now < startEpoch -> (startEpoch - now) / 1000L
                now in startEpoch..endEpoch -> (endEpoch - now) / 1000L
                else -> 0L
            }
            secondsRemaining = diff.coerceAtLeast(0L)
            delay(1000L)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Round #${cycle.cycleNumber} Auction Details",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = settings.groupName.ifBlank { "Chit Fund Scheme" },
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Status Banner Card
            AuctionStatusBannerCard(
                cycle = cycle,
                operationalStatus = operationalStatus,
                secondsRemaining = secondsRemaining,
                isGroupAdmin = isGroupAdmin,
                onRescheduleClick = {
                    if (cycle.status == ChitCycleStatus.COMPLETED) {
                        Toast.makeText(context, "Completed cycles cannot be rescheduled", Toast.LENGTH_SHORT).show()
                    } else if (isGroupAdmin) {
                        showRescheduleDialog = true
                    } else {
                        Toast.makeText(context, "Only Group Admin can reschedule auctions", Toast.LENGTH_SHORT).show()
                    }
                }
            )

            // 2. Schedule & Time Window Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "AUCTION TIMING & WINDOW",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        letterSpacing = 0.5.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(imageVector = Icons.Default.Event, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                            Text("Scheduled Date", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(
                            text = cycle.scheduledDate,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(imageVector = Icons.Default.AccessTime, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                            Text("Auction Window", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(
                            text = cycle.displayAuctionWindow,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(imageVector = Icons.Default.Schedule, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                            Text("Auction Duration", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(
                            text = "${cycle.auctionDurationMinutes} Minutes",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    if (cycle.isDateManuallyRescheduled) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Rose500.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = Rose500, modifier = Modifier.size(16.dp))
                            Column {
                                Text("Rescheduled by Administrator", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = Rose500)
                                if (!cycle.rescheduleReason.isNullOrBlank()) {
                                    Text("Reason: ${cycle.rescheduleReason}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }

            // 3. Scheme Financial Parameters Card
            val totalMembersCount = chitConfig.totalMembers ?: 20
            val installmentVal = cycle.installmentAmount.takeIf { it > 0 } ?: (chitConfig.monthlyInstallment ?: 5000.0)
            val expectedPot = totalMembersCount * installmentVal

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "SCHEME & FINANCIAL METRICS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        letterSpacing = 0.5.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Expected Pot Value", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = "$curr${CurrencyFormatter.formatIndian(expectedPot)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Base Installment Amount", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = "$curr${CurrencyFormatter.formatIndian(installmentVal)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = IndigoPrimary
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Frequency", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = chitConfig.frequency.ifBlank { "MONTHLY" },
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Scheme Pool Members", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = "$totalMembersCount Members",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // 4. Participation & Eligibility Summary
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "AUCTION RULES & ELIGIBILITY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        letterSpacing = 0.5.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Emerald500, modifier = Modifier.size(16.dp))
                        Text(
                            text = "Must have cleared all previous cycle installments to participate in bidding.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(16.dp))
                        Text(
                            text = "Members who have already taken the chit in earlier rounds cannot bid again, but must continue paying monthly installments.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // 5. Admin Controls (Only when Group Admin)
            if (isGroupAdmin && cycle.status != ChitCycleStatus.COMPLETED) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                    border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.25f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                            Text("Group Admin Controls", fontWeight = FontWeight.Bold, fontSize = 13.5.sp, color = IndigoPrimary)
                        }

                        Text(
                            text = "As Group Admin, you can reschedule future auction dates or adjust auction windows. Completed historical rounds remain securely protected.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        OutlinedButton(
                            onClick = { showRescheduleDialog = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_reschedule_auction_btn"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, IndigoPrimary)
                        ) {
                            Icon(imageVector = Icons.Default.EditCalendar, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Reschedule Round #${cycle.cycleNumber} Auction", color = IndigoPrimary, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                        }
                    }
                }
            }

            // 6. Primary Action Button
            Spacer(modifier = Modifier.height(4.dp))
            if (operationalStatus == ChitCycleStatus.AUCTION_OPEN) {
                Button(
                    onClick = { showLiveAuctionDialog = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("auction_enter_live_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Emerald500),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Enter Live Auction", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            } else if (operationalStatus == ChitCycleStatus.COMPLETED) {
                OutlinedButton(
                    onClick = { onNavigateBack() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Emerald500)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Round Completed — Return to Home", fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
                }
            } else {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(imageVector = Icons.Default.AccessTime, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when (operationalStatus) {
                                ChitCycleStatus.AUCTION_SCHEDULED, ChitCycleStatus.UPCOMING -> "Auction scheduled. Live bidding floor will open at ${cycle.auctionStartTime ?: "08:00 PM"}."
                                ChitCycleStatus.RESCHEDULED -> "Auction deferred. Will open on new scheduled date."
                                ChitCycleStatus.AUCTION_CLOSED, ChitCycleStatus.RESULT_PENDING -> "Bidding window closed. Awaiting result publication."
                                else -> "Auction not open for bidding at this moment."
                            },
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }

    // Live Auction Room Preview Dialog (In preparation for Phase B.3)
    if (showLiveAuctionDialog) {
        AlertDialog(
            onDismissRequest = { showLiveAuctionDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.Gavel, contentDescription = null, tint = Emerald500)
                    Text("Auction Floor — Round #${cycle.cycleNumber}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Auction status is currently AUCTION_OPEN.",
                        fontWeight = FontWeight.SemiBold,
                        color = Emerald500
                    )
                    Text(
                        text = "The cycle and auction schedule system is now fully active. The interactive bidding floor, reverse bid submission engine, and dividend calculation will be enabled in Phase B.3.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(onClick = { showLiveAuctionDialog = false }) {
                    Text("Understood")
                }
            }
        )
    }

    // Admin Reschedule Dialog
    if (showRescheduleDialog) {
        ChitAuctionRescheduleDialog(
            cycle = cycle,
            onDismiss = { showRescheduleDialog = false },
            onConfirmReschedule = { newDateMillis, newStartTime, newEndTime, reason ->
                viewModel.rescheduleChitCycle(
                    cycleNumber = cycle.cycleNumber,
                    newDateMillis = newDateMillis,
                    newStartTime = newStartTime,
                    newEndTime = newEndTime,
                    reason = reason,
                    onSuccess = {
                        showRescheduleDialog = false
                    }
                )
            }
        )
    }
}

/**
 * Visual Banner showing active state, countdown, and quick reschedule action.
 */
@Composable
private fun AuctionStatusBannerCard(
    cycle: ChitCycle,
    operationalStatus: ChitCycleStatus,
    secondsRemaining: Long,
    isGroupAdmin: Boolean,
    onRescheduleClick: () -> Unit
) {
    val statusColor = when (operationalStatus) {
        ChitCycleStatus.AUCTION_OPEN -> Emerald500
        ChitCycleStatus.AUCTION_SCHEDULED, ChitCycleStatus.UPCOMING -> IndigoPrimary
        ChitCycleStatus.AUCTION_CLOSED -> MaterialTheme.colorScheme.onSurfaceVariant
        ChitCycleStatus.RESULT_PENDING -> Amber500
        ChitCycleStatus.COMPLETED -> Emerald500
        ChitCycleStatus.RESCHEDULED -> Rose500
        ChitCycleStatus.CANCELLED -> MaterialTheme.colorScheme.error
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, statusColor.copy(alpha = 0.4f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = statusColor.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = operationalStatus.displayName.uppercase(Locale.US),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = statusColor,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        fontSize = 11.sp
                    )
                }

                if (cycle.status != ChitCycleStatus.COMPLETED && isGroupAdmin) {
                    TextButton(onClick = onRescheduleClick) {
                        Icon(imageVector = Icons.Default.EditCalendar, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reschedule", fontSize = 12.sp, color = IndigoPrimary, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Text(
                text = "Round #${cycle.cycleNumber} Chit Auction",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Dynamic Countdown Display
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val countdownTitle = when (operationalStatus) {
                        ChitCycleStatus.AUCTION_OPEN -> "AUCTION ENDS IN"
                        ChitCycleStatus.AUCTION_SCHEDULED, ChitCycleStatus.UPCOMING, ChitCycleStatus.RESCHEDULED -> "STARTS IN"
                        ChitCycleStatus.AUCTION_CLOSED, ChitCycleStatus.RESULT_PENDING -> "AUCTION CLOSED"
                        ChitCycleStatus.COMPLETED -> "ROUND FINISHED"
                        ChitCycleStatus.CANCELLED -> "ROUND CANCELLED"
                    }

                    Text(
                        text = countdownTitle,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = statusColor,
                        letterSpacing = 0.5.sp
                    )

                    if (operationalStatus in listOf(ChitCycleStatus.AUCTION_OPEN, ChitCycleStatus.AUCTION_SCHEDULED, ChitCycleStatus.UPCOMING, ChitCycleStatus.RESCHEDULED)) {
                        Text(
                            text = ChitCalculationEngine.formatCountdown(secondsRemaining),
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = statusColor
                        )
                    } else {
                        Text(
                            text = if (operationalStatus == ChitCycleStatus.COMPLETED) "Completed" else "Awaiting Result Audit",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

/**
 * Group Admin Dialog to safely reschedule a future auction date and window.
 */
@Composable
private fun ChitAuctionRescheduleDialog(
    cycle: ChitCycle,
    onDismiss: () -> Unit,
    onConfirmReschedule: (newDateMillis: Long, newStartTime: String, newEndTime: String, reason: String) -> Unit
) {
    val context = LocalContext.current
    var selectedDateMillis by remember { mutableLongStateOf(cycle.auctionDateMillis ?: cycle.scheduledDateMillis) }
    var startTime by remember { mutableStateOf(cycle.auctionStartTime ?: "08:00 PM") }
    var endTime by remember { mutableStateOf(cycle.auctionEndTime ?: "08:15 PM") }
    var reasonText by remember { mutableStateOf(cycle.rescheduleReason ?: "") }

    val formattedSelectedDate = remember(selectedDateMillis) {
        val sdf = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())
        sdf.format(Date(selectedDateMillis))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(imageVector = Icons.Default.EditCalendar, contentDescription = null, tint = IndigoPrimary)
                Text("Reschedule Round #${cycle.cycleNumber}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Specify the revised auction date and time window. All members will see the updated schedule on their Home page.",
                    fontSize = 12.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Date Picker trigger
                OutlinedButton(
                    onClick = {
                        val cal = Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
                        DatePickerDialog(
                            context,
                            { _, year, month, dayOfMonth ->
                                val newCal = Calendar.getInstance().apply {
                                    set(Calendar.YEAR, year)
                                    set(Calendar.MONTH, month)
                                    set(Calendar.DAY_OF_MONTH, dayOfMonth)
                                    set(Calendar.HOUR_OF_DAY, 20)
                                    set(Calendar.MINUTE, 0)
                                    set(Calendar.SECOND, 0)
                                    set(Calendar.MILLISECOND, 0)
                                }
                                selectedDateMillis = newCal.timeInMillis
                            },
                            cal.get(Calendar.YEAR),
                            cal.get(Calendar.MONTH),
                            cal.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Date: $formattedSelectedDate", fontSize = 12.5.sp)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Start Time Picker
                    OutlinedButton(
                        onClick = {
                            val cal = Calendar.getInstance()
                            TimePickerDialog(
                                context,
                                { _, hourOfDay, minute ->
                                    val isPm = hourOfDay >= 12
                                    val h = if (hourOfDay % 12 == 0) 12 else hourOfDay % 12
                                    val ampm = if (isPm) "PM" else "AM"
                                    startTime = String.format(Locale.US, "%02d:%02d %s", h, minute, ampm)
                                },
                                20,
                                0,
                                false
                            ).show()
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(text = "Start: $startTime", fontSize = 11.5.sp)
                    }

                    // End Time Picker
                    OutlinedButton(
                        onClick = {
                            val cal = Calendar.getInstance()
                            TimePickerDialog(
                                context,
                                { _, hourOfDay, minute ->
                                    val isPm = hourOfDay >= 12
                                    val h = if (hourOfDay % 12 == 0) 12 else hourOfDay % 12
                                    val ampm = if (isPm) "PM" else "AM"
                                    endTime = String.format(Locale.US, "%02d:%02d %s", h, minute, ampm)
                                },
                                20,
                                15,
                                false
                            ).show()
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(text = "End: $endTime", fontSize = 11.5.sp)
                    }
                }

                OutlinedTextField(
                    value = reasonText,
                    onValueChange = { reasonText = it },
                    label = { Text("Reason for Rescheduling (Optional)") },
                    placeholder = { Text("e.g., Festival holiday or bank closure") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = false,
                    maxLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirmReschedule(selectedDateMillis, startTime, endTime, reasonText)
                },
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
            ) {
                Text("Confirm Reschedule")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
