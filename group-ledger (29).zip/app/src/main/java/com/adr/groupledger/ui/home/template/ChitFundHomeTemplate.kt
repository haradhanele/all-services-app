package com.adr.groupledger.ui.home.template

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.adr.groupledger.data.model.ChitFundConfig
import com.adr.groupledger.ui.components.HomeNotificationCarousel
import com.adr.groupledger.ui.components.SamitiPullToRefreshBox
import com.adr.groupledger.ui.home.HomeTemplateContext
import com.adr.groupledger.ui.home.components.ChitFundAuctionCard
import com.adr.groupledger.ui.home.components.ChitFundConfigDialog
import com.adr.groupledger.ui.home.components.ChitFundHeroCard
import com.adr.groupledger.ui.home.components.ChitFundHistoryCard
import com.adr.groupledger.ui.home.components.ChitFundInstallmentCard
import com.adr.groupledger.ui.home.components.ChitFundMemberStatusCard
import com.adr.groupledger.ui.home.components.ChitFundPersonalStatusCard
import com.adr.groupledger.ui.home.components.HomeActionCarouselCard
import com.adr.groupledger.ui.home.components.HomeAnnouncementsCarousel
import com.adr.groupledger.ui.home.components.HomeHeaderBanner
import com.adr.groupledger.utils.ChitCalculationEngine

/**
 * Level 1: Sub-category specialized template for Chit Fund / BC.
 *
 * Fully integrated with real group settings, membership roster,
 * monthly installment summaries, and configured auction cycles.
 * Never depends on permanently hard-coded demo values.
 */
object ChitFundHomeTemplate : GroupHomeTemplate {

    override val templateId: String = "chit_fund_home"
    override val displayName: String = "Chit Fund Home Template"

    @Composable
    override fun Render(context: HomeTemplateContext) {
        val curr = context.settings.currencySymbol
        var showConfigDialog by remember { mutableStateOf(false) }

        // 1. Resolve Chit Fund Configuration from Settings JSON & fallback fields
        val chitConfig = remember(context.settings.modulesConfigJson, context.settings.defaultContribution, context.settings.dueDayOfMonth) {
            ChitFundConfig.parseFromSettings(context.settings)
        }

        // 2. Derive Real Member Counts (from MonthlySummary or Financials or ActiveMembers)
        val totalMembers = context.monthSummary?.totalMembers
            ?: context.totalActiveMembersCount.takeIf { it > 0 }
            ?: context.financials.activeMembers.takeIf { it > 0 }
            ?: context.financials.totalMembers

        val paidMembers = context.monthSummary?.paidCount ?: context.financials.currentMonthPaidCount
        val partialMembers = context.monthSummary?.partialCount ?: context.financials.currentMonthPartialCount
        val pendingMembers = context.monthSummary?.unpaidCount ?: context.financials.currentMonthUnpaidCount

        // 3. Resolve Financial Metrics & Cycle Progress from Calculation Engine
        val monthlyInstallment = chitConfig.monthlyInstallment
            ?: context.settings.defaultContribution.takeIf { it > 0.0 }

        val totalMembersCalculated = chitConfig.totalMembers
            ?: totalMembers.takeIf { it > 0 }
            ?: chitConfig.totalChits
            ?: 0

        val totalChits = chitConfig.totalChits
            ?: if (totalMembersCalculated > 0) totalMembersCalculated else null

        val currentChitNo = chitConfig.currentChitNo
            ?: if (totalChits != null) 1 else null

        val cycleMetrics = remember(chitConfig.cycles, totalChits, currentChitNo) {
            ChitCalculationEngine.deriveCycleMetrics(
                cycles = chitConfig.cycles,
                configuredTotalCycles = totalChits,
                currentChitNoOverride = currentChitNo
            )
        }

        val totalValue = chitConfig.totalValue
            ?: if (totalMembersCalculated > 0 && monthlyInstallment != null && monthlyInstallment > 0) {
                totalMembersCalculated * monthlyInstallment
            } else null

        val isSetupComplete = (monthlyInstallment != null && monthlyInstallment > 0 && totalChits != null && totalChits > 0)

        // Expected vs Collected for current period
        val expectedAmount = context.monthSummary?.totalExpected
            ?: if (totalMembersCalculated > 0 && monthlyInstallment != null) {
                totalMembersCalculated * monthlyInstallment
            } else 0.0

        val collectedAmount = context.monthSummary?.totalCollected
            ?: context.financials.currentMonthCollected

        // 4. Resolve Dynamic Next Auction Timestamp
        val nextAuctionEpoch = remember(chitConfig, context.settings) {
            chitConfig.resolveNextAuctionEpoch(context.settings)
        }

        val auctionScheduleText = remember(chitConfig, context.settings) {
            val day = chitConfig.auctionScheduleDay ?: context.settings.dueDayOfMonth.takeIf { it in 1..31 }
            val time = chitConfig.auctionTime?.ifBlank { "08:00 PM" } ?: "08:00 PM"
            if (day != null) {
                "${day}th of month, $time"
            } else {
                null
            }
        }

        SamitiPullToRefreshBox(
            isRefreshing = context.isRefreshing,
            onRefresh = { context.viewModel.refreshDashboard() },
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                state = context.listState,
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("chit_fund_dashboard"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 1. Unified Signature Group Header
                item {
                    HomeHeaderBanner(
                        context = context,
                        onOpenCategorySelector = {
                            context.onCategoryChangeRequest?.invoke(context.category, context.subCategory)
                        }
                    )
                }

                // 2. Chit Scheme Hero Card (Real Progress & Scheme Metrics)
                item {
                    ChitFundHeroCard(
                        groupName = context.settings.groupName,
                        groupSubtitle = context.settings.groupSubtitle,
                        currentChitNo = cycleMetrics.currentCycleNumber,
                        totalChits = cycleMetrics.totalCycles.takeIf { it > 0 } ?: totalChits,
                        totalValue = totalValue,
                        monthlyInstallment = monthlyInstallment,
                        totalMembers = totalMembersCalculated,
                        frequency = chitConfig.frequency.ifBlank { "MONTHLY" },
                        completedCyclesCount = cycleMetrics.completedCycles,
                        remainingCyclesCount = cycleMetrics.remainingCycles,
                        progressPercentage = cycleMetrics.progressPercent,
                        currencySymbol = curr,
                        isSetupComplete = isSetupComplete,
                        onConfigureClick = if (context.isAdminUnlocked) { { showConfigDialog = true } } else null
                    )
                }

                // 3. Next Auction Card (Dynamic Countdown, Auction States & Bidding)
                item {
                    ChitFundAuctionCard(
                        currentChitNo = cycleMetrics.currentCycleNumber,
                        nextAuctionTimestamp = nextAuctionEpoch,
                        auctionDate = auctionScheduleText,
                        auctionDurationMinutes = chitConfig.auctionDurationMinutes ?: 15,
                        explicitState = chitConfig.auctionState,
                        totalChitValue = totalValue,
                        totalMembers = totalMembersCalculated,
                        currencySymbol = curr,
                        onNavigateToAuctionRoom = {
                            context.onNavigateToAuctionDetails?.invoke(cycleMetrics.currentCycleNumber)
                                ?: context.onNavigateToInbox()
                        },
                        onConfigureAuction = if (context.isAdminUnlocked) { { showConfigDialog = true } } else null
                    )
                }

                // 4. Your Personal Member Participation Status
                item {
                    ChitFundPersonalStatusCard(
                        currentUserMember = context.currentUserMember,
                        currentUserMonthlyStatus = context.currentUserMonthlyStatus,
                        defaultInstallment = monthlyInstallment ?: context.settings.defaultContribution,
                        currencySymbol = curr,
                        onRecordPayment = { context.onNavigateToRecordPayment() }
                    )
                }

                // 5. Current Installment Collection Status (Expected vs Collected vs Pending)
                item {
                    ChitFundInstallmentCard(
                        expectedAmount = expectedAmount,
                        collectedAmount = collectedAmount,
                        currencySymbol = curr,
                        onNavigateToRecordPayment = { context.onNavigateToRecordPayment() }
                    )
                }

                // 6. Member Status Breakdown (Paid / Partial / Pending)
                item {
                    ChitFundMemberStatusCard(
                        totalMembers = totalMembersCalculated,
                        paidMembers = paidMembers,
                        partialMembers = partialMembers,
                        pendingMembers = pendingMembers,
                        onNavigateToMembers = { context.onNavigateToMembers() }
                    )
                }

                // 7. System Alerts / Notifications (if any active)
                if (context.notifications.isNotEmpty()) {
                    item {
                        HomeNotificationCarousel(notifications = context.notifications)
                    }
                }

                // 8. Chit Services & Actions Carousel
                item {
                    HomeActionCarouselCard(
                        context = context,
                        title = "Chit Actions & Tools",
                        subtitle = "Auction, passbook & records"
                    )
                }

                // 9. Dynamic Home Screen Announcements / Carousel (Restored)
                item {
                    HomeAnnouncementsCarousel(context = context)
                }

                // 10. Past Auction Results & Cycles History Timeline
                item {
                    ChitFundHistoryCard(
                        cycles = chitConfig.cycles,
                        currencySymbol = curr,
                        onCycleClick = { cycleNo ->
                            context.onNavigateToAuctionDetails?.invoke(cycleNo)
                                ?: context.onNavigateToInbox()
                        },
                        onNavigateToPassbook = {
                            context.onNavigateToAuctionDetails?.invoke(cycleMetrics.currentCycleNumber)
                                ?: context.onNavigateToInbox()
                        }
                    )
                }
            }
        }

        // Admin Chit Scheme Configuration Dialog
        if (showConfigDialog) {
            ChitFundConfigDialog(
                currentConfig = chitConfig,
                currencySymbol = curr,
                onDismiss = { showConfigDialog = false },
                onSave = { updatedConfig ->
                    val updatedSettings = ChitFundConfig.encodeIntoSettings(context.settings, updatedConfig)
                    context.viewModel.updateGroupSettings(updatedSettings)
                    showConfigDialog = false
                }
            )
        }
    }
}
