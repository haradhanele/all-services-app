package com.adr.groupledger.ui.home

import android.util.Log
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.HomeModuleConfig
import com.adr.groupledger.ui.screens.demo.GroupCategory
import org.json.JSONArray
import org.json.JSONObject

/**
 * Resolver responsible for determining the active [GroupCategory] and [subCategory]
 * for a given [GroupSettings] instance, with multi-level fallback safety.
 */
object HomeTemplateResolver {

    private const val TAG = "HomeTemplateResolver"

    /**
     * Resolves the (Category, SubCategory) pair from [GroupSettings].
     * Never throws; always returns a valid fallback.
     */
    fun resolve(settings: GroupSettings?): Pair<GroupCategory, String> {
        if (settings == null) {
            return Pair(GroupCategory.COMMUNITY_FUND, "Monthly Community Collection")
        }

        // 1. Try parsing from modulesConfigJson if stored as structured metadata
        val jsonMeta = parseFromModulesJson(settings.modulesConfigJson)
        if (jsonMeta != null) {
            val matchedCategory = GroupCategory.entries.find {
                it.id.equals(jsonMeta.first, ignoreCase = true) ||
                it.title.equals(jsonMeta.first, ignoreCase = true)
            }
            if (matchedCategory != null) {
                val candidateSub = jsonMeta.second.trim()
                val validatedSub = if (candidateSub.isNotBlank() && matchedCategory.subCategories.any { it.equals(candidateSub, ignoreCase = true) }) {
                    matchedCategory.subCategories.first { it.equals(candidateSub, ignoreCase = true) }
                } else if (candidateSub.isNotBlank() && matchedCategory.subCategories.any { it.contains(candidateSub, ignoreCase = true) || candidateSub.contains(it, ignoreCase = true) }) {
                    matchedCategory.subCategories.first { it.contains(candidateSub, ignoreCase = true) || candidateSub.contains(it, ignoreCase = true) }
                } else {
                    matchedCategory.subCategories.firstOrNull() ?: "General"
                }
                return Pair(matchedCategory, validatedSub)
            }
        }

        // 2. Try matching from groupType
        val groupType = settings.groupType.trim()
        val fromGroupType = matchCategoryFromString(groupType)
        if (fromGroupType != null) {
            val sub = matchSubCategoryFromString(fromGroupType, settings.groupSubtitle, groupType)
            return Pair(fromGroupType, sub)
        }

        // 3. Try matching from groupSubtitle or groupName
        val fromSubtitle = matchCategoryFromString(settings.groupSubtitle)
        if (fromSubtitle != null) {
            val sub = matchSubCategoryFromString(fromSubtitle, settings.groupSubtitle, settings.groupName)
            return Pair(fromSubtitle, sub)
        }

        // 4. Default Level 3 Fallback
        Log.d(TAG, "No category matched for groupType '${settings.groupType}'. Using default Community Fund.")
        return Pair(GroupCategory.COMMUNITY_FUND, "Monthly Community Collection")
    }

    private fun parseFromModulesJson(jsonStr: String): Pair<String, String>? {
        if (jsonStr.isBlank() || !jsonStr.trim().startsWith("{")) return null
        return try {
            val obj = JSONObject(jsonStr)
            val cat = obj.optString("category", "")
            val sub = obj.optString("subCategory", "")
            if (cat.isNotBlank()) Pair(cat, sub) else null
        } catch (e: Exception) {
            null
        }
    }

    private fun matchCategoryFromString(text: String): GroupCategory? {
        if (text.isBlank()) return null
        val lower = text.lowercase()

        return when {
            // Chit Fund / Savings & Credit
            lower.contains("chit fund") || lower.contains("chit") || lower.contains("shg") ||
            lower.contains("self-help") || lower.contains("credit") || lower.contains("rotating") ->
                GroupCategory.SAVINGS_CREDIT_CHIT

            // Puja / Festival
            lower.contains("puja") || lower.contains("festival") || lower.contains("chanda") ||
            lower.contains("pandal") || lower.contains("navratri") || lower.contains("durga") ||
            lower.contains("ganesh") || lower.contains("temple") || lower.contains("utsav") ->
                GroupCategory.PUJA_FESTIVAL

            // Sports & Cultural
            lower.contains("sports") || lower.contains("cultural") || lower.contains("club") ||
            lower.contains("cricket") || lower.contains("football") || lower.contains("tournament") ->
                GroupCategory.SPORTS_CULTURAL

            // Events, Trips & Mess
            lower.contains("trip") || lower.contains("tour") || lower.contains("travel") ||
            lower.contains("mess") || lower.contains("picnic") || lower.contains("outing") ||
            lower.contains("wedding") || lower.contains("reunion") ->
                GroupCategory.EVENTS_TRIPS

            // Family & Friends
            lower.contains("family") || lower.contains("friends") || lower.contains("shared pool") ||
            lower.contains("flatmates") || lower.contains("roommates") ->
                GroupCategory.FAMILY_FRIENDS

            // Welfare & NGO
            lower.contains("welfare") || lower.contains("ngo") || lower.contains("charity") ||
            lower.contains("relief") || lower.contains("donation") || lower.contains("foundation") ->
                GroupCategory.WELFARE_NGO

            // Housing & Apartment
            lower.contains("housing") || lower.contains("apartment") || lower.contains("flat") ||
            lower.contains("residents") || lower.contains("society") && lower.contains("maintenance") ->
                GroupCategory.HOUSING_APARTMENT

            // Business & Partnership
            lower.contains("business") || lower.contains("partnership") || lower.contains("venture") ||
            lower.contains("equity") || lower.contains("partner") || lower.contains("enterprise") ->
                GroupCategory.BUSINESS_PARTNERSHIP

            // Community Fund
            lower.contains("community fund") || lower.contains("community") || lower.contains("samiti") ||
            lower.contains("society") ->
                GroupCategory.COMMUNITY_FUND

            else -> null
        }
    }

    private fun matchSubCategoryFromString(category: GroupCategory, vararg candidates: String): String {
        for (cand in candidates) {
            if (cand.isBlank()) continue
            val lower = cand.lowercase()
            for (sub in category.subCategories) {
                if (lower.contains(sub.lowercase())) {
                    return sub
                }
            }
        }

        // Specific defaults based on category heuristics
        if (category == GroupCategory.SAVINGS_CREDIT_CHIT) {
            val combined = candidates.joinToString(" ").lowercase()
            if (combined.contains("chit")) return "Chit Fund / BC"
            if (combined.contains("shg") || combined.contains("self-help")) return "Self-Help Group (SHG)"
        }

        return category.subCategories.firstOrNull() ?: "General"
    }

    /**
     * Encodes the category and subCategory into the [GroupSettings.modulesConfigJson]
     * without altering any database tables or existing Room schema.
     */
    fun encodeCategoryIntoSettings(
        settings: GroupSettings,
        category: GroupCategory,
        subCategory: String
    ): GroupSettings {
        val existingModules = HomeModuleConfig.parseModulesJson(settings.modulesConfigJson)

        val jsonObject = try {
            if (settings.modulesConfigJson.trim().startsWith("{")) {
                JSONObject(settings.modulesConfigJson)
            } else {
                JSONObject()
            }
        } catch (e: Exception) {
            JSONObject()
        }

        val validatedSub = if (category.subCategories.any { it.equals(subCategory, ignoreCase = true) }) {
            category.subCategories.first { it.equals(subCategory, ignoreCase = true) }
        } else if (category.subCategories.any { it.contains(subCategory, ignoreCase = true) || subCategory.contains(it, ignoreCase = true) }) {
            category.subCategories.first { it.contains(subCategory, ignoreCase = true) || subCategory.contains(it, ignoreCase = true) }
        } else {
            category.subCategories.firstOrNull() ?: "General"
        }

        jsonObject.put("category", category.id)
        jsonObject.put("subCategory", validatedSub)

        val modulesArray = JSONArray()
        existingModules.forEach { modulesArray.put(it.toJson()) }
        jsonObject.put("modules", modulesArray)

        return settings.copy(
            modulesConfigJson = jsonObject.toString(),
            groupType = category.title
        )
    }
}
