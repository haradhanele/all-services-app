package com.adr.groupledger.data.model

import org.json.JSONObject
import java.util.Calendar

/**
 * Model representing configuration data for a Chit Fund / Rotating Savings group.
 * Stored within [GroupSettings.modulesConfigJson] as a structured nested object "chitConfig",
 * preserving full backward compatibility with Room and Firestore without schema migrations.
 */
data class ChitFundConfig(
    val totalChits: Int? = null,
    val currentChitNo: Int? = null,
    val totalValue: Double? = null,
    val monthlyInstallment: Double? = null,
    val auctionScheduleDay: Int? = null,
    val auctionTime: String? = null,
    val auctionTimestamp: Long? = null,
    val auctionDurationMinutes: Int = 60,
    val auctionState: String? = null,
    val startDateMillis: Long? = null,
    val frequency: String = "MONTHLY", // "MONTHLY", "WEEKLY", "DAILY"
    val totalMembers: Int? = null,
    val cycles: List<ChitCycle> = emptyList(),
    val minEligibilityInstallments: Int = 1
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            totalChits?.let { put("totalChits", it) }
            currentChitNo?.let { put("currentChitNo", it) }
            totalValue?.let { put("totalValue", it) }
            monthlyInstallment?.let { put("monthlyInstallment", it) }
            auctionScheduleDay?.let { put("auctionScheduleDay", it) }
            auctionTime?.let { put("auctionTime", it) }
            auctionTimestamp?.let { put("auctionTimestamp", it) }
            put("auctionDurationMinutes", auctionDurationMinutes)
            auctionState?.let { put("auctionState", it) }
            startDateMillis?.let { put("startDateMillis", it) }
            put("frequency", frequency)
            totalMembers?.let { put("totalMembers", it) }
            put("minEligibilityInstallments", minEligibilityInstallments)
            if (cycles.isNotEmpty()) {
                put("cycles", ChitCycle.serializeList(cycles))
            }
        }
    }

    /**
     * Resolves the next auction timestamp:
     * 1. Returns [auctionTimestamp] if explicitly configured.
     * 2. Checks active/next cycle's auction start epoch if configured.
     * 3. Otherwise calculates from [auctionScheduleDay] (or [settings.dueDayOfMonth])
     *    and [auctionTime] for the current or upcoming month.
     */
    fun resolveNextAuctionEpoch(settings: GroupSettings): Long? {
        if (auctionTimestamp != null && auctionTimestamp > 0L) {
            return auctionTimestamp
        }

        val activeCycle = cycles.firstOrNull {
            it.status in listOf(
                ChitCycleStatus.AUCTION_SCHEDULED,
                ChitCycleStatus.AUCTION_OPEN,
                ChitCycleStatus.AUCTION_CLOSED,
                ChitCycleStatus.RESULT_PENDING,
                ChitCycleStatus.RESCHEDULED
            )
        } ?: cycles.firstOrNull { !it.status.isTerminal() }

        if (activeCycle != null) {
            val epoch = activeCycle.resolveAuctionStartEpoch()
            if (epoch > 0L) return epoch
        }

        val targetDay = auctionScheduleDay ?: settings.dueDayOfMonth.takeIf { it in 1..31 } ?: return null

        val now = Calendar.getInstance()
        val scheduledCal = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, targetDay.coerceAtMost(getActualMaximum(Calendar.DAY_OF_MONTH)))
            set(Calendar.HOUR_OF_DAY, 20) // 8:00 PM default
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        // If today has already passed this month's auction time, schedule for next month
        if (scheduledCal.timeInMillis <= now.timeInMillis) {
            scheduledCal.add(Calendar.MONTH, 1)
            scheduledCal.set(
                Calendar.DAY_OF_MONTH,
                targetDay.coerceAtMost(scheduledCal.getActualMaximum(Calendar.DAY_OF_MONTH))
            )
        }

        return scheduledCal.timeInMillis
    }

    companion object {
        fun parseFromSettings(settings: GroupSettings): ChitFundConfig {
            val fallbackInstallment = if (settings.defaultContribution > 0) settings.defaultContribution else null
            val fallbackDay = if (settings.dueDayOfMonth in 1..31) settings.dueDayOfMonth else null
            val fallbackFrequency = settings.contributionFrequency.ifBlank { "MONTHLY" }

            if (settings.modulesConfigJson.isBlank() || !settings.modulesConfigJson.trim().startsWith("{")) {
                return ChitFundConfig(
                    monthlyInstallment = fallbackInstallment,
                    auctionScheduleDay = fallbackDay,
                    frequency = fallbackFrequency
                )
            }

            return try {
                val root = JSONObject(settings.modulesConfigJson)
                val chitObj = root.optJSONObject("chitConfig")
                if (chitObj != null) {
                    val parsedCycles = ChitCycle.parseArray(chitObj.optJSONArray("cycles"))
                    ChitFundConfig(
                        totalChits = if (chitObj.has("totalChits")) chitObj.optInt("totalChits").takeIf { it > 0 } else null,
                        currentChitNo = if (chitObj.has("currentChitNo")) chitObj.optInt("currentChitNo").takeIf { it > 0 } else null,
                        totalValue = if (chitObj.has("totalValue")) chitObj.optDouble("totalValue").takeIf { it > 0 } else null,
                        monthlyInstallment = if (chitObj.has("monthlyInstallment")) {
                            chitObj.optDouble("monthlyInstallment").takeIf { it > 0 }
                        } else fallbackInstallment,
                        auctionScheduleDay = if (chitObj.has("auctionScheduleDay")) {
                            chitObj.optInt("auctionScheduleDay").takeIf { it in 1..31 }
                        } else fallbackDay,
                        auctionTime = chitObj.optString("auctionTime", "08:00 PM").takeIf { it.isNotBlank() },
                        auctionTimestamp = if (chitObj.has("auctionTimestamp")) chitObj.optLong("auctionTimestamp").takeIf { it > 0 } else null,
                        auctionDurationMinutes = chitObj.optInt("auctionDurationMinutes", 60),
                        auctionState = chitObj.optString("auctionState", "").takeIf { it.isNotBlank() },
                        startDateMillis = if (chitObj.has("startDateMillis")) chitObj.optLong("startDateMillis").takeIf { it > 0 } else null,
                        frequency = chitObj.optString("frequency", fallbackFrequency),
                        totalMembers = if (chitObj.has("totalMembers")) chitObj.optInt("totalMembers").takeIf { it > 0 } else null,
                        cycles = parsedCycles,
                        minEligibilityInstallments = chitObj.optInt("minEligibilityInstallments", 1)
                    )
                } else {
                    ChitFundConfig(
                        monthlyInstallment = fallbackInstallment,
                        auctionScheduleDay = fallbackDay,
                        frequency = fallbackFrequency
                    )
                }
            } catch (e: Exception) {
                ChitFundConfig(
                    monthlyInstallment = fallbackInstallment,
                    auctionScheduleDay = fallbackDay,
                    frequency = fallbackFrequency
                )
            }
        }

        fun encodeIntoSettings(settings: GroupSettings, chitConfig: ChitFundConfig): GroupSettings {
            val root = try {
                if (settings.modulesConfigJson.trim().startsWith("{")) {
                    JSONObject(settings.modulesConfigJson)
                } else {
                    JSONObject()
                }
            } catch (e: Exception) {
                JSONObject()
            }

            root.put("chitConfig", chitConfig.toJson())

            return settings.copy(
                modulesConfigJson = root.toString(),
                defaultContribution = chitConfig.monthlyInstallment ?: settings.defaultContribution,
                contributionFrequency = chitConfig.frequency.ifBlank { settings.contributionFrequency }
            )
        }
    }
}
