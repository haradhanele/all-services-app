package com.adr.groupledger.ui.home.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adr.groupledger.data.model.ChitCycle
import com.adr.groupledger.data.model.ChitCycleStatus
import com.adr.groupledger.data.model.ChitFundConfig
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.MemberWithMonthlyStatus
import com.adr.groupledger.utils.ChitCalculationEngine
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.BorderLight
import com.adr.groupledger.ui.theme.BorderSubtle
import com.adr.groupledger.ui.theme.CardWhite
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoHeroProgress
import com.adr.groupledger.ui.theme.IndigoHeroTrack
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.StatusPaidText
import com.adr.groupledger.ui.theme.StatusPartialText
import com.adr.groupledger.ui.theme.StatusUnpaidText
import com.adr.groupledger.ui.theme.TextSlate400
import com.adr.groupledger.ui.theme.TextSlate500
import com.adr.groupledger.ui.theme.TextSlate800
import com.adr.groupledger.utils.CurrencyFormatter
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 7 Supported Chit Fund Auction States + NOT_SCHEDULED
 */
enum class ChitAuctionState(val label: String, val color: Color) {
    UPCOMING("Upcoming Auction", Color(0xFF6366F1)),
    OPEN("Live Auction Open", Color(0xFF10B981)),
    CLOSED("Bid Submission Closed", Color(0xFF64748B)),
    REVIEW("Result Processing", Color(0xFFF59E0B)),
    PUBLISHED("Result Published", Color(0xFF8B5CF6)),
    COMPLETED("Round Completed", Color(0xFF059669)),
    RESCHEDULED("Rescheduled", Color(0xFFEF4444)),
    NOT_SCHEDULED("Auction Not Scheduled", Color(0xFF94A3B8))
}

/**
 * Specialized Chit Fund Hero Card with Dynamic Circular Scheme Progress.
 * Completely driven by real group settings and configuration.
 * Adapts gracefully when values are unconfigured without showing fake zeros.
 */
@Composable
fun ChitFundHeroCard(
    groupName: String = "",
    groupSubtitle: String = "",
    currentChitNo: Int? = null,
    totalChits: Int? = null,
    totalValue: Double? = null,
    monthlyInstallment: Double? = null,
    totalMembers: Int = 0,
    frequency: String = "MONTHLY",
    completedCyclesCount: Int = 0,
    remainingCyclesCount: Int = 0,
    progressPercentage: Int = 0,
    currencySymbol: String = "₹",
    isSetupComplete: Boolean = true,
    onConfigureClick: (() -> Unit)? = null
) {
    val isCycleConfigured = totalChits != null && totalChits > 0 && currentChitNo != null && currentChitNo > 0
    val progressFraction = (progressPercentage / 100f).coerceIn(0f, 1f)

    val calculatedTotalValue = totalValue
        ?: if (totalMembers > 0 && monthlyInstallment != null && monthlyInstallment > 0) {
            totalMembers * monthlyInstallment
        } else null

    val frequencyLabel = when (frequency.uppercase().trim()) {
        "WEEKLY" -> "Weekly Chit"
        "DAILY" -> "Daily Chit"
        else -> "Monthly Chit"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("chit_hero_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Scheme Category, Cycle label, and Members Pool badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = if (groupName.isNotBlank()) groupName.uppercase() else "ACTIVE CHIT SCHEME",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = IndigoPrimary,
                            fontSize = 10.sp,
                            letterSpacing = 0.5.sp,
                            maxLines = 1
                        )
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = IndigoPrimary.copy(alpha = 0.10f)
                        ) {
                            Text(
                                text = frequencyLabel,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = IndigoPrimary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = if (isCycleConfigured) "Chit #$currentChitNo of $totalChits"
                        else if (currentChitNo != null && currentChitNo > 0) "Chit #$currentChitNo"
                        else "Chit cycle not configured",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 17.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = IndigoPrimary.copy(alpha = 0.10f),
                        modifier = Modifier.padding(start = 4.dp)
                    ) {
                        Text(
                            text = if (totalMembers > 0) "$totalMembers Members Pool" else "— Members Pool",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = IndigoPrimary,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                            fontSize = 11.sp
                        )
                    }

                    if (onConfigureClick != null) {
                        IconButton(
                            onClick = onConfigureClick,
                            modifier = Modifier
                                .size(28.dp)
                                .padding(start = 4.dp)
                                .testTag("chit_configure_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Configure Scheme",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // Incomplete Setup Banner if essential fields are missing
            if (!isSetupComplete) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Amber500.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, Amber500.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = Amber500,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "Chit Fund setup incomplete. Configure contribution & rounds.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        if (onConfigureClick != null) {
                            TextButton(
                                onClick = onConfigureClick,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("Complete Setup", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Middle Section: Circular Progress + Metrics
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Circular Progress Indicator
                Box(
                    modifier = Modifier.size(76.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        progress = { progressFraction },
                        modifier = Modifier.fillMaxWidth(),
                        color = if (isCycleConfigured) IndigoPrimary else MaterialTheme.colorScheme.outlineVariant,
                        trackColor = IndigoHeroTrack,
                        strokeWidth = 6.5.dp
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (isCycleConfigured) "$progressPercentage%" else "—%",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isCycleConfigured) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = if (isCycleConfigured) "COMPLETED" else "SCHEME",
                            fontSize = 7.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Scheme Breakdown Numbers
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total Chit Value", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = if (calculatedTotalValue != null && calculatedTotalValue > 0) {
                                "$currencySymbol${CurrencyFormatter.formatIndian(calculatedTotalValue)}"
                            } else "—",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Installment Amount", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = if (monthlyInstallment != null && monthlyInstallment > 0) {
                                "$currencySymbol${CurrencyFormatter.formatIndian(monthlyInstallment)}"
                            } else "Not configured",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (monthlyInstallment != null && monthlyInstallment > 0) IndigoPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Rounds Completed", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = if (isCycleConfigured) {
                                "$completedCyclesCount done ($remainingCyclesCount remain)"
                            } else "Cycle not configured",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isCycleConfigured) Emerald500 else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

/**
 * Next Auction Card with Live Countdown and dynamic states.
 * Fully connects to real auction schedules, timestamps, and durations.
 */
@Composable
fun ChitFundAuctionCard(
    currentChitNo: Int? = null,
    nextAuctionTimestamp: Long? = null,
    auctionDate: String? = null,
    auctionDurationMinutes: Int = 60,
    explicitState: String? = null,
    totalChitValue: Double? = null,
    totalMembers: Int = 0,
    currencySymbol: String = "₹",
    onNavigateToAuctionRoom: () -> Unit = {},
    onConfigureAuction: (() -> Unit)? = null
) {
    val now = System.currentTimeMillis()

    // Dynamically resolve auction state
    val defaultState = remember(nextAuctionTimestamp, explicitState, now) {
        if (!explicitState.isNullOrBlank()) {
            when (explicitState.uppercase().trim()) {
                "UPCOMING" -> ChitAuctionState.UPCOMING
                "OPEN", "AUCTION OPEN", "LIVE" -> ChitAuctionState.OPEN
                "CLOSED", "BID SUBMISSION CLOSED" -> ChitAuctionState.CLOSED
                "REVIEW", "RESULT PROCESSING", "PROCESSING" -> ChitAuctionState.REVIEW
                "PUBLISHED", "RESULT PUBLISHED" -> ChitAuctionState.PUBLISHED
                "COMPLETED", "ROUND COMPLETED" -> ChitAuctionState.COMPLETED
                "RESCHEDULED" -> ChitAuctionState.RESCHEDULED
                else -> ChitAuctionState.NOT_SCHEDULED
            }
        } else if (nextAuctionTimestamp == null || nextAuctionTimestamp <= 0L) {
            ChitAuctionState.NOT_SCHEDULED
        } else {
            val durationMillis = auctionDurationMinutes * 60 * 1000L
            val endMillis = nextAuctionTimestamp + durationMillis
            when {
                now < nextAuctionTimestamp -> ChitAuctionState.UPCOMING
                now in nextAuctionTimestamp..endMillis -> ChitAuctionState.OPEN
                now > endMillis -> ChitAuctionState.CLOSED
                else -> ChitAuctionState.UPCOMING
            }
        }
    }

    var auctionState by remember(defaultState) { mutableStateOf(defaultState) }
    var showBidModal by remember { mutableStateOf(false) }
    var bidDiscountAmount by remember { mutableStateOf("120000") }
    var bidSuccessMessage by remember { mutableStateOf<String?>(null) }

    // Dynamic Live Ticking Countdown based on real timestamp
    var secondsRemaining by remember(nextAuctionTimestamp) {
        val initialDiff = if (nextAuctionTimestamp != null && nextAuctionTimestamp > System.currentTimeMillis()) {
            (nextAuctionTimestamp - System.currentTimeMillis()) / 1000L
        } else 0L
        mutableLongStateOf(initialDiff.coerceAtLeast(0L))
    }

    LaunchedEffect(nextAuctionTimestamp, auctionState) {
        if (auctionState == ChitAuctionState.UPCOMING && nextAuctionTimestamp != null && nextAuctionTimestamp > System.currentTimeMillis()) {
            while (true) {
                val current = System.currentTimeMillis()
                val diff = (nextAuctionTimestamp - current) / 1000L
                secondsRemaining = diff.coerceAtLeast(0L)
                if (diff <= 0L) {
                    auctionState = ChitAuctionState.OPEN
                    break
                }
                delay(1000L)
            }
        }
    }

    val days = secondsRemaining / 86400
    val hours = (secondsRemaining % 86400) / 3600
    val minutes = (secondsRemaining % 3600) / 60
    val seconds = secondsRemaining % 60

    val displayDate = remember(nextAuctionTimestamp, auctionDate) {
        if (!auctionDate.isNullOrBlank()) {
            auctionDate
        } else if (nextAuctionTimestamp != null && nextAuctionTimestamp > 0L) {
            try {
                val sdf = SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.getDefault())
                sdf.format(Date(nextAuctionTimestamp))
            } catch (e: Exception) {
                "Scheduled on calendar"
            }
        } else {
            "Auction not scheduled"
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("chit_auction_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, if (auctionState == ChitAuctionState.OPEN) Emerald500 else MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Status badge + demo toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(
                        imageVector = Icons.Default.Gavel,
                        contentDescription = null,
                        tint = auctionState.color,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "NEXT AUCTION",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = auctionState.color,
                        fontSize = 10.sp,
                        letterSpacing = 0.5.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = auctionState.color.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = auctionState.label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = auctionState.color,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        fontSize = 10.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (currentChitNo != null && currentChitNo > 0) "Round #$currentChitNo Auction" else "Chit Auction Round",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                fontSize = 16.sp
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = if (auctionState == ChitAuctionState.NOT_SCHEDULED) Icons.Default.EventBusy else Icons.Default.Event,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(13.dp)
                )
                Text(
                    text = displayDate,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (auctionState == ChitAuctionState.NOT_SCHEDULED) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                    fontSize = 11.5.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // State Display (Live Countdown or descriptive notification)
            when (auctionState) {
                ChitAuctionState.UPCOMING -> {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp, horizontal = 12.dp),
                            horizontalArrangement = Arrangement.SpaceAround,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CountdownUnit(value = String.format(Locale.US, "%02d", days), unit = "DAYS")
                            Text(":", fontWeight = FontWeight.Bold, color = IndigoPrimary, fontSize = 16.sp)
                            CountdownUnit(value = String.format(Locale.US, "%02d", hours), unit = "HOURS")
                            Text(":", fontWeight = FontWeight.Bold, color = IndigoPrimary, fontSize = 16.sp)
                            CountdownUnit(value = String.format(Locale.US, "%02d", minutes), unit = "MINUTES")
                            Text(":", fontWeight = FontWeight.Bold, color = IndigoPrimary, fontSize = 16.sp)
                            CountdownUnit(value = String.format(Locale.US, "%02d", seconds), unit = "SECONDS")
                        }
                    }
                }
                ChitAuctionState.OPEN -> {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Emerald500.copy(alpha = 0.10f),
                        border = BorderStroke(1.dp, Emerald500.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(Emerald500)
                            )
                            Text(
                                text = "AUCTION IS LIVE NOW! Bidding floor open for Round #${currentChitNo ?: ""}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = Emerald500,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
                ChitAuctionState.CLOSED -> {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.AccessTime, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                            Text(
                                text = "Bid Submission Closed. Bids have been locked for Round #${currentChitNo ?: ""}.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.5.sp
                            )
                        }
                    }
                }
                ChitAuctionState.REVIEW -> {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Amber500.copy(alpha = 0.10f),
                        border = BorderStroke(1.dp, Amber500.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Timer, contentDescription = null, tint = Amber500, modifier = Modifier.size(16.dp))
                            Text(
                                text = "Result Processing: Verifying submitted bid discounts and member eligibility.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Amber500,
                                fontWeight = FontWeight.Medium,
                                fontSize = 11.5.sp
                            )
                        }
                    }
                }
                ChitAuctionState.PUBLISHED -> {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFF8B5CF6).copy(alpha = 0.10f),
                        border = BorderStroke(1.dp, Color(0xFF8B5CF6).copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF8B5CF6), modifier = Modifier.size(16.dp))
                            Text(
                                text = "Result Published! The winning bidder for Round #${currentChitNo ?: ""} has been announced.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF8B5CF6),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.5.sp
                            )
                        }
                    }
                }
                ChitAuctionState.COMPLETED -> {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Emerald500.copy(alpha = 0.08f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Emerald500, modifier = Modifier.size(16.dp))
                            Text(
                                text = "Round Completed. Dividend distribution and ledger entries finalized.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Emerald500,
                                fontSize = 11.5.sp
                            )
                        }
                    }
                }
                ChitAuctionState.RESCHEDULED -> {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Rose500.copy(alpha = 0.10f),
                        border = BorderStroke(1.dp, Rose500.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = Rose500, modifier = Modifier.size(16.dp))
                            Text(
                                text = "Auction Rescheduled: Meeting deferred by administrator.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Rose500,
                                fontSize = 11.5.sp
                            )
                        }
                    }
                }
                ChitAuctionState.NOT_SCHEDULED -> {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.EventBusy, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                            Text(
                                text = "Next auction has not been scheduled. Group admins can configure the auction date in scheme settings.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.5.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (auctionState == ChitAuctionState.OPEN) {
                    Button(
                        onClick = onNavigateToAuctionRoom,
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald500),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("enter_auction_button")
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Enter Live Auction", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                } else if (auctionState == ChitAuctionState.NOT_SCHEDULED) {
                    if (onConfigureAuction != null) {
                        Button(
                            onClick = onConfigureAuction,
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("schedule_auction_button")
                        ) {
                            Icon(imageVector = Icons.Default.Event, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Schedule Auction", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    } else {
                        OutlinedButton(
                            onClick = onNavigateToAuctionRoom,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("view_auction_rules_button")
                        ) {
                            Text("Auction Rules & Passbook", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                } else {
                    OutlinedButton(
                        onClick = onNavigateToAuctionRoom,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, IndigoPrimary),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("view_auction_details_button")
                    ) {
                        Icon(imageVector = Icons.Default.Gavel, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("View Auction Details", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                    }
                }

                // Interactive Demo State Toggle (helps review all 7 UI states easily)
                TextButton(
                    onClick = {
                        auctionState = when (auctionState) {
                            ChitAuctionState.UPCOMING -> ChitAuctionState.OPEN
                            ChitAuctionState.OPEN -> ChitAuctionState.CLOSED
                            ChitAuctionState.CLOSED -> ChitAuctionState.REVIEW
                            ChitAuctionState.REVIEW -> ChitAuctionState.PUBLISHED
                            ChitAuctionState.PUBLISHED -> ChitAuctionState.COMPLETED
                            ChitAuctionState.COMPLETED -> ChitAuctionState.RESCHEDULED
                            ChitAuctionState.RESCHEDULED -> ChitAuctionState.NOT_SCHEDULED
                            ChitAuctionState.NOT_SCHEDULED -> ChitAuctionState.UPCOMING
                        }
                    },
                    modifier = Modifier.testTag("toggle_auction_state_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Cycle State",
                        tint = IndigoPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("State Demo", fontSize = 11.sp, color = IndigoPrimary)
                }
            }
        }
    }

    // Interactive Bid Modal Dialog
    if (showBidModal) {
        val effectiveVal = totalChitValue ?: 1000000.0
        val discount = bidDiscountAmount.toDoubleOrNull() ?: 0.0
        val netPayout = (effectiveVal - discount).coerceAtLeast(0.0)
        val memberDivisor = if (totalMembers > 0) totalMembers.toDouble() else 20.0
        val dividendPerMember = discount / memberDivisor

        AlertDialog(
            onDismissRequest = { showBidModal = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.Gavel, contentDescription = null, tint = IndigoPrimary)
                    Text("Chit Auction Bidding (Round #${currentChitNo ?: 1})", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Enter your bid discount. The member with the highest acceptable bid discount wins the chit pool.",
                        fontSize = 12.sp,
                        color = TextSlate500
                    )

                    OutlinedTextField(
                        value = bidDiscountAmount,
                        onValueChange = { bidDiscountAmount = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Your Bid Discount ($currencySymbol)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("bid_discount_input")
                    )

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFF8FAFC),
                        border = BorderStroke(0.5.dp, BorderLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Chit Value:", fontSize = 11.sp, color = TextSlate400)
                                Text("$currencySymbol${CurrencyFormatter.formatIndian(effectiveVal)}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Net Prize Payout:", fontSize = 11.sp, color = TextSlate400)
                                Text("$currencySymbol${CurrencyFormatter.formatIndian(netPayout)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Dividend / Member:", fontSize = 11.sp, color = TextSlate400)
                                Text("$currencySymbol${CurrencyFormatter.formatIndian(dividendPerMember)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                            }
                        }
                    }

                    if (bidSuccessMessage != null) {
                        Text(
                            text = bidSuccessMessage!!,
                            color = Emerald500,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        bidSuccessMessage = "Bid of $currencySymbol${CurrencyFormatter.formatIndian(discount)} submitted successfully for review!"
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                ) {
                    Text("Submit Bid", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBidModal = false }) {
                    Text("Close", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        )
    }
}

@Composable
private fun CountdownUnit(value: String, unit: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            fontSize = 16.sp
        )
        Text(
            text = unit,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 8.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

/**
 * Chit Fund Installment Status Card (Expected, Collected, Pending, Progress Bar)
 * Handles unconfigured / 0-expected amount gracefully without divide-by-zero crashes.
 */
@Composable
fun ChitFundInstallmentCard(
    expectedAmount: Double = 0.0,
    collectedAmount: Double = 0.0,
    currencySymbol: String = "₹",
    onNavigateToRecordPayment: () -> Unit = {}
) {
    val isConfigured = expectedAmount > 0.0
    val pendingAmount = if (isConfigured) (expectedAmount - collectedAmount).coerceAtLeast(0.0) else 0.0
    val progress = if (isConfigured) (collectedAmount / expectedAmount).toFloat().coerceIn(0f, 1f) else 0f

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("chit_installment_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(
                        imageVector = Icons.Default.MonetizationOn,
                        contentDescription = null,
                        tint = IndigoPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "INSTALLMENT STATUS",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        fontSize = 10.sp,
                        letterSpacing = 0.5.sp
                    )
                }

                Text(
                    text = if (isConfigured) "${(progress * 100).toInt()}% Collected" else "Not configured",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (isConfigured) Emerald500 else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = if (isConfigured) Emerald500 else MaterialTheme.colorScheme.outlineVariant,
                trackColor = IndigoHeroTrack
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("TOTAL EXPECTED", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = if (isConfigured) "$currencySymbol${CurrencyFormatter.formatIndian(expectedAmount)}" else "—",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("COLLECTED", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = "$currencySymbol${CurrencyFormatter.formatIndian(collectedAmount)}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (collectedAmount > 0) Emerald500 else MaterialTheme.colorScheme.onSurface
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("PENDING", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = if (isConfigured) "$currencySymbol${CurrencyFormatter.formatIndian(pendingAmount)}" else "—",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (pendingAmount > 0) Rose500 else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

/**
 * Chit Fund Member Status Card (Paid, Partial, Pending breakdown).
 * Driven by real member counts from MonthlySummary or overall financials.
 */
@Composable
fun ChitFundMemberStatusCard(
    totalMembers: Int = 0,
    paidMembers: Int = 0,
    partialMembers: Int = 0,
    pendingMembers: Int = 0,
    onNavigateToMembers: () -> Unit = {}
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onNavigateToMembers() }
            .testTag("chit_member_status_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Member Installment Breakdown",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 13.5.sp
                )
                Text(
                    text = if (totalMembers > 0) "View All $totalMembers" else "View Members",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = IndigoPrimary,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (totalMembers == 0) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Payment data unavailable. No active members recorded for this scheme.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(10.dp),
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = StatusPaidText.copy(alpha = 0.10f),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "$paidMembers", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = StatusPaidText)
                            Text(text = "Paid", fontSize = 10.sp, color = StatusPaidText, fontWeight = FontWeight.Medium)
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = StatusPartialText.copy(alpha = 0.10f),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "$partialMembers", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = StatusPartialText)
                            Text(text = "Partial", fontSize = 10.sp, color = StatusPartialText, fontWeight = FontWeight.Medium)
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = StatusUnpaidText.copy(alpha = 0.10f),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "$pendingMembers", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = StatusUnpaidText)
                            Text(text = "Pending", fontSize = 10.sp, color = StatusUnpaidText, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }
}

/**
 * Chit Fund Personal Status Card (Your Installment, Your Status, Auction Eligibility).
 * Bound to the logged-in user's actual group membership. Protects user privacy and displays
 * an appropriate Admin/Guest state when not linked to a member record.
 */
@Composable
fun ChitFundPersonalStatusCard(
    currentUserMember: Member? = null,
    currentUserMonthlyStatus: MemberWithMonthlyStatus? = null,
    defaultInstallment: Double = 0.0,
    currencySymbol: String = "₹",
    onRecordPayment: () -> Unit = {}
) {
    val isMemberLinked = currentUserMember != null || currentUserMonthlyStatus != null

    val effectiveInstallment = currentUserMonthlyStatus?.effectiveExpectedAmount
        ?: if (currentUserMember != null && currentUserMember.monthlyContribution > 0) currentUserMember.monthlyContribution
        else defaultInstallment

    val isPaid = currentUserMonthlyStatus?.status.equals("PAID", ignoreCase = true) == true ||
            (currentUserMonthlyStatus != null && currentUserMonthlyStatus.dueAmount <= 0.0)

    val isEligibleForAuction = isMemberLinked && isPaid

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("chit_personal_status_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = IndigoPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (currentUserMember != null) "YOUR STATUS (${currentUserMember.name})" else "YOUR PARTICIPATION STATUS",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 11.sp,
                        letterSpacing = 0.5.sp,
                        maxLines = 1
                    )
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (!isMemberLinked) Amber500.copy(alpha = 0.12f)
                    else if (isPaid) Emerald500.copy(alpha = 0.12f)
                    else Rose500.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = if (!isMemberLinked) "ADMIN / GUEST" else if (isPaid) "PAID" else "DUE",
                        color = if (!isMemberLinked) Amber500 else if (isPaid) Emerald500 else Rose500,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (!isMemberLinked) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Viewing as Administrator. You are not registered as an active bidding member in this Chit pool.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedButton(
                        onClick = onRecordPayment,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("admin_record_payment_btn")
                    ) {
                        Text("Record Payment", fontSize = 11.sp)
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("YOUR INSTALLMENT", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = if (effectiveInstallment > 0) "$currencySymbol${CurrencyFormatter.formatIndian(effectiveInstallment)}" else "Not configured",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("AUCTION ELIGIBILITY", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(
                                imageVector = if (isEligibleForAuction) Icons.Default.CheckCircle else Icons.Default.Info,
                                contentDescription = null,
                                tint = if (isEligibleForAuction) Emerald500 else Amber500,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = if (isEligibleForAuction) "Eligible to Bid" else "Payment Due to Bid",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isEligibleForAuction) Emerald500 else Amber500
                            )
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("PAYMENT STATUS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = if (isPaid) "Cleared" else "Pending Due",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isPaid) Emerald500 else Rose500
                        )
                    }
                }
            }
        }
    }
}

/**
 * Past Rounds / Auction Results History Card
 * Shows real cycle history from [ChitCycle] or informative empty state if none have completed yet.
 */
@Composable
fun ChitFundHistoryCard(
    cycles: List<ChitCycle> = emptyList(),
    currencySymbol: String = "₹",
    onCycleClick: (Int) -> Unit = {},
    onNavigateToPassbook: () -> Unit = {}
) {
    // Display recent cycles (completed, active, scheduled, rescheduled) up to 5
    val displayCycles = remember(cycles) {
        if (cycles.isEmpty()) emptyList()
        else {
            val prioritized = cycles.sortedWith(
                compareBy<ChitCycle> {
                    when (it.status) {
                        ChitCycleStatus.AUCTION_OPEN -> 0
                        ChitCycleStatus.RESULT_PENDING, ChitCycleStatus.AUCTION_CLOSED -> 1
                        ChitCycleStatus.AUCTION_SCHEDULED, ChitCycleStatus.RESCHEDULED -> 2
                        ChitCycleStatus.COMPLETED -> 3
                        else -> 4
                    }
                }.thenBy { it.cycleNumber }
            )
            prioritized.take(5)
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("chit_history_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = IndigoPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Chit Rounds & Auction Schedule",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 13.5.sp
                    )
                }
                Text(
                    text = "View Schedule",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = IndigoPrimary,
                    fontSize = 11.sp,
                    modifier = Modifier.clickable { onNavigateToPassbook() }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (displayCycles.isEmpty()) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "No cycle schedule generated yet. Configure the Chit Fund scheme to view round dates and auctions.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.5.sp
                        )
                    }
                }
            } else {
                displayCycles.forEachIndexed { index, cycle ->
                    val statusColor = when (cycle.status) {
                        ChitCycleStatus.COMPLETED -> Emerald500
                        ChitCycleStatus.AUCTION_OPEN -> Emerald500
                        ChitCycleStatus.AUCTION_CLOSED, ChitCycleStatus.RESULT_PENDING -> Amber500
                        ChitCycleStatus.RESCHEDULED -> Rose500
                        ChitCycleStatus.CANCELLED -> MaterialTheme.colorScheme.error
                        else -> IndigoPrimary
                    }
                    val statusLabel = when (cycle.status) {
                        ChitCycleStatus.COMPLETED -> "Round #${cycle.cycleNumber} (Done)"
                        ChitCycleStatus.AUCTION_OPEN -> "Round #${cycle.cycleNumber} (Live)"
                        ChitCycleStatus.AUCTION_CLOSED -> "Round #${cycle.cycleNumber} (Closed)"
                        ChitCycleStatus.RESULT_PENDING -> "Round #${cycle.cycleNumber} (Result Pending)"
                        ChitCycleStatus.RESCHEDULED -> "Round #${cycle.cycleNumber} (Rescheduled)"
                        ChitCycleStatus.AUCTION_SCHEDULED -> "Round #${cycle.cycleNumber} (Scheduled)"
                        else -> "Round #${cycle.cycleNumber}"
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onCycleClick(cycle.cycleNumber) }
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = statusColor.copy(alpha = 0.12f)
                                ) {
                                    Text(
                                        text = statusLabel,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = statusColor,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                                Text(
                                    text = if (!cycle.winnerMemberName.isNullOrBlank()) {
                                        "${cycle.winnerMemberName} • Bid: $currencySymbol${cycle.winningBidAmount?.toInt() ?: 0}"
                                    } else {
                                        "${cycle.scheduledDate} (${cycle.displayAuctionWindow})"
                                    },
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                        Text(
                            text = if (cycle.dividendPerMember != null && cycle.dividendPerMember > 0) {
                                "Div: $currencySymbol${cycle.dividendPerMember.toInt()}"
                            } else {
                                "$currencySymbol${cycle.netInstallmentAmount.toInt()}"
                            },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (index < displayCycles.size - 1) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(0.5.dp)
                                .background(MaterialTheme.colorScheme.outlineVariant)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Chit Fund Scheme Configuration Dialog for Administrators.
 * Persists directly into [GroupSettings.modulesConfigJson] under "chitConfig".
 */
@Composable
fun ChitFundConfigDialog(
    currentConfig: ChitFundConfig,
    currencySymbol: String = "₹",
    onDismiss: () -> Unit,
    onSave: (ChitFundConfig) -> Unit
) {
    var totalMembersInput by remember { mutableStateOf(currentConfig.totalMembers?.toString() ?: currentConfig.totalChits?.toString() ?: "") }
    var totalChitsInput by remember { mutableStateOf(currentConfig.totalChits?.toString() ?: "") }
    var currentChitInput by remember { mutableStateOf(currentConfig.currentChitNo?.toString() ?: "") }
    var installmentInput by remember { mutableStateOf(currentConfig.monthlyInstallment?.toInt()?.toString() ?: "") }
    var frequencyInput by remember { mutableStateOf(currentConfig.frequency.ifBlank { "MONTHLY" }) }
    var scheduleDayInput by remember { mutableStateOf(currentConfig.auctionScheduleDay?.toString() ?: "") }
    var selectedState by remember { mutableStateOf(currentConfig.auctionState ?: "UPCOMING") }

    val stateOptions = listOf("UPCOMING", "OPEN", "CLOSED", "REVIEW", "PUBLISHED", "COMPLETED", "RESCHEDULED")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(imageVector = Icons.Default.Settings, contentDescription = null, tint = IndigoPrimary)
                Text("Configure Chit Scheme", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Update the parameters for this Chit Fund scheme. Configuration changes will instantly update the Home Page.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = totalMembersInput,
                        onValueChange = { totalMembersInput = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Total Members", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("config_total_members")
                    )
                    OutlinedTextField(
                        value = totalChitsInput,
                        onValueChange = { totalChitsInput = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Total Rounds", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("config_total_chits")
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = installmentInput,
                        onValueChange = { installmentInput = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Installment ($currencySymbol)", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("config_installment")
                    )
                    OutlinedTextField(
                        value = scheduleDayInput,
                        onValueChange = { scheduleDayInput = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Auction Day (1-31)", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("config_auction_day")
                    )
                }

                Text("Auction Status Override:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(stateOptions) { state ->
                        FilterChip(
                            selected = selectedState == state,
                            onClick = { selectedState = state },
                            label = { Text(state, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = IndigoPrimary.copy(alpha = 0.15f),
                                selectedLabelColor = IndigoPrimary
                            )
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsedTotalChits = totalChitsInput.toIntOrNull()?.takeIf { it > 0 }
                    val parsedInstallment = installmentInput.toDoubleOrNull()?.takeIf { it > 0 }
                    val parsedMembers = totalMembersInput.toIntOrNull()?.takeIf { it > 0 }
                    val startMillis = currentConfig.startDateMillis ?: System.currentTimeMillis()

                    val synchedCycles = if (parsedTotalChits != null && parsedInstallment != null) {
                        ChitCalculationEngine.generateOrUpdateCycles(
                            totalCycles = parsedTotalChits,
                            installmentAmount = parsedInstallment,
                            startDateMillis = startMillis,
                            frequency = frequencyInput,
                            existingCycles = currentConfig.cycles
                        )
                    } else {
                        currentConfig.cycles
                    }

                    val updated = currentConfig.copy(
                        totalMembers = parsedMembers,
                        totalChits = parsedTotalChits,
                        currentChitNo = currentChitInput.toIntOrNull()?.takeIf { it > 0 },
                        monthlyInstallment = parsedInstallment,
                        totalValue = if (parsedMembers != null && parsedInstallment != null) parsedMembers * parsedInstallment else currentConfig.totalValue,
                        auctionScheduleDay = scheduleDayInput.toIntOrNull()?.takeIf { it in 1..31 },
                        auctionState = selectedState,
                        frequency = frequencyInput,
                        cycles = synchedCycles
                    )
                    onSave(updated)
                },
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
            ) {
                Text("Save Configuration", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    )
}
