package com.adr.groupledger.utils

import com.adr.groupledger.data.model.ChitCycle
import com.adr.groupledger.data.model.ChitCycleStatus
import com.adr.groupledger.data.model.ChitFundConfig
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Pure calculation engine for Chit Fund / BC (Bishi) mathematics and schedule planning.
 * Single source of truth for:
 * 1. Financial formulas (Pot, Chit Value, Max Bids, Dividends, Net Installments).
 * 2. Schedule generation (Safe monthly calendar math, weekly, daily frequencies).
 * 3. Cycle and auction lifecycle status resolution.
 */
object ChitCalculationEngine {

    /**
     * Calculates the total expected pot per round / cycle.
     * Formula: Total Expected Pot = Total Members * Monthly Contribution Amount
     */
    fun calculateExpectedPot(totalMembers: Int, contributionAmount: Double): Double {
        if (totalMembers <= 0 || contributionAmount <= 0.0) return 0.0
        return totalMembers * contributionAmount
    }

    /**
     * Calculates the total Chit Fund scheme valuation across all cycles.
     * For a typical Chit Fund: Total Value = Total Chits / Rounds * Expected Pot Per Round
     */
    fun calculateTotalChitValue(
        totalMembers: Int,
        totalCycles: Int,
        monthlyContribution: Double
    ): Double {
        if (totalMembers <= 0 || totalCycles <= 0 || monthlyContribution <= 0.0) return 0.0
        return totalMembers * monthlyContribution
    }

    /**
     * Validates whether a user-configured total value is mathematically consistent.
     */
    fun isTotalValueConsistent(
        configuredTotalValue: Double?,
        totalMembers: Int?,
        monthlyContribution: Double?
    ): Boolean {
        if (configuredTotalValue == null || configuredTotalValue <= 0.0) return true
        if (totalMembers == null || totalMembers <= 0) return true
        if (monthlyContribution == null || monthlyContribution <= 0.0) return true

        val expected = totalMembers * monthlyContribution
        val diff = kotlin.math.abs(configuredTotalValue - expected)
        return diff < 1.0 // Within 1 currency unit
    }

    /**
     * Cycle Metrics summary container.
     */
    data class CycleMetrics(
        val totalCycles: Int,
        val completedCycles: Int,
        val remainingCycles: Int,
        val cancelledCycles: Int,
        val currentCycleNumber: Int,
        val currentCycle: ChitCycle?,
        val nextAuctionCycle: ChitCycle?,
        val progressPercent: Int,
        val isAuctionLive: Boolean
    ) {
        val hasStartedOrCompletedCycles: Boolean
            get() = completedCycles > 0 || isAuctionLive || currentCycleNumber > 1
    }

    /**
     * Validation result container for Chit Fund configuration.
     */
    data class ValidationResult(
        val isValid: Boolean,
        val calculatedExpectedPot: Double,
        val calculatedTotalValue: Double,
        val warningMessage: String? = null
    )

    /**
     * Mathematical validation for Chit Fund scheme setup.
     */
    fun validateConfiguration(
        totalMembers: Int?,
        totalCycles: Int?,
        installmentAmount: Double?,
        totalChitValue: Double?
    ): ValidationResult {
        val members = totalMembers ?: 0
        val cycles = totalCycles ?: members
        val inst = installmentAmount ?: 0.0
        val expectedPot = members * inst
        val configuredVal = totalChitValue ?: expectedPot

        var warning: String? = null
        if (members > 0 && inst > 0.0 && configuredVal > 0.0) {
            val pot = members * inst
            if (kotlin.math.abs(configuredVal - pot) > 1.0) {
                warning = "Note: Total chit value (${configuredVal.toInt()}) differs from expected round contribution (${members} × ${inst.toInt()} = ${pot.toInt()})."
            }
        }

        return ValidationResult(
            isValid = members > 0 && cycles > 0 && inst > 0.0,
            calculatedExpectedPot = expectedPot,
            calculatedTotalValue = configuredVal,
            warningMessage = warning
        )
    }

    /**
     * Derives cycle counts, completion metrics, and the active/next auction cycle.
     * Inspects actual cycle statuses instead of assuming sequential linear index.
     */
    fun deriveCycleMetrics(
        cycles: List<ChitCycle>,
        configuredTotalCycles: Int?,
        currentChitNoOverride: Int? = null,
        nowMillis: Long = System.currentTimeMillis()
    ): CycleMetrics {
        val totalCount = configuredTotalCycles ?: cycles.size.takeIf { it > 0 } ?: 0

        val completedCount = cycles.count { it.status == ChitCycleStatus.COMPLETED }
        val cancelledCount = cycles.count { it.status == ChitCycleStatus.CANCELLED }

        // Find the active cycle with priority:
        // 1. Cycle currently marked or operating in AUCTION_OPEN
        // 2. Cycle currently in RESULT_PENDING or AUCTION_CLOSED
        // 3. Cycle in AUCTION_SCHEDULED or RESCHEDULED
        // 4. First UPCOMING cycle
        val operationalCycles = cycles.map { cycle ->
            val opStatus = cycle.deriveOperationalStatus(nowMillis)
            cycle.copy(status = opStatus)
        }

        val activeCycle = operationalCycles.firstOrNull { it.status == ChitCycleStatus.AUCTION_OPEN }
            ?: operationalCycles.firstOrNull { it.status in listOf(ChitCycleStatus.AUCTION_CLOSED, ChitCycleStatus.RESULT_PENDING) }
            ?: operationalCycles.firstOrNull { it.status in listOf(ChitCycleStatus.AUCTION_SCHEDULED, ChitCycleStatus.RESCHEDULED) }
            ?: operationalCycles.firstOrNull { it.status == ChitCycleStatus.UPCOMING }
            ?: operationalCycles.firstOrNull { !it.status.isTerminal() }

        val currentCycleNumber = currentChitNoOverride
            ?: activeCycle?.cycleNumber
            ?: (completedCount + 1).coerceAtMost(if (totalCount > 0) totalCount else 1)

        val remainingCount = if (totalCount > 0) {
            (totalCount - completedCount - cancelledCount).coerceAtLeast(0)
        } else {
            cycles.count { !it.status.isTerminal() }
        }

        val progressPercent = if (totalCount > 0) {
            ((completedCount.toDouble() / totalCount.toDouble()) * 100).roundToInt().coerceIn(0, 100)
        } else 0

        val isAuctionLive = activeCycle?.status == ChitCycleStatus.AUCTION_OPEN

        return CycleMetrics(
            totalCycles = totalCount,
            completedCycles = completedCount,
            remainingCycles = remainingCount,
            cancelledCycles = cancelledCount,
            currentCycleNumber = currentCycleNumber,
            currentCycle = activeCycle,
            nextAuctionCycle = activeCycle,
            progressPercent = progressPercent,
            isAuctionLive = isAuctionLive
        )
    }

    /**
     * Generates a safe, complete list of [ChitCycle] schedules for a Chit Fund scheme.
     * Preserves existing cycle data (winners, manual reschedules, status) if already present.
     *
     * Handles varying month lengths safely (e.g., Jan 31 -> Feb 28 -> Mar 31) without spillover.
     */
    fun generateOrUpdateCycleSchedule(
        existingCycles: List<ChitCycle>,
        totalCycles: Int,
        installmentAmount: Double,
        startDateMillis: Long?,
        frequency: String = "MONTHLY",
        auctionScheduleDay: Int? = null,
        auctionStartTime: String = "08:00 PM",
        auctionEndTime: String = "08:15 PM",
        auctionDurationMinutes: Int = 15
    ): List<ChitCycle> {
        if (totalCycles <= 0) return emptyList()

        val baseStartMillis = startDateMillis?.takeIf { it > 0L } ?: System.currentTimeMillis()
        val anchorCalendar = Calendar.getInstance().apply { timeInMillis = baseStartMillis }
        val anchorDayOfMonth = auctionScheduleDay?.takeIf { it in 1..31 } ?: anchorCalendar.get(Calendar.DAY_OF_MONTH)

        val existingMap = existingCycles.associateBy { it.cycleNumber }
        val updatedList = mutableListOf<ChitCycle>()

        for (cycleNo in 1..totalCycles) {
            val existing = existingMap[cycleNo]

            if (existing != null && (existing.status == ChitCycleStatus.COMPLETED || existing.isDateManuallyRescheduled)) {
                // Preserve completed or manually rescheduled cycles
                updatedList.add(
                    existing.copy(
                        installmentAmount = if (existing.installmentAmount > 0) existing.installmentAmount else installmentAmount,
                        auctionStartTime = existing.auctionStartTime ?: auctionStartTime,
                        auctionEndTime = existing.auctionEndTime ?: auctionEndTime,
                        auctionDurationMinutes = if (existing.auctionDurationMinutes > 0) existing.auctionDurationMinutes else auctionDurationMinutes
                    )
                )
            } else {
                // Calculate safe scheduled timestamp based on frequency
                val cycleCal = Calendar.getInstance().apply { timeInMillis = baseStartMillis }
                val step = cycleNo - 1

                when (frequency.uppercase(Locale.US)) {
                    "WEEKLY" -> {
                        cycleCal.add(Calendar.WEEK_OF_YEAR, step)
                    }
                    "DAILY" -> {
                        cycleCal.add(Calendar.DAY_OF_YEAR, step)
                    }
                    else -> {
                        // MONTHLY calculation with safe day-of-month anchoring
                        cycleCal.add(Calendar.MONTH, step)
                        val maxDaysInMonth = cycleCal.getActualMaximum(Calendar.DAY_OF_MONTH)
                        cycleCal.set(Calendar.DAY_OF_MONTH, anchorDayOfMonth.coerceAtMost(maxDaysInMonth))
                    }
                }

                // Default scheduled auction time to 8:00 PM on that day
                cycleCal.set(Calendar.HOUR_OF_DAY, 20)
                cycleCal.set(Calendar.MINUTE, 0)
                cycleCal.set(Calendar.SECOND, 0)
                cycleCal.set(Calendar.MILLISECOND, 0)

                val scheduledMillis = cycleCal.timeInMillis

                val defaultStatus = if (existing != null) existing.status else {
                    if (cycleNo == 1) ChitCycleStatus.AUCTION_SCHEDULED else ChitCycleStatus.UPCOMING
                }

                updatedList.add(
                    ChitCycle(
                        cycleNumber = cycleNo,
                        scheduledDateMillis = scheduledMillis,
                        installmentAmount = installmentAmount,
                        status = defaultStatus,
                        auctionDateMillis = scheduledMillis,
                        auctionStartTime = auctionStartTime,
                        auctionEndTime = auctionEndTime,
                        auctionDurationMinutes = auctionDurationMinutes,
                        isDateManuallyRescheduled = false,
                        winnerMemberId = existing?.winnerMemberId,
                        winnerMemberName = existing?.winnerMemberName,
                        winningBidAmount = existing?.winningBidAmount,
                        dividendPerMember = existing?.dividendPerMember,
                        notes = existing?.notes ?: "",
                        createdAtMillis = existing?.createdAtMillis ?: System.currentTimeMillis(),
                        updatedAtMillis = System.currentTimeMillis()
                    )
                )
            }
        }

        return updatedList
    }

    /**
     * Compatibility overload for cycle schedule generation.
     */
    fun generateOrUpdateCycles(
        totalCycles: Int,
        installmentAmount: Double,
        startDateMillis: Long?,
        frequency: String = "MONTHLY",
        existingCycles: List<ChitCycle> = emptyList(),
        auctionScheduleDay: Int? = null,
        auctionStartTime: String = "08:00 PM",
        auctionEndTime: String = "08:15 PM",
        auctionDurationMinutes: Int = 15
    ): List<ChitCycle> {
        return generateOrUpdateCycleSchedule(
            existingCycles = existingCycles,
            totalCycles = totalCycles,
            installmentAmount = installmentAmount,
            startDateMillis = startDateMillis,
            frequency = frequency,
            auctionScheduleDay = auctionScheduleDay,
            auctionStartTime = auctionStartTime,
            auctionEndTime = auctionEndTime,
            auctionDurationMinutes = auctionDurationMinutes
        )
    }

    /**
     * Formats duration in seconds into human-readable countdown string.
     */
    fun formatCountdown(secondsRemaining: Long): String {
        if (secondsRemaining <= 0L) return "00:00"
        val days = secondsRemaining / 86400
        val hours = (secondsRemaining % 86400) / 3600
        val minutes = (secondsRemaining % 3600) / 60
        val seconds = secondsRemaining % 60

        return when {
            days > 0 -> String.format(Locale.US, "%dd %02dh %02dm", days, hours, minutes)
            hours > 0 -> String.format(Locale.US, "%02dh %02dm %02ds", hours, minutes, seconds)
            else -> String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }
}
