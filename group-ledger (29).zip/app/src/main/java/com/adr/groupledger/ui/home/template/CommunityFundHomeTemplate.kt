package com.adr.groupledger.ui.home.template

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.adr.groupledger.ui.components.HomeNotificationCarousel
import com.adr.groupledger.ui.components.SamitiPullToRefreshBox
import com.adr.groupledger.ui.home.HomeTemplateContext
import com.adr.groupledger.ui.home.components.HomeActionCarouselCard
import com.adr.groupledger.ui.home.components.HomeActivityTimelineCard
import com.adr.groupledger.ui.home.components.HomeAnnouncementsCarousel
import com.adr.groupledger.ui.home.components.HomeAssetPortfolioCard
import com.adr.groupledger.ui.home.components.HomeCollectionProgressCard
import com.adr.groupledger.ui.home.components.HomeHeaderBanner

/**
 * Level 2: Community Fund Home Template.
 * Faithfully preserves the existing baseline Community Fund Home design.
 */
object CommunityFundHomeTemplate : GroupHomeTemplate {

    override val templateId: String = "community_fund_home"
    override val displayName: String = "Community Fund Home"

    @Composable
    override fun Render(context: HomeTemplateContext) {
        SamitiPullToRefreshBox(
            isRefreshing = context.isRefreshing,
            onRefresh = { context.viewModel.refreshDashboard() },
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                state = context.listState,
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("community_fund_dashboard"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 1. Group Header Banner
                item {
                    HomeHeaderBanner(
                        context = context,
                        onOpenCategorySelector = {
                            context.onCategoryChangeRequest?.invoke(context.category, context.subCategory)
                        }
                    )
                }

                // 2. System Alerts / Notifications Carousel
                if (context.notifications.isNotEmpty()) {
                    item {
                        HomeNotificationCarousel(notifications = context.notifications)
                    }
                }

                // 3. Services & Actions Carousel
                item {
                    HomeActionCarouselCard(context = context)
                }

                // 4. Monthly Collection Progress Card
                item {
                    HomeCollectionProgressCard(
                        context = context,
                        title = "Monthly Collection",
                        expectedAmountLabel = "Expected",
                        collectedAmountLabel = "Collected"
                    )
                }

                // 5. Group Asset Portfolio (Fixed Deposit, Cash in Hand, Bank Accounts)
                item {
                    HomeAssetPortfolioCard(
                        context = context,
                        title = "Group Asset Portfolio"
                    )
                }

                // 6. Dynamic Home Announcements Carousel (Restored)
                item {
                    HomeAnnouncementsCarousel(context = context)
                }

                // 7. Recent Transactions Timeline
                item {
                    HomeActivityTimelineCard(
                        context = context,
                        title = "Recent Transactions"
                    )
                }
            }
        }
    }
}
