package com.adr.groupledger.ui.home

import androidx.compose.foundation.lazy.LazyListState
import com.adr.groupledger.data.model.FeedbackWithVotes
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.HomeModuleConfig
import com.adr.groupledger.data.model.LoanWithVotingDetails
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.MemberWithMonthlyStatus
import com.adr.groupledger.data.model.MonthlySummary
import com.adr.groupledger.data.model.OverallGroupFinancials
import com.adr.groupledger.data.model.PendingPaymentApprovalItem
import com.adr.groupledger.data.model.SocietyNotice
import com.adr.groupledger.data.model.TransactionRecord
import com.adr.groupledger.data.model.carousel.CarouselItem
import com.adr.groupledger.ui.components.HomeNotificationItem
import com.adr.groupledger.ui.screens.demo.GroupCategory
import com.adr.groupledger.ui.viewmodel.SocietyViewModel

/**
 * Context passed to any [com.adr.groupledger.ui.home.template.GroupHomeTemplate].
 * Provides all data, states, navigation callbacks and action handlers required
 * to render a category-aware or subcategory-aware Home Page.
 */
data class HomeTemplateContext(
    val viewModel: SocietyViewModel,
    val settings: GroupSettings,
    val category: GroupCategory,
    val subCategory: String,
    val financials: OverallGroupFinancials,
    val selectedMonth: Int,
    val selectedYear: Int,
    val monthSummary: MonthlySummary?,
    val recentTxns: List<TransactionRecord>,
    val isAdminUnlocked: Boolean,
    val loansWithVoting: List<LoanWithVotingDetails>,
    val pendingApprovals: List<PendingPaymentApprovalItem>,
    val feedbacksWithVotes: List<FeedbackWithVotes>,
    val notices: List<SocietyNotice>,
    val homeModules: List<HomeModuleConfig>,
    val activeCarouselItems: List<CarouselItem>,
    val notifications: List<HomeNotificationItem>,
    val isRefreshing: Boolean,
    val listState: LazyListState,

    // Real Member & Current User Status Data
    val membersWithMonthlyStatus: List<MemberWithMonthlyStatus> = emptyList(),
    val currentUserMember: Member? = null,
    val currentUserMonthlyStatus: MemberWithMonthlyStatus? = null,
    val totalActiveMembersCount: Int = 0,

    // Navigation callbacks (standard across the app)
    val onNavigateToMembers: () -> Unit,
    val onNavigateToMonthly: () -> Unit,
    val onNavigateToDues: () -> Unit,
    val onNavigateToReports: () -> Unit,
    val onNavigateToRecordPayment: () -> Unit,
    val onNavigateToAddMember: () -> Unit,
    val onNavigateToMemberProfile: (Long) -> Unit,
    val onNavigateToLoans: () -> Unit = {},
    val onNavigateToInvestments: () -> Unit = {},
    val onNavigateToFeedback: () -> Unit = {},
    val onNavigateToLedger: () -> Unit = {},
    val onNavigateToInbox: () -> Unit = {},
    val onNavigateToAuctionDetails: ((Int?) -> Unit)? = null,

    // Category / SubCategory switching handler
    val onCategoryChangeRequest: ((GroupCategory, String) -> Unit)? = null
)
