package com.adr.groupledger.ui.home.components

import androidx.compose.runtime.Composable
import com.adr.groupledger.ui.home.HomeTemplateContext

/**
 * Baseline original Community Fund First Card design component.
 * Preserves the exact signature Indigo gradient card layout with
 * Total Assets, In-Hand Cash, and monthly collection metrics.
 */
@Composable
fun CommunityFundFirstCard(
    context: HomeTemplateContext,
    onOpenCategorySelector: (() -> Unit)? = null
) {
    HomeHeaderBanner(
        context = context,
        onOpenCategorySelector = onOpenCategorySelector
    )
}
