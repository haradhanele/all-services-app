package com.adr.groupledger.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.BrightnessAuto
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.HomeModuleConfig
import com.adr.groupledger.data.model.UpdateCheckStatus
import com.adr.groupledger.ui.components.AppUpdateDialog
import com.adr.groupledger.ui.components.ConfirmActionDialog
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.appOutlinedTextFieldColors
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.utils.DateUtils

@Composable
fun SettingsScreen(
    viewModel: SocietyViewModel,
    onNavigateToBackup: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val currentSettings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val allGroups by viewModel.allGroups.collectAsStateWithLifecycle()
    val currentUserRole by viewModel.currentUserRole.collectAsStateWithLifecycle()
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()
    val homeModules by viewModel.homeModules.collectAsStateWithLifecycle()
    val updateStatus by viewModel.updateStatus.collectAsStateWithLifecycle()
    val lastCheckedTime by viewModel.lastUpdateCheckTime.collectAsStateWithLifecycle()

    var showAppUpdateDialog by remember { mutableStateOf(false) }

    val isAdmin = isAdminUnlocked || currentUserRole == "ADMIN"

    // 1. Profile State
    var groupName by remember { mutableStateOf("") }
    var groupSubtitle by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var groupType by remember { mutableStateOf("Self-Help Group") }
    var address by remember { mutableStateOf("") }
    var contactPhone by remember { mutableStateOf("") }
    var contactEmail by remember { mutableStateOf("") }

    // 2. Contribution State
    var isContributionEnabled by remember { mutableStateOf(true) }
    var defaultContribution by remember { mutableStateOf("") }
    var contributionFrequency by remember { mutableStateOf("MONTHLY") }
    var dueDayOfMonth by remember { mutableStateOf("10") }
    var isLateFeeEnabled by remember { mutableStateOf(false) }
    var lateFineAmount by remember { mutableStateOf("50") }
    var gracePeriodDays by remember { mutableStateOf("5") }
    var paymentRules by remember { mutableStateOf("") }

    // 3. Admin & Security & Theme State
    var adminName by remember { mutableStateOf("") }
    var adminPhone by remember { mutableStateOf("") }
    var adminPin by remember { mutableStateOf("") }
    var isPinLockEnabled by remember { mutableStateOf(false) }
    var themeMode by remember { mutableStateOf("SYSTEM") }

    // Modals
    var showResetConfirm by remember { mutableStateOf(false) }
    var showResetModulesConfirm by remember { mutableStateOf(false) }
    var renamingModule by remember { mutableStateOf<HomeModuleConfig?>(null) }
    var renameInputText by remember { mutableStateOf("") }
    var showAddCustomModuleDialog by remember { mutableStateOf(false) }

    LaunchedEffect(currentSettings) {
        groupName = currentSettings.groupName
        groupSubtitle = currentSettings.groupSubtitle
        description = currentSettings.description
        groupType = currentSettings.groupType.ifBlank { "Self-Help Group" }
        address = currentSettings.address
        contactPhone = currentSettings.contactPhone
        contactEmail = currentSettings.contactEmail

        isContributionEnabled = currentSettings.isContributionEnabled
        defaultContribution = if (currentSettings.defaultContribution <= 0.0) "00" else currentSettings.defaultContribution.toInt().toString()
        contributionFrequency = currentSettings.contributionFrequency.ifBlank { "MONTHLY" }
        dueDayOfMonth = currentSettings.dueDayOfMonth.toString()
        isLateFeeEnabled = currentSettings.isLateFeeEnabled
        lateFineAmount = currentSettings.lateFineAmount.toInt().toString()
        gracePeriodDays = currentSettings.gracePeriodDays.toString()
        paymentRules = currentSettings.paymentRules

        adminName = currentSettings.adminName
        adminPhone = currentSettings.adminPhone
        adminPin = currentSettings.adminPin
        isPinLockEnabled = currentSettings.isPinLockEnabled
        themeMode = currentSettings.themeMode
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .testTag("settings_screen"),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 36.dp)
        ) {
            // 1. Active Group / Society Card
            item {
                Text(
                    text = "Active Group / Society",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                        .testTag("settings_active_group_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = IndigoPrimary.copy(alpha = 0.12f),
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Groups,
                                            contentDescription = null,
                                            tint = IndigoPrimary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = currentSettings.groupName,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    if (currentSettings.groupSubtitle.isNotBlank()) {
                                        Text(
                                            text = currentSettings.groupSubtitle,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = IndigoPrimary.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = currentSettings.groupType.ifBlank { "Society" },
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = IndigoPrimary,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Group ID: #${currentSettings.id}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "Code: ${currentSettings.inviteCode}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = IndigoPrimary
                                )
                            }
                        }
                    }
                }
            }

            // 2. Group Profile Settings
            item {
                Text(
                    text = "Group Profile Settings",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = groupName,
                            onValueChange = { groupName = it },
                            label = { Text("Group / Society Name *") },
                            leadingIcon = { Icon(Icons.Default.AccountBalance, contentDescription = null, tint = IndigoPrimary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("settings_group_name_input"),
                            shape = RoundedCornerShape(10.dp),
                            colors = appOutlinedTextFieldColors()
                        )

                        OutlinedTextField(
                            value = groupSubtitle,
                            onValueChange = { groupSubtitle = it },
                            label = { Text("Tagline / Subtitle") },
                            placeholder = { Text("e.g. Monthly Savings & Welfare Society") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("settings_group_subtitle_input"),
                            shape = RoundedCornerShape(10.dp),
                            colors = appOutlinedTextFieldColors()
                        )

                        // Group Category / Type
                        Column {
                            Text(
                                text = "Group Category / Type",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            val groupTypes = listOf(
                                "Self-Help Group",
                                "Society",
                                "Welfare Club",
                                "Investment Club",
                                "Housing Society",
                                "Sports / Youth Club",
                                "Other"
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                groupTypes.forEach { type ->
                                    val isSelected = groupType == type
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { groupType = type },
                                        label = { Text(type, fontSize = 12.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = IndigoPrimary,
                                            selectedLabelColor = Color.White
                                        )
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = description,
                            onValueChange = { description = it },
                            label = { Text("Short Description / About") },
                            placeholder = { Text("Purpose and background of this samiti / group...") },
                            leadingIcon = { Icon(Icons.Default.Notes, contentDescription = null, tint = IndigoPrimary) },
                            minLines = 2,
                            maxLines = 3,
                            modifier = Modifier.fillMaxWidth().testTag("settings_description_input"),
                            shape = RoundedCornerShape(10.dp),
                            colors = appOutlinedTextFieldColors()
                        )

                        OutlinedTextField(
                            value = address,
                            onValueChange = { address = it },
                            label = { Text("Location / Address") },
                            placeholder = { Text("e.g. Village/Town, District, State") },
                            leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = IndigoPrimary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("settings_address_input"),
                            shape = RoundedCornerShape(10.dp),
                            colors = appOutlinedTextFieldColors()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = contactPhone,
                                onValueChange = { contactPhone = it },
                                label = { Text("Contact Phone") },
                                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = IndigoPrimary) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                modifier = Modifier.weight(1f).testTag("settings_contact_phone_input"),
                                shape = RoundedCornerShape(10.dp),
                                colors = appOutlinedTextFieldColors()
                            )

                            OutlinedTextField(
                                value = contactEmail,
                                onValueChange = { contactEmail = it },
                                label = { Text("Contact Email") },
                                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = IndigoPrimary) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                singleLine = true,
                                modifier = Modifier.weight(1f).testTag("settings_contact_email_input"),
                                shape = RoundedCornerShape(10.dp),
                                colors = appOutlinedTextFieldColors()
                            )
                        }

                        // Creation Date info badge
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Established: ${DateUtils.formatDate(currentSettings.createdAt)}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // 3. Contribution Configuration Settings
            item {
                Text(
                    text = "Contribution Configuration",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Enable/Disable Contribution toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Enable Group Contribution",
                                    fontWeight = FontWeight.SemiBold,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (isContributionEnabled) "Active • Monthly/Periodic collections enabled" else "Disabled • Society does not collect regular dues",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (isContributionEnabled) Emerald500 else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = isContributionEnabled,
                                onCheckedChange = { isContributionEnabled = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = IndigoPrimary, checkedTrackColor = IndigoPrimary.copy(alpha = 0.3f)),
                                modifier = Modifier.testTag("settings_contribution_switch")
                            )
                        }

                        if (isContributionEnabled) {
                            OutlinedTextField(
                                value = defaultContribution,
                                onValueChange = { defaultContribution = it },
                                label = { Text("Contribution Amount (₹) *") },
                                leadingIcon = { Icon(Icons.Default.Payment, contentDescription = null, tint = IndigoPrimary) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("settings_default_contribution_input"),
                                shape = RoundedCornerShape(10.dp),
                                colors = appOutlinedTextFieldColors()
                            )

                            // Frequency Selector
                            Column {
                                Text(
                                    text = "Collection Frequency",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                val frequencies = listOf("MONTHLY", "WEEKLY", "YEARLY", "CUSTOM")
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    frequencies.forEach { freq ->
                                        val isSelected = contributionFrequency == freq
                                        FilterChip(
                                            selected = isSelected,
                                            onClick = { contributionFrequency = freq },
                                            label = { Text(freq.lowercase().replaceFirstChar { it.uppercase() }, fontSize = 12.sp) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = IndigoPrimary,
                                                selectedLabelColor = Color.White
                                            ),
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }

                            // Due Day of Month
                            OutlinedTextField(
                                value = dueDayOfMonth,
                                onValueChange = { if (it.length <= 2) dueDayOfMonth = it },
                                label = { Text("Payment Due Day (1 - 31)") },
                                placeholder = { Text("e.g. 10") },
                                leadingIcon = { Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = IndigoPrimary) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("settings_due_day_input"),
                                shape = RoundedCornerShape(10.dp),
                                colors = appOutlinedTextFieldColors()
                            )

                            // Late Fine / Missed Contribution Penalty Settings
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "Late Fee / Missed Penalty",
                                                fontWeight = FontWeight.SemiBold,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "Apply fine for delayed payments after grace period",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Switch(
                                            checked = isLateFeeEnabled,
                                            onCheckedChange = { isLateFeeEnabled = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = IndigoPrimary, checkedTrackColor = IndigoPrimary.copy(alpha = 0.3f))
                                        )
                                    }

                                    if (isLateFeeEnabled) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            OutlinedTextField(
                                                value = lateFineAmount,
                                                onValueChange = { lateFineAmount = it },
                                                label = { Text("Fine Amount (₹)") },
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                singleLine = true,
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                colors = appOutlinedTextFieldColors()
                                            )

                                            OutlinedTextField(
                                                value = gracePeriodDays,
                                                onValueChange = { gracePeriodDays = it },
                                                label = { Text("Grace Period (Days)") },
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                singleLine = true,
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                colors = appOutlinedTextFieldColors()
                                            )
                                        }
                                    }
                                }
                            }

                            // Payment Rules Description
                            OutlinedTextField(
                                value = paymentRules,
                                onValueChange = { paymentRules = it },
                                label = { Text("Group Rules & Contribution Notes") },
                                placeholder = { Text("Describe due dates, bank transfer rules, fine exemptions, etc.") },
                                leadingIcon = { Icon(Icons.Default.Notes, contentDescription = null, tint = IndigoPrimary) },
                                minLines = 2,
                                maxLines = 4,
                                modifier = Modifier.fillMaxWidth().testTag("settings_rules_input"),
                                shape = RoundedCornerShape(10.dp),
                                colors = appOutlinedTextFieldColors()
                            )
                        }
                    }
                }
            }

            // 4. Home Page Modules & Services Carousel Management (Group Specific)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Home Modules & Services",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Enable, rename, and reorder cards on the Home Dashboard for this group",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))

                // Module Action Buttons: Add Custom Module & Reset
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { showAddCustomModuleDialog = true },
                        modifier = Modifier.weight(1f).height(40.dp).testTag("add_custom_module_btn"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Custom Card", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { showResetModulesConfirm = true },
                        modifier = Modifier.weight(1f).height(40.dp).testTag("reset_modules_btn"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Reset Modules", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))

                // List of Modules
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        val sortedModules = homeModules.sortedBy { it.orderIndex }
                        sortedModules.forEachIndexed { index, mod ->
                            val isFirst = index == 0
                            val isLast = index == sortedModules.size - 1

                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("module_item_${mod.key}"),
                                shape = RoundedCornerShape(10.dp),
                                color = if (mod.isEnabled) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.12f),
                                border = BorderStroke(1.dp, if (mod.isEnabled) IndigoPrimary.copy(alpha = 0.25f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    // Icon & Title & Tag
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Surface(
                                            shape = CircleShape,
                                            color = if (mod.isEnabled) IndigoPrimary.copy(alpha = 0.12f) else Color.Gray.copy(alpha = 0.12f),
                                            modifier = Modifier.size(34.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = resolveModuleIcon(mod.iconName),
                                                    contentDescription = null,
                                                    tint = if (mod.isEnabled) IndigoPrimary else Color.Gray,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = mod.getDisplayName(),
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.5.sp,
                                                    color = if (mod.isEnabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                if (mod.customName.isNotBlank() && mod.customName != mod.defaultName) {
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        text = "(${mod.defaultName})",
                                                        fontSize = 10.5.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text(
                                                    text = mod.description.ifBlank { "Home module" },
                                                    fontSize = 10.5.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1
                                                )
                                                if (mod.isCustom) {
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = Emerald500.copy(alpha = 0.15f)
                                                    ) {
                                                        Text("Custom", fontSize = 9.sp, color = Emerald500, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    // Action Controls: Move Up/Down, Rename, Toggle Switch, Delete (if custom)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        // Move Up
                                        IconButton(
                                            onClick = { viewModel.moveModule(mod.key, -1) },
                                            enabled = !isFirst,
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.ArrowUpward,
                                                contentDescription = "Move Up",
                                                tint = if (!isFirst) IndigoPrimary else Color.LightGray,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }

                                        // Move Down
                                        IconButton(
                                            onClick = { viewModel.moveModule(mod.key, 1) },
                                            enabled = !isLast,
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.ArrowDownward,
                                                contentDescription = "Move Down",
                                                tint = if (!isLast) IndigoPrimary else Color.LightGray,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }

                                        // Rename Button
                                        IconButton(
                                            onClick = {
                                                renamingModule = mod
                                                renameInputText = mod.customName.ifBlank { mod.defaultName }
                                            },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Edit,
                                                contentDescription = "Rename",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(15.dp)
                                            )
                                        }

                                        // Delete if Custom
                                        if (mod.isCustom) {
                                            IconButton(
                                                onClick = { viewModel.deleteCustomModule(mod.key) },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(
                                                    Icons.Default.Delete,
                                                    contentDescription = "Delete",
                                                    tint = Rose500,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(4.dp))

                                        // Enable/Disable Switch
                                        Switch(
                                            checked = mod.isEnabled,
                                            onCheckedChange = { isChecked ->
                                                viewModel.toggleModule(mod.key, isChecked)
                                            },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = IndigoPrimary,
                                                checkedTrackColor = IndigoPrimary.copy(alpha = 0.3f)
                                            ),
                                            modifier = Modifier.size(36.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 5. Group Joining Invitation Code Generator Card
            item {
                Text(
                    text = "Group Invitation & Joining Code",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                        .testTag("settings_invite_code_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Key,
                                    contentDescription = null,
                                    tint = IndigoPrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "Current Invitation Code",
                                        fontWeight = FontWeight.SemiBold,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Share this code for members to join this group",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        // Monospace Invitation Code Display Box
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = IndigoPrimary.copy(alpha = 0.08f),
                            border = BorderStroke(1.5.dp, IndigoPrimary.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = currentSettings.inviteCode,
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        color = IndigoPrimary,
                                        letterSpacing = 2.sp
                                    )
                                    Text(
                                        text = "Active & valid for registration",
                                        fontSize = 11.sp,
                                        color = Emerald500,
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    IconButton(
                                        onClick = {
                                            clipboardManager.setText(AnnotatedString(currentSettings.inviteCode))
                                            Toast.makeText(context, "Invite code copied to clipboard", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.testTag("copy_invite_code_btn")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ContentCopy,
                                            contentDescription = "Copy Code",
                                            tint = IndigoPrimary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            val shareIntent = Intent().apply {
                                                action = Intent.ACTION_SEND
                                                putExtra(
                                                    Intent.EXTRA_TEXT,
                                                    "Join our '${currentSettings.groupName}' on the Samiti App using Invitation Code: ${currentSettings.inviteCode}"
                                                )
                                                type = "text/plain"
                                            }
                                            context.startActivity(Intent.createChooser(shareIntent, "Share Group Invite Code"))
                                        },
                                        modifier = Modifier.testTag("share_invite_code_btn")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Share,
                                            contentDescription = "Share Code",
                                            tint = IndigoPrimary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }

                        OutlinedButton(
                            onClick = {
                                viewModel.regenerateGroupInviteCode { newCode ->
                                    Toast.makeText(context, "New invitation code generated: $newCode", Toast.LENGTH_LONG).show()
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(42.dp)
                                .testTag("generate_new_invite_code_btn"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = IndigoPrimary)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Generate New Invitation Code",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // 6. Theme & Appearance Selector Card
            item {
                Text(
                    text = "Appearance & Theme",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Palette,
                                contentDescription = null,
                                tint = IndigoPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Theme Display Mode",
                                    fontWeight = FontWeight.SemiBold,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Switch between Light, Dark, or System theme",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val themeOptions = listOf(
                                Triple("SYSTEM", "System", Icons.Default.BrightnessAuto),
                                Triple("LIGHT", "Light", Icons.Default.LightMode),
                                Triple("DARK", "Dark", Icons.Default.DarkMode)
                            )

                            themeOptions.forEach { (mode, title, icon) ->
                                val isSelected = themeMode == mode
                                Card(
                                    modifier = Modifier
                                        .weight(1f)
                                        .border(
                                            width = if (isSelected) 2.dp else 1.dp,
                                            color = if (isSelected) IndigoPrimary else MaterialTheme.colorScheme.outlineVariant,
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .testTag("theme_mode_${mode.lowercase()}"),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isSelected) IndigoPrimary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
                                    ),
                                    onClick = {
                                        themeMode = mode
                                        viewModel.updateGroupSettings(currentSettings.copy(themeMode = mode))
                                    }
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 12.dp, horizontal = 8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = icon,
                                            contentDescription = title,
                                            tint = if (isSelected) IndigoPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = title,
                                            fontSize = 12.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) IndigoPrimary else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 7. Data Management & Backup Buttons
            item {
                Text(
                    text = "Data Management & Storage",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onNavigateToBackup,
                        modifier = Modifier.weight(1f).testTag("backup_restore_nav_btn"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface)
                    ) {
                        Icon(Icons.Default.Backup, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(17.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Backup & Restore", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                    }

                    OutlinedButton(
                        onClick = { showResetConfirm = true },
                        modifier = Modifier.weight(1f).testTag("reset_demo_data_btn"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(17.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Reset Demo", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = { showAppUpdateDialog = true },
                    modifier = Modifier.fillMaxWidth().testTag("settings_app_update_btn"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface)
                ) {
                    Icon(Icons.Default.SystemUpdate, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(17.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (updateStatus is UpdateCheckStatus.UpdateAvailable) {
                            "✨ Update Available: v${(updateStatus as UpdateCheckStatus.UpdateAvailable).updateInfo.versionName}"
                        } else {
                            "App Update Service • v${viewModel.currentVersionName}"
                        },
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // 9. Save Settings Button
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = {
                        val defVal = defaultContribution.toDoubleOrNull() ?: 0.0
                        val dueDay = dueDayOfMonth.toIntOrNull()?.coerceIn(1, 31) ?: 10
                        val fineAmt = lateFineAmount.toDoubleOrNull() ?: 0.0
                        val graceDays = gracePeriodDays.toIntOrNull()?.coerceAtLeast(0) ?: 5

                        val updated = currentSettings.copy(
                            groupName = groupName.trim().ifEmpty { "Samiti Fund" },
                            groupSubtitle = groupSubtitle.trim(),
                            description = description.trim(),
                            groupType = groupType,
                            address = address.trim(),
                            contactPhone = contactPhone.trim(),
                            contactEmail = contactEmail.trim(),
                            isContributionEnabled = isContributionEnabled,
                            defaultContribution = defVal,
                            contributionFrequency = contributionFrequency,
                            dueDayOfMonth = dueDay,
                            isLateFeeEnabled = isLateFeeEnabled,
                            lateFineAmount = fineAmt,
                            gracePeriodDays = graceDays,
                            paymentRules = paymentRules.trim(),
                            adminName = adminName.trim(),
                            adminPhone = adminPhone.trim(),
                            adminPin = adminPin.trim().ifEmpty { "1234" },
                            isPinLockEnabled = isPinLockEnabled,
                            themeMode = themeMode
                        )
                        viewModel.updateGroupSettings(updated)
                        Toast.makeText(context, "Group profile & contribution settings saved", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("save_settings_btn"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save All Settings", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }

        // Rename Module Dialog
        if (renamingModule != null) {
            AlertDialog(
                onDismissRequest = { renamingModule = null },
                title = { Text("Rename Module Card", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Original key: ${renamingModule?.key} (${renamingModule?.defaultName})",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = renameInputText,
                            onValueChange = { renameInputText = it },
                            label = { Text("Display Name on Home") },
                            placeholder = { Text("e.g. Feedback, Borrowings...") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = appOutlinedTextFieldColors()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            renamingModule?.let {
                                viewModel.renameModule(it.key, renameInputText)
                            }
                            renamingModule = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                    ) {
                        Text("Rename")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { renamingModule = null }) {
                        Text("Cancel")
                    }
                }
            )
        }

        // Add Custom Module Dialog
        if (showAddCustomModuleDialog) {
            var customName by remember { mutableStateOf("") }
            var customDesc by remember { mutableStateOf("") }
            var selectedIcon by remember { mutableStateOf("star") }

            val availableIcons = listOf(
                "star" to "Star",
                "celebration" to "Events",
                "store" to "Store / Bazaar",
                "work" to "Projects",
                "auto_awesome" to "Special",
                "receipt_long" to "Receipt",
                "chat" to "Discussion",
                "campaign" to "Announcement",
                "lightbulb" to "Idea",
                "help" to "Support",
                "savings" to "Reserve",
                "assignment" to "Task"
            )

            AlertDialog(
                onDismissRequest = { showAddCustomModuleDialog = false },
                title = { Text("Add Custom Home Module", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = customName,
                            onValueChange = { customName = it },
                            label = { Text("Card Name *") },
                            placeholder = { Text("e.g. Welfare Fund, Projects...") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = appOutlinedTextFieldColors()
                        )

                        OutlinedTextField(
                            value = customDesc,
                            onValueChange = { customDesc = it },
                            label = { Text("Short Subtitle / Description") },
                            placeholder = { Text("e.g. Community Welfare Schemes") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = appOutlinedTextFieldColors()
                        )

                        Text("Select Card Icon:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            availableIcons.forEach { (iconKey, label) ->
                                val isSel = selectedIcon == iconKey
                                FilterChip(
                                    selected = isSel,
                                    onClick = { selectedIcon = iconKey },
                                    leadingIcon = {
                                        Icon(resolveModuleIcon(iconKey), contentDescription = null, modifier = Modifier.size(16.dp))
                                    },
                                    label = { Text(label, fontSize = 11.5.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = IndigoPrimary,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (customName.isNotBlank()) {
                                viewModel.addCustomModule(customName, customDesc, selectedIcon) {
                                    showAddCustomModuleDialog = false
                                }
                            } else {
                                Toast.makeText(context, "Please enter a card name", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                    ) {
                        Text("Add to Home")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddCustomModuleDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }

        // Reset Modules Confirm Dialog
        ConfirmActionDialog(
            isOpen = showResetModulesConfirm,
            title = "Reset Home Modules",
            message = "This will restore the standard default home modules order and visibility for this group.",
            confirmButtonText = "Reset Layout",
            isDestructive = false,
            onConfirm = {
                viewModel.resetModulesToDefault()
                showResetModulesConfirm = false
            },
            onDismiss = { showResetModulesConfirm = false }
        )

        // Reset demo confirm dialog
        ConfirmActionDialog(
            isOpen = showResetConfirm,
            title = "Reset to Sample Committee Data",
            message = "This will replace current data with the default sample committee members and transactions.",
            confirmButtonText = "Reset Data",
            isDestructive = true,
            onConfirm = { viewModel.resetToDemoData() },
            onDismiss = { showResetConfirm = false }
        )

        // App Update Dialog
        if (showAppUpdateDialog) {
            AppUpdateDialog(
                viewModel = viewModel,
                updateStatus = updateStatus,
                currentVersionName = viewModel.currentVersionName,
                currentVersionCode = viewModel.currentVersionCode,
                lastCheckedTime = lastCheckedTime,
                isAdmin = isAdmin,
                onDismissRequest = { showAppUpdateDialog = false }
            )
        }
    }
}
