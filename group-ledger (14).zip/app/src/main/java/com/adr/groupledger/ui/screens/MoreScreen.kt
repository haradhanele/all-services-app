package com.adr.groupledger.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AppRegistration
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.BrightnessAuto
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.UpdateCheckStatus
import com.adr.groupledger.ui.components.AppUpdateDialog
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.appOutlinedTextFieldColors
import com.adr.groupledger.ui.viewmodel.SocietyViewModel

@Composable
fun MoreScreen(
    viewModel: SocietyViewModel,
    onNavigateToLoans: () -> Unit,
    onNavigateToInvestments: () -> Unit,
    onNavigateToFeedback: () -> Unit,
    onNavigateToLedger: () -> Unit,
    onNavigateToMonthly: () -> Unit,
    onNavigateToDues: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToBackup: () -> Unit,
    onNavigateToMyProfile: (Long) -> Unit,
    onNavigateToMembers: () -> Unit = {},
    onNavigateToAddMember: () -> Unit = {},
    onNavigateToCreateGroup: () -> Unit = {},
    onNavigateToEditGroup: (Long) -> Unit = {},
    onNavigateToUserProfile: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val allGroups by viewModel.allGroups.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val userMemberships by viewModel.userMemberships.collectAsStateWithLifecycle()
    val currentUserRole by viewModel.currentUserRole.collectAsStateWithLifecycle()
    val loansWithVoting by viewModel.allLoansWithVotes.collectAsStateWithLifecycle()
    val members by viewModel.allActiveMembers.collectAsStateWithLifecycle()
    val currentMemberId by viewModel.currentMemberId.collectAsStateWithLifecycle()
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()
    val preAuthorizedMembers by viewModel.preAuthorizedMembers.collectAsStateWithLifecycle()
    val pendingJoinRequests by viewModel.pendingJoinRequests.collectAsStateWithLifecycle()

    val currentUserId by viewModel.currentUserId.collectAsStateWithLifecycle()

    // 1. Determine Account Status and Permissions
    val isSignedUpUser = currentUser?.isAccountCompleted == true
    val effectiveUserId = currentUser?.id ?: currentUserId

    // Groups I Manage / Created List: Strictly created by this user
    val managedGroups = remember(allGroups, currentUser, currentUserId) {
        val uid = currentUser?.id ?: currentUserId
        if (uid <= 0L) emptyList()
        else allGroups.filter { g -> g.createdByUserId == uid }.distinctBy { it.id }
    }

    // Groups I Joined List: Where user is an active member and not the creator
    val joinedGroups = remember(allGroups, userMemberships, currentUser, currentUserId, managedGroups) {
        val uid = currentUser?.id ?: currentUserId
        val managedIds = managedGroups.map { it.id }.toSet()
        allGroups.filter { g ->
            g.id !in managedIds &&
            userMemberships.any { m -> m.groupId == g.id && m.userId == uid && m.isActive }
        }.distinctBy { it.id }
    }

    // All Groups List: (joined + created) strictly where user is an active participant
    val allUserGroups = remember(allGroups, managedGroups, joinedGroups, userMemberships, currentUser, currentUserId, settings) {
        val uid = currentUser?.id ?: currentUserId
        val combined = (managedGroups + joinedGroups).toMutableList()
        if (combined.none { it.id == settings.id }) {
            if (settings.createdByUserId == uid || userMemberships.any { it.groupId == settings.id && it.userId == uid && it.isActive }) {
                combined.add(settings)
            }
        }
        combined.distinctBy { it.id }
    }

    val isGroupAdmin = settings.createdByUserId == effectiveUserId ||
            currentUserRole.equals("ADMIN", ignoreCase = true) ||
            isAdminUnlocked

    val pendingLoansCount = remember(loansWithVoting) {
        loansWithVoting.count { it.loan.status in listOf("VOTING", "SUBMITTED") }
    }

    val currentMember = remember(members, currentMemberId) {
        if (currentMemberId != null) members.find { it.id == currentMemberId } else null
    }

    // Modal / Dialog States
    var showProfileModal by remember { mutableStateOf(false) }
    var showCompleteSignUpDialog by remember { mutableStateOf(false) }
    var showGroupJoiningCodeDialog by remember { mutableStateOf(false) }
    var showReadOnlyGroupSettingsDialog by remember { mutableStateOf(false) }
    var showManagedGroupsDialog by remember { mutableStateOf(false) }
    var showJoinedGroupsDialog by remember { mutableStateOf(false) }
    var showCreateGroupDialog by remember { mutableStateOf(false) }
    var showPreAuthorizedMembersDialog by remember { mutableStateOf(false) }
    var showPendingRequestsDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var showSignOutConfirm by remember { mutableStateOf(false) }
    var showAppUpdateDialog by remember { mutableStateOf(false) }
    var groupToDelete by remember { mutableStateOf<GroupSettings?>(null) }

    val updateStatus by viewModel.updateStatus.collectAsStateWithLifecycle()
    val lastCheckedTime by viewModel.lastUpdateCheckTime.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("more_screen"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // =================================================================
        // 1. COMPACT, BEAUTIFUL USER PROFILE CARD
        // =================================================================
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("user_profile_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                ) {
                    // Top Row: Avatar, Identity Info, Status Badge & View Profile
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                modifier = Modifier.size(38.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    val displayName = currentUser?.fullName?.takeIf { it.isNotBlank() }
                                        ?: currentMember?.name?.takeIf { it.isNotBlank() }
                                        ?: "User"
                                    val initial = displayName.take(1).uppercase()
                                    Text(
                                        text = initial,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    val displayName = currentUser?.fullName?.takeIf { it.isNotBlank() }
                                        ?: currentMember?.name?.takeIf { it.isNotBlank() }
                                        ?: "User"
                                    Text(
                                        text = displayName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.5.sp,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )

                                    // Account Status Pill
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (isSignedUpUser) Emerald500.copy(alpha = 0.12f) else Amber500.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = if (isSignedUpUser) "Full Account" else "Join Code",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSignedUpUser) Emerald500 else Amber500,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(1.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    // Current Group Role Tag
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (isGroupAdmin) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.12f)
                                    ) {
                                        Text(
                                            text = if (isGroupAdmin) "Group Admin" else "Member",
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (isGroupAdmin) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }

                                    val contact = currentUser?.phone?.takeIf { it.isNotBlank() }
                                        ?: currentUser?.email?.takeIf { it.isNotBlank() && !it.contains("@groupledger.org") }
                                        ?: currentMember?.phone?.takeIf { it.isNotBlank() }
                                        ?: currentMember?.email?.takeIf { it.isNotBlank() }
                                        ?: ""
                                    if (contact.isNotBlank()) {
                                        Text(
                                            text = contact,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }

                        // View Profile Action Button
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                            modifier = Modifier
                                .clickable { onNavigateToUserProfile() }
                                .testTag("view_profile_btn")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Profile",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = null,
                                    modifier = Modifier.size(12.dp),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f), thickness = 0.75.dp)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Statistics Row: Create Groups vs Join Groups (CLICKABLE TO VIEW / SWITCH LISTS)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Stat Box 1: Create Groups (Emerald Theme)
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Emerald500.copy(alpha = 0.10f),
                            border = BorderStroke(1.dp, Emerald500.copy(alpha = 0.35f)),
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    if (isSignedUpUser) {
                                        if (managedGroups.isEmpty()) {
                                            onNavigateToCreateGroup()
                                        } else {
                                            showManagedGroupsDialog = true
                                        }
                                    } else {
                                        showCompleteSignUpDialog = true
                                    }
                                }
                                .testTag("stat_create_groups")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = "Create Groups",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Emerald500
                                    )
                                    Spacer(modifier = Modifier.height(1.dp))
                                    Row(verticalAlignment = Alignment.Bottom) {
                                        Text(
                                            text = "${managedGroups.size}",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Emerald500
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (managedGroups.size == 1) "group" else "groups",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Icon(
                                    imageVector = Icons.Default.AdminPanelSettings,
                                    contentDescription = null,
                                    tint = Emerald500,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        // Stat Box 2: Join Groups (Amber Theme - Displays count of ALL groups)
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Amber500.copy(alpha = 0.14f),
                            border = BorderStroke(1.dp, Amber500.copy(alpha = 0.40f)),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { showJoinedGroupsDialog = true }
                                .testTag("stat_join_groups")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = "Join Groups",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFFB45309)
                                    )
                                    Spacer(modifier = Modifier.height(1.dp))
                                    Row(verticalAlignment = Alignment.Bottom) {
                                        Text(
                                            text = "${allUserGroups.size}",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFB45309)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (allUserGroups.size == 1) "group" else "groups",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Icon(
                                    imageVector = Icons.Default.Groups,
                                    contentDescription = null,
                                    tint = Color(0xFFD97706),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    // Selected Active Group Box (Clickable to switch or view groups)
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showJoinedGroupsDialog = true
                            }
                            .testTag("selected_active_group_box")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Groups,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Selected Active Group",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = settings.groupName,
                                        fontSize = 13.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "ID #${settings.id} • ${settings.groupType.ifBlank { "Society" }} • Code: ${settings.inviteCode}",
                                        fontSize = 10.5.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // For join-by-code users, offer a helpful banner to complete sign up
                    if (!isSignedUpUser) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Amber500.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, Amber500.copy(alpha = 0.25f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showCompleteSignUpDialog = true }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        Icons.Default.AppRegistration,
                                        contentDescription = null,
                                        tint = Amber500,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Complete Sign Up to create your own groups",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                Text(
                                    text = "Upgrade",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Amber500
                                )
                            }
                        }
                    }
                }
            }
        }

        // =================================================================
        // 2. MY GROUPS SECTION (Cleaned up as instructed)
        // =================================================================
        item {
            SectionHeader(title = "MY GROUPS")
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    // Create New Group
                    if (isSignedUpUser) {
                        MoreOptionRow(
                            icon = Icons.Default.Add,
                            iconTint = Emerald500,
                            title = "Create New Group",
                            subtitle = "Start a new savings, welfare, or investment society",
                            onClick = { onNavigateToCreateGroup() }
                        )
                    } else {
                        // Protected for Join-Code user with clear explanation
                        MoreOptionRow(
                            icon = Icons.Default.Lock,
                            iconTint = MaterialTheme.colorScheme.onSurfaceVariant,
                            title = "Create New Group",
                            subtitle = "Sign Up required: Complete registration to create groups",
                            isLockProtected = true,
                            onClick = { showCompleteSignUpDialog = true }
                        )
                    }
                }
            }
        }

        // =================================================================
        // 3. MEMBER & GROUP MANAGEMENT SECTION (Visible to Group Admin only)
        // =================================================================
        if (isGroupAdmin) {
            item {
                SectionHeader(title = "MEMBER & GROUP MANAGEMENT")
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column {
                        MoreOptionRow(
                            icon = Icons.Default.Groups,
                            iconTint = MaterialTheme.colorScheme.primary,
                            title = "Manage Society Members",
                            subtitle = "View ${members.size} active members, update details and profiles",
                            onClick = onNavigateToMembers
                        )
                        MoreDivider()

                        MoreOptionRow(
                            icon = Icons.Default.GroupAdd,
                            iconTint = Emerald500,
                            title = "Add New Member",
                            subtitle = "Register a new member in ${settings.groupName}",
                            onClick = onNavigateToAddMember
                        )
                        MoreDivider()

                        MoreOptionRow(
                            icon = Icons.Default.Key,
                            iconTint = Amber500,
                            title = "Group Joining Code: ${settings.inviteCode}",
                            subtitle = "Share joining code with members or generate a new code",
                            onClick = { showGroupJoiningCodeDialog = true }
                        )
                        MoreDivider()

                        MoreOptionRow(
                            icon = Icons.Default.VerifiedUser,
                            iconTint = Emerald500,
                            title = "Pre-Authorized Members (${preAuthorizedMembers.size})",
                            subtitle = "Pre-add members by email so they auto-join instantly with invite code",
                            badgeCount = if (preAuthorizedMembers.isNotEmpty()) preAuthorizedMembers.size else null,
                            onClick = { showPreAuthorizedMembersDialog = true }
                        )
                        MoreDivider()

                        MoreOptionRow(
                            icon = Icons.Default.HowToReg,
                            iconTint = Color(0xFFF59E0B),
                            title = "Pending Join Requests",
                            subtitle = "Review and approve/reject join requests (${pendingJoinRequests.size} pending)",
                            badgeCount = if (pendingJoinRequests.isNotEmpty()) pendingJoinRequests.size else null,
                            onClick = { showPendingRequestsDialog = true }
                        )
                        if (settings.createdByUserId == effectiveUserId) {
                            MoreDivider()
                            MoreOptionRow(
                                icon = Icons.Default.Edit,
                                iconTint = IndigoPrimary,
                                title = "Edit Group Details",
                                subtitle = "Modify name, monthly dues, fines, rules and settings for ${settings.groupName}",
                                onClick = { onNavigateToEditGroup(settings.id) }
                            )
                            MoreDivider()
                            MoreOptionRow(
                                icon = Icons.Default.Delete,
                                iconTint = Rose500,
                                title = "Delete Group / Society",
                                subtitle = "Permanently delete ${settings.groupName} and all associated ledger data",
                                onClick = { groupToDelete = settings }
                            )
                        }
                    }
                }
            }
        }

        // =================================================================
        // 4. SETTINGS SECTION
        // =================================================================
        item {
            SectionHeader(title = "SETTINGS")
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    // Group Settings: Editable for Admin, Read-Only dialog for regular Member
                    if (isGroupAdmin) {
                        MoreOptionRow(
                            icon = Icons.Default.Settings,
                            iconTint = MaterialTheme.colorScheme.primary,
                            title = "Group Settings",
                            subtitle = "Society name, dues, fine rules, modules & contact info",
                            onClick = {
                                viewModel.requestAdminAction {
                                    onNavigateToSettings()
                                }
                            }
                        )
                    } else {
                        MoreOptionRow(
                            icon = Icons.Default.Visibility,
                            iconTint = MaterialTheme.colorScheme.primary,
                            title = "Group Details & Rules (Read-Only)",
                            subtitle = "View dues, due date, late fees & society policy",
                            onClick = { showReadOnlyGroupSettingsDialog = true }
                        )
                    }
                    MoreDivider()

                    // Theme & Appearance
                    MoreOptionRow(
                        icon = Icons.Default.Palette,
                        iconTint = Color(0xFF8B5CF6),
                        title = "App Theme & Appearance",
                        subtitle = "Current: ${settings.themeMode.replaceFirstChar { it.uppercase() }} mode",
                        onClick = { showThemeDialog = true }
                    )
                }
            }
        }

        // =================================================================
        // 5. FINANCE & LEDGER SECTION
        // =================================================================
        item {
            SectionHeader(title = "FINANCE & LEDGER")
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    MoreOptionRow(
                        icon = Icons.AutoMirrored.Filled.MenuBook,
                        iconTint = MaterialTheme.colorScheme.primary,
                        title = "Transaction Ledger",
                        subtitle = "Complete chronological credit & debit audit trail",
                        onClick = onNavigateToLedger
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.Default.CalendarMonth,
                        iconTint = Emerald500,
                        title = "Monthly Collection Matrix",
                        subtitle = "Month-by-month member payment breakdown and status",
                        onClick = onNavigateToMonthly
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.Default.Payments,
                        iconTint = Rose500,
                        title = "Pending Dues & Reminders",
                        subtitle = "Track unpaid balances and trigger WhatsApp alerts",
                        onClick = onNavigateToDues
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.Default.Handshake,
                        iconTint = Amber500,
                        title = "Loans & 70% Voting",
                        subtitle = "Apply, view active loans and cast member approval votes",
                        badgeCount = if (pendingLoansCount > 0) pendingLoansCount else null,
                        onClick = onNavigateToLoans
                    )
                    MoreDivider()

                    MoreOptionRow(
                        icon = Icons.Default.TrendingUp,
                        iconTint = Color(0xFF3B82F6),
                        title = "Investment Portfolio",
                        subtitle = "Track fixed deposits, land, community assets and returns",
                        onClick = onNavigateToInvestments
                    )
                }
            }
        }

        // =================================================================
        // 6. COMMUNITY & GOVERNANCE SECTION
        // =================================================================
        item {
            SectionHeader(title = "COMMUNITY & GOVERNANCE")
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    MoreOptionRow(
                        icon = Icons.Default.Feedback,
                        iconTint = Color(0xFF8B5CF6),
                        title = "Proposals, Suggestions & Complaints",
                        subtitle = "Submit society proposals and upvote community ideas",
                        onClick = onNavigateToFeedback
                    )
                }
            }
        }

        // =================================================================
        // 7. DATA & SYSTEM SECTION
        // =================================================================
        item {
            SectionHeader(title = "DATA & SYSTEM")
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    MoreOptionRow(
                        icon = Icons.Default.Backup,
                        iconTint = Emerald500,
                        title = "Backup & Restore Database",
                        subtitle = "Export or restore complete JSON database backup",
                        isLockProtected = !isGroupAdmin,
                        onClick = {
                            viewModel.requestAdminAction {
                                onNavigateToBackup()
                            }
                        }
                    )
                    MoreDivider()
                    MoreOptionRow(
                        icon = Icons.Default.SystemUpdate,
                        iconTint = IndigoPrimary,
                        title = "App Update Service",
                        subtitle = if (updateStatus is UpdateCheckStatus.UpdateAvailable) {
                            "✨ New version available: v${(updateStatus as UpdateCheckStatus.UpdateAvailable).updateInfo.versionName}"
                        } else {
                            "Current: v${viewModel.currentVersionName} • Check for releases & patches"
                        },
                        badgeCount = if (updateStatus is UpdateCheckStatus.UpdateAvailable) 1 else null,
                        onClick = {
                            showAppUpdateDialog = true
                        }
                    )
                }
            }
        }

        // =================================================================
        // 8. ACCOUNT SECTION (Cleaned up as instructed)
        // =================================================================
        item {
            SectionHeader(title = "ACCOUNT")
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    // Distinct Red / Destructive Sign Out Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showSignOutConfirm = true }
                            .padding(horizontal = 16.dp, vertical = 13.dp)
                            .testTag("sign_out_btn"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Rose500.copy(alpha = 0.12f),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Logout,
                                    contentDescription = "Sign Out",
                                    tint = Rose500,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Sign Out",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Rose500
                            )
                            Spacer(modifier = Modifier.height(1.dp))
                            Text(
                                text = "Exit current session and return to welcome login screen",
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = Rose500.copy(alpha = 0.6f),
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }
        }

        // App Info Footer
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showAppUpdateDialog = true }
                    .padding(vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "${settings.groupName} • v${viewModel.currentVersionName}",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Encrypted Local Database & Cloud Firestore Sync • Tap for updates",
                    fontSize = 10.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }
    }

    // =================================================================
    // DIALOGS AND MODALS
    // =================================================================

    // 1. GROUPS I MANAGE DIALOG (Indigo / Brand theme with Edit & Delete options)
    if (showManagedGroupsDialog) {
        AlertDialog(
            onDismissRequest = { showManagedGroupsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Groups I Manage", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                        Text("${managedGroups.size} managed societies", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 420.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (managedGroups.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.AdminPanelSettings,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "No groups managed yet",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Create a society / group to begin managing members and dues.",
                                    fontSize = 11.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            itemsIndexed(managedGroups) { index, group ->
                                val isActive = group.id == settings.id
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                    ),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                    )
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    if (!isActive) {
                                                        viewModel.switchGroup(group.id)
                                                        Toast.makeText(context, "Switched to ${group.groupName}", Toast.LENGTH_SHORT).show()
                                                    }
                                                    showManagedGroupsDialog = false
                                                },
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Surface(
                                                shape = CircleShape,
                                                color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Text(
                                                        text = "${index + 1}",
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 12.sp,
                                                        color = if (isActive) Color.White else MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                            }

                                            Spacer(modifier = Modifier.width(10.dp))

                                            Column(modifier = Modifier.weight(1f)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(
                                                        text = group.groupName,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 13.5.sp,
                                                        color = MaterialTheme.colorScheme.onSurface,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis,
                                                        modifier = Modifier.weight(1f, fill = false)
                                                    )
                                                    if (isActive) {
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Surface(
                                                            shape = RoundedCornerShape(4.dp),
                                                            color = Emerald500.copy(alpha = 0.15f)
                                                        ) {
                                                            Text(
                                                                text = "Active",
                                                                fontSize = 9.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = Emerald500,
                                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                            )
                                                        }
                                                    }
                                                }
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = group.groupSubtitle.ifBlank { "Code: ${group.inviteCode} • Dues: ${group.currencySymbol}${group.defaultContribution.toInt()} • Type: ${group.groupType.ifBlank { "Society" }}" },
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f), thickness = 0.5.dp)
                                        Spacer(modifier = Modifier.height(6.dp))

                                        // Action buttons: Switch (if not active), Edit, Delete
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            if (!isActive) {
                                                OutlinedButton(
                                                    onClick = {
                                                        viewModel.switchGroup(group.id)
                                                        Toast.makeText(context, "Switched to ${group.groupName}", Toast.LENGTH_SHORT).show()
                                                        showManagedGroupsDialog = false
                                                    },
                                                    shape = RoundedCornerShape(6.dp),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                    modifier = Modifier.height(30.dp)
                                                ) {
                                                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(13.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Switch", fontSize = 11.sp)
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                            }

                                            // Edit Button
                                            FilledTonalButton(
                                                onClick = {
                                                    showManagedGroupsDialog = false
                                                    onNavigateToEditGroup(group.id)
                                                },
                                                shape = RoundedCornerShape(6.dp),
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                modifier = Modifier.height(30.dp)
                                            ) {
                                                Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(13.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Edit", fontSize = 11.sp)
                                            }

                                            Spacer(modifier = Modifier.width(8.dp))

                                            // Delete Button
                                            FilledTonalButton(
                                                onClick = {
                                                    groupToDelete = group
                                                },
                                                shape = RoundedCornerShape(6.dp),
                                                colors = ButtonDefaults.filledTonalButtonColors(
                                                    containerColor = Rose500.copy(alpha = 0.12f),
                                                    contentColor = Rose500
                                                ),
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                modifier = Modifier.height(30.dp)
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = "Delete", modifier = Modifier.size(13.dp), tint = Rose500)
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Delete", fontSize = 11.sp, color = Rose500)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Button(
                        onClick = {
                            showManagedGroupsDialog = false
                            onNavigateToCreateGroup()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Create New Group / Society", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showManagedGroupsDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // DELETE GROUP CONFIRMATION DIALOG (With safety prompt)
    if (groupToDelete != null) {
        val group = groupToDelete!!
        AlertDialog(
            onDismissRequest = { groupToDelete = null },
            icon = {
                Surface(
                    shape = CircleShape,
                    color = Rose500.copy(alpha = 0.12f),
                    modifier = Modifier.size(48.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.DeleteForever,
                            contentDescription = null,
                            tint = Rose500,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            },
            title = {
                Text(
                    text = "Delete Group / Society?",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Are you sure you want to delete \"${group.groupName}\"?",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "All member records, monthly dues, financial transactions, loans, investments, and notices belonging to this group will be permanently removed. This action cannot be undone.",
                        fontSize = 12.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 17.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val groupId = group.id
                        val groupName = group.groupName
                        groupToDelete = null
                        showManagedGroupsDialog = false
                        viewModel.deleteGroup(groupId) {
                            Toast.makeText(context, "Group '$groupName' deleted successfully", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Delete Group", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { groupToDelete = null },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // 2. JOIN GROUPS / ALL GROUPS DIALOG (Displays ALL groups: joined + created, and allows switching)
    if (showJoinedGroupsDialog) {
        AlertDialog(
            onDismissRequest = { showJoinedGroupsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = Amber500.copy(alpha = 0.15f),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Groups,
                                contentDescription = null,
                                tint = Color(0xFFD97706),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Join Groups", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                        Text("${allUserGroups.size} societies (Created & Joined) • Tap to switch", fontSize = 11.sp, color = Color(0xFFB45309))
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (allUserGroups.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.Groups,
                                    contentDescription = null,
                                    tint = Amber500.copy(alpha = 0.4f),
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "No groups available",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "You can join societies using the invitation code shared by the society administrator.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            itemsIndexed(allUserGroups) { index, group ->
                                val isActive = group.id == settings.id
                                val isManaged = managedGroups.any { it.id == group.id }
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (!isActive) {
                                                viewModel.switchGroup(group.id)
                                                Toast.makeText(context, "Switched to ${group.groupName}", Toast.LENGTH_SHORT).show()
                                            }
                                            showJoinedGroupsDialog = false
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // Numbering 1, 2, 3...
                                        Surface(
                                            shape = CircleShape,
                                            color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                            modifier = Modifier.size(26.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = "${index + 1}",
                                                    fontSize = 11.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isActive) Color.White else MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(10.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = group.groupName,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.5.sp,
                                                    color = MaterialTheme.colorScheme.onSurface,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = if (isManaged) Emerald500.copy(alpha = 0.15f) else Amber500.copy(alpha = 0.15f)
                                                ) {
                                                    Text(
                                                        text = if (isManaged) "Admin" else "Member",
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (isManaged) Emerald500 else Color(0xFFB45309),
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                    )
                                                }
                                                if (isActive) {
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = MaterialTheme.colorScheme.primary
                                                    ) {
                                                        Text(
                                                            text = "Active",
                                                            fontSize = 9.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color.White,
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                        )
                                                    }
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "Code: ${group.inviteCode} • Admin: ${group.adminName} • Dues: ${group.currencySymbol}${group.defaultContribution.toInt()}",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }

                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                            contentDescription = "Switch",
                                            tint = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showJoinedGroupsDialog = false }) {
                    Text("Close", color = MaterialTheme.colorScheme.primary)
                }
            }
        )
    }

    // 3. Profile Details & Edit Modal
    if (showProfileModal) {
        val defaultName = currentUser?.fullName?.takeIf { it.isNotBlank() } ?: currentMember?.name ?: ""
        val defaultEmail = currentUser?.email?.takeIf { !it.contains("@groupledger.org") } ?: currentMember?.email ?: ""
        val defaultPhone = currentUser?.phone?.takeIf { it.isNotBlank() } ?: currentMember?.phone ?: ""

        var editName by remember { mutableStateOf(defaultName) }
        var editEmail by remember { mutableStateOf(defaultEmail) }
        var editPhone by remember { mutableStateOf(defaultPhone) }
        var isSaving by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showProfileModal = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AccountCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("User Profile Details", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Account Type Badge
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSignedUpUser) Emerald500.copy(alpha = 0.1f) else Amber500.copy(alpha = 0.1f),
                        border = BorderStroke(1.dp, if (isSignedUpUser) Emerald500.copy(alpha = 0.3f) else Amber500.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isSignedUpUser) Icons.Default.VerifiedUser else Icons.Default.Key,
                                contentDescription = null,
                                tint = if (isSignedUpUser) Emerald500 else Amber500,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = if (isSignedUpUser) "Registered Full Account" else "Guest Join-Code Account",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.5.sp,
                                    color = if (isSignedUpUser) Emerald500 else Amber500
                                )
                                Text(
                                    text = if (isSignedUpUser) "Can create, manage, and join societies" else "Joined via code. Can edit personal profile or upgrade anytime.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Full Name") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                        colors = appOutlinedTextFieldColors(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = editEmail,
                        onValueChange = { editEmail = it },
                        label = { Text("Email Address") },
                        leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                        colors = appOutlinedTextFieldColors(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = editPhone,
                        onValueChange = { editPhone = it },
                        label = { Text("Phone Number") },
                        leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        colors = appOutlinedTextFieldColors(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (!isSignedUpUser) {
                        Button(
                            onClick = {
                                showProfileModal = false
                                showCompleteSignUpDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Amber500),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.AppRegistration, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Upgrade to Full Account", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isSaving = true
                        viewModel.updateUserProfile(
                            fullName = editName,
                            email = editEmail,
                            phone = editPhone,
                            onSuccess = {
                                isSaving = false
                                showProfileModal = false
                            },
                            onError = {
                                isSaving = false
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    enabled = !isSaving && editName.isNotBlank()
                ) {
                    Text("Save Changes")
                }
            },
            dismissButton = {
                TextButton(onClick = { showProfileModal = false }) {
                    Text("Close")
                }
            }
        )
    }

    // 4. Complete Sign Up Dialog (For upgrading Join-Code users to Full Accounts)
    if (showCompleteSignUpDialog) {
        var suName by remember { mutableStateOf(currentUser?.fullName ?: "") }
        var suEmail by remember { mutableStateOf(if (currentUser?.email?.contains("@groupledger.org") == true) "" else (currentUser?.email ?: "")) }
        var suPassword by remember { mutableStateOf("") }
        var suPhone by remember { mutableStateOf(currentUser?.phone ?: "") }
        var suError by remember { mutableStateOf<String?>(null) }
        var suLoading by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { if (!suLoading) showCompleteSignUpDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AppRegistration, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Complete Your Registration", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Create a password and complete your profile so you can create and administer your own groups.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    suError?.let { err ->
                        Text(text = err, color = Rose500, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }

                    OutlinedTextField(
                        value = suName,
                        onValueChange = { suName = it },
                        label = { Text("Full Name *") },
                        colors = appOutlinedTextFieldColors(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = suEmail,
                        onValueChange = { suEmail = it },
                        label = { Text("Email Address *") },
                        colors = appOutlinedTextFieldColors(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = suPhone,
                        onValueChange = { suPhone = it },
                        label = { Text("Phone Number") },
                        colors = appOutlinedTextFieldColors(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = suPassword,
                        onValueChange = { suPassword = it },
                        label = { Text("Create Password (min 6 chars) *") },
                        visualTransformation = PasswordVisualTransformation(),
                        colors = appOutlinedTextFieldColors(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (suName.isBlank() || suEmail.isBlank() || suPassword.length < 6) {
                            suError = "Please fill in all required fields (password minimum 6 chars)"
                            return@Button
                        }
                        suLoading = true
                        suError = null
                        viewModel.completeGuestSignUp(
                            fullName = suName,
                            email = suEmail,
                            password = suPassword,
                            phone = suPhone,
                            onSuccess = {
                                suLoading = false
                                showCompleteSignUpDialog = false
                            },
                            onError = { err: String ->
                                suLoading = false
                                suError = err
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    enabled = !suLoading
                ) {
                    Text(if (suLoading) "Upgrading..." else "Complete Registration")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showCompleteSignUpDialog = false },
                    enabled = !suLoading
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // 5. Group Joining Code Modal (For Admins to share & regenerate)
    if (showGroupJoiningCodeDialog) {
        val inviteCode = settings.inviteCode
        var copied by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showGroupJoiningCodeDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Key, contentDescription = null, tint = Amber500, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Group Joining Code", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Share this 6-character code with new members so they can join '${settings.groupName}'.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )

                    // Big Display Box for Code
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = inviteCode,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 6.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    // Action Buttons: Copy & Share
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(inviteCode))
                                copied = true
                                Toast.makeText(context, "Code copied: $inviteCode", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(if (copied) Icons.Default.Check else Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (copied) "Copied!" else "Copy Code", fontSize = 12.5.sp)
                        }

                        Button(
                            onClick = {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(
                                        Intent.EXTRA_TEXT,
                                        "Join our society '${settings.groupName}' on Group Ledger!\n\nYour Joining Code: $inviteCode\n\nEnter this code in the app to join our group."
                                    )
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share Joining Code"))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Emerald500),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share Code", fontSize = 12.5.sp)
                        }
                    }

                    // Regenerate Code Option (Creator only)
                    if (settings.createdByUserId == effectiveUserId) {
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable {
                                    viewModel.regenerateGroupInviteCode()
                                }
                                .padding(vertical = 6.dp, horizontal = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Regenerate New Code", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showGroupJoiningCodeDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // 6. Read-Only Group Settings Modal (For regular members)
    if (showReadOnlyGroupSettingsDialog) {
        AlertDialog(
            onDismissRequest = { showReadOnlyGroupSettingsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Visibility, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Group Details & Rules", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            },
            text = {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Read-Only: These parameters are managed by your society administrator.",
                                    fontSize = 11.5.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }

                    item { ReadOnlyDetailRow("Society Name", settings.groupName) }
                    item { ReadOnlyDetailRow("Subtitle", settings.groupSubtitle.ifBlank { "Monthly Savings & Contribution Society" }) }
                    item { ReadOnlyDetailRow("Group Type", settings.groupType) }
                    item { ReadOnlyDetailRow("Monthly Dues", "${settings.currencySymbol}${settings.defaultContribution.toInt()} / member") }
                    item { ReadOnlyDetailRow("Frequency", settings.contributionFrequency) }
                    item { ReadOnlyDetailRow("Payment Due Day", "Day ${settings.dueDayOfMonth} of every month") }
                    item {
                        ReadOnlyDetailRow(
                            "Late Fine Policy",
                            if (settings.isLateFeeEnabled) "${settings.currencySymbol}${settings.lateFineAmount.toInt()} after ${settings.gracePeriodDays} days grace period" else "No late fine enabled"
                        )
                    }
                    item { ReadOnlyDetailRow("Society Admin", "${settings.adminName} • ${settings.adminPhone}") }
                    item { ReadOnlyDetailRow("Society Rules", settings.paymentRules) }
                }
            },
            confirmButton = {
                TextButton(onClick = { showReadOnlyGroupSettingsDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // 8. Theme Selection Dialog
    if (showThemeDialog) {
        val currentTheme = settings.themeMode

        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Palette, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("App Theme Mode", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    listOf(
                        Triple("SYSTEM", "System Default", Icons.Default.BrightnessAuto),
                        Triple("LIGHT", "Light Theme", Icons.Default.LightMode),
                        Triple("DARK", "Dark Theme", Icons.Default.DarkMode)
                    ).forEach { (mode, label, icon) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    viewModel.setThemeMode(mode)
                                    showThemeDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = currentTheme.equals(mode, ignoreCase = true),
                                onClick = {
                                    viewModel.setThemeMode(mode)
                                    showThemeDialog = false
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.primary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(label, fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showThemeDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // 9. Sign Out Confirmation Dialog
    if (showSignOutConfirm) {
        AlertDialog(
            onDismissRequest = { showSignOutConfirm = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = Rose500, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Confirm Sign Out", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            },
            text = {
                Text(
                    text = "Are you sure you want to sign out of '${settings.groupName}'? You can sign back in anytime using your registered email or invitation code.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSignOutConfirm = false
                        viewModel.logout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Rose500)
                ) {
                    Text("Sign Out", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSignOutConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // 10. Pre-Authorized Members Management Dialog (Admin Side)
    if (showPreAuthorizedMembersDialog) {
        var newMemberName by remember { mutableStateOf("") }
        var newMemberEmail by remember { mutableStateOf("") }
        var newMemberPhone by remember { mutableStateOf("") }
        var isAdding by remember { mutableStateOf(false) }
        var addError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showPreAuthorizedMembersDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = Emerald500.copy(alpha = 0.15f),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.VerifiedUser,
                                contentDescription = null,
                                tint = Emerald500,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Pre-Authorized Members",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Invite code: ${settings.inviteCode}",
                            fontSize = 11.sp,
                            color = Emerald500,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 480.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Pre-authorize members by their email address. When they enter group invite code (${settings.inviteCode}), they will join instantly without waiting for admin approval.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 16.sp
                    )

                    // Add New Pre-Authorized Member Form Card
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "Pre-Add New Member",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.5.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            OutlinedTextField(
                                value = newMemberName,
                                onValueChange = { newMemberName = it; addError = null },
                                label = { Text("Member Full Name *") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                colors = appOutlinedTextFieldColors()
                            )

                            OutlinedTextField(
                                value = newMemberEmail,
                                onValueChange = { newMemberEmail = it; addError = null },
                                label = { Text("Email Address *") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                colors = appOutlinedTextFieldColors()
                            )

                            OutlinedTextField(
                                value = newMemberPhone,
                                onValueChange = { newMemberPhone = it },
                                label = { Text("Phone Number (Optional)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                colors = appOutlinedTextFieldColors()
                            )

                            if (addError != null) {
                                Text(
                                    text = addError!!,
                                    color = Rose500,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            Button(
                                onClick = {
                                    if (newMemberName.isBlank()) {
                                        addError = "Please enter member name"
                                        return@Button
                                    }
                                    if (newMemberEmail.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(newMemberEmail.trim()).matches()) {
                                        addError = "Please enter a valid email"
                                        return@Button
                                    }
                                    isAdding = true
                                    viewModel.addPreAuthorizedMember(
                                        name = newMemberName,
                                        email = newMemberEmail,
                                        phone = newMemberPhone,
                                        onSuccess = {
                                            isAdding = false
                                            newMemberName = ""
                                            newMemberEmail = ""
                                            newMemberPhone = ""
                                            addError = null
                                            Toast.makeText(context, "Member pre-authorized successfully", Toast.LENGTH_SHORT).show()
                                        },
                                        onError = { err ->
                                            isAdding = false
                                            addError = err
                                        }
                                    )
                                },
                                enabled = !isAdding,
                                colors = ButtonDefaults.buttonColors(containerColor = Emerald500),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (isAdding) "Adding..." else "Pre-Authorize Member", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }

                    // Existing Pre-Authorized Members List
                    Text(
                        text = "Pre-Authorized List (${preAuthorizedMembers.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(top = 4.dp)
                    )

                    if (preAuthorizedMembers.isEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        ) {
                            Text(
                                text = "No pre-authorized members yet. Add members above so they can join directly using invite code ${settings.inviteCode}.",
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    } else {
                        preAuthorizedMembers.forEach { item ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = item.name,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.5.sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = if (item.status.equals("claimed", ignoreCase = true)) Emerald500.copy(alpha = 0.15f) else Amber500.copy(alpha = 0.15f)
                                            ) {
                                                Text(
                                                    text = if (item.status.equals("claimed", ignoreCase = true)) "Claimed" else "Unclaimed",
                                                    fontSize = 8.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (item.status.equals("claimed", ignoreCase = true)) Emerald500 else Amber500,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            text = item.email + if (item.phone.isNotBlank()) " • ${item.phone}" else "",
                                            fontSize = 10.5.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            viewModel.deletePreAuthorizedMember(item.id) {
                                                Toast.makeText(context, "Entry removed", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete",
                                            tint = Rose500,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPreAuthorizedMembersDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // 11. Pending Join Requests Review Dialog (Admin Side)
    if (showPendingRequestsDialog) {
        AlertDialog(
            onDismissRequest = { showPendingRequestsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFFF59E0B).copy(alpha = 0.15f),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.HowToReg,
                                contentDescription = null,
                                tint = Color(0xFFF59E0B),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Pending Join Requests",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${pendingJoinRequests.size} requests awaiting review",
                            fontSize = 11.sp,
                            color = Color(0xFFF59E0B),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 420.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (pendingJoinRequests.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = Emerald500.copy(alpha = 0.5f),
                                    modifier = Modifier.size(40.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "All Caught Up!",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "There are no pending join requests for ${settings.groupName}.",
                                    fontSize = 11.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        pendingJoinRequests.forEach { req ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                border = BorderStroke(0.75.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = req.applicantName,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.5.sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = req.applicantEmail + if (req.applicantPhone.isNotBlank()) " • ${req.applicantPhone}" else "",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Text(
                                                text = "Applied on: ${req.requestDate}",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f), thickness = 0.5.dp)
                                    Spacer(modifier = Modifier.height(6.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedButton(
                                            onClick = {
                                                viewModel.rejectJoinRequest(req.id) {
                                                    Toast.makeText(context, "Request rejected", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            shape = RoundedCornerShape(6.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Rose500),
                                            border = BorderStroke(1.dp, Rose500.copy(alpha = 0.4f)),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                            modifier = Modifier.height(30.dp)
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(13.dp), tint = Rose500)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Reject", fontSize = 11.sp, color = Rose500)
                                        }

                                        Spacer(modifier = Modifier.width(8.dp))

                                        Button(
                                            onClick = {
                                                viewModel.approveJoinRequest(req.id) {
                                                    Toast.makeText(context, "Approved! ${req.applicantName} added to group", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            shape = RoundedCornerShape(6.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Emerald500),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                            modifier = Modifier.height(30.dp)
                                        ) {
                                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(13.dp), tint = Color.White)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Approve", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPendingRequestsDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // 12. App Update Service Dialog
    if (showAppUpdateDialog) {
        AppUpdateDialog(
            viewModel = viewModel,
            updateStatus = updateStatus,
            currentVersionName = viewModel.currentVersionName,
            currentVersionCode = viewModel.currentVersionCode,
            lastCheckedTime = lastCheckedTime,
            isAdmin = isGroupAdmin,
            onDismissRequest = { showAppUpdateDialog = false }
        )
    }
}

// =================================================================
// REUSABLE UI HELPER COMPONENTS
// =================================================================

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        letterSpacing = 0.8.sp,
        modifier = Modifier.padding(start = 4.dp, top = 2.dp)
    )
}

@Composable
fun MoreOptionRow(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    badgeCount: Int? = null,
    isLockProtected: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = iconTint.copy(alpha = 0.12f),
            modifier = Modifier.size(38.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.5.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (isLockProtected) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        Icons.Default.Lock,
                        contentDescription = "Protected",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(1.dp))
            Text(
                text = subtitle,
                fontSize = 11.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 15.sp
            )
        }

        if (badgeCount != null && badgeCount > 0) {
            Surface(
                shape = CircleShape,
                color = Rose500,
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Text(
                    text = "$badgeCount",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
        }

        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier.size(15.dp)
        )
    }
}

@Composable
fun MoreDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(horizontal = 16.dp),
        thickness = 0.75.dp,
        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
    )
}

@Composable
private fun ReadOnlyDetailRow(label: String, value: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
