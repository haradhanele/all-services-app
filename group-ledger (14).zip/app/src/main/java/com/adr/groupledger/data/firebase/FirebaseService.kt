package com.adr.groupledger.data.firebase

import android.content.Context
import android.util.Log
import com.adr.groupledger.data.model.AppUpdateInfo
import com.adr.groupledger.data.model.GroupChatMessage
import com.adr.groupledger.data.model.GroupJoinRequest
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.LoanRequest
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.Payment
import com.adr.groupledger.data.model.PreAuthorizedMember
import com.adr.groupledger.data.model.SocietyNotice
import com.adr.groupledger.data.model.TransactionRecord
import com.adr.groupledger.data.model.UserAccount
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

/**
 * FirebaseService provides real-time Firebase Authentication (Email & Password, Password Reset)
 * and Cloud Firestore real-time synchronization for Users, Groups, Members, and Ledger Transactions.
 */
class FirebaseService(private val context: Context) {

    private val TAG = "FirebaseService"

    private val auth: FirebaseAuth? by lazy {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }
            FirebaseAuth.getInstance()
        } catch (e: Exception) {
            Log.w(TAG, "FirebaseAuth initialization: ${e.message}")
            null
        }
    }

    private val firestore: FirebaseFirestore? by lazy {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.w(TAG, "FirebaseFirestore initialization: ${e.message}")
            null
        }
    }

    val isFirebaseAvailable: Boolean
        get() = auth != null && firestore != null

    val currentFirebaseUser: FirebaseUser?
        get() = auth?.currentUser

    // -------------------------------------------------------------
    // Firebase Authentication: Email & Password, Reset
    // -------------------------------------------------------------

    suspend fun signUpWithEmail(
        email: String,
        password: String,
        displayName: String,
        phone: String = ""
    ): Result<UserAccount> {
        val trimmedEmail = email.trim()
        val trimmedPhone = phone.trim()
        val authInstance = auth
        if (authInstance == null) {
            val fallbackUser = UserAccount(
                fullName = displayName.trim(),
                email = trimmedEmail,
                phone = trimmedPhone,
                passwordHash = password,
                isAccountCompleted = true
            )
            return Result.success(fallbackUser)
        }

        return try {
            val result = authInstance.createUserWithEmailAndPassword(trimmedEmail, password).await()
            val firebaseUser = result.user

            if (firebaseUser != null && displayName.isNotBlank()) {
                try {
                    val profileUpdates = UserProfileChangeRequest.Builder()
                        .setDisplayName(displayName.trim())
                        .build()
                    firebaseUser.updateProfile(profileUpdates).await()
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to update Firebase display name: ${e.message}")
                }
            }

            val userAccount = UserAccount(
                id = (firebaseUser?.uid.hashCode().toLong() and 0x7FFFFFFFFFFFFFFFL).coerceAtLeast(1L),
                fullName = displayName.trim().ifBlank { firebaseUser?.displayName ?: "Member" },
                email = trimmedEmail,
                phone = trimmedPhone.ifBlank { firebaseUser?.phoneNumber ?: "" },
                passwordHash = "FIREBASE_AUTH_SECURED",
                isAccountCompleted = true
            )

            // Save user profile to Cloud Firestore
            saveUser(userAccount)

            Result.success(userAccount)
        } catch (e: Exception) {
            Log.e(TAG, "Firebase signUp error", e)
            Result.failure(e)
        }
    }

    suspend fun signInWithEmail(
        email: String,
        password: String
    ): Result<UserAccount> {
        val trimmedEmail = email.trim()
        val authInstance = auth
        if (authInstance == null) {
            val fallbackUser = UserAccount(
                fullName = trimmedEmail.substringBefore("@").replaceFirstChar { it.uppercase() },
                email = trimmedEmail,
                passwordHash = password,
                isAccountCompleted = true
            )
            return Result.success(fallbackUser)
        }

        return try {
            val result = authInstance.signInWithEmailAndPassword(trimmedEmail, password).await()
            val firebaseUser = result.user

            val userAccount = UserAccount(
                id = (firebaseUser?.uid.hashCode().toLong() and 0x7FFFFFFFFFFFFFFFL).coerceAtLeast(1L),
                fullName = firebaseUser?.displayName ?: trimmedEmail.substringBefore("@").replaceFirstChar { it.uppercase() },
                email = firebaseUser?.email ?: trimmedEmail,
                phone = firebaseUser?.phoneNumber ?: "",
                passwordHash = "FIREBASE_AUTH_SECURED",
                isAccountCompleted = true
            )

            // Sync user profile to Cloud Firestore
            saveUser(userAccount)

            Result.success(userAccount)
        } catch (e: Exception) {
            Log.e(TAG, "Firebase signIn error", e)
            Result.failure(e)
        }
    }

    suspend fun sendPasswordResetEmail(email: String): Result<Unit> {
        val trimmedEmail = email.trim()
        val authInstance = auth
        if (authInstance == null) {
            return Result.success(Unit)
        }

        return try {
            authInstance.sendPasswordResetEmail(trimmedEmail).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Firebase sendPasswordResetEmail error", e)
            Result.failure(e)
        }
    }

    fun signOut() {
        try {
            auth?.signOut()
        } catch (e: Exception) {
            Log.w(TAG, "Sign out error", e)
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Users
    // -------------------------------------------------------------

    suspend fun saveUser(user: UserAccount) {
        val db = firestore ?: return
        try {
            val currentAuthUid = auth?.currentUser?.uid ?: user.id.toString()
            val map = hashMapOf(
                "id" to user.id,
                "uid" to currentAuthUid,
                "fullName" to user.fullName,
                "email" to user.email,
                "phone" to user.phone,
                "avatarUri" to user.avatarUri,
                "isAccountCompleted" to user.isAccountCompleted,
                "createdAt" to user.createdAt
            )
            db.collection("users").document(user.id.toString()).set(map, SetOptions.merge()).await()
            if (currentAuthUid.isNotBlank() && currentAuthUid != user.id.toString()) {
                db.collection("users").document(currentAuthUid).set(map, SetOptions.merge()).await()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveUser error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Groups
    // -------------------------------------------------------------

    suspend fun saveGroup(group: GroupSettings) {
        val db = firestore ?: return
        try {
            val map = hashMapOf(
                "id" to group.id,
                "groupName" to group.groupName,
                "groupSubtitle" to group.groupSubtitle,
                "description" to group.description,
                "groupType" to group.groupType,
                "address" to group.address,
                "contactPhone" to group.contactPhone,
                "contactEmail" to group.contactEmail,
                "createdAt" to group.createdAt,
                "logoUri" to group.logoUri,
                "inviteCode" to group.inviteCode,
                "createdByUserId" to group.createdByUserId,
                "isContributionEnabled" to group.isContributionEnabled,
                "defaultContribution" to group.defaultContribution,
                "contributionFrequency" to group.contributionFrequency,
                "dueDayOfMonth" to group.dueDayOfMonth,
                "isLateFeeEnabled" to group.isLateFeeEnabled,
                "lateFineAmount" to group.lateFineAmount,
                "gracePeriodDays" to group.gracePeriodDays,
                "paymentRules" to group.paymentRules,
                "modulesConfigJson" to group.modulesConfigJson,
                "currencySymbol" to group.currencySymbol,
                "financialYearStartMonth" to group.financialYearStartMonth,
                "adminName" to group.adminName,
                "adminPhone" to group.adminPhone,
                "adminPin" to group.adminPin,
                "isPinLockEnabled" to group.isPinLockEnabled,
                "themeMode" to group.themeMode,
                "updatedAt" to System.currentTimeMillis()
            )
            db.collection("groups").document(group.id.toString()).set(map, SetOptions.merge()).await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveGroup error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Members
    // -------------------------------------------------------------

    suspend fun saveMember(member: Member) {
        val db = firestore ?: return
        try {
            val map = hashMapOf(
                "id" to member.id,
                "groupId" to member.groupId,
                "memberCode" to member.memberCode,
                "name" to member.name,
                "email" to member.email,
                "phone" to member.phone,
                "address" to member.address,
                "joinDate" to member.joinDate,
                "monthlyContribution" to member.monthlyContribution,
                "photoUri" to member.photoUri,
                "isActive" to member.isActive,
                "isClaimed" to member.isClaimed,
                "linkedUid" to member.linkedUid,
                "notes" to member.notes
            )
            db.collection("groups")
                .document(member.groupId.toString())
                .collection("members")
                .document(member.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveMember error: ${e.message}")
        }
    }

    suspend fun deleteMember(groupId: Long, memberId: Long) {
        val db = firestore ?: return
        try {
            db.collection("groups")
                .document(groupId.toString())
                .collection("members")
                .document(memberId.toString())
                .delete()
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore deleteMember error: ${e.message}")
        }
    }

    suspend fun getMembers(groupId: Long): List<Member> {
        val db = firestore ?: return emptyList()
        val resultList = mutableListOf<Member>()
        try {
            val snapshots = db.collection("groups")
                .document(groupId.toString())
                .collection("members")
                .get()
                .await()

            snapshots.documents.mapNotNullTo(resultList) { doc ->
                try {
                    Member(
                        id = doc.getLong("id") ?: (doc.id.toLongOrNull() ?: 0L),
                        groupId = doc.getLong("groupId") ?: groupId,
                        memberCode = doc.getString("memberCode") ?: "",
                        name = doc.getString("name") ?: "",
                        phone = doc.getString("phone") ?: "",
                        address = doc.getString("address") ?: "",
                        joinDate = doc.getLong("joinDate") ?: System.currentTimeMillis(),
                        monthlyContribution = doc.getDouble("monthlyContribution") ?: 0.0,
                        photoUri = doc.getString("photoUri") ?: "",
                        isActive = doc.getBoolean("isActive") ?: true,
                        notes = doc.getString("notes") ?: "",
                        email = doc.getString("email") ?: "",
                        isClaimed = doc.getBoolean("isClaimed") ?: false,
                        linkedUid = doc.getString("linkedUid") ?: ""
                    )
                } catch (e: Exception) {
                    null
                }
            }

            val groupDoc = db.collection("groups").document(groupId.toString()).get().await()
            val rawArray = groupDoc.get("members") as? List<*>
            rawArray?.forEach { item ->
                if (item is Map<*, *>) {
                    try {
                        val mId = (item["id"] as? Number)?.toLong() ?: 0L
                        if (resultList.none { it.id == mId }) {
                            resultList.add(
                                Member(
                                    id = mId,
                                    groupId = (item["groupId"] as? Number)?.toLong() ?: groupId,
                                    memberCode = item["memberCode"] as? String ?: "",
                                    name = item["name"] as? String ?: "",
                                    phone = item["phone"] as? String ?: "",
                                    address = item["address"] as? String ?: "",
                                    joinDate = (item["joinDate"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                                    monthlyContribution = (item["monthlyContribution"] as? Number)?.toDouble() ?: 0.0,
                                    photoUri = item["photoUri"] as? String ?: "",
                                    isActive = item["isActive"] as? Boolean ?: true,
                                    notes = item["notes"] as? String ?: "",
                                    email = item["email"] as? String ?: "",
                                    isClaimed = item["isClaimed"] as? Boolean ?: false,
                                    linkedUid = item["linkedUid"] as? String ?: ""
                                )
                            )
                        }
                    } catch (e: Exception) {
                        // ignore malformed member array element
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firestore getMembers error: ${e.message}")
        }
        return resultList
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Payments (Ledger Dues)
    // -------------------------------------------------------------

    suspend fun savePayment(payment: Payment) {
        val db = firestore ?: return
        try {
            val map = hashMapOf(
                "id" to payment.id,
                "groupId" to payment.groupId,
                "memberId" to payment.memberId,
                "month" to payment.month,
                "year" to payment.year,
                "expectedAmount" to payment.expectedAmount,
                "paidAmount" to payment.paidAmount,
                "dueAmount" to payment.dueAmount,
                "paymentDate" to payment.paymentDate,
                "paymentMethod" to payment.paymentMethod,
                "transactionReference" to payment.transactionReference,
                "notes" to payment.notes,
                "status" to payment.status,
                "approvalStatus" to payment.approvalStatus,
                "rejectionReason" to payment.rejectionReason,
                "approvedAt" to (payment.approvedAt ?: 0L),
                "approvedBy" to payment.approvedBy,
                "submittedAt" to payment.submittedAt
            )
            db.collection("groups")
                .document(payment.groupId.toString())
                .collection("payments")
                .document(payment.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore savePayment error: ${e.message}")
        }
    }

    suspend fun deletePayment(groupId: Long, paymentId: Long) {
        val db = firestore ?: return
        try {
            db.collection("groups")
                .document(groupId.toString())
                .collection("payments")
                .document(paymentId.toString())
                .delete()
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore deletePayment error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Transactions (Income / Expense Ledger)
    // -------------------------------------------------------------

    suspend fun saveTransaction(tx: TransactionRecord) {
        val db = firestore ?: return
        try {
            val map = hashMapOf(
                "id" to tx.id,
                "groupId" to tx.groupId,
                "txnNumber" to tx.txnNumber,
                "date" to tx.date,
                "amount" to tx.amount,
                "type" to tx.type,
                "isCredit" to tx.isCredit,
                "description" to tx.description,
                "paymentMethod" to tx.paymentMethod,
                "relatedMemberId" to (tx.relatedMemberId ?: 0L),
                "relatedMemberName" to (tx.relatedMemberName ?: ""),
                "relatedLoanId" to (tx.relatedLoanId ?: 0L),
                "relatedInvestmentId" to (tx.relatedInvestmentId ?: 0L),
                "createdBy" to tx.createdBy
            )
            db.collection("groups")
                .document(tx.groupId.toString())
                .collection("transactions")
                .document(tx.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveTransaction error: ${e.message}")
        }
    }

    suspend fun deleteTransaction(groupId: Long, txId: Long) {
        val db = firestore ?: return
        try {
            db.collection("groups")
                .document(groupId.toString())
                .collection("transactions")
                .document(txId.toString())
                .delete()
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore deleteTransaction error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Notices
    // -------------------------------------------------------------

    suspend fun saveNotice(notice: SocietyNotice) {
        val db = firestore ?: return
        try {
            val map = hashMapOf(
                "id" to notice.id,
                "groupId" to notice.groupId,
                "title" to notice.title,
                "content" to notice.content,
                "category" to notice.category,
                "author" to notice.author,
                "timestamp" to notice.timestamp,
                "isPinned" to notice.isPinned
            )
            db.collection("groups")
                .document(notice.groupId.toString())
                .collection("notices")
                .document(notice.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveNotice error: ${e.message}")
        }
    }

    suspend fun deleteNotice(groupId: Long, noticeId: Long) {
        val db = firestore ?: return
        try {
            db.collection("groups")
                .document(groupId.toString())
                .collection("notices")
                .document(noticeId.toString())
                .delete()
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore deleteNotice error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Loans
    // -------------------------------------------------------------

    suspend fun saveLoan(loan: LoanRequest) {
        val db = firestore ?: return
        try {
            val map = hashMapOf(
                "id" to loan.id,
                "groupId" to loan.groupId,
                "requesterMemberId" to loan.requesterMemberId,
                "requesterName" to loan.requesterName,
                "requesterPhone" to loan.requesterPhone,
                "requestedAmount" to loan.requestedAmount,
                "purpose" to loan.purpose,
                "reason" to loan.reason,
                "duration" to loan.duration,
                "durationUnit" to loan.durationUnit,
                "expectedRepaymentDate" to loan.expectedRepaymentDate,
                "note" to loan.note,
                "createdAt" to loan.createdAt,
                "votingDeadline" to loan.votingDeadline,
                "status" to loan.status,
                "disbursedDate" to (loan.disbursedDate ?: 0L),
                "disbursedBy" to (loan.disbursedBy ?: ""),
                "repaidAmount" to loan.repaidAmount,
                "remainingAmount" to loan.remainingAmount
            )
            db.collection("groups")
                .document(loan.groupId.toString())
                .collection("loans")
                .document(loan.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveLoan error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Chat Messages
    // -------------------------------------------------------------

    suspend fun saveChatMessage(msg: GroupChatMessage) {
        val db = firestore ?: return
        try {
            val map = hashMapOf(
                "id" to msg.id,
                "groupId" to msg.groupId,
                "senderId" to msg.senderId,
                "senderName" to msg.senderName,
                "senderRole" to msg.senderRole,
                "message" to msg.message,
                "timestamp" to msg.timestamp,
                "isAnnouncement" to msg.isAnnouncement,
                "isRead" to msg.isRead
            )
            db.collection("groups")
                .document(msg.groupId.toString())
                .collection("messages")
                .document(msg.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveChatMessage error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Pre-Authorized Members
    // -------------------------------------------------------------

    suspend fun savePreAuthorizedMember(member: PreAuthorizedMember) {
        val db = firestore ?: return
        try {
            val map = hashMapOf(
                "id" to member.id,
                "groupId" to member.groupId,
                "name" to member.name,
                "email" to member.email.trim().lowercase(),
                "phone" to member.phone,
                "status" to member.status,
                "addedAt" to member.addedAt,
                "claimedAt" to (member.claimedAt ?: 0L),
                "claimedUserId" to (member.claimedUserId ?: 0L)
            )
            db.collection("groups")
                .document(member.groupId.toString())
                .collection("preAuthorizedMembers")
                .document(member.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore savePreAuthorizedMember error: ${e.message}")
        }
    }

    suspend fun deletePreAuthorizedMember(groupId: Long, memberId: Long) {
        val db = firestore ?: return
        try {
            db.collection("groups")
                .document(groupId.toString())
                .collection("preAuthorizedMembers")
                .document(memberId.toString())
                .delete()
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore deletePreAuthorizedMember error: ${e.message}")
        }
    }

    suspend fun getPreAuthorizedMembers(groupId: Long): List<PreAuthorizedMember> {
        val db = firestore ?: return emptyList()
        return try {
            val snapshots = db.collection("groups")
                .document(groupId.toString())
                .collection("preAuthorizedMembers")
                .get()
                .await()

            snapshots.documents.mapNotNull { doc ->
                try {
                    PreAuthorizedMember(
                        id = doc.getLong("id") ?: 0L,
                        groupId = doc.getLong("groupId") ?: groupId,
                        name = doc.getString("name") ?: "",
                        email = doc.getString("email") ?: "",
                        phone = doc.getString("phone") ?: "",
                        status = doc.getString("status") ?: "unclaimed",
                        addedAt = doc.getLong("addedAt") ?: System.currentTimeMillis(),
                        claimedAt = doc.getLong("claimedAt").takeIf { it != null && it > 0 },
                        claimedUserId = doc.getLong("claimedUserId").takeIf { it != null && it > 0 }
                    )
                } catch (e: Exception) {
                    null
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firestore getPreAuthorizedMembers error: ${e.message}")
            emptyList()
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Group Join Requests (Pending / Approved / Rejected)
    // -------------------------------------------------------------

    suspend fun saveJoinRequest(request: GroupJoinRequest) {
        val db = firestore ?: return
        try {
            val map = hashMapOf(
                "id" to request.id,
                "groupId" to request.groupId,
                "groupName" to request.groupName,
                "userId" to request.userId,
                "name" to request.name,
                "email" to request.email.trim().lowercase(),
                "phone" to request.phone,
                "requestedAt" to request.requestedAt,
                "status" to request.status,
                "processedAt" to (request.processedAt ?: 0L),
                "processedBy" to (request.processedBy ?: "")
            )
            // Save in group subcollection
            db.collection("groups")
                .document(request.groupId.toString())
                .collection("pendingRequests")
                .document(request.id.toString())
                .set(map, SetOptions.merge())
                .await()

            // Also mirror in global user_requests collection for quick member-side status queries
            db.collection("users")
                .document(request.userId.toString())
                .collection("joinRequests")
                .document(request.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveJoinRequest error: ${e.message}")
        }
    }

    suspend fun deleteJoinRequest(groupId: Long, requestId: Long, userId: Long? = null) {
        val db = firestore ?: return
        try {
            db.collection("groups")
                .document(groupId.toString())
                .collection("pendingRequests")
                .document(requestId.toString())
                .delete()
                .await()

            if (userId != null && userId > 0) {
                db.collection("users")
                    .document(userId.toString())
                    .collection("joinRequests")
                    .document(requestId.toString())
                    .delete()
                    .await()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firestore deleteJoinRequest error: ${e.message}")
        }
    }

    suspend fun getJoinRequests(groupId: Long): List<GroupJoinRequest> {
        val db = firestore ?: return emptyList()
        return try {
            val snapshots = db.collection("groups")
                .document(groupId.toString())
                .collection("pendingRequests")
                .get()
                .await()

            snapshots.documents.mapNotNull { doc ->
                try {
                    GroupJoinRequest(
                        id = doc.getLong("id") ?: 0L,
                        groupId = doc.getLong("groupId") ?: groupId,
                        groupName = doc.getString("groupName") ?: "",
                        userId = doc.getLong("userId") ?: 0L,
                        name = doc.getString("name") ?: "",
                        email = doc.getString("email") ?: "",
                        phone = doc.getString("phone") ?: "",
                        requestedAt = doc.getLong("requestedAt") ?: System.currentTimeMillis(),
                        status = doc.getString("status") ?: "PENDING",
                        processedAt = doc.getLong("processedAt").takeIf { it != null && it > 0 },
                        processedBy = doc.getString("processedBy")
                    )
                } catch (e: Exception) {
                    null
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firestore getJoinRequests error: ${e.message}")
            emptyList()
        }
    }

    suspend fun findGroupByInviteCode(inviteCode: String): GroupSettings? {
        val db = firestore ?: return null
        val code = inviteCode.trim().uppercase()
        return try {
            val querySnapshot = db.collection("groups")
                .whereEqualTo("inviteCode", code)
                .limit(1)
                .get()
                .await()

            val doc = querySnapshot.documents.firstOrNull() ?: return null
            GroupSettings(
                id = doc.getLong("id") ?: (doc.id.toLongOrNull() ?: 1L),
                groupName = doc.getString("groupName") ?: "Group",
                groupSubtitle = doc.getString("groupSubtitle") ?: "",
                description = doc.getString("description") ?: "",
                groupType = doc.getString("groupType") ?: "Self-Help Group",
                address = doc.getString("address") ?: "",
                contactPhone = doc.getString("contactPhone") ?: "",
                contactEmail = doc.getString("contactEmail") ?: "",
                createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis(),
                logoUri = doc.getString("logoUri") ?: "",
                inviteCode = doc.getString("inviteCode") ?: code,
                createdByUserId = doc.getLong("createdByUserId") ?: 1L,
                isContributionEnabled = doc.getBoolean("isContributionEnabled") ?: true,
                defaultContribution = doc.getDouble("defaultContribution") ?: 500.0,
                contributionFrequency = doc.getString("contributionFrequency") ?: "MONTHLY",
                dueDayOfMonth = (doc.getLong("dueDayOfMonth") ?: 10).toInt(),
                isLateFeeEnabled = doc.getBoolean("isLateFeeEnabled") ?: false,
                lateFineAmount = doc.getDouble("lateFineAmount") ?: 0.0,
                gracePeriodDays = (doc.getLong("gracePeriodDays") ?: 5).toInt(),
                paymentRules = doc.getString("paymentRules") ?: "",
                modulesConfigJson = doc.getString("modulesConfigJson") ?: "",
                currencySymbol = doc.getString("currencySymbol") ?: "₹",
                financialYearStartMonth = (doc.getLong("financialYearStartMonth") ?: 4).toInt(),
                adminName = doc.getString("adminName") ?: "Society Treasurer",
                adminPhone = doc.getString("adminPhone") ?: "",
                adminPin = doc.getString("adminPin") ?: "1234",
                isPinLockEnabled = doc.getBoolean("isPinLockEnabled") ?: false,
                themeMode = doc.getString("themeMode") ?: "SYSTEM"
            )
        } catch (e: Exception) {
            Log.w(TAG, "Firestore findGroupByInviteCode error: ${e.message}")
            null
        }
    }

    // -------------------------------------------------------------
    // Real-Time Listeners for Cloud Firestore
    // -------------------------------------------------------------

    fun attachRealtimeSync(
        groupId: Long,
        onMembersReceived: (List<Member>) -> Unit,
        onPaymentsReceived: (List<Payment>) -> Unit,
        onTransactionsReceived: (List<TransactionRecord>) -> Unit,
        onNoticesReceived: (List<SocietyNotice>) -> Unit,
        onLoansReceived: (List<LoanRequest>) -> Unit,
        onMessagesReceived: (List<GroupChatMessage>) -> Unit,
        onGroupSettingsReceived: (GroupSettings) -> Unit,
        onPreAuthorizedReceived: (List<PreAuthorizedMember>) -> Unit = {},
        onPendingRequestsReceived: (List<GroupJoinRequest>) -> Unit = {}
    ): () -> Unit {
        val db = firestore ?: return {}
        val registrations = mutableListOf<ListenerRegistration>()

        try {
            // 1. Group settings listener
            val groupReg = db.collection("groups").document(groupId.toString())
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null || !snapshot.exists()) return@addSnapshotListener
                    try {
                        val settings = GroupSettings(
                            id = snapshot.getLong("id") ?: groupId,
                            groupName = snapshot.getString("groupName") ?: "All services group",
                            groupSubtitle = snapshot.getString("groupSubtitle") ?: "Monthly Savings & Contribution Society",
                            description = snapshot.getString("description") ?: "",
                            groupType = snapshot.getString("groupType") ?: "Self-Help Group",
                            address = snapshot.getString("address") ?: "",
                            contactPhone = snapshot.getString("contactPhone") ?: "",
                            contactEmail = snapshot.getString("contactEmail") ?: "",
                            createdAt = snapshot.getLong("createdAt") ?: System.currentTimeMillis(),
                            logoUri = snapshot.getString("logoUri") ?: "",
                            inviteCode = snapshot.getString("inviteCode") ?: "SAMITI-${groupId}",
                            createdByUserId = snapshot.getLong("createdByUserId") ?: 1L,
                            isContributionEnabled = snapshot.getBoolean("isContributionEnabled") ?: true,
                            defaultContribution = snapshot.getDouble("defaultContribution") ?: 500.0,
                            contributionFrequency = snapshot.getString("contributionFrequency") ?: "MONTHLY",
                            dueDayOfMonth = (snapshot.getLong("dueDayOfMonth") ?: 10).toInt(),
                            isLateFeeEnabled = snapshot.getBoolean("isLateFeeEnabled") ?: false,
                            lateFineAmount = snapshot.getDouble("lateFineAmount") ?: 0.0,
                            gracePeriodDays = (snapshot.getLong("gracePeriodDays") ?: 5).toInt(),
                            paymentRules = snapshot.getString("paymentRules") ?: "",
                            modulesConfigJson = snapshot.getString("modulesConfigJson") ?: "",
                            currencySymbol = snapshot.getString("currencySymbol") ?: "₹",
                            financialYearStartMonth = (snapshot.getLong("financialYearStartMonth") ?: 4).toInt(),
                            adminName = snapshot.getString("adminName") ?: "Society Treasurer",
                            adminPhone = snapshot.getString("adminPhone") ?: "+91 98765 43210",
                            adminPin = snapshot.getString("adminPin") ?: "1234",
                            isPinLockEnabled = snapshot.getBoolean("isPinLockEnabled") ?: false,
                            themeMode = snapshot.getString("themeMode") ?: "SYSTEM"
                        )
                        onGroupSettingsReceived(settings)
                    } catch (e: Exception) {
                        Log.w(TAG, "Error parsing Firestore group settings", e)
                    }
                }
            registrations.add(groupReg)

            // 2. Members listener
            val membersReg = db.collection("groups").document(groupId.toString())
                .collection("members")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            Member(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                memberCode = doc.getString("memberCode") ?: "",
                                name = doc.getString("name") ?: "",
                                phone = doc.getString("phone") ?: "",
                                address = doc.getString("address") ?: "",
                                joinDate = doc.getLong("joinDate") ?: System.currentTimeMillis(),
                                monthlyContribution = doc.getDouble("monthlyContribution") ?: 0.0,
                                photoUri = doc.getString("photoUri") ?: "",
                                isActive = doc.getBoolean("isActive") ?: true,
                                notes = doc.getString("notes") ?: "",
                                email = doc.getString("email") ?: "",
                                isClaimed = doc.getBoolean("isClaimed") ?: false,
                                linkedUid = doc.getString("linkedUid") ?: ""
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    if (list.isNotEmpty()) {
                        onMembersReceived(list)
                    }
                }
            registrations.add(membersReg)

            // 3. Payments listener
            val paymentsReg = db.collection("groups").document(groupId.toString())
                .collection("payments")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            Payment(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                memberId = doc.getLong("memberId") ?: 0L,
                                month = (doc.getLong("month") ?: 1).toInt(),
                                year = (doc.getLong("year") ?: 2026).toInt(),
                                expectedAmount = doc.getDouble("expectedAmount") ?: 0.0,
                                paidAmount = doc.getDouble("paidAmount") ?: 0.0,
                                dueAmount = doc.getDouble("dueAmount") ?: 0.0,
                                paymentDate = doc.getLong("paymentDate") ?: System.currentTimeMillis(),
                                paymentMethod = doc.getString("paymentMethod") ?: "Cash",
                                transactionReference = doc.getString("transactionReference") ?: "",
                                notes = doc.getString("notes") ?: "",
                                status = doc.getString("status") ?: "PAID",
                                approvalStatus = doc.getString("approvalStatus") ?: "APPROVED",
                                rejectionReason = doc.getString("rejectionReason") ?: "",
                                approvedAt = doc.getLong("approvedAt"),
                                approvedBy = doc.getString("approvedBy") ?: "",
                                submittedAt = doc.getLong("submittedAt") ?: System.currentTimeMillis()
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    if (list.isNotEmpty()) {
                        onPaymentsReceived(list)
                    }
                }
            registrations.add(paymentsReg)

            // 4. Transactions listener
            val txReg = db.collection("groups").document(groupId.toString())
                .collection("transactions")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            TransactionRecord(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                txnNumber = doc.getString("txnNumber") ?: "TXN-2026",
                                date = doc.getLong("date") ?: System.currentTimeMillis(),
                                amount = doc.getDouble("amount") ?: 0.0,
                                type = doc.getString("type") ?: "CONTRIBUTION",
                                isCredit = doc.getBoolean("isCredit") ?: true,
                                description = doc.getString("description") ?: "",
                                paymentMethod = doc.getString("paymentMethod") ?: "Cash",
                                relatedMemberId = doc.getLong("relatedMemberId"),
                                relatedMemberName = doc.getString("relatedMemberName"),
                                relatedLoanId = doc.getLong("relatedLoanId"),
                                relatedInvestmentId = doc.getLong("relatedInvestmentId"),
                                createdBy = doc.getString("createdBy") ?: "Admin"
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    if (list.isNotEmpty()) {
                        onTransactionsReceived(list)
                    }
                }
            registrations.add(txReg)

            // 5. Notices listener
            val noticesReg = db.collection("groups").document(groupId.toString())
                .collection("notices")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            SocietyNotice(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                title = doc.getString("title") ?: "",
                                content = doc.getString("content") ?: "",
                                category = doc.getString("category") ?: "ANNOUNCEMENT",
                                author = doc.getString("author") ?: "Admin",
                                timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis(),
                                isPinned = doc.getBoolean("isPinned") ?: false
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    if (list.isNotEmpty()) {
                        onNoticesReceived(list)
                    }
                }
            registrations.add(noticesReg)

            // 6. Loans listener
            val loansReg = db.collection("groups").document(groupId.toString())
                .collection("loans")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            LoanRequest(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                requesterMemberId = doc.getLong("requesterMemberId") ?: 0L,
                                requesterName = doc.getString("requesterName") ?: "",
                                requesterPhone = doc.getString("requesterPhone") ?: "",
                                requestedAmount = doc.getDouble("requestedAmount") ?: 0.0,
                                purpose = doc.getString("purpose") ?: "Emergency",
                                reason = doc.getString("reason") ?: "",
                                duration = (doc.getLong("duration") ?: 6).toInt(),
                                durationUnit = doc.getString("durationUnit") ?: "Months",
                                expectedRepaymentDate = doc.getLong("expectedRepaymentDate") ?: System.currentTimeMillis(),
                                note = doc.getString("note") ?: "",
                                createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis(),
                                votingDeadline = doc.getLong("votingDeadline") ?: System.currentTimeMillis(),
                                status = doc.getString("status") ?: "VOTING",
                                disbursedDate = doc.getLong("disbursedDate"),
                                disbursedBy = doc.getString("disbursedBy"),
                                repaidAmount = doc.getDouble("repaidAmount") ?: 0.0,
                                remainingAmount = doc.getDouble("remainingAmount") ?: 0.0
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    if (list.isNotEmpty()) {
                        onLoansReceived(list)
                    }
                }
            registrations.add(loansReg)

            // 7. Messages listener
            val messagesReg = db.collection("groups").document(groupId.toString())
                .collection("messages")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            GroupChatMessage(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                senderId = doc.getLong("senderId") ?: 1L,
                                senderName = doc.getString("senderName") ?: "Member",
                                senderRole = doc.getString("senderRole") ?: "Member",
                                message = doc.getString("message") ?: "",
                                timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis(),
                                isAnnouncement = doc.getBoolean("isAnnouncement") ?: false,
                                isRead = doc.getBoolean("isRead") ?: true
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    if (list.isNotEmpty()) {
                        onMessagesReceived(list)
                    }
                }
            registrations.add(messagesReg)

            // 8. Pre-authorized Members listener
            val preAuthReg = db.collection("groups").document(groupId.toString())
                .collection("preAuthorizedMembers")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            PreAuthorizedMember(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                name = doc.getString("name") ?: "",
                                email = doc.getString("email") ?: "",
                                phone = doc.getString("phone") ?: "",
                                status = doc.getString("status") ?: "unclaimed",
                                addedAt = doc.getLong("addedAt") ?: System.currentTimeMillis(),
                                claimedAt = doc.getLong("claimedAt").takeIf { it != null && it > 0 },
                                claimedUserId = doc.getLong("claimedUserId").takeIf { it != null && it > 0 }
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    onPreAuthorizedReceived(list)
                }
            registrations.add(preAuthReg)

            // 9. Pending Requests listener
            val pendingReg = db.collection("groups").document(groupId.toString())
                .collection("pendingRequests")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            GroupJoinRequest(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                groupName = doc.getString("groupName") ?: "",
                                userId = doc.getLong("userId") ?: 0L,
                                name = doc.getString("name") ?: "",
                                email = doc.getString("email") ?: "",
                                phone = doc.getString("phone") ?: "",
                                requestedAt = doc.getLong("requestedAt") ?: System.currentTimeMillis(),
                                status = doc.getString("status") ?: "PENDING",
                                processedAt = doc.getLong("processedAt").takeIf { it != null && it > 0 },
                                processedBy = doc.getString("processedBy")
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    onPendingRequestsReceived(list)
                }
            registrations.add(pendingReg)

        } catch (e: Exception) {
            Log.w(TAG, "Error attaching Firestore listeners: ${e.message}")
        }

        return {
            registrations.forEach { it.remove() }
            registrations.clear()
        }
    }

    fun attachUserJoinRequestsListener(
        userId: Long,
        onRequestsReceived: (List<GroupJoinRequest>) -> Unit
    ): () -> Unit {
        val db = firestore ?: return {}
        try {
            val reg = db.collection("users").document(userId.toString())
                .collection("joinRequests")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            GroupJoinRequest(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: 0L,
                                groupName = doc.getString("groupName") ?: "",
                                userId = doc.getLong("userId") ?: userId,
                                name = doc.getString("name") ?: "",
                                email = doc.getString("email") ?: "",
                                phone = doc.getString("phone") ?: "",
                                requestedAt = doc.getLong("requestedAt") ?: System.currentTimeMillis(),
                                status = doc.getString("status") ?: "PENDING",
                                processedAt = doc.getLong("processedAt").takeIf { it != null && it > 0 },
                                processedBy = doc.getString("processedBy")
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    onRequestsReceived(list)
                }
            return { reg.remove() }
        } catch (e: Exception) {
            Log.w(TAG, "Error attaching user join requests listener: ${e.message}")
            return {}
        }
    }

    suspend fun autoMatchAndClaimUnclaimedMembers(
        userId: Long,
        authUid: String,
        userName: String,
        userEmail: String,
        userPhone: String
    ): List<ClaimedMemberMatch> {
        val db = firestore ?: return emptyList()
        val matchedList = mutableListOf<ClaimedMemberMatch>()
        val cleanUserName = userName.trim().lowercase()
        val cleanUserEmail = userEmail.trim().lowercase()
        val normUserPhone = userPhone.filter { it.isDigit() }.let { if (it.length >= 10) it.takeLast(10) else it.trimStart('0') }

        fun isPhoneMatch(storedPhone: String): Boolean {
            val normStored = storedPhone.filter { it.isDigit() }.let { if (it.length >= 10) it.takeLast(10) else it.trimStart('0') }
            if (normUserPhone.isBlank() || normStored.isBlank()) return false
            if (normUserPhone == normStored) return true
            if (normUserPhone.length >= 8 && normStored.length >= 8 && (normUserPhone.endsWith(normStored) || normStored.endsWith(normUserPhone))) return true
            return false
        }

        fun isNameMatch(storedName: String): Boolean {
            val cStored = storedName.trim().lowercase().replace(Regex("\\s+"), " ")
            val cUser = cleanUserName.replace(Regex("\\s+"), " ")
            if (cStored.isBlank() || cUser.isBlank()) return false
            if (cStored == cUser) return true
            if (cStored.length >= 3 && cUser.length >= 3 && (cStored.contains(cUser) || cUser.contains(cStored))) return true
            return false
        }

        try {
            val groupsSnap = db.collection("groups").get().await()
            for (gDoc in groupsSnap.documents) {
                val groupId = gDoc.getLong("id") ?: (gDoc.id.toLongOrNull() ?: continue)
                val groupName = gDoc.getString("groupName") ?: "Group"

                // 1. Check members subcollection
                val membersRef = db.collection("groups").document(groupId.toString()).collection("members")
                val membersSnap = membersRef.get().await()
                for (mDoc in membersSnap.documents) {
                    val isClaimed = mDoc.getBoolean("isClaimed") ?: false
                    val linkedUid = mDoc.getString("linkedUid").orEmpty()
                    if (isClaimed && linkedUid.isNotBlank() && linkedUid != authUid) continue

                    val mName = mDoc.getString("name").orEmpty().trim()
                    val mEmail = mDoc.getString("email").orEmpty().trim().lowercase()
                    val mPhone = mDoc.getString("phone").orEmpty().trim()
                    val memberId = mDoc.getLong("id") ?: (mDoc.id.toLongOrNull() ?: 0L)

                    val nameMatches = isNameMatch(mName)
                    val emailMatches = cleanUserEmail.isNotBlank() && mEmail.isNotBlank() && cleanUserEmail == mEmail
                    val phoneMatches = isPhoneMatch(mPhone)

                    val isMatch = (nameMatches && (emailMatches || phoneMatches)) ||
                            (nameMatches && mEmail.isBlank() && mPhone.isBlank()) ||
                            ((emailMatches || phoneMatches) && (nameMatches || mName.isBlank()))

                    if (isMatch) {
                        membersRef.document(mDoc.id).set(
                            mapOf(
                                "isClaimed" to true,
                                "linkedUid" to authUid,
                                "email" to if (mEmail.isBlank()) userEmail else mDoc.getString("email").orEmpty(),
                                "phone" to if (mPhone.isBlank()) userPhone else mDoc.getString("phone").orEmpty()
                            ),
                            SetOptions.merge()
                        ).await()

                        try {
                            db.collection("groups").document(groupId.toString()).update(
                                "activeMemberUids", FieldValue.arrayUnion(authUid)
                            ).await()
                        } catch (e: Exception) {
                            Log.w(TAG, "Update activeMemberUids error: ${e.message}")
                        }

                        matchedList.add(
                            ClaimedMemberMatch(
                                groupId = groupId,
                                groupName = groupName,
                                memberId = memberId,
                                memberName = mName.ifBlank { userName }
                            )
                        )
                    }
                }

                // 2. Check preAuthorizedMembers subcollection
                val preAuthRef = db.collection("groups").document(groupId.toString()).collection("preAuthorizedMembers")
                val preAuthSnap = preAuthRef.get().await()
                for (pDoc in preAuthSnap.documents) {
                    val status = pDoc.getString("status").orEmpty()
                    if (status.equals("claimed", ignoreCase = true)) continue

                    val pName = pDoc.getString("name").orEmpty().trim()
                    val pEmail = pDoc.getString("email").orEmpty().trim().lowercase()
                    val pPhone = pDoc.getString("phone").orEmpty().trim()
                    val pId = pDoc.getLong("id") ?: (pDoc.id.toLongOrNull() ?: 0L)

                    val nameMatches = isNameMatch(pName)
                    val emailMatches = cleanUserEmail.isNotBlank() && pEmail.isNotBlank() && cleanUserEmail == pEmail
                    val phoneMatches = isPhoneMatch(pPhone)

                    val isMatch = (nameMatches && (emailMatches || phoneMatches)) ||
                            (nameMatches && pEmail.isBlank() && pPhone.isBlank()) ||
                            ((emailMatches || phoneMatches) && (nameMatches || pName.isBlank()))

                    if (isMatch) {
                        preAuthRef.document(pDoc.id).set(
                            mapOf(
                                "status" to "claimed",
                                "claimedAt" to System.currentTimeMillis(),
                                "claimedUserId" to userId
                            ),
                            SetOptions.merge()
                        ).await()

                        try {
                            db.collection("groups").document(groupId.toString()).update(
                                "activeMemberUids", FieldValue.arrayUnion(authUid)
                            ).await()
                        } catch (e: Exception) {
                            Log.w(TAG, "Update activeMemberUids error: ${e.message}")
                        }

                        matchedList.add(
                            ClaimedMemberMatch(
                                groupId = groupId,
                                groupName = groupName,
                                memberId = pId,
                                memberName = pName.ifBlank { userName }
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error in autoMatchAndClaimUnclaimedMembers: ${e.message}")
        }
        return matchedList
    }

    // -------------------------------------------------------------
    // App Update Service Support (Firestore app_config/version_info)
    // -------------------------------------------------------------

    suspend fun getLatestAppUpdate(): AppUpdateInfo? {
        val db = firestore ?: return null
        return try {
            val doc = db.collection("app_config").document("version_info").get().await()
            if (doc != null && doc.exists()) {
                val latestCode = doc.getLong("latestVersionCode")
                    ?: doc.getLong("versionCode")
                    ?: 1L
                val url = doc.getString("downloadUrl") ?: ""
                val versionName = doc.getString("versionName") ?: "v$latestCode"
                val title = doc.getString("title") ?: "Update Available"
                val notes = doc.getString("releaseNotes")
                    ?: "A new version of Group Ledger is available. Please update now to continue using the app."
                val isMandatory = doc.getBoolean("isMandatory") ?: false
                val bulletsList = (doc.get("changelogBullets") as? List<*>)?.mapNotNull { it?.toString() }
                    ?: emptyList()

                AppUpdateInfo(
                    versionCode = latestCode.toInt(),
                    versionName = versionName,
                    minSupportedVersionCode = (doc.getLong("minSupportedVersionCode") ?: 1).toInt(),
                    title = title,
                    releaseNotes = notes,
                    releaseDate = doc.getLong("releaseDate") ?: System.currentTimeMillis(),
                    downloadUrl = url,
                    isMandatory = isMandatory,
                    fileSizeBytes = doc.getLong("fileSizeBytes") ?: 0L,
                    publishedBy = doc.getString("publishedBy") ?: "Admin",
                    changelogBullets = if (bulletsList.isNotEmpty()) bulletsList else listOf(notes)
                )
            } else {
                null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error checking for app update from app_config/version_info: ${e.message}")
            null
        }
    }

    suspend fun publishAppUpdate(update: AppUpdateInfo): Result<Unit> {
        val db = firestore ?: return Result.failure(IllegalStateException("Firebase Firestore is not initialized"))
        return try {
            val data = mapOf(
                "latestVersionCode" to update.versionCode,
                "versionCode" to update.versionCode,
                "downloadUrl" to update.downloadUrl,
                "versionName" to update.versionName,
                "minSupportedVersionCode" to update.minSupportedVersionCode,
                "title" to update.title,
                "releaseNotes" to update.releaseNotes,
                "releaseDate" to update.releaseDate,
                "isMandatory" to update.isMandatory,
                "fileSizeBytes" to update.fileSizeBytes,
                "publishedBy" to update.publishedBy,
                "changelogBullets" to update.changelogBullets,
                "updatedAt" to System.currentTimeMillis()
            )
            db.collection("app_config").document("version_info")
                .set(data, SetOptions.merge()).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Error publishing app update to Firestore: ${e.message}")
            Result.failure(e)
        }
    }

    fun attachAppUpdateListener(onUpdateReceived: (AppUpdateInfo?) -> Unit): () -> Unit {
        val db = firestore ?: return {}
        val reg = db.collection("app_config").document("version_info")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Error listening to app updates: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    val latestCode = snapshot.getLong("latestVersionCode")
                        ?: snapshot.getLong("versionCode")
                        ?: 1L
                    val url = snapshot.getString("downloadUrl") ?: ""
                    val versionName = snapshot.getString("versionName") ?: "v$latestCode"
                    val title = snapshot.getString("title") ?: "Update Available"
                    val notes = snapshot.getString("releaseNotes")
                        ?: "A new version of Group Ledger is available. Please update now to continue using the app."
                    val isMandatory = snapshot.getBoolean("isMandatory") ?: false
                    val bulletsList = (snapshot.get("changelogBullets") as? List<*>)?.mapNotNull { it?.toString() }
                        ?: emptyList()

                    val info = AppUpdateInfo(
                        versionCode = latestCode.toInt(),
                        versionName = versionName,
                        minSupportedVersionCode = (snapshot.getLong("minSupportedVersionCode") ?: 1).toInt(),
                        title = title,
                        releaseNotes = notes,
                        releaseDate = snapshot.getLong("releaseDate") ?: System.currentTimeMillis(),
                        downloadUrl = url,
                        isMandatory = isMandatory,
                        fileSizeBytes = snapshot.getLong("fileSizeBytes") ?: 0L,
                        publishedBy = snapshot.getString("publishedBy") ?: "Admin",
                        changelogBullets = if (bulletsList.isNotEmpty()) bulletsList else listOf(notes)
                    )
                    onUpdateReceived(info)
                } else {
                    onUpdateReceived(null)
                }
            }
        return { reg.remove() }
    }
}

data class ClaimedMemberMatch(
    val groupId: Long,
    val groupName: String,
    val memberId: Long,
    val memberName: String
)
