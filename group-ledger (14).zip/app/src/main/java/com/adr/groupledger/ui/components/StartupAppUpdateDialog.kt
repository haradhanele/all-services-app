package com.adr.groupledger.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.BuildConfig
import com.adr.groupledger.data.model.UpdateCheckStatus
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import java.util.Locale

/**
 * Startup Modal Alert Dialog triggered immediately on app launch
 * whenever Firebase Firestore reports `latestVersionCode > BuildConfig.VERSION_CODE`.
 */
@Composable
fun StartupAppUpdateDialog(
    viewModel: SocietyViewModel
) {
    val updateStatus by viewModel.updateStatus.collectAsStateWithLifecycle()

    when (val status = updateStatus) {
        is UpdateCheckStatus.UpdateAvailable -> {
            val updateInfo = status.updateInfo
            // Verify condition latestVersionCode > BuildConfig.VERSION_CODE
            if (updateInfo.versionCode > BuildConfig.VERSION_CODE) {
                AlertDialog(
                    onDismissRequest = { /* Modal / Non-cancelable on outside click */ },
                    properties = DialogProperties(
                        dismissOnBackPress = false,
                        dismissOnClickOutside = false
                    ),
                    modifier = Modifier.testTag("startup_update_dialog"),
                    icon = {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(IndigoPrimary.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SystemUpdate,
                                contentDescription = "Update Icon",
                                tint = IndigoPrimary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    },
                    title = {
                        Text(
                            text = "Update Available",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    },
                    text = {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "A new version of Group Ledger is available. Please update now to continue using the app.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            // Optional version badge indicator
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "Current: v${BuildConfig.VERSION_CODE}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "→",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Latest: v${updateInfo.versionCode}",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = IndigoPrimary
                                )
                            }
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                viewModel.downloadAndInstallUpdate(updateInfo)
                            },
                            modifier = Modifier.testTag("startup_update_now_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudDownload,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Update Now",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    },
                    dismissButton = if (!updateInfo.isMandatory) {
                        {
                            TextButton(
                                onClick = {
                                    viewModel.dismissUpdateBanner()
                                    viewModel.resetUpdateStatus()
                                }
                            ) {
                                Text("Later")
                            }
                        }
                    } else null
                )
            }
        }

        is UpdateCheckStatus.Downloading -> {
            AlertDialog(
                onDismissRequest = { /* Non-cancelable during download */ },
                properties = DialogProperties(
                    dismissOnBackPress = false,
                    dismissOnClickOutside = false
                ),
                modifier = Modifier.testTag("startup_downloading_dialog"),
                icon = {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(IndigoPrimary.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudDownload,
                            contentDescription = "Downloading",
                            tint = IndigoPrimary,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                },
                title = {
                    Text(
                        text = "Downloading Update...",
                        fontWeight = FontWeight.Bold,
                        fontSize = 19.sp
                    )
                },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Please wait while the update APK is downloaded via DownloadManager.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        LinearProgressIndicator(
                            progress = { status.progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = IndigoPrimary
                        )

                        val percent = (status.progress * 100).toInt()
                        val textProgress = if (status.totalBytes > 0) {
                            val mbDownloaded = status.bytesDownloaded / (1024f * 1024f)
                            val mbTotal = status.totalBytes / (1024f * 1024f)
                            "$percent% • ${String.format(Locale.US, "%.1f", mbDownloaded)} MB / ${String.format(Locale.US, "%.1f", mbTotal)} MB"
                        } else {
                            "$percent% downloaded"
                        }

                        Text(
                            text = textProgress,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                confirmButton = {}
            )
        }

        is UpdateCheckStatus.ReadyToInstall -> {
            AlertDialog(
                onDismissRequest = { /* Non-cancelable */ },
                properties = DialogProperties(
                    dismissOnBackPress = false,
                    dismissOnClickOutside = false
                ),
                modifier = Modifier.testTag("startup_ready_install_dialog"),
                icon = {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(Emerald500.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Ready to Install",
                            tint = Emerald500,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                },
                title = {
                    Text(
                        text = "Update Ready",
                        fontWeight = FontWeight.Bold,
                        fontSize = 19.sp
                    )
                },
                text = {
                    Text(
                        text = "The update has finished downloading. Tap below to launch the package installer and install the new version over Group Ledger.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.installDownloadedApk(status.apkFile)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald500),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Install Now", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        is UpdateCheckStatus.Error -> {
            AlertDialog(
                onDismissRequest = { viewModel.resetUpdateStatus() },
                modifier = Modifier.testTag("startup_update_error_dialog"),
                icon = {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(Rose500.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = "Update Error",
                            tint = Rose500,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                },
                title = {
                    Text(
                        text = "Update Check Notice",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                text = {
                    Text(
                        text = status.message,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.checkForAppUpdates(isManual = true)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                    ) {
                        Text("Retry")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.resetUpdateStatus() }) {
                        Text("Dismiss")
                    }
                }
            )
        }

        else -> {
            // Idle, Checking, UpToDate -> No popup needed on startup
        }
    }
}
