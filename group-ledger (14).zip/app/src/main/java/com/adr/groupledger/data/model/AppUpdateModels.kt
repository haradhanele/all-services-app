package com.adr.groupledger.data.model

import java.io.File

/**
 * Model representing an application software release and update metadata.
 */
data class AppUpdateInfo(
    val versionCode: Int = 2,
    val versionName: String = "1.3.0",
    val minSupportedVersionCode: Int = 1,
    val title: String = "Version 1.3.0 Available",
    val releaseNotes: String = "• Real-time Cloud Firestore updates and instant synchronization\n• Enhanced offline ledger and audit history\n• In-app Update Service with fast background checks\n• Bug fixes and UI performance optimizations",
    val releaseDate: Long = System.currentTimeMillis(),
    val downloadUrl: String = "https://github.com/adr-groupledger/releases/download/v1.3.0/groupledger-v1.3.0.apk",
    val isMandatory: Boolean = false,
    val fileSizeBytes: Long = 18_450_000L,
    val publishedBy: String = "Samiti Admin & Engineering",
    val changelogBullets: List<String> = listOf(
        "Real-time Cloud Firestore updates and instant synchronization",
        "Enhanced offline ledger and audit history",
        "In-app Update Service with fast background checks",
        "Bug fixes and UI performance optimizations"
    )
)

/**
 * State machine representing the lifecycle of the in-app Update Service.
 */
sealed class UpdateCheckStatus {
    object Idle : UpdateCheckStatus()
    object Checking : UpdateCheckStatus()
    data class UpdateAvailable(val updateInfo: AppUpdateInfo) : UpdateCheckStatus()
    data class UpToDate(val currentVersion: String, val lastCheckedTime: Long = System.currentTimeMillis()) : UpdateCheckStatus()
    data class Downloading(val progress: Float, val bytesDownloaded: Long, val totalBytes: Long) : UpdateCheckStatus()
    data class ReadyToInstall(val apkFile: File, val updateInfo: AppUpdateInfo) : UpdateCheckStatus()
    data class Error(val message: String) : UpdateCheckStatus()
}
