package com.adr.groupledger.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adr.groupledger.ui.theme.BorderLight
import com.adr.groupledger.ui.theme.CardWhite
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.TextSlate400
import com.adr.groupledger.ui.theme.TextSlate500
import com.adr.groupledger.ui.theme.TextSlate800
import com.adr.groupledger.ui.theme.appOutlinedTextFieldColors
import com.adr.groupledger.ui.viewmodel.SocietyViewModel

import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.GroupSettings

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CreateNewGroupScreen(
    viewModel: SocietyViewModel,
    onNavigateBack: () -> Unit,
    editGroupId: Long? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val allGroups by viewModel.allGroups.collectAsStateWithLifecycle()
    val isEditMode = editGroupId != null && editGroupId > 0

    var groupName by remember { mutableStateOf("") }
    var groupSubtitle by remember { mutableStateOf("") }
    var groupType by remember { mutableStateOf("Self-Help Group") }
    var defaultDues by remember { mutableStateOf("500") }
    var currencySymbol by remember { mutableStateOf("₹") }
    var contributionFrequency by remember { mutableStateOf("MONTHLY") }
    var dueDayOfMonth by remember { mutableStateOf("10") }
    var isLateFeeEnabled by remember { mutableStateOf(false) }
    var lateFineAmount by remember { mutableStateOf("50") }
    var gracePeriodDays by remember { mutableStateOf("5") }
    var paymentRules by remember { mutableStateOf("Monthly contribution is due by the 10th of every month. Unpaid dues carry over to next cycle.") }
    var adminPin by remember { mutableStateOf("1234") }
    var isPinLockEnabled by remember { mutableStateOf(false) }

    var isCreating by remember { mutableStateOf(false) }
    var groupNameError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(editGroupId, allGroups) {
        if (isEditMode) {
            val group = allGroups.find { it.id == editGroupId }
            if (group != null) {
                groupName = group.groupName
                groupSubtitle = group.groupSubtitle
                groupType = group.groupType.ifBlank { "Self-Help Group" }
                defaultDues = if (group.defaultContribution % 1.0 == 0.0) group.defaultContribution.toLong().toString() else group.defaultContribution.toString()
                currencySymbol = group.currencySymbol.ifBlank { "₹" }
                contributionFrequency = group.contributionFrequency.ifBlank { "MONTHLY" }
                dueDayOfMonth = group.dueDayOfMonth.toString()
                isLateFeeEnabled = group.isLateFeeEnabled
                lateFineAmount = if (group.lateFineAmount % 1.0 == 0.0) group.lateFineAmount.toLong().toString() else group.lateFineAmount.toString()
                gracePeriodDays = group.gracePeriodDays.toString()
                paymentRules = group.paymentRules
                adminPin = group.adminPin.ifBlank { "1234" }
                isPinLockEnabled = group.isPinLockEnabled
            }
        }
    }

    val groupTypes = listOf(
        "Self-Help Group",
        "Welfare Society",
        "Apartment / Housing",
        "Savings & Credit",
        "Puja / Festival Samiti",
        "Sports & Cultural",
        "Other Community"
    )

    val frequencies = listOf("MONTHLY", "WEEKLY", "QUARTERLY", "YEARLY")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (isEditMode) "Edit Society / Group" else "Create New Society / Group",
                            fontWeight = FontWeight.Bold,
                            color = TextSlate800,
                            fontSize = 17.sp
                        )
                        Text(
                            text = if (isEditMode) "Update society parameters and settings" else "Set up society parameters and initial defaults",
                            fontSize = 11.5.sp,
                            color = IndigoPrimary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextSlate800)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CardWhite
                )
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .testTag("create_new_group_screen"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Informative Header Banner Card (matching AddEditMemberScreen style)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = IndigoPrimary.copy(alpha = 0.08f)),
                border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.25f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Groups,
                        contentDescription = null,
                        tint = IndigoPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (isEditMode) {
                            "Edit group details, contribution dues, fine policies, and admin security settings."
                        } else {
                            "Create a new society or group. A unique invite code will be generated, and you will be configured as the chief administrator."
                        },
                        fontSize = 12.sp,
                        color = TextSlate800,
                        lineHeight = 16.sp
                    )
                }
            }

            // 1. Basic Information Section
            Text(
                text = "1. BASIC INFORMATION",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = IndigoPrimary,
                letterSpacing = 0.5.sp
            )

            // Group Name Input
            OutlinedTextField(
                value = groupName,
                onValueChange = {
                    groupName = it
                    groupNameError = null
                },
                label = { Text("Society / Group Name *") },
                placeholder = { Text("e.g. Metro Welfare Samiti") },
                leadingIcon = { Icon(Icons.Default.Groups, contentDescription = null, tint = IndigoPrimary) },
                isError = groupNameError != null,
                supportingText = {
                    if (groupNameError != null) Text(groupNameError!!, color = Rose500)
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("group_name_input"),
                shape = RoundedCornerShape(10.dp),
                colors = appOutlinedTextFieldColors()
            )

            // Purpose / Subtitle Input
            OutlinedTextField(
                value = groupSubtitle,
                onValueChange = { groupSubtitle = it },
                label = { Text("Purpose / Subtitle") },
                placeholder = { Text("e.g. Monthly Savings & Emergency Fund") },
                leadingIcon = { Icon(Icons.Default.Notes, contentDescription = null, tint = IndigoPrimary) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("group_subtitle_input"),
                shape = RoundedCornerShape(10.dp),
                colors = appOutlinedTextFieldColors()
            )

            // Group Type Selection Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Group Category / Type",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextSlate800
                    )
                    Text(
                        text = "Select the type that best describes your organization",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSlate500,
                        fontSize = 11.5.sp
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        groupTypes.forEach { type ->
                            val isSelected = groupType == type
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) IndigoPrimary else CardWhite,
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) IndigoPrimary else BorderLight
                                ),
                                modifier = Modifier
                                    .clickable { groupType = type }
                                    .testTag("group_type_$type")
                            ) {
                                Text(
                                    text = type,
                                    fontSize = 11.5.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color.White else TextSlate800,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }

            // 2. Financial Settings Section
            Text(
                text = "2. FINANCIAL SETTINGS & DUES",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = IndigoPrimary,
                letterSpacing = 0.5.sp
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = defaultDues,
                            onValueChange = { defaultDues = it },
                            label = { Text("Default Dues Amount *") },
                            placeholder = { Text("500") },
                            leadingIcon = { Icon(Icons.Default.Payment, contentDescription = null, tint = IndigoPrimary) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1.4f)
                                .testTag("group_dues_input"),
                            shape = RoundedCornerShape(10.dp),
                            colors = appOutlinedTextFieldColors()
                        )

                        OutlinedTextField(
                            value = currencySymbol,
                            onValueChange = { currencySymbol = it },
                            label = { Text("Currency") },
                            placeholder = { Text("₹") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(0.8f)
                                .testTag("group_currency_input"),
                            shape = RoundedCornerShape(10.dp),
                            colors = appOutlinedTextFieldColors()
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = dueDayOfMonth,
                            onValueChange = { dueDayOfMonth = it },
                            label = { Text("Due Day of Month") },
                            placeholder = { Text("10 (1-28)") },
                            leadingIcon = { Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = IndigoPrimary) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("group_due_day_input"),
                            shape = RoundedCornerShape(10.dp),
                            colors = appOutlinedTextFieldColors()
                        )

                        OutlinedTextField(
                            value = contributionFrequency,
                            onValueChange = { contributionFrequency = it },
                            label = { Text("Billing Cycle") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("group_frequency_input"),
                            shape = RoundedCornerShape(10.dp),
                            colors = appOutlinedTextFieldColors()
                        )
                    }
                }
            }

            // 3. Late Fine & Policy Section
            Text(
                text = "3. LATE FINE & PENALTY POLICY",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = IndigoPrimary,
                letterSpacing = 0.5.sp
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Enable Late Fine",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextSlate800
                            )
                            Text(
                                text = "Apply automatic penalties on overdue member payments",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSlate500,
                                fontSize = 11.5.sp
                            )
                        }
                        Switch(
                            checked = isLateFeeEnabled,
                            onCheckedChange = { isLateFeeEnabled = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = IndigoPrimary,
                                checkedTrackColor = IndigoPrimary.copy(alpha = 0.3f)
                            )
                        )
                    }

                    if (isLateFeeEnabled) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = lateFineAmount,
                                onValueChange = { lateFineAmount = it },
                                label = { Text("Fine Amount ($currencySymbol)") },
                                placeholder = { Text("50") },
                                leadingIcon = { Icon(Icons.Default.Payment, contentDescription = null, tint = IndigoPrimary) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = appOutlinedTextFieldColors()
                            )

                            OutlinedTextField(
                                value = gracePeriodDays,
                                onValueChange = { gracePeriodDays = it },
                                label = { Text("Grace Period (Days)") },
                                placeholder = { Text("5") },
                                leadingIcon = { Icon(Icons.Default.Timer, contentDescription = null, tint = IndigoPrimary) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = appOutlinedTextFieldColors()
                            )
                        }
                    }
                }
            }

            // 4. Admin Security & PIN Section
            Text(
                text = "4. ADMIN SECURITY & PIN",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = IndigoPrimary,
                letterSpacing = 0.5.sp
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Require PIN for Admin Actions",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextSlate800
                            )
                            Text(
                                text = "Protects society settings, data backup, and member removal",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSlate500,
                                fontSize = 11.5.sp
                            )
                        }
                        Switch(
                            checked = isPinLockEnabled,
                            onCheckedChange = { isPinLockEnabled = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = IndigoPrimary,
                                checkedTrackColor = IndigoPrimary.copy(alpha = 0.3f)
                            )
                        )
                    }

                    OutlinedTextField(
                        value = adminPin,
                        onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) adminPin = it },
                        label = { Text("4-Digit Admin PIN") },
                        placeholder = { Text("1234") },
                        leadingIcon = { Icon(Icons.Default.Pin, contentDescription = null, tint = IndigoPrimary) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_pin_input"),
                        shape = RoundedCornerShape(10.dp),
                        colors = appOutlinedTextFieldColors()
                    )
                }
            }

            // 5. Payment Rules & Guidelines Section
            Text(
                text = "5. GROUP RULES & TERMS",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = IndigoPrimary,
                letterSpacing = 0.5.sp
            )

            OutlinedTextField(
                value = paymentRules,
                onValueChange = { paymentRules = it },
                label = { Text("Payment Rules & Member Guidelines") },
                placeholder = { Text("e.g. Monthly contribution is due by the 10th of every month.") },
                leadingIcon = { Icon(Icons.Default.Description, contentDescription = null, tint = IndigoPrimary) },
                maxLines = 3,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("group_rules_input"),
                shape = RoundedCornerShape(10.dp),
                colors = appOutlinedTextFieldColors()
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Save / Create Button (matching AddEditMemberScreen style)
            Button(
                onClick = {
                    if (groupName.trim().isBlank()) {
                        groupNameError = "Society / Group name is required"
                        return@Button
                    }

                    isCreating = true
                    groupNameError = null
                    val amount = defaultDues.toDoubleOrNull() ?: 500.0
                    val fineAmt = lateFineAmount.toDoubleOrNull() ?: 50.0
                    val graceDays = gracePeriodDays.toIntOrNull() ?: 5
                    val dueDay = dueDayOfMonth.toIntOrNull() ?: 10

                    if (isEditMode && editGroupId != null) {
                        val existing = allGroups.find { it.id == editGroupId }
                        val updated = (existing ?: GroupSettings(id = editGroupId)).copy(
                            groupName = groupName.trim(),
                            groupSubtitle = groupSubtitle.trim(),
                            groupType = groupType,
                            defaultContribution = amount,
                            currencySymbol = currencySymbol.trim().ifBlank { "₹" },
                            contributionFrequency = contributionFrequency.trim().ifBlank { "MONTHLY" },
                            dueDayOfMonth = dueDay,
                            isLateFeeEnabled = isLateFeeEnabled,
                            lateFineAmount = fineAmt,
                            gracePeriodDays = graceDays,
                            adminPin = adminPin.trim().ifBlank { "1234" },
                            isPinLockEnabled = isPinLockEnabled,
                            paymentRules = paymentRules.trim()
                        )
                        viewModel.updateSpecificGroup(updated) {
                            isCreating = false
                            Toast.makeText(context, "Group '${groupName.trim()}' updated successfully!", Toast.LENGTH_SHORT).show()
                            onNavigateBack()
                        }
                    } else {
                        viewModel.createNewGroup(
                            groupName = groupName.trim(),
                            groupSubtitle = groupSubtitle.trim(),
                            groupType = groupType,
                            defaultContribution = amount,
                            currencySymbol = currencySymbol.trim().ifBlank { "₹" },
                            contributionFrequency = contributionFrequency.trim().ifBlank { "MONTHLY" },
                            dueDayOfMonth = dueDay,
                            isLateFeeEnabled = isLateFeeEnabled,
                            lateFineAmount = fineAmt,
                            gracePeriodDays = graceDays,
                            adminPin = adminPin.trim().ifBlank { "1234" },
                            isPinLockEnabled = isPinLockEnabled,
                            paymentRules = paymentRules.trim(),
                            onSuccess = {
                                isCreating = false
                                Toast.makeText(context, "Group '${groupName.trim()}' created successfully!", Toast.LENGTH_SHORT).show()
                                onNavigateBack()
                            }
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("save_group_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                enabled = !isCreating
            ) {
                if (isCreating) {
                    CircularProgressIndicator(
                        color = Color.White,
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (isEditMode) "Saving Changes..." else "Creating Group...", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                } else {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isEditMode) "Save Changes" else "Create Society / Group",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}
