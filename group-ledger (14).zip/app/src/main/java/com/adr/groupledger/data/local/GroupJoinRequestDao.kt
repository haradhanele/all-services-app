package com.adr.groupledger.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.adr.groupledger.data.model.GroupJoinRequest
import kotlinx.coroutines.flow.Flow

@Dao
interface GroupJoinRequestDao {
    @Query("SELECT * FROM group_join_requests WHERE groupId = :groupId AND status = 'PENDING' ORDER BY requestedAt DESC")
    fun getPendingRequestsFlow(groupId: Long): Flow<List<GroupJoinRequest>>

    @Query("SELECT * FROM group_join_requests WHERE groupId = :groupId ORDER BY requestedAt DESC")
    fun getAllRequestsForGroupFlow(groupId: Long): Flow<List<GroupJoinRequest>>

    @Query("SELECT * FROM group_join_requests WHERE groupId = :groupId ORDER BY requestedAt DESC")
    fun getAllRequestsFlow(groupId: Long): Flow<List<GroupJoinRequest>>

    @Query("SELECT * FROM group_join_requests WHERE groupId = :groupId AND status = 'PENDING' ORDER BY requestedAt DESC")
    suspend fun getPendingRequestsDirect(groupId: Long): List<GroupJoinRequest>

    @Query("SELECT * FROM group_join_requests WHERE userId = :userId ORDER BY requestedAt DESC")
    fun getUserRequestsFlow(userId: Long): Flow<List<GroupJoinRequest>>

    @Query("SELECT * FROM group_join_requests WHERE userId = :userId AND groupId = :groupId LIMIT 1")
    suspend fun getRequestForUserAndGroup(userId: Long, groupId: Long): GroupJoinRequest?

    @Query("SELECT * FROM group_join_requests WHERE userId = :userId AND groupId = :groupId AND status = 'PENDING' LIMIT 1")
    suspend fun getUserPendingRequestForGroup(userId: Long, groupId: Long): GroupJoinRequest?

    @Query("SELECT * FROM group_join_requests WHERE id = :id LIMIT 1")
    suspend fun getRequestById(id: Long): GroupJoinRequest?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(request: GroupJoinRequest): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRequest(request: GroupJoinRequest): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(requests: List<GroupJoinRequest>)

    @Update
    suspend fun update(request: GroupJoinRequest)

    @Query("DELETE FROM group_join_requests WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM group_join_requests WHERE groupId = :groupId")
    suspend fun deleteForGroup(groupId: Long)

    @Query("DELETE FROM group_join_requests WHERE groupId = :groupId")
    suspend fun deleteByGroupId(groupId: Long)

    @Transaction
    suspend fun syncAll(groupId: Long, list: List<GroupJoinRequest>) {
        deleteForGroup(groupId)
        if (list.isNotEmpty()) {
            insertAll(list)
        }
    }
}
