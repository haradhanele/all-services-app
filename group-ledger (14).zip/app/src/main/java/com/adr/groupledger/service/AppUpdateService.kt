package com.adr.groupledger.service

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.util.Log
import androidx.core.content.FileProvider
import com.adr.groupledger.BuildConfig
import com.adr.groupledger.data.firebase.FirebaseService
import com.adr.groupledger.data.model.AppUpdateInfo
import com.adr.groupledger.data.model.UpdateCheckStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Production-ready App Update Service that connects directly to Firebase Firestore
 * at `app_config/version_info`, checks `latestVersionCode` vs `BuildConfig.VERSION_CODE`,
 * and manages direct downloads via Android's DownloadManager and immediate APK installation.
 */
class AppUpdateService(
    private val context: Context,
    private val firebaseService: FirebaseService?,
    private val scope: CoroutineScope
) {
    private val TAG = "AppUpdateService"
    private val prefs: SharedPreferences = context.getSharedPreferences("app_update_service_prefs", Context.MODE_PRIVATE)

    val currentVersionCode: Int = BuildConfig.VERSION_CODE
    val currentVersionName: String = if (BuildConfig.VERSION_NAME.isNotBlank()) BuildConfig.VERSION_NAME else "1.0"

    private val _updateStatus = MutableStateFlow<UpdateCheckStatus>(UpdateCheckStatus.Idle)
    val updateStatus: StateFlow<UpdateCheckStatus> = _updateStatus.asStateFlow()

    private val _lastCheckedTime = MutableStateFlow<Long>(prefs.getLong("last_check_timestamp", 0L))
    val lastCheckedTime: StateFlow<Long> = _lastCheckedTime.asStateFlow()

    private val _isBannerDismissed = MutableStateFlow<Boolean>(false)
    val isBannerDismissed: StateFlow<Boolean> = _isBannerDismissed.asStateFlow()

    private var listenerRegistration: (() -> Unit)? = null
    private var downloadReceiver: BroadcastReceiver? = null
    private var currentDownloadId: Long? = null
    private var progressPollingJob: Job? = null

    init {
        // Start listening to real-time update notifications from Cloud Firestore
        setupRealtimeUpdateListener()
    }

    private fun setupRealtimeUpdateListener() {
        listenerRegistration?.invoke()
        listenerRegistration = firebaseService?.attachAppUpdateListener { remoteUpdate ->
            if (remoteUpdate != null) {
                if (remoteUpdate.versionCode > currentVersionCode) {
                    _updateStatus.value = UpdateCheckStatus.UpdateAvailable(remoteUpdate)
                }
            }
        }
    }

    /**
     * Check for software updates either silently on startup or manually via UI.
     * Directly queries Firestore collection `app_config`, document `version_info`.
     */
    fun checkForUpdates(isManual: Boolean = false) {
        scope.launch {
            _updateStatus.value = UpdateCheckStatus.Checking
            val now = System.currentTimeMillis()
            prefs.edit().putLong("last_check_timestamp", now).apply()
            _lastCheckedTime.value = now

            if (isManual) {
                delay(400)
            }

            try {
                val remoteUpdate = firebaseService?.getLatestAppUpdate()

                if (remoteUpdate != null) {
                    if (remoteUpdate.versionCode > currentVersionCode) {
                        _isBannerDismissed.value = false
                        _updateStatus.value = UpdateCheckStatus.UpdateAvailable(remoteUpdate)
                    } else {
                        _updateStatus.value = UpdateCheckStatus.UpToDate(currentVersionName, now)
                    }
                } else {
                    _updateStatus.value = UpdateCheckStatus.UpToDate(currentVersionName, now)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error checking for update: ${e.message}")
                if (isManual) {
                    _updateStatus.value = UpdateCheckStatus.Error(e.localizedMessage ?: "Failed to reach update server")
                } else {
                    _updateStatus.value = UpdateCheckStatus.Idle
                }
            }
        }
    }

    /**
     * Download the APK file using Android's DownloadManager and trigger automatic installation.
     */
    fun downloadAndInstallUpdate(updateInfo: AppUpdateInfo) {
        val downloadUrl = updateInfo.downloadUrl.trim()
        if (downloadUrl.isBlank() || (!downloadUrl.startsWith("http://") && !downloadUrl.startsWith("https://"))) {
            _updateStatus.value = UpdateCheckStatus.Error("Invalid or missing APK download URL in Firebase app_config/version_info")
            return
        }

        val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager
        if (downloadManager == null) {
            _updateStatus.value = UpdateCheckStatus.Error("DownloadManager system service is unavailable")
            return
        }

        try {
            // Unregister any previous receiver and cancel polling
            unregisterDownloadReceiver()
            progressPollingJob?.cancel()

            // Prepare destination file in app's external files directory (or internal files/updates)
            val fileName = "groupledger-v${updateInfo.versionCode}.apk"
            val destinationDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                ?: File(context.filesDir, "updates").apply { mkdirs() }

            val destinationFile = File(destinationDir, fileName)
            if (destinationFile.exists()) {
                destinationFile.delete()
            }

            _updateStatus.value = UpdateCheckStatus.Downloading(
                progress = 0f,
                bytesDownloaded = 0L,
                totalBytes = updateInfo.fileSizeBytes
            )

            val downloadUri = Uri.parse(downloadUrl)
            val request = DownloadManager.Request(downloadUri).apply {
                setTitle("Group Ledger Update")
                setDescription("Downloading Group Ledger version ${updateInfo.versionName} (${updateInfo.versionCode})")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setMimeType("application/vnd.android.package-archive")
                setDestinationUri(Uri.fromFile(destinationFile))
                setAllowedOverMetered(true)
                setAllowedOverRoaming(true)
            }

            val downloadId = downloadManager.enqueue(request)
            currentDownloadId = downloadId

            // Register BroadcastReceiver for DownloadManager.ACTION_DOWNLOAD_COMPLETE
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(recvContext: Context?, intent: Intent?) {
                    val completedId = intent?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) ?: -1L
                    if (completedId == currentDownloadId) {
                        unregisterDownloadReceiver()
                        progressPollingJob?.cancel()

                        val query = DownloadManager.Query().setFilterById(completedId)
                        val cursor = downloadManager.query(query)
                        var isSuccess = false
                        if (cursor != null && cursor.moveToFirst()) {
                            val statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
                            val status = if (statusIndex != -1) cursor.getInt(statusIndex) else -1
                            cursor.close()
                            if (status == DownloadManager.STATUS_SUCCESSFUL) {
                                isSuccess = true
                            }
                        } else {
                            cursor?.close()
                        }

                        if (isSuccess || (destinationFile.exists() && destinationFile.length() > 0)) {
                            scope.launch(Dispatchers.Main) {
                                _updateStatus.value = UpdateCheckStatus.ReadyToInstall(destinationFile, updateInfo)
                                installApk(destinationFile)
                            }
                        } else {
                            scope.launch(Dispatchers.Main) {
                                _updateStatus.value = UpdateCheckStatus.Error("Download failed or was interrupted. Please try again.")
                            }
                        }
                    }
                }
            }

            downloadReceiver = receiver
            val intentFilter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, intentFilter, Context.RECEIVER_EXPORTED)
            } else {
                context.registerReceiver(receiver, intentFilter)
            }

            // Start polling DownloadManager cursor for live progress reporting
            progressPollingJob = scope.launch(Dispatchers.IO) {
                var isPolling = true
                while (isPolling) {
                    delay(400)
                    val activeId = currentDownloadId ?: break
                    val query = DownloadManager.Query().setFilterById(activeId)
                    val cursor = downloadManager.query(query)
                    if (cursor != null && cursor.moveToFirst()) {
                        val bytesDownloadedIdx = cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                        val bytesTotalIdx = cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                        val statusIdx = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)

                        val downloaded = if (bytesDownloadedIdx != -1) cursor.getLong(bytesDownloadedIdx) else 0L
                        val total = if (bytesTotalIdx != -1) cursor.getLong(bytesTotalIdx) else 0L
                        val status = if (statusIdx != -1) cursor.getInt(statusIdx) else -1
                        cursor.close()

                        if (status == DownloadManager.STATUS_SUCCESSFUL || status == DownloadManager.STATUS_FAILED) {
                            isPolling = false
                        } else {
                            val progress = if (total > 0) (downloaded.toFloat() / total).coerceIn(0f, 1f) else 0.5f
                            withContext(Dispatchers.Main) {
                                _updateStatus.value = UpdateCheckStatus.Downloading(progress, downloaded, total)
                            }
                        }
                    } else {
                        cursor?.close()
                        isPolling = false
                    }
                }
            }

        } catch (e: Exception) {
            Log.e(TAG, "Failed to initiate DownloadManager: ${e.message}", e)
            _updateStatus.value = UpdateCheckStatus.Error("Could not start download: ${e.localizedMessage}")
        }
    }

    /**
     * Trigger Android Package Installer Intent using FileProvider.
     * Action: Intent.ACTION_VIEW
     * Data: content:// URI from FileProvider
     * Type: application/vnd.android.package-archive
     * Flag: FLAG_GRANT_READ_URI_PERMISSION or FLAG_ACTIVITY_NEW_TASK
     */
    fun installApk(apkFile: File) {
        try {
            if (!apkFile.exists()) {
                _updateStatus.value = UpdateCheckStatus.Error("Update APK file does not exist on storage.")
                return
            }

            // Handle Android 8.0+ (Oreo) install permission check seamlessly
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (!context.packageManager.canRequestPackageInstalls()) {
                    Log.i(TAG, "Prompting user to grant REQUEST_INSTALL_PACKAGES permission")
                    val settingsIntent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                        data = Uri.parse("package:${context.packageName}")
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(settingsIntent)
                }
            }

            val authority = "${context.packageName}.provider"
            val apkUri: Uri = FileProvider.getUriForFile(context, authority, apkFile)

            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
            }

            context.startActivity(installIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch package installer: ${e.message}", e)
            _updateStatus.value = UpdateCheckStatus.Error("Failed to launch package installer: ${e.localizedMessage}")
        }
    }

    /**
     * Fallback to opening the browser / web release URL.
     */
    fun openDownloadInBrowser(url: String? = null) {
        val targetUrl = url ?: (_updateStatus.value as? UpdateCheckStatus.UpdateAvailable)?.updateInfo?.downloadUrl
            ?: "https://github.com/adr-groupledger/releases/latest"
        try {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(browserIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open download link in browser: ${e.message}")
        }
    }

    /**
     * Allows Society Admins to publish and broadcast an update to all members via Cloud Firestore.
     */
    suspend fun publishAppUpdate(
        updateInfo: AppUpdateInfo,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val result = firebaseService?.publishAppUpdate(updateInfo)
        if (result != null && result.isSuccess) {
            _updateStatus.value = UpdateCheckStatus.UpdateAvailable(updateInfo)
            onSuccess()
        } else {
            val errorMsg = result?.exceptionOrNull()?.localizedMessage ?: "Failed to publish update to Firestore"
            onError(errorMsg)
        }
    }

    /**
     * Test utility to simulate a fresh update available for testing.
     */
    fun simulateNewUpdateForTesting() {
        val simulated = AppUpdateInfo(
            versionCode = currentVersionCode + 1,
            versionName = "1.1",
            minSupportedVersionCode = currentVersionCode,
            title = "Update Available",
            releaseNotes = "A new version of Group Ledger is available. Please update now to continue using the app.",
            releaseDate = System.currentTimeMillis(),
            downloadUrl = "https://github.com/adr-groupledger/releases/download/v1.1/groupledger-v1.1.apk",
            isMandatory = false,
            fileSizeBytes = 18_450_000L,
            publishedBy = "Admin",
            changelogBullets = listOf("A new version of Group Ledger is available. Please update now to continue using the app.")
        )
        _isBannerDismissed.value = false
        _updateStatus.value = UpdateCheckStatus.UpdateAvailable(simulated)
    }

    fun dismissUpdateBanner() {
        _isBannerDismissed.value = true
    }

    fun resetStatus() {
        _updateStatus.value = UpdateCheckStatus.Idle
    }

    private fun unregisterDownloadReceiver() {
        downloadReceiver?.let {
            try {
                context.unregisterReceiver(it)
            } catch (e: Exception) {
                Log.w(TAG, "Receiver already unregistered: ${e.message}")
            }
            downloadReceiver = null
        }
    }

    fun cleanup() {
        listenerRegistration?.invoke()
        unregisterDownloadReceiver()
        progressPollingJob?.cancel()
    }
}
