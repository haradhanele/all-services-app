package com.adr.groupledger.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "group_join_requests",
    indices = [
        Index(value = ["groupId", "userId"])
    ]
)
data class GroupJoinRequest(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val groupId: Long,
    val groupName: String = "",
    val userId: Long,
    val name: String,
    val email: String,
    val phone: String = "",
    val requestedAt: Long = System.currentTimeMillis(),
    val status: String = "PENDING", // "PENDING", "APPROVED", "REJECTED"
    val processedAt: Long? = null,
    val processedBy: String? = null
) {
    val applicantName: String get() = name
    val applicantEmail: String get() = email
    val applicantPhone: String get() = phone
    val requestDate: String get() = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault()).format(java.util.Date(requestedAt))
    val isPending: Boolean get() = status.equals("PENDING", ignoreCase = true)
    val isApproved: Boolean get() = status.equals("APPROVED", ignoreCase = true)
    val isRejected: Boolean get() = status.equals("REJECTED", ignoreCase = true)
}
