const { describe, it } = require("node:test");
const assert = require("node:assert");
const http = require("http");

const FIRESTORE_PORT = 8085;
const PROJECT_ID = "demo-group-ledger";
const BASE_PATH = `/v1/projects/${PROJECT_ID}/databases/(default)/documents`;

/**
 * Creates an unsigned JWT recognized by the Firestore emulator.
 */
function makeToken(uid, appRole = "REGULAR_USER", extraClaims = {}) {
  const header = Buffer.from(JSON.stringify({ alg: "none", typ: "JWT" })).toString("base64url");
  const payload = Buffer.from(
    JSON.stringify({
      sub: uid,
      user_id: uid,
      appRole,
      ...extraClaims
    })
  ).toString("base64url");
  return `${header}.${payload}.`;
}

/**
 * Encodes a simple JS object into Firestore REST API value format.
 */
function toFirestoreFields(obj) {
  const fields = {};
  for (const [key, value] of Object.entries(obj)) {
    if (typeof value === "string") {
      fields[key] = { stringValue: value };
    } else if (typeof value === "number") {
      if (Number.isInteger(value)) {
        fields[key] = { integerValue: value.toString() };
      } else {
        fields[key] = { doubleValue: value };
      }
    } else if (typeof value === "boolean") {
      fields[key] = { booleanValue: value };
    } else if (Array.isArray(value)) {
      fields[key] = {
        arrayValue: {
          values: value.map(item => ({ stringValue: String(item) }))
        }
      };
    }
  }
  return { fields };
}

/**
 * Makes an HTTP request to the Firestore emulator REST API.
 */
function firestoreRequest(method, docPath, token = null, data = null) {
  return new Promise((resolve, reject) => {
    let path = `${BASE_PATH}/${docPath}`;
    let body = null;
    if (data && (method === "POST" || method === "PATCH")) {
      body = JSON.stringify(toFirestoreFields(data));
    }

    const headers = {};
    if (token) {
      headers["Authorization"] = `Bearer ${token}`;
    }
    if (body) {
      headers["Content-Type"] = "application/json";
      headers["Content-Length"] = Buffer.byteLength(body);
    }

    const req = http.request(
      {
        hostname: "127.0.0.1",
        port: FIRESTORE_PORT,
        path,
        method,
        headers
      },
      (res) => {
        let raw = "";
        res.on("data", (chunk) => { raw += chunk; });
        res.on("end", () => {
          let parsed;
          try {
            parsed = JSON.parse(raw);
          } catch (_) {
            parsed = raw;
          }
          resolve({ statusCode: res.statusCode, body: parsed });
        });
      }
    );

    req.on("error", reject);
    if (body) {
      req.write(body);
    }
    req.end();
  });
}

describe("Comprehensive Firestore Security Rules Verification (20 Test Scenarios)", () => {

  const userA_Uid = "user_A_101";
  const userB_Uid = "user_B_202";
  const groupAdmin_Uid = "admin_samiti_303";
  const appAdmin_Uid = "global_app_admin_404";
  const contentManager_Uid = "content_mgr_505";
  const nonMember_Uid = "stranger_606";

  const tokenUserA = makeToken(userA_Uid, "REGULAR_USER");
  const tokenUserB = makeToken(userB_Uid, "REGULAR_USER");
  const tokenGroupAdmin = makeToken(groupAdmin_Uid, "REGULAR_USER");
  const tokenAppAdmin = makeToken(appAdmin_Uid, "APP_ADMIN");
  const tokenContentManager = makeToken(contentManager_Uid, "CONTENT_MANAGER");
  const tokenNonMember = makeToken(nonMember_Uid, "REGULAR_USER");

  const groupA_Id = "group_A_701";
  const groupB_Id = "group_B_702";

  // 1. Unauthenticated read denied
  it("Test 1: Unauthenticated read denied on private collections", async () => {
    const res = await firestoreRequest("GET", "users/user_A_101", null);
    assert.strictEqual(res.statusCode, 403, "Unauthenticated read on users must be denied with 403");
  });

  // 2. Unauthenticated write denied
  it("Test 2: Unauthenticated write denied on private collections", async () => {
    const res = await firestoreRequest("POST", "users?documentId=user_A_101", null, {
      uid: userA_Uid,
      fullName: "Intruder User"
    });
    assert.strictEqual(res.statusCode, 403, "Unauthenticated write must be denied with 403");
  });

  // 3. User own data allowed
  it("Test 3: User can create and read their own user profile document", async () => {
    const createRes = await firestoreRequest("POST", `users?documentId=${userA_Uid}`, tokenUserA, {
      uid: userA_Uid,
      fullName: "User A Genuine",
      email: "user_a@example.com"
    });
    assert.strictEqual(createRes.statusCode, 200, "User must be allowed to create their own profile");

    const readRes = await firestoreRequest("GET", `users/${userA_Uid}`, tokenUserA);
    assert.strictEqual(readRes.statusCode, 200, "User must be allowed to read user profile");
  });

  // 4. User other data denied
  it("Test 4: User cannot write to another user's profile document", async () => {
    const res = await firestoreRequest("POST", `users?documentId=${userB_Uid}`, tokenUserA, {
      uid: userB_Uid,
      fullName: "User A Spoofing User B"
    });
    assert.strictEqual(res.statusCode, 403, "User cannot create another user's profile");
  });

  // 5. Group creation and member access
  it("Test 5: Group Admin creates Group A with activeMemberUids and member access is allowed", async () => {
    const groupRes = await firestoreRequest("POST", `groups?documentId=${groupA_Id}`, tokenGroupAdmin, {
      id: 701,
      groupName: "Group A Society",
      ownerUid: groupAdmin_Uid,
      creatorUid: groupAdmin_Uid,
      activeMemberUids: [groupAdmin_Uid, userA_Uid]
    });
    assert.strictEqual(groupRes.statusCode, 200, "Group admin must be allowed to create group");

    // Group member User A can read Group A notices
    const noticeRead = await firestoreRequest("GET", `groups/${groupA_Id}/notices/notice_1`, tokenUserA);
    assert.strictEqual(noticeRead.statusCode, 404, "Member read on subcollection returns 404 (allowed but empty)");
  });

  // 6. Non-member access denied
  it("Test 6: Non-member cannot access private group subcollections", async () => {
    const noticeRes = await firestoreRequest("GET", `groups/${groupA_Id}/payments/pay_1`, tokenNonMember);
    assert.strictEqual(noticeRes.statusCode, 403, "Non-member must be denied access with 403");
  });

  // 7. Group Admin allowed operation
  it("Test 7: Group Admin can create group notices and add members", async () => {
    const noticeRes = await firestoreRequest("POST", `groups/${groupA_Id}/notices?documentId=notice_1`, tokenGroupAdmin, {
      id: 1,
      groupId: 701,
      title: "Monthly Meeting Notice",
      authorUid: groupAdmin_Uid
    });
    assert.strictEqual(noticeRes.statusCode, 200, "Group admin must be allowed to post notices");
  });

  // 8. Normal member denied Admin operation
  it("Test 8: Normal member cannot create notices or delete group", async () => {
    const res = await firestoreRequest("POST", `groups/${groupA_Id}/notices?documentId=notice_fake`, tokenUserA, {
      id: 99,
      groupId: 701,
      title: "Unauthorized Notice",
      authorUid: userA_Uid
    });
    assert.strictEqual(res.statusCode, 403, "Normal member must be denied creating notices");
  });

  // 9. APP_ADMIN allowed intended operation
  it("Test 9: APP_ADMIN is authorized to write to app_config", async () => {
    const configRes = await firestoreRequest("POST", "app_config?documentId=version_info", tokenAppAdmin, {
      minVersion: 10,
      latestVersion: 12
    });
    assert.strictEqual(configRes.statusCode, 200, "APP_ADMIN must be allowed to write app_config");
  });

  // 10. CONTENT_MANAGER allowed intended operation
  it("Test 10: CONTENT_MANAGER is authorized to create carousel_items", async () => {
    const carouselRes = await firestoreRequest("POST", "carousel_items?documentId=banner_festival", tokenContentManager, {
      title: "Diwali Special Promotion",
      orderIndex: 1
    });
    assert.strictEqual(carouselRes.statusCode, 200, "CONTENT_MANAGER must be allowed to manage carousel");
  });

  // 11. Role escalation denied
  it("Test 11: Regular user cannot self-assign APP_ADMIN role", async () => {
    const escalateRes = await firestoreRequest("POST", `users?documentId=escalate_user`, tokenUserB, {
      uid: userB_Uid,
      fullName: "Attacker User",
      appRole: "APP_ADMIN"
    });
    assert.strictEqual(escalateRes.statusCode, 403, "Self-assigning APP_ADMIN must be rejected with 403");
  });

  // 12. Cross-group read denied
  it("Test 12: Member of Group B cannot read Group A private subcollections", async () => {
    // Group B created
    await firestoreRequest("POST", `groups?documentId=${groupB_Id}`, tokenUserB, {
      id: 702,
      groupName: "Group B Independent",
      ownerUid: userB_Uid,
      creatorUid: userB_Uid,
      activeMemberUids: [userB_Uid]
    });

    const crossRead = await firestoreRequest("GET", `groups/${groupA_Id}/payments/pay_99`, tokenUserB);
    assert.strictEqual(crossRead.statusCode, 403, "Cross-group read on payments must be denied with 403");
  });

  // 13. Cross-group write denied
  it("Test 13: Member of Group B cannot write to Group A subcollections", async () => {
    const crossWrite = await firestoreRequest("POST", `groups/${groupA_Id}/payments?documentId=pay_cross`, tokenUserB, {
      id: 55,
      groupId: 701,
      amount: 5000,
      memberId: 202
    });
    assert.strictEqual(crossWrite.statusCode, 403, "Cross-group payment creation must be denied with 403");
  });

  // 14. Financial record manipulation denied
  it("Test 14: Ledger transactions cannot be updated (Strict Immutability)", async () => {
    // Admin creates legitimate ledger transaction
    const txnCreate = await firestoreRequest("POST", `groups/${groupA_Id}/transactions?documentId=txn_101`, tokenGroupAdmin, {
      id: 101,
      groupId: 701,
      type: "CREDIT",
      amount: 10000,
      description: "Member Contribution Collection"
    });
    assert.strictEqual(txnCreate.statusCode, 200, "Admin can create ledger transaction");

    // Attempt to update ledger transaction is rejected
    const txnUpdate = await firestoreRequest("PATCH", `groups/${groupA_Id}/transactions/txn_101`, tokenGroupAdmin, {
      amount: 99999
    });
    assert.strictEqual(txnUpdate.statusCode, 403, "Updating ledger transaction must be strictly forbidden");
  });

  // 15. Unauthorized delete denied
  it("Test 15: Financial payment records cannot be deleted", async () => {
    // User A records payment in Group A
    await firestoreRequest("POST", `groups/${groupA_Id}/payments?documentId=pay_101`, tokenUserA, {
      id: 101,
      groupId: 701,
      amount: 2500,
      memberId: 101
    });

    // Attempt to delete payment document must fail
    const delRes = await firestoreRequest("DELETE", `groups/${groupA_Id}/payments/pay_101`, tokenUserA);
    assert.strictEqual(delRes.statusCode, 403, "Deleting payment records must be strictly forbidden");
  });

  // 16. Bid authorization: Only eligible group member can participate in group
  it("Test 16: Non-member cannot create chat messages or submit bids", async () => {
    const msgRes = await firestoreRequest("POST", `groups/${groupA_Id}/messages?documentId=msg_hack`, tokenNonMember, {
      id: 1,
      groupId: 701,
      senderAuthUid: nonMember_Uid,
      text: "Malicious message"
    });
    assert.strictEqual(msgRes.statusCode, 403, "Non-member cannot post messages or participate in group");
  });

  // 17. Auction state protection
  it("Test 17: Normal member cannot alter group settings or auction state", async () => {
    const patchRes = await firestoreRequest("PATCH", `groups/${groupA_Id}`, tokenUserA, {
      auctionState: "AUCTION_CLOSED"
    });
    assert.strictEqual(patchRes.statusCode, 403, "Normal member cannot modify auction state in group settings");
  });

  // 18. Result protection: Normal member cannot create approved result in settings
  it("Test 18: Normal member cannot approve auction result", async () => {
    const patchRes = await firestoreRequest("PATCH", `groups/${groupA_Id}`, tokenUserA, {
      auctionResultStatus: "RESULT_APPROVED"
    });
    assert.strictEqual(patchRes.statusCode, 403, "Normal member cannot approve auction results");
  });

  // 19. Settlement protection: Normal member cannot alter settlement state
  it("Test 19: Normal member cannot alter settlement state", async () => {
    const patchRes = await firestoreRequest("PATCH", `groups/${groupA_Id}`, tokenUserA, {
      settlementStatus: "SETTLED"
    });
    assert.strictEqual(patchRes.statusCode, 403, "Normal member cannot alter settlement status");
  });

  // 20. Carousel protection: Regular user cannot create or modify carousel
  it("Test 20: Regular user is denied from creating carousel items", async () => {
    const res = await firestoreRequest("POST", "carousel_items?documentId=hacked_banner", tokenUserA, {
      title: "Unauthorized Ad",
      orderIndex: 99
    });
    assert.strictEqual(res.statusCode, 403, "Regular user cannot create carousel banner");
  });
});
