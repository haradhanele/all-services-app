const { describe, it } = require("node:test");
const assert = require("node:assert");
const crypto = require("crypto");
const {
  ALLOWED_UPLOAD_PRESET,
  ALLOWED_FOLDER_PREFIX,
  ALLOWED_APP_ROLES,
  authenticateRequest,
  authorizeAppRole,
  validateUploadParameters,
  computeCloudinarySha1,
  resolveCloudinarySecret
} = require("../src/signatureService");

describe("Cloudinary Signature Service Backend Security Tests", () => {
  const MOCK_SECRET = "test_super_secret_cloudinary_key_123456";

  // Mock Admin Auth
  const mockAdminAuth = {
    verifyIdToken: async (token) => {
      if (token === "valid_admin_token") {
        return { uid: "user_app_admin_001", appRole: "APP_ADMIN" };
      }
      if (token === "valid_content_manager_token") {
        return { uid: "user_content_mgr_002", appRole: "CONTENT_MANAGER" };
      }
      if (token === "valid_group_admin_token") {
        // Group Admin for CC CUP, but regular user at app level
        return { uid: "user_group_admin_raj", appRole: "REGULAR_USER", groupRole: "ADMIN", groupName: "CC CUP" };
      }
      if (token === "valid_regular_user_token") {
        return { uid: "user_regular_003" };
      }
      if (token === "expired_token") {
        const err = new Error("Firebase ID token has expired. Get a fresh ID token and try again.");
        err.code = "auth/id-token-expired";
        throw err;
      }
      throw new Error("Decoding Firebase ID token failed. The token is invalid.");
    }
  };

  // 1. Missing authentication → 401
  it("Test 1: Missing authentication header throws 401", async () => {
    await assert.rejects(
      async () => {
        await authenticateRequest(undefined, mockAdminAuth);
      },
      (err) => {
        assert.strictEqual(err.statusCode, 401);
        assert.match(err.message, /Missing Authorization header/i);
        return true;
      }
    );
  });

  // 2. Invalid token → 401
  it("Test 2: Invalid token throws 401", async () => {
    await assert.rejects(
      async () => {
        await authenticateRequest("Bearer invalid_token_xyz", mockAdminAuth);
      },
      (err) => {
        assert.strictEqual(err.statusCode, 401);
        assert.match(err.message, /Authentication failed/i);
        return true;
      }
    );
  });

  // 3. Expired token → 401
  it("Test 3: Expired token throws 401", async () => {
    await assert.rejects(
      async () => {
        await authenticateRequest("Bearer expired_token", mockAdminAuth);
      },
      (err) => {
        assert.strictEqual(err.statusCode, 401);
        assert.match(err.message, /token has expired/i);
        return true;
      }
    );
  });

  // 4. REGULAR_USER → 403
  it("Test 4: REGULAR_USER without application-level permission is rejected with 403", async () => {
    const authResult = await authenticateRequest("Bearer valid_regular_user_token", mockAdminAuth);
    assert.strictEqual(authResult.uid, "user_regular_003");

    await assert.rejects(
      async () => {
        await authorizeAppRole(authResult.uid, authResult.decodedToken, null);
      },
      (err) => {
        assert.strictEqual(err.statusCode, 403);
        assert.match(err.message, /Forbidden/i);
        return true;
      }
    );
  });

  // 5. Group ADMIN without application role → 403
  it("Test 5: Group ADMIN (e.g. Raj in CC CUP) without application-level role is rejected with 403", async () => {
    const authResult = await authenticateRequest("Bearer valid_group_admin_token", mockAdminAuth);
    assert.strictEqual(authResult.uid, "user_group_admin_raj");
    assert.strictEqual(authResult.decodedToken.groupRole, "ADMIN");

    await assert.rejects(
      async () => {
        await authorizeAppRole(authResult.uid, authResult.decodedToken, null);
      },
      (err) => {
        assert.strictEqual(err.statusCode, 403);
        assert.match(err.message, /Local Group Admins are not permitted/i);
        return true;
      }
    );
  });

  // 6. APP_ADMIN → allowed
  it("Test 6: Valid APP_ADMIN token is authorized", async () => {
    const authResult = await authenticateRequest("Bearer valid_admin_token", mockAdminAuth);
    assert.strictEqual(authResult.uid, "user_app_admin_001");

    const authz = await authorizeAppRole(authResult.uid, authResult.decodedToken, null);
    assert.strictEqual(authz.authorized, true);
    assert.strictEqual(authz.appRole, "APP_ADMIN");
  });

  // 7. CONTENT_MANAGER → allowed
  it("Test 7: Valid CONTENT_MANAGER token is authorized", async () => {
    const authResult = await authenticateRequest("Bearer valid_content_manager_token", mockAdminAuth);
    assert.strictEqual(authResult.uid, "user_content_mgr_002");

    const authz = await authorizeAppRole(authResult.uid, authResult.decodedToken, null);
    assert.strictEqual(authz.authorized, true);
    assert.strictEqual(authz.appRole, "CONTENT_MANAGER");
  });

  // 8. Invalid folder → 400
  it("Test 8: Invalid folder outside cc_cup/carousel is rejected with 400", () => {
    assert.throws(
      () => {
        validateUploadParameters({
          folder: "other_app/secret_data",
          upload_preset: "Group_ledger_carousel"
        });
      },
      (err) => {
        assert.strictEqual(err.statusCode, 400);
        assert.match(err.message, /Invalid target folder/i);
        return true;
      }
    );
  });

  // 9. Invalid/injected parameters → 400
  it("Test 9: Injected parameters (overwrite, public_id, format) are rejected with 400", () => {
    assert.throws(
      () => {
        validateUploadParameters({
          folder: "cc_cup/carousel/test",
          upload_preset: "Group_ledger_carousel",
          overwrite: "true"
        });
      },
      (err) => {
        assert.strictEqual(err.statusCode, 400);
        assert.match(err.message, /Parameter 'overwrite' is forbidden/i);
        return true;
      }
    );
  });

  // 10. Correct Cloudinary signature
  it("Test 10: Correct Cloudinary SHA-1 signature generation matching specification", () => {
    const currentTimestamp = Math.floor(Date.now() / 1000);
    const validated = validateUploadParameters({
      folder: "cc_cup/carousel/announcements",
      timestamp: currentTimestamp.toString(),
      upload_preset: "Group_ledger_carousel"
    });

    assert.strictEqual(validated.uploadPreset, ALLOWED_UPLOAD_PRESET);
    assert.strictEqual(validated.folder, "cc_cup/carousel/announcements");
    assert.strictEqual(validated.timestamp, currentTimestamp);

    const signature = computeCloudinarySha1(validated.paramsToSign, MOCK_SECRET);
    assert.strictEqual(typeof signature, "string");
    assert.strictEqual(signature.length, 40); // 40 hex chars for SHA-1

    // Verify expected SHA-1 manually
    const expectedString = `folder=cc_cup/carousel/announcements&timestamp=${currentTimestamp}&upload_preset=Group_ledger_carousel` + MOCK_SECRET;
    const expectedSha1 = crypto.createHash("sha1").update(expectedString).digest("hex");
    assert.strictEqual(signature, expectedSha1);
  });

  // 11. API Secret never appears in response
  it("Test 11: Server response payload never contains the API Secret", () => {
    const currentTimestamp = Math.floor(Date.now() / 1000);
    const validated = validateUploadParameters({
      folder: "cc_cup/carousel/announcements",
      timestamp: currentTimestamp.toString(),
      upload_preset: "Group_ledger_carousel"
    });
    const signature = computeCloudinarySha1(validated.paramsToSign, MOCK_SECRET);

    const responsePayload = {
      signature,
      timestamp: validated.timestamp,
      apiKey: "498704388167",
      folder: validated.folder,
      uploadPreset: validated.uploadPreset
    };

    const serializedResponse = JSON.stringify(responsePayload);
    assert.strictEqual(serializedResponse.includes(MOCK_SECRET), false);
    assert.strictEqual(responsePayload.apiSecret, undefined);
    assert.strictEqual(responsePayload.secret, undefined);
    assert.strictEqual(responsePayload.cloudinary_api_secret, undefined);
  });

  // 12. Local secret resolution
  it("Test 12: resolveCloudinarySecret safely resolves local secret without hardcoding", () => {
    process.env.CLOUDINARY_API_SECRET = "test_env_secret_12345";
    const secret = resolveCloudinarySecret();
    assert.strictEqual(typeof secret, "string");
    assert.strictEqual(secret.length > 0, true);
    delete process.env.CLOUDINARY_API_SECRET;
  });
});
