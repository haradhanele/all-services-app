package com.adr.groupledger.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.IndigoPrimary

data class GroupExceptionItem(
    val id: String,
    val title: String,
    val description: String,
    val severity: String, // "INFO", "WARNING", "CRITICAL"
    val category: String, // "AUCTION", "CONTRIBUTION", "SETTLEMENT", "LEDGER"
    val status: String = "OPEN"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExceptionCenterScreen(
    viewModel: SocietyViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val chitConfig by viewModel.chitFundConfig.collectAsStateWithLifecycle()
    val cycles = chitConfig.cycles

    val exceptions = mutableListOf<GroupExceptionItem>()
    for (cycle in cycles) {
        if (cycle.status.name == "TIE_REQUIRES_ADMIN_REVIEW") {
            exceptions.add(
                GroupExceptionItem(
                    id = "tie_${cycle.cycleNumber}",
                    title = "Auction Tie - Cycle #${cycle.cycleNumber}",
                    description = "Multiple members placed identical winning bids requiring Administrator tie resolution.",
                    severity = "CRITICAL",
                    category = "AUCTION"
                )
            )
        }
        if (cycle.status.name == "RESULT_PENDING" || cycle.status.name == "RESULT_CALCULATED") {
            exceptions.add(
                GroupExceptionItem(
                    id = "review_${cycle.cycleNumber}",
                    title = "Result Pending Approval - Cycle #${cycle.cycleNumber}",
                    description = "Auction winner determined. Admin approval required to lock result & initiate settlement.",
                    severity = "WARNING",
                    category = "SETTLEMENT"
                )
            )
        }
        if (cycle.status.name == "SETTLEMENT_FAILED") {
            exceptions.add(
                GroupExceptionItem(
                    id = "settle_fail_${cycle.cycleNumber}",
                    title = "Settlement Exception - Cycle #${cycle.cycleNumber}",
                    description = "Prize payout reconciliation mismatch or missing member bank information.",
                    severity = "CRITICAL",
                    category = "SETTLEMENT"
                )
            )
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Exception & Reconciliation Center", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Unresolved operational flags & financial audits", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    TextButton(onClick = onNavigateBack) {
                        Text("Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Reconciliation Status", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            if (exceptions.isEmpty()) "All systems operational. No critical discrepancies or pending exceptions detected."
                            else "${exceptions.size} active operational item(s) require administrative review.",
                            fontSize = 12.sp,
                            color = if (exceptions.isEmpty()) Emerald500 else Rose500
                        )
                    }
                }
            }

            if (exceptions.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Emerald500, modifier = Modifier.size(56.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Zero Exceptions", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Your Chit Fund and Group Ledger are fully balanced.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            } else {
                items(exceptions, key = { it.id }) { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("exception_card_${item.id}"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, when (item.severity) {
                            "CRITICAL" -> Rose500.copy(alpha = 0.4f)
                            else -> Amber500.copy(alpha = 0.4f)
                        })
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = when (item.severity) {
                                            "CRITICAL" -> Icons.Default.Error
                                            else -> Icons.Default.Warning
                                        },
                                        contentDescription = null,
                                        tint = when (item.severity) {
                                            "CRITICAL" -> Rose500
                                            else -> Amber500
                                        },
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.size(8.dp))
                                    Text(item.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = when (item.severity) {
                                        "CRITICAL" -> Rose500.copy(alpha = 0.15f)
                                        else -> Amber500.copy(alpha = 0.15f)
                                    }
                                ) {
                                    Text(
                                        text = item.severity,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = when (item.severity) {
                                            "CRITICAL" -> Rose500
                                            else -> Amber500
                                        }
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(item.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
