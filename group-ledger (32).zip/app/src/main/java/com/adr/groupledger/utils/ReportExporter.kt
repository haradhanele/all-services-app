package com.adr.groupledger.utils

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.MemberWithMonthlyStatus
import com.adr.groupledger.data.model.Payment
import java.io.File
import java.io.FileOutputStream

object ReportExporter {

    fun exportMonthlyCsv(
        context: Context,
        settings: GroupSettings,
        monthName: String,
        year: Int,
        list: List<MemberWithMonthlyStatus>
    ): File? {
        try {
            val fileName = "Monthly_Report_${monthName}_$year.csv"
            val file = File(context.cacheDir, fileName)
            file.bufferedWriter().use { writer ->
                writer.write("${settings.groupName} - Monthly Collection Report\n")
                writer.write("Period: $monthName $year\n")
                writer.write("Generated on: ${DateUtils.formatDisplayDate(System.currentTimeMillis())}\n\n")
                writer.write("Member Code,Member Name,Phone,Expected (${settings.currencySymbol}),Paid (${settings.currencySymbol}),Due (${settings.currencySymbol}),Status,Payment Date,Payment Method,Reference\n")

                var totalExp = 0.0
                var totalPaid = 0.0
                var totalDue = 0.0

                for (item in list) {
                    val pay = item.payment
                    val pDate = if (pay != null && pay.paymentDate > 0) DateUtils.formatDisplayDate(pay.paymentDate) else "-"
                    val pMethod = pay?.paymentMethod ?: "-"
                    val pRef = pay?.transactionReference?.replace(",", " ") ?: ""

                    totalExp += item.effectiveExpectedAmount
                    totalPaid += item.paidAmount
                    totalDue += item.dueAmount

                    writer.write(
                        "\"${item.member.memberCode}\",\"${item.member.name}\",\"${item.member.phone}\"," +
                                "${item.effectiveExpectedAmount},${item.paidAmount},${item.dueAmount}," +
                                "\"${item.status}\",\"$pDate\",\"$pMethod\",\"$pRef\"\n"
                    )
                }

                writer.write("\nTOTAL,,,$totalExp,$totalPaid,$totalDue,,,\n")
            }
            return file
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    fun exportPendingDuesCsv(
        context: Context,
        settings: GroupSettings,
        monthName: String,
        year: Int,
        pendingList: List<MemberWithMonthlyStatus>
    ): File? {
        try {
            val fileName = "Pending_Dues_${monthName}_$year.csv"
            val file = File(context.cacheDir, fileName)
            file.bufferedWriter().use { writer ->
                writer.write("${settings.groupName} - Pending Dues Report\n")
                writer.write("Period: $monthName $year\n")
                writer.write("Generated on: ${DateUtils.formatDisplayDate(System.currentTimeMillis())}\n\n")
                writer.write("Member Code,Member Name,Phone,Address,Expected (${settings.currencySymbol}),Paid (${settings.currencySymbol}),Due Amount (${settings.currencySymbol}),Status\n")

                var totalDue = 0.0
                for (item in pendingList) {
                    totalDue += item.dueAmount
                    writer.write(
                        "\"${item.member.memberCode}\",\"${item.member.name}\",\"${item.member.phone}\",\"${item.member.address.replace(",", " ")}\"," +
                                "${item.effectiveExpectedAmount},${item.paidAmount},${item.dueAmount},\"${item.status}\"\n"
                    )
                }
                writer.write("\nTOTAL PENDING DUES,,,,,,$totalDue,\n")
            }
            return file
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    fun generatePdfReport(
        context: Context,
        settings: GroupSettings,
        reportTitle: String,
        subtitle: String,
        headers: List<String>,
        rows: List<List<String>>,
        summaryMap: Map<String, String>
    ): File? {
        try {
            val pdfDoc = PdfDocument()
            val pageWidth = 595 // A4 standard width in points
            val pageHeight = 842 // A4 standard height in points

            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
            val page = pdfDoc.startPage(pageInfo)
            val canvas: Canvas = page.canvas

            val titlePaint = Paint().apply {
                color = Color.rgb(0, 109, 91) // EmeraldPrimary
                textSize = 18f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }

            val subtitlePaint = Paint().apply {
                color = Color.DKGRAY
                textSize = 11f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                isAntiAlias = true
            }

            val headerPaint = Paint().apply {
                color = Color.rgb(240, 245, 243)
                style = Paint.Style.FILL
            }

            val textPaint = Paint().apply {
                color = Color.BLACK
                textSize = 9.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                isAntiAlias = true
            }

            val headerTextPaint = Paint().apply {
                color = Color.rgb(0, 56, 46)
                textSize = 10f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }

            val linePaint = Paint().apply {
                color = Color.LTGRAY
                strokeWidth = 0.8f
            }

            var y = 40f

            // 1. Group Header
            canvas.drawText(settings.groupName, 36f, y, titlePaint)
            y += 18f
            canvas.drawText(settings.groupSubtitle, 36f, y, subtitlePaint)
            y += 16f
            canvas.drawText("$reportTitle - $subtitle", 36f, y, titlePaint.apply { textSize = 14f; color = Color.BLACK })
            y += 14f
            canvas.drawText("Generated on: ${DateUtils.formatDateTime(System.currentTimeMillis())}", 36f, y, subtitlePaint)
            y += 18f

            // 2. Summary Metrics Box
            if (summaryMap.isNotEmpty()) {
                val boxPaint = Paint().apply {
                    color = Color.rgb(235, 245, 240)
                    style = Paint.Style.FILL
                }
                canvas.drawRoundRect(36f, y, (pageWidth - 36).toFloat(), y + 36f, 6f, 6f, boxPaint)
                var statX = 50f
                val statStep = (pageWidth - 100) / summaryMap.size.coerceAtLeast(1)
                for ((key, value) in summaryMap) {
                    canvas.drawText(key, statX, y + 15f, subtitlePaint.apply { textSize = 8.5f })
                    canvas.drawText(value, statX, y + 29f, headerTextPaint.apply { textSize = 11f })
                    statX += statStep
                }
                y += 50f
            }

            // 3. Table Header
            val tableLeft = 36f
            val tableRight = (pageWidth - 36).toFloat()
            val columnWidth = (tableRight - tableLeft) / headers.size.coerceAtLeast(1)

            canvas.drawRect(tableLeft, y, tableRight, y + 24f, headerPaint)
            for (i in headers.indices) {
                val hx = tableLeft + (i * columnWidth) + 6f
                canvas.drawText(headers[i], hx, y + 16f, headerTextPaint)
            }
            y += 24f
            canvas.drawLine(tableLeft, y, tableRight, y, linePaint)

            // 4. Table Rows (Up to page limit)
            val maxRows = 28
            val displayedRows = rows.take(maxRows)
            for (rowIndex in displayedRows.indices) {
                val row = displayedRows[rowIndex]
                if (rowIndex % 2 == 1) {
                    val altPaint = Paint().apply { color = Color.rgb(250, 252, 251); style = Paint.Style.FILL }
                    canvas.drawRect(tableLeft, y, tableRight, y + 20f, altPaint)
                }

                for (colIndex in row.indices) {
                    if (colIndex < headers.size) {
                        val cx = tableLeft + (colIndex * columnWidth) + 6f
                        val cellText = row[colIndex]
                        val truncated = if (cellText.length > 18) cellText.take(16) + ".." else cellText
                        canvas.drawText(truncated, cx, y + 14f, textPaint)
                    }
                }
                y += 20f
                canvas.drawLine(tableLeft, y, tableRight, y, linePaint)
            }

            // Footer
            val footerPaint = Paint().apply {
                color = Color.GRAY
                textSize = 8.5f
                isAntiAlias = true
            }
            canvas.drawText("Samiti Group Financial Manager | Authorized Administrator Report", 36f, pageHeight - 25f, footerPaint)

            pdfDoc.finishPage(page)

            val safeTitle = reportTitle.replace(" ", "_")
            val pdfFile = File(context.cacheDir, "${safeTitle}_Report.pdf")
            FileOutputStream(pdfFile).use { out ->
                pdfDoc.writeTo(out)
            }
            pdfDoc.close()
            return pdfFile
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    /**
     * Exports full Chit Fund Cycle History & Member Standings as a structured CSV document.
     */
    fun exportChitFundCsv(
        context: Context,
        settings: GroupSettings,
        overview: com.adr.groupledger.data.model.ChitFundReportOverview,
        cycleItems: List<com.adr.groupledger.data.model.ChitCycleReportItem>,
        memberSummaries: List<com.adr.groupledger.data.model.ChitMemberFinancialSummary>
    ): File? {
        try {
            val fileName = "Chit_Fund_Report_${System.currentTimeMillis()}.csv"
            val file = File(context.cacheDir, fileName)
            val curr = settings.currencySymbol.ifBlank { "₹" }

            file.bufferedWriter().use { writer ->
                writer.write("${settings.groupName} - Chit Fund Financial Statement\n")
                writer.write("Category: Savings, Credit & Chit Fund\n")
                writer.write("Generated on: ${DateUtils.formatDisplayDate(System.currentTimeMillis())}\n\n")

                // Overview metrics
                writer.write("SCHEME OVERVIEW\n")
                writer.write("Total Chit Value,$curr${overview.totalChitValue.toInt()}\n")
                writer.write("Total Members,${overview.totalMembers}\n")
                writer.write("Total Cycles,${overview.totalCycles}\n")
                writer.write("Completed Cycles,${overview.completedCyclesCount}\n")
                writer.write("Current Round,Round #${overview.currentCycleNumber}\n")
                writer.write("Remaining Cycles,${overview.remainingCyclesCount}\n")
                writer.write("Total Contributions Collected,$curr${overview.totalContributionsCollected.toInt()}\n")
                writer.write("Total Auction Discounts,$curr${overview.totalAuctionDiscounts.toInt()}\n")
                writer.write("Total Settled Prize Outflow,$curr${overview.totalSettledPrizeAmount.toInt()}\n")
                writer.write("Total Foreman Commission Earned,$curr${overview.totalForemanCommission.toInt()}\n")
                writer.write("Total Dividends Distributed,$curr${overview.totalDividendsDistributed.toInt()}\n\n")

                // Cycle History Table
                writer.write("CYCLE / ROUND HISTORY\n")
                writer.write("Round #,Date,Status,Total Pot ($curr),Winning Bid ($curr),Winner Name,Prize Payout ($curr),Commission ($curr),Dividend/Member ($curr),Settlement Status,Payout Ref\n")
                for (item in cycleItems) {
                    val dateStr = if (item.scheduledDateMillis > 0) DateUtils.formatDisplayDate(item.scheduledDateMillis) else "-"
                    val winBid = item.winningBidAmount?.toInt()?.toString() ?: "-"
                    val winName = item.winnerMemberName?.replace(",", " ") ?: "-"
                    val payout = item.prizePayoutAmount?.toInt()?.toString() ?: "-"
                    val comm = item.foremanCommission?.toInt()?.toString() ?: "-"
                    val div = item.dividendPerMember?.toInt()?.toString() ?: "-"
                    val ref = item.payoutTxnRef?.replace(",", " ") ?: "-"

                    writer.write(
                        "Round #${item.cycleNumber},\"$dateStr\",\"${item.cycleStatus.displayName}\",${item.totalPot.toInt()}," +
                        "$winBid,\"$winName\",$payout,$comm,$div,\"${item.settlementStatus}\",\"$ref\"\n"
                    )
                }

                writer.write("\n")

                // Member Financial Position Table
                writer.write("MEMBER CHIT FUND FINANCIAL STANDINGS\n")
                writer.write("Member Code,Member Name,Phone,Installments Paid ($curr),Due Balance ($curr),Dividends Earned ($curr),Rounds Won,Prize Money Received ($curr),Net Financial Position ($curr)\n")
                for (mem in memberSummaries) {
                    val wonRoundsStr = if (mem.wonRounds.isNotEmpty()) mem.wonRounds.joinToString(";") { "R#$it" } else "None"
                    writer.write(
                        "\"${mem.member.memberCode}\",\"${mem.member.name}\",\"${mem.member.phone}\"," +
                        "${mem.totalPaidAmount.toInt()},${mem.totalDueAmount.toInt()},${mem.totalDividendsEarned.toInt()}," +
                        "\"$wonRoundsStr\",${mem.totalPrizeReceived.toInt()},${mem.netFinancialPosition.toInt()}\n"
                    )
                }
            }
            return file
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    fun shareFile(context: Context, file: File, mimeType: String, chooserTitle: String = "Share Document") {
        try {
            val contentUri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.provider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, contentUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(shareIntent, chooserTitle).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Error opening file share: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
