package com.adr.groupledger.data.model

/**
 * Report navigation tabs for Chit Fund Category-Aware Reporting.
 */
enum class ChitReportTab(val title: String) {
    OVERVIEW("Overview"),
    CYCLES("Cycle History"),
    AUCTIONS("Auctions & Bids"),
    CONTRIBUTIONS("Contributions"),
    SETTLEMENTS("Settlements & Ledger"),
    MEMBER_VIEW("Member Ledger")
}

/**
 * High-level financial and cycle overview for Chit Fund Scheme.
 */
data class ChitFundReportOverview(
    val totalChitValue: Double = 0.0,
    val totalMembers: Int = 0,
    val totalCycles: Int = 0,
    val completedCyclesCount: Int = 0,
    val currentCycleNumber: Int = 1,
    val remainingCyclesCount: Int = 0,
    val totalContributionsCollected: Double = 0.0,
    val totalAuctionDiscounts: Double = 0.0,
    val totalSettledPrizeAmount: Double = 0.0,
    val totalForemanCommission: Double = 0.0,
    val totalDividendsDistributed: Double = 0.0,
    val pendingSettlementCount: Int = 0,
    val pendingSettlementAmount: Double = 0.0,
    val isAllReconciled: Boolean = true,
    val reconciliationMessage: String = "All transactions reconciled with Group Ledger"
)

/**
 * Detailed report line item for an individual Chit cycle/round.
 */
data class ChitCycleReportItem(
    val cycle: ChitCycle,
    val cycleNumber: Int,
    val scheduledDateMillis: Long,
    val installmentAmount: Double,
    val totalPot: Double,
    val cycleStatus: ChitCycleStatus,
    val winnerMemberId: Long?,
    val winnerMemberName: String?,
    val winningBidAmount: Double?,
    val prizePayoutAmount: Double?,
    val foremanCommission: Double?,
    val dividendPerMember: Double?,
    val settlementStatus: String,
    val payoutTxnRef: String?,
    val commissionTxnRef: String?,
    val bidsCount: Int,
    val validBidsCount: Int,
    val totalCollectedForCycle: Double,
    val totalExpectedForCycle: Double,
    val isCycleReconciled: Boolean
)

/**
 * Member-specific Chit Fund financial summary and ledger position.
 */
data class ChitMemberFinancialSummary(
    val member: Member,
    val totalPaidAmount: Double = 0.0,
    val totalDueAmount: Double = 0.0,
    val totalDividendsEarned: Double = 0.0,
    val participatedAuctionsCount: Int = 0,
    val wonRounds: List<Int> = emptyList(),
    val totalPrizeReceived: Double = 0.0,
    val netFinancialPosition: Double = 0.0, // (Prize received + Dividends earned) - Total installments paid
    val paymentHistory: List<Payment> = emptyList()
)

/**
 * Chit Fund internal financial reconciliation status with Group Ledger.
 */
data class ChitReconciliationSummary(
    val isAllReconciled: Boolean,
    val totalLedgerPrizePaid: Double,
    val totalCalculatedPrizeDue: Double,
    val totalLedgerCommission: Double,
    val totalCalculatedCommission: Double,
    val totalSettledCyclesCount: Int,
    val mismatchedCycleNumbers: List<Int> = emptyList(),
    val statusMessage: String
)

/**
 * Phase B.7: Comprehensive Collection Summary for a specific Chit Fund cycle/round.
 */
data class ChitCycleCollectionSummary(
    val cycleNumber: Int,
    val scheduledDateMillis: Long,
    val dueDateMillis: Long,
    val requiredContributionPerMember: Double,
    val totalEligibleMembers: Int,
    val totalExpectedCollection: Double,
    val totalCollectedAmount: Double,
    val pendingCollectionAmount: Double,
    val collectionPercentage: Float,
    val paidMembersCount: Int,
    val partialMembersCount: Int,
    val pendingMembersCount: Int,
    val overdueMembersCount: Int,
    val totalFineApplicable: Double,
    val isFullyCollected: Boolean,
    val isReconciled: Boolean,
    val reconciliationMessage: String = "Collection reconciled with member ledger"
)

/**
 * Phase B.7: Member-level payment and contribution status for a specific cycle.
 */
data class ChitMemberPaymentStatus(
    val member: Member,
    val cycleNumber: Int,
    val month: Int,
    val year: Int,
    val requiredAmount: Double,
    val paidAmount: Double,
    val remainingDue: Double,
    val fineAmount: Double,
    val totalDueWithFine: Double,
    val dueDateMillis: Long,
    val isOverdue: Boolean,
    val daysOverdue: Int,
    val paymentStatus: String, // "PAID", "PARTIAL", "PENDING", "OVERDUE", "WAIVED"
    val lastPaymentDate: Long? = null,
    val paymentMethod: String? = null,
    val transactionReference: String? = null,
    val approvalStatus: String = "APPROVED",
    val linkedPaymentId: Long? = null,
    val notes: String = ""
)

/**
 * Phase B.7: Member-facing "My Contribution" overview across current scheme.
 */
data class ChitMyContributionProfile(
    val member: Member,
    val currentCycleSummary: ChitCycleCollectionSummary?,
    val currentCyclePaymentStatus: ChitMemberPaymentStatus?,
    val totalLifetimeContributionsPaid: Double,
    val totalLifetimeOutstandingDue: Double,
    val totalDividendsReceived: Double,
    val netChitStanding: Double,
    val cyclePaymentHistory: List<ChitMemberPaymentStatus> = emptyList()
)

