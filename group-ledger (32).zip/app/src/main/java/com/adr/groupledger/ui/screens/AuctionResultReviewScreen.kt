package com.adr.groupledger.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.ChitAuctionResult
import com.adr.groupledger.data.model.ChitAuctionResultStatus
import com.adr.groupledger.data.model.ChitCycle
import com.adr.groupledger.data.model.ChitCycleStatus
import com.adr.groupledger.data.model.ChitFundConfig
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.utils.ChitCalculationEngine
import com.adr.groupledger.utils.CurrencyFormatter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Phase B.4 — Chit Fund Auction Result, Winner Determination & Settlement Preview Screen.
 *
 * Implements:
 * 1. Strict Winner Determination & Tie Detection under configured business rule.
 * 2. Financial Calculation Preview with transparent step-by-step breakdown.
 * 3. Prominent "Settlement not completed" badge & safeguards.
 * 4. Group Admin Result Review, Approval, Rejection with reason, and Tie Resolution.
 * 5. Role-based security (Admins only for review & approve, members see public summary).
 * 6. Non-mutating: DOES NOT alter member balances, cash balances, or ledger records.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuctionResultReviewScreen(
    cycleNumber: Int,
    viewModel: SocietyViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToLedger: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()
    val currentUserRole by viewModel.currentUserRole.collectAsStateWithLifecycle()
    val isGroupAdmin = isAdminUnlocked || currentUserRole.equals("ADMIN", ignoreCase = true)
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()

    val chitConfig = remember(settings) { ChitFundConfig.parseFromSettings(settings) }
    val curr = settings.currencySymbol.ifBlank { "₹" }

    val cycle = remember(chitConfig.cycles, cycleNumber) {
        chitConfig.cycles.find { it.cycleNumber == cycleNumber }
            ?: ChitCycle(cycleNumber = cycleNumber)
    }

    val totalMembers = chitConfig.totalMembers ?: 20

    // Authoritative result resolution: from cycle or computed live
    val auctionResult = remember(cycle, totalMembers, chitConfig.auctionRule) {
        cycle.auctionResult ?: ChitCalculationEngine.calculateAuthoritativeAuctionResult(
            cycle = cycle,
            totalMembers = totalMembers,
            auctionRule = chitConfig.auctionRule,
            foremanCommissionPercent = 5.0
        )
    }

    var showRejectDialog by remember { mutableStateOf(false) }
    var rejectionReasonInput by remember { mutableStateOf("") }
    var showTieResolveDialog by remember { mutableStateOf(false) }
    var selectedTieMemberId by remember { mutableStateOf<Long?>(null) }
    var tieNotesInput by remember { mutableStateOf("") }
    var showApproveConfirmDialog by remember { mutableStateOf(false) }
    var adminApprovalNotes by remember { mutableStateOf("") }
    var showSettleConfirmDialog by remember { mutableStateOf(false) }
    var settlementPaymentMethod by remember { mutableStateOf("Bank Transfer") }
    var settlementNotesInput by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Auction Result • Round #${cycle.cycleNumber}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (isGroupAdmin) "Admin Review & Settlement" else "Auction Result Summary",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    if (isGroupAdmin) {
                        IconButton(
                            onClick = {
                                viewModel.calculateAuctionResult(
                                    cycleNumber = cycle.cycleNumber,
                                    onSuccess = {
                                        Toast.makeText(context, "Result refreshed", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            },
                            modifier = Modifier.testTag("admin_refresh_result_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Recalculate Result",
                                tint = IndigoPrimary
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Settlement Status / Preview Safeguard Notice Banner
            SettlementStatusNoticeCard(
                result = auctionResult,
                cycle = cycle,
                curr = curr,
                onNavigateToLedger = onNavigateToLedger
            )

            // 2. Member Privacy View (If not admin and result not yet approved)
            if (!isGroupAdmin && auctionResult.resultStatus != ChitAuctionResultStatus.RESULT_APPROVED &&
                auctionResult.resultStatus != ChitAuctionResultStatus.SETTLEMENT_PENDING &&
                auctionResult.resultStatus != ChitAuctionResultStatus.SETTLED
            ) {
                MemberResultPendingCard(
                    cycleNumber = cycle.cycleNumber,
                    status = auctionResult.resultStatus
                )
            } else {
                // Admin or Public Approved View

                // 3. Auction Overview Card
                AuctionOverviewCard(
                    cycle = cycle,
                    result = auctionResult
                )

                // 4. Tie Warning Card (If tie detected)
                if (auctionResult.isTie) {
                    TieDetectedAlertCard(
                        result = auctionResult,
                        isGroupAdmin = isGroupAdmin,
                        onResolveTieClick = {
                            selectedTieMemberId = auctionResult.tiedMemberIds.firstOrNull()
                            showTieResolveDialog = true
                        }
                    )
                }

                // 5. Rule Missing Warning Card (If rule missing)
                if (auctionResult.resultStatus == ChitAuctionResultStatus.RESULT_REQUIRES_RULE) {
                    RuleMissingCard(result = auctionResult)
                }

                // 6. Winning Bid Section Card
                WinningBidSummaryCard(
                    curr = curr,
                    result = auctionResult,
                    cycle = cycle
                )

                // 7. Financial Calculation & Settlement Preview Card (Section 10 & 11)
                FinancialCalculationPreviewCard(
                    curr = curr,
                    result = auctionResult,
                    cycle = cycle,
                    totalMembers = totalMembers
                )

                // 8. Result Status & Review Audit Card
                ResultAuditDetailsCard(
                    result = auctionResult,
                    cycle = cycle
                )

                // 9. Admin Review Actions (Approve, Reject, Advance to Settlement Pending, Settle)
                if (isGroupAdmin) {
                    AdminResultActionsCard(
                        result = auctionResult,
                        cycle = cycle,
                        onApprove = { showApproveConfirmDialog = true },
                        onReject = { showRejectDialog = true },
                        onMarkSettlementPending = {
                            viewModel.markSettlementPending(
                                cycleNumber = cycle.cycleNumber,
                                onSuccess = {
                                    Toast.makeText(context, "Settlement pending marked", Toast.LENGTH_SHORT).show()
                                }
                            )
                        },
                        onSettle = { showSettleConfirmDialog = true },
                        onNavigateToLedger = onNavigateToLedger
                    )
                }
            }
        }
    }

    // Dialog: Execute Financial Settlement & Post to Group Ledger
    if (showSettleConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showSettleConfirmDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Emerald500,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "Settle Round #${cycle.cycleNumber} & Post to Ledger",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "This action will officially execute financial settlement and generate permanent accounting records:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Winner Payout (Debit / Expense):", style = MaterialTheme.typography.bodySmall)
                                Text(
                                    text = "$curr${CurrencyFormatter.formatIndian(auctionResult.estimatedOutcome?.prizePayoutAmount ?: 0.0)}",
                                    fontWeight = FontWeight.Bold,
                                    color = Emerald500
                                )
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Foreman Commission (Credit / Income):", style = MaterialTheme.typography.bodySmall)
                                Text(
                                    text = "$curr${CurrencyFormatter.formatIndian(auctionResult.estimatedOutcome?.foremanCommission ?: 0.0)}",
                                    fontWeight = FontWeight.Bold,
                                    color = IndigoPrimary
                                )
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Dividend per Member (Credit / Adj):", style = MaterialTheme.typography.bodySmall)
                                Text(
                                    text = "$curr${CurrencyFormatter.formatIndian(auctionResult.estimatedOutcome?.dividendPerMember ?: 0.0)}",
                                    fontWeight = FontWeight.Bold,
                                    color = Amber500
                                )
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Beneficiary Member:", style = MaterialTheme.typography.bodySmall)
                                Text(
                                    text = auctionResult.winningMemberName ?: "Declared Winner",
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    Text("Payment Method for Payout:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Bank Transfer", "UPI", "Cash", "Cheque").forEach { method ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (settlementPaymentMethod == method) IndigoPrimary else MaterialTheme.colorScheme.surfaceContainerHigh,
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (settlementPaymentMethod == method) IndigoPrimary else MaterialTheme.colorScheme.surfaceContainerHigh)
                            ) {
                                TextButton(
                                    onClick = { settlementPaymentMethod = method },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = method,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (settlementPaymentMethod == method) Color.White else MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = settlementNotesInput,
                        onValueChange = { settlementNotesInput = it },
                        label = { Text("Settlement Notes / Voucher Ref") },
                        placeholder = { Text("e.g. Disbursed via Bank IMPS ref #8912") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSettleConfirmDialog = false
                        viewModel.settleAuctionResult(
                            cycleNumber = cycle.cycleNumber,
                            paymentMethod = settlementPaymentMethod,
                            settlementNotes = settlementNotesInput.trim(),
                            onSuccess = {
                                Toast.makeText(context, "Settlement committed to Group Ledger!", Toast.LENGTH_LONG).show()
                            },
                            onError = { err ->
                                Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Emerald500),
                    modifier = Modifier.testTag("confirm_settle_auction_btn")
                ) {
                    Text("Confirm & Post to Ledger", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSettleConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Dialog: Reject Result with Reason
    if (showRejectDialog) {
        AlertDialog(
            onDismissRequest = { showRejectDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Cancel,
                    contentDescription = null,
                    tint = Rose500,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "Reject Auction Result",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Specify an audit reason for rejecting this auction result. Bids and auction history will be preserved.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = rejectionReasonInput,
                        onValueChange = { rejectionReasonInput = it },
                        label = { Text("Rejection Reason *") },
                        placeholder = { Text("e.g. Calculation needs review / Ineligible bidder") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reject_reason_input"),
                        singleLine = false,
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (rejectionReasonInput.isBlank()) {
                            Toast.makeText(context, "Please enter a rejection reason", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        showRejectDialog = false
                        viewModel.rejectAuctionResult(
                            cycleNumber = cycle.cycleNumber,
                            rejectionReason = rejectionReasonInput.trim(),
                            onSuccess = {
                                Toast.makeText(context, "Auction result rejected", Toast.LENGTH_SHORT).show()
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                    modifier = Modifier.testTag("confirm_reject_btn")
                ) {
                    Text("Reject Result", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRejectDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Dialog: Resolve Auction Tie
    if (showTieResolveDialog) {
        AlertDialog(
            onDismissRequest = { showTieResolveDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Gavel,
                    contentDescription = null,
                    tint = Amber500,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "Resolve Auction Tie",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "A tie was detected with identical highest discount bids. Select the member to award the prize pool to under admin discretion:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    auctionResult.tiedMemberIds.forEachIndexed { index, memberId ->
                        val memberName = auctionResult.tiedMemberNames.getOrNull(index) ?: "Member #$memberId"
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(
                                selected = selectedTieMemberId == memberId,
                                onClick = { selectedTieMemberId = memberId }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = memberName,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    OutlinedTextField(
                        value = tieNotesInput,
                        onValueChange = { tieNotesInput = it },
                        label = { Text("Resolution Reason / Notes") },
                        placeholder = { Text("e.g. Agreement by members / Lottery draw") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("tie_resolution_notes_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val chosenId = selectedTieMemberId
                        if (chosenId == null) {
                            Toast.makeText(context, "Select a member", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        showTieResolveDialog = false
                        viewModel.resolveAuctionTie(
                            cycleNumber = cycle.cycleNumber,
                            selectedMemberId = chosenId,
                            adminNotes = tieNotesInput.trim().ifBlank { "Tie resolved by Admin discretion" },
                            onSuccess = {
                                Toast.makeText(context, "Tie resolved successfully", Toast.LENGTH_SHORT).show()
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                    modifier = Modifier.testTag("confirm_resolve_tie_btn")
                ) {
                    Text("Resolve & Set Winner", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showTieResolveDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Dialog: Confirm Result Approval
    if (showApproveConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showApproveConfirmDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Emerald500,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "Approve Auction Result?",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "You are approving the official winner and settlement preview for Round #${cycle.cycleNumber}:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "Winner: ${auctionResult.winningMemberName ?: "Declared Winner"}",
                                fontWeight = FontWeight.Bold,
                                color = IndigoPrimary,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Winning Discount: $curr${CurrencyFormatter.formatIndian(auctionResult.winningBidAmount ?: 0.0)}",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Net Prize Payout: $curr${CurrencyFormatter.formatIndian(auctionResult.estimatedOutcome?.prizePayoutAmount ?: 0.0)}",
                                fontSize = 13.sp,
                                color = Emerald500,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    Text(
                        text = "Note: Approving records the audit verification. Member balances, cash accounts, and ledger records will NOT be modified in this phase.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = adminApprovalNotes,
                        onValueChange = { adminApprovalNotes = it },
                        label = { Text("Approval Audit Notes (Optional)") },
                        placeholder = { Text("e.g. Verified valid bids and member eligibility") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showApproveConfirmDialog = false
                        viewModel.approveAuctionResult(
                            cycleNumber = cycle.cycleNumber,
                            adminNotes = adminApprovalNotes.trim().takeIf { it.isNotBlank() },
                            onSuccess = {
                                Toast.makeText(context, "Result approved successfully", Toast.LENGTH_SHORT).show()
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Emerald500),
                    modifier = Modifier.testTag("confirm_approve_result_btn")
                ) {
                    Text("Confirm Approval", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showApproveConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

/**
 * Prominent Settlement Status & Safeguard Notice Banner.
 * Shows distinct states for:
 * 1. SETTLED: Green committed badge with transaction ledger references and link to Group Ledger.
 * 2. SETTLEMENT_PROCESSING: Blue animated loading state.
 * 3. PREVIEW / PENDING: Amber preview notice explaining balances are not altered before admin settlement.
 */
@Composable
private fun SettlementStatusNoticeCard(
    result: ChitAuctionResult,
    cycle: ChitCycle,
    curr: String,
    onNavigateToLedger: () -> Unit
) {
    val isSettled = result.resultStatus == ChitAuctionResultStatus.SETTLED ||
            cycle.status == ChitCycleStatus.SETTLED

    val isProcessing = result.resultStatus == ChitAuctionResultStatus.SETTLEMENT_PROCESSING ||
            cycle.status == ChitCycleStatus.SETTLEMENT_PROCESSING

    if (isSettled) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Emerald500.copy(alpha = 0.10f),
            border = BorderStroke(1.dp, Emerald500.copy(alpha = 0.45f)),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("settled_success_banner")
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Emerald500,
                        modifier = Modifier.size(24.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "FINANCIAL SETTLEMENT COMPLETED",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Emerald500
                            )
                            Surface(
                                color = Emerald500,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "SETTLED",
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text(
                            text = "All accounting entries (Prize Payout & Commission) committed to the Group Ledger.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 16.sp
                        )
                    }
                }

                HorizontalDivider(color = Emerald500.copy(alpha = 0.2f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Payout Txn Ref", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = result.settlementPayoutTxnId ?: "CHIT-PAYOUT-C${cycle.cycleNumber}",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.5.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Emerald500
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Commission Ref", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = result.settlementCommissionTxnId ?: "CHIT-COMMISSION-C${cycle.cycleNumber}",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.5.sp,
                            fontFamily = FontFamily.Monospace,
                            color = IndigoPrimary
                        )
                    }
                }

                Button(
                    onClick = onNavigateToLedger,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Emerald500),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("view_in_group_ledger_btn")
                ) {
                    Text("View in Group Ledger", fontWeight = FontWeight.Bold)
                }
            }
        }
    } else if (isProcessing) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = IndigoPrimary.copy(alpha = 0.10f),
            border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.35f)),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("settlement_processing_banner")
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = IndigoPrimary,
                    strokeWidth = 2.dp
                )
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = "COMMITTING TO GROUP LEDGER...",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = IndigoPrimary
                    )
                    Text(
                        text = "Posting Prize Payout, Foreman Commission, and updating member contribution balances.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    } else {
        // Preview Safeguard
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Amber500.copy(alpha = 0.10f),
            border = BorderStroke(1.dp, Amber500.copy(alpha = 0.35f)),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("settlement_preview_banner")
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = Amber500,
                    modifier = Modifier
                        .size(24.dp)
                        .padding(top = 2.dp)
                )
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "SETTLEMENT PREVIEW ONLY",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Amber500
                        )
                        Surface(
                            color = Amber500,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "NOT SETTLED",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                    Text(
                        text = "Settlement not completed. All calculations shown are preview figures for administrative review. Actual member dues, cash accounts, and ledger records remain untouched until Group Admin settlement.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}

/**
 * Member privacy view displayed before Group Admin approves the result.
 */
@Composable
private fun MemberResultPendingCard(
    cycleNumber: Int,
    status: ChitAuctionResultStatus
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("member_result_pending_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(IndigoPrimary.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = IndigoPrimary,
                    modifier = Modifier.size(28.dp)
                )
            }

            Text(
                text = "Result is Being Processed",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )

            Text(
                text = "The bidding floor for Round #$cycleNumber has concluded. The Group Admin is currently validating bid eligibility and calculating official results. The winner announcement will be published here once approved.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                lineHeight = 19.sp
            )

            Surface(
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "Status: ${status.displayName}",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp,
                    color = IndigoPrimary,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }
    }
}

/**
 * Section 14: AUCTION Overview (Cycle #, Date, Status).
 */
@Composable
private fun AuctionOverviewCard(
    cycle: ChitCycle,
    result: ChitAuctionResult
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("auction_overview_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Gavel,
                        contentDescription = null,
                        tint = IndigoPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "AUCTION OVERVIEW",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    color = when (result.resultStatus) {
                        ChitAuctionResultStatus.RESULT_APPROVED -> Emerald500.copy(alpha = 0.15f)
                        ChitAuctionResultStatus.TIE_REQUIRES_ADMIN_REVIEW -> Amber500.copy(alpha = 0.15f)
                        ChitAuctionResultStatus.RESULT_REJECTED -> Rose500.copy(alpha = 0.15f)
                        ChitAuctionResultStatus.SETTLEMENT_PENDING -> IndigoPrimary.copy(alpha = 0.15f)
                        else -> MaterialTheme.colorScheme.surfaceContainerHigh
                    },
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = result.resultStatus.displayName,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (result.resultStatus) {
                            ChitAuctionResultStatus.RESULT_APPROVED -> Emerald500
                            ChitAuctionResultStatus.TIE_REQUIRES_ADMIN_REVIEW -> Amber500
                            ChitAuctionResultStatus.RESULT_REJECTED -> Rose500
                            ChitAuctionResultStatus.SETTLEMENT_PENDING -> IndigoPrimary
                            else -> MaterialTheme.colorScheme.onSurface
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Round Cycle", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("#${cycle.cycleNumber}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Auction Date", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(cycle.scheduledDate, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Valid Bids Evaluated", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${result.validBidsCount} of ${result.totalBidsCount}", fontWeight = FontWeight.SemiBold, fontSize = 13.5.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Bidding Rule", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(result.ruleUsed, fontWeight = FontWeight.SemiBold, fontSize = 13.5.sp, color = IndigoPrimary)
                }
            }
        }
    }
}

/**
 * Section 6: Tie Warning Card.
 */
@Composable
private fun TieDetectedAlertCard(
    result: ChitAuctionResult,
    isGroupAdmin: Boolean,
    onResolveTieClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Amber500.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, Amber500.copy(alpha = 0.45f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("tie_detected_alert_card")
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = Amber500, modifier = Modifier.size(20.dp))
                Text(
                    text = "Tie Detected. Admin Review is Required.",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Amber500
                )
            }

            Text(
                text = "Multiple valid bids submitted the identical highest discount. Automatic winner determination cannot proceed without explicit administrative decision.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                lineHeight = 16.sp
            )

            Text(
                text = "Tied Members: ${result.tiedMemberNames.joinToString(", ")}",
                fontWeight = FontWeight.SemiBold,
                fontSize = 12.5.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            if (isGroupAdmin) {
                Button(
                    onClick = onResolveTieClick,
                    colors = ButtonDefaults.buttonColors(containerColor = Amber500),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("resolve_tie_btn")
                ) {
                    Icon(imageVector = Icons.Default.Gavel, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Resolve Tie & Choose Winner", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Rule Missing Warning Card.
 */
@Composable
private fun RuleMissingCard(result: ChitAuctionResult) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Rose500.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, Rose500.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(imageVector = Icons.Default.ErrorOutline, contentDescription = null, tint = Rose500)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Configuration Rule Required", fontWeight = FontWeight.Bold, color = Rose500, fontSize = 13.sp)
                Text(
                    text = result.ruleMissingReason ?: "Bidding rule is missing or unrecognized. Configure the rule in Group Settings.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

/**
 * Section 14: WINNING BID Summary.
 */
@Composable
private fun WinningBidSummaryCard(
    curr: String,
    result: ChitAuctionResult,
    cycle: ChitCycle
) {
    val winningBid = cycle.bids.find { it.bidId == result.winningBidId }
        ?: cycle.bids.find { it.memberId == result.winningMemberId && it.status == com.adr.groupledger.data.model.ChitBidStatus.VALID }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("winning_bid_summary_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.EmojiEvents, contentDescription = null, tint = Amber500, modifier = Modifier.size(20.dp))
                    Text("WINNING BID DETAILS", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                if (result.winningMemberId != null) {
                    Surface(color = Emerald500.copy(alpha = 0.12f), shape = RoundedCornerShape(4.dp)) {
                        Text("WINNER DETERMINED", color = Emerald500, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            if (result.winningMemberId != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(IndigoPrimary.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(24.dp))
                    }
                    Column {
                        Text(
                            text = result.winningMemberName ?: "Member #${result.winningMemberId}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Member ID: ${result.winningMemberId}",
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Winning Bid / Discount", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = "$curr${CurrencyFormatter.formatIndian(result.winningBidAmount ?: 0.0)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = IndigoPrimary
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Submission Time", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        val timeStr = winningBid?.let {
                            try {
                                SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(it.submittedAtMillis))
                            } catch (e: Exception) { "Recorded" }
                        } ?: "Recorded"
                        Text(timeStr, fontWeight = FontWeight.SemiBold, fontSize = 13.5.sp, color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            } else {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (result.isTie) "Tie detected. Please resolve tie to finalize winning member." else "No winning bid determined yet.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }
    }
}

/**
 * Section 10 & 11: FINANCIAL CALCULATION & TRANSPARENCY PREVIEW.
 * Displays:
 * Total Chit Value - Winning Discount = Calculated Winner Prize
 * Foreman Commission (5%)
 * Surplus Dividend Pool
 * Dividend Per Member
 * Net Next Round Installment Due
 */
@Composable
private fun FinancialCalculationPreviewCard(
    curr: String,
    result: ChitAuctionResult,
    cycle: ChitCycle,
    totalMembers: Int
) {
    val outcome = result.estimatedOutcome ?: ChitCalculationEngine.calculateEstimatedPrizeAndDividend(
        totalPot = totalMembers * cycle.installmentAmount,
        highestDiscountBid = result.winningBidAmount ?: 0.0,
        totalMembers = totalMembers,
        foremanCommissionPercent = 5.0,
        monthlyInstallment = cycle.installmentAmount
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("financial_calculation_preview_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.Calculate, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(20.dp))
                    Text("FINANCIAL CALCULATION PREVIEW", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Text(
                    text = "Rule: Reverse Discount",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            // Transparent Formula Walkthrough (Section 11)
            Surface(
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Calculation Formula Transparency:",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total Chit / Scheme Value", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                        Text("$curr${CurrencyFormatter.formatIndian(outcome.totalPot)}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("− Winning Bid / Discount", fontSize = 13.sp, color = Rose500)
                        Text("− $curr${CurrencyFormatter.formatIndian(outcome.winningDiscountBid)}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Rose500)
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("= Calculated Winner Prize Amount", fontSize = 13.5.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                        Text("$curr${CurrencyFormatter.formatIndian(outcome.prizePayoutAmount)}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Emerald500)
                    }
                }
            }

            // Other Configured Benefits & Commission Breakdown
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Foreman Commission (5%)", fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text("$curr${CurrencyFormatter.formatIndian(outcome.foremanCommission)}", fontSize = 12.5.sp, fontWeight = FontWeight.Medium)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Surplus Dividend Pool", fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("$curr${CurrencyFormatter.formatIndian(outcome.surplusDividendPool)}", fontSize = 12.5.sp, fontWeight = FontWeight.Medium)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Dividend Per Member ($totalMembers members)", fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("$curr${CurrencyFormatter.formatIndian(outcome.dividendPerMember)}", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Net Next Round Installment Due", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                    Text("$curr${CurrencyFormatter.formatIndian(outcome.netNextInstallment)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                }
            }
        }
    }
}

/**
 * Section 14: RESULT Audit Details (Winner, Result Status, Reviewed By/At).
 */
@Composable
private fun ResultAuditDetailsCard(
    result: ChitAuctionResult,
    cycle: ChitCycle
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("result_audit_details_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("RESULT & AUDIT TRAIL", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Result Status", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(result.resultStatus.displayName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }

            if (result.reviewedByMemberName != null) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Reviewed By", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(result.reviewedByMemberName, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                }
            }

            if (result.reviewedAtMillis != null) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Reviewed At", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val dateStr = try {
                        SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(result.reviewedAtMillis))
                    } catch (e: Exception) { "Recorded" }
                    Text(dateStr, fontSize = 12.sp)
                }
            }

            if (!result.rejectionReason.isNullOrBlank()) {
                Surface(
                    color = Rose500.copy(alpha = 0.10f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Rejection Reason: ${result.rejectionReason}",
                        color = Rose500,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            if (!result.adminReviewNotes.isNullOrBlank()) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Admin Review Notes: ${result.adminReviewNotes}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}

/**
 * Section 14, 15, 16: ADMIN ACTIONS CARD
 * Buttons:
 * [Approve Result]
 * [Reject / Review]
 * [Advance to Settlement Pending] (when already approved)
 */
@Composable
private fun AdminResultActionsCard(
    result: ChitAuctionResult,
    cycle: ChitCycle,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onMarkSettlementPending: () -> Unit,
    onSettle: () -> Unit,
    onNavigateToLedger: () -> Unit
) {
    val isSettled = result.resultStatus == ChitAuctionResultStatus.SETTLED ||
            cycle.status == ChitCycleStatus.SETTLED

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_result_actions_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                text = "ADMINISTRATIVE ACTIONS",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            if (isSettled) {
                Surface(
                    color = Emerald500.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Emerald500, modifier = Modifier.size(18.dp))
                            Text(
                                text = "Settlement Finalized & Committed",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Emerald500
                            )
                        }
                        Text(
                            text = "This round has been settled. Prize Payout and Foreman Commission records have been committed to the Group Ledger.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedButton(
                            onClick = onNavigateToLedger,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("actions_view_ledger_btn")
                        ) {
                            Text("Open Group Ledger Screen")
                        }
                    }
                }
            } else {
                when (result.resultStatus) {
                    ChitAuctionResultStatus.RESULT_CALCULATED,
                    ChitAuctionResultStatus.RESULT_PENDING -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = onReject,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Rose500),
                                border = BorderStroke(1.dp, Rose500),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("admin_reject_result_btn")
                            ) {
                                Icon(imageVector = Icons.Default.Cancel, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Reject", fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = onApprove,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Emerald500),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("admin_approve_result_btn")
                            ) {
                                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Approve", fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    ChitAuctionResultStatus.TIE_REQUIRES_ADMIN_REVIEW -> {
                        Text(
                            text = "Resolve the tie above to enable Result Approval.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Amber500
                        )
                    }

                    ChitAuctionResultStatus.RESULT_APPROVED,
                    ChitAuctionResultStatus.SETTLEMENT_PENDING -> {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Surface(
                                color = Emerald500.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Emerald500, modifier = Modifier.size(18.dp))
                                    Text(
                                        text = "Result Approved & Verified. Ready for Settlement.",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 12.5.sp,
                                        color = Emerald500
                                    )
                                }
                            }

                            Button(
                                onClick = onSettle,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Emerald500),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("settle_auction_btn")
                            ) {
                                Icon(imageVector = Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Settle Auction & Post to Ledger", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }
                    }

                    ChitAuctionResultStatus.SETTLEMENT_PROCESSING -> {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Settling and posting transactions...", fontWeight = FontWeight.Medium, fontSize = 13.sp)
                        }
                    }

                    ChitAuctionResultStatus.SETTLEMENT_FAILED -> {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Surface(
                                color = Rose500.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "Settlement Failed: Please retry posting to ledger.",
                                    color = Rose500,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                            Button(
                                onClick = onSettle,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Retry Settlement", fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    ChitAuctionResultStatus.RESULT_REJECTED -> {
                        OutlinedButton(
                            onClick = onApprove,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_reapprove_btn")
                        ) {
                            Text("Re-evaluate and Approve Result")
                        }
                    }

                    else -> {}
                }
            }
        }
    }
}
