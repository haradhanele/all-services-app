package com.adr.groupledger.service.notification

import android.content.Context
import com.adr.groupledger.data.model.ChitCycleReportItem
import com.adr.groupledger.data.model.ChitFundReportOverview
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.NotificationItem
import com.adr.groupledger.ui.screens.demo.GroupCategory
import com.adr.groupledger.ui.home.HomeTemplateResolver
import java.util.Calendar

data class GeneratedNotificationEvent(
    val title: String,
    val message: String,
    val type: String, // "CONTRIBUTION_REMINDER", "AUCTION_REMINDER", "AUCTION_OPENED", "AUCTION_CLOSING", "RESULT_PUBLISHED", "SETTLEMENT_COMPLETED", etc.
    val relatedId: Long? = null,
    val actionRoute: String? = null,
    val channelKey: String = "AUCTION_CHANNEL"
)

interface NotificationRuleProvider {
    fun evaluateEvents(
        context: Context,
        settings: GroupSettings,
        currentMember: Member?,
        cycleReports: List<ChitCycleReportItem>,
        overview: ChitFundReportOverview
    ): List<GeneratedNotificationEvent>
}

class ChitFundNotificationRules : NotificationRuleProvider {
    override fun evaluateEvents(
        context: Context,
        settings: GroupSettings,
        currentMember: Member?,
        cycleReports: List<ChitCycleReportItem>,
        overview: ChitFundReportOverview
    ): List<GeneratedNotificationEvent> {
        val events = mutableListOf<GeneratedNotificationEvent>()
        val currentMillis = System.currentTimeMillis()

        // 1. Current Live / Active Cycle events
        val currentCycle = cycleReports.find { it.cycleNumber == overview.currentCycleNumber } ?: cycleReports.firstOrNull()
        if (currentCycle != null) {
            val cycleNum = currentCycle.cycleNumber

            // Auction Approaching (Scheduled date within 24 hours)
            if (currentCycle.scheduledDateMillis > 0) {
                val diffHours = (currentCycle.scheduledDateMillis - currentMillis) / (1000 * 60 * 60)
                if (diffHours in 1..24) {
                    events.add(
                        GeneratedNotificationEvent(
                            title = "Cycle #$cycleNum Auction Tomorrow",
                            message = "Chit Fund auction for Round #$cycleNum is scheduled for tomorrow. Prepare your bids!",
                            type = "AUCTION_REMINDER",
                            relatedId = cycleNum.toLong(),
                            actionRoute = "auction_details/$cycleNum",
                            channelKey = "AUCTION_CHANNEL"
                        )
                    )
                }
            }

            // Auction Opened
            if (currentCycle.cycleStatus.name == "AUCTION_OPEN") {
                events.add(
                    GeneratedNotificationEvent(
                        title = "Cycle #$cycleNum Auction Now Open",
                        message = "Bidding is officially open for Round #$cycleNum. Submit your discount bids now.",
                        type = "AUCTION_OPENED",
                        relatedId = cycleNum.toLong(),
                        actionRoute = "auction_details/$cycleNum",
                        channelKey = "AUCTION_CHANNEL"
                    )
                )
            }

            // Result Published / Approved
            if (currentCycle.cycleStatus.name in listOf("RESULT_APPROVED", "SETTLED", "COMPLETED") && !currentCycle.winnerMemberName.isNullOrBlank()) {
                events.add(
                    GeneratedNotificationEvent(
                        title = "Cycle #$cycleNum Result Published",
                        message = "Winner determined for Round #$cycleNum (${currentCycle.winnerMemberName}). Tap to review outcome.",
                        type = "RESULT_PUBLISHED",
                        relatedId = cycleNum.toLong(),
                        actionRoute = "auction_result_review/$cycleNum",
                        channelKey = "AUCTION_CHANNEL"
                    )
                )
            }

            // Settlement Completed
            if (currentCycle.cycleStatus.name == "SETTLED") {
                events.add(
                    GeneratedNotificationEvent(
                        title = "Cycle #$cycleNum Settlement Completed",
                        message = "Prize payout and foreman commission have been successfully reconciled with Group Ledger.",
                        type = "SETTLEMENT_COMPLETED",
                        relatedId = cycleNum.toLong(),
                        actionRoute = "reports",
                        channelKey = "PAYMENT_CHANNEL"
                    )
                )
            }
        }

        // 2. Contribution / Payment Due for Current Member
        if (currentMember != null) {
            val cal = Calendar.getInstance()
            val dayOfMonth = cal.get(Calendar.DAY_OF_MONTH)
            val dueDay = settings.dueDayOfMonth

            if (dayOfMonth in (dueDay - 2)..dueDay) {
                events.add(
                    GeneratedNotificationEvent(
                        title = "Contribution Due Reminder",
                        message = "Your contribution installment for Round #${overview.currentCycleNumber} is due on or before the ${dueDay}th.",
                        type = "CONTRIBUTION_REMINDER",
                        relatedId = overview.currentCycleNumber.toLong(),
                        actionRoute = "my_contribution",
                        channelKey = "PAYMENT_CHANNEL"
                    )
                )
            } else if (dayOfMonth > dueDay + settings.gracePeriodDays) {
                events.add(
                    GeneratedNotificationEvent(
                        title = "Contribution Overdue Notice",
                        message = "Your contribution for Round #${overview.currentCycleNumber} is overdue. Kindly clear dues to maintain good standing.",
                        type = "CONTRIBUTION_OVERDUE",
                        relatedId = overview.currentCycleNumber.toLong(),
                        actionRoute = "my_contribution",
                        channelKey = "IMPORTANT_ALERTS_CHANNEL"
                    )
                )
            }
        }

        return events
    }
}

class CommunityFundNotificationRules : NotificationRuleProvider {
    override fun evaluateEvents(
        context: Context,
        settings: GroupSettings,
        currentMember: Member?,
        cycleReports: List<ChitCycleReportItem>,
        overview: ChitFundReportOverview
    ): List<GeneratedNotificationEvent> {
        val events = mutableListOf<GeneratedNotificationEvent>()
        val cal = Calendar.getInstance()
        val dayOfMonth = cal.get(Calendar.DAY_OF_MONTH)

        if (currentMember != null && dayOfMonth in (settings.dueDayOfMonth - 2)..settings.dueDayOfMonth) {
            events.add(
                GeneratedNotificationEvent(
                    title = "Monthly Dues Reminder",
                    message = "Friendly reminder: Monthly contribution for ${settings.groupName} is due by ${settings.dueDayOfMonth}th.",
                    type = "CONTRIBUTION_REMINDER",
                    relatedId = 0L,
                    actionRoute = "my_contribution",
                    channelKey = "PAYMENT_CHANNEL"
                )
            )
        }
        return events
    }
}

object NotificationEngineRegistry {
    fun getProvider(category: GroupCategory, subCategory: String): NotificationRuleProvider {
        return if (category == GroupCategory.SAVINGS_CREDIT_CHIT || subCategory.contains("Chit", ignoreCase = true)) {
            ChitFundNotificationRules()
        } else {
            CommunityFundNotificationRules()
        }
    }
}
