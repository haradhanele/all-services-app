package com.adr.groupledger.service.notification

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.adr.groupledger.MainActivity
import com.adr.groupledger.R
import com.adr.groupledger.data.model.NotificationItem
import com.adr.groupledger.data.repository.SocietyRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object NotificationDispatcher {

    const val CHANNEL_GROUP_UPDATES = "group_updates_channel"
    const val CHANNEL_PAYMENT = "payment_channel"
    const val CHANNEL_AUCTION = "auction_channel"
    const val CHANNEL_IMPORTANT = "important_alerts_channel"

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val groupChannel = NotificationChannel(
                CHANNEL_GROUP_UPDATES,
                "Group Updates",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "General announcements, notices, and group activity updates"
            }

            val paymentChannel = NotificationChannel(
                CHANNEL_PAYMENT,
                "Payments & Contributions",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Contribution dues, payment confirmations, and reminders"
            }

            val auctionChannel = NotificationChannel(
                CHANNEL_AUCTION,
                "Auction & Chit Fund",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Auction opening, approaching schedules, and result publications"
            }

            val importantChannel = NotificationChannel(
                CHANNEL_IMPORTANT,
                "Important Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Overdue notices, reconciliation warnings, and critical alerts"
            }

            notificationManager.createNotificationChannels(
                listOf(groupChannel, paymentChannel, auctionChannel, importantChannel)
            )
        }
    }

    fun dispatchAndSave(
        context: Context,
        repository: SocietyRepository,
        groupId: Long,
        event: GeneratedNotificationEvent,
        scope: CoroutineScope = CoroutineScope(Dispatchers.IO)
    ) {
        scope.launch {
            // 1. Save to Room database so it appears in in-app Notifications / Inbox
            val notificationItem = NotificationItem(
                groupId = groupId,
                title = event.title,
                message = event.message,
                type = event.type,
                timestamp = System.currentTimeMillis(),
                isRead = false,
                relatedId = event.relatedId,
                actionRoute = event.actionRoute
            )
            repository.insertNotification(notificationItem)

            // 2. Dispatch Android System Push Notification if permission granted
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            ) {
                showSystemNotification(context, event)
            }
        }
    }

    private fun showSystemNotification(context: Context, event: GeneratedNotificationEvent) {
        val channelId = when (event.channelKey) {
            "PAYMENT_CHANNEL" -> CHANNEL_PAYMENT
            "AUCTION_CHANNEL" -> CHANNEL_AUCTION
            "IMPORTANT_ALERTS_CHANNEL" -> CHANNEL_IMPORTANT
            else -> CHANNEL_GROUP_UPDATES
        }

        // Intent to open MainActivity with route
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("route", event.actionRoute)
        }

        val pendingIntentFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            event.hashCode(),
            intent,
            pendingIntentFlag
        )

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(event.title)
            .setContentText(event.message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(event.message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        val notificationId = event.hashCode()
        try {
            NotificationManagerCompat.from(context).notify(notificationId, builder.build())
        } catch (e: SecurityException) {
            // Permission not granted or revoked
        }
    }
}
