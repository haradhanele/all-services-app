package com.adr.groupledger.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NotificationImportant
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.ChitCycleCollectionSummary
import com.adr.groupledger.data.model.ChitMemberPaymentStatus
import com.adr.groupledger.ui.components.MemberAvatarView
import com.adr.groupledger.ui.components.StatusBadge
import com.adr.groupledger.ui.theme.EmeraldPrimary
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.StatusPaidText
import com.adr.groupledger.ui.theme.StatusPartialText
import com.adr.groupledger.ui.theme.StatusUnpaidText
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.utils.CurrencyFormatter
import com.adr.groupledger.utils.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChitCollectionTrackerScreen(
    viewModel: SocietyViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToMemberProfile: (Long) -> Unit,
    initialCycleNumber: Int? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val summaries by viewModel.chitCycleCollectionSummaries.collectAsStateWithLifecycle()
    val currentSummary by viewModel.currentCycleCollectionSummary.collectAsStateWithLifecycle()
    val memberStatuses by viewModel.currentCycleMemberPaymentStatuses.collectAsStateWithLifecycle()
    val selectedCycleNo by viewModel.selectedCollectionCycleNumber.collectAsStateWithLifecycle()
    val currency = settings.currencySymbol.ifBlank { "₹" }

    LaunchedEffect(initialCycleNumber) {
        if (initialCycleNumber != null && initialCycleNumber > 0) {
            viewModel.setSelectedCollectionCycleNumber(initialCycleNumber)
        }
    }

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, PAID, PARTIAL, PENDING, OVERDUE

    // Payment Recording Dialog States
    var recordingMemberStatus by remember { mutableStateOf<ChitMemberPaymentStatus?>(null) }
    var recordingAmountInput by remember { mutableStateOf("") }
    var selectedMethod by remember { mutableStateOf("Cash") }
    var txnRefInput by remember { mutableStateOf("") }
    var notesInput by remember { mutableStateOf("") }
    var showConfirmDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Chit Collection Tracker",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${settings.groupName} • Round #${currentSummary?.cycleNumber ?: 1}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.exportChitFundReportPdf(context) }) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = "Export PDF")
                    }
                    IconButton(onClick = { viewModel.exportChitFundReportCsv(context) }) {
                        Icon(Icons.Default.TableChart, contentDescription = "Export CSV")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .testTag("chit_collection_tracker_screen"),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 10.dp, bottom = 32.dp)
        ) {
            // 1. Cycle Selector Tabs
            if (summaries.isNotEmpty()) {
                item {
                    val activeCycleNumber = currentSummary?.cycleNumber ?: 1
                    val selectedIndex = summaries.indexOfFirst { it.cycleNumber == activeCycleNumber }.coerceAtLeast(0)

                    ScrollableTabRow(
                        selectedTabIndex = selectedIndex,
                        edgePadding = 0.dp,
                        divider = {},
                        indicator = { tabPositions ->
                            if (selectedIndex < tabPositions.size) {
                                TabRowDefaults.SecondaryIndicator(
                                    Modifier.tabIndicatorOffset(tabPositions[selectedIndex]),
                                    color = MaterialTheme.colorScheme.primary,
                                    height = 3.dp
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        summaries.forEach { summary ->
                            val isSelected = summary.cycleNumber == activeCycleNumber
                            Tab(
                                selected = isSelected,
                                onClick = { viewModel.setSelectedCollectionCycleNumber(summary.cycleNumber) },
                                text = {
                                    Text(
                                        text = "Round #${summary.cycleNumber}",
                                        fontSize = 13.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                },
                                modifier = Modifier.testTag("cycle_collection_tab_${summary.cycleNumber}")
                            )
                        }
                    }
                }
            }

            // 2. Collection KPI Banner Card
            if (currentSummary != null) {
                val summary = currentSummary!!
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Round #${summary.cycleNumber} Collection",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Due: ${DateUtils.formatDisplayDate(summary.dueDateMillis)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (summary.isFullyCollected) EmeraldPrimary.copy(alpha = 0.15f) else IndigoPrimary.copy(alpha = 0.15f),
                                    border = BorderStroke(1.dp, if (summary.isFullyCollected) EmeraldPrimary else IndigoPrimary)
                                ) {
                                    Text(
                                        text = "${summary.collectionPercentage.toInt()}% Collected",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (summary.isFullyCollected) EmeraldPrimary else IndigoPrimary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Three-column KPI: Expected, Collected, Pending
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("Expected", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        CurrencyFormatter.format(summary.totalExpectedCollection, currency),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Collected", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        CurrencyFormatter.format(summary.totalCollectedAmount, currency),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = StatusPaidText
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Pending", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        CurrencyFormatter.format(summary.pendingCollectionAmount, currency),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (summary.pendingCollectionAmount > 0) StatusUnpaidText else StatusPaidText
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Progress Bar
                            LinearProgressIndicator(
                                progress = { (summary.collectionPercentage / 100f).coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = if (summary.isFullyCollected) EmeraldPrimary else MaterialTheme.colorScheme.primary,
                                trackColor = MaterialTheme.colorScheme.surfaceContainerHighest
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Member count pill breakdown
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "✓ ${summary.paidMembersCount} Paid",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = StatusPaidText
                                )
                                Text(
                                    text = "◐ ${summary.partialMembersCount} Partial",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = StatusPartialText
                                )
                                Text(
                                    text = "○ ${summary.pendingMembersCount} Pending",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (summary.overdueMembersCount > 0) {
                                    Text(
                                        text = "! ${summary.overdueMembersCount} Overdue",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = StatusUnpaidText
                                    )
                                }
                            }
                        }
                    }
                }

                // Reconciliation indicator
                item {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (summary.isReconciled) EmeraldPrimary.copy(alpha = 0.08f) else StatusUnpaidText.copy(alpha = 0.08f),
                        border = BorderStroke(1.dp, if (summary.isReconciled) EmeraldPrimary.copy(alpha = 0.3f) else StatusUnpaidText.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                if (summary.isReconciled) Icons.Default.VerifiedUser else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (summary.isReconciled) EmeraldPrimary else StatusUnpaidText,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = summary.reconciliationMessage,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (summary.isReconciled) EmeraldPrimary else StatusUnpaidText,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            // 3. Search & Filters Bar
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("collection_search_field"),
                        placeholder = { Text("Search by name, code...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotBlank()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Filter Chips Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("ALL" to "All", "PAID" to "Paid", "PARTIAL" to "Partial", "PENDING" to "Pending", "OVERDUE" to "Overdue").forEach { (filterKey, label) ->
                            val isSelected = selectedFilter == filterKey
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedFilter = filterKey },
                                label = { Text(label, fontSize = 12.sp) },
                                modifier = Modifier.testTag("filter_chip_$filterKey")
                            )
                        }
                    }
                }
            }

            // 4. Member Collection Rows
            val filteredMembers = memberStatuses.filter { status ->
                val matchesSearch = searchQuery.isBlank() ||
                        status.member.name.contains(searchQuery, ignoreCase = true) ||
                        status.member.memberCode.contains(searchQuery, ignoreCase = true)

                val matchesFilter = when (selectedFilter) {
                    "PAID" -> status.paymentStatus == "PAID"
                    "PARTIAL" -> status.paymentStatus == "PARTIAL"
                    "PENDING" -> status.paymentStatus == "PENDING"
                    "OVERDUE" -> status.paymentStatus == "OVERDUE" || status.isOverdue
                    else -> true
                }

                matchesSearch && matchesFilter
            }

            if (filteredMembers.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.People, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (searchQuery.isNotBlank() || selectedFilter != "ALL") "No members match the selected filter" else "No active members enrolled in this scheme",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(filteredMembers) { status ->
                    MemberCollectionCard(
                        status = status,
                        currency = currency,
                        onRecordPayment = {
                            recordingMemberStatus = status
                            recordingAmountInput = status.remainingDue.toInt().toString()
                            selectedMethod = "Cash"
                            txnRefInput = ""
                            notesInput = ""
                        },
                        onNavigateToProfile = { onNavigateToMemberProfile(status.member.id) }
                    )
                }
            }
        }
    }

    // 5. Payment Input Dialog for Admin Quick Record
    if (recordingMemberStatus != null) {
        val st = recordingMemberStatus!!
        AlertDialog(
            onDismissRequest = { recordingMemberStatus = null },
            title = {
                Text(
                    text = "Record Member Payment",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "${st.member.name} (${st.member.memberCode}) • Round #${st.cycleNumber}",
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )

                    OutlinedTextField(
                        value = recordingAmountInput,
                        onValueChange = { recordingAmountInput = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Paid Amount ($currency)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_record_amount_field"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    // Payment Method Dropdown
                    var methodExpanded by remember { mutableStateOf(false) }
                    val paymentMethods = listOf("Cash", "UPI", "Bank Transfer", "Cheque", "Online")

                    ExposedDropdownMenuBox(
                        expanded = methodExpanded,
                        onExpandedChange = { methodExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedMethod,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Payment Method") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = methodExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(),
                            shape = RoundedCornerShape(10.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = methodExpanded,
                            onDismissRequest = { methodExpanded = false }
                        ) {
                            paymentMethods.forEach { method ->
                                DropdownMenuItem(
                                    text = { Text(method) },
                                    onClick = {
                                        selectedMethod = method
                                        methodExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = txnRefInput,
                        onValueChange = { txnRefInput = it },
                        label = { Text("Reference / Receipt No. (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = notesInput,
                        onValueChange = { notesInput = it },
                        label = { Text("Notes (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amount = recordingAmountInput.toDoubleOrNull() ?: 0.0
                        if (amount > 0) {
                            showConfirmDialog = true
                        }
                    },
                    enabled = (recordingAmountInput.toDoubleOrNull() ?: 0.0) > 0.0
                ) {
                    Text("Review")
                }
            },
            dismissButton = {
                TextButton(onClick = { recordingMemberStatus = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // 6. Admin Payment Confirmation Dialog
    if (showConfirmDialog && recordingMemberStatus != null) {
        val st = recordingMemberStatus!!
        val amount = recordingAmountInput.toDoubleOrNull() ?: 0.0
        AlertDialog(
            onDismissRequest = { showConfirmDialog = false },
            title = {
                Text("Confirm Payment Record", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Are you sure you want to record this contribution in the group ledger?")
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("• Member: ${st.member.name}")
                    Text("• Scheme: Round #${st.cycleNumber}")
                    Text("• Payment: ${CurrencyFormatter.format(amount, currency)}")
                    Text("• Method: $selectedMethod")
                    if (txnRefInput.isNotBlank()) {
                        Text("• Ref: $txnRefInput")
                    }
                    Text("• Date: ${DateUtils.formatDisplayDate(System.currentTimeMillis())}")
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.recordPayment(
                            memberId = st.member.id,
                            month = st.month,
                            year = st.year,
                            expectedAmount = st.requiredAmount,
                            paidAmount = st.paidAmount + amount,
                            paymentDate = System.currentTimeMillis(),
                            paymentMethod = selectedMethod,
                            transactionRef = txnRefInput,
                            notes = notesInput,
                            onSuccess = {
                                showConfirmDialog = false
                                recordingMemberStatus = null
                                recordingAmountInput = ""
                            }
                        )
                    },
                    modifier = Modifier.testTag("confirm_admin_payment_btn")
                ) {
                    Text("Confirm & Post to Ledger")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmDialog = false }) {
                    Text("Back")
                }
            }
        )
    }
}

@Composable
private fun MemberCollectionCard(
    status: ChitMemberPaymentStatus,
    currency: String,
    onRecordPayment: () -> Unit,
    onNavigateToProfile: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onNavigateToProfile() }
            .testTag("member_collection_card_${status.member.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    MemberAvatarView(
                        name = status.member.name,
                        size = 38.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = status.member.name,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Code: ${status.member.memberCode} • ${status.member.phone.ifBlank { "No Phone" }}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                StatusBadge(status = status.paymentStatus, compact = true)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Required", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        CurrencyFormatter.format(status.requiredAmount, currency),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Paid", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        CurrencyFormatter.format(status.paidAmount, currency),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (status.paidAmount > 0) StatusPaidText else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("Remaining", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        CurrencyFormatter.format(status.remainingDue, currency),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (status.remainingDue > 0) StatusUnpaidText else StatusPaidText
                    )
                }
            }

            if (status.fineAmount > 0) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Late Fine: ${CurrencyFormatter.format(status.fineAmount, currency)} (${status.daysOverdue} days overdue)",
                    style = MaterialTheme.typography.labelSmall,
                    color = StatusUnpaidText,
                    fontWeight = FontWeight.Medium
                )
            }

            if (status.remainingDue > 0) {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onRecordPayment,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                    ),
                    contentPadding = PaddingValues(vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Record Payment (${CurrencyFormatter.format(status.remainingDue, currency)})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
