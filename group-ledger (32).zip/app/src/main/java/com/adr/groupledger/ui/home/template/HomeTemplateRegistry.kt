package com.adr.groupledger.ui.home.template

import android.util.Log
import com.adr.groupledger.ui.screens.demo.GroupCategory

/**
 * Registry and resolver for Home Page templates.
 *
 * Implements the mandatory 3-Tier Template Priority System:
 * LEVEL 1: Exact Sub-category Home Template
 *          (e.g., Chit Fund -> [ChitFundHomeTemplate])
 * LEVEL 2: Category Home Template
 *          (e.g., Puja / Festival -> [PujaFestivalHomeTemplate])
 * LEVEL 3: Generic Group Home Template
 *          (Fallback to [GenericGroupHomeTemplate])
 *
 * Allows adding/registering future sub-category templates (such as SelfHelpGroupHomeTemplate)
 * without rewriting or modifying HomeScreen code.
 */
object HomeTemplateRegistry {

    private const val TAG = "HomeTemplateRegistry"

    // Level 1: Sub-category map (key = normalized "categoryId:subCategoryName")
    private val subCategoryTemplates = mutableMapOf<String, GroupHomeTemplate>()

    // Level 2: Category map (key = normalized categoryId)
    private val categoryTemplates = mutableMapOf<String, GroupHomeTemplate>()

    // Level 3: Generic fallback
    var genericTemplate: GroupHomeTemplate = GenericGroupHomeTemplate

    init {
        registerDefaults()
    }

    private fun registerDefaults() {
        // --- LEVEL 1: Sub-Category Specialized Templates ---
        registerSubCategory(
            categoryId = GroupCategory.SAVINGS_CREDIT_CHIT.id,
            subCategory = "Chit Fund",
            template = ChitFundHomeTemplate
        )
        registerSubCategory(
            categoryId = GroupCategory.SAVINGS_CREDIT_CHIT.id,
            subCategory = "Chit Fund / BC",
            template = ChitFundHomeTemplate
        )
        registerSubCategory(
            categoryId = GroupCategory.SAVINGS_CREDIT_CHIT.id,
            subCategory = "Rotating Savings Group",
            template = ChitFundHomeTemplate
        )

        // --- LEVEL 2: Category-Level Templates ---
        registerCategory(GroupCategory.COMMUNITY_FUND.id, CommunityFundHomeTemplate)
        registerCategory(GroupCategory.PUJA_FESTIVAL.id, PujaFestivalHomeTemplate)
        registerCategory(GroupCategory.SPORTS_CULTURAL.id, SportsCulturalHomeTemplate)
        registerCategory(GroupCategory.SAVINGS_CREDIT_CHIT.id, SavingsCreditHomeTemplate)
        registerCategory(GroupCategory.EVENTS_TRIPS.id, EventsTripsHomeTemplate)
        registerCategory(GroupCategory.FAMILY_FRIENDS.id, FamilyFriendsHomeTemplate)
        registerCategory(GroupCategory.WELFARE_NGO.id, WelfareNgoHomeTemplate)
        registerCategory(GroupCategory.HOUSING_APARTMENT.id, HousingSocietyHomeTemplate)
        registerCategory(GroupCategory.BUSINESS_PARTNERSHIP.id, BusinessPartnershipHomeTemplate)
        registerCategory(GroupCategory.OTHER_GROUPS.id, OtherGroupHomeTemplate)
    }

    /**
     * Registers a specialized template for a specific sub-category.
     */
    fun registerSubCategory(categoryId: String, subCategory: String, template: GroupHomeTemplate) {
        val key = buildSubCategoryKey(categoryId, subCategory)
        subCategoryTemplates[key] = template
        Log.d(TAG, "Registered sub-category template '${template.templateId}' for key: $key")
    }

    /**
     * Registers a template for an entire category.
     */
    fun registerCategory(categoryId: String, template: GroupHomeTemplate) {
        val key = categoryId.trim().lowercase()
        categoryTemplates[key] = template
        Log.d(TAG, "Registered category template '${template.templateId}' for key: $key")
    }

    /**
     * Resolves the appropriate [GroupHomeTemplate] for a given category and sub-category.
     * Follows Level 1 -> Level 2 -> Level 3 fallback priority. Never returns null.
     */
    fun resolve(category: GroupCategory?, subCategory: String?): GroupHomeTemplate {
        if (category == null) {
            Log.d(TAG, "Category is null. Resolving to Level 3 Generic Template.")
            return genericTemplate
        }

        // LEVEL 1: Check Exact Sub-Category Template
        if (!subCategory.isNullOrBlank()) {
            val subKey = buildSubCategoryKey(category.id, subCategory)
            val subTemplate = subCategoryTemplates[subKey]
            if (subTemplate != null) {
                Log.d(TAG, "Resolved Level 1 SubCategory Template: ${subTemplate.displayName}")
                return subTemplate
            }

            // Also check partial / normalized matches for subcategories (e.g. "Chit Fund" inside "Chit Fund / BC")
            for ((key, tmpl) in subCategoryTemplates) {
                val prefix = "${category.id.lowercase()}:"
                if (key.startsWith(prefix)) {
                    val registeredSub = key.removePrefix(prefix)
                    if (subCategory.contains(registeredSub, ignoreCase = true) || registeredSub.contains(subCategory, ignoreCase = true)) {
                        Log.d(TAG, "Resolved Level 1 SubCategory Template via fuzzy match: ${tmpl.displayName}")
                        return tmpl
                    }
                }
            }
        }

        // LEVEL 2: Check Category Template
        val catKey = category.id.trim().lowercase()
        val catTemplate = categoryTemplates[catKey]
        if (catTemplate != null) {
            Log.d(TAG, "Resolved Level 2 Category Template: ${catTemplate.displayName}")
            return catTemplate
        }

        // LEVEL 3: Generic Group Template Fallback
        Log.d(TAG, "No category template found for '$catKey'. Resolving to Level 3 Generic Template.")
        return genericTemplate
    }

    private fun buildSubCategoryKey(categoryId: String, subCategory: String): String {
        return "${categoryId.trim().lowercase()}:${subCategory.trim().lowercase()}"
    }
}
