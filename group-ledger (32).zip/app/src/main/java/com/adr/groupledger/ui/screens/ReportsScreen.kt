package com.adr.groupledger.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationImportant
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.ChitAuctionResultStatus
import com.adr.groupledger.data.model.ChitCycleReportItem
import com.adr.groupledger.data.model.ChitCycleStatus
import com.adr.groupledger.data.model.ChitFundConfig
import com.adr.groupledger.data.model.ChitFundReportOverview
import com.adr.groupledger.data.model.ChitMemberFinancialSummary
import com.adr.groupledger.data.model.ChitReportTab
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.MemberWithMonthlyStatus
import com.adr.groupledger.ui.components.CollectionBarChart
import com.adr.groupledger.ui.components.MonthPickerBar
import com.adr.groupledger.ui.components.StatMetricCard
import com.adr.groupledger.ui.components.StatusBadge
import com.adr.groupledger.ui.home.HomeTemplateResolver
import com.adr.groupledger.ui.screens.demo.GroupCategory
import com.adr.groupledger.ui.theme.EmeraldPrimary
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.StatusPaidText
import com.adr.groupledger.ui.theme.StatusPartialText
import com.adr.groupledger.ui.theme.StatusUnpaidText
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.utils.CurrencyFormatter
import com.adr.groupledger.utils.DateUtils

@Composable
fun ReportsScreen(
    viewModel: SocietyViewModel,
    modifier: Modifier = Modifier,
    onNavigateToLedger: () -> Unit = {},
    onNavigateToAuction: (Int) -> Unit = {},
    onNavigateToAuctionReview: (Int) -> Unit = {},
    onNavigateToMember: (Long) -> Unit = {}
) {
    val context = LocalContext.current
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()

    val (category, subCategory) = remember(settings) {
        HomeTemplateResolver.resolve(settings)
    }

    val isChitFund = remember(category, subCategory, settings.modulesConfigJson) {
        category == GroupCategory.SAVINGS_CREDIT_CHIT &&
                (subCategory.contains("Chit", ignoreCase = true) ||
                        settings.modulesConfigJson.contains("chitConfig"))
    }

    if (isChitFund) {
        ChitFundReportView(
            viewModel = viewModel,
            settings = settings,
            context = context,
            modifier = modifier,
            onNavigateToLedger = onNavigateToLedger,
            onNavigateToAuction = onNavigateToAuction,
            onNavigateToAuctionReview = onNavigateToAuctionReview,
            onNavigateToMember = onNavigateToMember
        )
    } else {
        CommunityFundReportView(
            viewModel = viewModel,
            settings = settings,
            context = context,
            modifier = modifier
        )
    }
}

// =============================================================================
// 1. CHIT FUND CATEGORY-AWARE REPORT TEMPLATE (Phase B.6)
// =============================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChitFundReportView(
    viewModel: SocietyViewModel,
    settings: GroupSettings,
    context: Context,
    modifier: Modifier = Modifier,
    onNavigateToLedger: () -> Unit,
    onNavigateToAuction: (Int) -> Unit,
    onNavigateToAuctionReview: (Int) -> Unit,
    onNavigateToMember: (Long) -> Unit
) {
    val selectedTab by viewModel.selectedChitReportTab.collectAsStateWithLifecycle()
    val overview by viewModel.chitReportOverview.collectAsStateWithLifecycle()
    val cycleReports by viewModel.chitCycleReports.collectAsStateWithLifecycle()
    val memberSummaries by viewModel.chitMemberSummaries.collectAsStateWithLifecycle()
    val chitConfig by viewModel.chitFundConfig.collectAsStateWithLifecycle()
    val transactions by viewModel.allTransactions.collectAsStateWithLifecycle()

    var selectedCycleForDetails by remember { mutableStateOf<ChitCycleReportItem?>(null) }
    var memberSearchQuery by remember { mutableStateOf("") }
    val currency = settings.currencySymbol.ifBlank { "₹" }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("chit_fund_reports_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 32.dp)
    ) {
        // 1. Scheme Header & Export Action Bar
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    Icons.Default.Savings,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "Chit Fund Financial Report",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Text(
                                text = "${settings.groupName} • Round #${overview.currentCycleNumber} of ${overview.totalCycles}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Status Badge
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (overview.isAllReconciled) EmeraldPrimary.copy(alpha = 0.15f) else StatusPartialText.copy(alpha = 0.15f),
                            border = BorderStroke(1.dp, if (overview.isAllReconciled) EmeraldPrimary else StatusPartialText)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    if (overview.isAllReconciled) Icons.Default.VerifiedUser else Icons.Default.Info,
                                    contentDescription = null,
                                    tint = if (overview.isAllReconciled) EmeraldPrimary else StatusPartialText,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = if (overview.isAllReconciled) "Ledger Reconciled" else "Sync Pending",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (overview.isAllReconciled) EmeraldPrimary else StatusPartialText
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Export Buttons Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.exportChitFundReportPdf(context) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("export_chit_pdf_btn"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            ),
                            contentPadding = PaddingValues(vertical = 8.dp, horizontal = 12.dp)
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Export PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { viewModel.exportChitFundReportCsv(context) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("export_chit_csv_btn"),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(vertical = 8.dp, horizontal = 12.dp)
                        ) {
                            Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Export CSV", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = onNavigateToLedger,
                            modifier = Modifier.testTag("nav_to_ledger_btn"),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(vertical = 8.dp, horizontal = 12.dp)
                        ) {
                            Icon(Icons.Default.AccountBalance, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Ledger", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // 2. Category-Aware Chit Navigation Tabs
        item {
            ScrollableTabRow(
                selectedTabIndex = selectedTab.ordinal,
                edgePadding = 0.dp,
                divider = {},
                indicator = { tabPositions ->
                    if (selectedTab.ordinal < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab.ordinal]),
                            color = MaterialTheme.colorScheme.primary,
                            height = 3.dp
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                ChitReportTab.entries.forEach { tab ->
                    val isSelected = selectedTab == tab
                    Tab(
                        selected = isSelected,
                        onClick = { viewModel.setSelectedChitReportTab(tab) },
                        text = {
                            Text(
                                text = tab.title,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        modifier = Modifier.testTag("chit_tab_${tab.name}")
                    )
                }
            }
        }

        // 3. Tab Specific Renderers
        when (selectedTab) {
            ChitReportTab.OVERVIEW -> {
                // Progress Bar
                item {
                    SchemeProgressCard(overview = overview)
                }

                // Summary Cards Grid
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            StatMetricCard(
                                title = "Total Chit Value",
                                value = CurrencyFormatter.format(overview.totalChitValue, currency),
                                subtitle = "${overview.totalMembers} Members × ${overview.totalCycles} Rounds",
                                icon = Icons.Default.Savings,
                                accentColor = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(1f)
                            )
                            StatMetricCard(
                                title = "Settled Outflow",
                                value = CurrencyFormatter.format(overview.totalSettledPrizeAmount, currency),
                                subtitle = "${overview.completedCyclesCount} Rounds settled",
                                icon = Icons.Default.CheckCircle,
                                accentColor = StatusPaidText,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            StatMetricCard(
                                title = "Total Collections",
                                value = CurrencyFormatter.format(overview.totalContributionsCollected, currency),
                                subtitle = "Confirmed installments",
                                icon = Icons.Default.ReceiptLong,
                                accentColor = IndigoPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            StatMetricCard(
                                title = "Auction Discounts",
                                value = CurrencyFormatter.format(overview.totalAuctionDiscounts, currency),
                                subtitle = "Distributed as dividend",
                                icon = Icons.Default.Gavel,
                                accentColor = StatusPartialText,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            StatMetricCard(
                                title = "Foreman Commission",
                                value = CurrencyFormatter.format(overview.totalForemanCommission, currency),
                                subtitle = "Group management fee",
                                icon = Icons.Default.TrendingUp,
                                accentColor = EmeraldPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            StatMetricCard(
                                title = "Pending Settlement",
                                value = CurrencyFormatter.format(overview.pendingSettlementAmount, currency),
                                subtitle = "${overview.pendingSettlementCount} Round(s) awaiting sync",
                                icon = Icons.Default.NotificationImportant,
                                accentColor = if (overview.pendingSettlementCount > 0) StatusUnpaidText else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // Current Live Cycle Card
                val currentCycleItem = cycleReports.find { it.cycleNumber == overview.currentCycleNumber } ?: cycleReports.firstOrNull()
                if (currentCycleItem != null) {
                    item {
                        Text(
                            text = "Current Round Status",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    item {
                        CurrentCycleHighlightCard(
                            item = currentCycleItem,
                            currency = currency,
                            onInspect = { selectedCycleForDetails = currentCycleItem },
                            onReviewAuction = { onNavigateToAuctionReview(currentCycleItem.cycleNumber) }
                        )
                    }
                }
            }

            ChitReportTab.CYCLES -> {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Cycle & Round History (${cycleReports.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Tap a round for ledger trace",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                items(cycleReports) { cycleItem ->
                    CycleHistoryCard(
                        item = cycleItem,
                        currency = currency,
                        onClick = { selectedCycleForDetails = cycleItem }
                    )
                }
            }

            ChitReportTab.AUCTIONS -> {
                item {
                    Text(
                        text = "Auction History & Bidding Analytics",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                val completedOrLiveAuctions = cycleReports.filter {
                    it.bidsCount > 0 ||
                    it.cycleStatus in listOf(
                        ChitCycleStatus.AUCTION_OPEN,
                        ChitCycleStatus.AUCTION_CLOSED,
                        ChitCycleStatus.RESULT_PENDING,
                        ChitCycleStatus.RESULT_CALCULATED,
                        ChitCycleStatus.TIE_REQUIRES_ADMIN_REVIEW,
                        ChitCycleStatus.RESULT_APPROVED,
                        ChitCycleStatus.SETTLEMENT_PENDING,
                        ChitCycleStatus.SETTLEMENT_PROCESSING,
                        ChitCycleStatus.SETTLED,
                        ChitCycleStatus.COMPLETED
                    )
                }

                if (completedOrLiveAuctions.isEmpty()) {
                    item {
                        EmptyStateCard(
                            title = "No Auctions Conducted Yet",
                            subtitle = "Upcoming auctions will automatically appear here with full bid records and analytics."
                        )
                    }
                } else {
                    items(completedOrLiveAuctions) { item ->
                        AuctionPerformanceCard(
                            item = item,
                            currency = currency,
                            onReviewAuction = { onNavigateToAuctionReview(item.cycleNumber) }
                        )
                    }
                }
            }

            ChitReportTab.CONTRIBUTIONS -> {
                item {
                    Text(
                        text = "Member Contributions & Dues",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Member Search Box
                item {
                    OutlinedTextField(
                        value = memberSearchQuery,
                        onValueChange = { memberSearchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("member_report_search_input"),
                        placeholder = { Text("Search by name or code...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (memberSearchQuery.isNotBlank()) {
                                IconButton(onClick = { memberSearchQuery = "" }) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear")
                                }
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surface,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surface
                        )
                    )
                }

                val filteredMembers = memberSummaries.filter {
                    memberSearchQuery.isBlank() ||
                            it.member.name.contains(memberSearchQuery, ignoreCase = true) ||
                            it.member.memberCode.contains(memberSearchQuery, ignoreCase = true)
                }

                items(filteredMembers) { summary ->
                    MemberFinancialCard(
                        summary = summary,
                        currency = currency,
                        onNavigateToProfile = { onNavigateToMember(summary.member.id) }
                    )
                }
            }

            ChitReportTab.SETTLEMENTS -> {
                item {
                    Text(
                        text = "Settlement & Group Ledger Reconciliation",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                val chitTransactions = transactions.filter {
                    it.type in listOf("CHIT_PRIZE_PAYOUT", "CHIT_FOREMAN_COMMISSION", "CHIT_INSTALLMENT") ||
                    it.txnNumber.startsWith("CHIT-") ||
                    it.description.contains("Chit Fund", ignoreCase = true)
                }

                if (chitTransactions.isEmpty()) {
                    item {
                        EmptyStateCard(
                            title = "No Chit Fund Ledger Entries Yet",
                            subtitle = "When an approved auction result is settled, payout debits and foreman credits will be posted here."
                        )
                    }
                } else {
                    item {
                        Text(
                            text = "Linked Group Ledger Entries (${chitTransactions.size})",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    items(chitTransactions) { txn ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = txn.description,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Ref: ${txn.txnNumber} • ${DateUtils.formatDisplayDate(txn.date)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Text(
                                    text = "${if (txn.isCredit) "+" else "-"}${CurrencyFormatter.format(txn.amount, currency)}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (txn.isCredit) StatusPaidText else StatusUnpaidText
                                )
                            }
                        }
                    }
                }
            }

            ChitReportTab.MEMBER_VIEW -> {
                item {
                    Text(
                        text = "Member Standings & Net Financial Position",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                items(memberSummaries) { summary ->
                    MemberStandingsDetailedCard(
                        summary = summary,
                        currency = currency,
                        onNavigateToProfile = { onNavigateToMember(summary.member.id) }
                    )
                }
            }
        }
    }

    // Cycle Detail Inspection Dialog
    if (selectedCycleForDetails != null) {
        val item = selectedCycleForDetails!!
        CycleDetailInspectionDialog(
            item = item,
            currency = currency,
            onDismiss = { selectedCycleForDetails = null },
            onReviewAuction = {
                selectedCycleForDetails = null
                onNavigateToAuctionReview(item.cycleNumber)
            },
            onNavigateToLedger = {
                selectedCycleForDetails = null
                onNavigateToLedger()
            }
        )
    }
}

@Composable
private fun SchemeProgressCard(overview: ChitFundReportOverview) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Scheme Lifecycle Progress",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${overview.completedCyclesCount} of ${overview.totalCycles} Rounds Completed",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            val progress = if (overview.totalCycles > 0) {
                overview.completedCyclesCount.toFloat() / overview.totalCycles.toFloat()
            } else 0f

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceContainerHighest
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Current: Round #${overview.currentCycleNumber}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "${overview.remainingCyclesCount} Rounds remaining",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun CurrentCycleHighlightCard(
    item: ChitCycleReportItem,
    currency: String,
    onInspect: () -> Unit,
    onReviewAuction: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onInspect() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "#${item.cycleNumber}",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 13.sp
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Round #${item.cycleNumber}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (item.scheduledDateMillis > 0) DateUtils.formatDisplayDate(item.scheduledDateMillis) else "Scheduled Date Pending",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                StatusBadge(status = item.cycleStatus.displayName, compact = true)
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Total Pot Value", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(CurrencyFormatter.format(item.totalPot, currency), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Installment", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(CurrencyFormatter.format(item.installmentAmount, currency), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("Winning Bid / Discount", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = item.winningBidAmount?.let { CurrencyFormatter.format(it, currency) } ?: "Pending",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall,
                        color = if (item.winningBidAmount != null) StatusPaidText else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (item.winnerMemberName != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = StatusPartialText, modifier = Modifier.size(14.dp))
                    Text(
                        text = "Winner: ${item.winnerMemberName}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onInspect,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Inspect Round", fontSize = 12.sp)
                }

                Button(
                    onClick = onReviewAuction,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Auction Details", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun CycleHistoryCard(
    item: ChitCycleReportItem,
    currency: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("chit_cycle_item_${item.cycleNumber}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(38.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "#${item.cycleNumber}",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontSize = 13.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "Round #${item.cycleNumber}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (item.scheduledDateMillis > 0) DateUtils.formatDisplayDate(item.scheduledDateMillis) else "Date Pending",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (item.winnerMemberName != null) {
                        Text(
                            text = "Winner: ${item.winnerMemberName}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                StatusBadge(status = item.cycleStatus.displayName, compact = true)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = CurrencyFormatter.format(item.totalPot, currency),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (item.winningBidAmount != null) {
                    Text(
                        text = "Discount: ${CurrencyFormatter.format(item.winningBidAmount, currency)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = StatusPaidText,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
private fun AuctionPerformanceCard(
    item: ChitCycleReportItem,
    currency: String,
    onReviewAuction: () -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Auction: Round #${item.cycleNumber}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Total Bids: ${item.bidsCount} • Valid Bids: ${item.validBidsCount}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                StatusBadge(status = item.cycleStatus.displayName, compact = true)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Winning Discount Bid", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = item.winningBidAmount?.let { CurrencyFormatter.format(it, currency) } ?: "None",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium,
                        color = StatusPaidText
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("Winner", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = item.winnerMemberName ?: "Undetermined",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = { isExpanded = !isExpanded },
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(if (isExpanded) "Hide Bid Records" else "Show Bid Breakdown (${item.cycle.bids.size})", fontSize = 12.sp)
                    Icon(
                        if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                }

                OutlinedButton(
                    onClick = onReviewAuction,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text("Review", fontSize = 11.sp)
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    Spacer(modifier = Modifier.height(4.dp))

                    if (item.cycle.bids.isEmpty()) {
                        Text(
                            "No bids placed in this round.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        item.cycle.bids.sortedByDescending { it.bidAmount }.forEach { bid ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surfaceContainerLow, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(bid.memberName, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                    Text("Status: ${bid.status.displayName}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(
                                    CurrencyFormatter.format(bid.bidAmount, currency),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = if (bid.bidAmount == item.winningBidAmount) StatusPaidText else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MemberFinancialCard(
    summary: ChitMemberFinancialSummary,
    currency: String,
    onNavigateToProfile: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onNavigateToProfile() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = summary.member.name,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${summary.member.memberCode} • ${summary.participatedAuctionsCount} Auctions",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (summary.wonRounds.isNotEmpty()) {
                    Text(
                        text = "Won Round: ${summary.wonRounds.joinToString(", ") { "#$it" }}",
                        style = MaterialTheme.typography.labelSmall,
                        color = StatusPaidText,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "Paid: ${CurrencyFormatter.format(summary.totalPaidAmount, currency)}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = StatusPaidText
                )
                if (summary.totalDueAmount > 0) {
                    Text(
                        text = "Due: ${CurrencyFormatter.format(summary.totalDueAmount, currency)}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = StatusUnpaidText
                    )
                }
            }
        }
    }
}

@Composable
private fun MemberStandingsDetailedCard(
    summary: ChitMemberFinancialSummary,
    currency: String,
    onNavigateToProfile: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onNavigateToProfile() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = summary.member.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = summary.member.memberCode,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Net Position Badge
                val isPositive = summary.netFinancialPosition >= 0
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isPositive) EmeraldPrimary.copy(alpha = 0.12f) else StatusUnpaidText.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, if (isPositive) EmeraldPrimary else StatusUnpaidText)
                ) {
                    Text(
                        text = "Net: ${if (isPositive) "+" else ""}${CurrencyFormatter.format(summary.netFinancialPosition, currency)}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPositive) EmeraldPrimary else StatusUnpaidText,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Total Installments Paid", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(CurrencyFormatter.format(summary.totalPaidAmount, currency), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Dividends Earned", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(CurrencyFormatter.format(summary.totalDividendsEarned, currency), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall, color = StatusPaidText)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("Prize Money Received", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = if (summary.totalPrizeReceived > 0) CurrencyFormatter.format(summary.totalPrizeReceived, currency) else "None",
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (summary.totalPrizeReceived > 0) StatusPaidText else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun CycleDetailInspectionDialog(
    item: ChitCycleReportItem,
    currency: String,
    onDismiss: () -> Unit,
    onReviewAuction: () -> Unit,
    onNavigateToLedger: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Default.Assessment, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text("Round #${item.cycleNumber} Audit Details", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Round Status:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    StatusBadge(status = item.cycleStatus.displayName, compact = true)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Scheduled Date:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        if (item.scheduledDateMillis > 0) DateUtils.formatDisplayDate(item.scheduledDateMillis) else "Pending",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Total Pot Value:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(CurrencyFormatter.format(item.totalPot, currency), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Winning Bid Discount:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        item.winningBidAmount?.let { CurrencyFormatter.format(it, currency) } ?: "-",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = StatusPaidText
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Winner Name:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(item.winnerMemberName ?: "Not yet determined", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                }

                if (item.prizePayoutAmount != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Prize Payout:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(CurrencyFormatter.format(item.prizePayoutAmount, currency), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                    }
                }

                if (item.foremanCommission != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Foreman Commission (5%):", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(CurrencyFormatter.format(item.foremanCommission, currency), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                    }
                }

                if (item.dividendPerMember != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Dividend Per Member:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(CurrencyFormatter.format(item.dividendPerMember, currency), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = StatusPaidText)
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                // Ledger traceability
                Text("Ledger Traceability:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text(
                    text = "Payout Txn: ${item.payoutTxnRef ?: "Pending Settle"}\nCommission Txn: ${item.commissionTxnRef ?: "Pending Settle"}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(onClick = onReviewAuction) {
                Text("Review Auction")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
private fun EmptyStateCard(title: String, subtitle: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(4.dp))
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        }
    }
}

// =============================================================================
// 2. COMMUNITY FUND REPORT TEMPLATE (Standard / Existing Compatibility)
// =============================================================================

@Composable
private fun CommunityFundReportView(
    viewModel: SocietyViewModel,
    settings: GroupSettings,
    context: Context,
    modifier: Modifier = Modifier
) {
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()
    val summary by viewModel.currentMonthSummary.collectAsStateWithLifecycle()
    val membersList by viewModel.monthlyMembersList.collectAsStateWithLifecycle()
    val financials by viewModel.overallFinancials.collectAsStateWithLifecycle()
    val selectedReportType by viewModel.selectedReportType.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("reports_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 24.dp)
    ) {
        // Report Type Selector Tabs
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "MONTHLY" to "Monthly Collection",
                    "PENDING" to "Pending Dues",
                    "OVERALL" to "Overall Society Summary"
                ).forEach { (type, label) ->
                    val isSelected = selectedReportType == type
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.setSelectedReportType(type) },
                        label = { Text(label, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                            containerColor = MaterialTheme.colorScheme.surfaceContainer,
                            labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                        ),
                        modifier = Modifier.testTag("report_tab_$type")
                    )
                }
            }
        }

        // Action Buttons Row (PDF / CSV)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { viewModel.exportCurrentReportPdf(context) },
                    modifier = Modifier.weight(1f).testTag("export_community_pdf_btn"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    contentPadding = PaddingValues(vertical = 8.dp, horizontal = 12.dp)
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Export PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = { viewModel.exportCurrentReportCsv(context) },
                    modifier = Modifier.weight(1f).testTag("export_community_csv_btn"),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(vertical = 8.dp, horizontal = 12.dp)
                ) {
                    Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Export CSV", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Month Picker Bar (if monthly or pending)
        if (selectedReportType != "OVERALL") {
            item {
                MonthPickerBar(
                    selectedMonth = selectedMonth,
                    selectedYear = selectedYear,
                    onPrevClick = { viewModel.prevMonth() },
                    onNextClick = { viewModel.nextMonth() },
                    onMonthYearSelected = { m, y -> viewModel.selectMonthYear(m, y) }
                )
            }
        }

        // Monthly Collection Trends Chart Section (Monthly Report)
        if (selectedReportType == "MONTHLY") {
            item {
                Text(
                    text = "Monthly Collection Trends",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            item {
                CollectionBarChart(
                    trends = financials.monthlyTrends,
                    currencySymbol = settings.currencySymbol
                )
            }
        }

        // Summary Breakdown
        item {
            when (selectedReportType) {
                "MONTHLY" -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StatMetricCard(
                            title = "Total Expected",
                            value = CurrencyFormatter.format(summary.totalExpected, settings.currencySymbol),
                            subtitle = "Target Monthly Dues",
                            icon = Icons.Default.ReceiptLong,
                            accentColor = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f)
                        )
                        StatMetricCard(
                            title = "Collected",
                            value = CurrencyFormatter.format(summary.totalCollected, settings.currencySymbol),
                            subtitle = "${summary.collectionPercentage.toInt()}% collected",
                            icon = Icons.Default.CheckCircle,
                            accentColor = StatusPaidText,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                "PENDING" -> {
                    val pendingItems = membersList.filter { it.status != "PAID" }
                    val totalPending = pendingItems.sumOf { it.dueAmount }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StatMetricCard(
                            title = "Pending Members",
                            value = "${pendingItems.size}",
                            subtitle = "Overdue members",
                            icon = Icons.Default.NotificationImportant,
                            accentColor = StatusUnpaidText,
                            modifier = Modifier.weight(1f)
                        )
                        StatMetricCard(
                            title = "Total Outstanding",
                            value = CurrencyFormatter.format(totalPending, settings.currencySymbol),
                            subtitle = "Unpaid balance",
                            icon = Icons.Default.ReceiptLong,
                            accentColor = StatusUnpaidText,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                "OVERALL" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            StatMetricCard(
                                title = "Total Active Members",
                                value = "${financials.activeMembers}",
                                subtitle = "Enrolled members",
                                icon = Icons.Default.Assessment,
                                accentColor = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(1f)
                            )
                            StatMetricCard(
                                title = "All-Time Collected",
                                value = CurrencyFormatter.format(financials.totalCollectedAllTime, settings.currencySymbol),
                                subtitle = "Total fund received",
                                icon = Icons.Default.CheckCircle,
                                accentColor = StatusPaidText,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // Table Preview Header
        item {
            Text(
                text = "Report Records Preview",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        // Items List
        val displayList = when (selectedReportType) {
            "PENDING" -> membersList.filter { it.status != "PAID" }
            else -> membersList
        }

        if (displayList.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No records found", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            items(displayList) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.member.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                            Text(
                                "${item.member.memberCode} • Exp: ${CurrencyFormatter.format(item.effectiveExpectedAmount, settings.currencySymbol)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Paid: ${CurrencyFormatter.format(item.paidAmount, settings.currencySymbol)}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = if (item.paidAmount > 0) StatusPaidText else MaterialTheme.colorScheme.onSurface
                            )
                            if (item.dueAmount > 0) {
                                Text(
                                    text = "Due: ${CurrencyFormatter.format(item.dueAmount, settings.currencySymbol)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = StatusUnpaidText
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))
                        StatusBadge(status = item.status, compact = true)
                    }
                }
            }
        }
    }
}
