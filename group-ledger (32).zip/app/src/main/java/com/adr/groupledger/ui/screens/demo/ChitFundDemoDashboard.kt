package com.adr.groupledger.ui.screens.demo

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoHeroDark
import com.adr.groupledger.ui.theme.IndigoHeroSurface
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.SlateTertiary
import kotlinx.coroutines.delay

/**
 * Auction status lifecycle states for Chit Fund.
 */
enum class AuctionStatus(val label: String, val badgeColor: Color) {
    UPCOMING("UPCOMING", Amber500),
    OPEN("AUCTION OPEN", Emerald500),
    CLOSED("BID SUBMISSION CLOSED", Rose500),
    REVIEW("RESULT PROCESSING", Amber500),
    PUBLISHED("RESULT PUBLISHED", Emerald500),
    COMPLETED("AUCTION COMPLETED", IndigoPrimary),
    RESCHEDULED("RESCHEDULED", Color.Gray)
}

/**
 * Historical chit round record.
 */
data class CompletedChitRound(
    val roundNumber: Int,
    val winnerName: String,
    val winningDiscount: String,
    val netDisbursed: String,
    val dividendPerMember: String,
    val date: String
)

/**
 * Sample member status for chit collection.
 */
data class ChitMemberStatus(
    val id: Int,
    val name: String,
    val status: String, // Paid, Partial, Pending
    val paidAmount: String,
    val hasWonChit: Boolean = false
)

/**
 * Main dedicated Chit Fund Dashboard content:
 * Follows the 11-section mobile financial hierarchy requested.
 */
@Composable
fun ChitFundDashboardContent(
    groupName: String = "Shakti Chit Fund",
    onEditSetupClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    // Interactive demo dialog states
    var showAuctionModal by remember { mutableStateOf(false) }
    var showRulesModal by remember { mutableStateOf(false) }
    var showHistoryModal by remember { mutableStateOf(false) }
    var showMembersModal by remember { mutableStateOf(false) }
    var showMyBidsModal by remember { mutableStateOf(false) }
    var showPaymentModal by remember { mutableStateOf(false) }

    // Auction current state for interactive testing
    var currentAuctionState by remember { mutableStateOf(AuctionStatus.UPCOMING) }

    // User's bid state in the demo
    var userSubmittedBid by remember { mutableStateOf<String?>(null) }
    var userBidTime by remember { mutableStateOf<String?>(null) }

    // Personal user installment status toggle (Paid vs Pending)
    var isUserInstallmentPaid by remember { mutableStateOf(true) }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Group Header & Identity Banner
        ChitFundHeaderCard(
            groupName = groupName,
            onRulesClick = { showRulesModal = true }
        )

        // Notification Ticker
        ChitFundNotificationBanner(
            onNotificationClick = { showAuctionModal = true }
        )

        // 2. Main Chit Fund Summary Card (Primary Focus)
        ChitFundMainSummaryCard(
            groupName = groupName,
            totalChitValue = "₹10,00,000",
            currentChit = 9,
            totalChits = 20,
            completedChits = 8,
            monthlyInstallment = "₹50,000",
            totalMembers = 20,
            cycleFrequency = "Monthly"
        )

        // 3. Chit Progress Section
        ChitProgressCard(
            currentChit = 9,
            totalChits = 20,
            completedChits = 8,
            startDate = "January 2026",
            expectedEndDate = "August 2027"
        )

        // 4. Next Auction Card — Most Important Action (Live Countdown)
        NextAuctionActionCard(
            chitRound = 9,
            auctionDate = "28 September 2026",
            auctionTime = "8:00 PM",
            auctionStatus = currentAuctionState,
            onViewAuction = { showAuctionModal = true },
            onQuickStateChange = { currentAuctionState = it }
        )

        // 5. Current Installment Status Card
        CurrentInstallmentCard(
            month = "October 2026",
            targetAmount = "₹10,00,000",
            collectedAmount = "₹9,25,000",
            pendingAmount = "₹75,000",
            progressPercent = 92.5f
        )

        // 6. Member Payment Distribution Status
        ChitMemberStatusCard(
            totalMembers = 20,
            paidCount = 18,
            partialCount = 1,
            pendingCount = 1,
            onViewMembersList = { showMembersModal = true }
        )

        // 7. Personal User Action ("Your Status")
        PersonalMemberStatusCard(
            isPaid = isUserInstallmentPaid,
            monthlyInstallment = "₹50,000",
            dividendSavings = "₹8,750",
            effectivePayable = "₹41,250",
            isAuctionEligible = true,
            onPayClick = { showPaymentModal = true },
            onToggleStatus = { isUserInstallmentPaid = !isUserInstallmentPaid }
        )

        // 8. Quick Actions Grid
        ChitQuickActionsGrid(
            onAuctionClick = { showAuctionModal = true },
            onMyBidsClick = { showMyBidsModal = true },
            onInstallmentClick = { showPaymentModal = true },
            onMembersClick = { showMembersModal = true },
            onHistoryClick = { showHistoryModal = true },
            onRulesClick = { showRulesModal = true }
        )

        // 9. Chit History (Recent Completed Rounds)
        ChitHistoryCard(
            onViewAllHistory = { showHistoryModal = true }
        )

        // 10. Financial Summary (Chit Fund specific)
        ChitFinancialSummaryCard()

        // 11. Auction Rules & Transparency Card
        ChitAuctionRulesCard(
            onViewFullRules = { showRulesModal = true }
        )
    }

    // =========================================================================
    // Interactive Demo Dialogs
    // =========================================================================

    // 1. Dedicated Interactive Auction Dialog
    if (showAuctionModal) {
        AuctionInteractiveDialog(
            chitRound = 9,
            totalChitValue = "₹10,00,000",
            eligibleMembers = 20,
            auctionStatus = currentAuctionState,
            userSubmittedBid = userSubmittedBid,
            userBidTime = userBidTime,
            onStatusChange = { currentAuctionState = it },
            onSubmitBid = { amount ->
                userSubmittedBid = amount
                userBidTime = "Today, 8:12 PM"
            },
            onDismiss = { showAuctionModal = false }
        )
    }

    // 2. Full Auction Rules Dialog
    if (showRulesModal) {
        ChitRulesDialog(onDismiss = { showRulesModal = false })
    }

    // 3. Chit History Full Dialog
    if (showHistoryModal) {
        ChitFullHistoryDialog(onDismiss = { showHistoryModal = false })
    }

    // 4. Members List Dialog
    if (showMembersModal) {
        ChitMembersDialog(onDismiss = { showMembersModal = false })
    }

    // 5. My Bids Dialog
    if (showMyBidsModal) {
        MyBidsDialog(
            currentBid = userSubmittedBid,
            bidTime = userBidTime,
            onDismiss = { showMyBidsModal = false }
        )
    }

    // 6. Installment Payment Dialog
    if (showPaymentModal) {
        InstallmentPaymentDemoDialog(
            isPaid = isUserInstallmentPaid,
            onMarkPaid = {
                isUserInstallmentPaid = true
                showPaymentModal = false
            },
            onDismiss = { showPaymentModal = false }
        )
    }
}

// =============================================================================
// SECTION 1: TOP GROUP HEADER
// =============================================================================

@Composable
fun ChitFundHeaderCard(
    groupName: String,
    onRulesClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = CircleShape,
                    color = IndigoPrimary.copy(alpha = 0.15f),
                    modifier = Modifier.size(44.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Gavel,
                            contentDescription = null,
                            tint = IndigoPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = groupName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        // Subtle DEMO tag
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Amber500.copy(alpha = 0.18f),
                            border = BorderStroke(0.5.dp, Amber500.copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = "DEMO",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Amber500,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Savings, Credit & Chit Fund",
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        // Premium subtle badge
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = IndigoPrimary.copy(alpha = 0.15f),
                            border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.45f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = IndigoPrimary,
                                    modifier = Modifier.size(10.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "CHIT FUND",
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = IndigoPrimary,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }
                    }
                }
            }

            IconButton(
                onClick = onRulesClick,
                modifier = Modifier.size(34.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Chit Rules",
                    tint = IndigoPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun ChitFundNotificationBanner(
    onNotificationClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = IndigoPrimary.copy(alpha = 0.08f),
        border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.25f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onNotificationClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Notifications,
                contentDescription = null,
                tint = IndigoPrimary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Next auction in 6 days (28 Sep, 8:00 PM) • Chit #09",
                fontSize = 11.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = IndigoPrimary,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

// =============================================================================
// SECTION 2: MAIN CHIT FUND SUMMARY CARD
// =============================================================================

@Composable
fun ChitFundMainSummaryCard(
    groupName: String,
    totalChitValue: String,
    currentChit: Int,
    totalChits: Int,
    completedChits: Int,
    monthlyInstallment: String,
    totalMembers: Int,
    cycleFrequency: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("demo_chit_main_summary_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = IndigoHeroDark),
        border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.4f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            IndigoHeroSurface.copy(alpha = 0.85f),
                            IndigoHeroDark
                        )
                    )
                )
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Top Row: Group name & current chit badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = groupName,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                    Text(
                        text = "Active Rotating Savings Scheme",
                        fontSize = 10.5.sp,
                        color = Color.White.copy(alpha = 0.6f)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Amber500.copy(alpha = 0.2f),
                    border = BorderStroke(1.dp, Amber500.copy(alpha = 0.6f))
                ) {
                    Text(
                        text = "Chit #0$currentChit of $totalChits",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Amber500,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            // Graphical Progress Bar & Circular Completion
            val completionFraction = completedChits.toFloat() / totalChits.toFloat()
            val remainingChits = totalChits - completedChits

            // Central Focus: Total Chit Value & Circular Completion Indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "TOTAL CHIT VALUE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.7f),
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = totalChitValue,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Emerald500.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "Guaranteed Pool",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Emerald500,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "$totalMembers Members • $monthlyInstallment",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.75f)
                        )
                    }
                }

                // Distinctive Circular completion indicator (8 Completed, 12 Remaining, 40%)
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White.copy(alpha = 0.08f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(54.dp)) {
                            CircularProgressIndicator(
                                progress = { completionFraction },
                                modifier = Modifier.size(52.dp),
                                color = Amber500,
                                trackColor = Color.White.copy(alpha = 0.15f),
                                strokeWidth = 5.dp
                            )
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${(completionFraction * 100).toInt()}%",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                                Text(
                                    text = "DONE",
                                    fontSize = 7.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Amber500
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$completedChits Completed",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Emerald500
                        )
                        Text(
                            text = "$remainingChits Remaining",
                            fontSize = 8.5.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Overall Scheme Progress",
                        fontSize = 11.5.sp,
                        color = Color.White.copy(alpha = 0.8f),
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "$completedChits of $totalChits Rounds Completed",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Amber500
                    )
                }

                LinearProgressIndicator(
                    progress = { completionFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(7.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = Amber500,
                    trackColor = Color.White.copy(alpha = 0.15f)
                )
            }

            HorizontalDivider(color = Color.White.copy(alpha = 0.12f), thickness = 0.8.dp)

            // 3 Key Stats Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ChitStatBox(
                    label = "Members",
                    value = "$totalMembers",
                    subtext = "Active participants",
                    modifier = Modifier.weight(1f)
                )
                ChitStatBox(
                    label = "Monthly Installment",
                    value = monthlyInstallment,
                    subtext = "Per member",
                    modifier = Modifier.weight(1.2f)
                )
                ChitStatBox(
                    label = "Cycle Frequency",
                    value = cycleFrequency.uppercase(),
                    subtext = "Every 28th",
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun ChitStatBox(
    label: String,
    value: String,
    subtext: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = Color.White.copy(alpha = 0.07f),
        border = BorderStroke(0.8.dp, Color.White.copy(alpha = 0.15f))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = label,
                fontSize = 9.5.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White.copy(alpha = 0.6f),
                maxLines = 1
            )
            Text(
                text = value,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1
            )
            Text(
                text = subtext,
                fontSize = 9.sp,
                color = Color.White.copy(alpha = 0.5f),
                maxLines = 1
            )
        }
    }
}

// =============================================================================
// SECTION 3: CHIT PROGRESS SECTION
// =============================================================================

@Composable
fun ChitProgressCard(
    currentChit: Int,
    totalChits: Int,
    completedChits: Int,
    startDate: String,
    expectedEndDate: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Assessment,
                        contentDescription = null,
                        tint = IndigoPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Chit Lifecycle Progress",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = IndigoPrimary.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "Current: #0$currentChit",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // Segmented Round Progress Visualization
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                for (i in 1..totalChits) {
                    val isCompleted = i <= completedChits
                    val isCurrent = i == currentChit
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(10.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(
                                when {
                                    isCurrent -> Amber500
                                    isCompleted -> Emerald500
                                    else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                                }
                            )
                    )
                }
            }

            // Legend & Breakdown
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Emerald500))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("$completedChits Completed", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Amber500))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("#0$currentChit Active", fontSize = 11.sp, color = Amber500, fontWeight = FontWeight.Bold)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("${totalChits - completedChits} Left", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f))

            // Timeline dates
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Started", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(startDate, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Expected Completion", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(expectedEndDate, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                }
            }
        }
    }
}

// =============================================================================
// SECTION 4: NEXT AUCTION CARD — MOST IMPORTANT ACTION
// =============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NextAuctionActionCard(
    chitRound: Int,
    auctionDate: String,
    auctionTime: String,
    auctionStatus: AuctionStatus,
    onViewAuction: () -> Unit,
    onQuickStateChange: (AuctionStatus) -> Unit
) {
    // Live ticking countdown timer
    var remainingSeconds by remember { mutableIntStateOf(6 * 86400 + 4 * 3600 + 21 * 60 + 32) }

    LaunchedEffect(Unit) {
        while (remainingSeconds > 0) {
            delay(1000)
            remainingSeconds -= 1
        }
    }

    val days = remainingSeconds / 86400
    val hours = (remainingSeconds % 86400) / 3600
    val minutes = (remainingSeconds % 3600) / 60
    val seconds = remainingSeconds % 60

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("demo_chit_next_auction_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            1.5.dp,
            when (auctionStatus) {
                AuctionStatus.OPEN -> Emerald500
                AuctionStatus.UPCOMING -> IndigoPrimary.copy(alpha = 0.6f)
                else -> MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Row: Next Auction label + Status badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = if (auctionStatus == AuctionStatus.OPEN) Emerald500.copy(alpha = 0.18f) else IndigoPrimary.copy(alpha = 0.15f),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Gavel,
                                contentDescription = null,
                                tint = if (auctionStatus == AuctionStatus.OPEN) Emerald500 else IndigoPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "NEXT AUCTION",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            letterSpacing = 0.8.sp
                        )
                        Text(
                            text = "Chit #0$chitRound Bidding Round",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                // Status Badge
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = auctionStatus.badgeColor.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, auctionStatus.badgeColor.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = auctionStatus.label,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = auctionStatus.badgeColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            // Date & Time Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Event, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(auctionDate, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Timer, contentDescription = null, tint = Amber500, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(auctionTime, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Amber500)
                }
            }

            // Segmented Live Countdown UI
            if (auctionStatus == AuctionStatus.UPCOMING) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "AUCTION OPENS IN",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        letterSpacing = 0.8.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CountdownSegment(value = "%02d".format(days), unit = "DAYS")
                        CountdownSeparator()
                        CountdownSegment(value = "%02d".format(hours), unit = "HOURS")
                        CountdownSeparator()
                        CountdownSegment(value = "%02d".format(minutes), unit = "MINS")
                        CountdownSeparator()
                        CountdownSegment(value = "%02d".format(seconds), unit = "SECS", isSeconds = true)
                    }
                }
            } else if (auctionStatus == AuctionStatus.OPEN) {
                // Live auction open banner
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Emerald500.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, Emerald500.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Current Best Bid (Discount)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("₹1,85,000", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Bids Received: 12", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                            Text("Closes in 08:42", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = Amber500)
                        }
                    }
                }
            }

            // Automation Note
            Text(
                text = "⚡ When countdown ends, auction automatically opens for 30 mins to all eligible members.",
                fontSize = 10.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 14.sp
            )

            // Primary CTA: Adaptive based on Auction state
            val ctaLabel = when (auctionStatus) {
                AuctionStatus.OPEN -> "Enter Live Auction & Bid"
                AuctionStatus.UPCOMING -> "View Auction Details"
                AuctionStatus.PUBLISHED, AuctionStatus.COMPLETED -> "View Auction Result"
                AuctionStatus.REVIEW, AuctionStatus.CLOSED -> "Check Result Processing"
                AuctionStatus.RESCHEDULED -> "View Rescheduled Date"
            }

            Button(
                onClick = onViewAuction,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("demo_view_auction_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = when (auctionStatus) {
                        AuctionStatus.OPEN -> Emerald500
                        AuctionStatus.COMPLETED, AuctionStatus.PUBLISHED -> IndigoPrimary
                        else -> IndigoPrimary
                    }
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Gavel,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = ctaLabel,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }

            // Quick State Switcher for testing all states
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Demo Preview State:",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    DemoStateChip(
                        label = "Upcoming",
                        isSelected = auctionStatus == AuctionStatus.UPCOMING,
                        onClick = { onQuickStateChange(AuctionStatus.UPCOMING) }
                    )
                    DemoStateChip(
                        label = "Open (Live)",
                        isSelected = auctionStatus == AuctionStatus.OPEN,
                        onClick = { onQuickStateChange(AuctionStatus.OPEN) }
                    )
                    DemoStateChip(
                        label = "Review",
                        isSelected = auctionStatus == AuctionStatus.REVIEW,
                        onClick = { onQuickStateChange(AuctionStatus.REVIEW) }
                    )
                    DemoStateChip(
                        label = "Published",
                        isSelected = auctionStatus == AuctionStatus.PUBLISHED,
                        onClick = { onQuickStateChange(AuctionStatus.PUBLISHED) }
                    )
                    DemoStateChip(
                        label = "Completed",
                        isSelected = auctionStatus == AuctionStatus.COMPLETED,
                        onClick = { onQuickStateChange(AuctionStatus.COMPLETED) }
                    )
                    DemoStateChip(
                        label = "Rescheduled",
                        isSelected = auctionStatus == AuctionStatus.RESCHEDULED,
                        onClick = { onQuickStateChange(AuctionStatus.RESCHEDULED) }
                    )
                }
            }
        }
    }
}

@Composable
private fun DemoStateChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = if (isSelected) IndigoPrimary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            text = label,
            fontSize = 9.5.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun CountdownSegment(
    value: String,
    unit: String,
    isSeconds: Boolean = false
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(52.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = if (isSeconds) IndigoPrimary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
            border = BorderStroke(1.dp, if (isSeconds) IndigoPrimary.copy(alpha = 0.4f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
            modifier = Modifier.size(width = 50.dp, height = 40.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = value,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSeconds) IndigoPrimary else MaterialTheme.colorScheme.onSurface
                )
            }
        }
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = unit,
            fontSize = 9.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun CountdownSeparator() {
    Text(
        text = ":",
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)
    )
}

// =============================================================================
// SECTION 5: CURRENT INSTALLMENT STATUS
// =============================================================================

@Composable
fun CurrentInstallmentCard(
    month: String,
    targetAmount: String,
    collectedAmount: String,
    pendingAmount: String,
    progressPercent: Float
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CURRENT INSTALLMENT",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        letterSpacing = 0.8.sp
                    )
                    Text(
                        text = "$month Collection",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Emerald500.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "$progressPercent% Collected",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald500,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            // Progress Bar
            LinearProgressIndicator(
                progress = { progressPercent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = Emerald500,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            // Target vs Collected vs Pending
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Target", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(targetAmount, fontSize = 13.5.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Collected", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(collectedAmount, fontSize = 13.5.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Pending", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(pendingAmount, fontSize = 13.5.sp, fontWeight = FontWeight.Bold, color = Amber500)
                }
            }
        }
    }
}

// =============================================================================
// SECTION 6: CHIT MEMBER STATUS CARD
// =============================================================================

@Composable
fun ChitMemberStatusCard(
    totalMembers: Int,
    paidCount: Int,
    partialCount: Int,
    pendingCount: Int,
    onViewMembersList: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Groups, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Member Dues Status",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                TextButton(
                    onClick = onViewMembersList,
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(
                        text = "View All $totalMembers",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary
                    )
                }
            }

            // 3 Semantic Colored Indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MemberStatusIndicator(
                    label = "Paid",
                    count = paidCount,
                    color = Emerald500,
                    modifier = Modifier.weight(1f)
                )
                MemberStatusIndicator(
                    label = "Partial",
                    count = partialCount,
                    color = Amber500,
                    modifier = Modifier.weight(1f)
                )
                MemberStatusIndicator(
                    label = "Pending",
                    count = pendingCount,
                    color = Rose500,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MemberStatusIndicator(
    label: String,
    count: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = color.copy(alpha = 0.08f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(color))
                Spacer(modifier = Modifier.width(6.dp))
                Text(label, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            }
            Text("$count", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

// =============================================================================
// SECTION 7: PERSONAL USER ACTION (YOUR STATUS)
// =============================================================================

@Composable
fun PersonalMemberStatusCard(
    isPaid: Boolean,
    monthlyInstallment: String,
    dividendSavings: String,
    effectivePayable: String,
    isAuctionEligible: Boolean,
    onPayClick: () -> Unit,
    onToggleStatus: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, if (isPaid) Emerald500.copy(alpha = 0.4f) else Amber500.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "YOUR STATUS (Member #03)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        letterSpacing = 0.6.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isPaid) Emerald500.copy(alpha = 0.15f) else Rose500.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = if (isPaid) "PAID ✓" else "DUE PENDING",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPaid) Emerald500 else Rose500,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // Calculation row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Gross Installment: $monthlyInstallment", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Dividend Discount: -$dividendSavings", fontSize = 11.sp, color = Emerald500, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text("Net Amount: $effectivePayable", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("Auction Eligibility", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (isAuctionEligible) Emerald500.copy(alpha = 0.15f) else Color.Gray.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = if (isAuctionEligible) "Eligible (Not Taken)" else "Prized (Taken)",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isAuctionEligible) Emerald500 else Color.Gray,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            // Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onToggleStatus,
                    modifier = Modifier.weight(1f).height(36.dp),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Text(
                        text = if (isPaid) "Simulate Due" else "Simulate Paid",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Button(
                    onClick = onPayClick,
                    modifier = Modifier.weight(1f).height(36.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                ) {
                    Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isPaid) "View Receipt" else "Pay Installment",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// =============================================================================
// SECTION 8: QUICK ACTIONS GRID
// =============================================================================

@Composable
fun ChitQuickActionsGrid(
    onAuctionClick: () -> Unit,
    onMyBidsClick: () -> Unit,
    onInstallmentClick: () -> Unit,
    onMembersClick: () -> Unit,
    onHistoryClick: () -> Unit,
    onRulesClick: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "QUICK ACTIONS",
            fontSize = 10.5.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            letterSpacing = 0.8.sp
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ChitActionTile(icon = Icons.Default.Gavel, label = "Auction", color = IndigoPrimary, onClick = onAuctionClick, modifier = Modifier.weight(1f))
            ChitActionTile(icon = Icons.Default.Receipt, label = "My Bids", color = Amber500, onClick = onMyBidsClick, modifier = Modifier.weight(1f))
            ChitActionTile(icon = Icons.Default.Payment, label = "Pay Due", color = Emerald500, onClick = onInstallmentClick, modifier = Modifier.weight(1f))
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ChitActionTile(icon = Icons.Default.Groups, label = "Members", color = SlateTertiary, onClick = onMembersClick, modifier = Modifier.weight(1f))
            ChitActionTile(icon = Icons.Default.History, label = "History", color = IndigoPrimary, onClick = onHistoryClick, modifier = Modifier.weight(1f))
            ChitActionTile(icon = Icons.Default.Security, label = "Rules", color = Amber500, onClick = onRulesClick, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
private fun ChitActionTile(
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = color.copy(alpha = 0.12f),
                modifier = Modifier.size(34.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(17.dp))
                }
            }
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
        }
    }
}

// =============================================================================
// SECTION 9: CHIT HISTORY
// =============================================================================

@Composable
fun ChitHistoryCard(
    onViewAllHistory: () -> Unit
) {
    val sampleCompletedRounds = listOf(
        CompletedChitRound(8, "Rajesh Sharma", "₹1,75,000", "₹8,25,000", "₹8,750", "28 Aug 2026"),
        CompletedChitRound(7, "Priya Mukherjee", "₹1,60,000", "₹8,40,000", "₹8,000", "28 Jul 2026"),
        CompletedChitRound(6, "Amit Kumar", "₹1,90,000", "₹8,10,000", "₹9,500", "28 Jun 2026")
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.History, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Chit Round History",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                TextButton(
                    onClick = onViewAllHistory,
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(
                        text = "View All 8",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                sampleCompletedRounds.forEach { round ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Emerald500.copy(alpha = 0.15f),
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text("#0${round.roundNumber}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                                    }
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(round.winnerName, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                                    Text("Net Payout: ${round.netDisbursed}", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = IndigoPrimary.copy(alpha = 0.12f)
                                ) {
                                    Text(
                                        text = "+${round.dividendPerMember} Div",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = IndigoPrimary,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                                Text(round.date, fontSize = 9.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}

// =============================================================================
// SECTION 10: FINANCIAL SUMMARY
// =============================================================================

@Composable
fun ChitFinancialSummaryCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountBalance, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Chit Financial Summary",
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FinancialMiniCard(label = "Total Scheme Pool", value = "₹10,00,000", sublabel = "Per Month", color = IndigoPrimary, modifier = Modifier.weight(1f))
                FinancialMiniCard(label = "Disbursed (8 Chits)", value = "₹66,25,000", sublabel = "Prize money", color = Emerald500, modifier = Modifier.weight(1f))
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FinancialMiniCard(label = "Dividends Distributed", value = "₹13,75,000", sublabel = "Member savings", color = IndigoPrimary, modifier = Modifier.weight(1f))
                FinancialMiniCard(label = "Current Round Dues", value = "₹9,25,000", sublabel = "92.5% collected", color = Amber500, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun FinancialMiniCard(
    label: String,
    value: String,
    sublabel: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = color)
            Text(sublabel, fontSize = 9.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// =============================================================================
// SECTION 11: AUCTION RULES & TRANSPARENCY CARD
// =============================================================================

@Composable
fun ChitAuctionRulesCard(
    onViewFullRules: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = Amber500, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Configured Auction Rules",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = Emerald500.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "Transparent",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald500,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                RuleBulletItem("Auction Frequency: Monthly (Every 28th at 8:00 PM)")
                RuleBulletItem("Eligible Members: 20 participants")
                RuleBulletItem("Bidding Window: 30 Minutes duration")
                RuleBulletItem("Min Discount: ₹1,00,000 (10%) | Max Ceiling: ₹3,00,000 (30%)")
                RuleBulletItem("Winner Calculation: Reverse Bidding (Highest discount bid)")
                RuleBulletItem("Disbursement: Admin & Treasurer dual approval required")
            }

            OutlinedButton(
                onClick = onViewFullRules,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.5f))
            ) {
                Text(
                    text = "View Full Rules & Bylaws",
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = IndigoPrimary
                )
            }
        }
    }
}

@Composable
private fun RuleBulletItem(text: String) {
    Row(verticalAlignment = Alignment.Top) {
        Text("• ", fontSize = 11.5.sp, color = IndigoPrimary, fontWeight = FontWeight.Bold)
        Text(text, fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 15.sp)
    }
}

// =============================================================================
// INTERACTIVE AUCTION DIALOG (WITH BID SUBMISSION FLOW)
// =============================================================================

@Composable
fun AuctionInteractiveDialog(
    chitRound: Int,
    totalChitValue: String,
    eligibleMembers: Int,
    auctionStatus: AuctionStatus,
    userSubmittedBid: String?,
    userBidTime: String?,
    onStatusChange: (AuctionStatus) -> Unit,
    onSubmitBid: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var bidInput by remember { mutableStateOf(userSubmittedBid ?: "185000") }
    var bidError by remember { mutableStateOf<String?>(null) }
    var bidSubmittedSuccess by remember { mutableStateOf(userSubmittedBid != null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.4f)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "CURRENT AUCTION",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = IndigoPrimary,
                                letterSpacing = 0.8.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = auctionStatus.badgeColor.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = auctionStatus.label,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = auctionStatus.badgeColor,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text(
                            text = "Chit #0$chitRound ($totalChitValue)",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", modifier = Modifier.size(18.dp))
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

                // Phase Selector Pills to test all states
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Phase:", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        DemoStateChip("Upcoming", auctionStatus == AuctionStatus.UPCOMING) { onStatusChange(AuctionStatus.UPCOMING) }
                        DemoStateChip("Open (Live)", auctionStatus == AuctionStatus.OPEN) { onStatusChange(AuctionStatus.OPEN) }
                        DemoStateChip("Completed", auctionStatus == AuctionStatus.COMPLETED) { onStatusChange(AuctionStatus.COMPLETED) }
                    }
                }

                // Conditional UI by state
                when (auctionStatus) {
                    AuctionStatus.UPCOMING -> {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Timer, contentDescription = null, tint = Amber500, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Scheduled for 28 Sep 2026, 8:00 PM", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                                }
                                Text(
                                    text = "Bidding will automatically unlock when timer reaches zero. You can review your eligible discount limit below.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 15.sp
                                )
                            }
                        }

                        // Limits preview
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FinancialMiniCard("Min Bid Discount", "₹1,00,000 (10%)", "Floor limit", IndigoPrimary, Modifier.weight(1f))
                            FinancialMiniCard("Max Ceiling Discount", "₹3,00,000 (30%)", "Cap limit", Amber500, Modifier.weight(1f))
                        }
                    }

                    AuctionStatus.OPEN -> {
                        // Live Stats
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Emerald500.copy(alpha = 0.12f),
                            border = BorderStroke(1.dp, Emerald500.copy(alpha = 0.35f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Current Best Bid", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("₹1,85,000", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Bids", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("12", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Time Remaining", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("08:42", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Amber500)
                                }
                            }
                        }

                        // Bid Input Section
                        if (bidSubmittedSuccess) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Emerald500.copy(alpha = 0.12f),
                                border = BorderStroke(1.dp, Emerald500.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Emerald500, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Your bid has been submitted!", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                                    }
                                    Text("Your Bid Discount: ₹$bidInput", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                                    Text("Expected Net Payout: ₹${1000000 - (bidInput.toLongOrNull() ?: 185000)}", fontSize = 11.sp, color = IndigoPrimary)
                                    Text("Submission Time: ${userBidTime ?: "Today, 8:12 PM"} • Status: Verified", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            OutlinedButton(
                                onClick = { bidSubmittedSuccess = false },
                                modifier = Modifier.fillMaxWidth().height(36.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Update Bid Amount", fontSize = 11.5.sp)
                            }
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "ENTER YOUR BID (DISCOUNT OFFER)",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                OutlinedTextField(
                                    value = bidInput,
                                    onValueChange = {
                                        bidInput = it.filter { char -> char.isDigit() }
                                        val numeric = bidInput.toLongOrNull() ?: 0L
                                        bidError = when {
                                            numeric < 100000 -> "Minimum bid discount is ₹1,00,000 (10%)"
                                            numeric > 300000 -> "Maximum allowed bid is ₹3,00,000 (30% ceiling)"
                                            else -> null
                                        }
                                    },
                                    prefix = { Text("₹ ", fontWeight = FontWeight.Bold) },
                                    isError = bidError != null,
                                    supportingText = {
                                        if (bidError != null) {
                                            Text(bidError!!, color = Rose500, fontSize = 10.sp)
                                        } else {
                                            Text("Min: ₹1,00,000 | Max: ₹3,00,000 | Step: ₹1,000", fontSize = 10.sp)
                                        }
                                    },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.fillMaxWidth().testTag("demo_auction_bid_input"),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = IndigoPrimary,
                                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                                    )
                                )

                                Button(
                                    onClick = {
                                        val numeric = bidInput.toLongOrNull() ?: 0L
                                        if (numeric in 100000..300000) {
                                            onSubmitBid(bidInput)
                                            bidSubmittedSuccess = true
                                        } else {
                                            bidError = "Please enter an amount between ₹1,00,000 and ₹3,00,000"
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().height(42.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Emerald500)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Submit Bid", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                        }
                    }

                    AuctionStatus.COMPLETED -> {
                        // Official Completed Result Card
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = IndigoPrimary.copy(alpha = 0.10f),
                            border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.35f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("AUCTION COMPLETED", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                                    Text("Chit #0$chitRound Result", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }

                                HorizontalDivider(color = IndigoPrimary.copy(alpha = 0.2f))

                                Text("Winner: Rajesh Sharma (Member #04)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                Text("Winning Bid Discount: ₹1,75,000", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                                Text("Gross Scheme Pool: $totalChitValue", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("Net Disbursed to Winner: ₹8,25,000", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                                Text("Dividend Per Member: ₹8,750 (Saved on next installment)", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = IndigoPrimary)
                            }
                        }
                    }
                    else -> {}
                }

                // Close CTA
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Close", fontWeight = FontWeight.SemiBold, color = IndigoPrimary)
                }
            }
        }
    }
}

// =============================================================================
// AUXILIARY DIALOGS: RULES, HISTORY, MEMBERS, MY BIDS, INSTALLMENT
// =============================================================================

@Composable
fun ChitRulesDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Chit Fund Bylaws & Rules", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", modifier = Modifier.size(18.dp))
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("1. Monthly Cycle & Due Dates", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = IndigoPrimary)
                    Text("Installment of ₹50,000 is due on or before the 20th of every calendar month. Late payment fee of 2% applies after due date.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Text("2. Reverse Bidding Mechanism", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = IndigoPrimary)
                    Text("Members bid the discount amount they are willing to forgo from the ₹10,00,000 total scheme. The eligible member who bids the highest discount wins the prize pool.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Text("3. Floor & Ceiling Caps", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = IndigoPrimary)
                    Text("Minimum bid discount is 10% (₹1,00,000). Maximum discount ceiling is 30% (₹3,00,000) to protect subscriber interests.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Text("4. Equal Dividend Distribution", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = IndigoPrimary)
                    Text("The entire discount bid (minus 5% foreman commission) is divided equally among all 20 members and credited to reduce the next monthly installment.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Text("5. One Win Limit", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = IndigoPrimary)
                    Text("A member who has already won a chit is prized and cannot bid again, but must continue paying monthly dues until round 20.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth().height(40.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                ) {
                    Text("Got It", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ChitFullHistoryDialog(onDismiss: () -> Unit) {
    val allRounds = listOf(
        CompletedChitRound(8, "Rajesh Sharma", "₹1,75,000", "₹8,25,000", "₹8,750", "28 Aug 2026"),
        CompletedChitRound(7, "Priya Mukherjee", "₹1,60,000", "₹8,40,000", "₹8,000", "28 Jul 2026"),
        CompletedChitRound(6, "Amit Kumar", "₹1,90,000", "₹8,10,000", "₹9,500", "28 Jun 2026"),
        CompletedChitRound(5, "Sneha Das", "₹1,50,000", "₹8,50,000", "₹7,500", "28 May 2026"),
        CompletedChitRound(4, "Vikram Patel", "₹2,10,000", "₹7,90,000", "₹10,500", "28 Apr 2026"),
        CompletedChitRound(3, "Ananya Roy", "₹1,80,000", "₹8,20,000", "₹9,000", "28 Mar 2026"),
        CompletedChitRound(2, "Manoj Tiwari", "₹1,70,000", "₹8,30,000", "₹8,500", "28 Feb 2026"),
        CompletedChitRound(1, "Foreman Chit (No Bid)", "₹0", "₹10,00,000", "₹0", "28 Jan 2026")
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("All 8 Completed Chits", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", modifier = Modifier.size(18.dp))
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

                LazyColumn(
                    modifier = Modifier.fillMaxWidth().height(320.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(allRounds) { round ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("#0${round.roundNumber} - ${round.winnerName}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                    Text("Disbursed: ${round.netDisbursed} (${round.winningDiscount} disc)", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("+${round.dividendPerMember} Div", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                                    Text(round.date, fontSize = 9.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth().height(40.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                ) {
                    Text("Close", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ChitMembersDialog(onDismiss: () -> Unit) {
    val sampleMembers = (1..20).map { id ->
        ChitMemberStatus(
            id = id,
            name = when (id) {
                1 -> "Suresh Banik (Admin)"
                2 -> "Rahul Sen"
                3 -> "You (Current User)"
                4 -> "Rajesh Sharma"
                5 -> "Priya Mukherjee"
                6 -> "Amit Kumar"
                7 -> "Sneha Das"
                8 -> "Vikram Patel"
                9 -> "Ananya Roy"
                10 -> "Manoj Tiwari"
                19 -> "Sunil Verma"
                20 -> "Deepak Saha"
                else -> "Member #%02d".format(id)
            },
            status = when {
                id == 20 -> "Pending"
                id == 19 -> "Partial"
                else -> "Paid"
            },
            paidAmount = when {
                id == 20 -> "₹0"
                id == 19 -> "₹25,000"
                else -> "₹41,250"
            },
            hasWonChit = id in listOf(1, 4, 5, 6, 7, 8, 9, 10)
        )
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("20 Registered Chit Members", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", modifier = Modifier.size(18.dp))
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

                LazyColumn(
                    modifier = Modifier.fillMaxWidth().height(320.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(sampleMembers) { member ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(member.name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                                        if (member.hasWonChit) {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Surface(
                                                shape = RoundedCornerShape(3.dp),
                                                color = Amber500.copy(alpha = 0.15f)
                                            ) {
                                                Text("Prized", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Amber500, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                            }
                                        }
                                    }
                                    Text("Paid: ${member.paidAmount} of ₹41,250", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }

                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = when (member.status) {
                                        "Paid" -> Emerald500.copy(alpha = 0.15f)
                                        "Partial" -> Amber500.copy(alpha = 0.15f)
                                        else -> Rose500.copy(alpha = 0.15f)
                                    }
                                ) {
                                    Text(
                                        text = member.status,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = when (member.status) {
                                            "Paid" -> Emerald500
                                            "Partial" -> Amber500
                                            else -> Rose500
                                        },
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth().height(40.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                ) {
                    Text("Close", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun MyBidsDialog(
    currentBid: String?,
    bidTime: String?,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("My Bid History", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", modifier = Modifier.size(18.dp))
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

                if (currentBid != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = IndigoPrimary.copy(alpha = 0.12f),
                        border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Chit #09 (Active Round)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                            Text("Submitted Discount: ₹$currentBid", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                            Text("Registered: ${bidTime ?: "Today, 8:12 PM"} • Sealed Bidding", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                // Past bids
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Past Rounds", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    PastBidItem(round = 8, bidAmount = "₹1,65,000", outcome = "Outbid (Winner took ₹1,75,000)")
                    PastBidItem(round = 7, bidAmount = "₹1,50,000", outcome = "Outbid (Winner took ₹1,60,000)")
                    PastBidItem(round = 6, bidAmount = "No Bid Submitted", outcome = "Earned ₹9,500 dividend")
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth().height(40.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                ) {
                    Text("Close", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun PastBidItem(round: Int, bidAmount: String, outcome: String) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Round #0$round: $bidAmount", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                Text(outcome, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun InstallmentPaymentDemoDialog(
    isPaid: Boolean,
    onMarkPaid: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Chit Installment Payment", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", modifier = Modifier.size(18.dp))
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("Installment Breakdown (Chit #09)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Gross Member Due:", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("₹50,000", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Chit #08 Dividend Credit:", fontSize = 11.5.sp, color = Emerald500)
                        Text("-₹8,750", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = Emerald500)
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total Net Payable:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        Text("₹41,250", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                    }
                }

                if (isPaid) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Emerald500.copy(alpha = 0.12f),
                        border = BorderStroke(1.dp, Emerald500.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Emerald500, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Payment receipt #CHIT-09-03 recorded on ledger.", fontSize = 11.5.sp, color = Emerald500, fontWeight = FontWeight.SemiBold)
                        }
                    }
                } else {
                    Button(
                        onClick = onMarkPaid,
                        modifier = Modifier.fillMaxWidth().height(42.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald500)
                    ) {
                        Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Record Demo Payment (₹41,250)", fontWeight = FontWeight.Bold)
                    }
                }

                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth().height(36.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Close", fontSize = 11.5.sp)
                }
            }
        }
    }
}
