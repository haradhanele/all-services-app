package com.adr.groupledger.data.model

import org.json.JSONObject

/**
 * Phase D.0: Chit Fund Auction Call Stages.
 *
 * Supports timed auction calling stages:
 * OPEN -> FIRST_CALL -> SECOND_CALL -> FINAL_CALL -> CLOSED
 */
enum class ChitAuctionCallStage(val displayName: String) {
    OPEN("Auction Open"),
    FIRST_CALL("First Call"),
    SECOND_CALL("Second Call"),
    FINAL_CALL("Final Call"),
    CLOSED("Auction Closed");

    val isBiddingAllowed: Boolean
        get() = this != CLOSED
}

/**
 * Phase D.0: Chit Fund Discount Distribution Rules.
 *
 * Allows group-specific configuration for handling winning bid discount / remaining amount:
 * - Option A: Divide equally among all members.
 * - Option B: Adjust in future cycle/game.
 * - Option C: Foreman commission + surplus dividend.
 * - Option D: Custom group-specific rule.
 */
enum class DiscountDistributionRule(val displayName: String, val description: String) {
    DIVIDE_EQUALLY_ALL_MEMBERS(
        displayName = "Divide Equally Among All Members",
        description = "Entire discount is divided equally among all group members (Option A)"
    ),
    FOREMAN_COMMISSION_AND_DIVIDEND(
        displayName = "Foreman Commission + Member Dividend",
        description = "Foreman takes commission percentage, remaining surplus divided as dividend"
    ),
    FUTURE_CYCLE_ADJUSTMENT(
        displayName = "Future Cycle Adjustment",
        description = "Discount is carried forward and adjusted in upcoming cycle / game (Option B)"
    ),
    CUSTOM_GROUP_RULE(
        displayName = "Custom Group Specific Rule",
        description = "Handled per custom group bylaws and manual adjustment (Option C)"
    )
}

/**
 * Phase D.0: Extensible Group-Specific Chit Fund Auction Rules Configuration.
 */
data class ChitAuctionRules(
    val openingBid: Double = 0.0,
    val minBidIncrement: Double = 500.0,
    val currentCallStage: ChitAuctionCallStage = ChitAuctionCallStage.OPEN,
    val discountDistributionRule: DiscountDistributionRule = DiscountDistributionRule.DIVIDE_EQUALLY_ALL_MEMBERS,
    val auctionDurationMinutes: Int = 60,
    val firstCallSeconds: Int = 120,
    val secondCallSeconds: Int = 60,
    val finalCallSeconds: Int = 30,
    val foremanCommissionPercent: Double = 5.0
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("openingBid", openingBid)
            put("minBidIncrement", minBidIncrement)
            put("currentCallStage", currentCallStage.name)
            put("discountDistributionRule", discountDistributionRule.name)
            put("auctionDurationMinutes", auctionDurationMinutes)
            put("firstCallSeconds", firstCallSeconds)
            put("secondCallSeconds", secondCallSeconds)
            put("finalCallSeconds", finalCallSeconds)
            put("foremanCommissionPercent", foremanCommissionPercent)
        }
    }

    companion object {
        fun fromJson(json: JSONObject?): ChitAuctionRules {
            if (json == null) return ChitAuctionRules()
            return ChitAuctionRules(
                openingBid = json.optDouble("openingBid", 0.0),
                minBidIncrement = json.optDouble("minBidIncrement", 500.0),
                currentCallStage = try {
                    ChitAuctionCallStage.valueOf(json.optString("currentCallStage", ChitAuctionCallStage.OPEN.name))
                } catch (e: Exception) {
                    ChitAuctionCallStage.OPEN
                },
                discountDistributionRule = try {
                    DiscountDistributionRule.valueOf(
                        json.optString("discountDistributionRule", DiscountDistributionRule.DIVIDE_EQUALLY_ALL_MEMBERS.name)
                    )
                } catch (e: Exception) {
                    DiscountDistributionRule.DIVIDE_EQUALLY_ALL_MEMBERS
                },
                auctionDurationMinutes = json.optInt("auctionDurationMinutes", 60),
                firstCallSeconds = json.optInt("firstCallSeconds", 120),
                secondCallSeconds = json.optInt("secondCallSeconds", 60),
                finalCallSeconds = json.optInt("finalCallSeconds", 30),
                foremanCommissionPercent = json.optDouble("foremanCommissionPercent", 5.0)
            )
        }
    }
}

/**
 * Result of bid validation.
 */
data class BidValidationResult(
    val isValid: Boolean,
    val reason: String = "",
    val requiredMinimumNextBid: Double = 0.0
)

/**
 * Result of auction settlement calculation.
 */
data class ChitAuctionSettlement(
    val totalChitValue: Double,
    val winningBidAmount: Double,
    val winnerPrizeAmount: Double,
    val discountAmount: Double,
    val foremanCommission: Double,
    val totalDividendPool: Double,
    val dividendPerMember: Double,
    val netNextInstallment: Double,
    val distributionRule: DiscountDistributionRule
)
