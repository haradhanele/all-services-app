package com.adr.groupledger.ui.home.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adr.groupledger.data.model.HomeModuleConfig
import com.adr.groupledger.ui.components.HomeScreenCarousel
import com.adr.groupledger.ui.home.HomeTemplateContext
import com.adr.groupledger.ui.screens.demo.GroupCategory
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoHeroTrack
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.StatusPaidText
import com.adr.groupledger.ui.theme.StatusPartialText
import com.adr.groupledger.ui.theme.StatusUnpaidText
import com.adr.groupledger.utils.CurrencyFormatter
import com.adr.groupledger.utils.DateUtils

/**
 * Reusable backend-driven Dynamic Home Screen Carousel / Announcements.
 * Placed below primary group summary & asset cards and above recent activity/timeline cards.
 */
@Composable
fun HomeAnnouncementsCarousel(
    context: HomeTemplateContext,
    modifier: Modifier = Modifier
) {
    if (context.activeCarouselItems.isNotEmpty()) {
        HomeScreenCarousel(
            items = context.activeCarouselItems,
            modifier = modifier,
            onNavigateToRoute = { route ->
                when (route.lowercase()) {
                    "members" -> context.onNavigateToMembers()
                    "monthly" -> context.onNavigateToMonthly()
                    "dues" -> context.onNavigateToDues()
                    "reports" -> context.onNavigateToReports()
                    "record_payment", "record_payment/0" -> context.onNavigateToRecordPayment()
                    "loans" -> context.onNavigateToLoans()
                    "investments" -> context.onNavigateToInvestments()
                    "feedback" -> context.onNavigateToFeedback()
                    "ledger" -> context.onNavigateToLedger()
                    "inbox" -> context.onNavigateToInbox()
                }
            },
            onNavigateToScreen = { screen ->
                when (screen.lowercase()) {
                    "members" -> context.onNavigateToMembers()
                    "monthly" -> context.onNavigateToMonthly()
                    "dues" -> context.onNavigateToDues()
                    "reports" -> context.onNavigateToReports()
                    "record_payment", "payment" -> context.onNavigateToRecordPayment()
                    "loans", "loan" -> context.onNavigateToLoans()
                    "investments", "investment" -> context.onNavigateToInvestments()
                    "feedback", "suggestions", "complaints", "proposals" -> context.onNavigateToFeedback()
                    "ledger" -> context.onNavigateToLedger()
                    "inbox" -> context.onNavigateToInbox()
                }
            }
        )
    }
}

/**
 * Modular Services & Actions Carousel.
 */
@Composable
fun HomeActionCarouselCard(
    context: HomeTemplateContext,
    title: String = "Services & Actions",
    subtitle: String = "Tap to manage or record",
    allowedKeys: List<String>? = null
) {
    val enabledModules = remember(context.homeModules, allowedKeys) {
        val filtered = if (allowedKeys != null) {
            context.homeModules.filter { it.isEnabled && allowedKeys.contains(it.key) }
        } else {
            context.homeModules.filter { it.isEnabled }
        }
        filtered.sortedBy { it.orderIndex }
    }

    if (enabledModules.isEmpty()) return

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("home_services_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 14.sp
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(enabledModules, key = { it.key }) { module ->
                    val icon = getModuleIcon(module.iconName)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .width(66.dp)
                            .clickable {
                                handleModuleNavigation(module.key, context)
                            }
                            .testTag("action_module_${module.key}")
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = IndigoPrimary.copy(alpha = 0.10f),
                            modifier = Modifier.size(46.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = module.getDisplayName(),
                                    tint = IndigoPrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(5.dp))
                        Text(
                            text = module.getDisplayName(),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 10.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

/**
 * Reusable Collection Progress Card (Paid, Partial, Pending breakdown).
 */
@Composable
fun HomeCollectionProgressCard(
    context: HomeTemplateContext,
    title: String = "Monthly Collection",
    expectedAmountLabel: String = "Expected",
    collectedAmountLabel: String = "Collected"
) {
    val monthSummary = context.monthSummary
    val settings = context.settings
    val curr = settings.currencySymbol

    val totalExpected = monthSummary?.totalExpected ?: 0.0
    val totalCollected = monthSummary?.totalCollected ?: 0.0
    val progress = if (totalExpected > 0) (totalCollected / totalExpected).toFloat().coerceIn(0f, 1f) else 0f

    val paidCount = monthSummary?.paidCount ?: 0
    val partialCount = monthSummary?.partialCount ?: 0
    val unpaidCount = monthSummary?.unpaidCount ?: 0

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { context.onNavigateToMonthly() }
            .testTag("home_collection_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(
                        imageVector = Icons.Default.Payments,
                        contentDescription = null,
                        tint = IndigoPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 14.sp
                    )
                }
                Text(
                    text = "${(progress * 100).toInt()}% Done",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Emerald500,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(7.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = Emerald500,
                trackColor = IndigoHeroTrack
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = expectedAmountLabel.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 9.sp
                    )
                    Text(
                        text = "$curr${CurrencyFormatter.formatIndian(totalExpected)}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 13.sp
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = collectedAmountLabel.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 9.sp
                    )
                    Text(
                        text = "$curr${CurrencyFormatter.formatIndian(totalCollected)}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = Emerald500,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Paid / Partial / Pending Breakdown Pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = StatusPaidText.copy(alpha = 0.10f),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$paidCount Paid",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = StatusPaidText
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = StatusPartialText.copy(alpha = 0.10f),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$partialCount Partial",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = StatusPartialText
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = StatusUnpaidText.copy(alpha = 0.10f),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$unpaidCount Pending",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = StatusUnpaidText
                        )
                    }
                }
            }
        }
    }
}

/**
 * Reusable Group Asset Portfolio card matching the baseline Community Fund layout.
 */
@Composable
fun HomeAssetPortfolioCard(
    context: HomeTemplateContext,
    title: String = "Group Asset Portfolio"
) {
    val financials = context.financials
    val curr = context.settings.currencySymbol

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("home_asset_portfolio_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 14.sp
                )
                Text(
                    text = "$curr${CurrencyFormatter.formatIndian(financials.totalGroupAssets)}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = IndigoPrimary,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Fixed Deposit / Investments
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Icon(
                            imageVector = Icons.Default.TrendingUp,
                            contentDescription = null,
                            tint = Emerald500,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Investments",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "$curr${CurrencyFormatter.formatIndian(financials.totalInvestmentsValue)}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                // In-Hand Cash
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Icon(
                            imageVector = Icons.Default.AccountBalance,
                            contentDescription = null,
                            tint = IndigoPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Cash in Hand",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "$curr${CurrencyFormatter.formatIndian(financials.cashBalance)}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                // Bank Account
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Icon(
                            imageVector = Icons.Default.Savings,
                            contentDescription = null,
                            tint = Amber500,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Bank Deposit",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "$curr${CurrencyFormatter.formatIndian(financials.bankBalance)}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

/**
 * Reusable Activity / Transactions Timeline Card.
 */
@Composable
fun HomeActivityTimelineCard(
    context: HomeTemplateContext,
    title: String = "Recent Transactions"
) {
    val txns = context.recentTxns.take(4)
    val curr = context.settings.currencySymbol

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("home_recent_txns_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 14.sp
                )
                Text(
                    text = "View All",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = IndigoPrimary,
                    fontSize = 11.5.sp,
                    modifier = Modifier.clickable { context.onNavigateToLedger() }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (txns.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No recent transactions recorded",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp
                    )
                }
            } else {
                txns.forEachIndexed { index, txn ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = if (txn.isCredit) Emerald500.copy(alpha = 0.15f) else Rose500.copy(alpha = 0.15f),
                                modifier = Modifier.size(30.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (txn.isCredit) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                        contentDescription = null,
                                        tint = if (txn.isCredit) Emerald500 else Rose500,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }
                            Column {
                                Text(
                                    text = txn.description.ifBlank { "Transaction" },
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = "${DateUtils.formatDate(txn.date)} • ${txn.paymentMethod}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Text(
                            text = "${if (txn.isCredit) "+" else "-"}$curr${CurrencyFormatter.formatIndian(txn.amount)}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (txn.isCredit) Emerald500 else Rose500,
                            fontSize = 12.5.sp
                        )
                    }

                    if (index < txns.size - 1) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(0.5.dp)
                                .background(MaterialTheme.colorScheme.outlineVariant)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Dialog to select and switch group category and sub-category on the fly.
 */
@Composable
fun CategoryChangeDialog(
    currentCategory: GroupCategory,
    currentSubCategory: String,
    onDismiss: () -> Unit,
    onConfirm: (GroupCategory, String) -> Unit
) {
    var selectedCat by remember { mutableStateOf(currentCategory) }
    var selectedSub by remember {
        mutableStateOf(
            if (currentCategory.subCategories.contains(currentSubCategory)) currentSubCategory
            else currentCategory.subCategories.firstOrNull() ?: "General"
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(
                    text = "Group Category & Type",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Choose your group type to adapt the Home Page layout",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp
                )
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Text(
                        text = "SELECT CATEGORY",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        fontSize = 10.sp,
                        letterSpacing = 0.5.sp
                    )
                }

                items(GroupCategory.entries) { cat ->
                    val isSelected = cat == selectedCat
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) IndigoPrimary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceContainerLow,
                        border = BorderStroke(1.dp, if (isSelected) IndigoPrimary else MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedCat = cat
                                selectedSub = cat.subCategories.firstOrNull() ?: "General"
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = cat.icon,
                                contentDescription = null,
                                tint = if (isSelected) IndigoPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = cat.title,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 12.5.sp,
                                    color = if (isSelected) IndigoPrimary else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = cat.description,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = IndigoPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "SELECT SUB-CATEGORY (${selectedCat.title.uppercase()})",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        fontSize = 10.sp,
                        letterSpacing = 0.5.sp
                    )
                }

                items(selectedCat.subCategories) { sub ->
                    val isSelected = sub == selectedSub
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) Emerald500.copy(alpha = 0.10f) else Color.Transparent,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedSub = sub }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { selectedSub = sub },
                                colors = RadioButtonDefaults.colors(selectedColor = IndigoPrimary),
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = sub,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(selectedCat, selectedSub) }
            ) {
                Text("Apply Layout", fontWeight = FontWeight.Bold, color = IndigoPrimary)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    )
}

internal fun handleModuleNavigation(moduleKey: String, context: HomeTemplateContext) {
    when (moduleKey) {
        "contribution" -> context.onNavigateToRecordPayment()
        "members" -> context.onNavigateToMembers()
        "expenses", "income" -> context.onNavigateToLedger()
        "meeting", "chat" -> context.onNavigateToInbox()
        "notice" -> context.onNavigateToInbox()
        "suggestion", "complaint", "feedback" -> context.onNavigateToFeedback()
        "events" -> context.onNavigateToMonthly()
        "investment" -> context.onNavigateToInvestments()
        "loan" -> context.onNavigateToLoans()
        "savings" -> context.onNavigateToMonthly()
        "reports" -> context.onNavigateToReports()
        else -> context.onNavigateToMonthly()
    }
}

internal fun getModuleIcon(iconName: String): ImageVector {
    return when (iconName.lowercase()) {
        "payments" -> Icons.Default.Payments
        "group" -> Icons.Default.Group
        "receipt_long" -> Icons.Default.ReceiptLong
        "account_balance" -> Icons.Default.AccountBalance
        "chat" -> Icons.Default.Feedback
        "campaign" -> Icons.Default.Campaign
        "lightbulb" -> Icons.Default.Lightbulb
        "report_problem" -> Icons.Default.ReportProblem
        "help" -> Icons.Default.Help
        "event" -> Icons.Default.Event
        "trending_up" -> Icons.Default.TrendingUp
        "handshake" -> Icons.Default.Handshake
        "savings" -> Icons.Default.Savings
        "check_circle" -> Icons.Default.CheckCircle
        "assignment" -> Icons.Default.Assignment
        "pie_chart" -> Icons.Default.PieChart
        else -> Icons.Default.Payments
    }
}
