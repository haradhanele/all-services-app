package com.adr.groupledger.data.model

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Status of an individual bid submitted during a Chit Fund auction.
 */
enum class ChitBidStatus(val displayName: String) {
    SUBMITTED("Submitted"),
    VALID("Valid"),
    INVALID("Invalid"),
    WITHDRAWN("Withdrawn"),
    REJECTED("Rejected");

    companion object {
        fun fromString(value: String?): ChitBidStatus {
            if (value.isNullOrBlank()) return SUBMITTED
            return entries.find { it.name.equals(value.trim(), ignoreCase = true) } ?: SUBMITTED
        }
    }
}

/**
 * Represents a single bid entry placed in a Chit Fund cycle auction.
 *
 * In the Indian Chit Fund (Act 1982) model used in this application,
 * [bidAmount] represents the DISCOUNT AMOUNT the member offers to forgo
 * from the total scheme pot in order to receive the prize pool immediately.
 * The highest valid discount bid wins the auction.
 */
data class ChitBid(
    val bidId: String = UUID.randomUUID().toString(),
    val auctionId: String = "",
    val groupId: Long = 1,
    val cycleNumber: Int = 1,
    val memberId: Long,
    val memberName: String = "",
    val bidAmount: Double, // Discount amount offered
    val submittedAtMillis: Long = System.currentTimeMillis(),
    val status: ChitBidStatus = ChitBidStatus.VALID,
    val rejectionReason: String? = null
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("bidId", bidId)
            put("auctionId", auctionId)
            put("groupId", groupId)
            put("cycleNumber", cycleNumber)
            put("memberId", memberId)
            put("memberName", memberName)
            put("bidAmount", bidAmount)
            put("submittedAtMillis", submittedAtMillis)
            put("status", status.name)
            rejectionReason?.let { put("rejectionReason", it) }
        }
    }

    companion object {
        fun fromJson(json: JSONObject): ChitBid {
            return ChitBid(
                bidId = json.optString("bidId", UUID.randomUUID().toString()),
                auctionId = json.optString("auctionId", ""),
                groupId = json.optLong("groupId", 1L),
                cycleNumber = json.optInt("cycleNumber", 1),
                memberId = json.optLong("memberId", 0L),
                memberName = json.optString("memberName", "Member"),
                bidAmount = json.optDouble("bidAmount", 0.0),
                submittedAtMillis = json.optLong("submittedAtMillis", System.currentTimeMillis()),
                status = ChitBidStatus.fromString(json.optString("status")),
                rejectionReason = if (json.has("rejectionReason")) json.optString("rejectionReason") else null
            )
        }

        fun parseArray(jsonArray: JSONArray?): List<ChitBid> {
            if (jsonArray == null) return emptyList()
            val list = mutableListOf<ChitBid>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.optJSONObject(i) ?: continue
                list.add(fromJson(obj))
            }
            return list
        }

        fun serializeList(bids: List<ChitBid>): JSONArray {
            val array = JSONArray()
            bids.forEach { array.put(it.toJson()) }
            return array
        }
    }
}

/**
 * Complete snapshot of a Chit Fund Auction session for a specific cycle.
 */
data class ChitAuction(
    val auctionId: String,
    val groupId: Long = 1,
    val cycleNumber: Int,
    val startEpochMillis: Long,
    val endEpochMillis: Long,
    val status: ChitCycleStatus,
    val totalSchemePot: Double,
    val minDiscountAmount: Double,
    val maxDiscountAmount: Double,
    val foremanCommissionPercent: Double = 5.0,
    val bids: List<ChitBid> = emptyList(),
    val highestBid: ChitBid? = null,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val updatedAtMillis: Long = System.currentTimeMillis()
)

/**
 * Result of checking a member's eligibility to participate in a Chit auction.
 */
data class ChitMemberEligibility(
    val memberId: Long,
    val memberName: String,
    val isEligible: Boolean,
    val reason: String,
    val hasWonPriorRound: Boolean = false,
    val priorWonRoundNumber: Int? = null,
    val hasPendingDues: Boolean = false,
    val pendingDuesAmount: Double = 0.0
)

/**
 * Estimated financial outcome of an auction based on current highest discount bid.
 */
data class EstimatedAuctionOutcome(
    val totalPot: Double,
    val winningDiscountBid: Double,
    val prizePayoutAmount: Double,
    val foremanCommission: Double,
    val surplusDividendPool: Double,
    val dividendPerMember: Double,
    val netNextInstallment: Double
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("totalPot", totalPot)
            put("winningDiscountBid", winningDiscountBid)
            put("prizePayoutAmount", prizePayoutAmount)
            put("foremanCommission", foremanCommission)
            put("surplusDividendPool", surplusDividendPool)
            put("dividendPerMember", dividendPerMember)
            put("netNextInstallment", netNextInstallment)
        }
    }

    companion object {
        fun fromJson(json: JSONObject?): EstimatedAuctionOutcome? {
            if (json == null) return null
            return EstimatedAuctionOutcome(
                totalPot = json.optDouble("totalPot", 0.0),
                winningDiscountBid = json.optDouble("winningDiscountBid", 0.0),
                prizePayoutAmount = json.optDouble("prizePayoutAmount", 0.0),
                foremanCommission = json.optDouble("foremanCommission", 0.0),
                surplusDividendPool = json.optDouble("surplusDividendPool", 0.0),
                dividendPerMember = json.optDouble("dividendPerMember", 0.0),
                netNextInstallment = json.optDouble("netNextInstallment", 0.0)
            )
        }
    }
}

/**
 * Status states for Chit Fund Auction Result, Winner Determination, and Review.
 * Enforces Phase B.4 lifecycle:
 * RESULT_PENDING -> RESULT_CALCULATED / TIE_REQUIRES_ADMIN_REVIEW / RESULT_REQUIRES_RULE
 * -> RESULT_APPROVED / RESULT_REJECTED -> SETTLEMENT_PENDING.
 * Strictly NEVER transitions to SETTLED in this review phase.
 */
enum class ChitAuctionResultStatus(val displayName: String) {
    RESULT_PENDING("Result Pending"),
    RESULT_CALCULATED("Result Ready for Review"),
    TIE_REQUIRES_ADMIN_REVIEW("Tie Detected - Admin Review Required"),
    RESULT_REQUIRES_RULE("Configuration Rule Missing"),
    NO_VALID_BIDS("No Valid Bids Submitted"),
    RESULT_APPROVED("Result Approved"),
    RESULT_REJECTED("Result Rejected"),
    SETTLEMENT_PENDING("Settlement Pending"),
    SETTLEMENT_PROCESSING("Settlement Processing"),
    SETTLED("Settled"),
    SETTLEMENT_FAILED("Settlement Failed");

    companion object {
        fun fromString(value: String?): ChitAuctionResultStatus {
            if (value.isNullOrBlank()) return RESULT_PENDING
            val normalized = value.trim().uppercase(java.util.Locale.US)
            return entries.find { it.name == normalized }
                ?: when (normalized) {
                    "PENDING", "PROCESSING" -> RESULT_PENDING
                    "CALCULATED", "READY" -> RESULT_CALCULATED
                    "TIE", "TIE_REVIEW" -> TIE_REQUIRES_ADMIN_REVIEW
                    "RULE_REQUIRED", "MISSING_RULE" -> RESULT_REQUIRES_RULE
                    "NO_BIDS" -> NO_VALID_BIDS
                    "APPROVED", "ACCEPTED" -> RESULT_APPROVED
                    "REJECTED", "DECLINED" -> RESULT_REJECTED
                    "SETTLEMENT_PENDING", "AWAITING_SETTLEMENT" -> SETTLEMENT_PENDING
                    "SETTLING", "SETTLEMENT_PROCESSING" -> SETTLEMENT_PROCESSING
                    "SETTLED", "COMPLETED", "CLOSED" -> SETTLED
                    "SETTLEMENT_FAILED", "FAILED" -> SETTLEMENT_FAILED
                    else -> RESULT_PENDING
                }
        }
    }
}

/**
 * Foundation events emitted during Chit Fund auction result evaluation and settlement.
 * Used for future notification triggers and audit logging.
 */
enum class ChitAuctionEvent {
    RESULT_CALCULATED,
    TIE_DETECTED,
    RESULT_APPROVED,
    RESULT_REJECTED,
    WINNER_DECLARED,
    SETTLEMENT_PREVIEW_READY,
    SETTLEMENT_PROCESSING,
    AUCTION_SETTLED,
    SETTLEMENT_FAILED
}

/**
 * Authoritative Phase B.4 & B.5 Auction Result Model.
 * Preserves audit result data, review status, and financial settlement ledger references.
 */
data class ChitAuctionResult(
    val resultId: String = UUID.randomUUID().toString(),
    val auctionId: String = "",
    val groupId: Long = 1L,
    val cycleNumber: Int = 1,
    val winningMemberId: Long? = null,
    val winningBidId: String? = null,
    val winningBidAmount: Double? = null,
    val winningMemberName: String? = null,
    val resultStatus: ChitAuctionResultStatus = ChitAuctionResultStatus.RESULT_PENDING,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val reviewedAtMillis: Long? = null,
    val reviewedByMemberId: Long? = null,
    val reviewedByMemberName: String? = null,
    val rejectionReason: String? = null,
    val adminReviewNotes: String? = null,
    val isTie: Boolean = false,
    val tiedMemberIds: List<Long> = emptyList(),
    val tiedMemberNames: List<String> = emptyList(),
    val totalBidsCount: Int = 0,
    val validBidsCount: Int = 0,
    val ruleUsed: String = "HIGHEST_DISCOUNT",
    val ruleMissingReason: String? = null,
    val estimatedOutcome: EstimatedAuctionOutcome? = null,
    val settledAtMillis: Long? = null,
    val settledByMemberId: Long? = null,
    val settledByMemberName: String? = null,
    val settlementPayoutTxnId: String? = null,
    val settlementCommissionTxnId: String? = null,
    val settlementNotes: String? = null
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("resultId", resultId)
            put("auctionId", auctionId)
            put("groupId", groupId)
            put("cycleNumber", cycleNumber)
            winningMemberId?.let { put("winningMemberId", it) }
            winningBidId?.let { put("winningBidId", it) }
            winningBidAmount?.let { put("winningBidAmount", it) }
            winningMemberName?.let { put("winningMemberName", it) }
            put("resultStatus", resultStatus.name)
            put("createdAtMillis", createdAtMillis)
            reviewedAtMillis?.let { put("reviewedAtMillis", it) }
            reviewedByMemberId?.let { put("reviewedByMemberId", it) }
            reviewedByMemberName?.let { put("reviewedByMemberName", it) }
            rejectionReason?.let { put("rejectionReason", it) }
            adminReviewNotes?.let { put("adminReviewNotes", it) }
            put("isTie", isTie)
            if (tiedMemberIds.isNotEmpty()) {
                val arr = JSONArray()
                tiedMemberIds.forEach { arr.put(it) }
                put("tiedMemberIds", arr)
            }
            if (tiedMemberNames.isNotEmpty()) {
                val arr = JSONArray()
                tiedMemberNames.forEach { arr.put(it) }
                put("tiedMemberNames", arr)
            }
            put("totalBidsCount", totalBidsCount)
            put("validBidsCount", validBidsCount)
            put("ruleUsed", ruleUsed)
            ruleMissingReason?.let { put("ruleMissingReason", it) }
            estimatedOutcome?.let { put("estimatedOutcome", it.toJson()) }
            settledAtMillis?.let { put("settledAtMillis", it) }
            settledByMemberId?.let { put("settledByMemberId", it) }
            settledByMemberName?.let { put("settledByMemberName", it) }
            settlementPayoutTxnId?.let { put("settlementPayoutTxnId", it) }
            settlementCommissionTxnId?.let { put("settlementCommissionTxnId", it) }
            settlementNotes?.let { put("settlementNotes", it) }
        }
    }

    companion object {
        fun fromJson(json: JSONObject): ChitAuctionResult {
            val tiedIds = mutableListOf<Long>()
            val idsArr = json.optJSONArray("tiedMemberIds")
            if (idsArr != null) {
                for (i in 0 until idsArr.length()) {
                    tiedIds.add(idsArr.optLong(i))
                }
            }

            val tiedNames = mutableListOf<String>()
            val namesArr = json.optJSONArray("tiedMemberNames")
            if (namesArr != null) {
                for (i in 0 until namesArr.length()) {
                    tiedNames.add(namesArr.optString(i))
                }
            }

            return ChitAuctionResult(
                resultId = json.optString("resultId", UUID.randomUUID().toString()),
                auctionId = json.optString("auctionId", ""),
                groupId = json.optLong("groupId", 1L),
                cycleNumber = json.optInt("cycleNumber", 1),
                winningMemberId = if (json.has("winningMemberId")) json.optLong("winningMemberId") else null,
                winningBidId = if (json.has("winningBidId")) json.optString("winningBidId") else null,
                winningBidAmount = if (json.has("winningBidAmount")) json.optDouble("winningBidAmount") else null,
                winningMemberName = if (json.has("winningMemberName")) json.optString("winningMemberName") else null,
                resultStatus = ChitAuctionResultStatus.fromString(json.optString("resultStatus")),
                createdAtMillis = json.optLong("createdAtMillis", System.currentTimeMillis()),
                reviewedAtMillis = if (json.has("reviewedAtMillis")) json.optLong("reviewedAtMillis") else null,
                reviewedByMemberId = if (json.has("reviewedByMemberId")) json.optLong("reviewedByMemberId") else null,
                reviewedByMemberName = if (json.has("reviewedByMemberName")) json.optString("reviewedByMemberName") else null,
                rejectionReason = if (json.has("rejectionReason")) json.optString("rejectionReason") else null,
                adminReviewNotes = if (json.has("adminReviewNotes")) json.optString("adminReviewNotes") else null,
                isTie = json.optBoolean("isTie", false),
                tiedMemberIds = tiedIds,
                tiedMemberNames = tiedNames,
                totalBidsCount = json.optInt("totalBidsCount", 0),
                validBidsCount = json.optInt("validBidsCount", 0),
                ruleUsed = json.optString("ruleUsed", "HIGHEST_DISCOUNT"),
                ruleMissingReason = if (json.has("ruleMissingReason")) json.optString("ruleMissingReason") else null,
                estimatedOutcome = EstimatedAuctionOutcome.fromJson(json.optJSONObject("estimatedOutcome")),
                settledAtMillis = if (json.has("settledAtMillis")) json.optLong("settledAtMillis") else null,
                settledByMemberId = if (json.has("settledByMemberId")) json.optLong("settledByMemberId") else null,
                settledByMemberName = if (json.has("settledByMemberName")) json.optString("settledByMemberName") else null,
                settlementPayoutTxnId = if (json.has("settlementPayoutTxnId")) json.optString("settlementPayoutTxnId") else null,
                settlementCommissionTxnId = if (json.has("settlementCommissionTxnId")) json.optString("settlementCommissionTxnId") else null,
                settlementNotes = if (json.has("settlementNotes")) json.optString("settlementNotes") else null
            )
        }
    }
}

/**
 * Backward compatibility container for result preparation.
 */
data class ChitAuctionResultPreparation(
    val auctionId: String,
    val groupId: Long = 1,
    val cycleNumber: Int,
    val totalBidsCount: Int = 0,
    val validBidsCount: Int = 0,
    val highestBidAmount: Double? = null,
    val candidateWinnerMemberId: Long? = null,
    val candidateWinnerMemberName: String? = null,
    val isTie: Boolean = false,
    val tiedMemberNames: List<String> = emptyList(),
    val tieResolutionMethod: String = "HIGHEST_DISCOUNT",
    val estimatedOutcome: EstimatedAuctionOutcome? = null,
    val preparedAtMillis: Long = System.currentTimeMillis(),
    val status: String = "RESULT_PENDING"
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("auctionId", auctionId)
            put("groupId", groupId)
            put("cycleNumber", cycleNumber)
            put("totalBidsCount", totalBidsCount)
            put("validBidsCount", validBidsCount)
            highestBidAmount?.let { put("highestBidAmount", it) }
            candidateWinnerMemberId?.let { put("candidateWinnerMemberId", it) }
            candidateWinnerMemberName?.let { put("candidateWinnerMemberName", it) }
            put("isTie", isTie)
            if (tiedMemberNames.isNotEmpty()) {
                val arr = JSONArray()
                tiedMemberNames.forEach { arr.put(it) }
                put("tiedMemberNames", arr)
            }
            put("tieResolutionMethod", tieResolutionMethod)
            put("preparedAtMillis", preparedAtMillis)
            put("status", status)
        }
    }
}

