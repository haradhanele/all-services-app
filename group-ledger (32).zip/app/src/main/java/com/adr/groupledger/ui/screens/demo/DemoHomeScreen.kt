package com.adr.groupledger.ui.screens.demo

import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.Diversity1
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.FamilyRestroom
import androidx.compose.material.icons.filled.Festival
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoHeroDark
import com.adr.groupledger.ui.theme.IndigoHeroSurface
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500

/**
 * Category-aware Home Page (Demo) preview.
 * Adapts its terminology, key metrics, status indicators, quick action cards,
 * and activity feeds dynamically based on the selected group category.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DemoHomeScreen(
    initialCategory: GroupCategory = GroupCategory.SAVINGS_CREDIT_CHIT,
    initialSubCategory: String = "Chit Fund / BC",
    initialGroupName: String = "Shakti Chit Fund",
    onNavigateBack: () -> Unit = {},
    onNavigateToSetup: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedCategory by remember { mutableStateOf(initialCategory) }
    var selectedSubCategory by remember { mutableStateOf(initialSubCategory) }
    var groupName by remember { mutableStateOf(initialGroupName) }

    // Special sub-toggle for Savings vs Chit Fund, or Trip vs Mess
    var chitFundMode by remember {
        mutableStateOf(
            selectedSubCategory.contains("Chit", ignoreCase = true) ||
            selectedSubCategory.contains("BC", ignoreCase = true) ||
            selectedSubCategory.contains("Rotating", ignoreCase = true)
        )
    }
    var messMode by remember { mutableStateOf(selectedSubCategory.contains("Mess", ignoreCase = true)) }

    // Interactive action dialog state
    var activeActionDialog by remember { mutableStateOf<DemoActionDialogState?>(null) }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
            ) {
                // Header Bar
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = onNavigateBack,
                                modifier = Modifier.size(36.dp).testTag("demo_home_back_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back",
                                    tint = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "Home Page",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        fontSize = 15.sp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Amber500.copy(alpha = 0.18f),
                                        border = BorderStroke(0.5.dp, Amber500.copy(alpha = 0.4f))
                                    ) {
                                        Text(
                                            text = "LIVE PREVIEW",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Amber500,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "Category-Aware Dashboard",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 10.5.sp
                                )
                            }
                        }

                        // Edit Setup shortcut button
                        OutlinedButton(
                            onClick = onNavigateToSetup,
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("demo_home_edit_setup_btn"),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.5f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = null,
                                tint = IndigoPrimary,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Edit Setup",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = IndigoPrimary
                            )
                        }
                    }
                }

                // Interactive Category Switcher (Scrollable Chip Bar)
                CategorySwitcherBar(
                    selectedCategory = selectedCategory,
                    onSelectCategory = { cat ->
                        selectedCategory = cat
                        selectedSubCategory = if (cat == GroupCategory.SAVINGS_CREDIT_CHIT) {
                            "Chit Fund / BC"
                        } else {
                            cat.subCategories.firstOrNull() ?: "General"
                        }
                        chitFundMode = selectedSubCategory.contains("Chit", ignoreCase = true) ||
                                selectedSubCategory.contains("BC", ignoreCase = true) ||
                                selectedSubCategory.contains("Rotating", ignoreCase = true)
                        messMode = selectedSubCategory.contains("Mess", ignoreCase = true)
                        groupName = getSampleGroupNameForCategory(cat)
                    }
                )
            }
        },
        bottomBar = {
            DemoBottomNavBar(
                selectedItem = "home",
                onItemClick = { itemKey ->
                    if (itemKey != "home") {
                        Toast.makeText(context, "$itemKey tab (Demo View)", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (selectedCategory == GroupCategory.SAVINGS_CREDIT_CHIT && chitFundMode) {
                // Sub-category model toggle bar for Savings vs Chit Fund
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Sub-Category:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = IndigoPrimary.copy(alpha = 0.18f),
                                border = BorderStroke(1.dp, IndigoPrimary)
                            ) {
                                Text(
                                    text = "Chit Fund / BC (Active)",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = IndigoPrimary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                        TextButton(
                            onClick = {
                                selectedSubCategory = "Self-Help Group (SHG)"
                                chitFundMode = false
                                groupName = "Mahila Kalyan SHG & Savings Group"
                            },
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("Switch to SHG", fontSize = 11.sp, color = IndigoPrimary, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                // 11-Section Dedicated Chit Fund Dashboard
                ChitFundDashboardContent(
                    groupName = groupName,
                    onEditSetupClick = onNavigateToSetup
                )
            } else {
                // 1. Group Identity & Category Hero Banner
                DemoGroupHeroCard(
                    groupName = groupName,
                    category = selectedCategory,
                    subCategory = selectedSubCategory,
                    onSubCategoryChange = { sub ->
                        selectedSubCategory = sub
                        chitFundMode = sub.contains("Chit", ignoreCase = true) ||
                                sub.contains("BC", ignoreCase = true) ||
                                sub.contains("Rotating", ignoreCase = true)
                        messMode = sub.contains("Mess", ignoreCase = true)
                        if (chitFundMode) {
                            groupName = "Shakti Chit Fund"
                        }
                    }
                )

                // 2. Category-Aware Core Financial & Status Metrics
                AnimatedContent(
                    targetState = Pair(selectedCategory, if (selectedCategory == GroupCategory.SAVINGS_CREDIT_CHIT) chitFundMode else messMode),
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "category_metrics"
                ) { (cat, subMode) ->
                    when (cat) {
                        GroupCategory.COMMUNITY_FUND -> CommunityFundMetricsCard(onAction = { activeActionDialog = it })
                        GroupCategory.PUJA_FESTIVAL -> PujaFestivalMetricsCard(onAction = { activeActionDialog = it })
                        GroupCategory.SPORTS_CULTURAL -> SportsClubMetricsCard(onAction = { activeActionDialog = it })
                        GroupCategory.SAVINGS_CREDIT_CHIT -> {
                            if (subMode) {
                                ChitFundMetricsCard(onAction = { activeActionDialog = it })
                            } else {
                                SavingsShgMetricsCard(onAction = { activeActionDialog = it })
                            }
                        }
                        GroupCategory.EVENTS_TRIPS -> {
                            if (subMode) {
                                MessPoolMetricsCard(onAction = { activeActionDialog = it })
                            } else {
                                TripEventsMetricsCard(onAction = { activeActionDialog = it })
                            }
                        }
                        GroupCategory.FAMILY_FRIENDS -> FamilyFriendsMetricsCard(onAction = { activeActionDialog = it })
                        GroupCategory.WELFARE_NGO -> WelfareNgoMetricsCard(onAction = { activeActionDialog = it })
                        GroupCategory.HOUSING_APARTMENT -> HousingSocietyMetricsCard(onAction = { activeActionDialog = it })
                        GroupCategory.BUSINESS_PARTNERSHIP -> BusinessPartnershipMetricsCard(onAction = { activeActionDialog = it })
                        GroupCategory.OTHER_GROUPS -> OtherGroupMetricsCard(onAction = { activeActionDialog = it })
                    }
                }

                // 3. Category-Aware Quick Actions Grid
                DemoQuickActionsSection(
                    category = selectedCategory,
                    isChitMode = chitFundMode,
                    isMessMode = messMode,
                    onActionClick = { actionType ->
                        activeActionDialog = DemoActionDialogState(
                            title = actionType.title,
                            category = selectedCategory,
                            description = actionType.description,
                            primaryFieldLabel = actionType.fieldLabel,
                            defaultAmount = actionType.defaultAmount
                        )
                    }
                )

                // 4. Category-Aware Notice / Highlights Card
                DemoCategoryNoticeCard(
                    category = selectedCategory,
                    isChitMode = chitFundMode
                )

                // 5. Category-Aware Activity Feed & Recent Transactions
                DemoCategoryActivityFeed(
                    category = selectedCategory,
                    isChitMode = chitFundMode,
                    isMessMode = messMode
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // Interactive Action Dialog
    activeActionDialog?.let { dialogState ->
        DemoActionInteractiveDialog(
            dialogState = dialogState,
            onDismiss = { activeActionDialog = null },
            onSubmit = { amount, note ->
                activeActionDialog = null
                Toast.makeText(
                    context,
                    "${dialogState.title}: Recorded successfully (Demo)",
                    Toast.LENGTH_SHORT
                ).show()
            }
        )
    }
}

/**
 * Scrollable Category Switcher Bar for effortless switching between all 10 group models.
 */
@Composable
private fun CategorySwitcherBar(
    selectedCategory: GroupCategory,
    onSelectCategory: (GroupCategory) -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Category:",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 4.dp, end = 2.dp)
            )

            GroupCategory.entries.forEach { category ->
                val isSelected = category == selectedCategory
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isSelected) IndigoPrimary else MaterialTheme.colorScheme.surface,
                    border = BorderStroke(
                        1.dp,
                        if (isSelected) IndigoPrimary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .clickable { onSelectCategory(category) }
                        .testTag("demo_cat_chip_${category.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = category.icon,
                            contentDescription = null,
                            tint = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = category.title,
                            fontSize = 11.5.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

/**
 * Hero Banner displaying group profile, active category, and sub-category selector.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DemoGroupHeroCard(
    groupName: String,
    category: GroupCategory,
    subCategory: String,
    onSubCategoryChange: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("demo_society_header_banner"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = IndigoHeroDark),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF1E1B4B),
                            Color(0xFF312E81),
                            Color(0xFF3730A3)
                        )
                    )
                )
                .padding(14.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Top row: Avatar icon, Group Name, Subtitle & Admin Pill
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.15f),
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = category.icon,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        Column {
                            Text(
                                text = groupName,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = subCategory,
                                fontSize = 11.sp,
                                color = Color(0xFFC7D2FE)
                            )
                        }
                    }

                    // Admin Active Pill
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White.copy(alpha = 0.12f),
                        border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.25f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(Emerald500)
                            )
                            Text(
                                text = getSampleMemberCount(category),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                        }
                    }
                }

                // Financial Overview row
                val financials = getCategoryHeroFinancials(category, subCategory)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(
                            text = financials.primaryLabel.uppercase(),
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFA5B4FC),
                            letterSpacing = 0.6.sp
                        )
                        Text(
                            text = financials.primaryVal,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = financials.secLabel.uppercase(),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFA5B4FC)
                        )
                        Text(
                            text = financials.secVal,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (financials.secLabel.contains("Due", true) || financials.secLabel.contains("Pending", true)) Color(0xFFFCA5A5) else Color(0xFFA7F3D0)
                        )
                    }
                }

                // 3 Sub-metrics Surface
                val subMetrics = getCategoryHeroSubMetrics(category, subCategory)
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color.White.copy(alpha = 0.08f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        subMetrics.forEach { (lbl, amount, col) ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(lbl, fontSize = 9.5.sp, color = Color(0xFFC7D2FE))
                                Text(amount, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = col)
                            }
                        }
                    }
                }

                // Sub-category model switcher chips
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Sub-Category Model:",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFC7D2FE)
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        category.subCategories.forEach { sub ->
                            val isSelected = sub == subCategory
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) Color.White.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.06f),
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) Color.White.copy(alpha = 0.6f) else Color.Transparent
                                ),
                                modifier = Modifier.clickable { onSubCategoryChange(sub) }
                            ) {
                                Text(
                                    text = sub,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else Color(0xFFC7D2FE),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// =========================================================================
// Category Specific Financial Metrics & Status Cards
// =========================================================================

@Composable
private fun CommunityFundMetricsCard(onAction: (DemoActionDialogState) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Total Community Balance", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("₹45,200", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Emerald500.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "+₹12,500 this month",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald500,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            // Monthly Collection Target Progress
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Monthly Collection Progress", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurface)
                    Text("₹12,500 / ₹15,000 (83%)", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                }
                LinearProgressIndicator(
                    progress = { 0.83f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = IndigoPrimary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }

            // Stat Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricStatTile(
                    label = "Pending Dues",
                    value = "₹2,500",
                    subValue = "5 members",
                    valueColor = Rose500,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Monthly Expenses",
                    value = "₹3,200",
                    subValue = "Utility & Repairs",
                    valueColor = Amber500,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Welfare Grants",
                    value = "₹5,000",
                    subValue = "2 Beneficiaries",
                    valueColor = IndigoPrimary,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun PujaFestivalMetricsCard(onAction: (DemoActionDialogState) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Festival Countdown Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(imageVector = Icons.Default.Festival, contentDescription = null, tint = Amber500, modifier = Modifier.size(18.dp))
                    Text("Durga Puja 2026", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Amber500.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "18 Days Left",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Amber500,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // Chanda Collection vs Target
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Chanda Collection Goal", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurface)
                    Text("₹78,500 / ₹1,00,000 (78.5%)", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                }
                LinearProgressIndicator(
                    progress = { 0.785f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = Emerald500,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }

            // Stat Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricStatTile(
                    label = "Sponsorships",
                    value = "₹25,000",
                    subValue = "5 Corporate Brands",
                    valueColor = IndigoPrimary,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Pandal & Decor",
                    value = "₹42,000",
                    subValue = "Advance Paid",
                    valueColor = Amber500,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Idol & Prasad",
                    value = "₹18,500",
                    subValue = "Budget Reserved",
                    valueColor = Emerald500,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun SportsClubMetricsCard(onAction: (DemoActionDialogState) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Club Treasury Balance", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("₹34,000", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = IndigoPrimary.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "18 / 22 Players Paid",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricStatTile(
                    label = "Tournament Fund",
                    value = "₹18,500",
                    subValue = "Inter-District Cup",
                    valueColor = Emerald500,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Gear & Pitch AMC",
                    value = "₹6,200",
                    subValue = "Balls & Net Maint.",
                    valueColor = Amber500,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Match Dues",
                    value = "₹1,200",
                    subValue = "4 Members",
                    valueColor = Rose500,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun SavingsShgMetricsCard(onAction: (DemoActionDialogState) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Total Group Savings Pool", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("₹1,85,000", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Emerald500.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "₹1,000/mo per member",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald500,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricStatTile(
                    label = "Active Loans",
                    value = "₹48,000",
                    subValue = "4 Members (2.0%/mo)",
                    valueColor = IndigoPrimary,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Interest Earned",
                    value = "₹960",
                    subValue = "This Month",
                    valueColor = Emerald500,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Next Meeting",
                    value = "Nov 5",
                    subValue = "10:00 AM",
                    valueColor = Amber500,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun ChitFundMetricsCard(onAction: (DemoActionDialogState) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Total Chit Value (20 Months)", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("₹1,00,000", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Amber500.copy(alpha = 0.18f)
                ) {
                    Text(
                        text = "Round 6 of 20 (Active)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Amber500,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricStatTile(
                    label = "Monthly Due",
                    value = "₹5,000",
                    subValue = "Per Member",
                    valueColor = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Last Bid Winner",
                    value = "₹81,500",
                    subValue = "Rahul Sen (₹18.5k disc)",
                    valueColor = Emerald500,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Member Dividend",
                    value = "₹925",
                    subValue = "Saved on due",
                    valueColor = IndigoPrimary,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun TripEventsMetricsCard(onAction: (DemoActionDialogState) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Trip Budget Pool (8 Travelers)", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("₹1,76,000", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Emerald500.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "Goa Tour 2026",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald500,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Spent So Far", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurface)
                    Text("₹1,14,350 / ₹1,76,000 (65%)", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = Amber500)
                }
                LinearProgressIndicator(
                    progress = { 0.65f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = Amber500,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricStatTile(
                    label = "Remaining Pool",
                    value = "₹61,650",
                    subValue = "In Common Kitty",
                    valueColor = Emerald500,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Resort & Travel",
                    value = "₹84,000",
                    subValue = "Fully Settled",
                    valueColor = IndigoPrimary,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Food & Misc",
                    value = "₹30,350",
                    subValue = "Logged in app",
                    valueColor = Amber500,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MessPoolMetricsCard(onAction: (DemoActionDialogState) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Mess Grocery Fund Balance", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("₹13,600", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = IndigoPrimary.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "Current Meal Rate: ₹48.50",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricStatTile(
                    label = "Total Meals",
                    value = "284",
                    subValue = "This Month",
                    valueColor = IndigoPrimary,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Grocery Spend",
                    value = "₹13,774",
                    subValue = "Veggies & Ration",
                    valueColor = Amber500,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Cook & Gas",
                    value = "₹4,500",
                    subValue = "Fixed Fee",
                    valueColor = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun FamilyFriendsMetricsCard(onAction: (DemoActionDialogState) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Family Shared Pool Balance", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("₹18,200", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = IndigoPrimary.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "6 Family Members",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricStatTile(
                    label = "Shared Spend",
                    value = "₹9,400",
                    subValue = "Split evenly",
                    valueColor = IndigoPrimary,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Emergency Pool",
                    value = "₹50,000",
                    subValue = "Fixed Deposit",
                    valueColor = Emerald500,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Pending Split",
                    value = "₹1,250",
                    subValue = "2 unpaid shares",
                    valueColor = Rose500,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun WelfareNgoMetricsCard(onAction: (DemoActionDialogState) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Public Donations & Grants", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("₹1,42,000", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Emerald500.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "100% Audit Score",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald500,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricStatTile(
                    label = "Aid Disbursed",
                    value = "₹95,000",
                    subValue = "Direct Relief",
                    valueColor = Emerald500,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Medical Support",
                    value = "₹45,000",
                    subValue = "6 Patients Assisted",
                    valueColor = Amber500,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Child Education",
                    value = "₹30,000",
                    subValue = "Scholarships Paid",
                    valueColor = IndigoPrimary,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun HousingSocietyMetricsCard(onAction: (DemoActionDialogState) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Maintenance Collection (38/42 Flats)", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("₹57,000", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Emerald500.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "90% Collected",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald500,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricStatTile(
                    label = "Sinking Reserve",
                    value = "₹2,10,000",
                    subValue = "Fixed Bank Fund",
                    valueColor = IndigoPrimary,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Overdue Dues",
                    value = "₹6,000",
                    subValue = "4 Flats (Notice Sent)",
                    valueColor = Rose500,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Vendor Bills Paid",
                    value = "₹28,500",
                    subValue = "Security & Lift AMC",
                    valueColor = Amber500,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun BusinessPartnershipMetricsCard(onAction: (DemoActionDialogState) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Net Distributable Profit", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("₹73,000", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = IndigoPrimary.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "3 Equity Partners",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricStatTile(
                    label = "Total Revenue",
                    value = "₹1,85,000",
                    subValue = "This Month",
                    valueColor = Emerald500,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Operating Cost",
                    value = "₹1,12,000",
                    subValue = "Salaries & Server",
                    valueColor = Amber500,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Capital Pool",
                    value = "₹5,00,000",
                    subValue = "Total Equity",
                    valueColor = IndigoPrimary,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun OtherGroupMetricsCard(onAction: (DemoActionDialogState) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Current Ledger Balance", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("₹28,400", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = IndigoPrimary.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "15 Active Members",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricStatTile(
                    label = "Total Collected",
                    value = "₹35,000",
                    subValue = "Inflow",
                    valueColor = Emerald500,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Total Spent",
                    value = "₹6,600",
                    subValue = "Outflow",
                    valueColor = Amber500,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Unpaid Dues",
                    value = "₹1,500",
                    subValue = "3 Members",
                    valueColor = Rose500,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MetricStatTile(
    label: String,
    value: String,
    subValue: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = value,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = valueColor
            )
            Text(
                text = subValue,
                fontSize = 9.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// =========================================================================
// Category-Aware Quick Actions Grid
// =========================================================================

data class QuickActionItem(
    val title: String,
    val description: String,
    val fieldLabel: String,
    val defaultAmount: String,
    val icon: ImageVector,
    val color: Color
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DemoQuickActionsSection(
    category: GroupCategory,
    isChitMode: Boolean,
    isMessMode: Boolean,
    onActionClick: (QuickActionItem) -> Unit
) {
    val actions = getCategoryQuickActions(category, isChitMode, isMessMode)

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "Quick Actions (${category.title})",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            actions.forEach { action ->
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onActionClick(action) }
                        .testTag("demo_quick_action_${action.title.lowercase().replace(" ", "_")}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(action.color.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = action.icon,
                                contentDescription = null,
                                tint = action.color,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Column {
                            Text(
                                text = action.title,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = action.description,
                                fontSize = 9.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun getCategoryQuickActions(
    category: GroupCategory,
    isChitMode: Boolean,
    isMessMode: Boolean
): List<QuickActionItem> {
    return when (category) {
        GroupCategory.COMMUNITY_FUND -> listOf(
            QuickActionItem("Collect Dues", "Record member payment", "Collection Amount", "500", Icons.Default.AddCard, Emerald500),
            QuickActionItem("Record Expense", "Log community bill", "Expense Amount", "850", Icons.Default.TrendingDown, Rose500),
            QuickActionItem("Welfare Grant", "Disburse emergency aid", "Grant Amount", "2500", Icons.Default.VolunteerActivism, IndigoPrimary),
            QuickActionItem("Meeting Notice", "Broadcast announcement", "Notice Title", "General Body Meeting", Icons.Default.Campaign, Amber500)
        )
        GroupCategory.PUJA_FESTIVAL -> listOf(
            QuickActionItem("Collect Chanda", "Record devotee donation", "Chanda Amount", "1000", Icons.Default.Payment, Emerald500),
            QuickActionItem("Add Sponsor", "Log banner sponsorship", "Sponsorship Amount", "5000", Icons.Default.Stars, Amber500),
            QuickActionItem("Pandal Voucher", "Record tent/sound bill", "Voucher Amount", "12000", Icons.Default.Receipt, Rose500),
            QuickActionItem("Print Receipts", "Export all donor receipts", "Batch Name", "Durga Puja 2026", Icons.Default.PictureAsPdf, IndigoPrimary)
        )
        GroupCategory.SPORTS_CULTURAL -> listOf(
            QuickActionItem("Member Fees", "Record monthly sports fee", "Fee Amount", "300", Icons.Default.Payment, Emerald500),
            QuickActionItem("Tournament Entry", "Log team registration", "Entry Fee", "1500", Icons.Default.WorkspacePremium, Amber500),
            QuickActionItem("Buy Equipment", "Balls, nets & maintenance", "Expense Amount", "2200", Icons.Default.SportsSoccer, Rose500),
            QuickActionItem("Match Schedule", "Post upcoming fixture", "Match Details", "Finals vs City Strikers", Icons.Default.Event, IndigoPrimary)
        )
        GroupCategory.SAVINGS_CREDIT_CHIT -> {
            if (isChitMode) {
                listOf(
                    QuickActionItem("Chit Installment", "Collect monthly installment", "Installment", "5000", Icons.Default.Payment, Emerald500),
                    QuickActionItem("Hold Auction", "Enter winning bidder & discount", "Winning Bid Discount", "18500", Icons.Default.Gavel, Amber500),
                    QuickActionItem("Disburse Chit", "Payout to auction winner", "Net Payout", "81500", Icons.Default.AttachMoney, IndigoPrimary),
                    QuickActionItem("Chit Passbook", "Generate audit statement", "Statement Period", "Cycle 1-20", Icons.Default.PictureAsPdf, IndigoPrimary)
                )
            } else {
                listOf(
                    QuickActionItem("Collect Savings", "Record monthly SHG saving", "Savings Amount", "1000", Icons.Default.Savings, Emerald500),
                    QuickActionItem("Disburse Loan", "Issue internal loan to member", "Loan Amount", "15000", Icons.Default.MonetizationOn, IndigoPrimary),
                    QuickActionItem("Loan Repayment", "Principal + interest payment", "Repayment Amount", "1800", Icons.Default.CheckCircle, Amber500),
                    QuickActionItem("SHG Passbook", "Export member ledger PDF", "Passbook Year", "2026-2027", Icons.Default.PictureAsPdf, Rose500)
                )
            }
        }
        GroupCategory.EVENTS_TRIPS -> {
            if (isMessMode) {
                listOf(
                    QuickActionItem("Add Grocery", "Log market & ration expense", "Bill Amount", "1450", Icons.Default.ShoppingBag, Amber500),
                    QuickActionItem("Log Meal Count", "Update today's meals", "Number of Meals", "12", Icons.Default.TableChart, IndigoPrimary),
                    QuickActionItem("Deposit Advance", "Member mess pool advance", "Deposit Amount", "2000", Icons.Default.Payment, Emerald500),
                    QuickActionItem("Mess Bill PDF", "Calculate meal rate statement", "Month Period", "October 2026", Icons.Default.PictureAsPdf, Rose500)
                )
            } else {
                listOf(
                    QuickActionItem("Add Trip Expense", "Log hotel, food or cab", "Expense Amount", "3400", Icons.Default.TrendingDown, Rose500),
                    QuickActionItem("Collect Pool", "Member trip kitty deposit", "Deposit Amount", "5000", Icons.Default.AddCard, Emerald500),
                    QuickActionItem("Split Bill", "Calculate equal/unequal share", "Total Bill", "6200", Icons.Default.PieChart, IndigoPrimary),
                    QuickActionItem("Trip Settlement", "Settle who owes whom", "Trip ID", "Goa Tour 2026", Icons.Default.SwapHoriz, Amber500)
                )
            }
        }
        GroupCategory.FAMILY_FRIENDS -> listOf(
            QuickActionItem("Split Expense", "Dinner, outing or groceries", "Bill Amount", "2400", Icons.Default.PieChart, IndigoPrimary),
            QuickActionItem("Add Pool Money", "Contribute to joint kitty", "Pool Amount", "2000", Icons.Default.Payment, Emerald500),
            QuickActionItem("Settle Dues", "Mark friend/member as paid", "Settle Amount", "600", Icons.Default.CheckCircle, Amber500),
            QuickActionItem("Export Split", "Send WhatsApp balance breakdown", "Report Name", "October Spends", Icons.Default.Share, Rose500)
        )
        GroupCategory.WELFARE_NGO -> listOf(
            QuickActionItem("Record Donation", "Log donor contribution", "Donation Amount", "2500", Icons.Default.VolunteerActivism, Emerald500),
            QuickActionItem("Distribute Relief", "Disburse medical / flood aid", "Aid Amount", "10000", Icons.Default.Handshake, IndigoPrimary),
            QuickActionItem("Project Expense", "Food kits, school supplies", "Project Cost", "4500", Icons.Default.TrendingDown, Amber500),
            QuickActionItem("80G Receipt", "Issue tax exemption receipt", "Donor PAN / Name", "Mr. R. Sen", Icons.Default.PictureAsPdf, Rose500)
        )
        GroupCategory.HOUSING_APARTMENT -> listOf(
            QuickActionItem("Maintenance Due", "Log flat maintenance payment", "Maintenance Amount", "1500", Icons.Default.Apartment, Emerald500),
            QuickActionItem("Pay Vendor", "Security agency or lift AMC", "Vendor Bill", "14000", Icons.Default.Receipt, Rose500),
            QuickActionItem("Post Circular", "Water shutdown / society notice", "Circular Title", "Tank Cleaning on Sunday", Icons.Default.Campaign, Amber500),
            QuickActionItem("Defaulters List", "Generate unpaid flat list", "Building Wing", "Block A & B", Icons.Default.Warning, IndigoPrimary)
        )
        GroupCategory.BUSINESS_PARTNERSHIP -> listOf(
            QuickActionItem("Record Revenue", "Client invoice / sales inflow", "Revenue Amount", "35000", Icons.Default.AutoGraph, Emerald500),
            QuickActionItem("Operating Cost", "Salaries, servers & tools", "Cost Amount", "18000", Icons.Default.TrendingDown, Rose500),
            QuickActionItem("Capital Infusion", "Partner equity investment", "Capital Amount", "50000", Icons.Default.BusinessCenter, IndigoPrimary),
            QuickActionItem("Distribute Profit", "Payout based on equity ratio", "Dividend Amount", "25000", Icons.Default.PieChart, Amber500)
        )
        GroupCategory.OTHER_GROUPS -> listOf(
            QuickActionItem("Add Income", "Record general group collection", "Income Amount", "1000", Icons.Default.TrendingUp, Emerald500),
            QuickActionItem("Add Expense", "Log general expenditure", "Expense Amount", "500", Icons.Default.TrendingDown, Rose500),
            QuickActionItem("Add Member", "Register new participant", "Member Name", "Vikram Sen", Icons.Default.GroupAdd, IndigoPrimary),
            QuickActionItem("Export PDF", "Download complete summary", "File Title", "General Ledger", Icons.Default.PictureAsPdf, Amber500)
        )
    }
}

// =========================================================================
// Category-Aware Notice & Highlight Banner
// =========================================================================

@Composable
private fun DemoCategoryNoticeCard(
    category: GroupCategory,
    isChitMode: Boolean
) {
    val noticeText = when (category) {
        GroupCategory.COMMUNITY_FUND -> "Notice: General Body Meeting scheduled for Sunday 10:00 AM at Community Hall."
        GroupCategory.PUJA_FESTIVAL -> "Pandal Construction Notice: Electrical inspection on 12th Oct. Devotee prasad booking is open."
        GroupCategory.SPORTS_CULTURAL -> "Tournament Alert: Final squad announcement on Friday. New club jerseys arrived."
        GroupCategory.SAVINGS_CREDIT_CHIT -> if (isChitMode) "Auction Alert: Round 7 auction will be conducted on 10th Nov at 7:00 PM." else "SHG Reminder: Monthly savings collection due by 5th of each month."
        GroupCategory.EVENTS_TRIPS -> "Trip Checklist: Resort advance confirmed. Please upload transport bills before Sunday."
        GroupCategory.FAMILY_FRIENDS -> "Shared Pool: Weekend family dinner bill has been logged and split."
        GroupCategory.WELFARE_NGO -> "Aid Mission: 200 food and medical kits distributed in Flood Zone Sector 2."
        GroupCategory.HOUSING_APARTMENT -> "Maintenance Circular: Overhead water tank cleaning scheduled this Saturday from 2 PM to 6 PM."
        GroupCategory.BUSINESS_PARTNERSHIP -> "Financial Review: Q3 Profit Distribution finalized. Equity vouchers ready for approval."
        GroupCategory.OTHER_GROUPS -> "Group Update: Monthly accounts audit completed with zero discrepancies."
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = IndigoHeroSurface.copy(alpha = 0.5f)),
        border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.25f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Campaign,
                contentDescription = null,
                tint = Amber500,
                modifier = Modifier.size(22.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "LATEST ANNOUNCEMENT",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Amber500
                )
                Text(
                    text = noticeText,
                    fontSize = 11.5.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    lineHeight = 15.sp
                )
            }
        }
    }
}

// =========================================================================
// Category-Aware Activity Feed / Recent Transactions
// =========================================================================

data class DemoTransactionItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val amount: String,
    val isPositive: Boolean,
    val tag: String,
    val timeAgo: String
)

@Composable
private fun DemoCategoryActivityFeed(
    category: GroupCategory,
    isChitMode: Boolean,
    isMessMode: Boolean
) {
    val items = getCategoryTransactions(category, isChitMode, isMessMode)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Transactions (${category.title})",
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "View All (Demo)",
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = IndigoPrimary
                )
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

            items.forEachIndexed { index, tx ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(
                                    if (tx.isPositive) Emerald500.copy(alpha = 0.15f) else Rose500.copy(alpha = 0.15f)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (tx.isPositive) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                                contentDescription = null,
                                tint = if (tx.isPositive) Emerald500 else Rose500,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        Column {
                            Text(
                                text = tx.title,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                ) {
                                    Text(
                                        text = tx.tag,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                                Text(
                                    text = tx.timeAgo,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Text(
                        text = if (tx.isPositive) "+${tx.amount}" else "-${tx.amount}",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (tx.isPositive) Emerald500 else Rose500
                    )
                }

                if (index < items.size - 1) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.15f))
                }
            }
        }
    }
}

private fun getCategoryTransactions(
    category: GroupCategory,
    isChitMode: Boolean,
    isMessMode: Boolean
): List<DemoTransactionItem> {
    return when (category) {
        GroupCategory.COMMUNITY_FUND -> listOf(
            DemoTransactionItem("1", "Anirban Das", "Paid October Subscription", "₹500", true, "Collection", "Today, 11:30 AM"),
            DemoTransactionItem("2", "Priya Mukherjee", "Paid October Subscription", "₹500", true, "Collection", "Today, 9:15 AM"),
            DemoTransactionItem("3", "Streetlight Repair", "Paid electrician & bulb replacement", "₹1,200", false, "Expense", "Yesterday"),
            DemoTransactionItem("4", "Medical Grant Disbursed", "Assistance to Subhash Mondal", "₹2,500", false, "Welfare", "2 days ago")
        )
        GroupCategory.PUJA_FESTIVAL -> listOf(
            DemoTransactionItem("1", "Swapan Roy & Family", "Family Festival Chanda", "₹2,000", true, "Chanda", "1 hour ago"),
            DemoTransactionItem("2", "Sunrise Jewellers", "Main Stage Gate Sponsorship", "₹10,000", true, "Sponsor", "Yesterday"),
            DemoTransactionItem("3", "Advance to Idol Sculptor", "Kumartuli workshop advance", "₹15,000", false, "Idol", "2 days ago"),
            DemoTransactionItem("4", "Sound & Mic Booking", "Four-day PA sound system", "₹8,000", false, "Sound", "3 days ago")
        )
        GroupCategory.SPORTS_CULTURAL -> listOf(
            DemoTransactionItem("1", "Rohan Roy", "October Football Membership", "₹300", true, "Monthly Fee", "Today"),
            DemoTransactionItem("2", "SG Leather Cricket Balls", "Purchased 6 tournament balls", "₹1,800", false, "Equipment", "Yesterday"),
            DemoTransactionItem("3", "Tournament Registration", "Received from 8 players", "₹2,400", true, "Tourney Fee", "2 days ago"),
            DemoTransactionItem("4", "Ground Roller Diesel", "Pitch preparation labor", "₹950", false, "Ground AMC", "3 days ago")
        )
        GroupCategory.SAVINGS_CREDIT_CHIT -> {
            if (isChitMode) {
                listOf(
                    DemoTransactionItem("1", "Rahul Sen", "Paid Round 6 Installment", "₹4,075", true, "Installment", "Today"),
                    DemoTransactionItem("2", "Chit Dividend Applied", "₹925 discount per member", "₹925", true, "Dividend", "Round 6"),
                    DemoTransactionItem("3", "Auction Payout Disbursed", "Disbursed to Rahul Sen", "₹81,500", false, "Chit Payout", "Round 5 Winner"),
                    DemoTransactionItem("4", "Amitabh Ghosh", "Paid Round 6 Installment", "₹4,075", true, "Installment", "Yesterday")
                )
            } else {
                listOf(
                    DemoTransactionItem("1", "Meera Devi", "Monthly Savings Deposit", "₹1,000", true, "Savings", "Today"),
                    DemoTransactionItem("2", "Kiran Bala", "Monthly Savings Deposit", "₹1,000", true, "Savings", "Today"),
                    DemoTransactionItem("3", "Emergency Loan Disbursed", "Disbursed to Anita Paul", "₹10,000", false, "Loan Disbursed", "Yesterday"),
                    DemoTransactionItem("4", "Loan Repayment (Principal + Int)", "Received from Rekha Roy", "₹1,200", true, "Loan Repay", "3 days ago")
                )
            }
        }
        GroupCategory.EVENTS_TRIPS -> {
            if (isMessMode) {
                listOf(
                    DemoTransactionItem("1", "Vegetables & Fish Market", "Morning market by Debanjan", "₹850", false, "Mess Ration", "Today, 8:00 AM"),
                    DemoTransactionItem("2", "Ratan Paul", "Deposited Mess Advance", "₹2,000", true, "Deposit", "Yesterday"),
                    DemoTransactionItem("3", "Indane LPG Cylinder", "Replaced mess cooking cylinder", "₹1,150", false, "Utility", "2 days ago"),
                    DemoTransactionItem("4", "Monthly Cook Salary", "Paid to Somesh Da", "₹3,500", false, "Cook Fee", "4 days ago")
                )
            } else {
                listOf(
                    DemoTransactionItem("1", "Beach Shack Dinner", "Paid by Arindam (Split 8 ways)", "₹4,800", false, "Trip Meal", "Last Night"),
                    DemoTransactionItem("2", "Self-Drive SUV Rental", "Goa car hire 4 days", "₹14,000", false, "Transport", "Yesterday"),
                    DemoTransactionItem("3", "Sneha Roy", "Added Kitty Deposit", "₹5,000", true, "Pool Deposit", "2 days ago"),
                    DemoTransactionItem("4", "Scuba & Water Sports", "Advance ticket booking", "₹9,600", false, "Activity", "3 days ago")
                )
            }
        }
        GroupCategory.FAMILY_FRIENDS -> listOf(
            DemoTransactionItem("1", "Family Weekend Brunch", "Paid by Abhijit (Split 4 ways)", "₹3,200", false, "Dining Out", "Yesterday"),
            DemoTransactionItem("2", "Joint Medical Insurance", "Quarterly family contribution", "₹4,500", false, "Healthcare", "3 days ago"),
            DemoTransactionItem("3", "Monthly Kitty Contribution", "Deposited by Ritu", "₹2,000", true, "Pool Deposit", "4 days ago"),
            DemoTransactionItem("4", "Groceries & Daily Milk", "Instamart shared basket", "₹1,450", false, "Groceries", "5 days ago")
        )
        GroupCategory.WELFARE_NGO -> listOf(
            DemoTransactionItem("1", "Donation: Dr. S. K. Gupta", "Cheque donation for child health", "₹10,000", true, "Donation", "Today"),
            DemoTransactionItem("2", "Patient Medical Aid", "Chemotherapy support for R. Das", "₹15,000", false, "Medical Aid", "Yesterday"),
            DemoTransactionItem("3", "Online UPI Donation", "Received from Ananya Sen", "₹1,000", true, "Public Donation", "Yesterday"),
            DemoTransactionItem("4", "School Bags & Books Drive", "Purchased 100 student kits", "₹12,500", false, "Education", "3 days ago")
        )
        GroupCategory.HOUSING_APARTMENT -> listOf(
            DemoTransactionItem("1", "Flat A-302 (R. K. Sharma)", "October Maintenance + Parking", "₹1,700", true, "Maintenance", "Today"),
            DemoTransactionItem("2", "Flat B-104 (Debasis Roy)", "October Maintenance", "₹1,500", true, "Maintenance", "Today"),
            DemoTransactionItem("3", "24/7 Security Agency Invoice", "Monthly 3-guard shift payout", "₹18,000", false, "Security Bill", "Yesterday"),
            DemoTransactionItem("4", "Lift AMC & Inspection", "Quarterly Schindler service", "₹4,500", false, "Lift AMC", "2 days ago")
        )
        GroupCategory.BUSINESS_PARTNERSHIP -> listOf(
            DemoTransactionItem("1", "Acme Corp Client Payment", "Website design invoice settled", "₹45,000", true, "Revenue", "Today"),
            DemoTransactionItem("2", "AWS & Cloudflare Hosting", "Monthly infrastructure bill", "₹8,400", false, "Hosting Cost", "Yesterday"),
            DemoTransactionItem("3", "Partner Capital Infusion", "Equity deposit by S. Sen (30%)", "₹1,50,000", true, "Capital Pool", "3 days ago"),
            DemoTransactionItem("4", "Contractor UI/UX Freelance", "Paid mobile design contractor", "₹15,000", false, "Contractor", "4 days ago")
        )
        GroupCategory.OTHER_GROUPS -> listOf(
            DemoTransactionItem("1", "Member Contribution", "Received from Debabrata Roy", "₹1,000", true, "Contribution", "Today"),
            DemoTransactionItem("2", "Stationery & Refreshments", "Meeting snacks and register", "₹450", false, "Expense", "Yesterday"),
            DemoTransactionItem("3", "Member Contribution", "Received from Tanmay Paul", "₹1,000", true, "Contribution", "2 days ago"),
            DemoTransactionItem("4", "Annual Hall Rent", "Booked association room", "₹3,000", false, "Rent", "4 days ago")
        )
    }
}

// =========================================================================
// Interactive Action Dialog for Demo Experience
// =========================================================================

data class DemoActionDialogState(
    val title: String,
    val category: GroupCategory,
    val description: String,
    val primaryFieldLabel: String,
    val defaultAmount: String
)

@Composable
private fun DemoActionInteractiveDialog(
    dialogState: DemoActionDialogState,
    onDismiss: () -> Unit,
    onSubmit: (amount: String, note: String) -> Unit
) {
    var amount by remember { mutableStateOf(dialogState.defaultAmount) }
    var note by remember { mutableStateOf("") }
    var selectedMember by remember { mutableStateOf("Anirban Das") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = dialogState.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 16.sp
                        )
                        Text(
                            text = dialogState.description,
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f))

                // Amount or Primary Field
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text(dialogState.primaryFieldLabel, fontSize = 12.sp) },
                    modifier = Modifier.fillMaxWidth().testTag("demo_action_input_field"),
                    shape = RoundedCornerShape(10.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = IndigoPrimary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                    )
                )

                // Optional Notes
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Notes / Particulars (Optional)", fontSize = 12.sp) },
                    placeholder = { Text("e.g. October installment via UPI", fontSize = 12.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = IndigoPrimary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onSubmit(amount, note) },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                        modifier = Modifier.testTag("demo_action_submit_btn")
                    ) {
                        Text("Record (Demo)", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

// Helpers
private fun getSampleGroupNameForCategory(category: GroupCategory): String {
    return when (category) {
        GroupCategory.COMMUNITY_FUND -> "Green Valley Community Fund"
        GroupCategory.PUJA_FESTIVAL -> "Navratri & Durga Puja Committee 2026"
        GroupCategory.SPORTS_CULTURAL -> "Rising Stars Sports & Cultural Club"
        GroupCategory.SAVINGS_CREDIT_CHIT -> "Shakti Chit Fund"
        GroupCategory.EVENTS_TRIPS -> "Goa Friends Vacation Pool 2026"
        GroupCategory.FAMILY_FRIENDS -> "Banerjee Family Trust & Shared Pool"
        GroupCategory.WELFARE_NGO -> "Hope Foundation & Public Welfare Society"
        GroupCategory.HOUSING_APARTMENT -> "Oakwood Heights Residents Society"
        GroupCategory.BUSINESS_PARTNERSHIP -> "Apex Tech Ventures & Partners"
        GroupCategory.OTHER_GROUPS -> "Universal Community Committee"
    }
}

private fun getSampleMemberCount(category: GroupCategory): String {
    return when (category) {
        GroupCategory.COMMUNITY_FUND -> "24 Members"
        GroupCategory.PUJA_FESTIVAL -> "18 Committee Members"
        GroupCategory.SPORTS_CULTURAL -> "22 Players"
        GroupCategory.SAVINGS_CREDIT_CHIT -> "20 Members"
        GroupCategory.EVENTS_TRIPS -> "8 Travelers"
        GroupCategory.FAMILY_FRIENDS -> "6 Family Members"
        GroupCategory.WELFARE_NGO -> "48 Donors"
        GroupCategory.HOUSING_APARTMENT -> "42 Flats"
        GroupCategory.BUSINESS_PARTNERSHIP -> "3 Equity Partners"
        GroupCategory.OTHER_GROUPS -> "15 Members"
    }
}

private data class CategoryHeroFinancials(
    val primaryLabel: String,
    val primaryVal: String,
    val secLabel: String,
    val secVal: String
)

private fun getCategoryHeroFinancials(category: GroupCategory, subCategory: String): CategoryHeroFinancials {
    return when (category) {
        GroupCategory.COMMUNITY_FUND -> CategoryHeroFinancials(
            primaryLabel = "Total Group Assets",
            primaryVal = "₹2,45,000",
            secLabel = "Due Amount",
            secVal = "₹12,500"
        )
        GroupCategory.PUJA_FESTIVAL -> CategoryHeroFinancials(
            primaryLabel = "Total Chanda Collection",
            primaryVal = "₹2,45,000",
            secLabel = "Budget Goal",
            secVal = "₹3,00,000"
        )
        GroupCategory.SPORTS_CULTURAL -> CategoryHeroFinancials(
            primaryLabel = "Club Treasury Balance",
            primaryVal = "₹42,500",
            secLabel = "Monthly Dues",
            secVal = "₹6,000"
        )
        GroupCategory.SAVINGS_CREDIT_CHIT -> CategoryHeroFinancials(
            primaryLabel = "SHG Revolving Capital",
            primaryVal = "₹1,85,000",
            secLabel = "Active Loans Due",
            secVal = "₹45,000"
        )
        GroupCategory.EVENTS_TRIPS -> {
            if (subCategory.contains("Mess", ignoreCase = true)) {
                CategoryHeroFinancials(
                    primaryLabel = "Mess Monthly Pool",
                    primaryVal = "₹24,500",
                    secLabel = "Pending Dues",
                    secVal = "₹2,500"
                )
            } else {
                CategoryHeroFinancials(
                    primaryLabel = "Total Trip Budget",
                    primaryVal = "₹1,20,000",
                    secLabel = "Collected",
                    secVal = "₹95,000"
                )
            }
        }
        GroupCategory.FAMILY_FRIENDS -> CategoryHeroFinancials(
            primaryLabel = "Shared Expense Pool",
            primaryVal = "₹84,000",
            secLabel = "Pending Settles",
            secVal = "₹4,200"
        )
        GroupCategory.WELFARE_NGO -> CategoryHeroFinancials(
            primaryLabel = "Welfare Donation Fund",
            primaryVal = "₹4,80,000",
            secLabel = "Campaign Target",
            secVal = "₹6,00,000"
        )
        GroupCategory.HOUSING_APARTMENT -> CategoryHeroFinancials(
            primaryLabel = "Maintenance Fund",
            primaryVal = "₹1,85,000",
            secLabel = "Pending Dues",
            secVal = "₹25,000"
        )
        GroupCategory.BUSINESS_PARTNERSHIP -> CategoryHeroFinancials(
            primaryLabel = "Working Capital Pool",
            primaryVal = "₹18,50,000",
            secLabel = "Monthly Net Profit",
            secVal = "₹2,40,000"
        )
        GroupCategory.OTHER_GROUPS -> CategoryHeroFinancials(
            primaryLabel = "Total Committee Assets",
            primaryVal = "₹65,000",
            secLabel = "Active Dues",
            secVal = "₹4,500"
        )
    }
}

private fun getCategoryHeroSubMetrics(
    category: GroupCategory,
    subCategory: String
): List<Triple<String, String, Color>> {
    return when (category) {
        GroupCategory.COMMUNITY_FUND -> listOf(
            Triple("Investment", "₹65,000", Color(0xFFA7F3D0)),
            Triple("Expenses", "₹18,200", Color(0xFFFDE68A)),
            Triple("In-Hand Bal", "₹1,61,800", Color.White)
        )
        GroupCategory.PUJA_FESTIVAL -> listOf(
            Triple("Pandal & Stage", "₹85,000", Color(0xFFFDE68A)),
            Triple("Idol & Murti", "₹35,000", Color(0xFFA7F3D0)),
            Triple("Prasad & Bhog", "₹28,000", Color.White)
        )
        GroupCategory.SPORTS_CULTURAL -> listOf(
            Triple("Kit & Gear", "₹15,000", Color(0xFFA7F3D0)),
            Triple("Ground AMC", "₹12,500", Color(0xFFFDE68A)),
            Triple("Prize Pool", "₹15,000", Color.White)
        )
        GroupCategory.SAVINGS_CREDIT_CHIT -> listOf(
            Triple("Member Savings", "₹1,40,000", Color(0xFFA7F3D0)),
            Triple("Interest Earned", "₹18,500", Color(0xFFFDE68A)),
            Triple("In-Hand Cash", "₹26,500", Color.White)
        )
        GroupCategory.EVENTS_TRIPS -> {
            if (subCategory.contains("Mess", ignoreCase = true)) {
                listOf(
                    Triple("Groceries", "₹14,200", Color(0xFFFDE68A)),
                    Triple("Cook & Gas", "₹6,500", Color(0xFFA7F3D0)),
                    Triple("In-Hand Pool", "₹3,800", Color.White)
                )
            } else {
                listOf(
                    Triple("Transport", "₹45,000", Color(0xFFA7F3D0)),
                    Triple("Stays & Resort", "₹38,000", Color(0xFFFDE68A)),
                    Triple("Activities", "₹12,000", Color.White)
                )
            }
        }
        GroupCategory.FAMILY_FRIENDS -> listOf(
            Triple("Shared Bills", "₹32,000", Color(0xFFA7F3D0)),
            Triple("Utilities", "₹18,000", Color(0xFFFDE68A)),
            Triple("Pool Balance", "₹34,000", Color.White)
        )
        GroupCategory.WELFARE_NGO -> listOf(
            Triple("Direct Relief", "₹2,80,000", Color(0xFFA7F3D0)),
            Triple("Medical Camps", "₹1,20,000", Color(0xFFFDE68A)),
            Triple("Reserve Fund", "₹80,000", Color.White)
        )
        GroupCategory.HOUSING_APARTMENT -> listOf(
            Triple("Security & Staff", "₹68,000", Color(0xFFA7F3D0)),
            Triple("Elevator AMC", "₹24,000", Color(0xFFFDE68A)),
            Triple("Sinking Fund", "₹93,000", Color.White)
        )
        GroupCategory.BUSINESS_PARTNERSHIP -> listOf(
            Triple("Gross Revenue", "₹6,20,000", Color(0xFFA7F3D0)),
            Triple("Total Expenses", "₹3,80,000", Color(0xFFFDE68A)),
            Triple("Cash Reserves", "₹8,50,000", Color.White)
        )
        GroupCategory.OTHER_GROUPS -> listOf(
            Triple("Collections", "₹35,000", Color(0xFFA7F3D0)),
            Triple("Disbursed", "₹18,000", Color(0xFFFDE68A)),
            Triple("Balance", "₹12,000", Color.White)
        )
    }
}

@Composable
private fun DemoBottomNavBar(
    selectedItem: String,
    onItemClick: (String) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("demo_bottom_nav_bar"),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            DemoBottomNavItem(
                icon = Icons.Default.Home,
                label = "Home",
                isSelected = selectedItem == "home",
                badge = null,
                onClick = { onItemClick("home") }
            )
            DemoBottomNavItem(
                icon = Icons.Default.Inbox,
                label = "Inbox",
                isSelected = selectedItem == "inbox",
                badge = "2",
                onClick = { onItemClick("Inbox") }
            )
            DemoBottomNavItem(
                icon = Icons.Default.Group,
                label = "Member",
                isSelected = selectedItem == "members",
                badge = null,
                onClick = { onItemClick("Member") }
            )
            DemoBottomNavItem(
                icon = Icons.AutoMirrored.Filled.ReceiptLong,
                label = "Report",
                isSelected = selectedItem == "reports",
                badge = null,
                onClick = { onItemClick("Report") }
            )
            DemoBottomNavItem(
                icon = Icons.Default.MoreHoriz,
                label = "More",
                isSelected = selectedItem == "more",
                badge = null,
                onClick = { onItemClick("More") }
            )
        }
    }
}

@Composable
private fun DemoBottomNavItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    badge: String? = null,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        BadgedBox(
            badge = {
                if (badge != null) {
                    Badge(
                        containerColor = Rose500,
                        contentColor = Color.White
                    ) {
                        Text(badge, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) IndigoPrimary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                modifier = Modifier.size(22.dp)
            )
        }
        Text(
            text = label,
            fontSize = 10.5.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) IndigoPrimary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
        )
    }
}
