package com.adr.groupledger.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adr.groupledger.data.model.ChitFundConfig
import com.adr.groupledger.ui.screens.demo.GroupCategory
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.utils.CurrencyFormatter

/**
 * Single source of truth Category & Sub-Category Selection Section.
 * Strictly enforces that the chosen sub-category belongs to the selected category.
 * Fully compatible with dark and light themes.
 */
@Composable
fun GroupCategorySelectorSection(
    selectedCategory: GroupCategory,
    selectedSubCategory: String,
    onCategoryChanged: (GroupCategory, String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Section Label
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Group Category",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = IndigoPrimary.copy(alpha = 0.12f)
            ) {
                Text(
                    text = selectedCategory.title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = IndigoPrimary,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }

        // Horizontal Category Chips
        val categoryScrollState = rememberScrollState()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(categoryScrollState)
                .testTag("group_category_chip_row"),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GroupCategory.entries.forEach { cat ->
                val isSelected = cat == selectedCategory
                FilterChip(
                    selected = isSelected,
                    onClick = {
                        if (!isSelected) {
                            val defaultSub = cat.subCategories.firstOrNull() ?: "General"
                            onCategoryChanged(cat, defaultSub)
                        }
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = cat.icon,
                            contentDescription = null,
                            tint = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    label = {
                        Text(
                            text = cat.title,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = IndigoPrimary,
                        selectedLabelColor = Color.White,
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                        labelColor = MaterialTheme.colorScheme.onSurface
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isSelected,
                        borderColor = MaterialTheme.colorScheme.outlineVariant,
                        selectedBorderColor = IndigoPrimary,
                        borderWidth = 1.dp,
                        selectedBorderWidth = 1.5.dp
                    )
                )
            }
        }

        // Sub-Category Selection (Strictly filtered from selectedCategory.subCategories)
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "Sub-Category / Type",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            val subCategoryScrollState = rememberScrollState()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(subCategoryScrollState)
                    .testTag("group_subcategory_chip_row"),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                selectedCategory.subCategories.forEach { sub ->
                    val isSubSelected = sub.equals(selectedSubCategory, ignoreCase = true)
                    FilterChip(
                        selected = isSubSelected,
                        onClick = {
                            onCategoryChanged(selectedCategory, sub)
                        },
                        label = {
                            Text(
                                text = sub,
                                fontSize = 11.5.sp,
                                fontWeight = if (isSubSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = IndigoPrimary.copy(alpha = 0.18f),
                            selectedLabelColor = IndigoPrimary,
                            containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                            labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSubSelected,
                            borderColor = MaterialTheme.colorScheme.outlineVariant,
                            selectedBorderColor = IndigoPrimary,
                            borderWidth = if (isSubSelected) 1.5.dp else 1.dp
                        )
                    )
                }
            }
        }

        // Reassurance / Adaptability Note
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = IndigoPrimary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "You can change category or sub-category anytime. The Home Page layout adapts automatically.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/**
 * Dedicated Chit Fund / BC Scheme Configuration Section.
 * Rendered conditionally only when Chit Fund sub-category is selected.
 *
 * Implements Phase B.1 requirements:
 * - Clear distinction between Required and Optional information
 * - Friendly, accessible English terminology (no confusing jargon)
 * - Automatic financial consistency checks & validation warnings
 * - Contextual protection for started/completed cycles (safe vs restricted editing)
 * - Support for Group Admin permission enforcement
 */
@Composable
fun ChitFundSettingsSection(
    chitConfig: ChitFundConfig,
    currencySymbol: String = "₹",
    isAdmin: Boolean = true,
    onConfigChanged: (ChitFundConfig) -> Unit,
    modifier: Modifier = Modifier
) {
    val cycleMetrics = remember(chitConfig) {
        com.adr.groupledger.utils.ChitCalculationEngine.deriveCycleMetrics(
            cycles = chitConfig.cycles,
            configuredTotalCycles = chitConfig.totalChits,
            currentChitNoOverride = chitConfig.currentChitNo
        )
    }
    val hasStarted = cycleMetrics.hasStartedOrCompletedCycles

    var totalMembersText by remember(chitConfig.totalMembers, chitConfig.totalChits) {
        mutableStateOf(
            chitConfig.totalMembers?.toString()
                ?: chitConfig.totalChits?.toString()
                ?: "20"
        )
    }
    var totalRoundsText by remember(chitConfig.totalChits) {
        mutableStateOf(chitConfig.totalChits?.toString() ?: "20")
    }
    var installmentAmountText by remember(chitConfig.monthlyInstallment) {
        mutableStateOf(chitConfig.monthlyInstallment?.toInt()?.toString() ?: "2500")
    }
    var totalValueText by remember(chitConfig.totalValue) {
        mutableStateOf(chitConfig.totalValue?.toInt()?.toString() ?: "50000")
    }
    var frequency by remember(chitConfig.frequency) {
        mutableStateOf(chitConfig.frequency.ifBlank { "MONTHLY" })
    }
    var auctionDayText by remember(chitConfig.auctionScheduleDay) {
        mutableStateOf(chitConfig.auctionScheduleDay?.toString() ?: "15")
    }
    var auctionTimeText by remember(chitConfig.auctionTime) {
        mutableStateOf(chitConfig.auctionTime ?: "08:00 PM")
    }
    var auctionDurationText by remember(chitConfig.auctionDurationMinutes) {
        mutableStateOf(chitConfig.auctionDurationMinutes.toString())
    }
    var minEligibilityText by remember(chitConfig.minEligibilityInstallments) {
        mutableStateOf(chitConfig.minEligibilityInstallments.toString())
    }

    // Mathematical consistency check
    val parsedMembers = totalMembersText.toIntOrNull()
    val parsedRounds = totalRoundsText.toIntOrNull()
    val parsedInstallment = installmentAmountText.toDoubleOrNull()
    val parsedTotalValue = totalValueText.toDoubleOrNull()

    val validationResult = remember(parsedMembers, parsedRounds, parsedInstallment, parsedTotalValue) {
        com.adr.groupledger.utils.ChitCalculationEngine.validateConfiguration(
            totalMembers = parsedMembers,
            totalCycles = parsedRounds,
            installmentAmount = parsedInstallment,
            totalChitValue = parsedTotalValue
        )
    }

    // Helper to generate updated ChitFundConfig with synchronized cycles
    fun syncAndNotifyConfig(
        newMembers: Int? = parsedMembers,
        newRounds: Int? = parsedRounds,
        newInstallment: Double? = parsedInstallment,
        newTotalVal: Double? = parsedTotalValue,
        newFreq: String = frequency,
        newAuctionDay: Int? = auctionDayText.toIntOrNull()?.coerceIn(1, 31),
        newAuctionTime: String = auctionTimeText.trim(),
        newAuctionDuration: Int = auctionDurationText.toIntOrNull() ?: 60,
        newEligibility: Int = minEligibilityText.toIntOrNull() ?: 1
    ) {
        val totalRounds = newRounds ?: 20
        val inst = newInstallment ?: 2500.0
        val startMillis = chitConfig.startDateMillis ?: System.currentTimeMillis()

        val generatedCycles = com.adr.groupledger.utils.ChitCalculationEngine.generateOrUpdateCycles(
            totalCycles = totalRounds,
            installmentAmount = inst,
            startDateMillis = startMillis,
            frequency = newFreq,
            existingCycles = chitConfig.cycles
        )

        val updated = chitConfig.copy(
            totalMembers = newMembers,
            totalChits = newRounds,
            monthlyInstallment = newInstallment,
            totalValue = newTotalVal,
            frequency = newFreq,
            auctionScheduleDay = newAuctionDay,
            auctionTime = newAuctionTime,
            auctionDurationMinutes = newAuctionDuration,
            minEligibilityInstallments = newEligibility,
            cycles = generatedCycles
        )
        onConfigChanged(updated)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("chit_fund_settings_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = IndigoPrimary.copy(alpha = 0.12f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Gavel,
                                contentDescription = null,
                                tint = IndigoPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Chit Fund / BC Scheme Settings",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Set up members, rounds, contributions and auction schedule",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Non-admin notification banner
            if (!isAdmin) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "View Only: Chit Fund configuration can only be modified by Group Administrators.",
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

            // Financial Summary & Calculation Preview
            val calcMembers = parsedMembers ?: 20
            val calcInst = parsedInstallment ?: 2500.0
            val calculatedExpectedPot = calcMembers * calcInst

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = IndigoPrimary.copy(alpha = 0.08f),
                border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.25f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Projected Total Scheme Pot",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = IndigoPrimary
                            )
                            Text(
                                text = "$calcMembers Members × $currencySymbol${calcInst.toInt()} per round",
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = CurrencyFormatter.format(calculatedExpectedPot, currencySymbol),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = IndigoPrimary
                        )
                    }

                    // Cycle progress indicator if cycles exist
                    if (cycleMetrics.totalCycles > 0) {
                        Text(
                            text = "Status: ${cycleMetrics.completedCycles} of ${cycleMetrics.totalCycles} rounds completed (${cycleMetrics.progressPercent}%) • ${cycleMetrics.remainingCycles} remaining",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Consistency Warning Banner if user entered mismatching total value
            if (validationResult.warningMessage != null) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Amber500.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, Amber500.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = Color(0xFFB45309),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = validationResult.warningMessage,
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // SECTION 1: Required Core Information
            Text(
                text = "Core Setup (Required)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = IndigoPrimary
            )

            // Input: Installment Amount
            Column {
                OutlinedTextField(
                    value = installmentAmountText,
                    onValueChange = {
                        if (!isAdmin || hasStarted) return@OutlinedTextField
                        installmentAmountText = it
                        val inst = it.toDoubleOrNull()
                        val members = totalMembersText.toIntOrNull() ?: 20
                        val autoPot = if (inst != null) inst * members else null
                        if (autoPot != null) {
                            totalValueText = autoPot.toInt().toString()
                        }
                        syncAndNotifyConfig(
                            newInstallment = inst,
                            newTotalVal = autoPot
                        )
                    },
                    label = { Text("How much will each member contribute? ($currencySymbol) *") },
                    leadingIcon = { Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    enabled = isAdmin && !hasStarted,
                    modifier = Modifier.fillMaxWidth().testTag("chit_installment_input"),
                    shape = RoundedCornerShape(10.dp)
                )
                if (hasStarted) {
                    Text(
                        text = "This setting cannot be changed after the first cycle starts.",
                        fontSize = 10.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 4.dp, top = 2.dp)
                    )
                }
            }

            // Inputs: Members & Rounds
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    OutlinedTextField(
                        value = totalMembersText,
                        onValueChange = {
                            if (!isAdmin || hasStarted) return@OutlinedTextField
                            totalMembersText = it
                            val members = it.toIntOrNull()
                            val inst = installmentAmountText.toDoubleOrNull() ?: 2500.0
                            val autoPot = if (members != null) members * inst else null
                            if (autoPot != null) {
                                totalValueText = autoPot.toInt().toString()
                            }
                            syncAndNotifyConfig(
                                newMembers = members,
                                newTotalVal = autoPot
                            )
                        },
                        label = { Text("Total Members *") },
                        leadingIcon = { Icon(Icons.Default.People, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        enabled = isAdmin && !hasStarted,
                        modifier = Modifier.fillMaxWidth().testTag("chit_total_members_input"),
                        shape = RoundedCornerShape(10.dp)
                    )
                    if (hasStarted) {
                        Text(
                            text = "Locked after start.",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(start = 4.dp, top = 2.dp)
                        )
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    OutlinedTextField(
                        value = totalRoundsText,
                        onValueChange = {
                            if (!isAdmin || hasStarted) return@OutlinedTextField
                            totalRoundsText = it
                            val rounds = it.toIntOrNull()
                            syncAndNotifyConfig(newRounds = rounds)
                        },
                        label = { Text("How many rounds? *") },
                        leadingIcon = { Icon(Icons.Default.TrendingUp, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        enabled = isAdmin && !hasStarted,
                        modifier = Modifier.fillMaxWidth().testTag("chit_total_chits_input"),
                        shape = RoundedCornerShape(10.dp)
                    )
                    if (hasStarted) {
                        Text(
                            text = "Locked after start.",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(start = 4.dp, top = 2.dp)
                        )
                    }
                }
            }

            // Total Chit Value override
            OutlinedTextField(
                value = totalValueText,
                onValueChange = {
                    if (!isAdmin || hasStarted) return@OutlinedTextField
                    totalValueText = it
                    syncAndNotifyConfig(newTotalVal = it.toDoubleOrNull())
                },
                label = { Text("Total Scheme Value ($currencySymbol)") },
                leadingIcon = { Icon(Icons.Default.AccountBalance, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                enabled = isAdmin && !hasStarted,
                modifier = Modifier.fillMaxWidth().testTag("chit_total_value_input"),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(2.dp))

            // SECTION 2: Optional Schedule & Auction Configuration
            Text(
                text = "Schedule & Auctions (Optional)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Contribution Frequency Chips
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "How often will members contribute?",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val frequencies = listOf("MONTHLY" to "Monthly", "WEEKLY" to "Weekly", "DAILY" to "Daily")
                    frequencies.forEach { (freqKey, freqLabel) ->
                        val isSelected = frequency.equals(freqKey, ignoreCase = true)
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                if (isAdmin && !hasStarted) {
                                    frequency = freqKey
                                    syncAndNotifyConfig(newFreq = freqKey)
                                }
                            },
                            label = { Text(freqLabel, fontSize = 11.5.sp) },
                            enabled = isAdmin && !hasStarted,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = IndigoPrimary.copy(alpha = 0.18f),
                                selectedLabelColor = IndigoPrimary
                            )
                        )
                    }
                }
            }

            // Auction Day & Auction Time (Safe to edit even after start)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = auctionDayText,
                    onValueChange = {
                        if (!isAdmin) return@OutlinedTextField
                        auctionDayText = it
                        val day = it.toIntOrNull()?.coerceIn(1, 31)
                        syncAndNotifyConfig(newAuctionDay = day)
                    },
                    label = { Text("Auction Day (1-31)") },
                    leadingIcon = { Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    enabled = isAdmin,
                    modifier = Modifier.weight(1f).testTag("chit_auction_day_input"),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = auctionTimeText,
                    onValueChange = {
                        if (!isAdmin) return@OutlinedTextField
                        auctionTimeText = it
                        syncAndNotifyConfig(newAuctionTime = it.trim())
                    },
                    label = { Text("Auction Time") },
                    placeholder = { Text("08:00 PM") },
                    leadingIcon = { Icon(Icons.Default.AccessTime, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp)) },
                    singleLine = true,
                    enabled = isAdmin,
                    modifier = Modifier.weight(1f).testTag("chit_auction_time_input"),
                    shape = RoundedCornerShape(10.dp)
                )
            }

            // Auction Duration & Basic Eligibility Foundation
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = auctionDurationText,
                    onValueChange = {
                        if (!isAdmin) return@OutlinedTextField
                        auctionDurationText = it
                        val dur = it.toIntOrNull() ?: 60
                        syncAndNotifyConfig(newAuctionDuration = dur)
                    },
                    label = { Text("Duration (mins)") },
                    leadingIcon = { Icon(Icons.Default.Timer, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    enabled = isAdmin,
                    modifier = Modifier.weight(1f).testTag("chit_auction_duration_input"),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = minEligibilityText,
                    onValueChange = {
                        if (!isAdmin) return@OutlinedTextField
                        minEligibilityText = it
                        val elig = it.toIntOrNull() ?: 1
                        syncAndNotifyConfig(newEligibility = elig)
                    },
                    label = { Text("Min. Paid Rounds to Bid") },
                    leadingIcon = { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    enabled = isAdmin,
                    modifier = Modifier.weight(1f).testTag("chit_eligibility_input"),
                    shape = RoundedCornerShape(10.dp)
                )
            }
        }
    }
}

/**
 * Authentic, non-faked Group Setup Progress Card.
 * Directly reflects whether basic info, group structure, financial rules, and admin info are completed.
 */
data class SettingsProgressSection(
    val title: String,
    val isComplete: Boolean,
    val detail: String
)

fun calculateGroupSetupProgress(
    groupName: String,
    category: GroupCategory,
    subCategory: String,
    isContributionEnabled: Boolean,
    defaultContribution: String,
    dueDayOfMonth: String,
    adminName: String,
    contactPhone: String,
    contactEmail: String,
    isChitFund: Boolean,
    chitConfig: ChitFundConfig
): Pair<Int, List<SettingsProgressSection>> {
    val basicInfoComplete = groupName.trim().isNotBlank()
    val structureComplete = category.subCategories.any { it.equals(subCategory, ignoreCase = true) }
    val financialComplete = if (isChitFund) {
        val installment = chitConfig.monthlyInstallment ?: defaultContribution.toDoubleOrNull()
        (installment != null && installment > 0.0) && (chitConfig.totalChits != null && chitConfig.totalChits!! > 0)
    } else {
        if (!isContributionEnabled) true else {
            val amt = defaultContribution.toDoubleOrNull()
            amt != null && amt > 0.0 && (dueDayOfMonth.toIntOrNull() in 1..31)
        }
    }
    val adminComplete = adminName.trim().isNotBlank() || contactPhone.trim().isNotBlank() || contactEmail.trim().isNotBlank()

    val sections = listOf(
        SettingsProgressSection(
            title = "Basic Information",
            isComplete = basicInfoComplete,
            detail = if (basicInfoComplete) groupName.trim() else "Group name required"
        ),
        SettingsProgressSection(
            title = "Group Structure",
            isComplete = structureComplete,
            detail = "${category.title} • $subCategory"
        ),
        SettingsProgressSection(
            title = if (isChitFund) "Chit Scheme Rules" else "Financial Rules",
            isComplete = financialComplete,
            detail = if (isChitFund) {
                if (financialComplete) "Installment: ₹${(chitConfig.monthlyInstallment ?: 0.0).toInt()} • ${chitConfig.totalChits ?: 0} Chits"
                else "Set installment & total chits"
            } else {
                if (financialComplete) "₹${defaultContribution.toDoubleOrNull()?.toInt() ?: 0} due by ${dueDayOfMonth}th"
                else "Set contribution amount & due day"
            }
        ),
        SettingsProgressSection(
            title = "Administration",
            isComplete = adminComplete,
            detail = if (adminComplete) "Contact & Admin set" else "Optional admin details"
        )
    )

    val completedCount = sections.count { it.isComplete }
    val progressPercent = (completedCount * 100) / sections.size
    return Pair(progressPercent, sections)
}

@Composable
fun GroupSetupProgressCard(
    progressPercent: Int,
    sections: List<SettingsProgressSection>,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
            .testTag("group_setup_progress_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Group Configuration Status",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (progressPercent == 100) "All configuration sections completed" else "$progressPercent% complete • Tap to view details",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (progressPercent == 100) Emerald500 else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.5.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (progressPercent == 100) Emerald500.copy(alpha = 0.15f) else IndigoPrimary.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "$progressPercent%",
                        fontWeight = FontWeight.Bold,
                        color = if (progressPercent == 100) Emerald500 else IndigoPrimary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            LinearProgressIndicator(
                progress = { progressPercent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (progressPercent == 100) Emerald500 else IndigoPrimary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    sections.forEach { section ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = if (section.isComplete) Icons.Default.CheckCircle else Icons.Default.Schedule,
                                    contentDescription = null,
                                    tint = if (section.isComplete) Emerald500 else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = section.title,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = section.detail,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (section.isComplete) Emerald500.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = if (section.isComplete) "Completed" else "Pending",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (section.isComplete) Emerald500 else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
