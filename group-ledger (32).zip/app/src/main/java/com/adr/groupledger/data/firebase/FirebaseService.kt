package com.adr.groupledger.data.firebase

import android.content.Context
import android.util.Log
import com.adr.groupledger.data.model.AppUpdateInfo
import com.adr.groupledger.data.model.GroupFeedback
import com.adr.groupledger.data.model.GroupChatMessage
import com.adr.groupledger.data.model.GroupJoinRequest
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.LoanRequest
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.Payment
import com.adr.groupledger.data.model.PreAuthorizedMember
import com.adr.groupledger.data.model.SocietyNotice
import com.adr.groupledger.data.model.TransactionRecord
import com.adr.groupledger.data.model.UserAccount
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Source
import kotlinx.coroutines.tasks.await

/**
 * FirebaseService provides real-time Firebase Authentication (Email & Password, Password Reset)
 * and Cloud Firestore real-time synchronization for Users, Groups, Members, and Ledger Transactions.
 */
class FirebaseService(private val context: Context) {

    private val TAG = "FirebaseService"

    private val auth: FirebaseAuth? by lazy {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }
            AppCheckInitializer.initialize(context)
            FirebaseAuth.getInstance()
        } catch (e: Exception) {
            Log.w(TAG, "FirebaseAuth initialization: ${e.message}")
            null
        }
    }

    private val firestore: FirebaseFirestore? by lazy {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }
            AppCheckInitializer.initialize(context)
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.w(TAG, "FirebaseFirestore initialization: ${e.message}")
            null
        }
    }

    val isFirebaseAvailable: Boolean
        get() = auth != null && firestore != null

    val currentFirebaseUser: FirebaseUser?
        get() = auth?.currentUser

    // -------------------------------------------------------------
    // Firebase Authentication: Email & Password, Reset
    // -------------------------------------------------------------

    suspend fun signUpWithEmail(
        email: String,
        password: String,
        displayName: String,
        phone: String = ""
    ): Result<UserAccount> {
        val trimmedEmail = email.trim()
        val trimmedPhone = phone.trim()
        val authInstance = auth
        if (authInstance == null) {
            val fallbackUser = UserAccount(
                fullName = displayName.trim(),
                email = trimmedEmail,
                phone = trimmedPhone,
                passwordHash = password,
                isAccountCompleted = true
            )
            return Result.success(fallbackUser)
        }

        return try {
            val result = authInstance.createUserWithEmailAndPassword(trimmedEmail, password).await()
            val firebaseUser = result.user

            if (firebaseUser != null && displayName.isNotBlank()) {
                try {
                    val profileUpdates = UserProfileChangeRequest.Builder()
                        .setDisplayName(displayName.trim())
                        .build()
                    firebaseUser.updateProfile(profileUpdates).await()
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to update Firebase display name: ${e.message}")
                }
            }

            val userAccount = UserAccount(
                id = (firebaseUser?.uid.hashCode().toLong() and 0x7FFFFFFFFFFFFFFFL).coerceAtLeast(1L),
                fullName = displayName.trim().ifBlank { firebaseUser?.displayName ?: "Member" },
                email = trimmedEmail,
                phone = trimmedPhone.ifBlank { firebaseUser?.phoneNumber ?: "" },
                passwordHash = "FIREBASE_AUTH_SECURED",
                isAccountCompleted = true
            )

            // Save user profile to Cloud Firestore
            saveUser(userAccount)

            Result.success(userAccount)
        } catch (e: Exception) {
            Log.e(TAG, "Firebase signUp error", e)
            Result.failure(e)
        }
    }

    suspend fun signInWithEmail(
        email: String,
        password: String
    ): Result<UserAccount> {
        val trimmedEmail = email.trim()
        val authInstance = auth
        if (authInstance == null) {
            val fallbackUser = UserAccount(
                fullName = trimmedEmail.substringBefore("@").replaceFirstChar { it.uppercase() },
                email = trimmedEmail,
                passwordHash = password,
                isAccountCompleted = true
            )
            return Result.success(fallbackUser)
        }

        return try {
            val result = authInstance.signInWithEmailAndPassword(trimmedEmail, password).await()
            val firebaseUser = result.user

            val userAccount = UserAccount(
                id = (firebaseUser?.uid.hashCode().toLong() and 0x7FFFFFFFFFFFFFFFL).coerceAtLeast(1L),
                fullName = firebaseUser?.displayName ?: trimmedEmail.substringBefore("@").replaceFirstChar { it.uppercase() },
                email = firebaseUser?.email ?: trimmedEmail,
                phone = firebaseUser?.phoneNumber ?: "",
                passwordHash = "FIREBASE_AUTH_SECURED",
                isAccountCompleted = true
            )

            // Sync user profile to Cloud Firestore
            saveUser(userAccount)

            Result.success(userAccount)
        } catch (e: Exception) {
            Log.e(TAG, "Firebase signIn error", e)
            Result.failure(e)
        }
    }

    suspend fun sendPasswordResetEmail(email: String): Result<Unit> {
        val trimmedEmail = email.trim()
        val authInstance = auth
        if (authInstance == null) {
            return Result.success(Unit)
        }

        return try {
            authInstance.sendPasswordResetEmail(trimmedEmail).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Firebase sendPasswordResetEmail error", e)
            Result.failure(e)
        }
    }

    fun signOut() {
        try {
            auth?.signOut()
        } catch (e: Exception) {
            Log.w(TAG, "Sign out error", e)
        }
    }

    /**
     * Inspects Firebase Authentication ID token claims for server-granted application-level admin privileges.
     * Note: Custom Claims can only be granted by a secure server environment or Firebase Admin SDK.
     */
    suspend fun isServerAppAdminClaimPresent(): Boolean {
        return try {
            val user = auth?.currentUser ?: return false
            val tokenResult = user.getIdToken(false).await()
            val claims = tokenResult.claims
            claims["app_admin"] == true ||
            claims["appRole"]?.toString().equals("APP_ADMIN", ignoreCase = true)
        } catch (e: Exception) {
            Log.w(TAG, "isServerAppAdminClaimPresent: ${e.message}")
            false
        }
    }

    /**
     * Reads the application-level role string from Firebase ID token custom claims.
     */
    suspend fun getServerAppRole(): String? {
        return try {
            val user = auth?.currentUser ?: return null
            val tokenResult = user.getIdToken(false).await()
            tokenResult.claims["appRole"]?.toString()
        } catch (e: Exception) {
            null
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Users
    // -------------------------------------------------------------

    suspend fun saveUser(user: UserAccount) {
        val db = firestore ?: return
        if (user.id <= 0L) {
            Log.w(TAG, "Firestore saveUser rejected: invalid userId ${user.id}")
            return
        }
        try {
            val currentAuthUid = auth?.currentUser?.uid ?: user.id.toString()
            val map = hashMapOf(
                "id" to user.id,
                "uid" to currentAuthUid,
                "fullName" to user.fullName,
                "email" to user.email,
                "phone" to user.phone,
                "avatarUri" to user.avatarUri,
                "isAccountCompleted" to user.isAccountCompleted,
                "createdAt" to user.createdAt
            )
            db.collection("users").document(user.id.toString()).set(map, SetOptions.merge()).await()
            if (currentAuthUid.isNotBlank() && currentAuthUid != user.id.toString()) {
                db.collection("users").document(currentAuthUid).set(map, SetOptions.merge()).await()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveUser error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Groups
    // -------------------------------------------------------------

    suspend fun saveGroup(group: GroupSettings) {
        val db = firestore ?: return
        if (group.id <= 0L) {
            Log.w(TAG, "Firestore saveGroup rejected: invalid groupId ${group.id}")
            return
        }
        try {
            // Phase 11 — Task 5: Attach authenticated Firebase auth.uid to document payload
            val currentAuthUid = auth?.currentUser?.uid ?: ""
            val resolvedOwnerUid = when {
                group.ownerUid.isNotBlank() -> group.ownerUid
                currentAuthUid.isNotBlank() -> currentAuthUid
                group.createdByUserId > 0L -> group.createdByUserId.toString()
                else -> ""
            }

            val map = hashMapOf(
                "id" to group.id,
                "groupName" to group.groupName,
                "groupSubtitle" to group.groupSubtitle,
                "description" to group.description,
                "groupType" to group.groupType,
                "address" to group.address,
                "contactPhone" to group.contactPhone,
                "contactEmail" to group.contactEmail,
                "createdAt" to group.createdAt,
                "logoUri" to group.logoUri,
                "inviteCode" to group.inviteCode,
                "createdByUserId" to group.createdByUserId,
                "ownerUid" to resolvedOwnerUid,
                "creatorUid" to resolvedOwnerUid,
                "isContributionEnabled" to group.isContributionEnabled,
                "defaultContribution" to group.defaultContribution,
                "contributionFrequency" to group.contributionFrequency,
                "dueDayOfMonth" to group.dueDayOfMonth,
                "isLateFeeEnabled" to group.isLateFeeEnabled,
                "lateFineAmount" to group.lateFineAmount,
                "gracePeriodDays" to group.gracePeriodDays,
                "paymentRules" to group.paymentRules,
                "modulesConfigJson" to group.modulesConfigJson,
                "currencySymbol" to group.currencySymbol,
                "financialYearStartMonth" to group.financialYearStartMonth,
                "adminName" to group.adminName,
                "adminPhone" to group.adminPhone,
                "adminPin" to group.adminPin,
                "isPinLockEnabled" to group.isPinLockEnabled,
                "themeMode" to group.themeMode,
                "updatedAt" to System.currentTimeMillis()
            )
            db.collection("groups").document(group.id.toString()).set(map, SetOptions.merge()).await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveGroup error: ${e.message}")
        }
    }

    /**
     * Phase 11 — Task 4 & Task 5: Enforces strict sequential ordering and UID ownership validation for group provisioning.
     * Step 1: Parent group document is written and committed FIRST with non-blank ownerUid / creatorId.
     * Step 2: Only after Step 1 completes, the admin member record is written under
     *         groups/{groupId}/members/{memberId} with strict groupId scoping.
     */
    suspend fun provisionGroupSequentially(group: GroupSettings, adminMember: Member): Boolean {
        val db = firestore ?: return false
        if (group.id <= 0L) {
            Log.w(TAG, "Cannot provision group with invalid groupId: ${group.id}")
            return false
        }
        if (adminMember.id <= 0L || adminMember.groupId <= 0L || adminMember.groupId != group.id) {
            Log.w(TAG, "Cannot provision member with unscoped, unassigned, or mismatched id/groupId: member.id=${adminMember.id}, member.groupId=${adminMember.groupId}, group.id=${group.id}")
            return false
        }
        val currentUid = auth?.currentUser?.uid ?: ""
        val resolvedOwnerUid = if (group.ownerUid.isNotBlank()) group.ownerUid else currentUid
        if (resolvedOwnerUid.isBlank() && group.createdByUserId <= 0L) {
            Log.w(TAG, "Cannot provision group without valid ownerUid or creator numeric ID")
            return false
        }

        return try {
            // Ensure group carries the resolved ownerUid
            val groupToSave = if (group.ownerUid.isBlank() && resolvedOwnerUid.isNotBlank()) {
                group.copy(ownerUid = resolvedOwnerUid)
            } else {
                group
            }

            // Step 1: Write and await parent group settings
            saveGroup(groupToSave)

            // Step 2: Only after Step 1 completes, write creator's member record
            saveMember(adminMember)
            true
        } catch (e: Exception) {
            Log.w(TAG, "Failed to provision group sequentially: ${e.message}")
            false
        }
    }

    /**
     * Phase 11 — Task 5: Query groups owned or created by an authenticated Firebase UID.
     * Searches by 'ownerUid' and fallback 'creatorUid'.
     */
    suspend fun getGroupsByOwnerUid(authUid: String? = null): List<GroupSettings> {
        val db = firestore ?: return emptyList()
        val targetUid = authUid?.takeIf { it.isNotBlank() } ?: auth?.currentUser?.uid
        if (targetUid.isNullOrBlank()) {
            Log.w(TAG, "getGroupsByOwnerUid rejected: no valid auth UID provided or logged in")
            return emptyList()
        }

        return try {
            val querySnapshot = db.collection("groups")
                .whereEqualTo("ownerUid", targetUid)
                .get()
                .await()

            val docs = if (querySnapshot.isEmpty) {
                db.collection("groups")
                    .whereEqualTo("creatorUid", targetUid)
                    .get()
                    .await()
                    .documents
            } else {
                querySnapshot.documents
            }

            docs.mapNotNull { doc ->
                try {
                    val id = doc.getLong("id") ?: doc.id.toLongOrNull() ?: return@mapNotNull null
                    GroupSettings(
                        id = id,
                        groupName = doc.getString("groupName") ?: "Group",
                        groupSubtitle = doc.getString("groupSubtitle") ?: "",
                        description = doc.getString("description") ?: "",
                        groupType = doc.getString("groupType") ?: "Self-Help Group",
                        address = doc.getString("address") ?: "",
                        contactPhone = doc.getString("contactPhone") ?: "",
                        contactEmail = doc.getString("contactEmail") ?: "",
                        createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis(),
                        logoUri = doc.getString("logoUri") ?: "",
                        inviteCode = doc.getString("inviteCode") ?: "SAMITI-$id",
                        createdByUserId = doc.getLong("createdByUserId") ?: 1L,
                        ownerUid = doc.getString("ownerUid") ?: doc.getString("creatorUid") ?: targetUid,
                        isContributionEnabled = doc.getBoolean("isContributionEnabled") ?: true,
                        defaultContribution = doc.getDouble("defaultContribution") ?: 500.0,
                        contributionFrequency = doc.getString("contributionFrequency") ?: "MONTHLY",
                        dueDayOfMonth = (doc.getLong("dueDayOfMonth") ?: 10).toInt(),
                        isLateFeeEnabled = doc.getBoolean("isLateFeeEnabled") ?: false,
                        lateFineAmount = doc.getDouble("lateFineAmount") ?: 0.0,
                        gracePeriodDays = (doc.getLong("gracePeriodDays") ?: 5).toInt(),
                        paymentRules = doc.getString("paymentRules") ?: "",
                        modulesConfigJson = doc.getString("modulesConfigJson") ?: "",
                        currencySymbol = doc.getString("currencySymbol") ?: "₹",
                        financialYearStartMonth = (doc.getLong("financialYearStartMonth") ?: 4).toInt(),
                        adminName = doc.getString("adminName") ?: "Society Treasurer",
                        adminPhone = doc.getString("adminPhone") ?: "",
                        adminPin = doc.getString("adminPin") ?: "1234",
                        isPinLockEnabled = doc.getBoolean("isPinLockEnabled") ?: false,
                        themeMode = doc.getString("themeMode") ?: "SYSTEM"
                    )
                } catch (e: Exception) {
                    null
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firestore getGroupsByOwnerUid error: ${e.message}")
            emptyList()
        }
    }

    /**
     * Phase 11 — Task 5: Validates whether an authenticated Firebase UID owns the given group.
     * Compares the user's string UID against ownerUid / creatorUid and handles numeric mapping.
     */
    fun verifyGroupOwnership(group: GroupSettings, authUid: String?, numericUserId: Long? = null): Boolean {
        if (authUid.isNullOrBlank()) return false
        val trimmedAuthUid = authUid.trim()
        if (trimmedAuthUid.isBlank()) return false

        // Exact match on ownerUid / creatorUid
        if (group.ownerUid.isNotBlank() && group.ownerUid == trimmedAuthUid) {
            return true
        }
        if (group.creatorUid.isNotBlank() && group.creatorUid == trimmedAuthUid) {
            return true
        }

        // Numeric conversion/mapping consistency check
        if (numericUserId != null && numericUserId > 0L && group.createdByUserId == numericUserId) {
            if (trimmedAuthUid == numericUserId.toString()) {
                return true
            }
        }

        return false
    }

    /**
     * Phase 11 — Task 7: Validates authorization before initiating group deletion.
     * Strictly verifies that requesterAuthUid matches ownerUid, creatorUid, or createdByUserId.
     */
    fun verifyGroupDeletionAuthorization(group: GroupSettings, requesterAuthUid: String): Result<Unit> {
        if (group.id <= 0L) {
            return Result.failure(IllegalArgumentException("Invalid groupId: ${group.id}"))
        }
        if (requesterAuthUid.isBlank()) {
            return Result.failure(SecurityException("Requester Auth UID cannot be blank"))
        }
        val trimmed = requesterAuthUid.trim()
        val isOwner = (group.ownerUid.isNotBlank() && group.ownerUid == trimmed) ||
                (group.creatorUid.isNotBlank() && group.creatorUid == trimmed) ||
                (group.createdByUserId > 0L && group.createdByUserId.toString() == trimmed)

        return if (isOwner) {
            Result.success(Unit)
        } else {
            Result.failure(SecurityException("User $trimmed is not authorized to delete group ${group.id}"))
        }
    }

    /**
     * Phase 11 — Task 7: Target subcollections required for complete cascading teardown.
     */
    fun getGroupTeardownTargetSubcollections(): List<String> {
        return FirestoreSecurityAudit.getAllGroupSubcollections()
    }

    fun getGroupTeardownDocumentPath(groupId: Long): String {
        return "groups/$groupId"
    }

    fun getGroupSubcollectionPath(groupId: Long, subcollection: String): String {
        return "groups/$groupId/$subcollection"
    }

    /**
     * Phase 11 — Task 7: Complete Group Cascading Teardown.
     * Recursively deletes all documents across all group subcollections using batched writes
     * before deleting the parent group document itself.
     * Enforces strict authorization: only verified owner/creator can delete.
     */
    suspend fun deleteGroupCompletely(groupId: Long, requesterAuthUid: String): Result<Boolean> {
        if (groupId <= 0L) {
            return Result.failure(IllegalArgumentException("Invalid groupId: $groupId"))
        }
        if (requesterAuthUid.isBlank()) {
            return Result.failure(SecurityException("Requester Auth UID cannot be blank"))
        }

        val db = firestore ?: run {
            Log.w(TAG, "Firestore not initialized for deleteGroupCompletely; returning simulated success")
            return Result.success(true)
        }

        return try {
            val groupDocRef = db.collection("groups").document(groupId.toString())
            val groupSnapshot = groupDocRef.get().await()

            if (!groupSnapshot.exists()) {
                Log.w(TAG, "Group $groupId does not exist on Firestore; skipping remote deletion")
                return Result.success(true)
            }

            // Verify ownership: requester must match ownerUid, creatorUid, or createdByUserId string
            val ownerUid = groupSnapshot.getString("ownerUid")?.trim() ?: ""
            val creatorUid = groupSnapshot.getString("creatorUid")?.trim() ?: ""
            val createdByUserId = groupSnapshot.getLong("createdByUserId")

            val trimmedRequester = requesterAuthUid.trim()
            val isAuthorized = (ownerUid.isNotBlank() && ownerUid == trimmedRequester) ||
                    (creatorUid.isNotBlank() && creatorUid == trimmedRequester) ||
                    (createdByUserId != null && createdByUserId > 0L && createdByUserId.toString() == trimmedRequester)

            if (!isAuthorized) {
                val errorMsg = "Unauthorized: requester $requesterAuthUid is not the owner/creator of group $groupId (owner=$ownerUid, creator=$creatorUid)"
                Log.w(TAG, errorMsg)
                return Result.failure(SecurityException(errorMsg))
            }

            // Subcollections to delete in batched writes
            val subcollections = listOf(
                "members",
                "transactions",
                "payments",
                "loans",
                "notices",
                "pendingRequests",
                "preAuthorizedMembers",
                "chatMessages",
                "auditLogs",
                "investments",
                "feedbacks"
            )

            for (subcolName in subcollections) {
                try {
                    val subcolDocs = groupDocRef.collection(subcolName).get().await()
                    if (!subcolDocs.isEmpty) {
                        var batch = db.batch()
                        var count = 0
                        for (doc in subcolDocs.documents) {
                            batch.delete(doc.reference)
                            count++
                            if (count >= 400) {
                                batch.commit().await()
                                batch = db.batch()
                                count = 0
                            }
                        }
                        if (count > 0) {
                            batch.commit().await()
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Error deleting subcollection $subcolName for group $groupId: ${e.message}")
                }
            }

            // Finally, delete the parent group document
            groupDocRef.delete().await()
            Log.i(TAG, "Group $groupId and all subcollections deleted completely by $requesterAuthUid")
            Result.success(true)
        } catch (e: Exception) {
            Log.e(TAG, "deleteGroupCompletely failed for group $groupId: ${e.message}", e)
            Result.failure(e)
        }
    }
    // Cloud Firestore Sync: Members
    // -------------------------------------------------------------

    suspend fun saveMember(member: Member) {
        val db = firestore ?: return
        if (member.groupId <= 0L || member.id <= 0L) {
            Log.w(TAG, "Firestore saveMember rejected: unscoped or invalid member (groupId=${member.groupId}, memberId=${member.id})")
            return
        }
        try {
            val map = hashMapOf(
                "id" to member.id,
                "groupId" to member.groupId,
                "memberCode" to member.memberCode,
                "name" to member.name,
                "email" to member.email,
                "phone" to member.phone,
                "address" to member.address,
                "joinDate" to member.joinDate,
                "monthlyContribution" to member.monthlyContribution,
                "photoUri" to member.photoUri,
                "isActive" to member.isActive,
                "isClaimed" to member.isClaimed,
                "linkedUid" to member.linkedUid,
                "notes" to member.notes,
                "dateOfBirth" to member.dateOfBirth
            )
            db.collection("groups")
                .document(member.groupId.toString())
                .collection("members")
                .document(member.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveMember error: ${e.message}")
        }
    }

    suspend fun deleteMember(groupId: Long, memberId: Long, memberAuthUid: String? = null) {
        removeMemberFromGroup(groupId, memberId, memberAuthUid)
    }

    /**
     * Phase 11 — Task 7: Member Removal & Group Leave Logic.
     * Deletes the member document from groups/{groupId}/members/{memberId} and
     * cleanly removes the member's Auth UID from the parent group's activeMemberUids array.
     */
    suspend fun removeMemberFromGroup(
        groupId: Long,
        memberId: Long,
        memberAuthUid: String? = null
    ): Result<Boolean> {
        val db = firestore ?: return Result.success(true)
        if (groupId <= 0L || (memberId <= 0L && memberAuthUid.isNullOrBlank())) {
            Log.w(TAG, "Firestore removeMemberFromGroup rejected: invalid parameters (groupId=$groupId, memberId=$memberId)")
            return Result.failure(IllegalArgumentException("Invalid groupId ($groupId) or memberId/authUid"))
        }

        return try {
            val groupDocRef = db.collection("groups").document(groupId.toString())
            var uidToRemove = memberAuthUid?.trim()

            if (memberId > 0L) {
                val memberDocRef = groupDocRef.collection("members").document(memberId.toString())
                if (uidToRemove.isNullOrBlank()) {
                    try {
                        val snap = memberDocRef.get().await()
                        if (snap.exists()) {
                            uidToRemove = snap.getString("linkedUid")?.trim()
                        }
                    } catch (e: Exception) {
                        // ignore
                    }
                }
                memberDocRef.delete().await()
            }

            // Remove member's Auth UID from parent group's activeMemberUids array if present
            if (!uidToRemove.isNullOrBlank()) {
                try {
                    groupDocRef.update("activeMemberUids", FieldValue.arrayRemove(uidToRemove)).await()
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to remove $uidToRemove from activeMemberUids: ${e.message}")
                }
            }

            Result.success(true)
        } catch (e: Exception) {
            Log.w(TAG, "Firestore removeMemberFromGroup error: ${e.message}")
            Result.failure(e)
        }
    }

    /**
     * Voluntary member departure: leaves the specified group cleanly.
     */
    suspend fun leaveGroup(groupId: Long, memberId: Long, userAuthUid: String): Result<Boolean> {
        return removeMemberFromGroup(groupId, memberId, userAuthUid)
    }

    suspend fun getMembers(groupId: Long): List<Member> {
        val db = firestore ?: return emptyList()
        val resultList = mutableListOf<Member>()
        try {
            val snapshots = db.collection("groups")
                .document(groupId.toString())
                .collection("members")
                .get()
                .await()

            snapshots.documents.mapNotNullTo(resultList) { doc ->
                try {
                    Member(
                        id = doc.getLong("id") ?: (doc.id.toLongOrNull() ?: 0L),
                        groupId = doc.getLong("groupId") ?: groupId,
                        memberCode = doc.getString("memberCode") ?: "",
                        name = doc.getString("name") ?: "",
                        phone = doc.getString("phone") ?: "",
                        address = doc.getString("address") ?: "",
                        joinDate = doc.getLong("joinDate") ?: System.currentTimeMillis(),
                        monthlyContribution = doc.getDouble("monthlyContribution") ?: 0.0,
                        photoUri = doc.getString("photoUri") ?: "",
                        isActive = doc.getBoolean("isActive") ?: true,
                        notes = doc.getString("notes") ?: "",
                        email = doc.getString("email") ?: "",
                        isClaimed = doc.getBoolean("isClaimed") ?: false,
                        linkedUid = doc.getString("linkedUid") ?: "",
                        dateOfBirth = doc.getString("dateOfBirth") ?: ""
                    )
                } catch (e: Exception) {
                    null
                }
            }

            val groupDoc = db.collection("groups").document(groupId.toString()).get().await()
            val rawArray = groupDoc.get("members") as? List<*>
            rawArray?.forEach { item ->
                if (item is Map<*, *>) {
                    try {
                        val mId = (item["id"] as? Number)?.toLong() ?: 0L
                        if (resultList.none { it.id == mId }) {
                            resultList.add(
                                Member(
                                    id = mId,
                                    groupId = (item["groupId"] as? Number)?.toLong() ?: groupId,
                                    memberCode = item["memberCode"] as? String ?: "",
                                    name = item["name"] as? String ?: "",
                                    phone = item["phone"] as? String ?: "",
                                    address = item["address"] as? String ?: "",
                                    joinDate = (item["joinDate"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                                    monthlyContribution = (item["monthlyContribution"] as? Number)?.toDouble() ?: 0.0,
                                    photoUri = item["photoUri"] as? String ?: "",
                                    isActive = item["isActive"] as? Boolean ?: true,
                                    notes = item["notes"] as? String ?: "",
                                    email = item["email"] as? String ?: "",
                                    isClaimed = item["isClaimed"] as? Boolean ?: false,
                                    linkedUid = item["linkedUid"] as? String ?: "",
                                    dateOfBirth = item["dateOfBirth"] as? String ?: ""
                                )
                            )
                        }
                    } catch (e: Exception) {
                        // ignore malformed member array element
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firestore getMembers error: ${e.message}")
        }
        return resultList
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Payments (Ledger Dues)
    // -------------------------------------------------------------

    suspend fun savePayment(payment: Payment) {
        val db = firestore ?: return
        if (payment.groupId <= 0L || payment.id <= 0L) {
            Log.w(TAG, "Firestore savePayment rejected: unscoped or invalid payment (groupId=${payment.groupId}, paymentId=${payment.id})")
            return
        }
        try {
            val map = hashMapOf(
                "id" to payment.id,
                "groupId" to payment.groupId,
                "memberId" to payment.memberId,
                "month" to payment.month,
                "year" to payment.year,
                "expectedAmount" to payment.expectedAmount,
                "paidAmount" to payment.paidAmount,
                "dueAmount" to payment.dueAmount,
                "paymentDate" to payment.paymentDate,
                "paymentMethod" to payment.paymentMethod,
                "transactionReference" to payment.transactionReference,
                "notes" to payment.notes,
                "status" to payment.status,
                "approvalStatus" to payment.approvalStatus,
                "rejectionReason" to payment.rejectionReason,
                "approvedAt" to (payment.approvedAt ?: 0L),
                "approvedBy" to payment.approvedBy,
                "submittedAt" to payment.submittedAt
            )
            db.collection("groups")
                .document(payment.groupId.toString())
                .collection("payments")
                .document(payment.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore savePayment error: ${e.message}")
        }
    }

    suspend fun deletePayment(groupId: Long, paymentId: Long) {
        val db = firestore ?: return
        if (groupId <= 0L || paymentId <= 0L) {
            Log.w(TAG, "Firestore deletePayment rejected: invalid parameters (groupId=$groupId, paymentId=$paymentId)")
            return
        }
        try {
            db.collection("groups")
                .document(groupId.toString())
                .collection("payments")
                .document(paymentId.toString())
                .delete()
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore deletePayment error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Transactions (Income / Expense Ledger)
    // -------------------------------------------------------------

    suspend fun saveTransaction(tx: TransactionRecord) {
        val db = firestore ?: return
        if (tx.groupId <= 0L || tx.id <= 0L) {
            Log.w(TAG, "Firestore saveTransaction rejected: unscoped or invalid transaction (groupId=${tx.groupId}, txId=${tx.id})")
            return
        }
        try {
            val map = hashMapOf(
                "id" to tx.id,
                "groupId" to tx.groupId,
                "txnNumber" to tx.txnNumber,
                "date" to tx.date,
                "amount" to tx.amount,
                "type" to tx.type,
                "isCredit" to tx.isCredit,
                "description" to tx.description,
                "paymentMethod" to tx.paymentMethod,
                "relatedMemberId" to (tx.relatedMemberId ?: 0L),
                "relatedMemberName" to (tx.relatedMemberName ?: ""),
                "relatedLoanId" to (tx.relatedLoanId ?: 0L),
                "relatedInvestmentId" to (tx.relatedInvestmentId ?: 0L),
                "createdBy" to tx.createdBy
            )
            db.collection("groups")
                .document(tx.groupId.toString())
                .collection("transactions")
                .document(tx.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveTransaction error: ${e.message}")
        }
    }

    suspend fun deleteTransaction(groupId: Long, txId: Long) {
        val db = firestore ?: return
        if (groupId <= 0L || txId <= 0L) {
            Log.w(TAG, "Firestore deleteTransaction rejected: invalid parameters (groupId=$groupId, txId=$txId)")
            return
        }
        try {
            db.collection("groups")
                .document(groupId.toString())
                .collection("transactions")
                .document(txId.toString())
                .delete()
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore deleteTransaction error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Notices
    // -------------------------------------------------------------

    suspend fun saveNotice(notice: SocietyNotice) {
        val db = firestore ?: return
        if (notice.groupId <= 0L || notice.id <= 0L) {
            Log.w(TAG, "Firestore saveNotice rejected: unscoped or invalid notice (groupId=${notice.groupId}, noticeId=${notice.id})")
            return
        }
        try {
            val map = hashMapOf(
                "id" to notice.id,
                "groupId" to notice.groupId,
                "title" to notice.title,
                "content" to notice.content,
                "category" to notice.category,
                "author" to notice.author,
                "timestamp" to notice.timestamp,
                "isPinned" to notice.isPinned,
                "isPollEnabled" to notice.isPollEnabled,
                "pollOptions" to notice.pollOptions,
                "pollExpiryDate" to notice.pollExpiryDate,
                "pollVotesJson" to notice.pollVotesJson
            )
            db.collection("groups")
                .document(notice.groupId.toString())
                .collection("notices")
                .document(notice.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveNotice error: ${e.message}")
        }
    }

    suspend fun voteOnNoticePoll(groupId: Long, noticeId: Long, memberId: Long, option: String) {
        val db = firestore ?: return
        if (groupId <= 0L || noticeId <= 0L || memberId <= 0L) {
            Log.w(TAG, "Firestore voteOnNoticePoll rejected: invalid parameters (groupId=$groupId, noticeId=$noticeId, memberId=$memberId)")
            return
        }
        try {
            val docRef = db.collection("groups")
                .document(groupId.toString())
                .collection("notices")
                .document(noticeId.toString())
            
            db.runTransaction { transaction ->
                val snapshot = transaction.get(docRef)
                if (snapshot.exists()) {
                    val currentVotesJson = snapshot.getString("pollVotesJson") ?: "{}"
                    val votesMap = try {
                        val obj = org.json.JSONObject(currentVotesJson)
                        val map = mutableMapOf<String, String>()
                        val keys = obj.keys()
                        while (keys.hasNext()) {
                            val k = keys.next()
                            map[k] = obj.getString(k)
                        }
                        map
                    } catch (e: Exception) {
                        mutableMapOf<String, String>()
                    }
                    votesMap[memberId.toString()] = option
                    val newObj = org.json.JSONObject()
                    votesMap.forEach { (k, v) -> newObj.put(k, v) }
                    transaction.update(docRef, "pollVotesJson", newObj.toString())
                }
                null
            }.await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore voteOnNoticePoll error: ${e.message}")
        }
    }

    suspend fun deleteNotice(groupId: Long, noticeId: Long) {
        val db = firestore ?: return
        if (groupId <= 0L || noticeId <= 0L) {
            Log.w(TAG, "Firestore deleteNotice rejected: invalid parameters (groupId=$groupId, noticeId=$noticeId)")
            return
        }
        try {
            db.collection("groups")
                .document(groupId.toString())
                .collection("notices")
                .document(noticeId.toString())
                .delete()
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore deleteNotice error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Loans
    // -------------------------------------------------------------

    suspend fun saveLoan(loan: LoanRequest) {
        val db = firestore ?: return
        if (loan.groupId <= 0L || loan.id <= 0L) {
            Log.w(TAG, "Firestore saveLoan rejected: unscoped or invalid loan (groupId=${loan.groupId}, loanId=${loan.id})")
            return
        }
        try {
            val map = hashMapOf(
                "id" to loan.id,
                "groupId" to loan.groupId,
                "requesterMemberId" to loan.requesterMemberId,
                "requesterName" to loan.requesterName,
                "requesterPhone" to loan.requesterPhone,
                "requestedAmount" to loan.requestedAmount,
                "purpose" to loan.purpose,
                "reason" to loan.reason,
                "duration" to loan.duration,
                "durationUnit" to loan.durationUnit,
                "expectedRepaymentDate" to loan.expectedRepaymentDate,
                "note" to loan.note,
                "createdAt" to loan.createdAt,
                "votingDeadline" to loan.votingDeadline,
                "status" to loan.status,
                "disbursedDate" to (loan.disbursedDate ?: 0L),
                "disbursedBy" to (loan.disbursedBy ?: ""),
                "repaidAmount" to loan.repaidAmount,
                "remainingAmount" to loan.remainingAmount
            )
            db.collection("groups")
                .document(loan.groupId.toString())
                .collection("loans")
                .document(loan.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveLoan error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Chat Messages
    // -------------------------------------------------------------

    suspend fun saveChatMessage(msg: GroupChatMessage) {
        val db = firestore ?: return
        if (msg.groupId <= 0L || msg.id <= 0L) {
            Log.w(TAG, "Firestore saveChatMessage rejected: unscoped or invalid message (groupId=${msg.groupId}, messageId=${msg.id})")
            return
        }
        try {
            val map = hashMapOf(
                "id" to msg.id,
                "groupId" to msg.groupId,
                "senderId" to msg.senderId,
                "senderName" to msg.senderName,
                "senderRole" to msg.senderRole,
                "message" to msg.message,
                "timestamp" to msg.timestamp,
                "isAnnouncement" to msg.isAnnouncement,
                "isRead" to msg.isRead
            )
            db.collection("groups")
                .document(msg.groupId.toString())
                .collection("messages")
                .document(msg.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveChatMessage error: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Pre-Authorized Members
    // -------------------------------------------------------------

    suspend fun savePreAuthorizedMember(member: PreAuthorizedMember) {
        val db = firestore ?: return
        if (member.groupId <= 0L || member.id <= 0L) {
            Log.w(TAG, "Firestore savePreAuthorizedMember rejected: unscoped or invalid pre-auth member (groupId=${member.groupId}, id=${member.id})")
            return
        }
        try {
            val map = hashMapOf(
                "id" to member.id,
                "groupId" to member.groupId,
                "name" to member.name,
                "email" to member.email.trim().lowercase(),
                "phone" to member.phone,
                "status" to member.status,
                "addedAt" to member.addedAt,
                "claimedAt" to (member.claimedAt ?: 0L),
                "claimedUserId" to (member.claimedUserId ?: 0L),
                "claimedUid" to member.claimedUid
            )
            db.collection("groups")
                .document(member.groupId.toString())
                .collection("preAuthorizedMembers")
                .document(member.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore savePreAuthorizedMember error: ${e.message}")
        }
    }

    suspend fun deletePreAuthorizedMember(groupId: Long, memberId: Long) {
        val db = firestore ?: return
        if (groupId <= 0L || memberId <= 0L) {
            Log.w(TAG, "Firestore deletePreAuthorizedMember rejected: invalid parameters (groupId=$groupId, memberId=$memberId)")
            return
        }
        try {
            db.collection("groups")
                .document(groupId.toString())
                .collection("preAuthorizedMembers")
                .document(memberId.toString())
                .delete()
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore deletePreAuthorizedMember error: ${e.message}")
        }
    }

    suspend fun getPreAuthorizedMembers(groupId: Long): List<PreAuthorizedMember> {
        val db = firestore ?: return emptyList()
        if (groupId <= 0L) {
            Log.w(TAG, "getPreAuthorizedMembers rejected: invalid groupId $groupId")
            return emptyList()
        }
        return try {
            val snapshots = db.collection("groups")
                .document(groupId.toString())
                .collection("preAuthorizedMembers")
                .get()
                .await()

            snapshots.documents.mapNotNull { doc ->
                try {
                    PreAuthorizedMember(
                        id = doc.getLong("id") ?: 0L,
                        groupId = doc.getLong("groupId") ?: groupId,
                        name = doc.getString("name") ?: "",
                        email = doc.getString("email") ?: "",
                        phone = doc.getString("phone") ?: "",
                        status = doc.getString("status") ?: "unclaimed",
                        addedAt = doc.getLong("addedAt") ?: System.currentTimeMillis(),
                        claimedAt = doc.getLong("claimedAt").takeIf { it != null && it > 0 },
                        claimedUserId = doc.getLong("claimedUserId").takeIf { it != null && it > 0 },
                        claimedUid = doc.getString("claimedUid") ?: ""
                    )
                } catch (e: Exception) {
                    null
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firestore getPreAuthorizedMembers error: ${e.message}")
            emptyList()
        }
    }

    /**
     * Phase 11 — Task 6: Pre-Authorized Member Claiming Race Condition Prevention.
     * Executes atomic Firestore transaction to prevent double-claiming or corrupt state:
     * 1. Reads the pre-authorized record inside transaction: `groups/{groupId}/preAuthorizedMembers/{preAuthId}`.
     * 2. Verifies that status is strictly "PENDING" or "unclaimed", and claimedAt == null/0 and claimedUserId == null/0.
     * 3. If already claimed, aborts transaction by throwing IllegalStateException("Member already claimed").
     * 4. Updates pre-authorized member status to "CLAIMED", sets claimedUserId and claimedUid, and timestamps claimedAt.
     * 5. Atomically provisions or activates the member in `groups/{groupId}/members/{memberId}` within the transaction.
     */
    suspend fun claimPreAuthorizedMember(
        groupId: Long,
        preAuthId: Long,
        claimantAuthUid: String,
        claimantUserId: Long = 0L,
        memberToProvision: Member? = null
    ): Result<PreAuthorizedMember> {
        if (groupId <= 0L) {
            return Result.failure(IllegalArgumentException("Invalid groupId: $groupId"))
        }
        if (preAuthId <= 0L) {
            return Result.failure(IllegalArgumentException("Invalid preAuthId: $preAuthId"))
        }
        if (claimantAuthUid.isBlank()) {
            return Result.failure(IllegalArgumentException("Claimant Auth UID cannot be blank"))
        }

        val db = firestore ?: run {
            Log.w(TAG, "Firestore not initialized for atomic claim; returning local simulated record")
            return Result.success(
                PreAuthorizedMember(
                    id = preAuthId,
                    groupId = groupId,
                    name = memberToProvision?.name ?: "Claimed Member",
                    email = memberToProvision?.email ?: "",
                    status = "CLAIMED",
                    claimedAt = System.currentTimeMillis(),
                    claimedUserId = claimantUserId,
                    claimedUid = claimantAuthUid
                )
            )
        }

        return try {
            val groupDocRef = db.collection("groups").document(groupId.toString())
            val preAuthDocRef = groupDocRef.collection("preAuthorizedMembers").document(preAuthId.toString())

            val result = db.runTransaction { transaction ->
                val snapshot = transaction.get(preAuthDocRef)
                if (!snapshot.exists()) {
                    throw NoSuchElementException("Pre-authorized member record not found: $preAuthId")
                }

                val currentStatus = snapshot.getString("status")?.trim() ?: "unclaimed"
                val claimedAt = snapshot.getLong("claimedAt")
                val existingClaimedUserId = snapshot.getLong("claimedUserId")
                val existingClaimedUid = snapshot.getString("claimedUid")

                // Strict verification that status is strictly unclaimed/pending and not already claimed
                val isAlreadyClaimed = currentStatus.equals("claimed", ignoreCase = true) ||
                        currentStatus.equals("CLAIMED", ignoreCase = true) ||
                        (claimedAt != null && claimedAt > 0L) ||
                        (existingClaimedUserId != null && existingClaimedUserId > 0L) ||
                        !existingClaimedUid.isNullOrBlank()

                if (isAlreadyClaimed) {
                    throw IllegalStateException("Member already claimed")
                }

                val now = System.currentTimeMillis()
                val updateMap = hashMapOf<String, Any>(
                    "status" to "CLAIMED",
                    "claimedAt" to now,
                    "claimedUserId" to (if (claimantUserId > 0L) claimantUserId else claimantAuthUid),
                    "claimedUid" to claimantAuthUid,
                    "updatedAt" to now
                )
                transaction.update(preAuthDocRef, updateMap)

                // Atomically provision or activate the member in groups/{groupId}/members/{memberId}
                if (memberToProvision != null && memberToProvision.id > 0L) {
                    val memberDocRef = groupDocRef.collection("members").document(memberToProvision.id.toString())
                    val memberPayload = hashMapOf(
                        "id" to memberToProvision.id,
                        "groupId" to groupId,
                        "memberCode" to memberToProvision.memberCode,
                        "name" to memberToProvision.name,
                        "phone" to memberToProvision.phone,
                        "email" to memberToProvision.email,
                        "address" to memberToProvision.address,
                        "monthlyContribution" to memberToProvision.monthlyContribution,
                        "joinDate" to memberToProvision.joinDate,
                        "photoUri" to memberToProvision.photoUri,
                        "isActive" to true,
                        "isClaimed" to true,
                        "linkedUid" to claimantAuthUid,
                        "notes" to memberToProvision.notes,
                        "dateOfBirth" to memberToProvision.dateOfBirth,
                        "updatedAt" to now
                    )
                    transaction.set(memberDocRef, memberPayload, SetOptions.merge())
                }

                // Append claimant to activeMemberUids on group document
                try {
                    transaction.update(groupDocRef, "activeMemberUids", FieldValue.arrayUnion(claimantAuthUid))
                } catch (e: Exception) {
                    // Safe fallback if activeMemberUids field is absent
                }

                PreAuthorizedMember(
                    id = preAuthId,
                    groupId = groupId,
                    name = snapshot.getString("name") ?: (memberToProvision?.name ?: ""),
                    email = snapshot.getString("email") ?: (memberToProvision?.email ?: ""),
                    phone = snapshot.getString("phone") ?: (memberToProvision?.phone ?: ""),
                    status = "CLAIMED",
                    addedAt = snapshot.getLong("addedAt") ?: now,
                    claimedAt = now,
                    claimedUserId = claimantUserId,
                    claimedUid = claimantAuthUid
                )
            }.await()

            Result.success(result)
        } catch (e: Exception) {
            Log.w(TAG, "claimPreAuthorizedMember atomic transaction failed: ${e.message}")
            Result.failure(e)
        }
    }

    /**
     * Alias for claimPreAuthorizedMember supporting atomic naming convention.
     */
    suspend fun claimPreAuthorizedMemberAtomic(
        groupId: Long,
        preAuthId: Long,
        claimantAuthUid: String,
        claimantUserId: Long = 0L,
        memberToProvision: Member? = null
    ): Result<PreAuthorizedMember> = claimPreAuthorizedMember(groupId, preAuthId, claimantAuthUid, claimantUserId, memberToProvision)

    /**
     * Phase 11 — Task 6: Pre-transaction validation helper for pre-authorized member claims.
     */
    fun validateClaimEligibility(
        record: PreAuthorizedMember,
        claimantAuthUid: String,
        targetGroupId: Long
    ): Result<Unit> {
        if (targetGroupId <= 0L || record.groupId <= 0L || record.groupId != targetGroupId) {
            return Result.failure(IllegalArgumentException("Invalid or mismatched groupId: target=$targetGroupId, record=${record.groupId}"))
        }
        if (claimantAuthUid.isBlank()) {
            return Result.failure(IllegalArgumentException("Claimant Auth UID cannot be blank"))
        }
        if (record.isClaimed || record.status.equals("claimed", ignoreCase = true) || record.status.equals("CLAIMED", ignoreCase = true)) {
            return Result.failure(IllegalStateException("Member already claimed"))
        }
        if ((record.claimedAt != null && record.claimedAt > 0L) ||
            (record.claimedUserId != null && record.claimedUserId > 0L) ||
            record.claimedUid.isNotBlank()) {
            return Result.failure(IllegalStateException("Member already claimed"))
        }
        return Result.success(Unit)
    }

    // -------------------------------------------------------------
    // Cloud Firestore Sync: Group Join Requests (Pending / Approved / Rejected)
    // -------------------------------------------------------------

    suspend fun saveJoinRequest(request: GroupJoinRequest) {
        val db = firestore ?: return
        if (request.groupId <= 0L || request.id <= 0L || request.userId <= 0L) {
            Log.w(TAG, "Firestore saveJoinRequest rejected: unscoped or invalid request (groupId=${request.groupId}, id=${request.id}, userId=${request.userId})")
            return
        }
        try {
            val map = hashMapOf(
                "id" to request.id,
                "groupId" to request.groupId,
                "groupName" to request.groupName,
                "userId" to request.userId,
                "name" to request.name,
                "email" to request.email.trim().lowercase(),
                "phone" to request.phone,
                "requestedAt" to request.requestedAt,
                "status" to request.status,
                "processedAt" to (request.processedAt ?: 0L),
                "processedBy" to (request.processedBy ?: "")
            )
            // Save in group subcollection strictly
            db.collection("groups")
                .document(request.groupId.toString())
                .collection("pendingRequests")
                .document(request.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveJoinRequest error: ${e.message}")
        }
    }

    suspend fun deleteJoinRequest(groupId: Long, requestId: Long, userId: Long? = null) {
        val db = firestore ?: return
        if (groupId <= 0L || requestId <= 0L) {
            Log.w(TAG, "Firestore deleteJoinRequest rejected: invalid parameters (groupId=$groupId, requestId=$requestId)")
            return
        }
        try {
            db.collection("groups")
                .document(groupId.toString())
                .collection("pendingRequests")
                .document(requestId.toString())
                .delete()
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore deleteJoinRequest error: ${e.message}")
        }
    }

    suspend fun getJoinRequests(groupId: Long): List<GroupJoinRequest> {
        val db = firestore ?: return emptyList()
        if (groupId <= 0L) {
            Log.w(TAG, "getJoinRequests rejected: invalid groupId $groupId")
            return emptyList()
        }
        return try {
            val snapshots = db.collection("groups")
                .document(groupId.toString())
                .collection("pendingRequests")
                .get()
                .await()

            snapshots.documents.mapNotNull { doc ->
                try {
                    GroupJoinRequest(
                        id = doc.getLong("id") ?: 0L,
                        groupId = doc.getLong("groupId") ?: groupId,
                        groupName = doc.getString("groupName") ?: "",
                        userId = doc.getLong("userId") ?: 0L,
                        name = doc.getString("name") ?: "",
                        email = doc.getString("email") ?: "",
                        phone = doc.getString("phone") ?: "",
                        requestedAt = doc.getLong("requestedAt") ?: System.currentTimeMillis(),
                        status = doc.getString("status") ?: "PENDING",
                        processedAt = doc.getLong("processedAt").takeIf { it != null && it > 0 },
                        processedBy = doc.getString("processedBy")
                    )
                } catch (e: Exception) {
                    null
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firestore getJoinRequests error: ${e.message}")
            emptyList()
        }
    }

    suspend fun findGroupByInviteCode(inviteCode: String): GroupSettings? {
        val db = firestore ?: return null
        val code = inviteCode.trim().uppercase()
        return try {
            val querySnapshot = db.collection("groups")
                .whereEqualTo("inviteCode", code)
                .limit(1)
                .get()
                .await()

            val doc = querySnapshot.documents.firstOrNull() ?: return null
            GroupSettings(
                id = doc.getLong("id") ?: (doc.id.toLongOrNull() ?: 1L),
                groupName = doc.getString("groupName") ?: "Group",
                groupSubtitle = doc.getString("groupSubtitle") ?: "",
                description = doc.getString("description") ?: "",
                groupType = doc.getString("groupType") ?: "Self-Help Group",
                address = doc.getString("address") ?: "",
                contactPhone = doc.getString("contactPhone") ?: "",
                contactEmail = doc.getString("contactEmail") ?: "",
                createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis(),
                logoUri = doc.getString("logoUri") ?: "",
                inviteCode = doc.getString("inviteCode") ?: code,
                createdByUserId = doc.getLong("createdByUserId") ?: 1L,
                ownerUid = doc.getString("ownerUid") ?: doc.getString("creatorUid") ?: "",
                isContributionEnabled = doc.getBoolean("isContributionEnabled") ?: true,
                defaultContribution = doc.getDouble("defaultContribution") ?: 500.0,
                contributionFrequency = doc.getString("contributionFrequency") ?: "MONTHLY",
                dueDayOfMonth = (doc.getLong("dueDayOfMonth") ?: 10).toInt(),
                isLateFeeEnabled = doc.getBoolean("isLateFeeEnabled") ?: false,
                lateFineAmount = doc.getDouble("lateFineAmount") ?: 0.0,
                gracePeriodDays = (doc.getLong("gracePeriodDays") ?: 5).toInt(),
                paymentRules = doc.getString("paymentRules") ?: "",
                modulesConfigJson = doc.getString("modulesConfigJson") ?: "",
                currencySymbol = doc.getString("currencySymbol") ?: "₹",
                financialYearStartMonth = (doc.getLong("financialYearStartMonth") ?: 4).toInt(),
                adminName = doc.getString("adminName") ?: "Society Treasurer",
                adminPhone = doc.getString("adminPhone") ?: "",
                adminPin = doc.getString("adminPin") ?: "1234",
                isPinLockEnabled = doc.getBoolean("isPinLockEnabled") ?: false,
                themeMode = doc.getString("themeMode") ?: "SYSTEM"
            )
        } catch (e: Exception) {
            Log.w(TAG, "Firestore findGroupByInviteCode error: ${e.message}")
            null
        }
    }

    // -------------------------------------------------------------
    // Real-Time Listeners for Cloud Firestore
    // -------------------------------------------------------------

    fun attachRealtimeSync(
        groupId: Long,
        onMembersReceived: (List<Member>) -> Unit,
        onPaymentsReceived: (List<Payment>) -> Unit,
        onTransactionsReceived: (List<TransactionRecord>) -> Unit,
        onNoticesReceived: (List<SocietyNotice>) -> Unit,
        onLoansReceived: (List<LoanRequest>) -> Unit,
        onMessagesReceived: (List<GroupChatMessage>) -> Unit,
        onGroupSettingsReceived: (GroupSettings) -> Unit,
        onPreAuthorizedReceived: (List<PreAuthorizedMember>) -> Unit = {},
        onPendingRequestsReceived: (List<GroupJoinRequest>) -> Unit = {}
    ): () -> Unit {
        val db = firestore ?: return {}
        if (groupId <= 0L) {
            Log.w(TAG, "attachRealtimeSync rejected: invalid groupId $groupId")
            return {}
        }
        val registrations = mutableListOf<ListenerRegistration>()

        try {
            // 1. Group settings listener
            val groupReg = db.collection("groups").document(groupId.toString())
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null || !snapshot.exists()) return@addSnapshotListener
                    try {
                        val settings = GroupSettings(
                            id = snapshot.getLong("id") ?: groupId,
                            groupName = snapshot.getString("groupName") ?: "All services group",
                            groupSubtitle = snapshot.getString("groupSubtitle") ?: "Monthly Savings & Contribution Society",
                            description = snapshot.getString("description") ?: "",
                            groupType = snapshot.getString("groupType") ?: "Self-Help Group",
                            address = snapshot.getString("address") ?: "",
                            contactPhone = snapshot.getString("contactPhone") ?: "",
                            contactEmail = snapshot.getString("contactEmail") ?: "",
                            createdAt = snapshot.getLong("createdAt") ?: System.currentTimeMillis(),
                            logoUri = snapshot.getString("logoUri") ?: "",
                            inviteCode = snapshot.getString("inviteCode") ?: "SAMITI-${groupId}",
                            createdByUserId = snapshot.getLong("createdByUserId") ?: 1L,
                            ownerUid = snapshot.getString("ownerUid") ?: snapshot.getString("creatorUid") ?: "",
                            isContributionEnabled = snapshot.getBoolean("isContributionEnabled") ?: true,
                            defaultContribution = snapshot.getDouble("defaultContribution") ?: 500.0,
                            contributionFrequency = snapshot.getString("contributionFrequency") ?: "MONTHLY",
                            dueDayOfMonth = (snapshot.getLong("dueDayOfMonth") ?: 10).toInt(),
                            isLateFeeEnabled = snapshot.getBoolean("isLateFeeEnabled") ?: false,
                            lateFineAmount = snapshot.getDouble("lateFineAmount") ?: 0.0,
                            gracePeriodDays = (snapshot.getLong("gracePeriodDays") ?: 5).toInt(),
                            paymentRules = snapshot.getString("paymentRules") ?: "",
                            modulesConfigJson = snapshot.getString("modulesConfigJson") ?: "",
                            currencySymbol = snapshot.getString("currencySymbol") ?: "₹",
                            financialYearStartMonth = (snapshot.getLong("financialYearStartMonth") ?: 4).toInt(),
                            adminName = snapshot.getString("adminName") ?: "Society Treasurer",
                            adminPhone = snapshot.getString("adminPhone") ?: "+91 98765 43210",
                            adminPin = snapshot.getString("adminPin") ?: "1234",
                            isPinLockEnabled = snapshot.getBoolean("isPinLockEnabled") ?: false,
                            themeMode = snapshot.getString("themeMode") ?: "SYSTEM"
                        )
                        onGroupSettingsReceived(settings)
                    } catch (e: Exception) {
                        Log.w(TAG, "Error parsing Firestore group settings", e)
                    }
                }
            registrations.add(groupReg)

            // 2. Members listener
            val membersReg = db.collection("groups").document(groupId.toString())
                .collection("members")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            Member(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                memberCode = doc.getString("memberCode") ?: "",
                                name = doc.getString("name") ?: "",
                                phone = doc.getString("phone") ?: "",
                                address = doc.getString("address") ?: "",
                                joinDate = doc.getLong("joinDate") ?: System.currentTimeMillis(),
                                monthlyContribution = doc.getDouble("monthlyContribution") ?: 0.0,
                                photoUri = doc.getString("photoUri") ?: "",
                                isActive = doc.getBoolean("isActive") ?: true,
                                notes = doc.getString("notes") ?: "",
                                email = doc.getString("email") ?: "",
                                isClaimed = doc.getBoolean("isClaimed") ?: false,
                                linkedUid = doc.getString("linkedUid") ?: "",
                                dateOfBirth = doc.getString("dateOfBirth") ?: ""
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    if (list.isNotEmpty()) {
                        onMembersReceived(list)
                    }
                }
            registrations.add(membersReg)

            // 3. Payments listener
            val paymentsReg = db.collection("groups").document(groupId.toString())
                .collection("payments")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            Payment(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                memberId = doc.getLong("memberId") ?: 0L,
                                month = (doc.getLong("month") ?: 1).toInt(),
                                year = (doc.getLong("year") ?: 2026).toInt(),
                                expectedAmount = doc.getDouble("expectedAmount") ?: 0.0,
                                paidAmount = doc.getDouble("paidAmount") ?: 0.0,
                                dueAmount = doc.getDouble("dueAmount") ?: 0.0,
                                paymentDate = doc.getLong("paymentDate") ?: System.currentTimeMillis(),
                                paymentMethod = doc.getString("paymentMethod") ?: "Cash",
                                transactionReference = doc.getString("transactionReference") ?: "",
                                notes = doc.getString("notes") ?: "",
                                status = doc.getString("status") ?: "PAID",
                                approvalStatus = doc.getString("approvalStatus") ?: "APPROVED",
                                rejectionReason = doc.getString("rejectionReason") ?: "",
                                approvedAt = doc.getLong("approvedAt"),
                                approvedBy = doc.getString("approvedBy") ?: "",
                                submittedAt = doc.getLong("submittedAt") ?: System.currentTimeMillis()
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    if (list.isNotEmpty()) {
                        onPaymentsReceived(list)
                    }
                }
            registrations.add(paymentsReg)

            // 4. Transactions listener
            val txReg = db.collection("groups").document(groupId.toString())
                .collection("transactions")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            TransactionRecord(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                txnNumber = doc.getString("txnNumber") ?: "TXN-2026",
                                date = doc.getLong("date") ?: System.currentTimeMillis(),
                                amount = doc.getDouble("amount") ?: 0.0,
                                type = doc.getString("type") ?: "CONTRIBUTION",
                                isCredit = doc.getBoolean("isCredit") ?: true,
                                description = doc.getString("description") ?: "",
                                paymentMethod = doc.getString("paymentMethod") ?: "Cash",
                                relatedMemberId = doc.getLong("relatedMemberId"),
                                relatedMemberName = doc.getString("relatedMemberName"),
                                relatedLoanId = doc.getLong("relatedLoanId"),
                                relatedInvestmentId = doc.getLong("relatedInvestmentId"),
                                createdBy = doc.getString("createdBy") ?: "Admin"
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    if (list.isNotEmpty()) {
                        onTransactionsReceived(list)
                    }
                }
            registrations.add(txReg)

            // 5. Notices listener
            val noticesReg = db.collection("groups").document(groupId.toString())
                .collection("notices")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            SocietyNotice(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                title = doc.getString("title") ?: "",
                                content = doc.getString("content") ?: "",
                                category = doc.getString("category") ?: "General",
                                author = doc.getString("author") ?: "Admin",
                                timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis(),
                                isPinned = doc.getBoolean("isPinned") ?: false,
                                isPollEnabled = doc.getBoolean("isPollEnabled") ?: false,
                                pollOptions = doc.getString("pollOptions") ?: "In Favor / Yes,Against / No",
                                pollExpiryDate = doc.getLong("pollExpiryDate") ?: 0L,
                                pollVotesJson = doc.getString("pollVotesJson") ?: "{}"
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    if (list.isNotEmpty()) {
                        onNoticesReceived(list)
                    }
                }
            registrations.add(noticesReg)

            // 6. Loans listener
            val loansReg = db.collection("groups").document(groupId.toString())
                .collection("loans")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            LoanRequest(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                requesterMemberId = doc.getLong("requesterMemberId") ?: 0L,
                                requesterName = doc.getString("requesterName") ?: "",
                                requesterPhone = doc.getString("requesterPhone") ?: "",
                                requestedAmount = doc.getDouble("requestedAmount") ?: 0.0,
                                purpose = doc.getString("purpose") ?: "Emergency",
                                reason = doc.getString("reason") ?: "",
                                duration = (doc.getLong("duration") ?: 6).toInt(),
                                durationUnit = doc.getString("durationUnit") ?: "Months",
                                expectedRepaymentDate = doc.getLong("expectedRepaymentDate") ?: System.currentTimeMillis(),
                                note = doc.getString("note") ?: "",
                                createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis(),
                                votingDeadline = doc.getLong("votingDeadline") ?: System.currentTimeMillis(),
                                status = doc.getString("status") ?: "VOTING",
                                disbursedDate = doc.getLong("disbursedDate"),
                                disbursedBy = doc.getString("disbursedBy"),
                                repaidAmount = doc.getDouble("repaidAmount") ?: 0.0,
                                remainingAmount = doc.getDouble("remainingAmount") ?: 0.0
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    if (list.isNotEmpty()) {
                        onLoansReceived(list)
                    }
                }
            registrations.add(loansReg)

            // 7. Messages listener
            val messagesReg = db.collection("groups").document(groupId.toString())
                .collection("messages")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            GroupChatMessage(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                senderId = doc.getLong("senderId") ?: 1L,
                                senderName = doc.getString("senderName") ?: "Member",
                                senderRole = doc.getString("senderRole") ?: "Member",
                                message = doc.getString("message") ?: "",
                                timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis(),
                                isAnnouncement = doc.getBoolean("isAnnouncement") ?: false,
                                isRead = doc.getBoolean("isRead") ?: true
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    if (list.isNotEmpty()) {
                        onMessagesReceived(list)
                    }
                }
            registrations.add(messagesReg)

            // 8. Pre-authorized Members listener
            val preAuthReg = db.collection("groups").document(groupId.toString())
                .collection("preAuthorizedMembers")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            PreAuthorizedMember(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                name = doc.getString("name") ?: "",
                                email = doc.getString("email") ?: "",
                                phone = doc.getString("phone") ?: "",
                                status = doc.getString("status") ?: "unclaimed",
                                addedAt = doc.getLong("addedAt") ?: System.currentTimeMillis(),
                                claimedAt = doc.getLong("claimedAt").takeIf { it != null && it > 0 },
                                claimedUserId = doc.getLong("claimedUserId").takeIf { it != null && it > 0 },
                                claimedUid = doc.getString("claimedUid") ?: ""
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    onPreAuthorizedReceived(list)
                }
            registrations.add(preAuthReg)

            // 9. Pending Requests listener
            val pendingReg = db.collection("groups").document(groupId.toString())
                .collection("pendingRequests")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    val list = snapshots.documents.mapNotNull { doc ->
                        try {
                            GroupJoinRequest(
                                id = doc.getLong("id") ?: 0L,
                                groupId = doc.getLong("groupId") ?: groupId,
                                groupName = doc.getString("groupName") ?: "",
                                userId = doc.getLong("userId") ?: 0L,
                                name = doc.getString("name") ?: "",
                                email = doc.getString("email") ?: "",
                                phone = doc.getString("phone") ?: "",
                                requestedAt = doc.getLong("requestedAt") ?: System.currentTimeMillis(),
                                status = doc.getString("status") ?: "PENDING",
                                processedAt = doc.getLong("processedAt").takeIf { it != null && it > 0 },
                                processedBy = doc.getString("processedBy")
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    onPendingRequestsReceived(list)
                }
            registrations.add(pendingReg)

        } catch (e: Exception) {
            Log.w(TAG, "Error attaching Firestore listeners: ${e.message}")
        }

        return {
            registrations.forEach { it.remove() }
            registrations.clear()
        }
    }

    @Deprecated("Join requests are strictly canonicalized under groups/{groupId}/pendingRequests")
    fun attachUserJoinRequestsListener(
        userId: Long,
        onRequestsReceived: (List<GroupJoinRequest>) -> Unit
    ): () -> Unit {
        if (userId <= 0L) {
            Log.w(TAG, "attachUserJoinRequestsListener rejected: invalid userId $userId")
            return {}
        }
        Log.d(TAG, "attachUserJoinRequestsListener: Join requests are canonically stored in groups/{groupId}/pendingRequests")
        return {}
    }

    suspend fun autoMatchAndClaimUnclaimedMembers(
        userId: Long,
        authUid: String,
        userName: String,
        userEmail: String,
        userPhone: String,
        targetGroupId: Long? = null
    ): List<ClaimedMemberMatch> {
        val db = firestore ?: return emptyList()
        val matchedList = mutableListOf<ClaimedMemberMatch>()

        // SECURITY ENFORCEMENT: Client-side cross-group collection scanning ("groups".get())
        // is strictly disabled to prevent unauthorized multi-tenant data enumeration.
        if (targetGroupId == null) {
            Log.d(
                TAG,
                "Security: Cross-group auto-match collection scan is disabled on client. " +
                        "Matching is strictly scoped to an explicit verified group (e.g. via inviteCode/PIN)."
            )
            return emptyList()
        }

        val cleanUserName = userName.trim().lowercase()
        val cleanUserEmail = userEmail.trim().lowercase()
        val normUserPhone = userPhone.filter { it.isDigit() }.let { if (it.length >= 10) it.takeLast(10) else it.trimStart('0') }

        fun isPhoneMatch(storedPhone: String): Boolean {
            val normStored = storedPhone.filter { it.isDigit() }.let { if (it.length >= 10) it.takeLast(10) else it.trimStart('0') }
            if (normUserPhone.isBlank() || normStored.isBlank()) return false
            if (normUserPhone == normStored) return true
            if (normUserPhone.length >= 8 && normStored.length >= 8 && (normUserPhone.endsWith(normStored) || normStored.endsWith(normUserPhone))) return true
            return false
        }

        fun isNameMatch(storedName: String): Boolean {
            val cStored = storedName.trim().lowercase().replace(Regex("\\s+"), " ")
            val cUser = cleanUserName.replace(Regex("\\s+"), " ")
            if (cStored.isBlank() || cUser.isBlank()) return false
            if (cStored == cUser) return true
            if (cStored.length >= 3 && cUser.length >= 3 && (cStored.contains(cUser) || cUser.contains(cStored))) return true
            return false
        }

        try {
            // OPERATE STRICTLY WITHIN THE SPECIFIED TARGET GROUP ONLY
            val groupDocRef = db.collection("groups").document(targetGroupId.toString())
            val groupDoc = groupDocRef.get().await()
            val groupName = groupDoc.getString("groupName") ?: "Group"

            // 1. Check members subcollection of the target group only
            val membersRef = groupDocRef.collection("members")
            val membersSnap = membersRef.get().await()
            for (mDoc in membersSnap.documents) {
                val isClaimed = mDoc.getBoolean("isClaimed") ?: false
                val linkedUid = mDoc.getString("linkedUid").orEmpty()
                if (isClaimed && linkedUid.isNotBlank() && linkedUid != authUid) continue

                val mName = mDoc.getString("name").orEmpty().trim()
                val mEmail = mDoc.getString("email").orEmpty().trim().lowercase()
                val mPhone = mDoc.getString("phone").orEmpty().trim()
                val memberId = mDoc.getLong("id") ?: (mDoc.id.toLongOrNull() ?: 0L)

                val nameMatches = isNameMatch(mName)
                val emailMatches = cleanUserEmail.isNotBlank() && mEmail.isNotBlank() && cleanUserEmail == mEmail
                val phoneMatches = isPhoneMatch(mPhone)

                val isMatch = (nameMatches && (emailMatches || phoneMatches)) ||
                        (nameMatches && mEmail.isBlank() && mPhone.isBlank()) ||
                        ((emailMatches || phoneMatches) && (nameMatches || mName.isBlank()))

                if (isMatch) {
                    membersRef.document(mDoc.id).set(
                        mapOf(
                            "isClaimed" to true,
                            "linkedUid" to authUid,
                            "email" to if (mEmail.isBlank()) userEmail else mDoc.getString("email").orEmpty(),
                            "phone" to if (mPhone.isBlank()) userPhone else mDoc.getString("phone").orEmpty()
                        ),
                        SetOptions.merge()
                    ).await()

                    try {
                        groupDocRef.update(
                            "activeMemberUids", FieldValue.arrayUnion(authUid)
                        ).await()
                    } catch (e: Exception) {
                        Log.w(TAG, "Update activeMemberUids error: ${e.message}")
                    }

                    matchedList.add(
                        ClaimedMemberMatch(
                            groupId = targetGroupId,
                            groupName = groupName,
                            memberId = memberId,
                            memberName = mName.ifBlank { userName }
                        )
                    )
                }
            }

            // 2. Check preAuthorizedMembers subcollection of the target group only
            val preAuthRef = groupDocRef.collection("preAuthorizedMembers")
            val preAuthSnap = preAuthRef.get().await()
            for (pDoc in preAuthSnap.documents) {
                val status = pDoc.getString("status").orEmpty()
                if (status.equals("claimed", ignoreCase = true)) continue

                val pName = pDoc.getString("name").orEmpty().trim()
                val pEmail = pDoc.getString("email").orEmpty().trim().lowercase()
                val pPhone = pDoc.getString("phone").orEmpty().trim()
                val pId = pDoc.getLong("id") ?: (pDoc.id.toLongOrNull() ?: 0L)

                val nameMatches = isNameMatch(pName)
                val emailMatches = cleanUserEmail.isNotBlank() && pEmail.isNotBlank() && cleanUserEmail == pEmail
                val phoneMatches = isPhoneMatch(pPhone)

                val isMatch = (nameMatches && (emailMatches || phoneMatches)) ||
                        (nameMatches && pEmail.isBlank() && pPhone.isBlank()) ||
                        ((emailMatches || phoneMatches) && (nameMatches || pName.isBlank()))

                if (isMatch) {
                    val claimResult = claimPreAuthorizedMember(
                        groupId = targetGroupId,
                        preAuthId = pId,
                        claimantAuthUid = authUid,
                        claimantUserId = userId
                    )

                    if (claimResult.isSuccess) {
                        matchedList.add(
                            ClaimedMemberMatch(
                                groupId = targetGroupId,
                                groupName = groupName,
                                memberId = pId,
                                memberName = pName.ifBlank { userName }
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error in autoMatchAndClaimUnclaimedMembers: ${e.message}")
        }
        return matchedList
    }

    // -------------------------------------------------------------
    // App Update Service Support (Firestore app_config/version_info)
    // -------------------------------------------------------------

    suspend fun getLatestAppUpdate(): AppUpdateInfo? {
        val db = firestore ?: return null
        return try {
            val doc = db.collection("app_config").document("version_info").get().await()
            if (doc != null && doc.exists()) {
                val latestCode = doc.getLong("latestVersionCode")
                    ?: doc.getLong("versionCode")
                    ?: 1L
                val url = doc.getString("downloadUrl") ?: ""
                val versionName = doc.getString("versionName") ?: "v$latestCode"
                val title = doc.getString("title") ?: "Update Available"
                val notes = doc.getString("releaseNotes")
                    ?: "A new version of Group Ledger is available. Please update now to continue using the app."
                val isMandatory = doc.getBoolean("isMandatory") ?: false
                val bulletsList = (doc.get("changelogBullets") as? List<*>)?.mapNotNull { it?.toString() }
                    ?: emptyList()

                AppUpdateInfo(
                    versionCode = latestCode.toInt(),
                    versionName = versionName,
                    minSupportedVersionCode = (doc.getLong("minSupportedVersionCode") ?: 1).toInt(),
                    title = title,
                    releaseNotes = notes,
                    releaseDate = doc.getLong("releaseDate") ?: System.currentTimeMillis(),
                    downloadUrl = url,
                    isMandatory = isMandatory,
                    fileSizeBytes = doc.getLong("fileSizeBytes") ?: 0L,
                    publishedBy = doc.getString("publishedBy") ?: "Admin",
                    changelogBullets = if (bulletsList.isNotEmpty()) bulletsList else listOf(notes)
                )
            } else {
                null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error checking for app update from app_config/version_info: ${e.message}")
            null
        }
    }

    suspend fun publishAppUpdate(update: AppUpdateInfo): Result<Unit> {
        val db = firestore ?: return Result.failure(IllegalStateException("Firebase Firestore is not initialized"))
        val currentUid = auth?.currentUser?.uid
        if (currentUid.isNullOrBlank()) {
            return Result.failure(SecurityException("Publishing app updates requires an authenticated administrator"))
        }
        return try {
            val data = mapOf(
                "latestVersionCode" to update.versionCode,
                "versionCode" to update.versionCode,
                "downloadUrl" to update.downloadUrl,
                "versionName" to update.versionName,
                "minSupportedVersionCode" to update.minSupportedVersionCode,
                "title" to update.title,
                "releaseNotes" to update.releaseNotes,
                "releaseDate" to update.releaseDate,
                "isMandatory" to update.isMandatory,
                "fileSizeBytes" to update.fileSizeBytes,
                "publishedBy" to update.publishedBy,
                "changelogBullets" to update.changelogBullets,
                "updatedAt" to System.currentTimeMillis()
            )
            db.collection("app_config").document("version_info")
                .set(data, SetOptions.merge()).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Error publishing app update to Firestore: ${e.message}")
            Result.failure(e)
        }
    }

    fun attachAppUpdateListener(onUpdateReceived: (AppUpdateInfo?) -> Unit): () -> Unit {
        val db = firestore ?: return {}
        val reg = db.collection("app_config").document("version_info")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Error listening to app updates: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    val latestCode = snapshot.getLong("latestVersionCode")
                        ?: snapshot.getLong("versionCode")
                        ?: 1L
                    val url = snapshot.getString("downloadUrl") ?: ""
                    val versionName = snapshot.getString("versionName") ?: "v$latestCode"
                    val title = snapshot.getString("title") ?: "Update Available"
                    val notes = snapshot.getString("releaseNotes")
                        ?: "A new version of Group Ledger is available. Please update now to continue using the app."
                    val isMandatory = snapshot.getBoolean("isMandatory") ?: false
                    val bulletsList = (snapshot.get("changelogBullets") as? List<*>)?.mapNotNull { it?.toString() }
                        ?: emptyList()

                    val info = AppUpdateInfo(
                        versionCode = latestCode.toInt(),
                        versionName = versionName,
                        minSupportedVersionCode = (snapshot.getLong("minSupportedVersionCode") ?: 1).toInt(),
                        title = title,
                        releaseNotes = notes,
                        releaseDate = snapshot.getLong("releaseDate") ?: System.currentTimeMillis(),
                        downloadUrl = url,
                        isMandatory = isMandatory,
                        fileSizeBytes = snapshot.getLong("fileSizeBytes") ?: 0L,
                        publishedBy = snapshot.getString("publishedBy") ?: "Admin",
                        changelogBullets = if (bulletsList.isNotEmpty()) bulletsList else listOf(notes)
                    )
                    onUpdateReceived(info)
                } else {
                    onUpdateReceived(null)
                }
            }
        return { reg.remove() }
    }

    // -------------------------------------------------------------
    // Direct Server-Side Fetch (Pull-to-Refresh via Source.SERVER)
    // -------------------------------------------------------------

    suspend fun getGroupSettingsFromServer(groupId: Long): GroupSettings? {
        val db = firestore ?: return null
        if (groupId <= 0L) {
            Log.w(TAG, "getGroupSettingsFromServer rejected: invalid groupId $groupId")
            return null
        }
        return try {
            val snapshot = db.collection("groups").document(groupId.toString()).get(Source.SERVER).await()
            if (snapshot.exists()) {
                GroupSettings(
                    id = snapshot.getLong("id") ?: groupId,
                    groupName = snapshot.getString("groupName") ?: "All services group",
                    groupSubtitle = snapshot.getString("groupSubtitle") ?: "Monthly Savings & Contribution Society",
                    description = snapshot.getString("description") ?: "",
                    groupType = snapshot.getString("groupType") ?: "Self-Help Group",
                    address = snapshot.getString("address") ?: "",
                    contactPhone = snapshot.getString("contactPhone") ?: "",
                    contactEmail = snapshot.getString("contactEmail") ?: "",
                    createdAt = snapshot.getLong("createdAt") ?: System.currentTimeMillis(),
                    logoUri = snapshot.getString("logoUri") ?: "",
                    inviteCode = snapshot.getString("inviteCode") ?: "SAMITI-${groupId}",
                    createdByUserId = snapshot.getLong("createdByUserId") ?: 1L,
                    ownerUid = snapshot.getString("ownerUid") ?: snapshot.getString("creatorUid") ?: "",
                    isContributionEnabled = snapshot.getBoolean("isContributionEnabled") ?: true,
                    defaultContribution = snapshot.getDouble("defaultContribution") ?: 500.0,
                    contributionFrequency = snapshot.getString("contributionFrequency") ?: "MONTHLY",
                    dueDayOfMonth = (snapshot.getLong("dueDayOfMonth") ?: 10).toInt(),
                    isLateFeeEnabled = snapshot.getBoolean("isLateFeeEnabled") ?: false,
                    lateFineAmount = snapshot.getDouble("lateFineAmount") ?: 0.0,
                    gracePeriodDays = (snapshot.getLong("gracePeriodDays") ?: 5).toInt(),
                    paymentRules = snapshot.getString("paymentRules") ?: "",
                    modulesConfigJson = snapshot.getString("modulesConfigJson") ?: "",
                    currencySymbol = snapshot.getString("currencySymbol") ?: "₹",
                    financialYearStartMonth = (snapshot.getLong("financialYearStartMonth") ?: 4).toInt(),
                    adminName = snapshot.getString("adminName") ?: "Society Treasurer",
                    adminPhone = snapshot.getString("adminPhone") ?: "+91 98765 43210",
                    adminPin = snapshot.getString("adminPin") ?: "1234",
                    isPinLockEnabled = snapshot.getBoolean("isPinLockEnabled") ?: false,
                    themeMode = snapshot.getString("themeMode") ?: "SYSTEM"
                )
            } else {
                null
            }
        } catch (e: Exception) {
            Log.w(TAG, "getGroupSettingsFromServer error: ${e.message}")
            null
        }
    }

    suspend fun getMembersFromServer(groupId: Long): List<Member> {
        val db = firestore ?: return emptyList()
        if (groupId <= 0L) {
            Log.w(TAG, "getMembersFromServer rejected: invalid groupId $groupId")
            return emptyList()
        }
        val resultList = mutableListOf<Member>()
        try {
            val snapshots = db.collection("groups")
                .document(groupId.toString())
                .collection("members")
                .get(Source.SERVER)
                .await()

            snapshots.documents.mapNotNullTo(resultList) { doc ->
                try {
                    Member(
                        id = doc.getLong("id") ?: (doc.id.toLongOrNull() ?: 0L),
                        groupId = doc.getLong("groupId") ?: groupId,
                        memberCode = doc.getString("memberCode") ?: "",
                        name = doc.getString("name") ?: "",
                        phone = doc.getString("phone") ?: "",
                        address = doc.getString("address") ?: "",
                        joinDate = doc.getLong("joinDate") ?: System.currentTimeMillis(),
                        monthlyContribution = doc.getDouble("monthlyContribution") ?: 0.0,
                        photoUri = doc.getString("photoUri") ?: "",
                        isActive = doc.getBoolean("isActive") ?: true,
                        notes = doc.getString("notes") ?: "",
                        email = doc.getString("email") ?: "",
                        isClaimed = doc.getBoolean("isClaimed") ?: false,
                        linkedUid = doc.getString("linkedUid") ?: "",
                        dateOfBirth = doc.getString("dateOfBirth") ?: ""
                    )
                } catch (e: Exception) {
                    null
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "getMembersFromServer error: ${e.message}")
        }
        return resultList
    }

    suspend fun getPaymentsFromServer(groupId: Long): List<Payment> {
        val db = firestore ?: return emptyList()
        if (groupId <= 0L) {
            Log.w(TAG, "getPaymentsFromServer rejected: invalid groupId $groupId")
            return emptyList()
        }
        val resultList = mutableListOf<Payment>()
        try {
            val snapshots = db.collection("groups")
                .document(groupId.toString())
                .collection("payments")
                .get(Source.SERVER)
                .await()

            snapshots.documents.mapNotNullTo(resultList) { doc ->
                try {
                    Payment(
                        id = doc.getLong("id") ?: (doc.id.toLongOrNull() ?: 0L),
                        groupId = doc.getLong("groupId") ?: groupId,
                        memberId = doc.getLong("memberId") ?: 0L,
                        month = (doc.getLong("month") ?: 1).toInt(),
                        year = (doc.getLong("year") ?: 2026).toInt(),
                        expectedAmount = doc.getDouble("expectedAmount") ?: 0.0,
                        paidAmount = doc.getDouble("paidAmount") ?: 0.0,
                        dueAmount = doc.getDouble("dueAmount") ?: 0.0,
                        paymentDate = doc.getLong("paymentDate") ?: System.currentTimeMillis(),
                        paymentMethod = doc.getString("paymentMethod") ?: "Cash",
                        transactionReference = doc.getString("transactionReference") ?: "",
                        notes = doc.getString("notes") ?: "",
                        status = doc.getString("status") ?: "PAID",
                        approvalStatus = doc.getString("approvalStatus") ?: "APPROVED",
                        rejectionReason = doc.getString("rejectionReason") ?: "",
                        approvedAt = doc.getLong("approvedAt"),
                        approvedBy = doc.getString("approvedBy") ?: "",
                        submittedAt = doc.getLong("submittedAt") ?: System.currentTimeMillis()
                    )
                } catch (e: Exception) {
                    null
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "getPaymentsFromServer error: ${e.message}")
        }
        return resultList
    }

    suspend fun getTransactionsFromServer(groupId: Long): List<TransactionRecord> {
        val db = firestore ?: return emptyList()
        if (groupId <= 0L) {
            Log.w(TAG, "getTransactionsFromServer rejected: invalid groupId $groupId")
            return emptyList()
        }
        val resultList = mutableListOf<TransactionRecord>()
        try {
            val snapshots = db.collection("groups")
                .document(groupId.toString())
                .collection("transactions")
                .get(Source.SERVER)
                .await()

            snapshots.documents.mapNotNullTo(resultList) { doc ->
                try {
                    TransactionRecord(
                        id = doc.getLong("id") ?: (doc.id.toLongOrNull() ?: 0L),
                        groupId = doc.getLong("groupId") ?: groupId,
                        txnNumber = doc.getString("txnNumber") ?: "TXN-2026",
                        date = doc.getLong("date") ?: System.currentTimeMillis(),
                        amount = doc.getDouble("amount") ?: 0.0,
                        type = doc.getString("type") ?: "CONTRIBUTION",
                        isCredit = doc.getBoolean("isCredit") ?: true,
                        description = doc.getString("description") ?: "",
                        paymentMethod = doc.getString("paymentMethod") ?: "Cash",
                        relatedMemberId = doc.getLong("relatedMemberId"),
                        relatedMemberName = doc.getString("relatedMemberName"),
                        relatedLoanId = doc.getLong("relatedLoanId"),
                        relatedInvestmentId = doc.getLong("relatedInvestmentId"),
                        createdBy = doc.getString("createdBy") ?: "Admin"
                    )
                } catch (e: Exception) {
                    null
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "getTransactionsFromServer error: ${e.message}")
        }
        return resultList
    }

    suspend fun getNoticesFromServer(groupId: Long): List<SocietyNotice> {
        val db = firestore ?: return emptyList()
        if (groupId <= 0L) {
            Log.w(TAG, "getNoticesFromServer rejected: invalid groupId $groupId")
            return emptyList()
        }
        val resultList = mutableListOf<SocietyNotice>()
        try {
            val snapshots = db.collection("groups")
                .document(groupId.toString())
                .collection("notices")
                .get(Source.SERVER)
                .await()

            snapshots.documents.mapNotNullTo(resultList) { doc ->
                try {
                    SocietyNotice(
                        id = doc.getLong("id") ?: (doc.id.toLongOrNull() ?: 0L),
                        groupId = doc.getLong("groupId") ?: groupId,
                        title = doc.getString("title") ?: "",
                        content = doc.getString("content") ?: "",
                        category = doc.getString("category") ?: "General",
                        author = doc.getString("author") ?: "Admin",
                        timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis(),
                        isPinned = doc.getBoolean("isPinned") ?: false,
                        isPollEnabled = doc.getBoolean("isPollEnabled") ?: false,
                        pollOptions = doc.getString("pollOptions") ?: "In Favor / Yes,Against / No",
                        pollExpiryDate = doc.getLong("pollExpiryDate") ?: 0L,
                        pollVotesJson = doc.getString("pollVotesJson") ?: "{}"
                    )
                } catch (e: Exception) {
                    null
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "getNoticesFromServer error: ${e.message}")
        }
        return resultList
    }

    suspend fun saveFeedback(feedback: GroupFeedback) {
        val db = firestore ?: return
        if (feedback.groupId <= 0L || feedback.id <= 0L) {
            Log.w(TAG, "Firestore saveFeedback rejected: unscoped or invalid feedback (groupId=${feedback.groupId}, feedbackId=${feedback.id})")
            return
        }
        try {
            val map = hashMapOf(
                "id" to feedback.id,
                "groupId" to feedback.groupId,
                "memberId" to feedback.memberId,
                "memberName" to feedback.memberName,
                "type" to feedback.type,
                "subject" to feedback.subject,
                "description" to feedback.description,
                "createdAt" to feedback.createdAt,
                "status" to feedback.status,
                "adminResponse" to feedback.adminResponse,
                "isAnonymous" to feedback.isAnonymous,
                "requiresVoting" to feedback.requiresVoting,
                "votingThresholdPercent" to feedback.votingThresholdPercent
            )
            db.collection("groups")
                .document(feedback.groupId.toString())
                .collection("feedbacks")
                .document(feedback.id.toString())
                .set(map, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore saveFeedback error: ${e.message}")
        }
    }

    suspend fun getFeedbacksFromServer(groupId: Long): List<GroupFeedback> {
        val db = firestore ?: return emptyList()
        if (groupId <= 0L) {
            Log.w(TAG, "getFeedbacksFromServer rejected: invalid groupId $groupId")
            return emptyList()
        }
        val resultList = mutableListOf<GroupFeedback>()
        try {
            val snapshots = db.collection("groups")
                .document(groupId.toString())
                .collection("feedbacks")
                .get(Source.SERVER)
                .await()

            snapshots.documents.mapNotNullTo(resultList) { doc ->
                try {
                    GroupFeedback(
                        id = doc.getLong("id") ?: (doc.id.toLongOrNull() ?: 0L),
                        groupId = doc.getLong("groupId") ?: groupId,
                        memberId = doc.getLong("memberId") ?: 0L,
                        memberName = doc.getString("memberName") ?: "",
                        type = doc.getString("type") ?: "SUGGESTION",
                        subject = doc.getString("subject") ?: "",
                        description = doc.getString("description") ?: "",
                        createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis(),
                        status = doc.getString("status") ?: "SUBMITTED",
                        adminResponse = doc.getString("adminResponse") ?: "",
                        isAnonymous = doc.getBoolean("isAnonymous") ?: false,
                        requiresVoting = doc.getBoolean("requiresVoting") ?: false,
                        votingThresholdPercent = (doc.getLong("votingThresholdPercent") ?: 50L).toInt()
                    )
                } catch (e: Exception) {
                    null
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "getFeedbacksFromServer error: ${e.message}")
        }
        return resultList
    }
}

data class ClaimedMemberMatch(
    val groupId: Long,
    val groupName: String,
    val memberId: Long,
    val memberName: String
)
