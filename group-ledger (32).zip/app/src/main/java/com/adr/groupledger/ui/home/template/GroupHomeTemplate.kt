package com.adr.groupledger.ui.home.template

import androidx.compose.runtime.Composable
import com.adr.groupledger.ui.home.HomeTemplateContext

/**
 * Interface that all category and sub-category specific Home Page templates implement.
 * Each template decides its own information hierarchy, visible components, action items,
 * and data visualization while adhering to the common Group Ledger design system.
 */
interface GroupHomeTemplate {
    val templateId: String
    val displayName: String

    @Composable
    fun Render(context: HomeTemplateContext)
}
