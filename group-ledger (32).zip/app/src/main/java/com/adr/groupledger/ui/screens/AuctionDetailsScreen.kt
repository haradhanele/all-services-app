package com.adr.groupledger.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.EditCalendar
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.ChitAuctionResultPreparation
import com.adr.groupledger.data.model.ChitBid
import com.adr.groupledger.data.model.ChitBidStatus
import com.adr.groupledger.data.model.ChitCycle
import com.adr.groupledger.data.model.ChitCycleStatus
import com.adr.groupledger.data.model.ChitFundConfig
import com.adr.groupledger.data.model.ChitMemberEligibility
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.utils.ChitCalculationEngine
import com.adr.groupledger.utils.CurrencyFormatter
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Phase B.3 — Chit Fund Live Auction & Bid Engine Screen.
 *
 * Implements:
 * 1. Live Auction Bidding Floor with authoritative reverse discount bidding.
 * 2. Real-time discount bounds calculation (Floor: 5%, Ceiling: 30%-40%).
 * 3. Member eligibility validation (Prized subscriber restriction, pending dues check).
 * 4. Transparent live bids leaderboard with tiebreaker timestamps.
 * 5. Instant prize payout and member dividend estimation preview.
 * 6. Group Admin auction lifecycle controls (Close bidding floor, Reopen floor, Reschedule).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuctionDetailsScreen(
    cycleNumber: Int?,
    viewModel: SocietyViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToResultReview: (Int) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()
    val currentUserRole by viewModel.currentUserRole.collectAsStateWithLifecycle()
    val isGroupAdmin = isAdminUnlocked || currentUserRole.equals("ADMIN", ignoreCase = true)
    val currentMemberId by viewModel.currentMemberId.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val activeMembers by viewModel.activeMembers.collectAsStateWithLifecycle()

    val chitConfig = remember(settings) { ChitFundConfig.parseFromSettings(settings) }
    val curr = settings.currencySymbol.ifBlank { "₹" }

    // Resolve target cycle
    val targetCycleNumber = cycleNumber ?: chitConfig.currentChitNo ?: 1
    val cycle = remember(chitConfig.cycles, targetCycleNumber) {
        chitConfig.cycles.find { it.cycleNumber == targetCycleNumber }
            ?: ChitCycle(
                cycleNumber = targetCycleNumber,
                scheduledDateMillis = chitConfig.resolveNextAuctionEpoch(settings) ?: System.currentTimeMillis(),
                installmentAmount = chitConfig.monthlyInstallment ?: settings.defaultContribution,
                status = ChitCycleStatus.AUCTION_SCHEDULED,
                auctionStartTime = chitConfig.auctionTime ?: "08:00 PM"
            )
    }

    val totalMembersCount = chitConfig.totalMembers ?: (activeMembers.size.takeIf { it > 0 } ?: 20)
    val installmentVal = cycle.installmentAmount.takeIf { it > 0 } ?: (chitConfig.monthlyInstallment ?: 5000.0)
    val totalPot = totalMembersCount * installmentVal

    // Discount Bounds (5% to 30%)
    val (minDiscount, maxDiscount) = remember(totalPot) {
        ChitCalculationEngine.calculateDiscountBounds(totalPot, 5.0, 30.0)
    }

    // Member Eligibility State
    var memberEligibility by remember(cycle.cycleNumber, currentMemberId) {
        mutableStateOf(
            ChitMemberEligibility(
                memberId = currentMemberId ?: 1L,
                memberName = currentUser?.fullName ?: "Member",
                isEligible = true,
                reason = "Evaluating eligibility..."
            )
        )
    }

    LaunchedEffect(cycle.cycleNumber, currentMemberId, chitConfig.cycles) {
        val resolvedId = viewModel.resolveCurrentMemberId() ?: (currentMemberId ?: 1L)
        memberEligibility = viewModel.checkMemberEligibility(resolvedId, cycle.cycleNumber)
    }

    var showRescheduleDialog by remember { mutableStateOf(false) }
    var showCloseFloorDialog by remember { mutableStateOf(false) }
    var showReopenFloorDialog by remember { mutableStateOf(false) }

    // Live dynamic status and countdown resolution
    var operationalStatus by remember(cycle) { mutableStateOf(cycle.deriveOperationalStatus()) }
    var secondsRemaining by remember(cycle, operationalStatus) {
        val now = System.currentTimeMillis()
        val startEpoch = cycle.resolveAuctionStartEpoch()
        val endEpoch = cycle.resolveAuctionEndEpoch()
        val diff = when {
            now < startEpoch -> (startEpoch - now) / 1000L
            now in startEpoch..endEpoch -> (endEpoch - now) / 1000L
            else -> 0L
        }
        mutableLongStateOf(diff.coerceAtLeast(0L))
    }

    LaunchedEffect(cycle) {
        while (true) {
            val now = System.currentTimeMillis()
            val startEpoch = cycle.resolveAuctionStartEpoch()
            val endEpoch = cycle.resolveAuctionEndEpoch()
            operationalStatus = cycle.deriveOperationalStatus(now)

            val diff = when {
                now < startEpoch -> (startEpoch - now) / 1000L
                now in startEpoch..endEpoch -> (endEpoch - now) / 1000L
                else -> 0L
            }
            secondsRemaining = diff.coerceAtLeast(0L)
            delay(1000L)
        }
    }

    // Bid Ranking & Highest Bid
    val rankedBids = remember(cycle.bids) { ChitCalculationEngine.rankBids(cycle.bids) }
    val highestBid = remember(cycle.bids) { ChitCalculationEngine.resolveHighestBid(cycle.bids) }

    // Financial outcome based on highest bid
    val estimatedOutcome = remember(totalPot, highestBid, totalMembersCount, installmentVal) {
        val winningDiscount = highestBid?.bidAmount ?: minDiscount
        ChitCalculationEngine.calculateEstimatedPrizeAndDividend(
            totalPot = totalPot,
            highestDiscountBid = winningDiscount,
            totalMembers = totalMembersCount,
            foremanCommissionPercent = 5.0,
            monthlyInstallment = installmentVal
        )
    }

    // User's own submitted bid in this cycle
    val userBid = remember(cycle.bids, currentMemberId) {
        cycle.bids.find { it.memberId == (currentMemberId ?: 1L) && it.status == ChitBidStatus.VALID }
    }

    // Bid Submission Input State
    var customBidInput by remember(highestBid, minDiscount) {
        val initialAmount = if (highestBid != null && highestBid.bidAmount >= minDiscount) {
            (highestBid.bidAmount + 500.0).coerceAtMost(maxDiscount)
        } else {
            minDiscount
        }
        mutableStateOf(initialAmount.toInt().toString())
    }

    // Phase B.3: Controlled Visibility & Deterministic Result Preparation & Confirmation Dialog State
    val isBiddingSealed = remember(chitConfig.biddingVisibility) {
        chitConfig.biddingVisibility.equals("SEALED", ignoreCase = true)
    }

    val preparedResult = remember(cycle, totalMembersCount) {
        ChitCalculationEngine.prepareAuctionResult(cycle, totalMembersCount, 5.0)
    }

    var bidToConfirm by remember { mutableStateOf<Double?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Round #${cycle.cycleNumber} Auction & Bids",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = settings.groupName.ifBlank { "Chit Fund Scheme" },
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    if (isGroupAdmin && operationalStatus == ChitCycleStatus.AUCTION_OPEN) {
                        TextButton(
                            onClick = { showCloseFloorDialog = true },
                            modifier = Modifier.testTag("admin_close_floor_btn")
                        ) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = Rose500, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Close Floor", color = Rose500, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Status Banner Card
            AuctionStatusBannerCard(
                cycle = cycle,
                operationalStatus = operationalStatus,
                secondsRemaining = secondsRemaining,
                isGroupAdmin = isGroupAdmin,
                onRescheduleClick = {
                    if (cycle.status == ChitCycleStatus.COMPLETED) {
                        Toast.makeText(context, "Completed cycles cannot be rescheduled", Toast.LENGTH_SHORT).show()
                    } else if (isGroupAdmin) {
                        showRescheduleDialog = true
                    } else {
                        Toast.makeText(context, "Only Group Admin can reschedule auctions", Toast.LENGTH_SHORT).show()
                    }
                }
            )

            // 2. Member Eligibility Status Card
            MemberEligibilityCard(
                eligibility = memberEligibility,
                operationalStatus = operationalStatus
            )

            // 3. Current Winning Bid Spotlight (or Sealed Scheme Floor Info if sealed mode for members)
            if (!isBiddingSealed || isGroupAdmin) {
                WinningBidSpotlightCard(
                    curr = curr,
                    totalPot = totalPot,
                    highestBid = highestBid,
                    outcome = estimatedOutcome,
                    totalBidsCount = cycle.bids.count { it.status == ChitBidStatus.VALID },
                    operationalStatus = operationalStatus
                )
            } else {
                SealedBiddingSchemeInfoCard(
                    curr = curr,
                    totalPot = totalPot,
                    minDiscount = minDiscount,
                    maxDiscount = maxDiscount,
                    totalBidsPlaced = cycle.bids.count { it.status == ChitBidStatus.VALID }
                )
            }

            // 4. Interactive Live Bid Submission Card (When Auction is Open)
            if (operationalStatus == ChitCycleStatus.AUCTION_OPEN) {
                BidSubmissionCard(
                    curr = curr,
                    cycleNumber = cycle.cycleNumber,
                    secondsRemaining = secondsRemaining,
                    minDiscount = minDiscount,
                    maxDiscount = maxDiscount,
                    totalPot = totalPot,
                    highestBid = highestBid,
                    userBid = userBid,
                    isEligible = memberEligibility.isEligible,
                    ineligibleReason = memberEligibility.reason,
                    bidAmountInput = customBidInput,
                    onBidAmountChange = { customBidInput = it },
                    onSubmitBid = { amount ->
                        // Triggers Phase B.3 confirmation step before network submission
                        bidToConfirm = amount
                    },
                    onWithdrawBid = {
                        userBid?.let {
                            viewModel.withdrawChitBid(
                                cycleNumber = cycle.cycleNumber,
                                bidId = it.bidId,
                                onSuccess = {
                                    Toast.makeText(context, "Bid withdrawn", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    }
                )
            }

            // 5. Result Preparation, Review & Settlement Preview Card (When auction is closed or in result pending)
            if (operationalStatus in listOf(
                    ChitCycleStatus.AUCTION_CLOSED,
                    ChitCycleStatus.RESULT_PENDING,
                    ChitCycleStatus.RESULT_CALCULATED,
                    ChitCycleStatus.TIE_REQUIRES_ADMIN_REVIEW,
                    ChitCycleStatus.RESULT_REQUIRES_RULE,
                    ChitCycleStatus.RESULT_APPROVED,
                    ChitCycleStatus.RESULT_REJECTED,
                    ChitCycleStatus.SETTLEMENT_PENDING,
                    ChitCycleStatus.SETTLEMENT_PROCESSING,
                    ChitCycleStatus.SETTLED,
                    ChitCycleStatus.SETTLEMENT_FAILED,
                    ChitCycleStatus.COMPLETED
                )
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("auction_result_review_cta_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(imageVector = Icons.Default.Gavel, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(20.dp))
                                Text(
                                    text = "AUCTION RESULT & SETTLEMENT PREVIEW",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = IndigoPrimary
                                )
                            }
                            Surface(
                                color = IndigoPrimary.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = operationalStatus.displayName,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = IndigoPrimary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = if (isGroupAdmin) {
                                "Review verified bids, inspect financial calculations (Prize, Commission, Dividends), and officially approve or reject this auction result."
                            } else {
                                "Inspect published auction outcome, verified winning bids, and calculated member dividends."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Button(
                            onClick = { onNavigateToResultReview(cycle.cycleNumber) },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("open_result_review_btn")
                        ) {
                            Text(
                                text = if (isGroupAdmin) "Open Result Review & Settlement Preview" else "View Full Auction Result",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                AuctionResultPreparationCard(
                    curr = curr,
                    result = preparedResult,
                    isGroupAdmin = isGroupAdmin
                )
            }

            // 6. Controlled Bids Visibility: Admin Audit View vs Member Sealed View vs Open Leaderboard
            if (isGroupAdmin) {
                AdminLiveBidsCard(
                    curr = curr,
                    bids = rankedBids,
                    isBiddingSealed = isBiddingSealed,
                    onToggleVisibility = { newMode ->
                        viewModel.updateBiddingVisibility(
                            visibility = newMode,
                            onSuccess = {
                                Toast.makeText(context, "Bidding visibility set to $newMode", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                )
            } else {
                if (isBiddingSealed) {
                    MemberSealedBidsCard(
                        curr = curr,
                        userBid = userBid,
                        totalBidsPlaced = cycle.bids.count { it.status == ChitBidStatus.VALID },
                        operationalStatus = operationalStatus
                    )
                } else {
                    LiveBidsLeaderboardCard(
                        curr = curr,
                        bids = rankedBids,
                        currentMemberId = currentMemberId ?: 1L,
                        operationalStatus = operationalStatus
                    )
                }
            }

            // 6. Timing & Schedule Window Card
            AuctionScheduleCard(
                cycle = cycle,
                isDateRescheduled = cycle.isDateManuallyRescheduled,
                rescheduleReason = cycle.rescheduleReason
            )

            // 7. Admin Controls Card
            if (isGroupAdmin && cycle.status != ChitCycleStatus.COMPLETED) {
                AdminAuctionControlsCard(
                    cycle = cycle,
                    operationalStatus = operationalStatus,
                    onOpenReschedule = { showRescheduleDialog = true },
                    onCloseFloor = { showCloseFloorDialog = true },
                    onReopenFloor = { showReopenFloorDialog = true }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // Admin Close Floor Dialog
    if (showCloseFloorDialog) {
        AlertDialog(
            onDismissRequest = { showCloseFloorDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = Rose500)
                    Text("Close Bidding Floor", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Text(
                    text = "Are you sure you want to close bidding for Round #${cycle.cycleNumber}? No new bids can be submitted. The status will transition to RESULT_PENDING for result audit.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showCloseFloorDialog = false
                        viewModel.closeAuctionBiddingFloor(
                            cycleNumber = cycle.cycleNumber,
                            onSuccess = {
                                Toast.makeText(context, "Auction closed. Status moved to RESULT_PENDING.", Toast.LENGTH_SHORT).show()
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Rose500)
                ) {
                    Text("Confirm & Close Floor")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCloseFloorDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Admin Reopen Floor Dialog
    if (showReopenFloorDialog) {
        AlertDialog(
            onDismissRequest = { showReopenFloorDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.LockOpen, contentDescription = null, tint = Emerald500)
                    Text("Reopen Auction Floor", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Text(
                    text = "Reopen the live bidding floor for Round #${cycle.cycleNumber} for an additional 15 minutes? Eligible members will immediately be allowed to place bids.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showReopenFloorDialog = false
                        viewModel.reopenAuctionBiddingFloor(
                            cycleNumber = cycle.cycleNumber,
                            additionalMinutes = 15,
                            onSuccess = {
                                Toast.makeText(context, "Auction floor reopened for 15 minutes", Toast.LENGTH_SHORT).show()
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Emerald500)
                ) {
                    Text("Reopen (+15 Min)")
                }
            },
            dismissButton = {
                TextButton(onClick = { showReopenFloorDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Admin Reschedule Dialog
    if (showRescheduleDialog) {
        ChitAuctionRescheduleDialog(
            cycle = cycle,
            onDismiss = { showRescheduleDialog = false },
            onConfirmReschedule = { newDateMillis, newStartTime, newEndTime, reason ->
                viewModel.rescheduleChitCycle(
                    cycleNumber = cycle.cycleNumber,
                    newDateMillis = newDateMillis,
                    newStartTime = newStartTime,
                    newEndTime = newEndTime,
                    reason = reason,
                    onSuccess = {
                        showRescheduleDialog = false
                        Toast.makeText(context, "Round #${cycle.cycleNumber} rescheduled", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        )
    }

    // Phase B.3: Member Bid Confirmation Dialog before authoritative submission
    if (bidToConfirm != null) {
        val amount = bidToConfirm!!
        ChitBidConfirmationDialog(
            amount = amount,
            cycleNumber = cycle.cycleNumber,
            closingTime = cycle.displayAuctionWindow,
            curr = curr,
            totalPot = totalPot,
            onDismiss = { bidToConfirm = null },
            onConfirm = {
                bidToConfirm = null
                viewModel.submitChitBid(
                    cycleNumber = cycle.cycleNumber,
                    bidAmount = amount,
                    onSuccess = {
                        Toast.makeText(context, "Bid of $curr${CurrencyFormatter.formatIndian(amount)} placed successfully!", Toast.LENGTH_SHORT).show()
                    },
                    onError = { err ->
                        Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                    }
                )
            }
        )
    }
}

/**
 * Visual Banner showing active state, countdown, and quick reschedule action.
 */
@Composable
private fun AuctionStatusBannerCard(
    cycle: ChitCycle,
    operationalStatus: ChitCycleStatus,
    secondsRemaining: Long,
    isGroupAdmin: Boolean,
    onRescheduleClick: () -> Unit
) {
    val statusColor = when (operationalStatus) {
        ChitCycleStatus.AUCTION_OPEN -> Emerald500
        ChitCycleStatus.AUCTION_SCHEDULED, ChitCycleStatus.UPCOMING -> IndigoPrimary
        ChitCycleStatus.AUCTION_CLOSED -> MaterialTheme.colorScheme.onSurfaceVariant
        ChitCycleStatus.RESULT_PENDING -> Amber500
        ChitCycleStatus.RESULT_CALCULATED -> IndigoPrimary
        ChitCycleStatus.TIE_REQUIRES_ADMIN_REVIEW -> Amber500
        ChitCycleStatus.RESULT_REQUIRES_RULE -> Rose500
        ChitCycleStatus.RESULT_APPROVED -> Emerald500
        ChitCycleStatus.RESULT_REJECTED -> Rose500
        ChitCycleStatus.SETTLEMENT_PENDING -> IndigoPrimary
        ChitCycleStatus.SETTLEMENT_PROCESSING -> IndigoPrimary
        ChitCycleStatus.SETTLED -> Emerald500
        ChitCycleStatus.SETTLEMENT_FAILED -> Rose500
        ChitCycleStatus.COMPLETED -> Emerald500
        ChitCycleStatus.RESCHEDULED -> Rose500
        ChitCycleStatus.CANCELLED -> MaterialTheme.colorScheme.error
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, statusColor.copy(alpha = 0.4f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = statusColor.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = operationalStatus.displayName.uppercase(Locale.US),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = statusColor,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        fontSize = 11.sp
                    )
                }

                if (cycle.status != ChitCycleStatus.COMPLETED && cycle.status != ChitCycleStatus.SETTLED && isGroupAdmin) {
                    TextButton(onClick = onRescheduleClick) {
                        Icon(imageVector = Icons.Default.EditCalendar, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reschedule", fontSize = 12.sp, color = IndigoPrimary, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Text(
                text = "Round #${cycle.cycleNumber} Chit Auction Floor",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Dynamic Countdown Display
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val countdownTitle = when (operationalStatus) {
                        ChitCycleStatus.AUCTION_OPEN -> "BIDDING CLOSES IN"
                        ChitCycleStatus.AUCTION_SCHEDULED, ChitCycleStatus.UPCOMING, ChitCycleStatus.RESCHEDULED -> "BIDDING FLOOR OPENS IN"
                        ChitCycleStatus.AUCTION_CLOSED -> "AUCTION CLOSED"
                        ChitCycleStatus.RESULT_PENDING -> "RESULT PROCESSING"
                        ChitCycleStatus.RESULT_CALCULATED -> "RESULT READY FOR REVIEW"
                        ChitCycleStatus.TIE_REQUIRES_ADMIN_REVIEW -> "TIE DETECTED - REVIEW REQUIRED"
                        ChitCycleStatus.RESULT_REQUIRES_RULE -> "RULE CONFIGURATION REQUIRED"
                        ChitCycleStatus.RESULT_APPROVED -> "RESULT APPROVED"
                        ChitCycleStatus.RESULT_REJECTED -> "RESULT REJECTED"
                        ChitCycleStatus.SETTLEMENT_PENDING -> "SETTLEMENT PENDING"
                        ChitCycleStatus.SETTLEMENT_PROCESSING -> "SETTLEMENT PROCESSING"
                        ChitCycleStatus.SETTLED -> "SETTLED & COMMITTED"
                        ChitCycleStatus.SETTLEMENT_FAILED -> "SETTLEMENT FAILED"
                        ChitCycleStatus.COMPLETED -> "ROUND COMPLETED"
                        ChitCycleStatus.CANCELLED -> "ROUND CANCELLED"
                    }

                    Text(
                        text = countdownTitle,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = statusColor,
                        letterSpacing = 0.5.sp
                    )

                    if (operationalStatus in listOf(ChitCycleStatus.AUCTION_OPEN, ChitCycleStatus.AUCTION_SCHEDULED, ChitCycleStatus.UPCOMING, ChitCycleStatus.RESCHEDULED)) {
                        Text(
                            text = ChitCalculationEngine.formatCountdown(secondsRemaining),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = statusColor
                        )
                    } else {
                        Text(
                            text = if (operationalStatus == ChitCycleStatus.COMPLETED) "Completed" else "Awaiting Result Audit",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

/**
 * Member Eligibility Badge and Information Card.
 */
@Composable
private fun MemberEligibilityCard(
    eligibility: ChitMemberEligibility,
    operationalStatus: ChitCycleStatus
) {
    val isEligible = eligibility.isEligible
    val badgeColor = if (isEligible) Emerald500 else Rose500

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = badgeColor.copy(alpha = 0.12f),
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (isEligible) Icons.Default.CheckCircle else Icons.Default.Cancel,
                        contentDescription = null,
                        tint = badgeColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = if (isEligible) "Eligible to Bid" else "Participation Ineligible",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.5.sp,
                        color = badgeColor
                    )
                    Text(
                        text = "• ${eligibility.memberName}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    text = eligibility.reason,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/**
 * Current Winning Bid & Financial Outcome Spotlight Card.
 */
@Composable
private fun WinningBidSpotlightCard(
    curr: String,
    totalPot: Double,
    highestBid: ChitBid?,
    outcome: com.adr.groupledger.data.model.EstimatedAuctionOutcome,
    totalBidsCount: Int,
    operationalStatus: ChitCycleStatus
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(imageVector = Icons.Default.EmojiEvents, contentDescription = null, tint = Amber500, modifier = Modifier.size(18.dp))
                    Text(
                        text = if (operationalStatus == ChitCycleStatus.COMPLETED) "WINNING BID OUTCOME" else "CURRENT LEADING BID",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Amber500,
                        letterSpacing = 0.5.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = IndigoPrimary.copy(alpha = 0.1f)
                ) {
                    Text(
                        text = "$totalBidsCount Bids Placed",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            // Highest Discount & Leader Spotlight
            if (highestBid != null) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Highest Bid Discount", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = "$curr${CurrencyFormatter.formatIndian(highestBid.bidAmount)}",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = IndigoPrimary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("Leading Bidder", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = highestBid.memberName,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "No bids placed yet. Bidding floor is open at starting floor of $curr${CurrencyFormatter.formatIndian(outcome.winningDiscountBid)}.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            // Live Calculated Metrics Grid
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Total Pot", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("$curr${CurrencyFormatter.formatIndian(totalPot)}", fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
                }
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Take-Home Prize", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("$curr${CurrencyFormatter.formatIndian(outcome.prizePayoutAmount)}", fontSize = 13.5.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                }
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text("Est. Dividend/Member", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("$curr${CurrencyFormatter.formatIndian(outcome.dividendPerMember)}", fontSize = 13.5.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Foreman Fee (5%)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("$curr${CurrencyFormatter.formatIndian(outcome.foremanCommission)}", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                }
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text("Next Month Net Due", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("$curr${CurrencyFormatter.formatIndian(outcome.netNextInstallment)}", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                }
            }
        }
    }
}

/**
 * Phase B.3 Interactive Live Bid Submission Component.
 * Features:
 * - Simple & modern AUCTION header with cycle and live countdown
 * - Authoritative numeric discount bid input with bounds checking
 * - Instant take-home estimate and quick increment chips
 * - Concise bidding rule guidelines
 */
@Composable
private fun BidSubmissionCard(
    curr: String,
    cycleNumber: Int,
    secondsRemaining: Long,
    minDiscount: Double,
    maxDiscount: Double,
    totalPot: Double,
    highestBid: ChitBid?,
    userBid: ChitBid?,
    isEligible: Boolean,
    ineligibleReason: String,
    bidAmountInput: String,
    onBidAmountChange: (String) -> Unit,
    onSubmitBid: (Double) -> Unit,
    onWithdrawBid: () -> Unit
) {
    val numericAmount = bidAmountInput.toDoubleOrNull() ?: 0.0
    val isValidAmount = numericAmount in minDiscount..maxDiscount

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.35f))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // Section 9: AUCTION Cycle & Countdown Header
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = IndigoPrimary.copy(alpha = 0.08f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("AUCTION", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary, letterSpacing = 1.sp)
                        Text("Cycle #$cycleNumber", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Auction closes in:", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = ChitCalculationEngine.formatCountdown(secondsRemaining),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Emerald500
                        )
                    }
                }
            }

            // User's Current Active Bid Banner (if already submitted)
            if (userBid != null) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Emerald500.copy(alpha = 0.1f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Your Active Bid", fontSize = 11.sp, color = Emerald500, fontWeight = FontWeight.Bold)
                            Text("$curr${CurrencyFormatter.formatIndian(userBid.bidAmount)}", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (highestBid != null && highestBid.bidId == userBid.bidId) {
                                Surface(shape = RoundedCornerShape(6.dp), color = Emerald500) {
                                    Text("LEADING", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                            } else if (highestBid != null) {
                                Surface(shape = RoundedCornerShape(6.dp), color = Rose500) {
                                    Text("OUTBID", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                            }
                            TextButton(
                                onClick = onWithdrawBid,
                                modifier = Modifier.testTag("withdraw_bid_btn")
                            ) {
                                Text("Withdraw", color = Rose500, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Section 9: Your Bid Input Field
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Your Bid",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                OutlinedTextField(
                    value = bidAmountInput,
                    onValueChange = { onBidAmountChange(it.filter { ch -> ch.isDigit() }) },
                    placeholder = { Text("Enter discount amount (e.g. ${minDiscount.toInt()})") },
                    prefix = { Text("$curr ", fontWeight = FontWeight.Bold) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    isError = !isValidAmount && bidAmountInput.isNotBlank(),
                    supportingText = {
                        if (numericAmount < minDiscount && bidAmountInput.isNotBlank()) {
                            Text("Minimum discount floor is $curr${CurrencyFormatter.formatIndian(minDiscount)} (5%)", color = Rose500)
                        } else if (numericAmount > maxDiscount) {
                            Text("Cannot exceed maximum cap of $curr${CurrencyFormatter.formatIndian(maxDiscount)} (30%)", color = Rose500)
                        } else if (!isEligible) {
                            Text(ineligibleReason, color = Rose500)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("bid_amount_input"),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            // Quick Increment Preset Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val base = highestBid?.bidAmount ?: minDiscount
                listOf(500.0, 1000.0, 2000.0).forEach { inc ->
                    val candidate = (base + inc).coerceAtMost(maxDiscount)
                    AssistChip(
                        onClick = { onBidAmountChange(candidate.toInt().toString()) },
                        label = { Text("+₹${inc.toInt()}", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        colors = AssistChipDefaults.assistChipColors(containerColor = MaterialTheme.colorScheme.surface)
                    )
                }
                AssistChip(
                    onClick = { onBidAmountChange(maxDiscount.toInt().toString()) },
                    label = { Text("Max Cap", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.weight(1f),
                    colors = AssistChipDefaults.assistChipColors(containerColor = MaterialTheme.colorScheme.surface)
                )
            }

            // Concise Bidding Rule Guide
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(16.dp))
                    Text(
                        text = "Reverse discount bidding: Offer discount from pot ($curr${CurrencyFormatter.formatIndian(minDiscount)} – $curr${CurrencyFormatter.formatIndian(maxDiscount)}). Highest discount wins.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Submit / Revise Button (Triggers Confirmation Dialog)
            Button(
                onClick = {
                    if (isValidAmount && isEligible) {
                        onSubmitBid(numericAmount)
                    }
                },
                enabled = isEligible && isValidAmount,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("submit_bid_button"),
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.Gavel, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (userBid != null) "Revise Bid to $curr${CurrencyFormatter.formatIndian(numericAmount)}" else "Submit Bid",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }
    }
}

/**
 * Phase B.3 Section 10: Authoritative Confirmation Dialog before bid submission.
 * Prevents accidental or errant bids.
 */
@Composable
private fun ChitBidConfirmationDialog(
    amount: Double,
    cycleNumber: Int,
    closingTime: String,
    curr: String,
    totalPot: Double,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    val estimatedPrize = (totalPot - amount).coerceAtLeast(0.0)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(imageVector = Icons.Default.Gavel, contentDescription = null, tint = IndigoPrimary)
                Text("Confirm Your Bid", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Please review your bid before submission to prevent accidental entries:",
                    fontSize = 12.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Auction:", fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Cycle #$cycleNumber", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Closing Window:", fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(closingTime, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Bid Discount Amount:", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("$curr${CurrencyFormatter.formatIndian(amount)}", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = IndigoPrimary)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Take-Home Prize (if winning):", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("$curr${CurrencyFormatter.formatIndian(estimatedPrize)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                        }
                    }
                }

                Text(
                    text = "Note: In accordance with Chit Fund rules, bids are audited deterministically once the auction closes.",
                    fontSize = 11.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                modifier = Modifier.testTag("confirm_bid_dialog_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Confirm Bid", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

/**
 * Phase B.3 Section 19, 20, 21: Deterministic Result Preparation Card.
 * Shown when auction reaches closing or RESULT_PENDING.
 * Displays candidate winner, tie resolution, and financial preview WITHOUT mutating ledger balances.
 */
@Composable
private fun AuctionResultPreparationCard(
    curr: String,
    result: ChitAuctionResultPreparation,
    isGroupAdmin: Boolean
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("auction_result_preparation_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Amber500.copy(alpha = 0.5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(imageVector = Icons.Default.EmojiEvents, contentDescription = null, tint = Amber500, modifier = Modifier.size(18.dp))
                    Text(
                        text = "AUCTION RESULT AUDIT & PREPARATION",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Amber500,
                        letterSpacing = 0.5.sp
                    )
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Amber500.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "RESULT PENDING",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Amber500,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Candidate Winner", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = result.candidateWinnerMemberName ?: "None (No bids placed)",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Winning Discount Bid", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = "$curr${CurrencyFormatter.formatIndian(result.highestBidAmount ?: 0.0)}",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = IndigoPrimary
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Take-Home Prize", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("$curr${CurrencyFormatter.formatIndian(result.estimatedOutcome?.prizePayoutAmount ?: 0.0)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Foreman Commission", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("$curr${CurrencyFormatter.formatIndian(result.estimatedOutcome?.foremanCommission ?: 0.0)}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Est. Dividend/Member", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("$curr${CurrencyFormatter.formatIndian(result.estimatedOutcome?.dividendPerMember ?: 0.0)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                        }
                    }
                }
            }

            // Section 21: Deterministic Tie Handling Status
            if (result.isTie) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Amber500.copy(alpha = 0.08f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = Amber500, modifier = Modifier.size(16.dp))
                        Text(
                            text = "Tie detected between: ${result.tiedMemberNames.joinToString(", ")}. Deterministically resolved by earliest bid submission timestamp.",
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Section 19: Strict Audit Disclaimer (No funds transferred)
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = IndigoPrimary.copy(alpha = 0.06f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(16.dp))
                    Text(
                        text = "Prepared for audit. Financial settlement, winner payout disbursement, and member ledger posting will be processed in the upcoming Settlement Phase.",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

/**
 * Phase B.3 Section 15: Admin Bid Monitor Card.
 * Allows Group Admins to inspect all bids, submitted times, and toggle visibility.
 */
@Composable
private fun AdminLiveBidsCard(
    curr: String,
    bids: List<ChitBid>,
    isBiddingSealed: Boolean,
    onToggleVisibility: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_bids_list"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ADMIN BIDS MONITOR (AUDIT)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "${bids.size} Total Submissions (${bids.count { it.status == ChitBidStatus.VALID }} Valid)",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                OutlinedButton(
                    onClick = {
                        onToggleVisibility(if (isBiddingSealed) "OPEN" else "SEALED")
                    },
                    modifier = Modifier.testTag("admin_toggle_visibility_btn"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = if (isBiddingSealed) Icons.Default.Lock else Icons.Default.LockOpen,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = IndigoPrimary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isBiddingSealed) "Sealed Mode" else "Open Mode",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary
                    )
                }
            }

            if (bids.isEmpty()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Gavel, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(28.dp))
                        Text("No Bids Submitted Yet", fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                        Text("Submissions from eligible members will appear here in real time.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    bids.forEachIndexed { index, bid ->
                        val isLeader = index == 0 && bid.status == ChitBidStatus.VALID
                        val timeStr = try {
                            val sdf = SimpleDateFormat("hh:mm:ss a", Locale.getDefault())
                            sdf.format(Date(bid.submittedAtMillis))
                        } catch (e: Exception) {
                            "Recent"
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isLeader) Amber500.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceContainerLow,
                            border = BorderStroke(1.dp, if (isLeader) Amber500.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Surface(
                                        shape = CircleShape,
                                        color = if (isLeader) Amber500 else MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "#${index + 1}",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = if (isLeader) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Column {
                                        Text(
                                            text = bid.memberName,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "Time: $timeStr • Status: ${bid.status.displayName}",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "$curr${CurrencyFormatter.formatIndian(bid.bidAmount)}",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 14.5.sp,
                                        color = if (isLeader) Amber500 else IndigoPrimary
                                    )
                                    if (isLeader) {
                                        Text("Highest Bid", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Amber500)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Phase B.3 Section 16 & 17: Normal Member View for Sealed Bidding Schemes.
 * Shows member's own bid and privacy guarantees without exposing other members' bids.
 */
@Composable
private fun MemberSealedBidsCard(
    curr: String,
    userBid: ChitBid?,
    totalBidsPlaced: Int,
    operationalStatus: ChitCycleStatus
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(16.dp))
                    Text(
                        text = "YOUR SUBMISSION STATUS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        letterSpacing = 0.5.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = IndigoPrimary.copy(alpha = 0.1f)
                ) {
                    Text(
                        text = "Sealed Bidding",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            if (userBid != null) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Emerald500.copy(alpha = 0.08f),
                    border = BorderStroke(1.dp, Emerald500.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Your Bid Discount Amount:", fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("$curr${CurrencyFormatter.formatIndian(userBid.bidAmount)}", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Emerald500)
                        }
                        val timeStr = try {
                            val sdf = SimpleDateFormat("hh:mm:ss a", Locale.getDefault())
                            sdf.format(Date(userBid.submittedAtMillis))
                        } catch (e: Exception) {
                            "Recent"
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Status: ${userBid.status.displayName}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                            Text("Submitted at: $timeStr", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "You have not submitted a bid for this cycle yet. Enter your bid discount above during the open window.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            // Sealed Bidding Privacy Notice
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(20.dp))
                    Column {
                        Text("Privacy Preserving Sealed Bidding", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(
                            text = "In accordance with Chit Fund rules, member bids are confidential and sealed until the bidding window closes. Total bids placed across all members: $totalBidsPlaced.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

/**
 * Information Card when Sealed Bidding Scheme is active for normal members.
 */
@Composable
private fun SealedBiddingSchemeInfoCard(
    curr: String,
    totalPot: Double,
    minDiscount: Double,
    maxDiscount: Double,
    totalBidsPlaced: Int
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                    Text(
                        text = "SEALED AUCTION FLOOR",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        letterSpacing = 0.5.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = IndigoPrimary.copy(alpha = 0.1f)
                ) {
                    Text(
                        text = "$totalBidsPlaced Bids Submitted",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Total Pot", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("$curr${CurrencyFormatter.formatIndian(totalPot)}", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Min Floor (5%)", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("$curr${CurrencyFormatter.formatIndian(minDiscount)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                }
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text("Max Cap (30%)", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("$curr${CurrencyFormatter.formatIndian(maxDiscount)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Amber500)
                }
            }
        }
    }
}

/**
 * Real-time Bids Leaderboard / Feed for Open Visibility mode.
 */
@Composable
private fun LiveBidsLeaderboardCard(
    curr: String,
    bids: List<ChitBid>,
    currentMemberId: Long,
    operationalStatus: ChitCycleStatus
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LIVE BIDS FLOOR & RANKINGS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = IndigoPrimary,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "${bids.size} Total Submissions",
                    fontSize = 11.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (bids.isEmpty()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Gavel, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(28.dp))
                        Text("No Bids Submitted Yet", fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                        Text("Eligible subscribers can place bids during the live auction window.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                    }
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("bids_list"),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    bids.forEachIndexed { index, bid ->
                        val isLeader = index == 0 && bid.status == ChitBidStatus.VALID
                        val isSelf = bid.memberId == currentMemberId
                        val timeStr = try {
                            val sdf = SimpleDateFormat("hh:mm:ss a", Locale.getDefault())
                            sdf.format(Date(bid.submittedAtMillis))
                        } catch (e: Exception) {
                            "Recent"
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isLeader) Amber500.copy(alpha = 0.08f) else if (isSelf) IndigoPrimary.copy(alpha = 0.06f) else MaterialTheme.colorScheme.surfaceContainerLow,
                            border = BorderStroke(1.dp, if (isLeader) Amber500.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Surface(
                                        shape = CircleShape,
                                        color = if (isLeader) Amber500 else MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "#${index + 1}",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = if (isLeader) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(
                                                text = bid.memberName,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            if (isSelf) {
                                                Surface(shape = RoundedCornerShape(4.dp), color = IndigoPrimary.copy(alpha = 0.15f)) {
                                                    Text("YOU", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                                }
                                            }
                                        }
                                        Text(
                                            text = "Time: $timeStr • ${bid.status.displayName}",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "$curr${CurrencyFormatter.formatIndian(bid.bidAmount)}",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 14.5.sp,
                                        color = if (isLeader) Amber500 else IndigoPrimary
                                    )
                                    if (isLeader) {
                                        Text("Highest Bid", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Amber500)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Schedule & Time Window details.
 */
@Composable
private fun AuctionScheduleCard(
    cycle: ChitCycle,
    isDateRescheduled: Boolean,
    rescheduleReason: String?
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                text = "SCHEDULE & AUCTION WINDOW",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = IndigoPrimary,
                letterSpacing = 0.5.sp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.Event, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                    Text("Scheduled Date", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(
                    text = cycle.scheduledDate,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.AccessTime, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                    Text("Auction Window", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(
                    text = cycle.displayAuctionWindow,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            if (isDateRescheduled) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Rose500.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = Rose500, modifier = Modifier.size(16.dp))
                    Column {
                        Text("Rescheduled by Administrator", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = Rose500)
                        if (!rescheduleReason.isNullOrBlank()) {
                            Text("Reason: $rescheduleReason", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

/**
 * Group Admin Controls Component.
 */
@Composable
private fun AdminAuctionControlsCard(
    cycle: ChitCycle,
    operationalStatus: ChitCycleStatus,
    onOpenReschedule: () -> Unit,
    onCloseFloor: () -> Unit,
    onReopenFloor: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.25f))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                Text("Group Admin Controls", fontWeight = FontWeight.Bold, fontSize = 13.5.sp, color = IndigoPrimary)
            }

            Text(
                text = "Authorized Group Admins can reschedule auction dates, manually close the bidding floor, or reopen the floor if needed.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = onOpenReschedule,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("admin_reschedule_auction_btn"),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, IndigoPrimary)
                ) {
                    Icon(imageVector = Icons.Default.EditCalendar, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Reschedule", color = IndigoPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                if (operationalStatus == ChitCycleStatus.AUCTION_OPEN) {
                    Button(
                        onClick = onCloseFloor,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("admin_close_auction_btn"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Rose500)
                    ) {
                        Icon(imageVector = Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Close Floor", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                } else if (operationalStatus in listOf(ChitCycleStatus.AUCTION_CLOSED, ChitCycleStatus.RESULT_PENDING)) {
                    Button(
                        onClick = onReopenFloor,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("admin_reopen_auction_btn"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald500)
                    ) {
                        Icon(imageVector = Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reopen (+15m)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

/**
 * Group Admin Dialog to safely reschedule a future auction date and window.
 */
@Composable
private fun ChitAuctionRescheduleDialog(
    cycle: ChitCycle,
    onDismiss: () -> Unit,
    onConfirmReschedule: (newDateMillis: Long, newStartTime: String, newEndTime: String, reason: String) -> Unit
) {
    val context = LocalContext.current
    var selectedDateMillis by remember { mutableLongStateOf(cycle.auctionDateMillis ?: cycle.scheduledDateMillis) }
    var startTime by remember { mutableStateOf(cycle.auctionStartTime ?: "08:00 PM") }
    var endTime by remember { mutableStateOf(cycle.auctionEndTime ?: "08:15 PM") }
    var reasonText by remember { mutableStateOf(cycle.rescheduleReason ?: "") }

    val formattedSelectedDate = remember(selectedDateMillis) {
        val sdf = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())
        sdf.format(Date(selectedDateMillis))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(imageVector = Icons.Default.EditCalendar, contentDescription = null, tint = IndigoPrimary)
                Text("Reschedule Round #${cycle.cycleNumber}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Specify the revised auction date and time window. All members will see the updated schedule on their Home page.",
                    fontSize = 12.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Date Picker trigger
                OutlinedButton(
                    onClick = {
                        val cal = Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
                        DatePickerDialog(
                            context,
                            { _, year, month, dayOfMonth ->
                                val newCal = Calendar.getInstance().apply {
                                    set(Calendar.YEAR, year)
                                    set(Calendar.MONTH, month)
                                    set(Calendar.DAY_OF_MONTH, dayOfMonth)
                                    set(Calendar.HOUR_OF_DAY, 20)
                                    set(Calendar.MINUTE, 0)
                                    set(Calendar.SECOND, 0)
                                    set(Calendar.MILLISECOND, 0)
                                }
                                selectedDateMillis = newCal.timeInMillis
                            },
                            cal.get(Calendar.YEAR),
                            cal.get(Calendar.MONTH),
                            cal.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Date: $formattedSelectedDate", fontSize = 12.5.sp)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Start Time Picker
                    OutlinedButton(
                        onClick = {
                            val cal = Calendar.getInstance()
                            TimePickerDialog(
                                context,
                                { _, hourOfDay, minute ->
                                    val isPm = hourOfDay >= 12
                                    val h = if (hourOfDay % 12 == 0) 12 else hourOfDay % 12
                                    val ampm = if (isPm) "PM" else "AM"
                                    startTime = String.format(Locale.US, "%02d:%02d %s", h, minute, ampm)
                                },
                                20,
                                0,
                                false
                            ).show()
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(text = "Start: $startTime", fontSize = 11.5.sp)
                    }

                    // End Time Picker
                    OutlinedButton(
                        onClick = {
                            val cal = Calendar.getInstance()
                            TimePickerDialog(
                                context,
                                { _, hourOfDay, minute ->
                                    val isPm = hourOfDay >= 12
                                    val h = if (hourOfDay % 12 == 0) 12 else hourOfDay % 12
                                    val ampm = if (isPm) "PM" else "AM"
                                    endTime = String.format(Locale.US, "%02d:%02d %s", h, minute, ampm)
                                },
                                20,
                                15,
                                false
                            ).show()
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(text = "End: $endTime", fontSize = 11.5.sp)
                    }
                }

                OutlinedTextField(
                    value = reasonText,
                    onValueChange = { reasonText = it },
                    label = { Text("Reason for Rescheduling (Optional)") },
                    placeholder = { Text("e.g., Festival holiday or bank closure") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = false,
                    maxLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirmReschedule(selectedDateMillis, startTime, endTime, reasonText)
                },
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
            ) {
                Text("Confirm Reschedule")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
