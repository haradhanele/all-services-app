package com.adr.groupledger.ui.home.template

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.adr.groupledger.ui.components.HomeNotificationCarousel
import com.adr.groupledger.ui.components.SamitiPullToRefreshBox
import com.adr.groupledger.ui.home.HomeTemplateContext
import com.adr.groupledger.ui.home.components.HomeActionCarouselCard
import com.adr.groupledger.ui.home.components.HomeActivityTimelineCard
import com.adr.groupledger.ui.home.components.HomeAnnouncementsCarousel
import com.adr.groupledger.ui.home.components.HomeAssetPortfolioCard
import com.adr.groupledger.ui.home.components.HomeCollectionProgressCard
import com.adr.groupledger.ui.home.components.HomeHeaderBanner

/**
 * Level 2: Puja / Festival Committee Home Template
 */
object PujaFestivalHomeTemplate : GroupHomeTemplate {
    override val templateId: String = "puja_festival_home"
    override val displayName: String = "Puja / Festival Committee Home"

    @Composable
    override fun Render(context: HomeTemplateContext) {
        SamitiPullToRefreshBox(
            isRefreshing = context.isRefreshing,
            onRefresh = { context.viewModel.refreshDashboard() },
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                state = context.listState,
                modifier = Modifier.fillMaxSize().testTag("puja_festival_dashboard"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    HomeHeaderBanner(
                        context = context,
                        onOpenCategorySelector = {
                            context.onCategoryChangeRequest?.invoke(context.category, context.subCategory)
                        }
                    )
                }

                if (context.notifications.isNotEmpty()) {
                    item { HomeNotificationCarousel(notifications = context.notifications) }
                }

                item {
                    HomeActionCarouselCard(
                        context = context,
                        title = "Festival Services & Actions",
                        subtitle = "Chanda, vouchers & events"
                    )
                }

                item {
                    HomeCollectionProgressCard(
                        context = context,
                        title = "Festival Chanda Collection",
                        expectedAmountLabel = "Target Budget",
                        collectedAmountLabel = "Chanda Collected"
                    )
                }

                item {
                    HomeAssetPortfolioCard(
                        context = context,
                        title = "Festival Treasury & Pandal Fund"
                    )
                }

                item {
                    HomeAnnouncementsCarousel(context = context)
                }

                item {
                    HomeActivityTimelineCard(
                        context = context,
                        title = "Recent Chanda & Pandal Expenses"
                    )
                }
            }
        }
    }
}

/**
 * Level 2: Sports & Cultural Club Home Template
 */
object SportsCulturalHomeTemplate : GroupHomeTemplate {
    override val templateId: String = "sports_cultural_home"
    override val displayName: String = "Sports & Cultural Club Home"

    @Composable
    override fun Render(context: HomeTemplateContext) {
        SamitiPullToRefreshBox(
            isRefreshing = context.isRefreshing,
            onRefresh = { context.viewModel.refreshDashboard() },
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                state = context.listState,
                modifier = Modifier.fillMaxSize().testTag("sports_cultural_dashboard"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    HomeHeaderBanner(
                        context = context,
                        onOpenCategorySelector = {
                            context.onCategoryChangeRequest?.invoke(context.category, context.subCategory)
                        }
                    )
                }

                if (context.notifications.isNotEmpty()) {
                    item { HomeNotificationCarousel(notifications = context.notifications) }
                }

                item {
                    HomeActionCarouselCard(
                        context = context,
                        title = "Club Actions & Facilities",
                        subtitle = "Tournaments, kit & dues"
                    )
                }

                item {
                    HomeCollectionProgressCard(
                        context = context,
                        title = "Club Membership Fees",
                        expectedAmountLabel = "Club Dues Target",
                        collectedAmountLabel = "Fees Collected"
                    )
                }

                item {
                    HomeAssetPortfolioCard(
                        context = context,
                        title = "Club Equipment & Ground Fund"
                    )
                }

                item {
                    HomeAnnouncementsCarousel(context = context)
                }

                item {
                    HomeActivityTimelineCard(
                        context = context,
                        title = "Tournament Outflows & Fees"
                    )
                }
            }
        }
    }
}

/**
 * Level 2: Savings & Credit Group Home Template (when not Chit Fund, e.g. SHG)
 */
object SavingsCreditHomeTemplate : GroupHomeTemplate {
    override val templateId: String = "savings_credit_home"
    override val displayName: String = "Savings & Credit / SHG Home"

    @Composable
    override fun Render(context: HomeTemplateContext) {
        SamitiPullToRefreshBox(
            isRefreshing = context.isRefreshing,
            onRefresh = { context.viewModel.refreshDashboard() },
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                state = context.listState,
                modifier = Modifier.fillMaxSize().testTag("savings_credit_dashboard"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    HomeHeaderBanner(
                        context = context,
                        onOpenCategorySelector = {
                            context.onCategoryChangeRequest?.invoke(context.category, context.subCategory)
                        }
                    )
                }

                if (context.notifications.isNotEmpty()) {
                    item { HomeNotificationCarousel(notifications = context.notifications) }
                }

                item {
                    HomeActionCarouselCard(
                        context = context,
                        title = "SHG Credit & Ledger Services",
                        subtitle = "Internal loans, savings & passbook"
                    )
                }

                item {
                    HomeCollectionProgressCard(
                        context = context,
                        title = "Monthly SHG Member Savings",
                        expectedAmountLabel = "Target Savings",
                        collectedAmountLabel = "Savings Deposited"
                    )
                }

                item {
                    HomeAssetPortfolioCard(
                        context = context,
                        title = "Internal Loan Portfolio & Reserves"
                    )
                }

                item {
                    HomeAnnouncementsCarousel(context = context)
                }

                item {
                    HomeActivityTimelineCard(
                        context = context,
                        title = "Recent Loan Disbursals & Repayments"
                    )
                }
            }
        }
    }
}

/**
 * Level 2: Events, Trips, Picnic & Mess Pool Home Template
 */
object EventsTripsHomeTemplate : GroupHomeTemplate {
    override val templateId: String = "events_trips_home"
    override val displayName: String = "Events, Trips & Mess Home"

    @Composable
    override fun Render(context: HomeTemplateContext) {
        SamitiPullToRefreshBox(
            isRefreshing = context.isRefreshing,
            onRefresh = { context.viewModel.refreshDashboard() },
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                state = context.listState,
                modifier = Modifier.fillMaxSize().testTag("events_trips_dashboard"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    HomeHeaderBanner(
                        context = context,
                        onOpenCategorySelector = {
                            context.onCategoryChangeRequest?.invoke(context.category, context.subCategory)
                        }
                    )
                }

                item {
                    HomeActionCarouselCard(
                        context = context,
                        title = "Trip & Pool Management",
                        subtitle = "Split expenses & settlements"
                    )
                }

                item {
                    HomeCollectionProgressCard(
                        context = context,
                        title = "Shared Budget Pool",
                        expectedAmountLabel = "Budget Target",
                        collectedAmountLabel = "Collected From Members"
                    )
                }

                item {
                    HomeAssetPortfolioCard(
                        context = context,
                        title = "Available Trip / Mess Pool Cash"
                    )
                }

                item {
                    HomeAnnouncementsCarousel(context = context)
                }

                item {
                    HomeActivityTimelineCard(
                        context = context,
                        title = "Recent Shared Bills & Splits"
                    )
                }
            }
        }
    }
}

/**
 * Level 2: Family, Friends & Shared Pool Home Template
 */
object FamilyFriendsHomeTemplate : GroupHomeTemplate {
    override val templateId: String = "family_friends_home"
    override val displayName: String = "Family & Friends Pool Home"

    @Composable
    override fun Render(context: HomeTemplateContext) {
        SamitiPullToRefreshBox(
            isRefreshing = context.isRefreshing,
            onRefresh = { context.viewModel.refreshDashboard() },
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                state = context.listState,
                modifier = Modifier.fillMaxSize().testTag("family_friends_dashboard"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    HomeHeaderBanner(
                        context = context,
                        onOpenCategorySelector = {
                            context.onCategoryChangeRequest?.invoke(context.category, context.subCategory)
                        }
                    )
                }

                item {
                    HomeActionCarouselCard(
                        context = context,
                        title = "Shared Services",
                        subtitle = "Groceries, rent & friendly splits"
                    )
                }

                item {
                    HomeCollectionProgressCard(
                        context = context,
                        title = "Monthly Shared Contributions",
                        expectedAmountLabel = "Target Shares",
                        collectedAmountLabel = "Paid In"
                    )
                }

                item {
                    HomeAssetPortfolioCard(
                        context = context,
                        title = "Emergency & Joint Reserves"
                    )
                }

                item {
                    HomeAnnouncementsCarousel(context = context)
                }

                item {
                    HomeActivityTimelineCard(
                        context = context,
                        title = "Recent Expenses & Settles"
                    )
                }
            }
        }
    }
}

/**
 * Level 2: Welfare & NGO Home Template
 */
object WelfareNgoHomeTemplate : GroupHomeTemplate {
    override val templateId: String = "welfare_ngo_home"
    override val displayName: String = "Welfare & NGO Home"

    @Composable
    override fun Render(context: HomeTemplateContext) {
        SamitiPullToRefreshBox(
            isRefreshing = context.isRefreshing,
            onRefresh = { context.viewModel.refreshDashboard() },
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                state = context.listState,
                modifier = Modifier.fillMaxSize().testTag("welfare_ngo_dashboard"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    HomeHeaderBanner(
                        context = context,
                        onOpenCategorySelector = {
                            context.onCategoryChangeRequest?.invoke(context.category, context.subCategory)
                        }
                    )
                }

                if (context.notifications.isNotEmpty()) {
                    item { HomeNotificationCarousel(notifications = context.notifications) }
                }

                item {
                    HomeActionCarouselCard(
                        context = context,
                        title = "Welfare Actions & Aid",
                        subtitle = "Donations, receipts & relief"
                    )
                }

                item {
                    HomeCollectionProgressCard(
                        context = context,
                        title = "Relief & Donation Campaign",
                        expectedAmountLabel = "Campaign Target",
                        collectedAmountLabel = "Donations Received"
                    )
                }

                item {
                    HomeAssetPortfolioCard(
                        context = context,
                        title = "Disaster & Medical Aid Reserves"
                    )
                }

                item {
                    HomeAnnouncementsCarousel(context = context)
                }

                item {
                    HomeActivityTimelineCard(
                        context = context,
                        title = "Recent Aid Allocations & Donors"
                    )
                }
            }
        }
    }
}

/**
 * Level 2: Housing Society / Apartment Home Template
 */
object HousingSocietyHomeTemplate : GroupHomeTemplate {
    override val templateId: String = "housing_society_home"
    override val displayName: String = "Housing Society / Apartment Home"

    @Composable
    override fun Render(context: HomeTemplateContext) {
        SamitiPullToRefreshBox(
            isRefreshing = context.isRefreshing,
            onRefresh = { context.viewModel.refreshDashboard() },
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                state = context.listState,
                modifier = Modifier.fillMaxSize().testTag("housing_society_dashboard"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    HomeHeaderBanner(
                        context = context,
                        onOpenCategorySelector = {
                            context.onCategoryChangeRequest?.invoke(context.category, context.subCategory)
                        }
                    )
                }

                if (context.notifications.isNotEmpty()) {
                    item { HomeNotificationCarousel(notifications = context.notifications) }
                }

                item {
                    HomeActionCarouselCard(
                        context = context,
                        title = "Resident Services & Dues",
                        subtitle = "Maintenance, notices & complaints"
                    )
                }

                item {
                    HomeCollectionProgressCard(
                        context = context,
                        title = "Monthly Flat Maintenance",
                        expectedAmountLabel = "Total Flat Dues",
                        collectedAmountLabel = "Maintenance Collected"
                    )
                }

                item {
                    HomeAssetPortfolioCard(
                        context = context,
                        title = "Sinking Fund & Society Treasury"
                    )
                }

                item {
                    HomeAnnouncementsCarousel(context = context)
                }

                item {
                    HomeActivityTimelineCard(
                        context = context,
                        title = "Recent Utility Bills & Vendor AMC"
                    )
                }
            }
        }
    }
}

/**
 * Level 2: Business & Partnership Home Template
 */
object BusinessPartnershipHomeTemplate : GroupHomeTemplate {
    override val templateId: String = "business_partnership_home"
    override val displayName: String = "Business & Partnership Home"

    @Composable
    override fun Render(context: HomeTemplateContext) {
        SamitiPullToRefreshBox(
            isRefreshing = context.isRefreshing,
            onRefresh = { context.viewModel.refreshDashboard() },
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                state = context.listState,
                modifier = Modifier.fillMaxSize().testTag("business_partnership_dashboard"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    HomeHeaderBanner(
                        context = context,
                        onOpenCategorySelector = {
                            context.onCategoryChangeRequest?.invoke(context.category, context.subCategory)
                        }
                    )
                }

                if (context.notifications.isNotEmpty()) {
                    item { HomeNotificationCarousel(notifications = context.notifications) }
                }

                item {
                    HomeActionCarouselCard(
                        context = context,
                        title = "Partner Actions & Approvals",
                        subtitle = "Capital, invoices & approvals"
                    )
                }

                item {
                    HomeCollectionProgressCard(
                        context = context,
                        title = "Partner Capital & Equity Share",
                        expectedAmountLabel = "Expected Capital",
                        collectedAmountLabel = "Contributed Capital"
                    )
                }

                item {
                    HomeAssetPortfolioCard(
                        context = context,
                        title = "Business Working Capital & Reserves"
                    )
                }

                item {
                    HomeAnnouncementsCarousel(context = context)
                }

                item {
                    HomeActivityTimelineCard(
                        context = context,
                        title = "Recent Inflow & Operational Outflow"
                    )
                }
            }
        }
    }
}

/**
 * Level 2: Other Groups Home Template
 */
object OtherGroupHomeTemplate : GroupHomeTemplate {
    override val templateId: String = "other_group_home"
    override val displayName: String = "Other Group Home"

    @Composable
    override fun Render(context: HomeTemplateContext) {
        // Leverages the clean Generic fallback template
        GenericGroupHomeTemplate.Render(context)
    }
}
