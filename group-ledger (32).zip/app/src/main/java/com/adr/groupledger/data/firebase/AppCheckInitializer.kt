package com.adr.groupledger.data.firebase

import android.content.Context
import android.util.Log
import com.adr.groupledger.BuildConfig
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory

/**
 * Phase C.3 — Firebase App Check Initialization & Hardening.
 *
 * Provides safe, architecture-compliant App Check initialization:
 * - Debug Builds: Dynamically invokes DebugAppCheckProviderFactory via reflection (debug-only dependency)
 *   or gracefully falls back in emulator/unit test environments without crashing.
 * - Release Builds: Uses zero-secret, Google Play backed PlayIntegrityAppCheckProviderFactory.
 * - Production Enforcement: Strictly maintained as OPT-IN / DISABLED until deployment verification.
 */
object AppCheckInitializer {
    private const val TAG = "AppCheckInitializer"

    @Volatile
    private var isInitialized = false

    fun isReady(): Boolean = isInitialized

    fun initialize(context: Context) {
        if (isInitialized) return
        synchronized(this) {
            if (isInitialized) return

            try {
                if (FirebaseApp.getApps(context).isEmpty()) {
                    FirebaseApp.initializeApp(context)
                }

                val appCheck = FirebaseAppCheck.getInstance()

                if (BuildConfig.DEBUG) {
                    try {
                        val debugFactoryClass = Class.forName("com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory")
                        val getInstanceMethod = debugFactoryClass.getMethod("getInstance")
                        val factory = getInstanceMethod.invoke(null) as com.google.firebase.appcheck.AppCheckProviderFactory
                        appCheck.installAppCheckProviderFactory(factory)
                        Log.i(TAG, "App Check initialized with DebugAppCheckProviderFactory for local/emulator development")
                    } catch (e: Exception) {
                        Log.d(TAG, "Debug App Check provider not attached or running in test/emulator environment: ${e.message}")
                    }
                } else {
                    try {
                        val playIntegrityFactory = PlayIntegrityAppCheckProviderFactory.getInstance()
                        appCheck.installAppCheckProviderFactory(playIntegrityFactory)
                        Log.i(TAG, "App Check initialized with PlayIntegrityAppCheckProviderFactory for production release")
                    } catch (e: Exception) {
                        Log.w(TAG, "Release App Check PlayIntegrity initialization deferred: ${e.message}")
                    }
                }
                isInitialized = true
            } catch (e: Exception) {
                Log.w(TAG, "Firebase App Check initialization safely bypassed (e.g. unconfigured Firebase or test environment): ${e.message}")
                isInitialized = true
            }
        }
    }
}
