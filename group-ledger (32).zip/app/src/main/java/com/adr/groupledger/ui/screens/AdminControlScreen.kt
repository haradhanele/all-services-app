package com.adr.groupledger.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.ChitCycle
import com.adr.groupledger.data.model.ChitCycleStatus
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.Amber500

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminControlScreen(
    viewModel: SocietyViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToExceptions: () -> Unit,
    modifier: Modifier = Modifier
) {
    val chitConfig by viewModel.chitFundConfig.collectAsStateWithLifecycle()
    val cycles = chitConfig.cycles
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()

    var selectedCycleForPostpone by remember { mutableStateOf<ChitCycle?>(null) }
    var selectedCycleForCancel by remember { mutableStateOf<ChitCycle?>(null) }
    var selectedCycleForReview by remember { mutableStateOf<ChitCycle?>(null) }
    var reasonInput by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Chit Fund Admin Control", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Cycle Management, Postponement & Governance", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    TextButton(onClick = onNavigateBack) {
                        Text("Back")
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToExceptions, modifier = Modifier.testTag("admin_exceptions_button")) {
                        Icon(imageVector = Icons.Default.Warning, contentDescription = "Exceptions", tint = Amber500)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = IndigoPrimary.copy(alpha = 0.08f)),
                    border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.AdminPanelSettings, contentDescription = null, tint = IndigoPrimary)
                            Spacer(modifier = Modifier.size(8.dp))
                            Text("Secure Governance & Audit Active", fontWeight = FontWeight.Bold, color = IndigoPrimary)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "All administrative interventions (auction postponements, cancellations, result approvals) are cryptographically or transactionally recorded in Audit Logs.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item {
                Text("Active & Scheduled Cycles (${cycles.size})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }

            items(cycles, key = { it.cycleNumber }) { cycle ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_cycle_card_${cycle.cycleNumber}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Cycle #${cycle.cycleNumber}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = when (cycle.status) {
                                    ChitCycleStatus.SETTLED -> Emerald500.copy(alpha = 0.15f)
                                    ChitCycleStatus.CANCELLED -> Rose500.copy(alpha = 0.15f)
                                    ChitCycleStatus.AUCTION_OPEN -> IndigoPrimary.copy(alpha = 0.15f)
                                    else -> Amber500.copy(alpha = 0.15f)
                                }
                            ) {
                                Text(
                                    text = cycle.status.displayName,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = when (cycle.status) {
                                        ChitCycleStatus.SETTLED -> Emerald500
                                        ChitCycleStatus.CANCELLED -> Rose500
                                        ChitCycleStatus.AUCTION_OPEN -> IndigoPrimary
                                        else -> Amber500
                                    }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Scheduled Date: ${cycle.scheduledDate} (${cycle.displayAuctionWindow})", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (!cycle.winnerMemberName.isNullOrBlank()) {
                            Text("Winner: ${cycle.winnerMemberName} (${settings.currencySymbol}${cycle.winningBidAmount ?: 0.0})", fontSize = 12.sp, color = Emerald500, fontWeight = FontWeight.Medium)
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (!cycle.status.isTerminal()) {
                                OutlinedButton(
                                    onClick = { selectedCycleForPostpone = cycle },
                                    modifier = Modifier.weight(1f).testTag("postpone_btn_${cycle.cycleNumber}"),
                                    contentPadding = PaddingValues(4.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.size(4.dp))
                                    Text("Postpone", fontSize = 11.sp)
                                }
                                OutlinedButton(
                                    onClick = { selectedCycleForCancel = cycle },
                                    modifier = Modifier.weight(1f).testTag("cancel_btn_${cycle.cycleNumber}"),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Rose500),
                                    contentPadding = PaddingValues(4.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Block, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.size(4.dp))
                                    Text("Cancel", fontSize = 11.sp)
                                }
                            }
                            if (cycle.status in listOf(ChitCycleStatus.AUCTION_CLOSED, ChitCycleStatus.RESULT_PENDING, ChitCycleStatus.RESULT_CALCULATED)) {
                                Button(
                                    onClick = { selectedCycleForReview = cycle },
                                    modifier = Modifier.weight(1f).testTag("review_btn_${cycle.cycleNumber}"),
                                    colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                                    contentPadding = PaddingValues(4.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Gavel, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.size(4.dp))
                                    Text("Review & Approve", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Postpone Dialog
    selectedCycleForPostpone?.let { cycle ->
        AlertDialog(
            onDismissRequest = { selectedCycleForPostpone = null; reasonInput = "" },
            title = { Text("Postpone Auction for Cycle #${cycle.cycleNumber}?") },
            text = {
                Column {
                    Text("Provide a valid reason for rescheduling this auction. This action will be audited.")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = reasonInput,
                        onValueChange = { reasonInput = it },
                        label = { Text("Reason for Postponement") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (reasonInput.isNotBlank()) {
                            viewModel.postponeChitAuction(cycle.cycleNumber, reasonInput)
                            selectedCycleForPostpone = null
                            reasonInput = ""
                        }
                    },
                    enabled = reasonInput.isNotBlank()
                ) {
                    Text("Confirm Postpone")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedCycleForPostpone = null; reasonInput = "" }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Cancel Dialog
    selectedCycleForCancel?.let { cycle ->
        AlertDialog(
            onDismissRequest = { selectedCycleForCancel = null; reasonInput = "" },
            title = { Text("Cancel Auction for Cycle #${cycle.cycleNumber}?") },
            text = {
                Column {
                    Text("This will mark Cycle #${cycle.cycleNumber} as CANCELLED. Existing bids remain as historical audit records.")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = reasonInput,
                        onValueChange = { reasonInput = it },
                        label = { Text("Reason for Cancellation") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (reasonInput.isNotBlank()) {
                            viewModel.cancelChitAuction(cycle.cycleNumber, reasonInput)
                            selectedCycleForCancel = null
                            reasonInput = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                    enabled = reasonInput.isNotBlank()
                ) {
                    Text("Confirm Cancel")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedCycleForCancel = null; reasonInput = "" }) {
                    Text("Back")
                }
            }
        )
    }

    // Result Review & Approval Dialog
    selectedCycleForReview?.let { cycle ->
        AlertDialog(
            onDismissRequest = { selectedCycleForReview = null },
            title = { Text("Approve Result for Cycle #${cycle.cycleNumber}?") },
            text = {
                Column {
                    Text("Winner: ${cycle.winnerMemberName ?: "None"}")
                    Text("Winning Bid: ${settings.currencySymbol}${cycle.winningBidAmount ?: 0.0}")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Once approved, the result becomes immutable and triggers financial settlement processing.")
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.approveChitAuctionResult(cycle.cycleNumber)
                        selectedCycleForReview = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Emerald500)
                ) {
                    Text("Approve Result")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedCycleForReview = null }) {
                    Text("Close")
                }
            }
        )
    }
}
