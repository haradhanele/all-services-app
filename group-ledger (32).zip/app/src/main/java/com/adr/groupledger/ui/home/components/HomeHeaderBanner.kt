package com.adr.groupledger.ui.home.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adr.groupledger.ui.home.HomeTemplateContext
import com.adr.groupledger.ui.screens.demo.GroupCategory
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoHeroSubtext
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.utils.CurrencyFormatter

data class HeaderFinancialLabels(
    val primaryLabel: String,
    val primaryValue: String,
    val secondaryLabel: String,
    val secondaryValue: String,
    val subMetrics: List<Triple<String, String, Color>>
)

/**
 * Reusable Signature Indigo gradient hero banner matching the baseline Group Ledger design.
 * Dynamically presents category-aware financial headlines and sub-metrics.
 */
@Composable
fun HomeHeaderBanner(
    context: HomeTemplateContext,
    customLabels: HeaderFinancialLabels? = null,
    onOpenCategorySelector: (() -> Unit)? = null
) {
    val settings = context.settings
    val financials = context.financials
    val category = context.category
    val subCategory = context.subCategory

    val labels = customLabels ?: getCategoryFinancialLabels(context)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("dashboard_header_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color(0xFF1E1B4B),
                            Color(0xFF312E81),
                            Color(0xFF3730A3)
                        )
                    )
                )
                .padding(14.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Top row: Group identity + Category badge + Admin pill
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.15f),
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = category.icon,
                                    contentDescription = category.title,
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        Column {
                            Text(
                                text = settings.groupName.ifBlank { "Group Ledger" },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 16.5.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = if (settings.groupSubtitle.isNotBlank()) settings.groupSubtitle else subCategory,
                                style = MaterialTheme.typography.bodySmall,
                                color = IndigoHeroSubtext,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // Admin pill
                    Surface(
                        shape = CircleShape,
                        color = Color.White.copy(alpha = 0.15f),
                        modifier = Modifier.padding(start = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Icon(
                                imageVector = if (context.isAdminUnlocked) Icons.Default.LockOpen else Icons.Default.Lock,
                                contentDescription = "Admin Security",
                                tint = Color.White,
                                modifier = Modifier.size(11.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = if (context.isAdminUnlocked) "Admin Active" else "Protected",
                                color = Color.White,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // Category & SubCategory selector pill
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White.copy(alpha = 0.12f),
                        border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.25f)),
                        modifier = Modifier
                            .clickable(enabled = onOpenCategorySelector != null) {
                                onOpenCategorySelector?.invoke()
                            }
                            .testTag("home_category_pill")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(Emerald500, CircleShape)
                            )
                            Text(
                                text = "${category.title} • $subCategory",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (onOpenCategorySelector != null) {
                                Icon(
                                    imageVector = Icons.Default.Category,
                                    contentDescription = "Switch Category",
                                    tint = Color.White.copy(alpha = 0.7f),
                                    modifier = Modifier.size(11.dp)
                                )
                            }
                        }
                    }
                }

                // Primary & Secondary Financial Metrics Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(
                            text = labels.primaryLabel.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = IndigoHeroSubtext,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = labels.primaryValue,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 20.sp
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = labels.secondaryLabel.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = IndigoHeroSubtext,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = labels.secondaryValue,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (labels.secondaryLabel.contains("Due", true) || labels.secondaryLabel.contains("Pending", true)) Color(0xFFFCA5A5) else Color(0xFFA7F3D0),
                            fontSize = 16.sp
                        )
                    }
                }

                // 3 Sub-metrics Surface
                if (labels.subMetrics.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.White.copy(alpha = 0.10f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            labels.subMetrics.forEach { (lbl, valStr, color) ->
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = lbl,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = IndigoHeroSubtext,
                                        fontSize = 8.5.sp
                                    )
                                    Text(
                                        text = valStr,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = color,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Computes category-aware financial values from the real [HomeTemplateContext.financials]
 * and [GroupSettings.currencySymbol].
 */
fun getCategoryFinancialLabels(context: HomeTemplateContext): HeaderFinancialLabels {
    val curr = context.settings.currencySymbol
    val fin = context.financials
    val category = context.category
    val sub = context.subCategory

    val totalAssetsStr = "$curr${CurrencyFormatter.formatIndian(fin.totalGroupAssets)}"
    val dueStr = "$curr${CurrencyFormatter.formatIndian(fin.totalDueAllTime + fin.outstandingLoans)}"
    val invStr = "$curr${CurrencyFormatter.formatIndian(fin.totalInvestmentsValue)}"
    val expStr = "$curr${CurrencyFormatter.formatIndian(fin.totalExpenses)}"
    val inHandStr = "$curr${CurrencyFormatter.formatIndian(fin.cashBalance + fin.bankBalance)}"

    return when (category) {
        GroupCategory.COMMUNITY_FUND -> HeaderFinancialLabels(
            primaryLabel = "Total Group Assets",
            primaryValue = totalAssetsStr,
            secondaryLabel = "Due Amount",
            secondaryValue = dueStr,
            subMetrics = listOf(
                Triple("Investment", invStr, Color(0xFFA7F3D0)),
                Triple("Expenses", expStr, Color(0xFFFDE68A)),
                Triple("In-Hand Bal", inHandStr, Color.White)
            )
        )
        GroupCategory.PUJA_FESTIVAL -> HeaderFinancialLabels(
            primaryLabel = "Total Chanda Collection",
            primaryValue = totalAssetsStr,
            secondaryLabel = "Pending Chanda",
            secondaryValue = dueStr,
            subMetrics = listOf(
                Triple("Pandal / Stage", expStr, Color(0xFFFDE68A)),
                Triple("Bhog & Prasad", invStr, Color(0xFFA7F3D0)),
                Triple("Cash in Hand", inHandStr, Color.White)
            )
        )
        GroupCategory.SPORTS_CULTURAL -> HeaderFinancialLabels(
            primaryLabel = "Club Treasury Balance",
            primaryValue = inHandStr,
            secondaryLabel = "Member Dues",
            secondaryValue = dueStr,
            subMetrics = listOf(
                Triple("Kit & Gear", invStr, Color(0xFFA7F3D0)),
                Triple("Ground / AMC", expStr, Color(0xFFFDE68A)),
                Triple("Total Fund", totalAssetsStr, Color.White)
            )
        )
        GroupCategory.SAVINGS_CREDIT_CHIT -> {
            if (sub.contains("Chit", ignoreCase = true)) {
                HeaderFinancialLabels(
                    primaryLabel = "Total Chit Fund Value",
                    primaryValue = "$curr${CurrencyFormatter.formatIndian(1000000.0)}",
                    secondaryLabel = "Installment Pool",
                    secondaryValue = inHandStr,
                    subMetrics = listOf(
                        Triple("Collected", totalAssetsStr, Color(0xFFA7F3D0)),
                        Triple("Pending", dueStr, Color(0xFFFDE68A)),
                        Triple("Chit Balance", inHandStr, Color.White)
                    )
                )
            } else {
                HeaderFinancialLabels(
                    primaryLabel = "SHG Revolving Pool",
                    primaryValue = totalAssetsStr,
                    secondaryLabel = "Loans Outstanding",
                    secondaryValue = "$curr${CurrencyFormatter.formatIndian(fin.outstandingLoans)}",
                    subMetrics = listOf(
                        Triple("Savings Pool", inHandStr, Color(0xFFA7F3D0)),
                        Triple("Interest", invStr, Color(0xFFFDE68A)),
                        Triple("Total Assets", totalAssetsStr, Color.White)
                    )
                )
            }
        }
        GroupCategory.EVENTS_TRIPS -> HeaderFinancialLabels(
            primaryLabel = if (sub.contains("Mess", ignoreCase = true)) "Mess Monthly Pool" else "Trip Budget Pool",
            primaryValue = totalAssetsStr,
            secondaryLabel = "Pending Shares",
            secondaryValue = dueStr,
            subMetrics = listOf(
                Triple("Outflow / Spent", expStr, Color(0xFFFDE68A)),
                Triple("Advance Paid", invStr, Color(0xFFA7F3D0)),
                Triple("Pool Balance", inHandStr, Color.White)
            )
        )
        GroupCategory.FAMILY_FRIENDS -> HeaderFinancialLabels(
            primaryLabel = "Shared Expense Pool",
            primaryValue = totalAssetsStr,
            secondaryLabel = "Pending Settles",
            secondaryValue = dueStr,
            subMetrics = listOf(
                Triple("Shared Bills", expStr, Color(0xFFFDE68A)),
                Triple("Investments", invStr, Color(0xFFA7F3D0)),
                Triple("Balance", inHandStr, Color.White)
            )
        )
        GroupCategory.WELFARE_NGO -> HeaderFinancialLabels(
            primaryLabel = "Welfare Donation Fund",
            primaryValue = totalAssetsStr,
            secondaryLabel = "Pledged Dues",
            secondaryValue = dueStr,
            subMetrics = listOf(
                Triple("Aid Disbursed", expStr, Color(0xFFA7F3D0)),
                Triple("Reserve Fund", invStr, Color(0xFFFDE68A)),
                Triple("Available Cash", inHandStr, Color.White)
            )
        )
        GroupCategory.HOUSING_APARTMENT -> HeaderFinancialLabels(
            primaryLabel = "Maintenance Fund",
            primaryValue = totalAssetsStr,
            secondaryLabel = "Pending Flat Dues",
            secondaryValue = dueStr,
            subMetrics = listOf(
                Triple("Staff & Security", expStr, Color(0xFFFDE68A)),
                Triple("Sinking Fund", invStr, Color(0xFFA7F3D0)),
                Triple("Society Cash", inHandStr, Color.White)
            )
        )
        GroupCategory.BUSINESS_PARTNERSHIP -> HeaderFinancialLabels(
            primaryLabel = "Business Capital Pool",
            primaryValue = totalAssetsStr,
            secondaryLabel = "Accounts Due",
            secondaryValue = dueStr,
            subMetrics = listOf(
                Triple("Revenue", inHandStr, Color(0xFFA7F3D0)),
                Triple("Expenses", expStr, Color(0xFFFDE68A)),
                Triple("Net Reserves", invStr, Color.White)
            )
        )
        GroupCategory.OTHER_GROUPS -> HeaderFinancialLabels(
            primaryLabel = "Total Committee Assets",
            primaryValue = totalAssetsStr,
            secondaryLabel = "Due Amount",
            secondaryValue = dueStr,
            subMetrics = listOf(
                Triple("Investments", invStr, Color(0xFFA7F3D0)),
                Triple("Expenses", expStr, Color(0xFFFDE68A)),
                Triple("In-Hand Bal", inHandStr, Color.White)
            )
        )
    }
}
