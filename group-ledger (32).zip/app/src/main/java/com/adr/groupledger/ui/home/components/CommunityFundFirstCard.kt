package com.adr.groupledger.ui.home.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adr.groupledger.ui.home.HomeTemplateContext
import com.adr.groupledger.ui.theme.IndigoHeroSubtext
import com.adr.groupledger.utils.CurrencyFormatter

/**
 * Original Community Fund Signature First Card.
 *
 * Faithfully preserves the authentic visual baseline for Community Fund category:
 * - Group Name & Subtitle on top left
 * - Admin Security Status Pill (Admin Active / Protected) on top right
 * - Total Group Assets on middle left
 * - Due Amount on middle right
 * - Rounded Translucent Sub-Metrics Pill (Investment, Expenses, In-Hand Balance) on bottom
 */
@Composable
fun CommunityFundFirstCard(
    context: HomeTemplateContext,
    modifier: Modifier = Modifier
) {
    val settings = context.settings
    val financials = context.financials
    val curr = settings.currencySymbol.ifBlank { "₹" }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("dashboard_header_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color(0xFF1E1B4B),
                            Color(0xFF312E81),
                            Color(0xFF3730A3)
                        )
                    )
                )
                .padding(14.dp)
        ) {
            Column {
                // Top Row: Group Name & Subtitle + Admin Status Pill
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = settings.groupName.ifBlank { "Community Fund" },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 17.sp
                        )
                        if (settings.groupSubtitle.isNotBlank()) {
                            Spacer(modifier = Modifier.height(1.dp))
                            Text(
                                text = settings.groupSubtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = IndigoHeroSubtext,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Admin status pill
                    Surface(
                        shape = CircleShape,
                        color = Color.White.copy(alpha = 0.15f),
                        modifier = Modifier.padding(start = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Icon(
                                imageVector = if (context.isAdminUnlocked) Icons.Default.LockOpen else Icons.Default.Lock,
                                contentDescription = "Admin Security",
                                tint = Color.White,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = if (context.isAdminUnlocked) "Admin Active" else "Protected",
                                color = Color.White,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Middle Row: Total Group Assets & Due Amount
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "TOTAL GROUP ASSETS",
                            style = MaterialTheme.typography.labelSmall,
                            color = IndigoHeroSubtext,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "$curr${CurrencyFormatter.formatIndian(financials.totalGroupAssets)}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 19.sp
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "DUE AMOUNT",
                            style = MaterialTheme.typography.labelSmall,
                            color = IndigoHeroSubtext,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        val totalDue = financials.totalDueAllTime + financials.outstandingLoans
                        Text(
                            text = "$curr${CurrencyFormatter.formatIndian(totalDue)}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFCA5A5),
                            fontSize = 16.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Bottom Row: Sub-metrics (Investment, Expenses, In-Hand Balance)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.White.copy(alpha = 0.10f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Investment", fontSize = 9.5.sp, color = IndigoHeroSubtext)
                            Text(
                                text = "$curr${CurrencyFormatter.formatIndian(financials.totalInvestmentsValue)}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Expenses", fontSize = 9.5.sp, color = IndigoHeroSubtext)
                            Text(
                                text = "$curr${CurrencyFormatter.formatIndian(financials.totalExpenses)}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("In-Hand Balance", fontSize = 9.5.sp, color = IndigoHeroSubtext)
                            Text(
                                text = "$curr${CurrencyFormatter.formatIndian(financials.availableInHandBalance)}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFA7F3D0)
                            )
                        }
                    }
                }
            }
        }
    }
}
