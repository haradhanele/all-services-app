package com.adr.groupledger

import com.adr.groupledger.data.model.ChitFundConfig
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.ui.home.template.HomeTemplateRegistry
import com.adr.groupledger.ui.screens.demo.GroupCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ChitFundConfigTest {

    @Test
    fun testChitFundConfigParsingAndEncoding() {
        val originalSettings = GroupSettings(
            id = 1L,
            groupName = "Lucky Star Chit Fund",
            defaultContribution = 10000.0,
            dueDayOfMonth = 15
        )

        // 1. Initial parse fallback
        val defaultConfig = ChitFundConfig.parseFromSettings(originalSettings)
        assertEquals(10000.0, defaultConfig.monthlyInstallment ?: 0.0, 0.01)
        assertEquals(15, defaultConfig.auctionScheduleDay)

        // 2. Custom config encoding
        val customConfig = ChitFundConfig(
            totalChits = 20,
            currentChitNo = 9,
            totalValue = 500000.0,
            monthlyInstallment = 25000.0,
            auctionScheduleDay = 28,
            auctionTime = "07:30 PM",
            auctionState = "OPEN"
        )
        val updatedSettings = ChitFundConfig.encodeIntoSettings(originalSettings, customConfig)
        assertTrue(updatedSettings.modulesConfigJson.contains("chitConfig"))

        // 3. Parse back from JSON
        val parsedConfig = ChitFundConfig.parseFromSettings(updatedSettings)
        assertEquals(20, parsedConfig.totalChits)
        assertEquals(9, parsedConfig.currentChitNo)
        assertEquals(500000.0, parsedConfig.totalValue ?: 0.0, 0.01)
        assertEquals(25000.0, parsedConfig.monthlyInstallment ?: 0.0, 0.01)
        assertEquals(28, parsedConfig.auctionScheduleDay)
        assertEquals("07:30 PM", parsedConfig.auctionTime)
        assertEquals("OPEN", parsedConfig.auctionState)

        // 4. Resolve Next Auction Epoch
        val epoch = parsedConfig.resolveNextAuctionEpoch(updatedSettings)
        assertNotNull(epoch)
        assertTrue(epoch!! > 0L)
    }

    @Test
    fun testHomeTemplateResolverResolution() {
        val chitTemplate = HomeTemplateRegistry.resolve(
            GroupCategory.SAVINGS_CREDIT_CHIT,
            "Chit Fund"
        )
        assertEquals("chit_fund_home", chitTemplate.templateId)

        val shgTemplate = HomeTemplateRegistry.resolve(
            GroupCategory.SAVINGS_CREDIT_CHIT,
            "Self-Help Group (SHG)"
        )
        assertEquals("savings_credit_home", shgTemplate.templateId)

        val housingTemplate = HomeTemplateRegistry.resolve(
            GroupCategory.HOUSING_APARTMENT,
            "Apartment Society"
        )
        assertEquals("housing_society_home", housingTemplate.templateId)
    }
}
