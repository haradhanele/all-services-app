package com.adr.groupledger

import com.adr.groupledger.data.model.ChitAuctionCallStage
import com.adr.groupledger.data.model.ChitAuctionRules
import com.adr.groupledger.data.model.ChitCycle
import com.adr.groupledger.data.model.ChitCycleStatus
import com.adr.groupledger.data.model.DiscountDistributionRule
import com.adr.groupledger.utils.ChitCalculationEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.util.Calendar

@RunWith(RobolectricTestRunner::class)
class ChitCalculationEngineTest {

    @Test
    fun testGenerateMonthlyScheduleSafeMonthEnd() {
        // Start date: January 31st
        val cal = Calendar.getInstance().apply {
            set(2026, Calendar.JANUARY, 31, 20, 0, 0)
        }
        val startMillis = cal.timeInMillis

        val cycles = ChitCalculationEngine.generateOrUpdateCycleSchedule(
            existingCycles = emptyList(),
            totalCycles = 3,
            installmentAmount = 5000.0,
            startDateMillis = startMillis,
            frequency = "MONTHLY",
            auctionScheduleDay = 31,
            auctionStartTime = "08:00 PM",
            auctionEndTime = "08:15 PM",
            auctionDurationMinutes = 15
        )

        assertEquals(3, cycles.size)
        assertEquals(1, cycles[0].cycleNumber)
        assertEquals(2, cycles[1].cycleNumber)
        assertEquals(3, cycles[2].cycleNumber)

        // Verify cycle 2 is February and doesn't spill into March
        val febCal = Calendar.getInstance().apply { timeInMillis = cycles[1].scheduledDateMillis }
        assertEquals(Calendar.FEBRUARY, febCal.get(Calendar.MONTH))
        assertEquals(28, febCal.get(Calendar.DAY_OF_MONTH))

        // Verify cycle 3 is March 31
        val marCal = Calendar.getInstance().apply { timeInMillis = cycles[2].scheduledDateMillis }
        assertEquals(Calendar.MARCH, marCal.get(Calendar.MONTH))
        assertEquals(31, marCal.get(Calendar.DAY_OF_MONTH))
    }

    @Test
    fun testCycleStatusTransitions() {
        // Valid transitions
        assertTrue(ChitCycleStatus.UPCOMING.canTransitionTo(ChitCycleStatus.AUCTION_SCHEDULED))
        assertTrue(ChitCycleStatus.AUCTION_SCHEDULED.canTransitionTo(ChitCycleStatus.AUCTION_OPEN))
        assertTrue(ChitCycleStatus.AUCTION_OPEN.canTransitionTo(ChitCycleStatus.AUCTION_CLOSED))
        assertTrue(ChitCycleStatus.AUCTION_CLOSED.canTransitionTo(ChitCycleStatus.RESULT_PENDING))
        assertTrue(ChitCycleStatus.RESULT_PENDING.canTransitionTo(ChitCycleStatus.COMPLETED))

        // Rescheduling allowed for non-terminal states
        assertTrue(ChitCycleStatus.UPCOMING.canTransitionTo(ChitCycleStatus.RESCHEDULED))
        assertTrue(ChitCycleStatus.AUCTION_SCHEDULED.canTransitionTo(ChitCycleStatus.RESCHEDULED))

        // Completed cycles cannot transition to active/open/rescheduled
        assertFalse(ChitCycleStatus.COMPLETED.canTransitionTo(ChitCycleStatus.UPCOMING))
        assertFalse(ChitCycleStatus.COMPLETED.canTransitionTo(ChitCycleStatus.AUCTION_OPEN))
        assertFalse(ChitCycleStatus.COMPLETED.canTransitionTo(ChitCycleStatus.RESCHEDULED))
        assertTrue(ChitCycleStatus.COMPLETED.isTerminal())
    }

    @Test
    fun testDeriveOperationalStatus() {
        val cal = Calendar.getInstance().apply {
            set(2026, Calendar.OCTOBER, 5, 20, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startMillis = cal.timeInMillis // 08:00 PM
        val nowDuring = startMillis + 5 * 60 * 1000L // 08:05 PM (during 15 min window)
        val nowBefore = startMillis - 60 * 1000L // 07:59 PM (before auction)
        val nowAfter = startMillis + 20 * 60 * 1000L // 08:20 PM (after auction)

        val cycle = ChitCycle(
            cycleNumber = 1,
            scheduledDateMillis = startMillis,
            auctionDateMillis = startMillis,
            status = ChitCycleStatus.AUCTION_SCHEDULED,
            auctionStartTime = "08:00 PM",
            auctionEndTime = "08:15 PM",
            auctionDurationMinutes = 15
        )

        // During auction window -> AUCTION_OPEN
        val currentStatus = cycle.deriveOperationalStatus(nowDuring)
        assertEquals(ChitCycleStatus.AUCTION_OPEN, currentStatus)

        // Before auction window -> AUCTION_SCHEDULED
        val beforeStatus = cycle.deriveOperationalStatus(nowBefore)
        assertEquals(ChitCycleStatus.AUCTION_SCHEDULED, beforeStatus)

        // After auction window -> AUCTION_CLOSED
        val afterStatus = cycle.deriveOperationalStatus(nowAfter)
        assertEquals(ChitCycleStatus.AUCTION_CLOSED, afterStatus)
    }

    @Test
    fun testCycleMetricsCalculation() {
        val cycle1 = ChitCycle(cycleNumber = 1, status = ChitCycleStatus.COMPLETED)
        val cycle2 = ChitCycle(cycleNumber = 2, status = ChitCycleStatus.AUCTION_SCHEDULED)
        val cycle3 = ChitCycle(cycleNumber = 3, status = ChitCycleStatus.UPCOMING)

        val metrics = ChitCalculationEngine.deriveCycleMetrics(
            cycles = listOf(cycle1, cycle2, cycle3),
            configuredTotalCycles = 3
        )

        assertEquals(3, metrics.totalCycles)
        assertEquals(1, metrics.completedCycles)
        assertEquals(2, metrics.remainingCycles)
        assertEquals(2, metrics.currentCycleNumber)
        assertEquals(33, metrics.progressPercent)
        assertTrue(metrics.hasStartedOrCompletedCycles)
    }

    @Test
    fun testCountdownFormatting() {
        assertEquals("02:30", ChitCalculationEngine.formatCountdown(150))
        assertEquals("01h 15m 30s", ChitCalculationEngine.formatCountdown(4530))
        assertEquals("2d 03h 20m", ChitCalculationEngine.formatCountdown(184800))
    }

    // =========================================================================
    // PHASE B.3 — BID ENGINE UNIT TESTS
    // =========================================================================

    @Test
    fun testDiscountBoundsCalculation() {
        val totalPot = 100000.0 // 20 members * ₹5,000
        val (minDiscount, maxDiscount) = ChitCalculationEngine.calculateDiscountBounds(
            totalPot = totalPot,
            minDiscountPercent = 5.0,
            maxDiscountPercent = 30.0
        )

        assertEquals(5000.0, minDiscount, 0.01)
        assertEquals(30000.0, maxDiscount, 0.01)
    }

    @Test
    fun testMemberEligibilityEvaluation() {
        val completedCycle1 = ChitCycle(
            cycleNumber = 1,
            status = ChitCycleStatus.COMPLETED,
            winnerMemberId = 2L,
            winnerMemberName = "Priya Chakraborty"
        )
        val activeCycle2 = ChitCycle(
            cycleNumber = 2,
            status = ChitCycleStatus.AUCTION_OPEN
        )

        val dummyPayments = listOf(
            com.adr.groupledger.data.model.Payment(
                memberId = 3L,
                month = 1,
                year = 2026,
                expectedAmount = 500.0,
                paidAmount = 0.0,
                dueAmount = 500.0,
                status = "UNPAID"
            ),
            com.adr.groupledger.data.model.Payment(
                memberId = 1L,
                month = 1,
                year = 2026,
                expectedAmount = 500.0,
                paidAmount = 500.0,
                dueAmount = 0.0,
                status = "PAID"
            )
        )

        // Case 1: Member 2 is a prized subscriber (already won Round 1) -> INELIGIBLE
        val priyaEligibility = ChitCalculationEngine.evaluateMemberEligibility(
            memberId = 2L,
            memberName = "Priya Chakraborty",
            allCycles = listOf(completedCycle1, activeCycle2),
            currentCycleNumber = 2,
            memberPayments = dummyPayments,
            monthlyInstallment = 5000.0
        )
        assertFalse(priyaEligibility.isEligible)
        assertTrue(priyaEligibility.hasWonPriorRound)
        assertEquals(1, priyaEligibility.priorWonRoundNumber)

        // Case 2: Member 3 has overdue dues -> INELIGIBLE
        val member3Eligibility = ChitCalculationEngine.evaluateMemberEligibility(
            memberId = 3L,
            memberName = "Sourav Ganguly",
            allCycles = listOf(completedCycle1, activeCycle2),
            currentCycleNumber = 2,
            memberPayments = dummyPayments,
            monthlyInstallment = 5000.0
        )
        assertFalse(member3Eligibility.isEligible)
        assertTrue(member3Eligibility.hasPendingDues)
        assertEquals(500.0, member3Eligibility.pendingDuesAmount, 0.01)

        // Case 3: Member 1 has clean history and no prior win -> ELIGIBLE
        val member1Eligibility = ChitCalculationEngine.evaluateMemberEligibility(
            memberId = 1L,
            memberName = "Amitabh Banerjee",
            allCycles = listOf(completedCycle1, activeCycle2),
            currentCycleNumber = 2,
            memberPayments = dummyPayments,
            monthlyInstallment = 5000.0
        )
        assertTrue(member1Eligibility.isEligible)
        assertFalse(member1Eligibility.hasWonPriorRound)
        assertFalse(member1Eligibility.hasPendingDues)
    }

    @Test
    fun testBidValidationRules() {
        val totalPot = 100000.0
        val now = 1760000000000L
        val startEpoch = now - 5 * 60 * 1000L
        val endEpoch = now + 10 * 60 * 1000L

        val cleanEligibility = com.adr.groupledger.data.model.ChitMemberEligibility(
            memberId = 1L,
            memberName = "Amitabh",
            isEligible = true,
            reason = "Eligible"
        )
        val ineligibleUser = com.adr.groupledger.data.model.ChitMemberEligibility(
            memberId = 2L,
            memberName = "Priya",
            isEligible = false,
            reason = "Prized Subscriber"
        )

        // 1. Valid bid inside bounds during AUCTION_OPEN
        val validResult = ChitCalculationEngine.validateBidSubmission(
            bidAmount = 15000.0,
            totalPot = totalPot,
            eligibility = cleanEligibility,
            cycleStatus = ChitCycleStatus.AUCTION_OPEN,
            nowMillis = now,
            startEpoch = startEpoch,
            endEpoch = endEpoch
        )
        assertTrue(validResult.isValid)
        assertEquals(com.adr.groupledger.data.model.ChitBidStatus.VALID, validResult.status)

        // 2. Bid below floor (e.g. ₹3,000 < ₹5,000) -> INVALID
        val underFloorResult = ChitCalculationEngine.validateBidSubmission(
            bidAmount = 3000.0,
            totalPot = totalPot,
            eligibility = cleanEligibility,
            cycleStatus = ChitCycleStatus.AUCTION_OPEN,
            nowMillis = now,
            startEpoch = startEpoch,
            endEpoch = endEpoch
        )
        assertFalse(underFloorResult.isValid)
        assertEquals(com.adr.groupledger.data.model.ChitBidStatus.INVALID, underFloorResult.status)

        // 3. Bid exceeding max cap (e.g. ₹35,000 > ₹30,000) -> INVALID
        val overCapResult = ChitCalculationEngine.validateBidSubmission(
            bidAmount = 35000.0,
            totalPot = totalPot,
            eligibility = cleanEligibility,
            cycleStatus = ChitCycleStatus.AUCTION_OPEN,
            nowMillis = now,
            startEpoch = startEpoch,
            endEpoch = endEpoch
        )
        assertFalse(overCapResult.isValid)
        assertEquals(com.adr.groupledger.data.model.ChitBidStatus.INVALID, overCapResult.status)

        // 4. Ineligible member -> REJECTED
        val ineligibleResult = ChitCalculationEngine.validateBidSubmission(
            bidAmount = 15000.0,
            totalPot = totalPot,
            eligibility = ineligibleUser,
            cycleStatus = ChitCycleStatus.AUCTION_OPEN,
            nowMillis = now,
            startEpoch = startEpoch,
            endEpoch = endEpoch
        )
        assertFalse(ineligibleResult.isValid)
        assertEquals(com.adr.groupledger.data.model.ChitBidStatus.REJECTED, ineligibleResult.status)

        // 5. Bid after auction end -> REJECTED
        val expiredResult = ChitCalculationEngine.validateBidSubmission(
            bidAmount = 15000.0,
            totalPot = totalPot,
            eligibility = cleanEligibility,
            cycleStatus = ChitCycleStatus.AUCTION_OPEN,
            nowMillis = endEpoch + 1000L,
            startEpoch = startEpoch,
            endEpoch = endEpoch
        )
        assertFalse(expiredResult.isValid)
        assertEquals(com.adr.groupledger.data.model.ChitBidStatus.REJECTED, expiredResult.status)
    }

    @Test
    fun testResolveHighestBidAndTiebreaker() {
        val bid1 = com.adr.groupledger.data.model.ChitBid(
            bidId = "1",
            memberId = 1L,
            memberName = "Amitabh",
            bidAmount = 15000.0,
            submittedAtMillis = 1000L
        )
        val bid2 = com.adr.groupledger.data.model.ChitBid(
            bidId = "2",
            memberId = 4L,
            memberName = "Ananya",
            bidAmount = 22000.0,
            submittedAtMillis = 2000L
        )
        val bid3 = com.adr.groupledger.data.model.ChitBid(
            bidId = "3",
            memberId = 5L,
            memberName = "Debasish",
            bidAmount = 22000.0, // Same amount as Ananya, but later timestamp
            submittedAtMillis = 2500L
        )

        val highest = ChitCalculationEngine.resolveHighestBid(listOf(bid1, bid2, bid3))
        assertNotNull(highest)
        assertEquals("2", highest?.bidId) // Ananya submitted ₹22,000 first
        assertEquals(22000.0, highest?.bidAmount ?: 0.0, 0.01)
    }

    @Test
    fun testCalculateEstimatedPrizeAndDividend() {
        val totalPot = 100000.0
        val winningDiscount = 20000.0
        val totalMembers = 20
        val baseInstallment = 5000.0

        val outcome = ChitCalculationEngine.calculateEstimatedPrizeAndDividend(
            totalPot = totalPot,
            highestDiscountBid = winningDiscount,
            totalMembers = totalMembers,
            foremanCommissionPercent = 5.0,
            monthlyInstallment = baseInstallment
        )

        // Payout = 100000 - 20000 = 80000
        assertEquals(80000.0, outcome.prizePayoutAmount, 0.01)
        // Commission = 5% of 100000 = 5000
        assertEquals(5000.0, outcome.foremanCommission, 0.01)
        // Surplus = 20000 - 5000 = 15000
        assertEquals(15000.0, outcome.surplusDividendPool, 0.01)
        // Dividend per member = 15000 / 20 = 750
        assertEquals(750.0, outcome.dividendPerMember, 0.01)
        // Net installment next month = 5000 - 750 = 4250
        assertEquals(4250.0, outcome.netNextInstallment, 0.01)
    }

    @Test
    fun testChitCycleSerializationWithBids() {
        val bid = com.adr.groupledger.data.model.ChitBid(
            bidId = "bid-123",
            auctionId = "AUC-G1-C1",
            groupId = 1L,
            cycleNumber = 1,
            memberId = 5L,
            memberName = "Debasish",
            bidAmount = 18000.0,
            status = com.adr.groupledger.data.model.ChitBidStatus.VALID
        )

        val cycle = ChitCycle(
            cycleNumber = 1,
            scheduledDateMillis = 1760000000000L,
            installmentAmount = 5000.0,
            status = ChitCycleStatus.AUCTION_OPEN,
            bids = listOf(bid)
        )

        val json = cycle.toJson()
        val reconstructed = ChitCycle.fromJson(json)

        assertEquals(cycle.cycleNumber, reconstructed.cycleNumber)
        assertEquals(1, reconstructed.bids.size)
        assertEquals("bid-123", reconstructed.bids[0].bidId)
        assertEquals(18000.0, reconstructed.bids[0].bidAmount, 0.01)
        assertEquals("Debasish", reconstructed.bids[0].memberName)
    }

    @Test
    fun testPrepareAuctionResultDeterministicAndTieResolution() {
        val bid1 = com.adr.groupledger.data.model.ChitBid(
            bidId = "bid-1",
            memberId = 10L,
            memberName = "Member A",
            bidAmount = 25000.0,
            submittedAtMillis = 1000L
        )
        val bid2 = com.adr.groupledger.data.model.ChitBid(
            bidId = "bid-2",
            memberId = 20L,
            memberName = "Member B",
            bidAmount = 25000.0, // Same highest discount, later timestamp
            submittedAtMillis = 2000L
        )
        val bid3 = com.adr.groupledger.data.model.ChitBid(
            bidId = "bid-3",
            memberId = 30L,
            memberName = "Member C",
            bidAmount = 15000.0,
            submittedAtMillis = 500L
        )

        val cycle = ChitCycle(
            cycleNumber = 1,
            installmentAmount = 5000.0,
            status = ChitCycleStatus.AUCTION_CLOSED,
            bids = listOf(bid1, bid2, bid3)
        )

        val prepared = ChitCalculationEngine.prepareAuctionResult(
            cycle = cycle,
            totalMembers = 20,
            foremanCommissionPercent = 5.0
        )

        assertTrue(prepared.isTie)
        assertEquals(2, prepared.tiedMemberNames.size)
        assertTrue(prepared.tiedMemberNames.contains("Member A"))
        assertTrue(prepared.tiedMemberNames.contains("Member B"))
        // Candidate winner resolved deterministically by earliest timestamp
        assertEquals(10L, prepared.candidateWinnerMemberId)
        assertEquals("Member A", prepared.candidateWinnerMemberName)
        assertEquals(25000.0, prepared.highestBidAmount ?: 0.0, 0.01)
        assertEquals("RESULT_PENDING", prepared.status)
        assertNotNull(prepared.estimatedOutcome)
        // Payout = 100,000 - 25,000 = 75,000
        assertEquals(75000.0, prepared.estimatedOutcome?.prizePayoutAmount ?: 0.0, 0.01)
    }

    @Test
    fun testAuctionCallStagesBiddingAllowed() {
        assertTrue(ChitAuctionCallStage.OPEN.isBiddingAllowed)
        assertTrue(ChitAuctionCallStage.FIRST_CALL.isBiddingAllowed)
        assertTrue(ChitAuctionCallStage.SECOND_CALL.isBiddingAllowed)
        assertTrue(ChitAuctionCallStage.FINAL_CALL.isBiddingAllowed)
        assertFalse(ChitAuctionCallStage.CLOSED.isBiddingAllowed)
    }

    @Test
    fun testValidateBidSubmissionRules() {
        val rules = ChitAuctionRules(
            openingBid = 2000.0,
            minBidIncrement = 500.0,
            currentCallStage = ChitAuctionCallStage.OPEN
        )

        // 1. Below opening bid -> Invalid
        val belowOpening = ChitCalculationEngine.validateBidSubmission(
            bidAmount = 1500.0,
            currentHighestBid = 0.0,
            rules = rules
        )
        assertFalse(belowOpening.isValid)

        // 2. Exactly equal or above opening bid when no prior bid -> Valid
        val validOpening = ChitCalculationEngine.validateBidSubmission(
            bidAmount = 2000.0,
            currentHighestBid = 0.0,
            rules = rules
        )
        assertTrue(validOpening.isValid)
        assertEquals(2500.0, validOpening.requiredMinimumNextBid, 0.01)

        // 3. Bid less than or equal to current highest bid -> Invalid
        val lowerBid = ChitCalculationEngine.validateBidSubmission(
            bidAmount = 3000.0,
            currentHighestBid = 3000.0,
            rules = rules
        )
        assertFalse(lowerBid.isValid)

        // 4. Bid increment below minimum -> Invalid
        val insufficientIncrement = ChitCalculationEngine.validateBidSubmission(
            bidAmount = 3200.0,
            currentHighestBid = 3000.0,
            rules = rules
        )
        assertFalse(insufficientIncrement.isValid)

        // 5. Bid increment >= minimum -> Valid
        val validIncrement = ChitCalculationEngine.validateBidSubmission(
            bidAmount = 3500.0,
            currentHighestBid = 3000.0,
            rules = rules
        )
        assertTrue(validIncrement.isValid)
        assertEquals(4000.0, validIncrement.requiredMinimumNextBid, 0.01)

        // 6. Closed stage -> Invalid
        val closedRules = rules.copy(currentCallStage = ChitAuctionCallStage.CLOSED)
        val closedBid = ChitCalculationEngine.validateBidSubmission(
            bidAmount = 5000.0,
            currentHighestBid = 3000.0,
            rules = closedRules
        )
        assertFalse(closedBid.isValid)
    }

    @Test
    fun testOrderBidsAuthoritatively() {
        val b1 = com.adr.groupledger.data.model.ChitBid(
            bidId = "bid-c",
            memberId = 1L,
            bidAmount = 5000.0,
            submittedAtMillis = 2000L
        )
        val b2 = com.adr.groupledger.data.model.ChitBid(
            bidId = "bid-a",
            memberId = 2L,
            bidAmount = 7000.0,
            submittedAtMillis = 3000L
        )
        val b3 = com.adr.groupledger.data.model.ChitBid(
            bidId = "bid-b",
            memberId = 3L,
            bidAmount = 7000.0,
            submittedAtMillis = 1000L // earlier timestamp
        )

        val ordered = ChitCalculationEngine.orderBidsAuthoritatively(listOf(b1, b2, b3))
        assertEquals("bid-b", ordered[0].bidId) // Highest amount (7000) & earliest timestamp (1000)
        assertEquals("bid-a", ordered[1].bidId) // Highest amount (7000) & later timestamp (3000)
        assertEquals("bid-c", ordered[2].bidId) // Lower amount (5000)
    }

    @Test
    fun testCalculateAuctionWinnerAndSettlementAllOptions() {
        // Total Chit Value = 50,000 (10 members * ₹5,000)
        // Winning bid discount = 7,000
        val totalChitValue = 50000.0
        val winningDiscount = 7000.0
        val totalMembers = 10
        val monthlyInstallment = 5000.0

        // Option A: Divide equally among all members
        val ruleOptionA = ChitAuctionRules(
            discountDistributionRule = DiscountDistributionRule.DIVIDE_EQUALLY_ALL_MEMBERS
        )
        val settlementA = ChitCalculationEngine.calculateAuctionWinnerAndSettlement(
            totalChitValue = totalChitValue,
            winningBidDiscount = winningDiscount,
            totalMembers = totalMembers,
            monthlyContribution = monthlyInstallment,
            rules = ruleOptionA
        )
        assertEquals(43000.0, settlementA.winnerPrizeAmount, 0.01)
        assertEquals(7000.0, settlementA.discountAmount, 0.01)
        assertEquals(0.0, settlementA.foremanCommission, 0.01)
        assertEquals(7000.0, settlementA.totalDividendPool, 0.01)
        assertEquals(700.0, settlementA.dividendPerMember, 0.01)
        assertEquals(4300.0, settlementA.netNextInstallment, 0.01)

        // Option B: Foreman commission (5%) + surplus dividend
        val ruleOptionB = ChitAuctionRules(
            discountDistributionRule = DiscountDistributionRule.FOREMAN_COMMISSION_AND_DIVIDEND,
            foremanCommissionPercent = 5.0 // 5% of 50,000 = 2,500
        )
        val settlementB = ChitCalculationEngine.calculateAuctionWinnerAndSettlement(
            totalChitValue = totalChitValue,
            winningBidDiscount = winningDiscount,
            totalMembers = totalMembers,
            monthlyContribution = monthlyInstallment,
            rules = ruleOptionB
        )
        assertEquals(43000.0, settlementB.winnerPrizeAmount, 0.01)
        assertEquals(2500.0, settlementB.foremanCommission, 0.01)
        assertEquals(4500.0, settlementB.totalDividendPool, 0.01) // 7000 - 2500 = 4500
        assertEquals(450.0, settlementB.dividendPerMember, 0.01) // 4500 / 10 = 450
        assertEquals(4550.0, settlementB.netNextInstallment, 0.01) // 5000 - 450 = 4550

        // Option C: Future cycle adjustment (carry forward)
        val ruleOptionC = ChitAuctionRules(
            discountDistributionRule = DiscountDistributionRule.FUTURE_CYCLE_ADJUSTMENT
        )
        val settlementC = ChitCalculationEngine.calculateAuctionWinnerAndSettlement(
            totalChitValue = totalChitValue,
            winningBidDiscount = winningDiscount,
            totalMembers = totalMembers,
            monthlyContribution = monthlyInstallment,
            rules = ruleOptionC
        )
        assertEquals(43000.0, settlementC.winnerPrizeAmount, 0.01)
        assertEquals(0.0, settlementC.dividendPerMember, 0.01)
        assertEquals(5000.0, settlementC.netNextInstallment, 0.01)
    }

    @Test
    fun testChitAuctionRulesJsonSerialization() {
        val rules = ChitAuctionRules(
            openingBid = 1000.0,
            minBidIncrement = 250.0,
            currentCallStage = ChitAuctionCallStage.SECOND_CALL,
            discountDistributionRule = DiscountDistributionRule.FOREMAN_COMMISSION_AND_DIVIDEND,
            auctionDurationMinutes = 45,
            firstCallSeconds = 90,
            secondCallSeconds = 45,
            finalCallSeconds = 20,
            foremanCommissionPercent = 4.0
        )

        val json = rules.toJson()
        val restored = ChitAuctionRules.fromJson(json)

        assertEquals(rules.openingBid, restored.openingBid, 0.01)
        assertEquals(rules.minBidIncrement, restored.minBidIncrement, 0.01)
        assertEquals(ChitAuctionCallStage.SECOND_CALL, restored.currentCallStage)
        assertEquals(DiscountDistributionRule.FOREMAN_COMMISSION_AND_DIVIDEND, restored.discountDistributionRule)
        assertEquals(45, restored.auctionDurationMinutes)
        assertEquals(90, restored.firstCallSeconds)
        assertEquals(45, restored.secondCallSeconds)
        assertEquals(20, restored.finalCallSeconds)
        assertEquals(4.0, restored.foremanCommissionPercent, 0.01)
    }
}

