package com.adr.groupledger

import com.adr.groupledger.data.model.ChitFundConfig
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.ui.components.calculateGroupSetupProgress
import com.adr.groupledger.ui.home.HomeTemplateResolver
import com.adr.groupledger.ui.home.template.HomeTemplateRegistry
import com.adr.groupledger.ui.screens.demo.GroupCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Phase A.3: Comprehensive validation tests for Group Settings -> Category -> Sub-Category -> Home Template
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CategoryConfigurationValidationTest {

    @Test
    fun testValidCategoryAndSubCategoryEncoding() {
        val original = GroupSettings(
            id = 1L,
            groupName = "Apex Chit Fund",
            groupType = "Savings, Credit & Chit Fund"
        )

        // Encode valid category and sub-category
        val updated = HomeTemplateResolver.encodeCategoryIntoSettings(
            settings = original,
            category = GroupCategory.SAVINGS_CREDIT_CHIT,
            subCategory = "Chit Fund / BC"
        )

        val (resolvedCat, resolvedSub) = HomeTemplateResolver.resolve(updated)
        assertEquals(GroupCategory.SAVINGS_CREDIT_CHIT, resolvedCat)
        assertEquals("Chit Fund / BC", resolvedSub)

        // Verify Home template resolves to specialized Chit Fund Home
        val template = HomeTemplateRegistry.resolve(resolvedCat, resolvedSub)
        assertEquals("chit_fund_home", template.templateId)
    }

    @Test
    fun testInvalidSubCategoryCrossCategoryValidation() {
        val original = GroupSettings(
            id = 2L,
            groupName = "Greenwood Heights",
            groupType = "Housing Society / Apartment"
        )

        // Attempting to encode "Chit Fund" under HOUSING_APARTMENT must be prevented
        val updated = HomeTemplateResolver.encodeCategoryIntoSettings(
            settings = original,
            category = GroupCategory.HOUSING_APARTMENT,
            subCategory = "Chit Fund" // INVALID for Housing Apartment!
        )

        val (resolvedCat, resolvedSub) = HomeTemplateResolver.resolve(updated)
        assertEquals(GroupCategory.HOUSING_APARTMENT, resolvedCat)
        // Must safely fall back to a valid sub-category of HOUSING_APARTMENT
        assertTrue(GroupCategory.HOUSING_APARTMENT.subCategories.contains(resolvedSub))
        assertNotEquals("Chit Fund", resolvedSub)

        // Housing apartment must never resolve to Chit Fund template
        val template = HomeTemplateRegistry.resolve(resolvedCat, resolvedSub)
        assertEquals("housing_society_home", template.templateId)
    }

    @Test
    fun testCategorySwitchingRemovesChitFundUI() {
        val chitSettings = GroupSettings(
            id = 3L,
            groupName = "Prosperity Group",
            groupType = "Savings, Credit & Chit Fund"
        )
        val withChit = HomeTemplateResolver.encodeCategoryIntoSettings(
            chitSettings,
            GroupCategory.SAVINGS_CREDIT_CHIT,
            "Chit Fund / BC"
        )
        val initialTemplate = HomeTemplateRegistry.resolve(
            HomeTemplateResolver.resolve(withChit).first,
            HomeTemplateResolver.resolve(withChit).second
        )
        assertEquals("chit_fund_home", initialTemplate.templateId)

        // User switches from Chit Fund to Self-Help Group (SHG)
        val switchedToShg = HomeTemplateResolver.encodeCategoryIntoSettings(
            withChit,
            GroupCategory.SAVINGS_CREDIT_CHIT,
            "Self-Help Group (SHG)"
        )
        val (switchedCat, switchedSub) = HomeTemplateResolver.resolve(switchedToShg)
        val newTemplate = HomeTemplateRegistry.resolve(switchedCat, switchedSub)

        // Must no longer show chit_fund_home; must fall back to category template
        assertEquals("savings_credit_home", newTemplate.templateId)
        assertFalse(newTemplate.templateId == "chit_fund_home")
    }

    @Test
    fun testSetupProgressCalculationBasedOnActualData() {
        // Incomplete setup (only name provided, empty subCategory, enabled contribution but empty amount)
        val (initialProgress, initialSections) = calculateGroupSetupProgress(
            groupName = "My Society",
            category = GroupCategory.COMMUNITY_FUND,
            subCategory = "",
            isContributionEnabled = true,
            defaultContribution = "",
            dueDayOfMonth = "",
            adminName = "",
            contactPhone = "",
            contactEmail = "",
            isChitFund = false,
            chitConfig = ChitFundConfig()
        )
        assertEquals(25, initialProgress)
        assertTrue(initialSections.first { it.title.contains("Basic") }.isComplete)
        assertFalse(initialSections.first { it.title.contains("Structure") }.isComplete)
        assertFalse(initialSections.first { it.title.contains("Financial") }.isComplete)
        assertFalse(initialSections.first { it.title.contains("Admin") }.isComplete)

        // Fully completed setup
        val (fullProgress, fullSections) = calculateGroupSetupProgress(
            groupName = "Sunrise Welfare Samiti",
            category = GroupCategory.COMMUNITY_FUND,
            subCategory = "Monthly Community Collection",
            isContributionEnabled = true,
            defaultContribution = "500",
            dueDayOfMonth = "10",
            adminName = "Rahul Sharma",
            contactPhone = "9876543210",
            contactEmail = "admin@sunrise.org",
            isChitFund = false,
            chitConfig = ChitFundConfig()
        )
        assertEquals(100, fullProgress)
        assertTrue(fullSections.all { it.isComplete })
    }

    @Test
    fun testPartialGroupSetupDoesNotCrash() {
        // Incomplete group with blank subcategory and default empty json
        val minimalSettings = GroupSettings(
            id = 4L,
            groupName = "Minimal Group",
            modulesConfigJson = ""
        )

        val (cat, sub) = HomeTemplateResolver.resolve(minimalSettings)
        assertNotNull(cat)
        assertNotNull(sub)
        assertTrue(sub.isNotBlank())

        val template = HomeTemplateRegistry.resolve(cat, sub)
        assertNotNull(template)
        assertTrue(template.templateId.isNotBlank())
    }
}
