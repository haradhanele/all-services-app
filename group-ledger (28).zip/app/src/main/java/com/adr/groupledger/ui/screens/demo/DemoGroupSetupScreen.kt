package com.adr.groupledger.ui.screens.demo

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Rule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500

/**
 * Modern, standalone DEMO Group Setup & Multi-Category Settings Page.
 * Pure UI/UX demonstration without altering any production databases or logic.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DemoGroupSetupScreen(
    onNavigateBack: () -> Unit = {},
    onFinishDemo: () -> Unit = {},
    onNavigateToDemoHome: (category: GroupCategory, subCategory: String, groupName: String) -> Unit = { _, _, _ -> },
    modifier: Modifier = Modifier
) {
    var state by remember { mutableStateOf(DemoGroupSetupState()) }
    var showSuccessDialog by remember { mutableStateOf(false) }
    var nameError by remember { mutableStateOf<String?>(null) }

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            // Compact Header: Shorter in height, title positioned toward the top with dark background and purple accent
            Surface(
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        IconButton(
                            onClick = {
                                if (state.currentStep.stepNumber > 1) {
                                    val prevStep = SetupStep.entries[state.currentStep.stepNumber - 2]
                                    state = state.copy(currentStep = prevStep)
                                } else {
                                    onNavigateBack()
                                }
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("demo_setup_back_btn")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        Column(verticalArrangement = Arrangement.Center) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Group Setup",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = IndigoPrimary
                                ) {
                                    Text(
                                        text = "DEMO",
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Step ${state.currentStep.stepNumber} of 5 • ${state.currentStep.title}",
                                fontSize = 11.sp,
                                color = IndigoPrimary,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Direct shortcut to Home Preview
                        OutlinedButton(
                            onClick = {
                                onNavigateToDemoHome(state.selectedCategory, state.selectedSubCategory, state.groupName)
                            },
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("demo_top_preview_home_btn"),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                            border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = "Preview Home",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = IndigoPrimary
                            )
                        }

                        if (state.isMinimumRequiredComplete) {
                            TextButton(
                                onClick = { showSuccessDialog = true },
                                modifier = Modifier.testTag("demo_complete_later_top_btn"),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "Done",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = IndigoPrimary
                                )
                            }
                        }
                    }
                }
            }
        },
        bottomBar = {
            DemoSetupBottomBar(
                currentStep = state.currentStep,
                isMinimumRequiredComplete = state.isMinimumRequiredComplete,
                onSaveAndContinue = {
                    if (state.currentStep == SetupStep.BASIC_INFO && state.groupName.trim().isBlank()) {
                        nameError = "Please enter your group name."
                    } else {
                        nameError = null
                        if (state.currentStep.stepNumber < 5) {
                            val nextStep = SetupStep.entries[state.currentStep.stepNumber]
                            state = state.copy(currentStep = nextStep)
                        } else {
                            showSuccessDialog = true
                        }
                    }
                },
                onCompleteLater = {
                    showSuccessDialog = true
                },
                onCreateEarly = {
                    if (state.groupName.trim().isBlank()) {
                        nameError = "Please enter your group name."
                    } else {
                        showSuccessDialog = true
                    }
                }
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Compact Section-Based Progress Card
            SetupProgressHeader(
                progressPercent = state.progressPercentage,
                currentStep = state.currentStep,
                onStepClick = { targetStep ->
                    state = state.copy(currentStep = targetStep)
                }
            )

            // Step Content Animated Container
            AnimatedContent(
                targetState = state.currentStep,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "step_transition"
            ) { currentStep ->
                when (currentStep) {
                    SetupStep.BASIC_INFO -> Step1BasicInformationCohesive(
                        state = state,
                        nameError = nameError,
                        onStateChange = { updated ->
                            state = updated
                            if (updated.groupName.isNotBlank()) nameError = null
                        }
                    )
                    SetupStep.MONEY_COLLECTION -> Step2MoneyCollectionCohesive(
                        state = state,
                        onStateChange = { state = it }
                    )
                    SetupStep.FEATURES_SERVICES -> Step3FeaturesServicesCohesive(
                        state = state,
                        onStateChange = { state = it }
                    )
                    SetupStep.GROUP_RULES -> Step4GroupRulesCohesive(
                        state = state,
                        onStateChange = { state = it }
                    )
                    SetupStep.ADVANCED -> Step5AdvancedSettingsCohesive(
                        state = state,
                        onStateChange = { state = it },
                        onEditStep = { step -> state = state.copy(currentStep = step) },
                        onCompleteAll = { showSuccessDialog = true }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showSuccessDialog) {
        DemoGroupCreatedDialog(
            groupName = state.groupName.ifBlank { "All Services Group" },
            progressPercent = state.progressPercentage,
            inviteCode = state.demoInviteCode,
            onContinueSetup = {
                showSuccessDialog = false
                if (state.currentStep.stepNumber < 5) {
                    val nextStep = SetupStep.entries[state.currentStep.stepNumber]
                    state = state.copy(currentStep = nextStep)
                }
            },
            onGoToGroup = {
                showSuccessDialog = false
                onNavigateToDemoHome(state.selectedCategory, state.selectedSubCategory, state.groupName)
            },
            onDismiss = { showSuccessDialog = false }
        )
    }
}

/**
 * STEP 1: Basic Information as ONE Complete Cohesive Card
 * Order:
 * 1. Group Name *
 * 2. Group Tagline / Subtitle
 * 3. Group Category *
 * 4. Group Sub-category *
 * 5. Optional Additional Information
 */
@Composable
private fun Step1BasicInformationCohesive(
    state: DemoGroupSetupState,
    nameError: String?,
    onStateChange: (DemoGroupSetupState) -> Unit
) {
    DemoSectionCard(
        title = "Basic Information",
        subtitle = "Tell us a little about your group to get started.",
        badgeText = "Step 1 of 5"
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // 1. Group Name (Required)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "GROUP NAME *",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 0.8.sp
                )
                OutlinedTextField(
                    value = state.groupName,
                    onValueChange = { onStateChange(state.copy(groupName = it)) },
                    placeholder = { Text("e.g. All Services Group, Puja Committee...") },
                    isError = nameError != null,
                    supportingText = {
                        if (nameError != null) {
                            Text(text = nameError, color = Rose500, fontSize = 10.5.sp)
                        } else {
                            Text(text = "The primary name displayed to all members", fontSize = 10.5.sp)
                        }
                    },
                    leadingIcon = {
                        Icon(Icons.Default.Groups, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("demo_group_name_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = IndigoPrimary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                    )
                )
            }

            // 2. Group Tagline / Subtitle
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "GROUP TAGLINE / SUBTITLE",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 0.8.sp
                )
                OutlinedTextField(
                    value = state.tagline,
                    onValueChange = { onStateChange(state.copy(tagline = it)) },
                    placeholder = { Text("e.g. Monthly Community Savings & Support") },
                    leadingIcon = {
                        Icon(Icons.Default.Tag, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = IndigoPrimary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                    )
                )
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

            // 3 & 4. Group Category and Sub-category Selector (Direct Cards)
            CategoryAndSubCategorySelector(
                selectedCategory = state.selectedCategory,
                selectedSubCategory = state.selectedSubCategory,
                onCategoryChange = { cat ->
                    val defaultSub = cat.subCategories.firstOrNull() ?: "General"
                    onStateChange(
                        state.copy(
                            selectedCategory = cat,
                            selectedSubCategory = defaultSub,
                            contributionAmount = cat.defaultAmount
                        )
                    )
                },
                onSubCategoryChange = { subCat ->
                    onStateChange(state.copy(selectedSubCategory = subCat))
                }
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

            // 5. Optional Additional Details Accordion / Toggle
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onStateChange(state.copy(showOptionalDetails = !state.showOptionalDetails)) }
                        .padding(vertical = 6.dp, horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = IndigoPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Optional: Description, Location & Contact",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = IndigoPrimary
                        )
                    }
                    Icon(
                        imageVector = if (state.showOptionalDetails) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = IndigoPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                if (state.showOptionalDetails) {
                    Column(
                        modifier = Modifier.padding(top = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = state.description,
                            onValueChange = { onStateChange(state.copy(description = it)) },
                            label = { Text("Description / About") },
                            placeholder = { Text("Describe the purpose of your group...") },
                            leadingIcon = { Icon(Icons.Default.Description, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp)) },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
                        )

                        OutlinedTextField(
                            value = state.location,
                            onValueChange = { onStateChange(state.copy(location = it)) },
                            label = { Text("Location / Address") },
                            placeholder = { Text("e.g. Sector 4, Green Valley") },
                            leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = state.contactPhone,
                                onValueChange = { onStateChange(state.copy(contactPhone = it)) },
                                label = { Text("Phone") },
                                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(16.dp)) },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
                            )
                            OutlinedTextField(
                                value = state.contactEmail,
                                onValueChange = { onStateChange(state.copy(contactEmail = it)) },
                                label = { Text("Email") },
                                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(16.dp)) },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * STEP 2: Category-Aware Money & Collection Questions
 * Displays dynamic, intelligent questions based on selected Category + Sub-category in ONE cohesive card.
 */
@Composable
private fun Step2MoneyCollectionCohesive(
    state: DemoGroupSetupState,
    onStateChange: (DemoGroupSetupState) -> Unit
) {
    DemoSectionCard(
        title = "Money & Collection",
        subtitle = "Tailored financial rules for ${state.selectedCategory.title} (${state.selectedSubCategory})",
        badgeText = "Step 2 of 5"
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // Dynamic routing based on category/subcategory
            when (state.selectedCategory) {
                GroupCategory.PUJA_FESTIVAL -> PujaFestivalFlow(state, onStateChange)
                GroupCategory.SAVINGS_CREDIT_CHIT -> {
                    if (state.selectedSubCategory.contains("Chit", ignoreCase = true) || state.selectedSubCategory.contains("BC", ignoreCase = true)) {
                        ChitFundSpecialFlow(state, onStateChange)
                    } else {
                        SavingsCreditShgFlow(state, onStateChange)
                    }
                }
                GroupCategory.HOUSING_APARTMENT -> HousingApartmentFlow(state, onStateChange)
                else -> CommunityFundFlow(state, onStateChange)
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

            // Historical Data Protection Notice
            HistoricalRuleNotice(
                currentAmountText = "₹${state.contributionAmount}",
                newAmountText = "₹${state.contributionAmount} / ${state.collectionFrequency}",
                startDateText = "Next Billing Cycle"
            )
        }
    }
}

/**
 * Category Flow 1: Community Fund & Monthly Collection
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CommunityFundFlow(
    state: DemoGroupSetupState,
    onStateChange: (DemoGroupSetupState) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Question 1: Does your group collect money from members?
        DemoQuestionRow(
            question = "Does your group collect money from members?",
            bengaliPrompt = "টাকা জমা নেওয়া হবে কি?"
        ) {
            DemoOptionChips(
                options = listOf(true, false),
                selectedOption = state.collectsMoney,
                optionLabel = { if (it) "Yes" else "No" },
                onOptionSelected = { onStateChange(state.copy(collectsMoney = it)) }
            )
        }

        if (state.collectsMoney) {
            // Frequency
            DemoQuestionRow(
                question = "How is the money collected?",
                bengaliPrompt = "কত ঘন ঘন টাকা জমা হবে?"
            ) {
                DemoOptionChips(
                    options = listOf("One-time", "Daily", "Weekly", "Monthly", "Custom"),
                    selectedOption = state.collectionFrequency,
                    optionLabel = { it },
                    onOptionSelected = { onStateChange(state.copy(collectionFrequency = it)) }
                )
            }

            // Contribution Equality
            DemoQuestionRow(
                question = "Is the contribution amount the same for everyone?",
                helperText = "You can set fixed or individual member dues"
            ) {
                DemoOptionChips(
                    options = listOf("Same amount for everyone", "Different amount for different members", "Depends on member / situation"),
                    selectedOption = state.isContributionSame,
                    optionLabel = { it },
                    onOptionSelected = { onStateChange(state.copy(isContributionSame = it)) }
                )
            }

            if (state.isContributionSame.startsWith("Same")) {
                OutlinedTextField(
                    value = state.contributionAmount,
                    onValueChange = { onStateChange(state.copy(contributionAmount = it)) },
                    label = { Text("Monthly Contribution Amount (₹)") },
                    leadingIcon = { Text("₹", fontWeight = FontWeight.Bold, color = IndigoPrimary, modifier = Modifier.padding(start = 12.dp)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
                )
            }

            // Question 2: Fixed time/date for payment?
            DemoQuestionRow(
                question = "Is there a fixed time/date for payment?",
                bengaliPrompt = "নির্দিষ্ট জমা দেওয়ার দিন আছে কি?"
            ) {
                DemoOptionChips(
                    options = listOf(false, true),
                    selectedOption = state.hasFixedPaymentDate,
                    optionLabel = { if (it) "Yes (e.g. Day ${state.paymentDueDateDay}th)" else "No fixed date" },
                    onOptionSelected = { onStateChange(state.copy(hasFixedPaymentDate = it)) }
                )
            }

            if (state.hasFixedPaymentDate) {
                OutlinedTextField(
                    value = state.paymentDueDateDay,
                    onValueChange = { onStateChange(state.copy(paymentDueDateDay = it)) },
                    label = { Text("Monthly Collection Due Day (1 - 31)") },
                    placeholder = { Text("e.g. 10") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
                )
            }

            // Question 3: Fine for late payment?
            DemoQuestionRow(
                question = "Is there a fine for late payment?",
                bengaliPrompt = "সময়মতো না দিলে জরিমানা হবে কি?"
            ) {
                DemoOptionChips(
                    options = listOf(false, true),
                    selectedOption = state.hasLatePaymentFine,
                    optionLabel = { if (it) "Yes" else "No" },
                    onOptionSelected = { onStateChange(state.copy(hasLatePaymentFine = it)) }
                )
            }

            if (state.hasLatePaymentFine) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DemoOptionChips(
                        options = listOf("Fixed amount", "Percentage"),
                        selectedOption = state.lateFineType,
                        optionLabel = { it },
                        onOptionSelected = { onStateChange(state.copy(lateFineType = it)) },
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = if (state.lateFineType == "Fixed amount") state.lateFineAmount else state.lateFinePercentage,
                        onValueChange = {
                            if (state.lateFineType == "Fixed amount") {
                                onStateChange(state.copy(lateFineAmount = it))
                            } else {
                                onStateChange(state.copy(lateFinePercentage = it))
                            }
                        },
                        label = { Text(if (state.lateFineType == "Fixed amount") "Amount (₹)" else "Percent (%)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.width(110.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
                    )
                }
            }

            // Question 4: Does your group make investments?
            DemoQuestionRow(
                question = "Does your group make investments?",
                helperText = "Select standard financial instruments your group utilizes"
            ) {
                DemoOptionChips(
                    options = listOf(false, true),
                    selectedOption = state.makesInvestments,
                    optionLabel = { if (it) "Yes" else "No" },
                    onOptionSelected = { onStateChange(state.copy(makesInvestments = it)) }
                )
            }

            if (state.makesInvestments) {
                val investmentOptions = listOf("Bank FD", "Bank RD", "Mutual Fund", "Stock Market", "ETF", "Government Securities", "Other")
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    investmentOptions.forEach { opt ->
                        val isChecked = state.selectedInvestments.contains(opt)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isChecked) IndigoPrimary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = BorderStroke(1.dp, if (isChecked) IndigoPrimary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    val updated = if (isChecked) state.selectedInvestments - opt else state.selectedInvestments + opt
                                    onStateChange(state.copy(selectedInvestments = updated))
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = null,
                                    colors = CheckboxDefaults.colors(checkedColor = IndigoPrimary),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(opt, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }
                }

                if (state.selectedInvestments.contains("Other")) {
                    OutlinedTextField(
                        value = state.otherInvestmentText,
                        onValueChange = { onStateChange(state.copy(otherInvestmentText = it)) },
                        label = { Text("Other Investment Type") },
                        placeholder = { Text("Specify investment details...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
                    )
                }
            }
        }
    }
}

/**
 * Category Flow 2: Puja / Festival Committee
 */
@Composable
private fun PujaFestivalFlow(
    state: DemoGroupSetupState,
    onStateChange: (DemoGroupSetupState) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Collection Method
        DemoQuestionRow(
            question = "How will money be collected?",
            bengaliPrompt = "চাঁদা বা অনুদান কীভাবে তোলা হবে?"
        ) {
            DemoOptionChips(
                options = listOf("One-time Chanda", "Multiple collections", "Donation", "Sponsorship", "Other"),
                selectedOption = state.pujaCollectionMethod,
                optionLabel = { it },
                onOptionSelected = { onStateChange(state.copy(pujaCollectionMethod = it)) }
            )
        }

        // Contribution Equality
        DemoQuestionRow(
            question = "Is the contribution amount the same for everyone?"
        ) {
            DemoOptionChips(
                options = listOf("Same for everyone", "Different for different members", "Voluntary"),
                selectedOption = state.pujaContributionType,
                optionLabel = { it },
                onOptionSelected = { onStateChange(state.copy(pujaContributionType = it)) }
            )
        }

        if (state.pujaContributionType == "Same for everyone") {
            OutlinedTextField(
                value = state.pujaChandaAmount,
                onValueChange = { onStateChange(state.copy(pujaChandaAmount = it)) },
                label = { Text("Target Chanda per Member (₹)") },
                leadingIcon = { Text("₹", fontWeight = FontWeight.Bold, color = IndigoPrimary, modifier = Modifier.padding(start = 12.dp)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
            )
        }

        // Collection Deadline
        DemoQuestionRow(
            question = "Is there a collection deadline?"
        ) {
            DemoOptionChips(
                options = listOf(false, true),
                selectedOption = state.hasPujaDeadline,
                optionLabel = { if (it) "Yes (${state.pujaDeadlineDate})" else "No deadline" },
                onOptionSelected = { onStateChange(state.copy(hasPujaDeadline = it)) }
            )
        }

        // Late payment fine
        DemoQuestionRow(
            question = "Is there a late payment fine?"
        ) {
            DemoOptionChips(
                options = listOf(false, true),
                selectedOption = state.hasPujaLateFine,
                optionLabel = { if (it) "Yes (₹${state.pujaLateFineAmount})" else "No" },
                onOptionSelected = { onStateChange(state.copy(hasPujaLateFine = it)) }
            )
        }

        // Expense Approval
        DemoQuestionRow(
            question = "Will the group have expenses? Who approves them?",
            bengaliPrompt = "খরচ করার আগে অনুমতি লাগবে কি?"
        ) {
            DemoOptionChips(
                options = listOf("No approval required", "Admin approval", "Treasurer approval", "Multiple approval"),
                selectedOption = state.pujaExpenseApproval,
                optionLabel = { it },
                onOptionSelected = { onStateChange(state.copy(pujaExpenseApproval = it)) }
            )
        }

        // Budget
        DemoQuestionRow(
            question = "Does the group maintain a festival budget?"
        ) {
            DemoOptionChips(
                options = listOf(false, true),
                selectedOption = state.maintainsPujaBudget,
                optionLabel = { if (it) "Yes" else "No" },
                onOptionSelected = { onStateChange(state.copy(maintainsPujaBudget = it)) }
            )
        }

        if (state.maintainsPujaBudget) {
            OutlinedTextField(
                value = state.pujaBudgetAmount,
                onValueChange = { onStateChange(state.copy(pujaBudgetAmount = it)) },
                label = { Text("Festival Estimated Budget (₹)") },
                placeholder = { Text("e.g. 100000") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
            )
        }
    }
}

/**
 * Category Flow 3: Savings, Credit & SHG
 */
@Composable
private fun SavingsCreditShgFlow(
    state: DemoGroupSetupState,
    onStateChange: (DemoGroupSetupState) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        DemoQuestionRow(
            question = "Does every member contribute regularly?",
            bengaliPrompt = "সব সদস্য কি নিয়মিত সঞ্চয় জমা দেন?"
        ) {
            DemoOptionChips(
                options = listOf(true, false),
                selectedOption = state.shgRegularContribution,
                optionLabel = { if (it) "Yes" else "No" },
                onOptionSelected = { onStateChange(state.copy(shgRegularContribution = it)) }
            )
        }

        DemoQuestionRow(
            question = "Collection Frequency & Savings Amount"
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DemoOptionChips(
                    options = listOf("Weekly", "Monthly", "Custom"),
                    selectedOption = state.shgCollectionFrequency,
                    optionLabel = { it },
                    onOptionSelected = { onStateChange(state.copy(shgCollectionFrequency = it)) },
                    modifier = Modifier.weight(1f)
                )

                OutlinedTextField(
                    value = state.shgSavingsAmount,
                    onValueChange = { onStateChange(state.copy(shgSavingsAmount = it)) },
                    label = { Text("₹ / Period") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.width(110.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
                )
            }
        }

        DemoQuestionRow(
            question = "Can members take loans from the group?",
            bengaliPrompt = "গ্রুপ থেকে লোন দেওয়া হয় কি?"
        ) {
            DemoOptionChips(
                options = listOf(true, false),
                selectedOption = state.shgCanTakeLoans,
                optionLabel = { if (it) "Yes" else "No" },
                onOptionSelected = { onStateChange(state.copy(shgCanTakeLoans = it)) }
            )
        }

        if (state.shgCanTakeLoans) {
            DemoQuestionRow(
                question = "Loan Interest & Approval"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DemoOptionChips(
                        options = listOf("No interest", "Fixed amount", "Percentage"),
                        selectedOption = state.shgLoanInterestType,
                        optionLabel = { it },
                        onOptionSelected = { onStateChange(state.copy(shgLoanInterestType = it)) },
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = state.shgLoanInterestRate,
                        onValueChange = { onStateChange(state.copy(shgLoanInterestRate = it)) },
                        label = { Text("Interest") },
                        singleLine = true,
                        modifier = Modifier.width(90.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
                    )
                }
            }
        }
    }
}

/**
 * Category Flow 4: Chit Fund (BC) Special Flow
 */
@Composable
private fun ChitFundSpecialFlow(
    state: DemoGroupSetupState,
    onStateChange: (DemoGroupSetupState) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Chit Fund Parameters Grid
        Card(
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = IndigoPrimary.copy(alpha = 0.06f)),
            border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.25f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Chit Fund Scheme Parameters",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.5.sp,
                    color = IndigoPrimary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = state.chitTotalMembers,
                        onValueChange = { onStateChange(state.copy(chitTotalMembers = it)) },
                        label = { Text("Total Members") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
                    )

                    OutlinedTextField(
                        value = state.chitTotalValue,
                        onValueChange = { onStateChange(state.copy(chitTotalValue = it)) },
                        label = { Text("Chit Value (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = state.chitInstallmentAmount,
                        onValueChange = { onStateChange(state.copy(chitInstallmentAmount = it)) },
                        label = { Text("Monthly Installment (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
                    )

                    OutlinedTextField(
                        value = state.chitDurationMonths,
                        onValueChange = { onStateChange(state.copy(chitDurationMonths = it)) },
                        label = { Text("Duration (Months)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
                    )
                }
            }
        }

        // Bidding / Auction
        DemoQuestionRow(
            question = "Will there be an auction / bidding process?",
            bengaliPrompt = "নিলাম বা বিডিং হবে কি?"
        ) {
            DemoOptionChips(
                options = listOf(true, false),
                selectedOption = state.hasChitAuction,
                optionLabel = { if (it) "Yes" else "No" },
                onOptionSelected = { onStateChange(state.copy(hasChitAuction = it)) }
            )
        }

        if (state.hasChitAuction) {
            DemoQuestionRow(
                question = "Bidding Method & Eligibility",
                helperText = "Members place bids. The group follows the selected rule to decide who receives the chit amount."
            ) {
                DemoOptionChips(
                    options = listOf("Lowest bid", "Highest bid", "Other"),
                    selectedOption = state.chitBiddingMethod,
                    optionLabel = { it },
                    onOptionSelected = { onStateChange(state.copy(chitBiddingMethod = it)) }
                )
            }

            DemoQuestionRow(
                question = "Who can participate in the bid?"
            ) {
                DemoOptionChips(
                    options = listOf("All eligible members", "Only members with no outstanding dues", "Custom rule"),
                    selectedOption = state.chitBiddingEligibility,
                    optionLabel = { it },
                    onOptionSelected = { onStateChange(state.copy(chitBiddingEligibility = it)) }
                )
            }

            DemoQuestionRow(
                question = "How is the bid discount handled?"
            ) {
                DemoOptionChips(
                    options = listOf("Distributed among members", "Discount to the winning member", "Group-defined rule"),
                    selectedOption = state.chitBidAmountHandling,
                    optionLabel = { it },
                    onOptionSelected = { onStateChange(state.copy(chitBidAmountHandling = it)) }
                )
            }
        }

        // Commission & Missed Penalty
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = state.chitCommissionValue,
                onValueChange = { onStateChange(state.copy(chitCommissionValue = it)) },
                label = { Text("Organizer Commission") },
                singleLine = true,
                modifier = Modifier.weight(1f),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
            )

            OutlinedTextField(
                value = state.chitMissedPenaltyValue,
                onValueChange = { onStateChange(state.copy(chitMissedPenaltyValue = it)) },
                label = { Text("Missed Penalty (₹)") },
                singleLine = true,
                modifier = Modifier.weight(1f),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
            )
        }
    }
}

/**
 * Category Flow 5: Housing Society / Apartment
 */
@Composable
private fun HousingApartmentFlow(
    state: DemoGroupSetupState,
    onStateChange: (DemoGroupSetupState) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        DemoQuestionRow(
            question = "Maintenance Collection Frequency & Due Date",
            bengaliPrompt = "ফ্ল্যাট মেইনটেন্যান্স সংগ্রহ"
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DemoOptionChips(
                    options = listOf("Monthly", "Quarterly", "Bi-annually"),
                    selectedOption = state.housingMaintenanceFrequency,
                    optionLabel = { it },
                    onOptionSelected = { onStateChange(state.copy(housingMaintenanceFrequency = it)) },
                    modifier = Modifier.weight(1f)
                )

                OutlinedTextField(
                    value = state.housingMaintenanceAmount,
                    onValueChange = { onStateChange(state.copy(housingMaintenanceAmount = it)) },
                    label = { Text("₹ / Flat") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.width(110.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
                )
            }
        }

        DemoQuestionRow(
            question = "Late Payment Surcharge & Repair Fund"
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DemoOptionChips(
                    options = listOf(true, false),
                    selectedOption = state.hasHousingLateFee,
                    optionLabel = { if (it) "Late Fee (₹${state.housingLateFeeAmount})" else "No Late Fee" },
                    onOptionSelected = { onStateChange(state.copy(hasHousingLateFee = it)) },
                    modifier = Modifier.weight(1f)
                )

                DemoOptionChips(
                    options = listOf(true, false),
                    selectedOption = state.hasRepairDevelopmentFund,
                    optionLabel = { if (it) "Repair Fund Active" else "No Sinking Fund" },
                    onOptionSelected = { onStateChange(state.copy(hasRepairDevelopmentFund = it)) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

/**
 * STEP 3: Group Features in ONE Cohesive Card
 * Includes "Recommended for your group" banner + toggles.
 */
@Composable
private fun Step3FeaturesServicesCohesive(
    state: DemoGroupSetupState,
    onStateChange: (DemoGroupSetupState) -> Unit
) {
    DemoSectionCard(
        title = "Group Features",
        subtitle = "Enable features and services tailored to ${state.selectedCategory.title}",
        badgeText = "Step 3 of 5"
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // "Recommended for your group" highlight box
            RecommendedFeaturesBanner(category = state.selectedCategory)

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

            // Core features (Always Included)
            Text(
                text = "CORE MODULES (INCLUDED)",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 0.8.sp
            )

            FeatureToggleItem(
                title = "Member Directory & Dues Tracking",
                description = "Track active members, flat/membership numbers, phone & balances.",
                isEnabled = true,
                isCore = true,
                onToggle = {}
            )

            FeatureToggleItem(
                title = "Collections & Expense Ledgers",
                description = "Record collections with digital receipts and categorized expense tracking.",
                isEnabled = true,
                isCore = true,
                onToggle = {}
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

            // Optional Activities & Modules
            Text(
                text = "COMMUNICATION & ACTIVITIES",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 0.8.sp
            )

            val features = listOf(
                Triple("notice", "Notice Board & Announcements", "Post digital circulars, meeting notices & PDFs to members."),
                Triple("meetings", "Meetings & Attendance", "Log general body meeting minutes, agenda & member presence."),
                Triple("savings", "Member Savings Scheme", "Maintain individual member savings ledgers with passbooks."),
                Triple("loans", "Internal Member Loans", "Offer loans to members with interest calculation and EMI tracking."),
                Triple("voting", "Polls & Decision Voting", "Hold transparent democratic votes on budgets and resolutions.")
            )

            features.forEach { (id, title, desc) ->
                val isEnabled = state.enabledFeatures.contains(id)
                val isRecommended = state.selectedCategory.recommendedFeatures.any { it.contains(title.split(" ").first(), ignoreCase = true) }
                FeatureToggleItem(
                    title = title,
                    description = desc,
                    isEnabled = isEnabled,
                    isRecommended = isRecommended,
                    onToggle = { checked ->
                        val updated = if (checked) state.enabledFeatures + id else state.enabledFeatures - id
                        onStateChange(state.copy(enabledFeatures = updated))
                    }
                )
            }
        }
    }
}

/**
 * STEP 4: Group Rules in ONE Cohesive Card with plain, non-technical conversational language
 */
@Composable
private fun Step4GroupRulesCohesive(
    state: DemoGroupSetupState,
    onStateChange: (DemoGroupSetupState) -> Unit
) {
    DemoSectionCard(
        title = "Group Rules & Permissions",
        subtitle = "Clear, category-aware governance rules for smooth administration",
        badgeText = "Step 4 of 5"
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // Rule 1: Expense Approval
            DemoQuestionRow(
                question = "Is approval required before making an expense?",
                bengaliPrompt = "খরচ করার আগে অনুমতি লাগবে কি?"
            ) {
                DemoOptionChips(
                    options = listOf(true, false),
                    selectedOption = state.expenseApprovalRequired,
                    optionLabel = { if (it) "Yes (Above ₹${state.expenseApprovalThreshold})" else "No approval required" },
                    onOptionSelected = { onStateChange(state.copy(expenseApprovalRequired = it)) }
                )
            }

            if (state.expenseApprovalRequired) {
                DemoQuestionRow(
                    question = "Who can approve expenses?"
                ) {
                    DemoOptionChips(
                        options = listOf("Admin Only", "Admin & Treasurer", "Full Committee (3+ Approvals)"),
                        selectedOption = state.whoCanApproveExpense,
                        optionLabel = { it },
                        onOptionSelected = { onStateChange(state.copy(whoCanApproveExpense = it)) }
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

            // Rule 2: Transaction Permissions
            DemoQuestionRow(
                question = "Who can add or record collections?",
                bengaliPrompt = "কে হিসাব যোগ করতে পারবেন?"
            ) {
                DemoOptionChips(
                    options = listOf("All Admins & Collectors", "Admin Only", "Designated Cashier"),
                    selectedOption = state.whoCanAddCollection,
                    optionLabel = { it },
                    onOptionSelected = { onStateChange(state.copy(whoCanAddCollection = it)) }
                )
            }

            DemoQuestionRow(
                question = "Who can edit or modify past transactions?",
                bengaliPrompt = "কে হিসাব পরিবর্তন করতে পারবেন?"
            ) {
                DemoOptionChips(
                    options = listOf("Admin Only", "Admin with Treasurer Approval", "Locked (No Edits Allowed)"),
                    selectedOption = state.whoCanEditTransactions,
                    optionLabel = { it },
                    onOptionSelected = { onStateChange(state.copy(whoCanEditTransactions = it)) }
                )
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

            // Rule 3: Member Approval & Report Visibility
            DemoQuestionRow(
                question = "Require admin approval for new member join requests?"
            ) {
                DemoOptionChips(
                    options = listOf(true, false),
                    selectedOption = state.memberApprovalRequired,
                    optionLabel = { if (it) "Yes (Admin verifies each member)" else "No (Instant join with invite code)" },
                    onOptionSelected = { onStateChange(state.copy(memberApprovalRequired = it)) }
                )
            }

            DemoQuestionRow(
                question = "Who can view the monthly audit statements and balances?"
            ) {
                DemoOptionChips(
                    options = listOf("All Members", "Admins & Committee Only", "Public"),
                    selectedOption = state.reportVisibility,
                    optionLabel = { it },
                    onOptionSelected = { onStateChange(state.copy(reportVisibility = it)) }
                )
            }
        }
    }
}

/**
 * STEP 5: Advanced Settings & Review in ONE Cohesive Card
 */
@Composable
private fun Step5AdvancedSettingsCohesive(
    state: DemoGroupSetupState,
    onStateChange: (DemoGroupSetupState) -> Unit,
    onEditStep: (SetupStep) -> Unit,
    onCompleteAll: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Review Summary Card
        DemoReviewSummaryCard(
            state = state,
            onEditStep = onEditStep
        )

        // Collapsed Advanced Settings
        DemoSectionCard(
            title = "Advanced Settings",
            subtitle = "Optional system configurations (These settings can be changed later)",
            badgeText = "Step 5 of 5"
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                AdvancedSectionAccordion(
                    title = "Automated Reminders & Notifications",
                    subtitle = "WhatsApp & SMS notifications for upcoming dues",
                    icon = Icons.Default.Notifications
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Auto WhatsApp Dues Reminder", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                        Switch(
                            checked = state.autoSendWhatsAppReminders,
                            onCheckedChange = { onStateChange(state.copy(autoSendWhatsAppReminders = it)) },
                            colors = SwitchDefaults.colors(checkedTrackColor = IndigoPrimary),
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("SMS Alerts for Receipts & Notices", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                        Switch(
                            checked = state.autoSendSmsReminders,
                            onCheckedChange = { onStateChange(state.copy(autoSendSmsReminders = it)) },
                            colors = SwitchDefaults.colors(checkedTrackColor = IndigoPrimary),
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                AdvancedSectionAccordion(
                    title = "Accounting & Fiscal Year",
                    subtitle = "Currency format, start month & audit logs",
                    icon = Icons.Default.Tune
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = state.fiscalYearStart,
                            onValueChange = { onStateChange(state.copy(fiscalYearStart = it)) },
                            label = { Text("Fiscal Year Starts") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
                        )
                        OutlinedTextField(
                            value = state.currencySymbol,
                            onValueChange = { onStateChange(state.copy(currencySymbol = it)) },
                            label = { Text("Currency") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IndigoPrimary, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant)
                        )
                    }
                }

                AdvancedSectionAccordion(
                    title = "Privacy & Audit Logs",
                    subtitle = "Member statement visibility & change history",
                    icon = Icons.Default.Security
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Enable Tamper-Proof Audit Log", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                        Switch(
                            checked = state.enableAuditLog,
                            onCheckedChange = { onStateChange(state.copy(enableAuditLog = it)) },
                            colors = SwitchDefaults.colors(checkedTrackColor = IndigoPrimary),
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                Text(
                    text = "You can change any of these settings later anytime from the Group Settings tab.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 14.sp
                )
            }
        }
    }
}

/**
 * Bottom action bar with Save & Continue and Complete Later buttons.
 */
@Composable
private fun DemoSetupBottomBar(
    currentStep: SetupStep,
    isMinimumRequiredComplete: Boolean,
    onSaveAndContinue: () -> Unit,
    onCompleteLater: () -> Unit,
    onCreateEarly: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Secondary action: Complete Later
            OutlinedButton(
                onClick = onCompleteLater,
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
                    .testTag("demo_complete_later_bottom_btn"),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Text(
                    text = "Complete Later",
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            // Primary action: Save & Continue / Complete Setup
            Button(
                onClick = onSaveAndContinue,
                modifier = Modifier
                    .weight(1.3f)
                    .height(42.dp)
                    .testTag("demo_save_and_continue_btn"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (currentStep == SetupStep.ADVANCED) "Complete Setup 🎉" else "Save & Continue",
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    if (currentStep != SetupStep.ADVANCED) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }
        }
    }
}
