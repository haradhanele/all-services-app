package com.adr.groupledger.ui.screens.demo

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Diversity1
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.FamilyRestroom
import androidx.compose.material.icons.filled.Festival
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * 10 Core Group Categories with exact user-defined sub-categories and recommended features.
 */
enum class GroupCategory(
    val id: String,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val subCategories: List<String>,
    val recommendedFeatures: List<String>,
    val defaultContributionType: String,
    val defaultAmount: String
) {
    COMMUNITY_FUND(
        id = "community_fund",
        title = "Community Fund",
        description = "Regular contributions for community initiatives, local development & member support",
        icon = Icons.Default.Groups,
        subCategories = listOf(
            "Monthly Community Collection",
            "Member Support Fund",
            "Emergency Fund",
            "Mutual Assistance Fund",
            "Community Development Fund",
            "Savings Pool",
            "Other"
        ),
        recommendedFeatures = listOf(
            "Monthly Collection",
            "Member Support / Assistance",
            "Late Payment Fees",
            "Meeting Minutes & Notices",
            "Financial Reports & PDF"
        ),
        defaultContributionType = "Monthly Collection",
        defaultAmount = "500"
    ),
    PUJA_FESTIVAL(
        id = "puja_festival",
        title = "Puja / Festival Committee",
        description = "Chanda, sponsorships, pandal budgets, festival events & public programs",
        icon = Icons.Default.Festival,
        subCategories = listOf(
            "Festival Event Fund",
            "Religious Event Fund",
            "Temple / Religious Institution Fund",
            "Community Celebration Fund",
            "Donation-Based Religious Fund",
            "Event-Specific Collection",
            "Other"
        ),
        recommendedFeatures = listOf(
            "Chanda / Subscription Collection",
            "Festival Budget Tracker",
            "Expense & Voucher Approvals",
            "Notice Board & Announcements",
            "Donor List & Public Reports"
        ),
        defaultContributionType = "One-time Chanda",
        defaultAmount = "1000"
    ),
    SPORTS_CULTURAL(
        id = "sports_cultural",
        title = "Sports & Cultural Club",
        description = "Sports tournaments, cultural programs, club activities & sports equipment",
        icon = Icons.Default.SportsSoccer,
        subCategories = listOf(
            "Sports Club",
            "Cultural Club",
            "Youth & Recreation Club",
            "Sports & Event Fund",
            "Club Membership Fund",
            "Other"
        ),
        recommendedFeatures = listOf(
            "Membership Fee Collection",
            "Tournament / Event Budgets",
            "Equipment & Ground Expenses",
            "Attendance Tracking",
            "Club Notice Board"
        ),
        defaultContributionType = "Membership Fee",
        defaultAmount = "300"
    ),
    SAVINGS_CREDIT_CHIT(
        id = "savings_credit_chit",
        title = "Savings, Credit & Chit Fund",
        description = "Self-Help Groups (SHG), savings schemes, internal member loans & chit funds (BC)",
        icon = Icons.Default.Savings,
        subCategories = listOf(
            "Self-Help Group (SHG)",
            "Savings Group",
            "Savings & Credit Group",
            "Member Loan Group",
            "Chit Fund / BC",
            "Rotating Savings Group",
            "Other"
        ),
        recommendedFeatures = listOf(
            "Mandatory Periodic Savings",
            "Member Loan & Interest Ledger",
            "Chit Fund / BC Auction Engine",
            "Missed Payment Penalty",
            "Passbook & Audit Statements"
        ),
        defaultContributionType = "Monthly Savings",
        defaultAmount = "1000"
    ),
    EVENTS_TRIPS(
        id = "events_trips",
        title = "Events, Trips, Picnic & Mess Pool",
        description = "Shared trip budgets, mess accounts, weddings & group reunions",
        icon = Icons.Default.Event,
        subCategories = listOf(
            "Travel / Tour Pool",
            "Picnic / Outing Pool",
            "Shared Mess Fund",
            "Wedding / Function Pool",
            "Reunion / Gathering Pool",
            "Shared Event Expenses",
            "Other"
        ),
        recommendedFeatures = listOf(
            "Participant Pool Contributions",
            "Shared Expense Splits",
            "Budget vs Actual Tracker",
            "Voting & Decision Polls",
            "Settlement & Refund Ledger"
        ),
        defaultContributionType = "Trip Pool / Budget",
        defaultAmount = "2000"
    ),
    FAMILY_FRIENDS(
        id = "family_friends",
        title = "Family, Friends & Shared Pool",
        description = "Personal family funds, friendly expense splits & joint savings",
        icon = Icons.Default.FamilyRestroom,
        subCategories = listOf(
            "Family Fund",
            "Friends Shared Fund",
            "Shared Expense Pool",
            "Joint Savings Pool",
            "Emergency Family / Friends Fund",
            "Other"
        ),
        recommendedFeatures = listOf(
            "Flexible / Voluntary Contribution",
            "Shared Expense Tracking",
            "Emergency Pool Fund",
            "Member Balance Summary",
            "Easy WhatsApp Updates"
        ),
        defaultContributionType = "Flexible Contribution",
        defaultAmount = "500"
    ),
    WELFARE_NGO(
        id = "welfare_ngo",
        title = "Welfare & NGO",
        description = "Charitable causes, medical aid, disaster relief & public welfare",
        icon = Icons.Default.VolunteerActivism,
        subCategories = listOf(
            "Welfare Society",
            "NGO / Non-Profit Group",
            "Charity Fund",
            "Community Relief Fund",
            "Medical Assistance Fund",
            "Education Assistance Fund",
            "Other"
        ),
        recommendedFeatures = listOf(
            "Donation & Relief Collections",
            "Beneficiary Aid Allocation",
            "Committee Expense Approval",
            "Audit Logs & Transparency",
            "Official Receipt Generation"
        ),
        defaultContributionType = "Voluntary Donation",
        defaultAmount = "500"
    ),
    HOUSING_APARTMENT(
        id = "housing_apartment",
        title = "Housing Society / Apartment",
        description = "Apartment maintenance, security, development fund & resident dues",
        icon = Icons.Default.Apartment,
        subCategories = listOf(
            "Apartment Society",
            "Housing Society",
            "Maintenance Fund",
            "Repair & Development Fund",
            "Common Facility Fund",
            "Resident Welfare Fund",
            "Other"
        ),
        recommendedFeatures = listOf(
            "Monthly Maintenance Collection",
            "Flat / Unit Wise Ledger",
            "Late Payment Surcharge",
            "Vendor & Utility Expenses",
            "Resident Complaints & Notices"
        ),
        defaultContributionType = "Monthly Maintenance",
        defaultAmount = "1500"
    ),
    BUSINESS_PARTNERSHIP(
        id = "business_partnership",
        title = "Business & Partnership",
        description = "Joint ventures, small enterprises, capital investments & profit shares",
        icon = Icons.Default.BusinessCenter,
        subCategories = listOf(
            "Business Partnership",
            "Joint Business",
            "Joint Investment",
            "Profit Sharing Group",
            "Small Enterprise Partnership",
            "Other"
        ),
        recommendedFeatures = listOf(
            "Partner Capital & Equity Share",
            "Revenue & Expense Ledger",
            "Receivables & Payables",
            "Profit / Loss Distribution",
            "Dual-Admin Approvals"
        ),
        defaultContributionType = "Capital / Equity Share",
        defaultAmount = "5000"
    ),
    OTHER_GROUPS(
        id = "other_groups",
        title = "Other Groups",
        description = "Custom committees, clubs, associations & custom ledgers",
        icon = Icons.Default.Diversity1,
        subCategories = listOf(
            "Custom Community Group",
            "Custom Shared Fund",
            "Association",
            "Committee",
            "Other"
        ),
        recommendedFeatures = listOf(
            "Custom Ledger Recording",
            "Flexible Member Dues",
            "Income & Expense Tracking",
            "Multi-User Roles",
            "Standard Export & Reports"
        ),
        defaultContributionType = "General Contribution",
        defaultAmount = "500"
    )
}

enum class SetupStep(val stepNumber: Int, val title: String, val shortName: String) {
    BASIC_INFO(1, "Basic Information", "Basic Info"),
    MONEY_COLLECTION(2, "Money & Collection", "Money & Collection"),
    FEATURES_SERVICES(3, "Group Features", "Features"),
    GROUP_RULES(4, "Group Rules", "Rules"),
    ADVANCED(5, "Advanced Settings", "Advanced")
}

data class DemoFeatureItem(
    val id: String,
    val name: String,
    val description: String,
    val category: FeatureCategory,
    val isCore: Boolean = false
)

enum class FeatureCategory(val title: String) {
    CORE("Core Accounting (Always Included)"),
    GROUP("Group Activities & Communication"),
    FINANCIAL("Advanced Financial Modules")
}

/**
 * State holding all user configurations across the 5 setup steps for the interactive demo.
 */
data class DemoGroupSetupState(
    // Step 1: Basic Information
    val groupName: String = "All Services Group",
    val tagline: String = "Monthly Community Savings & Support",
    val selectedCategory: GroupCategory = GroupCategory.COMMUNITY_FUND,
    val selectedSubCategory: String = "Monthly Community Collection",
    val description: String = "A neighborhood community fund for mutual support, celebrations and emergency aid.",
    val location: String = "Sector 4, Green Valley",
    val contactPhone: String = "+91 98765 43210",
    val contactEmail: String = "contact@allservicesgroup.org",
    val showOptionalDetails: Boolean = false,

    // Step 2: Money & Collection (Dynamic category-specific fields)
    // Common / Community Fund Flow
    val collectsMoney: Boolean = true,
    val collectionFrequency: String = "Monthly", // One-time, Daily, Weekly, Monthly, Custom
    val isContributionSame: String = "Same amount for everyone", // Same amount for everyone, Different amount for different members, Depends on member / situation
    val contributionAmount: String = "500",
    val hasFixedPaymentDate: Boolean = true,
    val paymentDueDateDay: String = "10",
    val hasLatePaymentFine: Boolean = true,
    val lateFineType: String = "Fixed amount", // Fixed amount, Percentage
    val lateFineAmount: String = "50",
    val lateFinePercentage: String = "5",
    val makesInvestments: Boolean = false,
    val selectedInvestments: Set<String> = setOf("Bank FD", "Bank RD"),
    val otherInvestmentText: String = "",

    // Puja / Festival Flow
    val pujaCollectionMethod: String = "One-time Chanda", // One-time Chanda, Multiple collections, Donation, Sponsorship, Other
    val pujaContributionType: String = "Same for everyone", // Same for everyone, Different for different members, Voluntary
    val pujaChandaAmount: String = "1000",
    val hasPujaDeadline: Boolean = true,
    val pujaDeadlineDate: String = "15 Oct 2026",
    val hasPujaLateFine: Boolean = false,
    val pujaLateFineAmount: String = "100",
    val hasPujaExpenses: Boolean = true,
    val pujaExpenseApproval: String = "Admin & Treasurer approval", // No approval required, Admin approval, Treasurer approval, Multiple approval
    val maintainsPujaBudget: Boolean = true,
    val pujaBudgetAmount: String = "100000",

    // Savings / SHG Flow
    val shgRegularContribution: Boolean = true,
    val shgCollectionFrequency: String = "Monthly",
    val shgContributionMode: String = "Same for everyone",
    val shgSavingsAmount: String = "1000",
    val shgMaintainsSavings: Boolean = true,
    val shgCanTakeLoans: Boolean = true,
    val shgLoanApprovalRequired: Boolean = true,
    val shgLoanInterestType: String = "Percentage", // No interest, Fixed amount, Percentage
    val shgLoanInterestRate: String = "2.0%",
    val shgLoanRepaymentFrequency: String = "Monthly",
    val shgHasLoanPenalty: Boolean = true,

    // Chit Fund (BC) Special Flow
    val chitTotalMembers: String = "20",
    val chitTotalValue: String = "100000",
    val chitInstallmentAmount: String = "5000",
    val chitDurationMonths: String = "20",
    val chitCollectionFrequency: String = "Monthly",
    val hasChitAuction: Boolean = true,
    val chitBiddingMethod: String = "Lowest bid", // Highest bid, Lowest bid, Other
    val chitBiddingEligibility: String = "All eligible members", // All eligible members, Only members with no outstanding dues, Custom rule
    val chitBidAmountHandling: String = "Distributed among members", // Discount to the winning member, Distributed among members, Group-defined rule
    val hasChitCommission: Boolean = true,
    val chitCommissionType: String = "Percentage",
    val chitCommissionValue: String = "4%",
    val hasChitMissedPenalty: Boolean = true,
    val chitMissedPenaltyType: String = "Fixed amount",
    val chitMissedPenaltyValue: String = "100",

    // Housing Society Flow
    val housingMaintenanceFrequency: String = "Monthly",
    val housingMaintenanceAmount: String = "1500",
    val housingDueDateDay: String = "10",
    val hasHousingLateFee: Boolean = true,
    val housingLateFeeAmount: String = "100",
    val hasRepairDevelopmentFund: Boolean = true,

    // Step 3: Features & Services
    val enabledFeatures: Set<String> = setOf(
        "members", "collection", "expenses", "income", "reports",
        "meetings", "notice", "member_assistance", "savings"
    ),

    // Step 4: Rules & Permissions
    val expenseApprovalRequired: Boolean = true,
    val expenseApprovalThreshold: String = "2000",
    val whoCanApproveExpense: String = "Admin & Treasurer",
    val whoCanAddCollection: String = "All Admins & Collectors",
    val whoCanAddExpense: String = "All Admins",
    val whoCanEditTransactions: String = "Admin Only",
    val memberApprovalRequired: Boolean = true,
    val reportVisibility: String = "All Members",

    // Step 5: Advanced Settings
    val fiscalYearStart: String = "April",
    val currencySymbol: String = "₹ (INR)",
    val enableAuditLog: Boolean = true,
    val autoSendSmsReminders: Boolean = true,
    val autoSendWhatsAppReminders: Boolean = true,
    val allowMemberSelfDownloadStatements: Boolean = true,
    val memberPrivacyMode: String = "Standard (Show dues to group)",

    // Completed Sections tracker (1..5)
    val completedSteps: Set<Int> = setOf(1), // Step 1 is active/completed
    val currentStep: SetupStep = SetupStep.BASIC_INFO,
    val demoInviteCode: String = "JQ5W3"
) {
    /**
     * Exact section-based progress calculation:
     * Basic Information complete = 20%
     * Money & Collection complete = 40%
     * Group Features complete = 60%
     * Group Rules complete = 80%
     * Advanced Settings complete = 100%
     */
    val progressPercentage: Int
        get() {
            return when (currentStep) {
                SetupStep.BASIC_INFO -> if (groupName.isNotBlank()) 20 else 0
                SetupStep.MONEY_COLLECTION -> 40
                SetupStep.FEATURES_SERVICES -> 60
                SetupStep.GROUP_RULES -> 80
                SetupStep.ADVANCED -> 100
            }
        }

    val isMinimumRequiredComplete: Boolean
        get() = groupName.trim().isNotBlank()
}

