package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Member
import com.example.ui.components.MonthPickerBar
import com.example.ui.components.StatusBadge
import com.example.ui.theme.BorderLight
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CardWhite
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.StatusPaidText
import com.example.ui.theme.StatusUnpaidText
import com.example.ui.theme.TextSlate400
import com.example.ui.theme.TextSlate500
import com.example.ui.theme.TextSlate800
import com.example.ui.viewmodel.SocietyViewModel
import com.example.utils.CurrencyFormatter
import com.example.utils.DateUtils
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordPaymentScreen(
    preselectedMemberId: Long,
    viewModel: SocietyViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val allMembers by viewModel.allMembers.collectAsStateWithLifecycle()
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val currentSelMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val currentSelYear by viewModel.selectedYear.collectAsStateWithLifecycle()

    var selectedMember by remember { mutableStateOf<Member?>(null) }
    var memberDropdownExpanded by remember { mutableStateOf(false) }

    var paymentMonth by remember { mutableIntStateOf(currentSelMonth) }
    var paymentYear by remember { mutableIntStateOf(currentSelYear) }

    var expectedAmount by remember { mutableDoubleStateOf(settings.defaultContribution) }
    var paidAmountText by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("Cash") }
    var transactionRef by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var paymentDate by remember { mutableLongStateOf(System.currentTimeMillis()) }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Initialize preselected member
    LaunchedEffect(preselectedMemberId, allMembers) {
        if (allMembers.isNotEmpty()) {
            val target = allMembers.find { it.id == preselectedMemberId } ?: allMembers.firstOrNull()
            selectedMember = target
            if (target != null) {
                val exp = if (target.monthlyContribution > 0) target.monthlyContribution else settings.defaultContribution
                expectedAmount = exp
                paidAmountText = exp.toString()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Record Contribution", fontWeight = FontWeight.Bold, color = TextSlate800) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextSlate800)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CardWhite)
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .testTag("record_payment_screen"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Member Selector Dropdown
            ExposedDropdownMenuBox(
                expanded = memberDropdownExpanded,
                onExpandedChange = { memberDropdownExpanded = !memberDropdownExpanded }
            ) {
                OutlinedTextField(
                    value = selectedMember?.name ?: "Select Member",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Select Society Member *") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = IndigoPrimary) },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = memberDropdownExpanded) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                        .testTag("payment_member_selector"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = CardWhite,
                        unfocusedContainerColor = CardWhite,
                        focusedBorderColor = IndigoPrimary,
                        unfocusedBorderColor = BorderSubtle
                    )
                )

                ExposedDropdownMenu(
                    expanded = memberDropdownExpanded,
                    onDismissRequest = { memberDropdownExpanded = false }
                ) {
                    allMembers.forEach { member ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(member.name, fontWeight = FontWeight.Bold, color = TextSlate800)
                                    Text(
                                        "${member.memberCode} • ${if (member.phone.isNotBlank()) member.phone else "No phone"}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSlate500
                                    )
                                }
                            },
                            onClick = {
                                selectedMember = member
                                val exp = if (member.monthlyContribution > 0) member.monthlyContribution else settings.defaultContribution
                                expectedAmount = exp
                                paidAmountText = exp.toString()
                                memberDropdownExpanded = false
                            }
                        )
                    }
                }
            }

            // 2. Month & Year Picker Bar
            Text("BILLING MONTH & YEAR", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = TextSlate400, fontSize = 9.5.sp, letterSpacing = 0.5.sp)
            MonthPickerBar(
                selectedMonth = paymentMonth,
                selectedYear = paymentYear,
                onPrevClick = {
                    if (paymentMonth == 1) {
                        paymentMonth = 12
                        paymentYear -= 1
                    } else paymentMonth -= 1
                },
                onNextClick = {
                    if (paymentMonth == 12) {
                        paymentMonth = 1
                        paymentYear += 1
                    } else paymentMonth += 1
                },
                onMonthYearSelected = { m, y ->
                    paymentMonth = m
                    paymentYear = y
                }
            )

            // 3. Amount Section Card
            val paidVal = paidAmountText.toDoubleOrNull() ?: 0.0
            val dueVal = (expectedAmount - paidVal).coerceAtLeast(0.0)
            val computedStatus = if (paidVal >= expectedAmount && expectedAmount > 0) "PAID" else if (paidVal > 0) "PARTIAL" else "UNPAID"

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderLight, RoundedCornerShape(14.dp)),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Expected Contribution", style = MaterialTheme.typography.bodyMedium, color = TextSlate500)
                        Text(
                            text = CurrencyFormatter.format(expectedAmount, settings.currencySymbol),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextSlate800
                        )
                    }

                    // Paid Amount Field
                    OutlinedTextField(
                        value = paidAmountText,
                        onValueChange = {
                            paidAmountText = it
                            errorMessage = null
                        },
                        label = { Text("Amount Paid (${settings.currencySymbol}) *") },
                        leadingIcon = { Icon(Icons.Default.Payment, contentDescription = null, tint = IndigoPrimary) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("payment_amount_input"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = IndigoPrimary,
                            unfocusedBorderColor = BorderSubtle
                        )
                    )

                    // Quick Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SuggestionChip(
                            onClick = { paidAmountText = expectedAmount.toString() },
                            label = { Text("Full (${CurrencyFormatter.format(expectedAmount, settings.currencySymbol)})", fontSize = 11.5.sp) },
                            border = SuggestionChipDefaults.suggestionChipBorder(enabled = true, borderColor = BorderSubtle)
                        )
                        if (expectedAmount > 0) {
                            SuggestionChip(
                                onClick = { paidAmountText = (expectedAmount / 2).toString() },
                                label = { Text("Half (${CurrencyFormatter.format(expectedAmount / 2, settings.currencySymbol)})", fontSize = 11.5.sp) },
                                border = SuggestionChipDefaults.suggestionChipBorder(enabled = true, borderColor = BorderSubtle)
                            )
                        }
                        SuggestionChip(
                            onClick = { paidAmountText = "0" },
                            label = { Text("Zero / Due", fontSize = 11.5.sp) },
                            border = SuggestionChipDefaults.suggestionChipBorder(enabled = true, borderColor = BorderSubtle)
                        )
                    }

                    // Live Status Result
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Remaining Due", style = MaterialTheme.typography.labelSmall, color = TextSlate400, fontSize = 10.sp)
                            Text(
                                text = CurrencyFormatter.format(dueVal, settings.currencySymbol),
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                color = if (dueVal > 0) StatusUnpaidText else StatusPaidText
                            )
                        }
                        StatusBadge(status = computedStatus)
                    }
                }
            }

            // 4. Payment Method
            Text("PAYMENT METHOD", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = TextSlate400, fontSize = 9.5.sp, letterSpacing = 0.5.sp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Cash", "UPI", "Bank Transfer", "Cheque", "Online", "Other").forEach { method ->
                    val isSelected = paymentMethod == method
                    FilterChip(
                        selected = isSelected,
                        onClick = { paymentMethod = method },
                        label = { Text(method, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = IndigoPrimary,
                            selectedLabelColor = Color.White,
                            containerColor = CardWhite,
                            labelColor = TextSlate500
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) IndigoPrimary else BorderSubtle
                        )
                    )
                }
            }

            // 5. Transaction Reference ID
            OutlinedTextField(
                value = transactionRef,
                onValueChange = { transactionRef = it },
                label = { Text("Reference / UPI Txn ID (Optional)") },
                placeholder = { Text("e.g. UPI-123456789 or Cheque #00452") },
                leadingIcon = { Icon(Icons.Default.Tag, contentDescription = null, tint = IndigoPrimary) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("payment_ref_input"),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = IndigoPrimary,
                    unfocusedBorderColor = BorderSubtle
                )
            )

            // 6. Payment Date Picker
            val cal = Calendar.getInstance().apply { timeInMillis = paymentDate }
            val datePickerDialog = DatePickerDialog(
                context,
                { _, y, m, d ->
                    val selCal = Calendar.getInstance().apply { set(y, m, d, 0, 0, 0) }
                    paymentDate = selCal.timeInMillis
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderLight, RoundedCornerShape(10.dp))
                    .clickable { datePickerDialog.show() },
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(13.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Payment Date", style = MaterialTheme.typography.labelSmall, color = TextSlate400, fontSize = 10.sp)
                            Text(DateUtils.formatDisplayDate(paymentDate), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TextSlate800)
                        }
                    }
                    Text("Change", color = IndigoPrimary, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                }
            }

            // 7. Notes
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes / Remarks (Optional)") },
                placeholder = { Text("e.g. Paid in cash at monthly committee meeting") },
                leadingIcon = { Icon(Icons.Default.Notes, contentDescription = null, tint = IndigoPrimary) },
                maxLines = 2,
                modifier = Modifier.fillMaxWidth().testTag("payment_notes_input"),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = IndigoPrimary,
                    unfocusedBorderColor = BorderSubtle
                )
            )

            if (errorMessage != null) {
                Text(errorMessage!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            // 8. Save Button
            Button(
                onClick = {
                    if (selectedMember == null) {
                        errorMessage = "Please select a member"
                        return@Button
                    }
                    val paid = paidAmountText.toDoubleOrNull()
                    if (paid == null) {
                        errorMessage = "Please enter a valid paid amount"
                        return@Button
                    }

                    viewModel.recordPayment(
                        memberId = selectedMember!!.id,
                        month = paymentMonth,
                        year = paymentYear,
                        expectedAmount = expectedAmount,
                        paidAmount = paid,
                        paymentMethod = paymentMethod,
                        transactionRef = transactionRef.trim(),
                        notes = notes.trim(),
                        paymentDate = paymentDate
                    ) {
                        onNavigateBack()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("save_payment_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
            ) {
                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Save Payment Record", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

