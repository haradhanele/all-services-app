package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.InvestmentRecord
import com.example.ui.theme.Amber500
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CardWhite
import com.example.ui.theme.Emerald500
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.Rose500
import com.example.ui.theme.TextSlate400
import com.example.ui.theme.TextSlate500
import com.example.ui.theme.TextSlate800
import com.example.ui.viewmodel.SocietyViewModel
import com.example.utils.CurrencyFormatter
import com.example.utils.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InvestmentsScreen(
    viewModel: SocietyViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val investments by viewModel.allInvestments.collectAsStateWithLifecycle()
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: All, 1: FD, 2: Mutual Funds, 3: Stocks
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedInvestmentForEdit by remember { mutableStateOf<InvestmentRecord?>(null) }

    val filteredInvestments = remember(investments, selectedTab) {
        when (selectedTab) {
            1 -> investments.filter { it.type == "FD" }
            2 -> investments.filter { it.type == "MUTUAL_FUND" }
            3 -> investments.filter { it.type == "STOCK" }
            else -> investments
        }
    }

    val totalPrincipal = remember(investments) { investments.sumOf { it.principalAmount } }
    val totalCurrentValue = remember(investments) { investments.sumOf { it.currentValue } }
    val totalGain = totalCurrentValue - totalPrincipal
    val totalReturnPercentage = if (totalPrincipal > 0) (totalGain / totalPrincipal) * 100.0 else 0.0

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    viewModel.requestAdminAction {
                        showAddDialog = true
                    }
                },
                containerColor = IndigoPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_investment_fab")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add Investment")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add Investment", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Portfolio Summary Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(IndigoPrimary.copy(alpha = 0.06f), Color.Transparent)
                            )
                        )
                        .padding(16.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Total Portfolio Value",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextSlate500
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (totalGain >= 0) Emerald500.copy(alpha = 0.15f) else Rose500.copy(alpha = 0.15f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.TrendingUp,
                                        contentDescription = null,
                                        tint = if (totalGain >= 0) Emerald500 else Rose500,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${if (totalGain >= 0) "+" else ""}${String.format("%.1f", totalReturnPercentage)}%",
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (totalGain >= 0) Emerald500 else Rose500
                                    )
                                }
                            }
                        }

                        Text(
                            text = "${settings.currencySymbol}${CurrencyFormatter.formatIndian(totalCurrentValue)}",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSlate800,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Invested: ${settings.currencySymbol}${CurrencyFormatter.formatIndian(totalPrincipal)}",
                                fontSize = 12.sp,
                                color = TextSlate500
                            )
                            Text(
                                text = "Gain/Loss: ${if (totalGain >= 0) "+" else ""}${settings.currencySymbol}${CurrencyFormatter.formatIndian(totalGain)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (totalGain >= 0) Emerald500 else Rose500
                            )
                        }
                    }
                }
            }

            // Type Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = IndigoPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = IndigoPrimary,
                        height = 3.dp
                    )
                }
            ) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("All (${investments.size})", fontSize = 12.sp) })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("FD (${investments.count { it.type == "FD" }})", fontSize = 12.sp) })
                Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Mutual Funds", fontSize = 12.sp) })
                Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("Stocks / ETF", fontSize = 12.sp) })
            }

            if (filteredInvestments.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.AccountBalance, contentDescription = null, tint = TextSlate400, modifier = Modifier.size(56.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No investments recorded in this category", fontWeight = FontWeight.SemiBold, color = TextSlate500)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredInvestments, key = { it.id }) { item ->
                        InvestmentCardItem(
                            item = item,
                            currencySymbol = settings.currencySymbol,
                            onEdit = {
                                viewModel.requestAdminAction {
                                    selectedInvestmentForEdit = item
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    // Add Investment Dialog
    if (showAddDialog) {
        AddInvestmentDialog(
            currencySymbol = settings.currencySymbol,
            onDismiss = { showAddDialog = false },
            onSubmit = { type, inst, name, principal, value, notes ->
                viewModel.addInvestment(type, inst, name, principal, value, notes) {
                    showAddDialog = false
                }
            }
        )
    }

    // Edit Valuation Dialog
    selectedInvestmentForEdit?.let { inv ->
        UpdateValuationDialog(
            investment = inv,
            currencySymbol = settings.currencySymbol,
            onDismiss = { selectedInvestmentForEdit = null },
            onSubmit = { newValue ->
                viewModel.updateInvestmentValue(inv, newValue)
                selectedInvestmentForEdit = null
            }
        )
    }
}

@Composable
fun InvestmentCardItem(
    item: InvestmentRecord,
    currencySymbol: String,
    onEdit: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite),
        border = BorderStroke(1.dp, BorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = when (item.type) {
                            "FD" -> IndigoPrimary.copy(alpha = 0.12f)
                            "MUTUAL_FUND" -> Color(0xFF3B82F6).copy(alpha = 0.12f)
                            "STOCK" -> Color(0xFF8B5CF6).copy(alpha = 0.12f)
                            else -> Amber500.copy(alpha = 0.12f)
                        },
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = when (item.type) {
                                    "FD" -> Icons.Default.AccountBalance
                                    "MUTUAL_FUND" -> Icons.Default.PieChart
                                    else -> Icons.Default.ShowChart
                                },
                                contentDescription = null,
                                tint = when (item.type) {
                                    "FD" -> IndigoPrimary
                                    "MUTUAL_FUND" -> Color(0xFF3B82F6)
                                    else -> Color(0xFF8B5CF6)
                                },
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = item.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextSlate800
                        )
                        Text(
                            text = "${item.institution} • ${item.type}",
                            fontSize = 12.sp,
                            color = TextSlate500
                        )
                    }
                }

                IconButton(onClick = onEdit) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Value", tint = TextSlate400, modifier = Modifier.size(18.dp))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Invested Principal", fontSize = 11.5.sp, color = TextSlate500)
                    Text("$currencySymbol${CurrencyFormatter.formatIndian(item.principalAmount)}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextSlate800)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Current Valuation", fontSize = 11.5.sp, color = TextSlate500)
                    Text("$currencySymbol${CurrencyFormatter.formatIndian(item.currentValue)}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                }
            }

            if (item.gainLoss != 0.0) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = "Gain: ${if (item.gainLoss >= 0) "+" else ""}$currencySymbol${CurrencyFormatter.formatIndian(item.gainLoss)} (${String.format("%.1f", item.returnPercentage)}%)",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (item.gainLoss >= 0) Emerald500 else Rose500
                    )
                }
            }

            if (item.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = item.notes,
                    fontSize = 11.sp,
                    color = TextSlate500
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddInvestmentDialog(
    currencySymbol: String,
    onDismiss: () -> Unit,
    onSubmit: (String, String, String, Double, Double, String) -> Unit
) {
    var type by remember { mutableStateOf("FD") }
    var institution by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var principalText by remember { mutableStateOf("") }
    var currentValueText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Group Investment", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Type chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("FD", "MUTUAL_FUND", "STOCK", "OTHER").forEach { t ->
                        FilterChip(
                            selected = type == t,
                            onClick = { type = t },
                            label = { Text(if (t == "MUTUAL_FUND") "MF" else t, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Investment Name / Title") },
                    placeholder = { Text("e.g. SBI 3-Yr FD, Nifty Index Fund") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = institution,
                    onValueChange = { institution = it },
                    label = { Text("Institution / Platform") },
                    placeholder = { Text("e.g. State Bank of India, Zerodha") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = principalText,
                    onValueChange = { principalText = it.filter { c -> c.isDigit() } },
                    label = { Text("Principal Amount ($currencySymbol)") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = currentValueText,
                    onValueChange = { currentValueText = it.filter { c -> c.isDigit() } },
                    label = { Text("Current Valuation ($currencySymbol, Optional)") },
                    placeholder = { Text("Leave blank if same as principal") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Account Number") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val p = principalText.toDoubleOrNull() ?: 0.0
                    val v = currentValueText.toDoubleOrNull() ?: p
                    if (name.isNotBlank() && p > 0) {
                        onSubmit(type, institution, name, p, v, notes)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
            ) {
                Text("Add Investment")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun UpdateValuationDialog(
    investment: InvestmentRecord,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onSubmit: (Double) -> Unit
) {
    var valueText by remember { mutableStateOf(investment.currentValue.toInt().toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Update Current Valuation", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text = investment.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(
                    text = "Invested Principal: $currencySymbol${CurrencyFormatter.formatIndian(investment.principalAmount)}",
                    fontSize = 12.5.sp,
                    color = TextSlate500
                )

                OutlinedTextField(
                    value = valueText,
                    onValueChange = { valueText = it.filter { c -> c.isDigit() } },
                    label = { Text("New Valuation ($currencySymbol)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val v = valueText.toDoubleOrNull() ?: 0.0
                    if (v > 0) onSubmit(v)
                },
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
            ) {
                Text("Update Value")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
