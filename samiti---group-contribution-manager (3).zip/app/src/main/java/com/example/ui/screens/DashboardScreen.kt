package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.NotificationImportant
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.TransactionRecord
import com.example.ui.components.CollectionBarChart
import com.example.ui.components.MemberAvatarView
import com.example.ui.components.MonthPickerBar
import com.example.ui.components.StatMetricCard
import com.example.ui.theme.Amber500
import com.example.ui.theme.BorderLight
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CardWhite
import com.example.ui.theme.Emerald500
import com.example.ui.theme.IndigoHeroDark
import com.example.ui.theme.IndigoHeroGradientEnd
import com.example.ui.theme.IndigoHeroProgress
import com.example.ui.theme.IndigoHeroSubtext
import com.example.ui.theme.IndigoHeroSurface
import com.example.ui.theme.IndigoHeroTrack
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.Rose500
import com.example.ui.theme.StatusPaidText
import com.example.ui.theme.StatusPartialText
import com.example.ui.theme.StatusUnpaidText
import com.example.ui.theme.TextSlate400
import com.example.ui.theme.TextSlate500
import com.example.ui.theme.TextSlate800
import com.example.ui.viewmodel.SocietyViewModel
import com.example.utils.CurrencyFormatter
import com.example.utils.DateUtils

@Composable
fun DashboardScreen(
    viewModel: SocietyViewModel,
    onNavigateToMembers: () -> Unit,
    onNavigateToMonthly: () -> Unit,
    onNavigateToDues: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToRecordPayment: () -> Unit,
    onNavigateToAddMember: () -> Unit,
    onNavigateToMemberProfile: (Long) -> Unit,
    onNavigateToLoans: () -> Unit = {},
    onNavigateToInvestments: () -> Unit = {},
    onNavigateToFeedback: () -> Unit = {},
    onNavigateToLedger: () -> Unit = {},
    listState: LazyListState = rememberLazyListState(),
    modifier: Modifier = Modifier
) {
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val financials by viewModel.overallFinancials.collectAsStateWithLifecycle()
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()
    val monthSummary by viewModel.currentMonthSummary.collectAsStateWithLifecycle()
    val recentTxns by viewModel.allTransactions.collectAsStateWithLifecycle()
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()
    val loansWithVoting by viewModel.allLoansWithVotes.collectAsStateWithLifecycle()

    val pendingLoansCount = remember(loansWithVoting) {
        loansWithVoting.count { it.loan.status in listOf("VOTING", "SUBMITTED") }
    }

    LazyColumn(
        state = listState,
        modifier = modifier
            .fillMaxSize()
            .testTag("dashboard_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Group Society Header Banner (Total Assets & In-Hand Cash/Bank)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dashboard_header_card"),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    Color(0xFF1E1B4B),
                                    Color(0xFF312E81),
                                    Color(0xFF3730A3)
                                )
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = settings.groupName,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 20.sp
                                )
                                if (settings.groupSubtitle.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = settings.groupSubtitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = IndigoHeroSubtext,
                                        fontSize = 12.sp
                                    )
                                }
                            }

                            // Admin status pill
                            Surface(
                                shape = CircleShape,
                                color = Color.White.copy(alpha = 0.15f),
                                modifier = Modifier.padding(start = 8.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isAdminUnlocked) Icons.Default.LockOpen else Icons.Default.Lock,
                                        contentDescription = "Admin Security",
                                        tint = Color.White,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isAdminUnlocked) "Admin Active" else "Protected",
                                        color = Color.White,
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Total Group Assets & In-Hand Balance
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "TOTAL GROUP ASSETS",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = IndigoHeroSubtext,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = "${settings.currencySymbol}${CurrencyFormatter.formatIndian(financials.totalGroupAssets)}",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 22.sp
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "IN-HAND / BANK CASH",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = IndigoHeroSubtext,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = "${settings.currencySymbol}${CurrencyFormatter.formatIndian(financials.availableInHandBalance)}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFA7F3D0),
                                    fontSize = 18.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Sub-metrics row (Bank, Loans Given, Investments)
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color.White.copy(alpha = 0.10f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Loans Given", fontSize = 10.5.sp, color = IndigoHeroSubtext)
                                    Text("${settings.currencySymbol}${CurrencyFormatter.formatIndian(financials.outstandingLoans)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Investments (FD/MF)", fontSize = 10.5.sp, color = IndigoHeroSubtext)
                                    Text("${settings.currencySymbol}${CurrencyFormatter.formatIndian(financials.totalInvestmentsValue)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Monthly Collected", fontSize = 10.5.sp, color = IndigoHeroSubtext)
                                    Text("${settings.currencySymbol}${CurrencyFormatter.formatIndian(financials.currentMonthCollected)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFA7F3D0))
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. Pending Loan Voting Alert Banner (If Any)
        if (pendingLoansCount > 0) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onNavigateToLoans),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Amber500.copy(alpha = 0.12f)),
                    border = BorderStroke(1.dp, Amber500.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = Icons.Default.Handshake,
                                contentDescription = null,
                                tint = Amber500,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "$pendingLoansCount Loan Request(s) Awaiting Vote",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.5.sp,
                                    color = TextSlate800
                                )
                                Text(
                                    text = "70% approval rule active. Tap to vote now.",
                                    fontSize = 11.5.sp,
                                    color = TextSlate500
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = Amber500,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // 3. Quick Actions Grid
        item {
            Text(
                text = "Services & Actions",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextSlate800
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickActionButton(
                    title = "Record Pay",
                    icon = Icons.Default.Payments,
                    backgroundColor = IndigoPrimary,
                    textColor = Color.White,
                    onClick = onNavigateToRecordPayment,
                    modifier = Modifier.weight(1f),
                    testTag = "quick_record_pay_btn"
                )
                QuickActionButton(
                    title = "Loans (70%)",
                    icon = Icons.Default.Handshake,
                    backgroundColor = CardWhite,
                    textColor = TextSlate800,
                    borderColor = BorderLight,
                    onClick = onNavigateToLoans,
                    modifier = Modifier.weight(1f),
                    testTag = "quick_loans_btn"
                )
                QuickActionButton(
                    title = "Investments",
                    icon = Icons.Default.TrendingUp,
                    backgroundColor = CardWhite,
                    textColor = TextSlate800,
                    borderColor = BorderLight,
                    onClick = onNavigateToInvestments,
                    modifier = Modifier.weight(1f),
                    testTag = "quick_investments_btn"
                )
                QuickActionButton(
                    title = "Proposals",
                    icon = Icons.Default.Feedback,
                    backgroundColor = CardWhite,
                    textColor = TextSlate800,
                    borderColor = BorderLight,
                    onClick = onNavigateToFeedback,
                    modifier = Modifier.weight(1f),
                    testTag = "quick_feedback_btn"
                )
            }
        }

        // 4. Current Month Overview Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderLight, RoundedCornerShape(16.dp))
                    .testTag("current_month_summary_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${DateUtils.getMonthName(selectedMonth)} $selectedYear Contributions",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextSlate800
                        )
                        TextButton(
                            onClick = onNavigateToMonthly,
                            modifier = Modifier.testTag("view_month_details_btn")
                        ) {
                            Text("Manage", color = IndigoPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(3.dp))
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(15.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Progress bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Collection Target (${monthSummary.collectionPercentage.toInt()}%)",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSlate500,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "${settings.currencySymbol}${CurrencyFormatter.formatIndian(monthSummary.totalCollected)} / ${settings.currencySymbol}${CurrencyFormatter.formatIndian(monthSummary.totalExpected)}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = TextSlate800,
                            fontSize = 12.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { (monthSummary.collectionPercentage / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(7.dp)
                            .clip(CircleShape),
                        color = IndigoPrimary,
                        trackColor = Color(0xFFEEF2FF)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Paid vs Pending count row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(StatusPaidText))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "${monthSummary.paidCount} Paid", fontWeight = FontWeight.SemiBold, color = TextSlate800, fontSize = 13.sp)
                        }

                        if (monthSummary.partialCount > 0) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(StatusPartialText))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "${monthSummary.partialCount} Partial", fontWeight = FontWeight.SemiBold, color = StatusPartialText, fontSize = 13.sp)
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(StatusUnpaidText))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "${monthSummary.unpaidCount} Pending", fontWeight = FontWeight.SemiBold, color = StatusUnpaidText, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // 5. Group Asset Allocation Breakdown Bar
        if (financials.assetAllocations.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CardWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Group Asset Portfolio",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = TextSlate800
                            )
                            Text(
                                text = "${settings.currencySymbol}${CurrencyFormatter.formatIndian(financials.totalGroupAssets)}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = IndigoPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Segmented bar
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(10.dp)
                                .clip(RoundedCornerShape(5.dp))
                        ) {
                            financials.assetAllocations.forEach { item ->
                                Box(
                                    modifier = Modifier
                                        .weight(item.percentage.coerceAtLeast(1f))
                                        .fillMaxSize()
                                        .background(Color(item.colorHex))
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Labels grid
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            financials.assetAllocations.forEach { item ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(Color(item.colorHex))
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(text = item.category, fontSize = 12.sp, color = TextSlate800)
                                    }
                                    Text(
                                        text = "${settings.currencySymbol}${CurrencyFormatter.formatIndian(item.amount)} (${item.percentage.toInt()}%)",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextSlate800
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 6. Collection Trend Chart
        item {
            CollectionBarChart(
                trends = financials.monthlyTrends,
                currencySymbol = settings.currencySymbol
            )
        }

        // 7. Recent Transactions Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Financial Activity Ledger",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextSlate800
                )
                TextButton(onClick = onNavigateToLedger) {
                    Text("View Full Ledger", color = IndigoPrimary, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (recentTxns.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No financial transactions recorded yet",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSlate500
                    )
                }
            }
        } else {
            items(recentTxns.take(6)) { txn ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, BorderLight, RoundedCornerShape(14.dp)),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CardWhite),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = if (txn.isCredit) Emerald500.copy(alpha = 0.12f) else Rose500.copy(alpha = 0.12f),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (txn.isCredit) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                        contentDescription = null,
                                        tint = if (txn.isCredit) Emerald500 else Rose500,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = txn.description,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextSlate800
                                )
                                Text(
                                    text = "${DateUtils.formatDate(txn.date)} • ${txn.paymentMethod}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSlate500
                                )
                            }
                        }

                        Text(
                            text = "${if (txn.isCredit) "+" else "-"}${settings.currencySymbol}${CurrencyFormatter.formatIndian(txn.amount)}",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = if (txn.isCredit) Emerald500 else Rose500
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun QuickActionButton(
    title: String,
    icon: ImageVector,
    backgroundColor: Color,
    textColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    borderColor: Color? = null,
    testTag: String = "quick_action_btn"
) {
    Card(
        modifier = modifier
            .then(
                if (borderColor != null) Modifier.border(1.dp, borderColor, RoundedCornerShape(12.dp))
                    .clickable(onClick = onClick)
                else Modifier.clickable(onClick = onClick)
            )
            .testTag(testTag),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = textColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = textColor,
                fontWeight = FontWeight.SemiBold,
                fontSize = 11.sp
            )
        }
    }
}
