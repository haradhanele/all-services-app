package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Member
import com.example.data.model.NotificationItem
import com.example.data.model.SocietyNotice
import com.example.ui.theme.Amber500
import com.example.ui.theme.BorderLight
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CardWhite
import com.example.ui.theme.Emerald500
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.IndigoPrimaryContainer
import com.example.ui.theme.Rose500
import com.example.ui.theme.TextSlate400
import com.example.ui.theme.TextSlate500
import com.example.ui.theme.TextSlate800
import com.example.ui.viewmodel.SocietyViewModel
import com.example.utils.CurrencyFormatter
import com.example.utils.DateUtils
import com.example.utils.ReminderHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InboxScreen(
    viewModel: SocietyViewModel,
    onNavigateToRoute: (String) -> Unit,
    onNavigateToMemberProfile: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val notifications by viewModel.allNotifications.collectAsStateWithLifecycle()
    val unreadCount by viewModel.unreadNotificationsCount.collectAsStateWithLifecycle()
    val notices by viewModel.notices.collectAsStateWithLifecycle()
    val membersList by viewModel.allActiveMembers.collectAsStateWithLifecycle()
    val groupSettings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val monthlyMembers by viewModel.monthlyMembersList.collectAsStateWithLifecycle()
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) } // 0: Alerts & Updates, 1: Notices, 2: Direct Connect
    var showPostNoticeDialog by remember { mutableStateOf(false) }
    var memberSearchQuery by remember { mutableStateOf("") }
    var selectedMemberForChat by remember { mutableStateOf<Member?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("combined_inbox_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top Tab Row
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp
            ) {
                SecondaryTabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = IndigoPrimary,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Tab 0: Alerts & Activity
                    Tab(
                        selected = selectedTabIndex == 0,
                        onClick = { selectedTabIndex = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Alerts",
                                    fontWeight = if (selectedTabIndex == 0) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 13.sp
                                )
                                if (unreadCount > 0) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = CircleShape,
                                        color = Rose500,
                                        modifier = Modifier.size(18.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = if (unreadCount > 9) "9+" else "$unreadCount",
                                                color = Color.White,
                                                fontSize = 9.5.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    )

                    // Tab 1: Notices
                    Tab(
                        selected = selectedTabIndex == 1,
                        onClick = { selectedTabIndex = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Notices (${notices.size})",
                                    fontWeight = if (selectedTabIndex == 1) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    )

                    // Tab 2: Direct Connect
                    Tab(
                        selected = selectedTabIndex == 2,
                        onClick = { selectedTabIndex = 2 },
                        text = {
                            Text(
                                text = "Direct Connect",
                                fontWeight = if (selectedTabIndex == 2) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 13.sp
                            )
                        }
                    )
                }
            }

            // Tab Content
            when (selectedTabIndex) {
                0 -> {
                    // 1. Alerts & Activity Notifications
                    InboxAlertsTab(
                        notifications = notifications,
                        unreadCount = unreadCount,
                        onMarkAllRead = { viewModel.markAllNotificationsRead() },
                        onNotificationClick = { item ->
                            viewModel.markNotificationRead(item.id)
                            item.actionRoute?.let { onNavigateToRoute(it) }
                        }
                    )
                }
                1 -> {
                    // 2. Society Notices & Broadcasts
                    InboxNoticesTab(
                        notices = notices,
                        onTogglePin = { notice -> viewModel.togglePinNotice(notice) },
                        onDeleteNotice = { notice -> viewModel.deleteNotice(notice) },
                        onShareNotice = { notice ->
                            ReminderHelper.shareText(
                                context,
                                "📢 *${notice.title}*\n\n${notice.content}\n\n— *${groupSettings.groupName}*",
                                "Share Society Notice"
                            )
                        }
                    )
                }
                2 -> {
                    // 3. Member WhatsApp & Direct Chat
                    InboxDirectConnectTab(
                        members = membersList,
                        monthlyMembers = monthlyMembers,
                        searchQuery = memberSearchQuery,
                        onSearchQueryChange = { memberSearchQuery = it },
                        onMemberClick = { member -> selectedMemberForChat = member },
                        onCallMember = { phone ->
                            if (phone.isNotBlank()) {
                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
                                context.startActivity(intent)
                            }
                        },
                        onNavigateToProfile = onNavigateToMemberProfile
                    )
                }
            }
        }

        // Floating Action Button for Posting Notice in Tab 1
        if (selectedTabIndex == 1) {
            FloatingActionButton(
                onClick = { showPostNoticeDialog = true },
                containerColor = IndigoPrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .testTag("post_notice_fab")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 16.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Post Notice")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("New Notice", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }

    // Post Notice Dialog
    if (showPostNoticeDialog) {
        PostNoticeDialog(
            groupName = groupSettings.groupName,
            onDismiss = { showPostNoticeDialog = false },
            onPost = { title, content, category, isPinned, shareToWhatsApp ->
                viewModel.postNotice(
                    title = title,
                    content = content,
                    category = category,
                    isPinned = isPinned,
                    author = if (isAdminUnlocked) "Society Admin" else "Society Member"
                )
                if (shareToWhatsApp) {
                    ReminderHelper.shareText(
                        context,
                        "📢 *NEW SOCIETY NOTICE*\n*${title.trim()}*\n\n${content.trim()}\n\n— *${groupSettings.groupName}*",
                        "Broadcast Notice"
                    )
                }
                showPostNoticeDialog = false
            }
        )
    }

    // Direct WhatsApp Chat Dialog
    selectedMemberForChat?.let { member ->
        val monthlyItem = monthlyMembers.find { it.member.id == member.id }
        val dueAmount = monthlyItem?.dueAmount ?: 0.0

        MemberChatActionDialog(
            member = member,
            groupName = groupSettings.groupName,
            currencySymbol = groupSettings.currencySymbol,
            dueAmount = dueAmount,
            adminName = groupSettings.adminName,
            adminPhone = groupSettings.adminPhone,
            onDismiss = { selectedMemberForChat = null },
            onSendWhatsApp = { text ->
                if (member.phone.isNotBlank()) {
                    ReminderHelper.sendWhatsAppReminder(context, member.phone, text)
                } else {
                    ReminderHelper.shareText(context, text, "Send Message")
                }
                selectedMemberForChat = null
            },
            onCall = {
                if (member.phone.isNotBlank()) {
                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${member.phone}"))
                    context.startActivity(intent)
                }
            }
        )
    }
}

// -------------------------------------------------------------
// Tab 0: Alerts & Activity
// -------------------------------------------------------------
@Composable
fun InboxAlertsTab(
    notifications: List<NotificationItem>,
    unreadCount: Int,
    onMarkAllRead: () -> Unit,
    onNotificationClick: (NotificationItem) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Activity & Notifications ($unreadCount Unread)",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = TextSlate800
                )

                if (unreadCount > 0) {
                    TextButton(
                        onClick = onMarkAllRead,
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Icon(imageVector = Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Mark all read", fontSize = 11.5.sp)
                    }
                }
            }
        }

        if (notifications.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Default.Notifications, contentDescription = null, tint = TextSlate400, modifier = Modifier.size(52.dp))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("No notifications yet", fontWeight = FontWeight.SemiBold, color = TextSlate500)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("You'll receive alerts for monthly dues, loan votes, and announcements here.", fontSize = 12.sp, color = TextSlate400, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(notifications, key = { it.id }) { item ->
                    NotificationCardItem(
                        item = item,
                        onClick = { onNotificationClick(item) }
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Tab 1: Notices & Announcements
// -------------------------------------------------------------
@Composable
fun InboxNoticesTab(
    notices: List<SocietyNotice>,
    onTogglePin: (SocietyNotice) -> Unit,
    onDeleteNotice: (SocietyNotice) -> Unit,
    onShareNotice: (SocietyNotice) -> Unit
) {
    if (notices.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Campaign, contentDescription = null, tint = TextSlate400, modifier = Modifier.size(56.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text("No notices posted yet", fontWeight = FontWeight.SemiBold, color = TextSlate500)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Tap 'New Notice' below to post an official society announcement.", fontSize = 12.sp, color = TextSlate400, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(notices, key = { it.id }) { notice ->
                NoticeCard(
                    notice = notice,
                    onTogglePin = { onTogglePin(notice) },
                    onDelete = { onDeleteNotice(notice) },
                    onShare = { onShareNotice(notice) }
                )
            }
        }
    }
}

@Composable
fun NoticeCard(
    notice: SocietyNotice,
    onTogglePin: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (notice.isPinned) Color(0xFFEEF2FF) else CardWhite
        ),
        border = BorderStroke(
            1.dp,
            if (notice.isPinned) IndigoPrimary.copy(alpha = 0.4f) else BorderLight
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (notice.isPinned) 2.dp else 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when (notice.category) {
                            "URGENT" -> Rose500.copy(alpha = 0.15f)
                            "PAYMENT" -> Amber500.copy(alpha = 0.15f)
                            "MEETING" -> IndigoPrimary.copy(alpha = 0.15f)
                            else -> Emerald500.copy(alpha = 0.15f)
                        }
                    ) {
                        Text(
                            text = notice.category,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (notice.category) {
                                "URGENT" -> Rose500
                                "PAYMENT" -> Amber500
                                "MEETING" -> IndigoPrimary
                                else -> Emerald500
                            },
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    if (notice.isPinned) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = IndigoPrimary.copy(alpha = 0.12f)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Icon(Icons.Default.PushPin, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(10.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text("PINNED", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                            }
                        }
                    }
                }

                Text(
                    text = DateUtils.formatDate(notice.timestamp),
                    fontSize = 11.sp,
                    color = TextSlate400
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = notice.title,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = TextSlate800
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = notice.content,
                fontSize = 13.sp,
                color = TextSlate500,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Posted by: ${notice.author}",
                    fontSize = 11.sp,
                    color = TextSlate400
                )

                Row {
                    IconButton(onClick = onTogglePin, modifier = Modifier.size(32.dp)) {
                        Icon(
                            if (notice.isPinned) Icons.Default.PushPin else Icons.Outlined.PushPin,
                            contentDescription = "Pin",
                            tint = if (notice.isPinned) IndigoPrimary else TextSlate400,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(onClick = onShare, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Share, contentDescription = "Share", tint = Color(0xFF059669), modifier = Modifier.size(16.dp))
                    }

                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = TextSlate400, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Tab 2: Direct Connect & Member Chat
// -------------------------------------------------------------
@Composable
fun InboxDirectConnectTab(
    members: List<Member>,
    monthlyMembers: List<com.example.data.model.MemberWithMonthlyStatus>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onMemberClick: (Member) -> Unit,
    onCallMember: (String) -> Unit,
    onNavigateToProfile: (Long) -> Unit
) {
    val filtered = remember(members, searchQuery) {
        if (searchQuery.isBlank()) members else {
            members.filter {
                it.name.contains(searchQuery, ignoreCase = true) ||
                        it.phone.contains(searchQuery) ||
                        it.memberCode.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            placeholder = { Text("Search member for direct WhatsApp...", fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSlate400, modifier = Modifier.size(18.dp)) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchQueryChange("") }) {
                        Icon(Icons.Default.Close, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = IndigoPrimary,
                unfocusedBorderColor = BorderLight,
                focusedContainerColor = CardWhite,
                unfocusedContainerColor = CardWhite
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        )

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("No matching members found", color = TextSlate400, fontSize = 13.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filtered, key = { it.id }) { member ->
                    val monthlyItem = monthlyMembers.find { it.member.id == member.id }
                    val due = monthlyItem?.dueAmount ?: 0.0

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onMemberClick(member) },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = CardWhite),
                        border = BorderStroke(1.dp, BorderLight),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = IndigoPrimary.copy(alpha = 0.12f),
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = member.name.take(2).uppercase(),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = IndigoPrimary
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = member.name,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp,
                                    color = TextSlate800
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = member.phone.ifBlank { member.memberCode },
                                        fontSize = 12.sp,
                                        color = TextSlate400
                                    )
                                    if (due > 0) {
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = Rose500.copy(alpha = 0.12f)
                                        ) {
                                            Text(
                                                text = "Due: ₹${CurrencyFormatter.formatIndian(due)}",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Rose500,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            // Quick WhatsApp Button
                            IconButton(
                                onClick = { onMemberClick(member) },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.Chat, contentDescription = "WhatsApp", tint = Color(0xFF059669), modifier = Modifier.size(20.dp))
                            }

                            // Quick Call Button
                            if (member.phone.isNotBlank()) {
                                IconButton(
                                    onClick = { onCallMember(member.phone) },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(Icons.Default.Call, contentDescription = "Call", tint = IndigoPrimary, modifier = Modifier.size(20.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Dialogs
// -------------------------------------------------------------
@Composable
fun PostNoticeDialog(
    groupName: String,
    onDismiss: () -> Unit,
    onPost: (title: String, content: String, category: String, isPinned: Boolean, shareToWhatsApp: Boolean) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("GENERAL") } // GENERAL, URGENT, PAYMENT, MEETING
    var isPinned by remember { mutableStateOf(false) }
    var shareToWhatsApp by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Post Society Notice", fontWeight = FontWeight.Bold, fontSize = 17.sp)
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Notice Subject / Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Announcement Details") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Category:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextSlate500)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("GENERAL", "PAYMENT", "MEETING", "URGENT").forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = IndigoPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Pin to Top", fontSize = 13.sp, color = TextSlate800)
                    androidx.compose.material3.Switch(
                        checked = isPinned,
                        onCheckedChange = { isPinned = it }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Share to WhatsApp after posting", fontSize = 13.sp, color = TextSlate800)
                    androidx.compose.material3.Switch(
                        checked = shareToWhatsApp,
                        onCheckedChange = { shareToWhatsApp = it }
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && content.isNotBlank()) {
                        onPost(title, content, category, isPinned, shareToWhatsApp)
                    }
                },
                enabled = title.isNotBlank() && content.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
            ) {
                Text("Publish Notice")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun MemberChatActionDialog(
    member: Member,
    groupName: String,
    currencySymbol: String,
    dueAmount: Double,
    adminName: String,
    adminPhone: String,
    onDismiss: () -> Unit,
    onSendWhatsApp: (String) -> Unit,
    onCall: () -> Unit
) {
    var customMessage by remember {
        mutableStateOf(
            if (dueAmount > 0) {
                "Hello ${member.name}, this is a gentle reminder from $groupName regarding your pending society contribution of $currencySymbol${CurrencyFormatter.formatIndian(dueAmount)}. Kindly clear the dues at your earliest convenience. Thank you!"
            } else {
                "Hello ${member.name}, greeting from $groupName! We appreciate your timely contributions and active participation in the society."
            }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Connect with ${member.name}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(member.phone.ifBlank { "No phone number registered" }, fontSize = 12.sp, color = TextSlate400)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = customMessage,
                    onValueChange = { customMessage = it },
                    label = { Text("WhatsApp Message Text") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )

                if (member.phone.isNotBlank()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onCall,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Direct Call", fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSendWhatsApp(customMessage) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
            ) {
                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Send WhatsApp")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
