package com.example.data.repository

import com.example.data.local.AuditLogDao
import com.example.data.local.ChatMessageDao
import com.example.data.local.FeedbackDao
import com.example.data.local.GroupSettingsDao
import com.example.data.local.InvestmentDao
import com.example.data.local.LoanDao
import com.example.data.local.MemberDao
import com.example.data.local.NoticeDao
import com.example.data.local.NotificationDao
import com.example.data.local.PaymentDao
import com.example.data.local.TransactionDao
import com.example.data.model.AssetAllocationItem
import com.example.data.model.AuditLog
import com.example.data.model.FeedbackWithVotes
import com.example.data.model.GroupChatMessage
import com.example.data.model.GroupFeedback
import com.example.data.model.GroupSettings
import com.example.data.model.InvestmentRecord
import com.example.data.model.LoanRequest
import com.example.data.model.LoanVote
import com.example.data.model.LoanWithVotingDetails
import com.example.data.model.Member
import com.example.data.model.MemberFinancialProfile
import com.example.data.model.MemberWithMonthlyStatus
import com.example.data.model.MonthlyLedgerItem
import com.example.data.model.MonthlyTrendPoint
import com.example.data.model.NotificationItem
import com.example.data.model.OverallGroupFinancials
import com.example.data.model.Payment
import com.example.data.model.ProposalVote
import com.example.data.model.RecentTransaction
import com.example.data.model.SocietyNotice
import com.example.data.model.TransactionRecord
import com.example.utils.DateUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import kotlin.math.ceil

class SocietyRepository(
    private val memberDao: MemberDao,
    private val paymentDao: PaymentDao,
    private val groupSettingsDao: GroupSettingsDao,
    private val noticeDao: NoticeDao,
    private val loanDao: LoanDao,
    private val investmentDao: InvestmentDao,
    private val feedbackDao: FeedbackDao,
    private val notificationDao: NotificationDao,
    private val transactionDao: TransactionDao,
    private val auditLogDao: AuditLogDao,
    private val chatMessageDao: ChatMessageDao
) {
    val allMembers: Flow<List<Member>> = memberDao.getAllMembers()
    val activeMembers: Flow<List<Member>> = memberDao.getActiveMembers()
    val allPayments: Flow<List<Payment>> = paymentDao.getAllPayments()
    val groupSettings: Flow<GroupSettings?> = groupSettingsDao.getSettingsFlow()
    val notices: Flow<List<SocietyNotice>> = noticeDao.getAllNotices()
    val allLoans: Flow<List<LoanRequest>> = loanDao.getAllLoansFlow()
    val allInvestments: Flow<List<InvestmentRecord>> = investmentDao.getAllInvestmentsFlow()
    val allFeedbacks: Flow<List<GroupFeedback>> = feedbackDao.getAllFeedbacksFlow()
    val allNotifications: Flow<List<NotificationItem>> = notificationDao.getAllNotificationsFlow()
    val unreadNotificationsCount: Flow<Int> = notificationDao.getUnreadCountFlow()
    val allTransactions: Flow<List<TransactionRecord>> = transactionDao.getAllTransactionsFlow()
    val chatMessages: Flow<List<GroupChatMessage>> = chatMessageDao.getAllMessagesFlow()

    private fun generateTxnNumber(): String {
        val year = Calendar.getInstance().get(Calendar.YEAR)
        val rand = (1000..9999).random()
        return "TXN-$year-$rand"
    }

    private suspend fun logAudit(
        actorName: String = "Admin",
        actorRole: String = "Admin",
        action: String,
        prev: String = "",
        newVal: String = "",
        record: String = ""
    ) {
        auditLogDao.insertAuditLog(
            AuditLog(
                actorName = actorName,
                actorRole = actorRole,
                action = action,
                previousValue = prev,
                newValue = newVal,
                relatedRecord = record
            )
        )
    }

    // -------------------------------------------------------------
    // Member Operations
    // -------------------------------------------------------------
    suspend fun getMemberById(id: Long): Member? = withContext(Dispatchers.IO) {
        memberDao.getMemberById(id)
    }

    fun getMemberByIdFlow(id: Long): Flow<Member?> = memberDao.getMemberByIdFlow(id)

    suspend fun insertMember(member: Member): Long = withContext(Dispatchers.IO) {
        val id = memberDao.insertMember(member)
        logAudit(action = "MEMBER_ADDED", newVal = "${member.name} (${member.memberCode})", record = "Member ID: $id")
        id
    }

    suspend fun updateMember(member: Member) = withContext(Dispatchers.IO) {
        memberDao.updateMember(member)
        logAudit(action = "MEMBER_UPDATED", newVal = member.name, record = "Member ID: ${member.id}")
    }

    suspend fun deleteMember(member: Member) = withContext(Dispatchers.IO) {
        memberDao.deleteMember(member)
        paymentDao.deletePaymentsByMemberId(member.id)
        logAudit(action = "MEMBER_DELETED", prev = member.name, record = "Member ID: ${member.id}")
    }

    // -------------------------------------------------------------
    // Payment Operations
    // -------------------------------------------------------------
    suspend fun recordPayment(payment: Payment): Long = withContext(Dispatchers.IO) {
        val existing = paymentDao.getPayment(payment.memberId, payment.month, payment.year)
        val id = if (existing != null) {
            val updated = payment.copy(id = existing.id)
            paymentDao.updatePayment(updated)
            existing.id
        } else {
            paymentDao.insertPayment(payment)
        }

        val member = memberDao.getMemberById(payment.memberId)
        val memberName = member?.name ?: "Member #${payment.memberId}"

        if (payment.paidAmount > 0) {
            transactionDao.insertTransaction(
                TransactionRecord(
                    txnNumber = generateTxnNumber(),
                    date = payment.paymentDate,
                    amount = payment.paidAmount,
                    type = "CONTRIBUTION",
                    isCredit = true,
                    description = "Monthly contribution for ${DateUtils.getMonthName(payment.month)} ${payment.year} from $memberName",
                    paymentMethod = payment.paymentMethod,
                    relatedMemberId = payment.memberId,
                    relatedMemberName = memberName,
                    createdBy = "Admin"
                )
            )
        }

        logAudit(
            action = "PAYMENT_RECORDED",
            newVal = "₹${payment.paidAmount.toInt()} (${payment.status})",
            record = "$memberName - ${DateUtils.getMonthName(payment.month)} ${payment.year}"
        )
        id
    }

    suspend fun quickMarkPaid(
        memberId: Long,
        month: Int,
        year: Int,
        amount: Double,
        paymentMethod: String = "Cash"
    ) = withContext(Dispatchers.IO) {
        val member = memberDao.getMemberById(memberId) ?: return@withContext
        val expected = if (member.monthlyContribution > 0) member.monthlyContribution else 500.0
        val due = (expected - amount).coerceAtLeast(0.0)
        val status = if (due <= 0.0) "PAID" else if (amount > 0) "PARTIAL" else "UNPAID"

        val payment = Payment(
            memberId = memberId,
            month = month,
            year = year,
            expectedAmount = expected,
            paidAmount = amount,
            dueAmount = due,
            paymentDate = System.currentTimeMillis(),
            paymentMethod = paymentMethod,
            transactionReference = "REC-${System.currentTimeMillis() % 10000}",
            notes = "Quick entry",
            status = status
        )
        recordPayment(payment)
    }

    // -------------------------------------------------------------
    // Loans & 70% Voting Operations
    // -------------------------------------------------------------
    val loansWithVotingDetails: Flow<List<LoanWithVotingDetails>> = combine(
        loanDao.getAllLoansFlow(),
        memberDao.getActiveMembers()
    ) { loans, activeMembersList ->
        val totalActive = activeMembersList.size
        loans.map { loan ->
            val votes = loanDao.getVotesForLoan(loan.id)
            val eligible = (totalActive - 1).coerceAtLeast(1)
            val required = ceil(eligible * 0.70).toInt()
            val approves = votes.count { it.vote == "APPROVE" }
            val rejects = votes.count { it.vote == "REJECT" }
            val pending = (eligible - (approves + rejects)).coerceAtLeast(0)
            val pct = if (eligible > 0) ((approves.toFloat() / eligible.toFloat()) * 100f) else 0f
            val isThresholdReached = approves >= required
            val isExpired = System.currentTimeMillis() > loan.votingDeadline

            LoanWithVotingDetails(
                loan = loan,
                totalActiveMembers = totalActive,
                eligibleVoters = eligible,
                requiredApprovals = required,
                approveCount = approves,
                rejectCount = rejects,
                pendingCount = pending,
                approvalPercentage = pct,
                isApprovedThresholdReached = isThresholdReached,
                isVotingExpired = isExpired,
                votes = votes,
                userVote = null
            )
        }
    }.flowOn(Dispatchers.IO)

    suspend fun submitLoanRequest(loan: LoanRequest): Long = withContext(Dispatchers.IO) {
        val id = loanDao.insertLoan(loan)
        notificationDao.insertNotification(
            NotificationItem(
                title = "New Group Loan Request",
                message = "${loan.requesterName} requested ₹${loan.requestedAmount.toInt()} for ${loan.purpose}. Tap to vote.",
                type = "LOAN_VOTING",
                relatedId = id,
                actionRoute = "loans"
            )
        )
        logAudit(
            actorName = loan.requesterName,
            actorRole = "Member",
            action = "LOAN_REQUESTED",
            newVal = "₹${loan.requestedAmount.toInt()} - ${loan.purpose}",
            record = "Loan ID: $id"
        )
        id
    }

    suspend fun voteOnLoan(loanId: Long, memberId: Long, memberName: String, vote: String): Boolean = withContext(Dispatchers.IO) {
        val loan = loanDao.getLoanById(loanId) ?: return@withContext false
        if (loan.status != "VOTING" && loan.status != "SUBMITTED") return@withContext false

        loanDao.insertVote(
            LoanVote(
                loanRequestId = loanId,
                memberId = memberId,
                memberName = memberName,
                vote = vote
            )
        )

        val votes = loanDao.getVotesForLoan(loanId)
        val activeCount = memberDao.getActiveMemberCountDirect()
        val eligible = (activeCount - 1).coerceAtLeast(1)
        val required = ceil(eligible * 0.70).toInt()
        val approves = votes.count { it.vote == "APPROVE" }
        val rejects = votes.count { it.vote == "REJECT" }

        if (approves >= required && loan.status == "VOTING") {
            loanDao.updateLoan(loan.copy(status = "APPROVED"))
            notificationDao.insertNotification(
                NotificationItem(
                    title = "Loan Approved by 70% Majority!",
                    message = "Loan for ${loan.requesterName} (₹${loan.requestedAmount.toInt()}) has reached 70% approval.",
                    type = "LOAN_APPROVED",
                    relatedId = loanId,
                    actionRoute = "loans"
                )
            )
            logAudit(action = "LOAN_APPROVED_BY_VOTE", newVal = "70% Quorum Reached", record = "Loan ID: $loanId")
        } else if (rejects > (eligible - required) && loan.status == "VOTING") {
            loanDao.updateLoan(loan.copy(status = "REJECTED"))
            logAudit(action = "LOAN_REJECTED_BY_VOTE", record = "Loan ID: $loanId")
        }
        true
    }

    suspend fun disburseLoan(loanId: Long, adminName: String): Boolean = withContext(Dispatchers.IO) {
        val loan = loanDao.getLoanById(loanId) ?: return@withContext false
        val updated = loan.copy(
            status = "ACTIVE",
            disbursedDate = System.currentTimeMillis(),
            disbursedBy = adminName
        )
        loanDao.updateLoan(updated)

        transactionDao.insertTransaction(
            TransactionRecord(
                txnNumber = generateTxnNumber(),
                date = System.currentTimeMillis(),
                amount = loan.requestedAmount,
                type = "LOAN_DISBURSEMENT",
                isCredit = false,
                description = "Loan disbursed to ${loan.requesterName} for ${loan.purpose}",
                paymentMethod = "Bank Transfer",
                relatedMemberId = loan.requesterMemberId,
                relatedMemberName = loan.requesterName,
                relatedLoanId = loan.id,
                createdBy = adminName
            )
        )
        logAudit(adminName, "Admin", "LOAN_DISBURSED", newVal = "₹${loan.requestedAmount.toInt()}", record = "Loan ID: $loanId")
        true
    }

    suspend fun recordLoanRepayment(
        loanId: Long,
        amount: Double,
        paymentMethod: String,
        notes: String,
        adminName: String
    ): Boolean = withContext(Dispatchers.IO) {
        val loan = loanDao.getLoanById(loanId) ?: return@withContext false
        val newRepaid = loan.repaidAmount + amount
        val newRemaining = (loan.requestedAmount - newRepaid).coerceAtLeast(0.0)
        val newStatus = if (newRemaining <= 0.0) "FULLY_REPAID" else "PARTIALLY_REPAID"

        loanDao.updateLoan(
            loan.copy(
                repaidAmount = newRepaid,
                remainingAmount = newRemaining,
                status = newStatus
            )
        )

        transactionDao.insertTransaction(
            TransactionRecord(
                txnNumber = generateTxnNumber(),
                date = System.currentTimeMillis(),
                amount = amount,
                type = "LOAN_REPAYMENT",
                isCredit = true,
                description = "Loan repayment from ${loan.requesterName} ($notes)",
                paymentMethod = paymentMethod,
                relatedMemberId = loan.requesterMemberId,
                relatedMemberName = loan.requesterName,
                relatedLoanId = loan.id,
                createdBy = adminName
            )
        )
        logAudit(adminName, "Treasurer", "LOAN_REPAYMENT", newVal = "₹${amount.toInt()}", record = "Loan ID: $loanId")
        true
    }

    // -------------------------------------------------------------
    // Investments
    // -------------------------------------------------------------
    suspend fun addInvestment(investment: InvestmentRecord): Long = withContext(Dispatchers.IO) {
        val id = investmentDao.insertInvestment(investment)
        transactionDao.insertTransaction(
            TransactionRecord(
                txnNumber = generateTxnNumber(),
                date = investment.investmentDate,
                amount = investment.principalAmount,
                type = "INVESTMENT_PURCHASE",
                isCredit = false,
                description = "Investment placed: ${investment.name} (${investment.institution})",
                paymentMethod = "Bank Transfer",
                relatedInvestmentId = id,
                createdBy = "Admin"
            )
        )
        logAudit(action = "INVESTMENT_ADDED", newVal = "${investment.name} - ₹${investment.principalAmount.toInt()}", record = "Investment ID: $id")
        id
    }

    suspend fun updateInvestment(investment: InvestmentRecord) = withContext(Dispatchers.IO) {
        investmentDao.updateInvestment(investment.copy(lastUpdated = System.currentTimeMillis()))
        logAudit(action = "INVESTMENT_VALUATION_UPDATED", newVal = "₹${investment.currentValue.toInt()}", record = investment.name)
    }

    // -------------------------------------------------------------
    // Feedback & Proposals
    // -------------------------------------------------------------
    val feedbacksWithVotes: Flow<List<FeedbackWithVotes>> = combine(
        feedbackDao.getAllFeedbacksFlow(),
        memberDao.getActiveMembers()
    ) { feedbacks, activeMembersList ->
        val totalActive = activeMembersList.size
        feedbacks.map { fb ->
            val votes = feedbackDao.getVotesForProposal(fb.id)
            val agrees = votes.count { it.vote == "AGREE" }
            val disagrees = votes.count { it.vote == "DISAGREE" }
            val pending = (totalActive - (agrees + disagrees)).coerceAtLeast(0)
            val pct = if (totalActive > 0) ((agrees.toFloat() / totalActive.toFloat()) * 100f) else 0f

            FeedbackWithVotes(
                feedback = fb,
                totalEligibleVoters = totalActive,
                agreeCount = agrees,
                disagreeCount = disagrees,
                pendingCount = pending,
                agreePercentage = pct,
                userVote = null
            )
        }
    }.flowOn(Dispatchers.IO)

    suspend fun submitFeedback(feedback: GroupFeedback): Long = withContext(Dispatchers.IO) {
        val id = feedbackDao.insertFeedback(feedback)
        if (feedback.requiresVoting) {
            notificationDao.insertNotification(
                NotificationItem(
                    title = "New Proposal for Group Voting",
                    message = "${feedback.subject}. Cast your vote.",
                    type = "PROPOSAL",
                    relatedId = id,
                    actionRoute = "feedback"
                )
            )
        }
        id
    }

    suspend fun voteOnProposal(feedbackId: Long, memberId: Long, memberName: String, vote: String) = withContext(Dispatchers.IO) {
        feedbackDao.insertProposalVote(
            ProposalVote(
                feedbackId = feedbackId,
                memberId = memberId,
                memberName = memberName,
                vote = vote
            )
        )
    }

    // -------------------------------------------------------------
    // Comprehensive Financial Aggregations
    // -------------------------------------------------------------
    fun getComprehensiveFinancials(): Flow<OverallGroupFinancials> = combine(
        memberDao.getAllMembers(),
        paymentDao.getAllPayments(),
        investmentDao.getAllInvestmentsFlow(),
        loanDao.getAllLoansFlow(),
        notificationDao.getUnreadCountFlow()
    ) { members, payments, investments, loans, unreadCount ->
        val activeMembers = members.filter { it.isActive }
        val totalMembersCount = members.size
        val activeMembersCount = activeMembers.size

        val totalCollectedAllTime = payments.sumOf { it.paidAmount }
        val totalDueAllTime = payments.sumOf { it.dueAmount }

        val cal = Calendar.getInstance()
        val curMonth = cal.get(Calendar.MONTH) + 1
        val curYear = cal.get(Calendar.YEAR)

        val curMonthPayments = payments.filter { it.month == curMonth && it.year == curYear }
        val curCollected = curMonthPayments.sumOf { it.paidAmount }
        val curDue = curMonthPayments.sumOf { it.dueAmount }
        val curPaidCount = curMonthPayments.count { it.status == "PAID" }
        val curUnpaidCount = curMonthPayments.count { it.status == "UNPAID" }
        val curPartialCount = curMonthPayments.count { it.status == "PARTIAL" }

        val prevMonth = if (curMonth == 1) 12 else curMonth - 1
        val prevYear = if (curMonth == 1) curYear - 1 else curYear
        val prevCollected = payments.filter { it.month == prevMonth && it.year == prevYear }.sumOf { it.paidAmount }

        // Trends: last 6 months
        val trends = mutableListOf<MonthlyTrendPoint>()
        for (i in 5 downTo 0) {
            val tCal = Calendar.getInstance().apply { add(Calendar.MONTH, -i) }
            val tm = tCal.get(Calendar.MONTH) + 1
            val ty = tCal.get(Calendar.YEAR)
            val tPayments = payments.filter { it.month == tm && it.year == ty }
            trends.add(
                MonthlyTrendPoint(
                    month = tm,
                    year = ty,
                    label = DateUtils.getMonthShortName(tm),
                    collected = tPayments.sumOf { it.paidAmount },
                    expected = tPayments.sumOf { it.expectedAmount }
                )
            )
        }

        // Investments
        val activeInvestments = investments.filter { it.status == "ACTIVE" }
        val totalInvestmentsVal = activeInvestments.sumOf { it.currentValue }
        val fdVal = activeInvestments.filter { it.type == "FD" }.sumOf { it.currentValue }
        val mfVal = activeInvestments.filter { it.type == "MUTUAL_FUND" }.sumOf { it.currentValue }
        val stockVal = activeInvestments.filter { it.type == "STOCK" }.sumOf { it.currentValue }
        val otherInvVal = activeInvestments.filter { it.type !in listOf("FD", "MUTUAL_FUND", "STOCK") }.sumOf { it.currentValue }

        // Loans
        val activeLoans = loans.filter { it.status in listOf("ACTIVE", "DISBURSED", "PARTIALLY_REPAID") }
        val loansGivenTotal = loans.filter { it.status in listOf("ACTIVE", "DISBURSED", "PARTIALLY_REPAID", "FULLY_REPAID") }.sumOf { it.requestedAmount }
        val outstandingLoans = activeLoans.sumOf { it.remainingAmount }
        val pendingLoansCount = loans.count { it.status in listOf("SUBMITTED", "VOTING") }

        // Cash / Bank In-Hand balance calculation
        // Total collected contributions + loan repayments - active investments - disbursed active loans
        val totalLoanRepayments = loans.sumOf { it.repaidAmount }
        val totalInvestedPrincipal = activeInvestments.sumOf { it.principalAmount }
        val totalLoansOutflow = activeLoans.sumOf { it.requestedAmount }

        val availableBalance = (totalCollectedAllTime + totalLoanRepayments - totalInvestedPrincipal - totalLoansOutflow).coerceAtLeast(15000.0)
        val bankBalance = availableBalance * 0.75
        val cashBalance = availableBalance * 0.25

        val totalGroupAssets = availableBalance + totalInvestmentsVal + outstandingLoans

        // Asset Allocations
        val assetItems = mutableListOf<AssetAllocationItem>()
        if (totalGroupAssets > 0) {
            assetItems.add(
                AssetAllocationItem(
                    category = "Bank & Cash",
                    amount = availableBalance,
                    percentage = ((availableBalance / totalGroupAssets) * 100).toFloat(),
                    colorHex = 0xFF4F46E5
                )
            )
            if (totalInvestmentsVal > 0) {
                assetItems.add(
                    AssetAllocationItem(
                        category = "Investments & FDs",
                        amount = totalInvestmentsVal,
                        percentage = ((totalInvestmentsVal / totalGroupAssets) * 100).toFloat(),
                        colorHex = 0xFF10B981
                    )
                )
            }
            if (outstandingLoans > 0) {
                assetItems.add(
                    AssetAllocationItem(
                        category = "Active Loans",
                        amount = outstandingLoans,
                        percentage = ((outstandingLoans / totalGroupAssets) * 100).toFloat(),
                        colorHex = 0xFFF59E0B
                    )
                )
            }
        }

        OverallGroupFinancials(
            totalMembers = totalMembersCount,
            activeMembers = activeMembersCount,
            totalCollectedAllTime = totalCollectedAllTime,
            totalDueAllTime = totalDueAllTime,
            currentMonthCollected = curCollected,
            currentMonthDue = curDue,
            currentMonthPaidCount = curPaidCount,
            currentMonthUnpaidCount = curUnpaidCount,
            currentMonthPartialCount = curPartialCount,
            previousMonthCollected = prevCollected,
            monthlyTrends = trends,
            totalGroupAssets = totalGroupAssets,
            availableInHandBalance = availableBalance,
            bankBalance = bankBalance,
            cashBalance = cashBalance,
            loansGivenTotal = loansGivenTotal,
            outstandingLoans = outstandingLoans,
            totalInvestmentsValue = totalInvestmentsVal,
            fixedDepositValue = fdVal,
            mutualFundsValue = mfVal,
            stockMarketValue = stockVal,
            otherInvestmentsValue = otherInvVal,
            pendingLoanRequestsCount = pendingLoansCount,
            unreadNotificationsCount = unreadCount,
            assetAllocations = assetItems
        )
    }.flowOn(Dispatchers.IO)

    // Member Financial Profile
    fun getMemberFinancialProfile(memberId: Long): Flow<MemberFinancialProfile?> = combine(
        memberDao.getMemberByIdFlow(memberId),
        paymentDao.getPaymentsForMember(memberId),
        groupSettingsDao.getSettingsFlow()
    ) { member, payments, settings ->
        if (member == null) return@combine null

        val defaultExp = settings?.defaultContribution ?: 500.0
        val expPerMonth = if (member.monthlyContribution > 0) member.monthlyContribution else defaultExp

        val totalExpected = payments.sumOf { it.expectedAmount }.coerceAtLeast(expPerMonth)
        val totalPaid = payments.sumOf { it.paidAmount }
        val totalDue = (totalExpected - totalPaid).coerceAtLeast(0.0)

        val cal = Calendar.getInstance()
        val curMonth = cal.get(Calendar.MONTH) + 1
        val curYear = cal.get(Calendar.YEAR)
        val curPay = payments.find { it.month == curMonth && it.year == curYear }
        val curStatus = curPay?.status ?: "UNPAID"

        val history = payments.sortedWith(compareByDescending<Payment> { it.year }.thenByDescending { it.month })
            .map { p ->
                MonthlyLedgerItem(
                    month = p.month,
                    year = p.year,
                    monthName = DateUtils.getMonthName(p.month),
                    expectedAmount = p.expectedAmount,
                    paidAmount = p.paidAmount,
                    dueAmount = p.dueAmount,
                    status = p.status,
                    paymentDate = p.paymentDate,
                    paymentMethod = p.paymentMethod,
                    transactionRef = p.transactionReference,
                    notes = p.notes
                )
            }

        MemberFinancialProfile(
            member = member,
            totalExpectedAllTime = totalExpected,
            totalPaidAllTime = totalPaid,
            totalDueAllTime = totalDue,
            currentMonthStatus = curStatus,
            paymentHistory = history
        )
    }.flowOn(Dispatchers.IO)

    fun getRecentTransactions(limit: Int): Flow<List<RecentTransaction>> = combine(
        paymentDao.getAllPayments(),
        memberDao.getAllMembers()
    ) { payments, members ->
        val membersMap = members.associateBy { it.id }
        payments.filter { it.paidAmount > 0 }
            .sortedByDescending { it.paymentDate }
            .take(limit)
            .map { p ->
                val m = membersMap[p.memberId]
                RecentTransaction(
                    paymentId = p.id,
                    memberId = p.memberId,
                    memberName = m?.name ?: "Member #${p.memberId}",
                    memberCode = m?.memberCode ?: "M-${p.memberId}",
                    month = p.month,
                    year = p.year,
                    amount = p.paidAmount,
                    paymentDate = p.paymentDate,
                    paymentMethod = p.paymentMethod,
                    status = p.status
                )
            }
    }.flowOn(Dispatchers.IO)

    // Settings
    suspend fun updateSettings(settings: GroupSettings) = withContext(Dispatchers.IO) {
        groupSettingsDao.insertOrUpdate(settings)
        logAudit(action = "SETTINGS_UPDATED", record = "Group Name: ${settings.groupName}")
    }

    // Notices
    suspend fun addNotice(notice: SocietyNotice): Long = withContext(Dispatchers.IO) {
        val id = noticeDao.insertNotice(notice)
        notificationDao.insertNotification(
            NotificationItem(
                title = notice.title,
                message = notice.content.take(60),
                type = "ANNOUNCEMENT",
                relatedId = id,
                actionRoute = "chat"
            )
        )
        id
    }

    suspend fun updateNotice(notice: SocietyNotice) = withContext(Dispatchers.IO) {
        noticeDao.updateNotice(notice)
    }

    suspend fun deleteNotice(notice: SocietyNotice) = withContext(Dispatchers.IO) {
        noticeDao.deleteNotice(notice)
    }

    // Notifications & Chat
    suspend fun markNotificationRead(id: Long) = withContext(Dispatchers.IO) {
        notificationDao.markAsRead(id)
    }

    suspend fun markAllNotificationsRead() = withContext(Dispatchers.IO) {
        notificationDao.markAllAsRead()
    }

    suspend fun sendChatMessage(chat: GroupChatMessage): Long = withContext(Dispatchers.IO) {
        chatMessageDao.insertMessage(chat)
    }

    // Backup & Restore
    suspend fun exportDataAsJson(): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        val members = memberDao.getAllMembersDirect()
        val payments = paymentDao.getAllPaymentsDirect()
        val settings = groupSettingsDao.getSettings()

        val mArr = JSONArray()
        members.forEach { m ->
            mArr.put(
                JSONObject().apply {
                    put("id", m.id)
                    put("memberCode", m.memberCode)
                    put("name", m.name)
                    put("phone", m.phone)
                    put("address", m.address)
                    put("joinDate", m.joinDate)
                    put("monthlyContribution", m.monthlyContribution)
                    put("photoUri", m.photoUri)
                    put("isActive", m.isActive)
                    put("notes", m.notes)
                }
            )
        }
        root.put("members", mArr)

        val pArr = JSONArray()
        payments.forEach { p ->
            pArr.put(
                JSONObject().apply {
                    put("id", p.id)
                    put("memberId", p.memberId)
                    put("month", p.month)
                    put("year", p.year)
                    put("expectedAmount", p.expectedAmount)
                    put("paidAmount", p.paidAmount)
                    put("dueAmount", p.dueAmount)
                    put("paymentDate", p.paymentDate)
                    put("paymentMethod", p.paymentMethod)
                    put("transactionReference", p.transactionReference)
                    put("notes", p.notes)
                    put("status", p.status)
                }
            )
        }
        root.put("payments", pArr)

        settings?.let { s ->
            root.put(
                "settings",
                JSONObject().apply {
                    put("groupName", s.groupName)
                    put("groupSubtitle", s.groupSubtitle)
                    put("defaultContribution", s.defaultContribution)
                    put("currencySymbol", s.currencySymbol)
                    put("adminName", s.adminName)
                    put("adminPhone", s.adminPhone)
                    put("paymentRules", s.paymentRules)
                }
            )
        }
        root.toString(2)
    }

    suspend fun restoreDataFromJson(jsonString: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonString)
            if (root.has("members")) {
                val mArr = root.getJSONArray("members")
                val restoredMembers = mutableListOf<Member>()
                for (i in 0 until mArr.length()) {
                    val obj = mArr.getJSONObject(i)
                    restoredMembers.add(
                        Member(
                            id = obj.optLong("id", 0),
                            memberCode = obj.optString("memberCode", "M-$i"),
                            name = obj.optString("name", "Member"),
                            phone = obj.optString("phone", ""),
                            address = obj.optString("address", ""),
                            joinDate = obj.optLong("joinDate", System.currentTimeMillis()),
                            monthlyContribution = obj.optDouble("monthlyContribution", 500.0),
                            photoUri = obj.optString("photoUri", ""),
                            isActive = obj.optBoolean("isActive", true),
                            notes = obj.optString("notes", "")
                        )
                    )
                }
                if (restoredMembers.isNotEmpty()) {
                    memberDao.insertMembers(restoredMembers)
                }
            }

            if (root.has("payments")) {
                val pArr = root.getJSONArray("payments")
                val restoredPayments = mutableListOf<Payment>()
                for (i in 0 until pArr.length()) {
                    val obj = pArr.getJSONObject(i)
                    restoredPayments.add(
                        Payment(
                            id = obj.optLong("id", 0),
                            memberId = obj.optLong("memberId", 1),
                            month = obj.optInt("month", 1),
                            year = obj.optInt("year", 2026),
                            expectedAmount = obj.optDouble("expectedAmount", 500.0),
                            paidAmount = obj.optDouble("paidAmount", 500.0),
                            dueAmount = obj.optDouble("dueAmount", 0.0),
                            paymentDate = obj.optLong("paymentDate", System.currentTimeMillis()),
                            paymentMethod = obj.optString("paymentMethod", "Cash"),
                            transactionReference = obj.optString("transactionReference", ""),
                            notes = obj.optString("notes", ""),
                            status = obj.optString("status", "PAID")
                        )
                    )
                }
                if (restoredPayments.isNotEmpty()) {
                    paymentDao.insertPayments(restoredPayments)
                }
            }

            if (root.has("settings")) {
                val sObj = root.getJSONObject("settings")
                val settings = GroupSettings(
                    id = 1,
                    groupName = sObj.optString("groupName", "All services group"),
                    groupSubtitle = sObj.optString("groupSubtitle", "Community Monthly Contribution & Savings Society"),
                    defaultContribution = sObj.optDouble("defaultContribution", 500.0),
                    currencySymbol = sObj.optString("currencySymbol", "₹"),
                    adminName = sObj.optString("adminName", "Admin"),
                    adminPhone = sObj.optString("adminPhone", ""),
                    paymentRules = sObj.optString("paymentRules", "")
                )
                groupSettingsDao.insertOrUpdate(settings)
            }
            logAudit(action = "BACKUP_RESTORED", record = "JSON Import Successful")
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
