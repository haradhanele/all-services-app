package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "members")
data class Member(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val memberCode: String = "", // e.g. "M-101"
    val name: String,
    val phone: String = "",
    val address: String = "",
    val joinDate: Long = System.currentTimeMillis(), // Timestamp
    val monthlyContribution: Double = 0.0, // 0.0 means use default group contribution
    val photoUri: String = "",
    val isActive: Boolean = true,
    val notes: String = ""
)
