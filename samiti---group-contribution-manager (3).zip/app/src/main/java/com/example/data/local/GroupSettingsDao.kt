package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.GroupSettings
import kotlinx.coroutines.flow.Flow

@Dao
interface GroupSettingsDao {
    @Query("SELECT * FROM group_settings WHERE id = 1 LIMIT 1")
    fun getSettingsFlow(): Flow<GroupSettings?>

    @Query("SELECT * FROM group_settings WHERE id = 1 LIMIT 1")
    suspend fun getSettings(): GroupSettings?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(settings: GroupSettings)

    @Update
    suspend fun update(settings: GroupSettings)
}
