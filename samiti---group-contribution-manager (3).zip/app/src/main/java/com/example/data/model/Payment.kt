package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "payments",
    indices = [
        Index(value = ["memberId", "month", "year"], unique = true)
    ]
)
data class Payment(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val memberId: Long,
    val month: Int, // 1 to 12
    val year: Int,  // e.g. 2026
    val expectedAmount: Double,
    val paidAmount: Double,
    val dueAmount: Double = (expectedAmount - paidAmount).coerceAtLeast(0.0),
    val paymentDate: Long = System.currentTimeMillis(),
    val paymentMethod: String = "Cash", // Cash, UPI, Bank Transfer, Cheque, Other
    val transactionReference: String = "",
    val notes: String = "",
    val status: String = calculateStatus(expectedAmount, paidAmount) // "PAID", "PARTIAL", "UNPAID"
) {
    companion object {
        fun calculateStatus(expected: Double, paid: Double): String {
            return when {
                paid >= expected && expected > 0 -> "PAID"
                paid > 0 && paid < expected -> "PARTIAL"
                else -> "UNPAID"
            }
        }
    }
}
