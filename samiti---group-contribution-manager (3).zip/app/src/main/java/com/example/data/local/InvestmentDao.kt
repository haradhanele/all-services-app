package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.InvestmentRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface InvestmentDao {
    @Query("SELECT * FROM investments ORDER BY lastUpdated DESC")
    fun getAllInvestmentsFlow(): Flow<List<InvestmentRecord>>

    @Query("SELECT * FROM investments WHERE id = :id")
    suspend fun getInvestmentById(id: Long): InvestmentRecord?

    @Query("SELECT * FROM investments WHERE type = :type ORDER BY lastUpdated DESC")
    fun getInvestmentsByTypeFlow(type: String): Flow<List<InvestmentRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvestment(investment: InvestmentRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvestments(investments: List<InvestmentRecord>)

    @Update
    suspend fun updateInvestment(investment: InvestmentRecord)

    @Query("DELETE FROM investments WHERE id = :id")
    suspend fun deleteInvestmentById(id: Long)
}
