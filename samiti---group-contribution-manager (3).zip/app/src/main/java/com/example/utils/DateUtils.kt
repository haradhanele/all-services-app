package com.example.utils

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateUtils {
    private val monthNames = arrayOf(
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    )

    private val monthShortNames = arrayOf(
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    )

    fun getMonthName(month: Int): String {
        return if (month in 1..12) monthNames[month - 1] else "Month $month"
    }

    fun getMonthShortName(month: Int): String {
        return if (month in 1..12) monthShortNames[month - 1] else "M$month"
    }

    fun formatDate(timestamp: Long): String {
        return formatDisplayDate(timestamp)
    }

    fun formatDisplayDate(timestamp: Long): String {
        if (timestamp <= 0) return "-"
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    fun formatDateTime(timestamp: Long): String {
        if (timestamp <= 0) return "-"
        val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    fun getCurrentMonthYear(): Pair<Int, Int> {
        val cal = Calendar.getInstance()
        return Pair(cal.get(Calendar.MONTH) + 1, cal.get(Calendar.YEAR))
    }

    fun getMonthYearLabel(month: Int, year: Int): String {
        return "${getMonthName(month)} $year"
    }

    fun getMonthYearShortLabel(month: Int, year: Int): String {
        return "${getMonthShortName(month)} '$year".replace("'20", "'")
    }

    fun parseMonthName(name: String): Int {
        val index = monthNames.indexOfFirst { it.equals(name, ignoreCase = true) }
        if (index >= 0) return index + 1
        val shortIndex = monthShortNames.indexOfFirst { it.equals(name, ignoreCase = true) }
        if (shortIndex >= 0) return shortIndex + 1
        return Calendar.getInstance().get(Calendar.MONTH) + 1
    }

    fun getMonthRange(fromTimestamp: Long): List<Pair<Int, Int>> {
        val result = mutableListOf<Pair<Int, Int>>()
        val startCal = Calendar.getInstance().apply {
            timeInMillis = fromTimestamp
            set(Calendar.DAY_OF_MONTH, 1)
        }
        val endCal = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
        }

        val minStartCal = Calendar.getInstance().apply {
            add(Calendar.MONTH, -5)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        if (startCal.after(minStartCal)) {
            startCal.timeInMillis = minStartCal.timeInMillis
        }

        val cursor = Calendar.getInstance().apply {
            timeInMillis = startCal.timeInMillis
        }

        while (!cursor.after(endCal)) {
            val m = cursor.get(Calendar.MONTH) + 1
            val y = cursor.get(Calendar.YEAR)
            result.add(Pair(m, y))
            cursor.add(Calendar.MONTH, 1)
        }
        return result
    }
}
