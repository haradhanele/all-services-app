package com.adr.groupledger.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adr.groupledger.data.model.MonthlyTrendPoint
import com.adr.groupledger.ui.theme.BorderLight
import com.adr.groupledger.ui.theme.BorderSubtle
import com.adr.groupledger.ui.theme.CardWhite
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.TextSlate500
import com.adr.groupledger.ui.theme.TextSlate800
import com.adr.groupledger.utils.CurrencyFormatter

@Composable
fun CollectionBarChart(
    trends: List<MonthlyTrendPoint>,
    currencySymbol: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, BorderLight, RoundedCornerShape(12.dp))
            .testTag("collection_bar_chart"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = CardWhite
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            // Legend
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(IndigoPrimary)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Collected",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSlate500,
                    fontSize = 10.sp
                )
                Spacer(modifier = Modifier.width(10.dp))
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(BorderSubtle)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Expected",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSlate500,
                    fontSize = 10.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (trends.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No collection data recorded yet",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSlate500
                    )
                }
            } else {
                val maxVal = trends.maxOfOrNull { maxOf(it.collected, it.expected) }?.coerceAtLeast(100.0) ?: 100.0
                val primaryColor = IndigoPrimary
                val expectedBarColor = Color(0xFFE2E8F0)

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                ) {
                    val w = size.width
                    val h = size.height
                    val bottomPadding = 32f
                    val topPadding = 14f
                    val chartHeight = h - bottomPadding - topPadding

                    val groupCount = trends.size
                    val groupWidth = w / groupCount.coerceAtLeast(1)
                    val barWidth = (groupWidth * 0.24f).coerceAtMost(18f)

                    // Draw grid lines
                    for (i in 0..3) {
                        val y = topPadding + (chartHeight / 3) * i
                        drawLine(
                            color = Color(0xFFF1F5F9),
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1f
                        )
                    }

                    // Draw bars and labels
                    trends.forEachIndexed { index, point ->
                        val centerX = groupWidth * index + groupWidth / 2

                        // Expected bar (lighter background bar)
                        val expFraction = (point.expected / maxVal).toFloat().coerceIn(0f, 1f)
                        val expBarHeight = (chartHeight * expFraction).coerceAtLeast(3f)
                        val expY = topPadding + chartHeight - expBarHeight

                        drawRoundRect(
                            color = expectedBarColor,
                            topLeft = Offset(centerX - barWidth - 2f, expY),
                            size = Size(barWidth, expBarHeight),
                            cornerRadius = CornerRadius(3f, 3f)
                        )

                        // Collected bar (vibrant indigo bar)
                        val colFraction = (point.collected / maxVal).toFloat().coerceIn(0f, 1f)
                        val colBarHeight = (chartHeight * colFraction).coerceAtLeast(3f)
                        val colY = topPadding + chartHeight - colBarHeight

                        drawRoundRect(
                            color = primaryColor,
                            topLeft = Offset(centerX + 2f, colY),
                            size = Size(barWidth, colBarHeight),
                            cornerRadius = CornerRadius(3f, 3f)
                        )

                        // Draw Month Label below
                        drawContext.canvas.nativeCanvas.drawText(
                            point.label,
                            centerX,
                            h - 6f,
                            android.graphics.Paint().apply {
                                color = android.graphics.Color.parseColor("#64748B")
                                textSize = 22f
                                textAlign = android.graphics.Paint.Align.CENTER
                                isAntiAlias = true
                            }
                        )

                        // Draw collected amount text above bar
                        if (point.collected > 0) {
                            val shortAmount = if (point.collected >= 1000) {
                                "${(point.collected / 1000).toInt()}k"
                            } else {
                                "${point.collected.toInt()}"
                            }
                            drawContext.canvas.nativeCanvas.drawText(
                                shortAmount,
                                centerX + 2f + barWidth / 2,
                                (colY - 4f).coerceAtLeast(12f),
                                android.graphics.Paint().apply {
                                    color = android.graphics.Color.parseColor("#1E293B")
                                    textSize = 18f
                                    textAlign = android.graphics.Paint.Align.CENTER
                                    isAntiAlias = true
                                    isFakeBoldText = true
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

