package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.InvestmentRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface InvestmentDao {
    @Query("SELECT * FROM investments WHERE groupId = :groupId AND isDeleted = 0 ORDER BY lastUpdated DESC")
    fun getAllInvestmentsFlow(groupId: Long): Flow<List<InvestmentRecord>>

    @Query("SELECT * FROM investments WHERE groupId = :groupId ORDER BY lastUpdated DESC")
    fun getAllInvestmentsIncludingDeletedFlow(groupId: Long): Flow<List<InvestmentRecord>>

    @Query("SELECT * FROM investments WHERE id = :id")
    suspend fun getInvestmentById(id: Long): InvestmentRecord?

    @Query("SELECT * FROM investments WHERE groupId = :groupId AND type = :type AND isDeleted = 0 ORDER BY lastUpdated DESC")
    fun getInvestmentsByTypeFlow(groupId: Long, type: String): Flow<List<InvestmentRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvestment(investment: InvestmentRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvestments(investments: List<InvestmentRecord>)

    @Update
    suspend fun updateInvestment(investment: InvestmentRecord)

    @Query("UPDATE investments SET isDeleted = 1, status = 'DELETED', deletedAt = :deletedAt, deletedBy = :deletedBy WHERE id = :id")
    suspend fun softDeleteInvestment(id: Long, deletedBy: String, deletedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM investments WHERE id = :id")
    suspend fun deleteInvestmentById(id: Long)
}
