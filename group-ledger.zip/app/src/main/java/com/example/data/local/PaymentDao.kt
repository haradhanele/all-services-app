package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Payment
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payments WHERE groupId = :groupId ORDER BY paymentDate DESC")
    fun getAllPayments(groupId: Long): Flow<List<Payment>>

    @Query("SELECT * FROM payments WHERE groupId = :groupId ORDER BY paymentDate DESC")
    suspend fun getAllPaymentsDirect(groupId: Long): List<Payment>

    @Query("SELECT * FROM payments WHERE groupId = :groupId AND month = :month AND year = :year")
    fun getPaymentsForMonth(groupId: Long, month: Int, year: Int): Flow<List<Payment>>

    @Query("SELECT * FROM payments WHERE groupId = :groupId AND year = :year")
    fun getPaymentsForYear(groupId: Long, year: Int): Flow<List<Payment>>

    @Query("SELECT * FROM payments WHERE memberId = :memberId ORDER BY year DESC, month DESC")
    fun getPaymentsForMember(memberId: Long): Flow<List<Payment>>

    @Query("SELECT * FROM payments WHERE memberId = :memberId AND month = :month AND year = :year LIMIT 1")
    suspend fun getPayment(memberId: Long, month: Int, year: Int): Payment?

    @Query("SELECT * FROM payments WHERE id = :id")
    suspend fun getPaymentById(id: Long): Payment?

    @Query("SELECT * FROM payments WHERE groupId = :groupId AND (approvalStatus = 'PENDING_APPROVAL' OR status = 'PENDING_APPROVAL') ORDER BY paymentDate DESC")
    fun getPendingApprovalPayments(groupId: Long): Flow<List<Payment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: Payment): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayments(payments: List<Payment>)

    @Update
    suspend fun updatePayment(payment: Payment)

    @Delete
    suspend fun deletePayment(payment: Payment)

    @Query("DELETE FROM payments WHERE id = :id")
    suspend fun deletePaymentById(id: Long)

    @Query("DELETE FROM payments WHERE memberId = :memberId")
    suspend fun deletePaymentsByMemberId(memberId: Long)

    @Query("SELECT * FROM payments WHERE groupId = :groupId AND paidAmount > 0 AND approvalStatus = 'APPROVED' ORDER BY paymentDate DESC LIMIT :limit")
    fun getRecentTransactions(groupId: Long, limit: Int = 10): Flow<List<Payment>>
}
