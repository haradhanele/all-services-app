package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "group_memberships",
    indices = [
        Index(value = ["userId", "groupId"], unique = true)
    ]
)
data class GroupMembership(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long,
    val groupId: Long,
    val role: String = "MEMBER", // "ADMIN", "MEMBER", "TREASURER", "SECRETARY", "MODERATOR"
    val memberIdInGroup: Long? = null, // Links to row in members table for this group
    val joinedAt: Long = System.currentTimeMillis(),
    val isActive: Boolean = true
) {
    val isAdmin: Boolean get() = role.equals("ADMIN", ignoreCase = true)
}

data class UserGroupSummary(
    val group: GroupSettings,
    val membership: GroupMembership,
    val isCurrentActive: Boolean
)
