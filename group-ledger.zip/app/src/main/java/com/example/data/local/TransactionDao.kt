package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.TransactionRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM financial_transactions WHERE groupId = :groupId ORDER BY date DESC")
    fun getAllTransactionsFlow(groupId: Long): Flow<List<TransactionRecord>>

    @Query("SELECT * FROM financial_transactions WHERE groupId = :groupId AND type = :type ORDER BY date DESC")
    fun getTransactionsByTypeFlow(groupId: Long, type: String): Flow<List<TransactionRecord>>

    @Query("SELECT * FROM financial_transactions WHERE groupId = :groupId AND relatedMemberId = :memberId ORDER BY date DESC")
    fun getTransactionsByMemberFlow(groupId: Long, memberId: Long): Flow<List<TransactionRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(transactions: List<TransactionRecord>)

    @Query("SELECT * FROM financial_transactions WHERE id = :id")
    suspend fun getTransactionById(id: Long): TransactionRecord?

    @Query("DELETE FROM financial_transactions WHERE id = :id")
    suspend fun deleteTransactionById(id: Long)
}
