package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "society_notices")
data class SocietyNotice(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val groupId: Long = 1,
    val title: String,
    val content: String,
    val category: String = "ANNOUNCEMENT", // "ANNOUNCEMENT", "COLLECTION", "MEETING", "ALERT", "GENERAL"
    val author: String = "Admin",
    val timestamp: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false
)

