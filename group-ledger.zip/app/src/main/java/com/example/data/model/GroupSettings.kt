package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "group_settings")
data class GroupSettings(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 1,
    val groupName: String = "All services group",
    val groupSubtitle: String = "Monthly Savings & Contribution Society",
    val inviteCode: String = "SAMITI-101",
    val createdByUserId: Long = 1,
    val logoUri: String = "",
    val defaultContribution: Double = 500.0,
    val currencySymbol: String = "₹",
    val financialYearStartMonth: Int = 4, // April
    val adminName: String = "Society Treasurer",
    val adminPhone: String = "+91 98765 43210",
    val adminPin: String = "1234",
    val isPinLockEnabled: Boolean = false,
    val paymentRules: String = "Monthly contribution is due on or before the 10th of every calendar month. Pending balances roll over.",
    val themeMode: String = "SYSTEM" // "SYSTEM", "LIGHT", "DARK"
)

