package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.NotificationItem
import kotlinx.coroutines.flow.Flow

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications WHERE groupId = :groupId ORDER BY timestamp DESC")
    fun getAllNotificationsFlow(groupId: Long): Flow<List<NotificationItem>>

    @Query("SELECT COUNT(*) FROM notifications WHERE groupId = :groupId AND isRead = 0")
    fun getUnreadCountFlow(groupId: Long): Flow<Int>

    @Query("SELECT * FROM notifications WHERE groupId = :groupId AND isRead = 0 ORDER BY timestamp DESC")
    fun getUnreadNotificationsFlow(groupId: Long): Flow<List<NotificationItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(notifications: List<NotificationItem>)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: Long)

    @Query("UPDATE notifications SET isRead = 1 WHERE groupId = :groupId")
    suspend fun markAllAsRead(groupId: Long)

    @Query("DELETE FROM notifications WHERE id = :id")
    suspend fun deleteNotificationById(id: Long)

    @Query("DELETE FROM notifications WHERE groupId = :groupId")
    suspend fun clearAllNotifications(groupId: Long)
}
