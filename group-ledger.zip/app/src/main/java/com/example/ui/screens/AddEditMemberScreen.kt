package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Member
import com.example.ui.theme.BorderLight
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CardWhite
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.TextSlate400
import com.example.ui.theme.TextSlate500
import com.example.ui.theme.TextSlate800
import com.example.ui.theme.appOutlinedTextFieldColors
import com.example.ui.viewmodel.SocietyViewModel
import com.example.utils.CurrencyFormatter
import com.example.utils.DateUtils
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditMemberScreen(
    memberId: Long,
    viewModel: SocietyViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val allMembers by viewModel.allMembers.collectAsStateWithLifecycle()

    val isEditing = memberId > 0

    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()
    val currentMemberId by viewModel.currentMemberId.collectAsStateWithLifecycle()
    val isSelfEditing = isEditing && !isAdminUnlocked && (currentMemberId == memberId)

    var name by remember { mutableStateOf("") }
    var memberCode by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var joinDate by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var contributionText by remember { mutableStateOf("") }
    var useCustomContribution by remember { mutableStateOf(false) }
    var isActive by remember { mutableStateOf(true) }
    var notes by remember { mutableStateOf("") }

    var nameError by remember { mutableStateOf<String?>(null) }

    // Load existing member if editing
    LaunchedEffect(memberId) {
        if (isEditing) {
            val existing = allMembers.find { it.id == memberId }
            if (existing != null) {
                name = existing.name
                memberCode = existing.memberCode
                phone = existing.phone
                address = existing.address
                joinDate = existing.joinDate
                isActive = existing.isActive
                notes = existing.notes
                if (existing.monthlyContribution > 0) {
                    useCustomContribution = true
                    contributionText = existing.monthlyContribution.toString()
                } else {
                    useCustomContribution = false
                    contributionText = ""
                }
            }
        } else {
            // Suggest next code
            val nextNum = 101 + allMembers.size
            memberCode = "SAM-$nextNum"
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (isSelfEditing) "Edit My Profile" else if (isEditing) "Edit Member Details" else "Add New Member",
                            fontWeight = FontWeight.Bold,
                            color = TextSlate800
                        )
                        if (isSelfEditing) {
                            Text(
                                text = "Self-service profile update",
                                fontSize = 11.sp,
                                color = IndigoPrimary
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextSlate800)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CardWhite
                )
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .testTag("add_edit_member_screen"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (isSelfEditing) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = IndigoPrimary.copy(alpha = 0.08f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.25f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Person, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "You are updating your personal profile. Financial parameters & membership ID are managed by the Society Admin.",
                            fontSize = 12.sp,
                            color = TextSlate800,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
            // Full Name Input
            OutlinedTextField(
                value = name,
                onValueChange = {
                    name = it
                    nameError = null
                },
                label = { Text("Full Name *") },
                placeholder = { Text("e.g. Rajesh Sharma") },
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = IndigoPrimary) },
                isError = nameError != null,
                supportingText = {
                    if (nameError != null) Text(nameError!!, color = MaterialTheme.colorScheme.error)
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("member_name_input"),
                shape = RoundedCornerShape(10.dp),
                colors = appOutlinedTextFieldColors()
            )

            // Member ID / Code
            OutlinedTextField(
                value = memberCode,
                onValueChange = { memberCode = it },
                label = { Text("Member Code / ID") },
                placeholder = { Text("e.g. SAM-101") },
                leadingIcon = { Icon(Icons.Default.Tag, contentDescription = null, tint = IndigoPrimary) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("member_code_input"),
                shape = RoundedCornerShape(10.dp),
                colors = appOutlinedTextFieldColors()
            )

            // Phone Number
            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Phone Number") },
                placeholder = { Text("e.g. +91 98300 12345") },
                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = IndigoPrimary) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("member_phone_input"),
                shape = RoundedCornerShape(10.dp),
                colors = appOutlinedTextFieldColors()
            )

            // Address
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Address / Flat Number") },
                placeholder = { Text("e.g. Flat 4B, Harmony Society") },
                leadingIcon = { Icon(Icons.Default.Home, contentDescription = null, tint = IndigoPrimary) },
                maxLines = 2,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("member_address_input"),
                shape = RoundedCornerShape(10.dp),
                colors = appOutlinedTextFieldColors()
            )

            // Join Date Picker Field
            val calendar = Calendar.getInstance().apply { timeInMillis = joinDate }
            val datePickerDialog = DatePickerDialog(
                context,
                { _, y, m, d ->
                    val selCal = Calendar.getInstance().apply {
                        set(y, m, d, 0, 0, 0)
                    }
                    joinDate = selCal.timeInMillis
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderLight, RoundedCornerShape(10.dp))
                    .clickable { datePickerDialog.show() }
                    .testTag("member_joindate_picker"),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(
                    containerColor = CardWhite
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(13.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = IndigoPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Joining Date",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSlate400,
                                fontSize = 10.sp
                            )
                            Text(
                                text = DateUtils.formatDisplayDate(joinDate),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextSlate800
                            )
                        }
                    }
                    Text(
                        text = "Change",
                        color = IndigoPrimary,
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.labelLarge,
                        fontSize = 12.5.sp
                    )
                }
            }

            // Monthly Contribution Preference
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderLight, RoundedCornerShape(12.dp)),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = CardWhite
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Custom Monthly Contribution",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextSlate800
                            )
                            Text(
                                text = "Default is ${CurrencyFormatter.format(settings.defaultContribution, settings.currencySymbol)}/month",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSlate500
                            )
                        }
                        Switch(
                            checked = useCustomContribution,
                            onCheckedChange = { useCustomContribution = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = IndigoPrimary, checkedTrackColor = IndigoPrimary.copy(alpha = 0.3f))
                        )
                    }

                    if (useCustomContribution) {
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = contributionText,
                            onValueChange = { contributionText = it },
                            label = { Text("Custom Amount (${settings.currencySymbol})") },
                            placeholder = { Text("e.g. 1000") },
                            leadingIcon = { Icon(Icons.Default.Payment, contentDescription = null, tint = IndigoPrimary) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("custom_contribution_input"),
                            shape = RoundedCornerShape(10.dp),
                            colors = appOutlinedTextFieldColors()
                        )
                    }
                }
            }

            // Active Status Switch (if editing)
            if (isEditing) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp)),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Active Member",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (isActive) "Included in monthly contribution dues" else "Excluded from future monthly billing",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = isActive,
                            onCheckedChange = { isActive = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = IndigoPrimary, checkedTrackColor = IndigoPrimary.copy(alpha = 0.3f))
                        )
                    }
                }
            }

            // Notes
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes / Remarks (Optional)") },
                placeholder = { Text("e.g. Preferred contact time, patron status, etc.") },
                leadingIcon = { Icon(Icons.Default.Notes, contentDescription = null, tint = IndigoPrimary) },
                maxLines = 3,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("member_notes_input"),
                shape = RoundedCornerShape(10.dp),
                colors = appOutlinedTextFieldColors()
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Save Button
            Button(
                onClick = {
                    if (name.trim().isBlank()) {
                        nameError = "Member name is required"
                        return@Button
                    }

                    val customAmount = if (useCustomContribution) {
                        contributionText.toDoubleOrNull() ?: 0.0
                    } else {
                        0.0
                    }

                    val memberToSave = Member(
                        id = if (isEditing) memberId else 0,
                        memberCode = memberCode.trim(),
                        name = name.trim(),
                        phone = phone.trim(),
                        address = address.trim(),
                        joinDate = joinDate,
                        monthlyContribution = customAmount,
                        isActive = isActive,
                        notes = notes.trim()
                    )

                    viewModel.saveMember(memberToSave) {
                        onNavigateBack()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("save_member_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
            ) {
                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isEditing) "Update Member Details" else "Save Member",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }
    }
}

