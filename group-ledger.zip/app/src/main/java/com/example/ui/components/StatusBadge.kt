package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.StatusPaidBg
import com.example.ui.theme.StatusPaidBorder
import com.example.ui.theme.StatusPaidText
import com.example.ui.theme.StatusPartialBg
import com.example.ui.theme.StatusPartialBorder
import com.example.ui.theme.StatusPartialText
import com.example.ui.theme.StatusUnpaidBg
import com.example.ui.theme.StatusUnpaidBorder
import com.example.ui.theme.StatusUnpaidText

@Composable
fun StatusBadge(
    status: String,
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    val (bgColor, textColor, borderColor, label, icon) = when (status.uppercase()) {
        "PAID", "APPROVED" -> StatusConfig(
            bgColor = StatusPaidBg,
            textColor = StatusPaidText,
            borderColor = StatusPaidBorder,
            label = if (status.uppercase() == "APPROVED") "APPROVED" else "PAID",
            icon = Icons.Default.CheckCircle
        )
        "PENDING", "PENDING_APPROVAL" -> StatusConfig(
            bgColor = Color(0xFFFEF3C7),
            textColor = Color(0xFFB45309),
            borderColor = Color(0xFFFDE68A),
            label = "PENDING APPROVAL",
            icon = Icons.Default.HourglassEmpty
        )
        "REJECTED" -> StatusConfig(
            bgColor = Color(0xFFFEE2E2),
            textColor = Color(0xFFB91C1C),
            borderColor = Color(0xFFFECACA),
            label = "REJECTED",
            icon = Icons.Default.Close
        )
        "PARTIAL" -> StatusConfig(
            bgColor = StatusPartialBg,
            textColor = StatusPartialText,
            borderColor = StatusPartialBorder,
            label = "PARTIAL",
            icon = Icons.Default.HourglassEmpty
        )
        else -> StatusConfig(
            bgColor = StatusUnpaidBg,
            textColor = StatusUnpaidText,
            borderColor = StatusUnpaidBorder,
            label = "UNPAID",
            icon = Icons.Default.Warning
        )
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(6.dp))
            .padding(horizontal = if (compact) 6.dp else 8.dp, vertical = if (compact) 2.5.dp else 4.dp)
            .testTag("status_badge_${status.lowercase()}"),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(5.dp)
                    .clip(CircleShape)
                    .background(textColor)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                color = textColor,
                fontSize = if (compact) 9.sp else 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp,
                style = MaterialTheme.typography.labelSmall
            )
        }
    }
}

private data class StatusConfig(
    val bgColor: Color,
    val textColor: Color,
    val borderColor: Color,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)
