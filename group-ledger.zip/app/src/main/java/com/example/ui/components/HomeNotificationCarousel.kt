package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

/**
 * Configurable rotation interval for the Home page announcement carousel.
 * Default is 4000 milliseconds (4 seconds).
 */
const val ANNOUNCEMENT_ROTATION_INTERVAL = 4000L

enum class NotificationType {
    LOAN_REQUEST,
    PENDING_PAYMENT,
    COMPLAINT,
    PROPOSAL,
    SUGGESTION,
    NOTICE,
    SUCCESS
}

data class HomeNotificationItem(
    val id: String,
    val type: NotificationType,
    val title: String,
    val description: String,
    val categoryLabel: String,
    val accentColor: Color,
    val icon: ImageVector,
    val priority: Int,
    val onClick: () -> Unit
)

/**
 * Smart Auto-Rotating Notification & Announcement Carousel for the Home Page.
 *
 * - Smooth horizontal slide + fade animation between notifications
 * - Stable outer container that prevents layout jumps or size changes
 * - Dynamic accent colors matching notification types:
 *   - Loan Request -> Orange
 *   - Suggestion -> Blue
 *   - Proposal -> Purple
 *   - Complaint -> Red
 *   - Success / Notice -> Green
 *   - Pending / Warning -> Amber/Yellow
 * - Auto-rotation with single-timer lifecycle management
 * - Horizontal swipe gesture support
 * - Subtle carousel dot indicators
 */
@Composable
fun HomeNotificationCarousel(
    notifications: List<HomeNotificationItem>,
    modifier: Modifier = Modifier,
    rotationIntervalMs: Long = ANNOUNCEMENT_ROTATION_INTERVAL
) {
    if (notifications.isEmpty()) {
        return
    }

    var currentIndex by remember(notifications.size) { mutableIntStateOf(0) }
    var isUserInteracting by remember { mutableStateOf(false) }
    var isForwardAnimation by remember { mutableStateOf(true) }

    // Ensure index remains in bounds if notifications list changes dynamically
    val safeIndex = if (currentIndex in notifications.indices) currentIndex else 0
    val currentItem = notifications[safeIndex]

    // Single rotation timer with lifecycle awareness
    LaunchedEffect(notifications.size, isUserInteracting, rotationIntervalMs) {
        if (notifications.size > 1 && !isUserInteracting) {
            while (isActive) {
                delay(rotationIntervalMs)
                isForwardAnimation = true
                currentIndex = (currentIndex + 1) % notifications.size
            }
        }
    }

    // Smooth color transitions for accents
    val animatedBorderColor by animateColorAsState(
        targetValue = currentItem.accentColor.copy(alpha = 0.45f),
        animationSpec = tween(durationMillis = 350),
        label = "border_color_anim"
    )
    val animatedBgTint by animateColorAsState(
        targetValue = currentItem.accentColor.copy(alpha = 0.08f),
        animationSpec = tween(durationMillis = 350),
        label = "bg_tint_anim"
    )

    // Gesture tracking for manual swipe
    var totalDragOffset by remember { mutableFloatStateOf(0f) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("home_notification_carousel")
            .pointerInput(notifications.size) {
                if (notifications.size > 1) {
                    detectHorizontalDragGestures(
                        onDragStart = {
                            isUserInteracting = true
                            totalDragOffset = 0f
                        },
                        onDragEnd = {
                            if (totalDragOffset < -40f) {
                                // Swiped left -> next
                                isForwardAnimation = true
                                currentIndex = (currentIndex + 1) % notifications.size
                            } else if (totalDragOffset > 40f) {
                                // Swiped right -> previous
                                isForwardAnimation = false
                                currentIndex = if (currentIndex - 1 < 0) notifications.size - 1 else (currentIndex - 1) % notifications.size
                            }
                            isUserInteracting = false
                        },
                        onDragCancel = {
                            isUserInteracting = false
                        },
                        onHorizontalDrag = { _, dragAmount ->
                            totalDragOffset += dragAmount
                        }
                    )
                }
            }
            .clickable(onClick = currentItem.onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(1.dp, animatedBorderColor)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(animatedBgTint)
                .padding(horizontal = 11.dp, vertical = 9.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Animated notification body
                AnimatedContent(
                    targetState = safeIndex,
                    transitionSpec = {
                        if (isForwardAnimation) {
                            (slideInHorizontally(
                                animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing)
                            ) { width -> width } + fadeIn(animationSpec = tween(durationMillis = 300)))
                                .togetherWith(
                                    slideOutHorizontally(
                                        animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing)
                                    ) { width -> -width } + fadeOut(animationSpec = tween(durationMillis = 250))
                                )
                        } else {
                            (slideInHorizontally(
                                animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing)
                            ) { width -> -width } + fadeIn(animationSpec = tween(durationMillis = 300)))
                                .togetherWith(
                                    slideOutHorizontally(
                                        animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing)
                                    ) { width -> width } + fadeOut(animationSpec = tween(durationMillis = 250))
                                )
                        }
                    },
                    label = "notification_carousel_content_anim"
                ) { targetIdx ->
                    val item = notifications.getOrElse(targetIdx) { notifications.first() }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("home_notification_item_${item.id}"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Left Section: Icon & Content
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            // Icon Container with Category Accent Tint
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = item.accentColor.copy(alpha = 0.16f),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = item.icon,
                                        contentDescription = item.categoryLabel,
                                        tint = item.accentColor,
                                        modifier = Modifier.size(19.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(9.dp))

                            // Text Details
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    // Category Pill Badge
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = item.accentColor.copy(alpha = 0.18f)
                                    ) {
                                        Text(
                                            text = item.categoryLabel.uppercase(),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = item.accentColor,
                                            modifier = Modifier.padding(horizontal = 4.5.dp, vertical = 1.dp)
                                        )
                                    }

                                    // Title
                                    Text(
                                        text = item.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.5.sp,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Spacer(modifier = Modifier.height(1.5.dp))

                                // Description
                                Text(
                                    text = item.description,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        // Right Action Arrow
                        Surface(
                            shape = CircleShape,
                            color = item.accentColor.copy(alpha = 0.12f),
                            modifier = Modifier.size(24.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = "Open",
                                    tint = item.accentColor,
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                        }
                    }
                }

                // Subtle Dots Carousel Indicator (Only visible if > 1 notification)
                if (notifications.size > 1) {
                    Spacer(modifier = Modifier.height(5.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        notifications.indices.forEach { index ->
                            val isSelected = index == safeIndex
                            Box(
                                modifier = Modifier
                                    .padding(horizontal = 2.dp)
                                    .size(width = if (isSelected) 14.dp else 4.5.dp, height = 4.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isSelected) currentItem.accentColor else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.25f)
                                    )
                                    .clickable {
                                        isForwardAnimation = index >= safeIndex
                                        currentIndex = index
                                    }
                            )
                        }
                    }
                }
            }
        }
    }
}
