package com.adr.groupledger.ui.screens.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.adr.groupledger.R
import kotlinx.coroutines.delay

/**
 * Splash Screen with single smooth 360-degree clockwise logo rotation.
 * Follows exact fintech specifications:
 * - Clean dark navy / near-black stationary canvas
 * - Centered cleaned logo with transparent background
 * - Exactly ONE 360-degree rotation (1.0s, FastOutSlowInEasing)
 * - Stationary pause after rotation (250ms)
 * - Smooth fade transition out (250ms)
 */
@Composable
fun SplashScreen(
    onSplashFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    val rotationAngle = remember { Animatable(0f) }
    val screenAlpha = remember { Animatable(1f) }

    LaunchedEffect(Unit) {
        // 1. One complete 360-degree clockwise rotation (1000ms duration, smooth premium easing)
        rotationAngle.animateTo(
            targetValue = 360f,
            animationSpec = tween(
                durationMillis = 1000,
                easing = FastOutSlowInEasing
            )
        )

        // 2. Brief stationary pause after rotation finishes
        delay(250)

        // 3. Smooth exit fade transition
        screenAlpha.animateTo(
            targetValue = 0f,
            animationSpec = tween(
                durationMillis = 250,
                easing = FastOutSlowInEasing
            )
        )

        // 4. Signal splash completion
        onSplashFinished()
    }

    // Stationary Dark Navy / Near-Black Background matching existing fintech design
    val bgGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF090D16),
            Color(0xFF0F172A),
            Color(0xFF131C31)
        )
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(bgGradient)
            .alpha(screenAlpha.value)
            .testTag("splash_screen_container"),
        contentAlignment = Alignment.Center
    ) {
        // Centered Cleaned Logo with exact 360-degree rotation
        Image(
            painter = painterResource(id = R.drawable.ic_logo_cleaned),
            contentDescription = "Group Ledger Logo",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .size(140.dp)
                .rotate(rotationAngle.value)
                .testTag("splash_logo_image")
        )
    }
}
