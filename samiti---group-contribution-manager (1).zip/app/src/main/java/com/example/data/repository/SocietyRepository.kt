package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.GroupSettingsDao
import com.example.data.local.MemberDao
import com.example.data.local.NoticeDao
import com.example.data.local.PaymentDao
import com.example.data.model.GroupSettings
import com.example.data.model.Member
import com.example.data.model.MemberFinancialProfile
import com.example.data.model.MemberWithMonthlyStatus
import com.example.data.model.MonthlyLedgerItem
import com.example.data.model.MonthlySummary
import com.example.data.model.MonthlyTrendPoint
import com.example.data.model.OverallGroupFinancials
import com.example.data.model.Payment
import com.example.data.model.RecentTransaction
import com.example.data.model.SocietyNotice
import com.example.utils.DateUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.firstOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

class SocietyRepository(
    private val database: AppDatabase,
    private val memberDao: MemberDao,
    private val paymentDao: PaymentDao,
    private val groupSettingsDao: GroupSettingsDao,
    private val noticeDao: NoticeDao = database.noticeDao()
) {
    val allMembers: Flow<List<Member>> = memberDao.getAllMembers()
    val activeMembers: Flow<List<Member>> = memberDao.getActiveMembers()
    val groupSettings: Flow<GroupSettings?> = groupSettingsDao.getSettingsFlow()
    val allPayments: Flow<List<Payment>> = paymentDao.getAllPayments()
    val allNotices: Flow<List<SocietyNotice>> = noticeDao.getAllNotices()

    suspend fun addNotice(notice: SocietyNotice): Long = noticeDao.insertNotice(notice)
    suspend fun updateNotice(notice: SocietyNotice) = noticeDao.updateNotice(notice)
    suspend fun deleteNotice(notice: SocietyNotice) = noticeDao.deleteNotice(notice)
    suspend fun deleteNoticeById(id: Long) = noticeDao.deleteById(id)

    suspend fun getSettings(): GroupSettings {
        return groupSettingsDao.getSettings() ?: GroupSettings()
    }

    suspend fun updateSettings(settings: GroupSettings) {
        groupSettingsDao.insertOrUpdate(settings)
    }

    suspend fun addMember(member: Member): Long {
        return memberDao.insertMember(member)
    }

    suspend fun updateMember(member: Member) {
        memberDao.updateMember(member)
    }

    suspend fun deleteMember(member: Member) {
        paymentDao.deletePaymentsByMemberId(member.id)
        memberDao.deleteMember(member)
    }

    suspend fun getMemberById(id: Long): Member? {
        return memberDao.getMemberById(id)
    }

    fun getMemberByIdFlow(id: Long): Flow<Member?> {
        return memberDao.getMemberByIdFlow(id)
    }

    suspend fun recordPayment(payment: Payment): Long {
        // Calculate status cleanly
        val updated = payment.copy(
            dueAmount = (payment.expectedAmount - payment.paidAmount).coerceAtLeast(0.0),
            status = Payment.calculateStatus(payment.expectedAmount, payment.paidAmount)
        )
        return paymentDao.insertPayment(updated)
    }

    suspend fun deletePayment(paymentId: Long) {
        paymentDao.deletePaymentById(paymentId)
    }

    suspend fun quickMarkPaid(
        memberId: Long,
        month: Int,
        year: Int,
        amount: Double,
        paymentMethod: String = "Cash",
        reference: String = "",
        notes: String = ""
    ) {
        val existing = paymentDao.getPayment(memberId, month, year)
        val member = memberDao.getMemberById(memberId)
        val settings = getSettings()
        val expected = if (existing != null) {
            existing.expectedAmount
        } else if (member != null && member.monthlyContribution > 0) {
            member.monthlyContribution
        } else {
            settings.defaultContribution
        }

        val payment = Payment(
            id = existing?.id ?: 0,
            memberId = memberId,
            month = month,
            year = year,
            expectedAmount = expected,
            paidAmount = amount,
            dueAmount = (expected - amount).coerceAtLeast(0.0),
            paymentDate = System.currentTimeMillis(),
            paymentMethod = paymentMethod,
            transactionReference = reference,
            notes = notes,
            status = Payment.calculateStatus(expected, amount)
        )
        paymentDao.insertPayment(payment)
    }

    fun getPaymentsForMonth(month: Int, year: Int): Flow<List<Payment>> {
        return paymentDao.getPaymentsForMonth(month, year)
    }

    fun getMonthlyMembersStatus(month: Int, year: Int): Flow<List<MemberWithMonthlyStatus>> {
        return combine(
            memberDao.getActiveMembers(),
            paymentDao.getPaymentsForMonth(month, year),
            groupSettingsDao.getSettingsFlow()
        ) { members, payments, settings ->
            val defContribution = settings?.defaultContribution ?: 500.0
            val paymentMap = payments.associateBy { it.memberId }

            members.map { member ->
                val payment = paymentMap[member.id]
                val expected = if (member.monthlyContribution > 0) member.monthlyContribution else defContribution
                val paid = payment?.paidAmount ?: 0.0
                val due = if (payment != null) payment.dueAmount else expected
                val status = if (payment != null) payment.status else "UNPAID"

                MemberWithMonthlyStatus(
                    member = member,
                    payment = payment,
                    effectiveExpectedAmount = expected,
                    paidAmount = paid,
                    dueAmount = due,
                    status = status
                )
            }
        }
    }

    fun getMonthlySummary(month: Int, year: Int): Flow<MonthlySummary> {
        return getMonthlyMembersStatus(month, year).mapToSummary(month, year)
    }

    private fun Flow<List<MemberWithMonthlyStatus>>.mapToSummary(month: Int, year: Int): Flow<MonthlySummary> {
        return combine(this) { (items) ->
            val monthName = DateUtils.getMonthName(month)
            val totalMembers = items.size
            val totalExpected = items.sumOf { it.effectiveExpectedAmount }
            val totalCollected = items.sumOf { it.paidAmount }
            val totalDue = items.sumOf { it.dueAmount }

            val paidCount = items.count { it.status == "PAID" }
            val partialCount = items.count { it.status == "PARTIAL" }
            val unpaidCount = items.count { it.status == "UNPAID" }

            val percentage = if (totalExpected > 0) ((totalCollected / totalExpected) * 100).toFloat() else 0f

            MonthlySummary(
                month = month,
                year = year,
                monthName = monthName,
                totalMembers = totalMembers,
                totalExpected = totalExpected,
                totalCollected = totalCollected,
                totalDue = totalDue,
                paidCount = paidCount,
                partialCount = partialCount,
                unpaidCount = unpaidCount,
                collectionPercentage = percentage.coerceIn(0f, 100f)
            )
        }
    }

    fun getOverallFinancials(): Flow<OverallGroupFinancials> {
        return combine(
            memberDao.getAllMembers(),
            paymentDao.getAllPayments(),
            groupSettingsDao.getSettingsFlow()
        ) { members, payments, settings ->
            val activeMembersList = members.filter { it.isActive }
            val defaultContribution = settings?.defaultContribution ?: 500.0

            val (currMonth, currYear) = DateUtils.getCurrentMonthYear()
            val prevCal = Calendar.getInstance().apply { add(Calendar.MONTH, -1) }
            val prevMonth = prevCal.get(Calendar.MONTH) + 1
            val prevYear = prevCal.get(Calendar.YEAR)

            // Current month payments
            val currPayments = payments.filter { it.month == currMonth && it.year == currYear }
            val currPaymentMap = currPayments.associateBy { it.memberId }

            var currentMonthCollected = 0.0
            var currentMonthDue = 0.0
            var currPaidCount = 0
            var currUnpaidCount = 0
            var currPartialCount = 0

            for (m in activeMembersList) {
                val exp = if (m.monthlyContribution > 0) m.monthlyContribution else defaultContribution
                val pay = currPaymentMap[m.id]
                if (pay != null) {
                    currentMonthCollected += pay.paidAmount
                    currentMonthDue += pay.dueAmount
                    when (pay.status) {
                        "PAID" -> currPaidCount++
                        "PARTIAL" -> currPartialCount++
                        else -> currUnpaidCount++
                    }
                } else {
                    currentMonthDue += exp
                    currUnpaidCount++
                }
            }

            // Previous month collected
            val prevMonthCollected = payments
                .filter { it.month == prevMonth && it.year == prevYear }
                .sumOf { it.paidAmount }

            // Total collected all time
            val totalCollectedAllTime = payments.sumOf { it.paidAmount }

            // Total due all-time: sum of all unpaid/partial months for all active members from their joinDate to current month
            var totalExpectedAllTime = 0.0
            val paymentLookup = payments.associateBy { "${it.memberId}_${it.month}_${it.year}" }

            for (m in activeMembersList) {
                val exp = if (m.monthlyContribution > 0) m.monthlyContribution else defaultContribution
                val months = DateUtils.getMonthRange(m.joinDate)
                for ((mon, yr) in months) {
                    totalExpectedAllTime += exp
                }
            }
            val totalDueAllTime = (totalExpectedAllTime - totalCollectedAllTime).coerceAtLeast(0.0)

            // 6-Month Trend Points
            val trendPoints = mutableListOf<MonthlyTrendPoint>()
            for (offset in -5..0) {
                val tCal = Calendar.getInstance().apply { add(Calendar.MONTH, offset) }
                val tMonth = tCal.get(Calendar.MONTH) + 1
                val tYear = tCal.get(Calendar.YEAR)
                val label = DateUtils.getMonthShortName(tMonth)

                val monthPayments = payments.filter { it.month == tMonth && it.year == tYear }
                val collected = monthPayments.sumOf { it.paidAmount }
                val expected = activeMembersList.sumOf {
                    if (it.monthlyContribution > 0) it.monthlyContribution else defaultContribution
                }

                trendPoints.add(
                    MonthlyTrendPoint(
                        month = tMonth,
                        year = tYear,
                        label = label,
                        collected = collected,
                        expected = expected
                    )
                )
            }

            OverallGroupFinancials(
                totalMembers = members.size,
                activeMembers = activeMembersList.size,
                totalCollectedAllTime = totalCollectedAllTime,
                totalDueAllTime = totalDueAllTime,
                currentMonthCollected = currentMonthCollected,
                currentMonthDue = currentMonthDue,
                currentMonthPaidCount = currPaidCount,
                currentMonthUnpaidCount = currUnpaidCount,
                currentMonthPartialCount = currPartialCount,
                previousMonthCollected = prevMonthCollected,
                monthlyTrends = trendPoints
            )
        }
    }

    fun getMemberFinancialProfile(memberId: Long): Flow<MemberFinancialProfile?> {
        return combine(
            memberDao.getMemberByIdFlow(memberId),
            paymentDao.getPaymentsForMember(memberId),
            groupSettingsDao.getSettingsFlow()
        ) { member, payments, settings ->
            if (member == null) return@combine null

            val defaultContribution = settings?.defaultContribution ?: 500.0
            val expMonthly = if (member.monthlyContribution > 0) member.monthlyContribution else defaultContribution

            val paymentMap = payments.associateBy { "${it.month}_${it.year}" }
            val monthsList = DateUtils.getMonthRange(member.joinDate).reversed() // Most recent first

            val ledgerItems = mutableListOf<MonthlyLedgerItem>()
            var totalExpected = 0.0
            var totalPaid = 0.0

            for ((mon, yr) in monthsList) {
                val pay = paymentMap["${mon}_${yr}"]
                val expected = expMonthly
                val paid = pay?.paidAmount ?: 0.0
                val due = if (pay != null) pay.dueAmount else expected
                val status = if (pay != null) pay.status else "UNPAID"

                totalExpected += expected
                totalPaid += paid

                ledgerItems.add(
                    MonthlyLedgerItem(
                        month = mon,
                        year = yr,
                        monthName = DateUtils.getMonthName(mon),
                        expectedAmount = expected,
                        paidAmount = paid,
                        dueAmount = due,
                        status = status,
                        paymentDate = pay?.paymentDate,
                        paymentMethod = pay?.paymentMethod,
                        transactionRef = pay?.transactionReference,
                        notes = pay?.notes
                    )
                )
            }

            val (currMonth, currYear) = DateUtils.getCurrentMonthYear()
            val currPay = paymentMap["${currMonth}_${currYear}"]
            val currStatus = currPay?.status ?: "UNPAID"
            val totalDue = (totalExpected - totalPaid).coerceAtLeast(0.0)

            MemberFinancialProfile(
                member = member,
                totalExpectedAllTime = totalExpected,
                totalPaidAllTime = totalPaid,
                totalDueAllTime = totalDue,
                currentMonthStatus = currStatus,
                paymentHistory = ledgerItems
            )
        }
    }

    fun getRecentTransactions(limit: Int = 10): Flow<List<RecentTransaction>> {
        return combine(
            paymentDao.getRecentTransactions(limit),
            memberDao.getAllMembers()
        ) { payments, members ->
            val memberMap = members.associateBy { it.id }
            payments.map { pay ->
                val member = memberMap[pay.memberId]
                RecentTransaction(
                    paymentId = pay.id,
                    memberId = pay.memberId,
                    memberName = member?.name ?: "Unknown Member",
                    memberCode = member?.memberCode ?: "-",
                    month = pay.month,
                    year = pay.year,
                    amount = pay.paidAmount,
                    paymentDate = pay.paymentDate,
                    paymentMethod = pay.paymentMethod,
                    status = pay.status
                )
            }
        }
    }

    // Backup & Restore
    suspend fun exportAllDataJson(): String {
        val root = JSONObject()
        val settings = getSettings()
        val members = memberDao.getAllMembers().firstOrNull() ?: emptyList()
        val payments = paymentDao.getAllPayments().firstOrNull() ?: emptyList()

        // Settings JSON
        val settingsObj = JSONObject().apply {
            put("groupName", settings.groupName)
            put("groupSubtitle", settings.groupSubtitle)
            put("defaultContribution", settings.defaultContribution)
            put("currencySymbol", settings.currencySymbol)
            put("financialYearStartMonth", settings.financialYearStartMonth)
            put("adminName", settings.adminName)
            put("adminPhone", settings.adminPhone)
            put("adminPin", settings.adminPin)
            put("isPinLockEnabled", settings.isPinLockEnabled)
            put("paymentRules", settings.paymentRules)
        }
        root.put("settings", settingsObj)

        // Members JSON Array
        val membersArr = JSONArray()
        for (m in members) {
            val mObj = JSONObject().apply {
                put("id", m.id)
                put("memberCode", m.memberCode)
                put("name", m.name)
                put("phone", m.phone)
                put("address", m.address)
                put("joinDate", m.joinDate)
                put("monthlyContribution", m.monthlyContribution)
                put("photoUri", m.photoUri)
                put("isActive", m.isActive)
                put("notes", m.notes)
            }
            membersArr.put(mObj)
        }
        root.put("members", membersArr)

        // Payments JSON Array
        val paymentsArr = JSONArray()
        for (p in payments) {
            val pObj = JSONObject().apply {
                put("id", p.id)
                put("memberId", p.memberId)
                put("month", p.month)
                put("year", p.year)
                put("expectedAmount", p.expectedAmount)
                put("paidAmount", p.paidAmount)
                put("dueAmount", p.dueAmount)
                put("paymentDate", p.paymentDate)
                put("paymentMethod", p.paymentMethod)
                put("transactionReference", p.transactionReference)
                put("notes", p.notes)
                put("status", p.status)
            }
            paymentsArr.put(pObj)
        }
        root.put("payments", paymentsArr)
        root.put("exportTimestamp", System.currentTimeMillis())

        return root.toString(2)
    }

    suspend fun restoreAllDataJson(jsonString: String): Boolean {
        try {
            val root = JSONObject(jsonString)
            if (root.has("settings")) {
                val sObj = root.getJSONObject("settings")
                val restoredSettings = GroupSettings(
                    id = 1,
                    groupName = sObj.optString("groupName", "Samiti Fund"),
                    groupSubtitle = sObj.optString("groupSubtitle", ""),
                    defaultContribution = sObj.optDouble("defaultContribution", 500.0),
                    currencySymbol = sObj.optString("currencySymbol", "₹"),
                    financialYearStartMonth = sObj.optInt("financialYearStartMonth", 4),
                    adminName = sObj.optString("adminName", "Admin"),
                    adminPhone = sObj.optString("adminPhone", ""),
                    adminPin = sObj.optString("adminPin", "1234"),
                    isPinLockEnabled = sObj.optBoolean("isPinLockEnabled", false),
                    paymentRules = sObj.optString("paymentRules", "")
                )
                groupSettingsDao.insertOrUpdate(restoredSettings)
            }

            if (root.has("members")) {
                val mArr = root.getJSONArray("members")
                val members = mutableListOf<Member>()
                for (i in 0 until mArr.length()) {
                    val o = mArr.getJSONObject(i)
                    members.add(
                        Member(
                            id = o.optLong("id", 0),
                            memberCode = o.optString("memberCode", ""),
                            name = o.optString("name", ""),
                            phone = o.optString("phone", ""),
                            address = o.optString("address", ""),
                            joinDate = o.optLong("joinDate", System.currentTimeMillis()),
                            monthlyContribution = o.optDouble("monthlyContribution", 0.0),
                            photoUri = o.optString("photoUri", ""),
                            isActive = o.optBoolean("isActive", true),
                            notes = o.optString("notes", "")
                        )
                    )
                }
                memberDao.insertMembers(members)
            }

            if (root.has("payments")) {
                val pArr = root.getJSONArray("payments")
                val payments = mutableListOf<Payment>()
                for (i in 0 until pArr.length()) {
                    val o = pArr.getJSONObject(i)
                    payments.add(
                        Payment(
                            id = o.optLong("id", 0),
                            memberId = o.optLong("memberId", 0),
                            month = o.optInt("month", 1),
                            year = o.optInt("year", 2026),
                            expectedAmount = o.optDouble("expectedAmount", 500.0),
                            paidAmount = o.optDouble("paidAmount", 0.0),
                            dueAmount = o.optDouble("dueAmount", 0.0),
                            paymentDate = o.optLong("paymentDate", System.currentTimeMillis()),
                            paymentMethod = o.optString("paymentMethod", "Cash"),
                            transactionReference = o.optString("transactionReference", ""),
                            notes = o.optString("notes", ""),
                            status = o.optString("status", "UNPAID")
                        )
                    )
                }
                paymentDao.insertPayments(payments)
            }
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    suspend fun resetSampleData() {
        AppDatabase.populateInitialData(database)
    }
}
