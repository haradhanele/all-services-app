package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.GroupSettings
import com.example.data.model.Member
import com.example.data.model.Payment
import com.example.data.model.SocietyNotice
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

@Database(
    entities = [Member::class, Payment::class, GroupSettings::class, SocietyNotice::class],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun memberDao(): MemberDao
    abstract fun paymentDao(): PaymentDao
    abstract fun groupSettingsDao(): GroupSettingsDao
    abstract fun noticeDao(): NoticeDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE group_settings ADD COLUMN themeMode TEXT NOT NULL DEFAULT 'SYSTEM'")
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `society_notices` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `title` TEXT NOT NULL,
                        `content` TEXT NOT NULL,
                        `category` TEXT NOT NULL DEFAULT 'ANNOUNCEMENT',
                        `author` TEXT NOT NULL DEFAULT 'Admin',
                        `timestamp` INTEGER NOT NULL,
                        `isPinned` INTEGER NOT NULL DEFAULT 0
                    )
                """.trimIndent())
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "samiti_society_database.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .fallbackToDestructiveMigration()
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database)
                    }
                }
            }
        }

        suspend fun populateInitialData(database: AppDatabase) {
            val settingsDao = database.groupSettingsDao()
            val memberDao = database.memberDao()
            val paymentDao = database.paymentDao()

            // 1. Initial Group Settings
            val defaultSettings = GroupSettings(
                id = 1,
                groupName = "All services group",
                groupSubtitle = "Community Monthly Contribution & Savings Society",
                defaultContribution = 500.0,
                currencySymbol = "₹",
                financialYearStartMonth = 4, // April
                adminName = "Rajesh Sharma",
                adminPhone = "+91 98310 12345",
                adminPin = "1234",
                isPinLockEnabled = false,
                paymentRules = "Contribution is due by the 10th of every month. Unpaid amounts roll over as pending dues."
            )
            settingsDao.insertOrUpdate(defaultSettings)

            // Current calendar date
            val calendar = Calendar.getInstance()
            val currentYear = calendar.get(Calendar.YEAR)
            val currentMonth = calendar.get(Calendar.MONTH) + 1 // 1..12

            // Base join timestamp: 6 months ago
            val joinCal = Calendar.getInstance().apply {
                add(Calendar.MONTH, -5)
                set(Calendar.DAY_OF_MONTH, 1)
            }
            val joinTimestamp = joinCal.timeInMillis

            // 2. Initial Sample Members
            val initialMembers = listOf(
                Member(
                    id = 1,
                    memberCode = "SAM-001",
                    name = "Amitabh Banerjee",
                    phone = "+91 98301 23456",
                    address = "Flat 3A, Block B, Green Heights",
                    joinDate = joinTimestamp,
                    monthlyContribution = 500.0,
                    isActive = true,
                    notes = "Founder member"
                ),
                Member(
                    id = 2,
                    memberCode = "SAM-002",
                    name = "Priya Chakraborty",
                    phone = "+91 98312 34567",
                    address = "Plot 12, Lake View Road",
                    joinDate = joinTimestamp,
                    monthlyContribution = 500.0,
                    isActive = true,
                    notes = "Regular payer"
                ),
                Member(
                    id = 3,
                    memberCode = "SAM-003",
                    name = "Sourav Ganguly",
                    phone = "+91 98323 45678",
                    address = "House 45, VIP Enclave",
                    joinDate = joinTimestamp,
                    monthlyContribution = 1000.0, // Variable higher contribution
                    isActive = true,
                    notes = "Patron tier contribution"
                ),
                Member(
                    id = 4,
                    memberCode = "SAM-004",
                    name = "Ananya Mukherjee",
                    phone = "+91 98334 56789",
                    address = "Tower 2, Apt 804, Regency Park",
                    joinDate = joinTimestamp,
                    monthlyContribution = 500.0,
                    isActive = true,
                    notes = ""
                ),
                Member(
                    id = 5,
                    memberCode = "SAM-005",
                    name = "Debasish Roy",
                    phone = "+91 98345 67890",
                    address = "B-14, Shantiniketan Society",
                    joinDate = joinTimestamp,
                    monthlyContribution = 500.0,
                    isActive = true,
                    notes = "Prefers UPI payments"
                ),
                Member(
                    id = 6,
                    memberCode = "SAM-006",
                    name = "Sunita Sen",
                    phone = "+91 98356 78901",
                    address = "12/1 Deshapriya Park",
                    joinDate = joinTimestamp,
                    monthlyContribution = 500.0,
                    isActive = true,
                    notes = ""
                ),
                Member(
                    id = 7,
                    memberCode = "SAM-007",
                    name = "Vikram Aditya",
                    phone = "+91 98367 89012",
                    address = "78 Rashbehari Avenue",
                    joinDate = joinTimestamp,
                    monthlyContribution = 500.0,
                    isActive = true,
                    notes = ""
                ),
                Member(
                    id = 8,
                    memberCode = "SAM-008",
                    name = "Mousumi Das",
                    phone = "+91 98378 90123",
                    address = "C-5, Sunrise Apartment",
                    joinDate = joinTimestamp,
                    monthlyContribution = 750.0,
                    isActive = true,
                    notes = ""
                )
            )
            memberDao.insertMembers(initialMembers)

            // 3. Populate Payments for the past few months up to current
            val paymentList = mutableListOf<Payment>()

            // Iterate past 4 months + current month
            for (mOffset in -4..0) {
                val mCal = Calendar.getInstance().apply {
                    add(Calendar.MONTH, mOffset)
                }
                val mYear = mCal.get(Calendar.YEAR)
                val mMonth = mCal.get(Calendar.MONTH) + 1

                for (member in initialMembers) {
                    val exp = if (member.monthlyContribution > 0) member.monthlyContribution else 500.0

                    if (mOffset < 0) {
                        // Past months: mostly paid, some partial or unpaid
                        when (member.id) {
                            1L, 2L, 3L, 4L -> {
                                paymentList.add(
                                    Payment(
                                        memberId = member.id,
                                        month = mMonth,
                                        year = mYear,
                                        expectedAmount = exp,
                                        paidAmount = exp,
                                        dueAmount = 0.0,
                                        paymentDate = mCal.timeInMillis + 86400000L * 5,
                                        paymentMethod = if (member.id % 2L == 0L) "UPI" else "Cash",
                                        transactionReference = if (member.id % 2L == 0L) "UPI/REF/${mYear}${mMonth}/${member.id}08" else "",
                                        notes = "Monthly deposit received on time",
                                        status = "PAID"
                                    )
                                )
                            }
                            5L -> {
                                // Partial payment in earlier month
                                val paid = if (mOffset == -1) 300.0 else exp
                                val due = exp - paid
                                paymentList.add(
                                    Payment(
                                        memberId = member.id,
                                        month = mMonth,
                                        year = mYear,
                                        expectedAmount = exp,
                                        paidAmount = paid,
                                        dueAmount = due,
                                        paymentDate = mCal.timeInMillis + 86400000L * 8,
                                        paymentMethod = "UPI",
                                        transactionReference = "UPI/TXN/${mYear}${mMonth}55",
                                        notes = if (due > 0) "Part payment of ₹300 made" else "Paid",
                                        status = if (due > 0) "PARTIAL" else "PAID"
                                    )
                                )
                            }
                            6L, 7L, 8L -> {
                                paymentList.add(
                                    Payment(
                                        memberId = member.id,
                                        month = mMonth,
                                        year = mYear,
                                        expectedAmount = exp,
                                        paidAmount = exp,
                                        dueAmount = 0.0,
                                        paymentDate = mCal.timeInMillis + 86400000L * 3,
                                        paymentMethod = "Bank Transfer",
                                        transactionReference = "IMPS/NEFT/${mYear}${mMonth}99",
                                        notes = "Verified bank transfer",
                                        status = "PAID"
                                    )
                                )
                            }
                        }
                    } else {
                        // Current month: some paid, some partial, some pending
                        when (member.id) {
                            1L -> paymentList.add(
                                Payment(
                                    memberId = member.id,
                                    month = mMonth,
                                    year = mYear,
                                    expectedAmount = exp,
                                    paidAmount = exp,
                                    dueAmount = 0.0,
                                    paymentDate = System.currentTimeMillis() - 86400000L * 2,
                                    paymentMethod = "Cash",
                                    transactionReference = "REC-CURR-01",
                                    notes = "Paid in cash to Treasurer",
                                    status = "PAID"
                                )
                            )
                            2L -> paymentList.add(
                                Payment(
                                    memberId = member.id,
                                    month = mMonth,
                                    year = mYear,
                                    expectedAmount = exp,
                                    paidAmount = exp,
                                    dueAmount = 0.0,
                                    paymentDate = System.currentTimeMillis() - 86400000L,
                                    paymentMethod = "UPI",
                                    transactionReference = "UPI/GPAY/9831/11",
                                    notes = "Google Pay received",
                                    status = "PAID"
                                )
                            )
                            3L -> paymentList.add(
                                Payment(
                                    memberId = member.id,
                                    month = mMonth,
                                    year = mYear,
                                    expectedAmount = exp,
                                    paidAmount = exp,
                                    dueAmount = 0.0,
                                    paymentDate = System.currentTimeMillis() - 86400000L * 3,
                                    paymentMethod = "Bank Transfer",
                                    transactionReference = "HDFC0012984",
                                    notes = "Netbanking auto-credit",
                                    status = "PAID"
                                )
                            )
                            5L -> paymentList.add(
                                Payment(
                                    memberId = member.id,
                                    month = mMonth,
                                    year = mYear,
                                    expectedAmount = exp,
                                    paidAmount = 250.0,
                                    dueAmount = 250.0,
                                    paymentDate = System.currentTimeMillis() - 3600000L * 12,
                                    paymentMethod = "UPI",
                                    transactionReference = "PhonePe/88392",
                                    notes = "Remaining ₹250 promised by weekend",
                                    status = "PARTIAL"
                                )
                            )
                            // 4, 6, 7, 8 remain unpaid for current month to show realistic pending dues & reminder triggers!
                            4L -> paymentList.add(
                                Payment(
                                    memberId = member.id,
                                    month = mMonth,
                                    year = mYear,
                                    expectedAmount = exp,
                                    paidAmount = 0.0,
                                    dueAmount = exp,
                                    paymentDate = System.currentTimeMillis(),
                                    paymentMethod = "None",
                                    transactionReference = "",
                                    notes = "Pending",
                                    status = "UNPAID"
                                )
                            )
                            6L -> paymentList.add(
                                Payment(
                                    memberId = member.id,
                                    month = mMonth,
                                    year = mYear,
                                    expectedAmount = exp,
                                    paidAmount = 0.0,
                                    dueAmount = exp,
                                    paymentDate = System.currentTimeMillis(),
                                    paymentMethod = "None",
                                    transactionReference = "",
                                    notes = "Pending",
                                    status = "UNPAID"
                                )
                            )
                        }
                    }
                }
            }

            paymentDao.insertPayments(paymentList)

            // 4. Sample Society Notices / Announcements
            val noticeDao = database.noticeDao()
            noticeDao.insertNotice(
                SocietyNotice(
                    title = "📢 Monthly Samiti Contribution Due",
                    content = "Dear members, kindly clear your monthly contribution by the 10th of this month. Digital receipts are generated automatically.",
                    category = "COLLECTION",
                    author = "Treasurer",
                    timestamp = System.currentTimeMillis() - 86400000L * 2,
                    isPinned = true
                )
            )
            noticeDao.insertNotice(
                SocietyNotice(
                    title = "🗓️ Society General Meeting (AGM)",
                    content = "The bi-monthly society review meeting will be held on Sunday at 6:00 PM in the community hall. All members are requested to attend.",
                    category = "MEETING",
                    author = "President",
                    timestamp = System.currentTimeMillis() - 86400000L * 5,
                    isPinned = false
                )
            )
            noticeDao.insertNotice(
                SocietyNotice(
                    title = "✨ Welcome to Digital Samiti Portal",
                    content = "Welcome to All services group society digital ledger! You can now check member profiles, monthly payment status, and pending dues with 1-tap.",
                    category = "ANNOUNCEMENT",
                    author = "Admin",
                    timestamp = System.currentTimeMillis() - 86400000L * 15,
                    isPinned = false
                )
            )
        }
    }
}
