package com.example.ui.navigation

import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.NotificationImportant
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.NotificationImportant
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.components.AdminPinDialog
import com.example.ui.screens.AddEditMemberScreen
import com.example.ui.screens.BackupRestoreScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.MemberProfileScreen
import com.example.ui.screens.MembersScreen
import com.example.ui.screens.MonthlyManagementScreen
import com.example.ui.screens.PendingDuesScreen
import com.example.ui.screens.RecordPaymentScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SocietyChatScreen
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CardWhite
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.Rose500
import com.example.ui.theme.TextSlate400
import com.example.ui.theme.TextSlate500
import com.example.ui.theme.TextSlate800
import com.example.ui.viewmodel.SocietyViewModel

sealed class Screen(val route: String, val title: String, val selectedIcon: ImageVector, val unselectedIcon: ImageVector) {
    data object Dashboard : Screen("dashboard", "Dashboard", Icons.Filled.Dashboard, Icons.Outlined.Dashboard)
    data object Monthly : Screen("monthly", "Monthly", Icons.Filled.CalendarMonth, Icons.Outlined.CalendarMonth)
    data object Members : Screen("members", "Members", Icons.Filled.Group, Icons.Outlined.Group)
    data object Chat : Screen("chat", "Chat", Icons.Filled.Chat, Icons.Outlined.Chat)
    data object Reports : Screen("reports", "Reports", Icons.Filled.ReceiptLong, Icons.Outlined.ReceiptLong)
    data object Dues : Screen("dues", "Dues", Icons.Filled.NotificationsActive, Icons.Outlined.Notifications)
}

val bottomNavItems = listOf(
    Screen.Dashboard,
    Screen.Monthly,
    Screen.Members,
    Screen.Chat,
    Screen.Reports
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SamitiApp(
    viewModel: SocietyViewModel,
    modifier: Modifier = Modifier,
    navController: NavHostController = rememberNavController()
) {
    val context = LocalContext.current
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val userMessage by viewModel.userMessage.collectAsStateWithLifecycle()
    val showPinDialog by viewModel.showPinDialog.collectAsStateWithLifecycle()
    val monthSummary by viewModel.currentMonthSummary.collectAsStateWithLifecycle()
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()

    // Show Toast for user message
    LaunchedEffect(userMessage) {
        userMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearUserMessage()
        }
    }

    val isTopLevelDestination = bottomNavItems.any { it.route == currentRoute }

    Scaffold(
        topBar = {
            if (isTopLevelDestination) {
                TopAppBar(
                    title = {
                        val currentScreen = bottomNavItems.find { it.route == currentRoute }
                        Text(
                            text = if (currentScreen == Screen.Dashboard) settings.groupName else (currentScreen?.title ?: "Samiti"),
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    },
                    actions = {
                        if (currentRoute == Screen.Reports.route) {
                            // Settings option ONLY visible when Report tab is selected
                            IconButton(
                                onClick = {
                                    viewModel.requestAdminAction {
                                        navController.navigate("settings")
                                    }
                                },
                                modifier = Modifier.testTag("settings_top_bar_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = "Settings",
                                    tint = IndigoPrimary
                                )
                            }
                        } else {
                            // Notification bell in top bar showing pending dues
                            val duesBadgeCount = monthSummary.unpaidCount + monthSummary.partialCount
                            IconButton(
                                onClick = {
                                    navController.navigate(Screen.Dues.route)
                                },
                                modifier = Modifier.testTag("notifications_dues_top_bar_btn")
                            ) {
                                if (duesBadgeCount > 0) {
                                    BadgedBox(
                                        badge = {
                                            Badge(
                                                containerColor = Rose500,
                                                contentColor = Color.White
                                            ) {
                                                Text("$duesBadgeCount", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.NotificationsActive,
                                            contentDescription = "Pending Dues & Notifications",
                                            tint = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Notifications,
                                        contentDescription = "Notifications",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        },
        bottomBar = {
            if (isTopLevelDestination) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 1.dp
                ) {
                    bottomNavItems.forEach { screen ->
                        val selected = currentRoute == screen.route

                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                if (currentRoute != screen.route) {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (selected) screen.selectedIcon else screen.unselectedIcon,
                                    contentDescription = screen.title
                                )
                            },
                            label = {
                                Text(
                                    text = screen.title,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 11.sp
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = IndigoPrimary,
                                selectedTextColor = IndigoPrimary,
                                unselectedIconColor = TextSlate400,
                                unselectedTextColor = TextSlate400,
                                indicatorColor = IndigoPrimary.copy(alpha = 0.12f)
                            ),
                            modifier = Modifier.testTag("nav_item_${screen.route}")
                        )
                    }
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            // 1. Dashboard Screen
            composable(Screen.Dashboard.route) {
                DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToMembers = { navController.navigate(Screen.Members.route) },
                    onNavigateToMonthly = { navController.navigate(Screen.Monthly.route) },
                    onNavigateToDues = { navController.navigate(Screen.Dues.route) },
                    onNavigateToReports = { navController.navigate(Screen.Reports.route) },
                    onNavigateToRecordPayment = { navController.navigate("record_payment/0") },
                    onNavigateToAddMember = { navController.navigate("add_member") },
                    onNavigateToMemberProfile = { id -> navController.navigate("member_profile/$id") }
                )
            }

            // 2. Monthly Management Screen
            composable(Screen.Monthly.route) {
                MonthlyManagementScreen(
                    viewModel = viewModel,
                    onNavigateToMemberProfile = { id -> navController.navigate("member_profile/$id") },
                    onNavigateToRecordPayment = { id -> navController.navigate("record_payment/$id") }
                )
            }

            // 3. Members List Screen
            composable(Screen.Members.route) {
                MembersScreen(
                    viewModel = viewModel,
                    onNavigateToAddMember = { navController.navigate("add_member") },
                    onNavigateToEditMember = { id -> navController.navigate("edit_member/$id") },
                    onNavigateToProfile = { id -> navController.navigate("member_profile/$id") },
                    onNavigateToRecordPayment = { id -> navController.navigate("record_payment/$id") }
                )
            }

            // 4. Chat & Notice Board Screen
            composable(Screen.Chat.route) {
                SocietyChatScreen(
                    viewModel = viewModel,
                    onNavigateToMemberProfile = { id -> navController.navigate("member_profile/$id") }
                )
            }

            // 5. Reports Screen
            composable(Screen.Reports.route) {
                ReportsScreen(
                    viewModel = viewModel,
                    onNavigateToSettings = {
                        viewModel.requestAdminAction {
                            navController.navigate("settings")
                        }
                    }
                )
            }

            // 6. Pending Dues Screen (Accessible from Top Notification Bell and Dashboard)
            composable(Screen.Dues.route) {
                PendingDuesScreen(
                    viewModel = viewModel,
                    onNavigateToRecordPayment = { id -> navController.navigate("record_payment/$id") },
                    onNavigateToMemberProfile = { id -> navController.navigate("member_profile/$id") }
                )
            }

            // 7. Add Member Screen
            composable("add_member") {
                AddEditMemberScreen(
                    memberId = 0L,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // 8. Edit Member Screen
            composable(
                route = "edit_member/{memberId}",
                arguments = listOf(navArgument("memberId") { type = NavType.LongType })
            ) { backStackEntry ->
                val memberId = backStackEntry.arguments?.getLong("memberId") ?: 0L
                AddEditMemberScreen(
                    memberId = memberId,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // 9. Member Profile Screen
            composable(
                route = "member_profile/{memberId}",
                arguments = listOf(navArgument("memberId") { type = NavType.LongType })
            ) { backStackEntry ->
                val memberId = backStackEntry.arguments?.getLong("memberId") ?: 0L
                MemberProfileScreen(
                    memberId = memberId,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToEdit = { id -> navController.navigate("edit_member/$id") },
                    onNavigateToRecordPayment = { id -> navController.navigate("record_payment/$id") }
                )
            }

            // 10. Record Payment Screen
            composable(
                route = "record_payment/{memberId}",
                arguments = listOf(navArgument("memberId") { type = NavType.LongType })
            ) { backStackEntry ->
                val memberId = backStackEntry.arguments?.getLong("memberId") ?: 0L
                RecordPaymentScreen(
                    preselectedMemberId = memberId,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // 11. Settings Screen
            composable("settings") {
                SettingsScreen(
                    viewModel = viewModel,
                    onNavigateToBackup = { navController.navigate("backup_restore") }
                )
            }

            // 12. Backup & Restore Screen
            composable("backup_restore") {
                BackupRestoreScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
    }

    // Admin PIN Security Dialog
    AdminPinDialog(
        isOpen = showPinDialog,
        onDismiss = { viewModel.dismissPinDialog() },
        onVerify = { pin ->
            val verified = viewModel.verifyPin(pin)
            if (verified) {
                navController.navigate("settings")
            }
            verified
        }
    )
}
