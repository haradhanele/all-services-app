package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.NotificationImportant
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.CollectionBarChart
import com.example.ui.components.MemberAvatarView
import com.example.ui.components.MonthPickerBar
import com.example.ui.components.StatMetricCard
import com.example.ui.theme.BorderLight
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CardWhite
import com.example.ui.theme.IndigoHeroDark
import com.example.ui.theme.IndigoHeroGradientEnd
import com.example.ui.theme.IndigoHeroProgress
import com.example.ui.theme.IndigoHeroSubtext
import com.example.ui.theme.IndigoHeroSurface
import com.example.ui.theme.IndigoHeroTrack
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.StatusPaidText
import com.example.ui.theme.StatusPartialText
import com.example.ui.theme.StatusUnpaidText
import com.example.ui.theme.TextSlate400
import com.example.ui.theme.TextSlate500
import com.example.ui.theme.TextSlate800
import com.example.ui.viewmodel.SocietyViewModel
import com.example.utils.CurrencyFormatter
import com.example.utils.DateUtils

@Composable
fun DashboardScreen(
    viewModel: SocietyViewModel,
    onNavigateToMembers: () -> Unit,
    onNavigateToMonthly: () -> Unit,
    onNavigateToDues: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToRecordPayment: () -> Unit,
    onNavigateToAddMember: () -> Unit,
    onNavigateToMemberProfile: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val financials by viewModel.overallFinancials.collectAsStateWithLifecycle()
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()
    val monthSummary by viewModel.currentMonthSummary.collectAsStateWithLifecycle()
    val recentTxns by viewModel.recentTransactions.collectAsStateWithLifecycle()
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("dashboard_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Group Society Header Banner (Midnight Indigo Gradient)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dashboard_header_card"),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.Transparent
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    Color(0xFF1E1B4B),
                                    Color(0xFF312E81),
                                    Color(0xFF3730A3)
                                )
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = settings.groupName,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 20.sp
                                )
                                if (settings.groupSubtitle.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = settings.groupSubtitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = IndigoHeroSubtext,
                                        fontSize = 12.sp
                                    )
                                }
                            }

                            // Admin status pill
                            Surface(
                                shape = CircleShape,
                                color = Color.White.copy(alpha = 0.15f),
                                modifier = Modifier.padding(start = 8.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isAdminUnlocked) Icons.Default.LockOpen else Icons.Default.Lock,
                                        contentDescription = "Admin Security",
                                        tint = Color.White,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isAdminUnlocked) "Admin Active" else "Protected",
                                        color = Color.White,
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // All-Time Collection & Due Summary inside banner
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "TOTAL FUNDS COLLECTED",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = IndigoHeroSubtext,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = CurrencyFormatter.format(financials.totalCollectedAllTime, settings.currencySymbol),
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 22.sp
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "PENDING DUES",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = IndigoHeroSubtext,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = CurrencyFormatter.format(financials.totalDueAllTime, settings.currencySymbol),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFFECDD3),
                                    fontSize = 18.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Month Selector Bar
        item {
            MonthPickerBar(
                selectedMonth = selectedMonth,
                selectedYear = selectedYear,
                onPrevClick = { viewModel.prevMonth() },
                onNextClick = { viewModel.nextMonth() },
                onMonthYearSelected = { m, y -> viewModel.selectMonthYear(m, y) }
            )
        }

        // 3. Current Month Summary Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderLight, RoundedCornerShape(16.dp))
                    .testTag("current_month_summary_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = CardWhite
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${DateUtils.getMonthName(selectedMonth)} $selectedYear Overview",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextSlate800
                        )
                        TextButton(
                            onClick = onNavigateToMonthly,
                            modifier = Modifier.testTag("view_month_details_btn")
                        ) {
                            Text("Manage Month", color = IndigoPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(3.dp))
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(15.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Progress bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Target Progress (${monthSummary.collectionPercentage.toInt()}%)",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSlate500,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "${CurrencyFormatter.format(monthSummary.totalCollected, settings.currencySymbol)} / ${CurrencyFormatter.format(monthSummary.totalExpected, settings.currencySymbol)}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = TextSlate800,
                            fontSize = 12.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { (monthSummary.collectionPercentage / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(7.dp)
                            .clip(CircleShape),
                        color = IndigoPrimary,
                        trackColor = Color(0xFFEEF2FF)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Paid vs Pending count row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(StatusPaidText)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${monthSummary.paidCount} Paid",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = TextSlate800,
                                fontSize = 13.sp
                            )
                        }

                        if (monthSummary.partialCount > 0) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(StatusPartialText)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "${monthSummary.partialCount} Partial",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = StatusPartialText,
                                    fontSize = 13.sp
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(StatusUnpaidText)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${monthSummary.unpaidCount} Pending",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = StatusUnpaidText,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }

        // 4. Two-Column Metric Cards Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatMetricCard(
                    title = "Total Members",
                    value = "${financials.activeMembers}",
                    subtitle = "Active in Society",
                    icon = Icons.Default.Group,
                    accentColor = IndigoPrimary,
                    modifier = Modifier.weight(1f),
                    testTag = "total_members_stat_card"
                )
                StatMetricCard(
                    title = "Pending Dues",
                    value = CurrencyFormatter.format(monthSummary.totalDue, settings.currencySymbol),
                    subtitle = "${monthSummary.unpaidCount + monthSummary.partialCount} unpaid",
                    icon = Icons.Default.NotificationImportant,
                    accentColor = Color(0xFFE11D48),
                    modifier = Modifier.weight(1f),
                    testTag = "pending_dues_stat_card"
                )
            }
        }

        // 5. Quick Actions Row
        item {
            Text(
                text = "Quick Actions",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextSlate800
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickActionButton(
                    title = "Record Pay",
                    icon = Icons.Default.Payments,
                    backgroundColor = IndigoPrimary,
                    textColor = Color.White,
                    onClick = onNavigateToRecordPayment,
                    modifier = Modifier.weight(1f),
                    testTag = "quick_record_pay_btn"
                )
                QuickActionButton(
                    title = "Add Member",
                    icon = Icons.Default.Add,
                    backgroundColor = CardWhite,
                    textColor = TextSlate800,
                    borderColor = BorderLight,
                    onClick = onNavigateToAddMember,
                    modifier = Modifier.weight(1f),
                    testTag = "quick_add_member_btn"
                )
                QuickActionButton(
                    title = "Reminders",
                    icon = Icons.Default.NotificationImportant,
                    backgroundColor = CardWhite,
                    textColor = TextSlate800,
                    borderColor = BorderLight,
                    onClick = onNavigateToDues,
                    modifier = Modifier.weight(1f),
                    testTag = "quick_reminders_btn"
                )
                QuickActionButton(
                    title = "Reports",
                    icon = Icons.Default.ReceiptLong,
                    backgroundColor = CardWhite,
                    textColor = TextSlate800,
                    borderColor = BorderLight,
                    onClick = onNavigateToReports,
                    modifier = Modifier.weight(1f),
                    testTag = "quick_reports_btn"
                )
            }
        }

        // 6. Collection Trend Canvas Bar Chart
        item {
            CollectionBarChart(
                trends = financials.monthlyTrends,
                currencySymbol = settings.currencySymbol
            )
        }

        // 7. Recent Transactions List
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Transactions",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextSlate800
                )
                TextButton(onClick = onNavigateToReports) {
                    Text("View All", color = IndigoPrimary, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (recentTxns.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No payments recorded yet",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSlate500
                    )
                }
            }
        } else {
            items(recentTxns) { txn ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, BorderLight, RoundedCornerShape(14.dp))
                        .testTag("recent_txn_item_${txn.paymentId}"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = CardWhite
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp),
                    onClick = { onNavigateToMemberProfile(txn.memberId) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            MemberAvatarView(name = txn.memberName, size = 40.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = txn.memberName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextSlate800
                                )
                                Text(
                                    text = "${DateUtils.getMonthShortName(txn.month)} ${txn.year} • ${txn.paymentMethod}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSlate500
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "+${CurrencyFormatter.format(txn.amount, settings.currencySymbol)}",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                color = StatusPaidText
                            )
                            Text(
                                text = DateUtils.formatDisplayDate(txn.paymentDate),
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSlate400,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuickActionButton(
    title: String,
    icon: ImageVector,
    backgroundColor: Color,
    textColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    borderColor: Color? = null,
    testTag: String = "quick_action_btn"
) {
    Card(
        modifier = modifier
            .then(
                if (borderColor != null) Modifier.border(1.dp, borderColor, RoundedCornerShape(12.dp))
                else Modifier
            )
            .testTag(testTag),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = textColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = textColor,
                fontWeight = FontWeight.SemiBold,
                fontSize = 11.sp
            )
        }
    }
}

