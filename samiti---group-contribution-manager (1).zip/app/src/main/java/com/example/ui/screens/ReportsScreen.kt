package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NotificationImportant
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.MonthPickerBar
import com.example.ui.components.StatMetricCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.BorderLight
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CardWhite
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.StatusPaidText
import com.example.ui.theme.StatusUnpaidText
import com.example.ui.theme.TextSlate400
import com.example.ui.theme.TextSlate500
import com.example.ui.theme.TextSlate800
import com.example.ui.viewmodel.SocietyViewModel
import com.example.utils.CurrencyFormatter
import com.example.utils.DateUtils

@Composable
fun ReportsScreen(
    viewModel: SocietyViewModel,
    onNavigateToSettings: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()
    val summary by viewModel.currentMonthSummary.collectAsStateWithLifecycle()
    val membersList by viewModel.monthlyMembersList.collectAsStateWithLifecycle()
    val financials by viewModel.overallFinancials.collectAsStateWithLifecycle()
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()

    var selectedReportType by remember { mutableStateOf("MONTHLY") } // "MONTHLY", "PENDING", "OVERALL"

    Scaffold(
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .testTag("reports_screen"),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
        ) {
            // Report Type Selector Tabs
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "MONTHLY" to "Monthly Collection",
                        "PENDING" to "Pending Dues",
                        "OVERALL" to "Overall Society Summary"
                    ).forEach { (type, label) ->
                        val isSelected = selectedReportType == type
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedReportType = type },
                            label = { Text(label, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = IndigoPrimary,
                                selectedLabelColor = Color.White,
                                containerColor = CardWhite,
                                labelColor = TextSlate500
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) IndigoPrimary else BorderSubtle
                            ),
                            modifier = Modifier.testTag("report_tab_$type")
                        )
                    }
                }
            }

            // Month Picker Bar (if monthly or pending)
            if (selectedReportType != "OVERALL") {
                item {
                    MonthPickerBar(
                        selectedMonth = selectedMonth,
                        selectedYear = selectedYear,
                        onPrevClick = { viewModel.prevMonth() },
                        onNextClick = { viewModel.nextMonth() },
                        onMonthYearSelected = { m, y -> viewModel.selectMonthYear(m, y) }
                    )
                }
            }

            // Report Header Card with Export Actions
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, BorderLight, RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CardWhite),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = when (selectedReportType) {
                                        "MONTHLY" -> "Monthly Report (${DateUtils.getMonthName(selectedMonth)} $selectedYear)"
                                        "PENDING" -> "Pending Dues (${DateUtils.getMonthName(selectedMonth)} $selectedYear)"
                                        else -> "Society Financial Statement"
                                    },
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextSlate800
                                )
                                Text(
                                    text = "${settings.groupName} • Generated Live",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSlate500
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Export Buttons Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    when (selectedReportType) {
                                        "MONTHLY" -> viewModel.exportMonthlyReportPdf(context)
                                        "PENDING" -> viewModel.exportPendingDuesPdf(context)
                                        else -> viewModel.exportMonthlyReportPdf(context)
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("export_pdf_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                            ) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(17.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Export PDF", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                            }

                            OutlinedButton(
                                onClick = {
                                    when (selectedReportType) {
                                        "MONTHLY" -> viewModel.exportMonthlyReportCsv(context)
                                        "PENDING" -> viewModel.exportPendingDuesCsv(context)
                                        else -> viewModel.exportMonthlyReportCsv(context)
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("export_csv_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = TextSlate800
                                )
                            ) {
                                Icon(Icons.Default.TableChart, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(17.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Export CSV", fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
                            }
                        }
                    }
                }
            }

            // Summary Breakdown
            item {
                when (selectedReportType) {
                    "MONTHLY" -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            StatMetricCard(
                                title = "Total Expected",
                                value = CurrencyFormatter.format(summary.totalExpected, settings.currencySymbol),
                                icon = Icons.Default.ReceiptLong,
                                accentColor = IndigoPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            StatMetricCard(
                                title = "Collected",
                                value = CurrencyFormatter.format(summary.totalCollected, settings.currencySymbol),
                                subtitle = "${summary.collectionPercentage.toInt()}% collected",
                                icon = Icons.Default.CheckCircle,
                                accentColor = StatusPaidText,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    "PENDING" -> {
                        val pendingItems = membersList.filter { it.status != "PAID" }
                        val totalPending = pendingItems.sumOf { it.dueAmount }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            StatMetricCard(
                                title = "Pending Members",
                                value = "${pendingItems.size}",
                                icon = Icons.Default.NotificationImportant,
                                accentColor = StatusUnpaidText,
                                modifier = Modifier.weight(1f)
                            )
                            StatMetricCard(
                                title = "Total Outstanding",
                                value = CurrencyFormatter.format(totalPending, settings.currencySymbol),
                                icon = Icons.Default.ReceiptLong,
                                accentColor = StatusUnpaidText,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    "OVERALL" -> {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                StatMetricCard(
                                    title = "Total Active Members",
                                    value = "${financials.activeMembers}",
                                    icon = Icons.Default.Assessment,
                                    accentColor = IndigoPrimary,
                                    modifier = Modifier.weight(1f)
                                )
                                StatMetricCard(
                                    title = "All-Time Collected",
                                    value = CurrencyFormatter.format(financials.totalCollectedAllTime, settings.currencySymbol),
                                    icon = Icons.Default.CheckCircle,
                                    accentColor = StatusPaidText,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            // Table Preview Header
            item {
                Text(
                    text = "Report Records Preview",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextSlate800
                )
            }

            // Items List
            val displayList = when (selectedReportType) {
                "PENDING" -> membersList.filter { it.status != "PAID" }
                else -> membersList
            }

            if (displayList.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No records found", style = MaterialTheme.typography.bodyMedium, color = TextSlate500)
                    }
                }
            } else {
                items(displayList) { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, BorderLight, RoundedCornerShape(10.dp)),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = CardWhite),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.member.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = TextSlate800)
                                Text(
                                    "${item.member.memberCode} • Exp: ${CurrencyFormatter.format(item.effectiveExpectedAmount, settings.currencySymbol)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSlate500
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "Paid: ${CurrencyFormatter.format(item.paidAmount, settings.currencySymbol)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (item.paidAmount > 0) StatusPaidText else TextSlate800
                                )
                                if (item.dueAmount > 0) {
                                    Text(
                                        text = "Due: ${CurrencyFormatter.format(item.dueAmount, settings.currencySymbol)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = StatusUnpaidText
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))
                            StatusBadge(status = item.status, compact = true)
                        }
                    }
                }
            }

            // Society Settings & Administration Card
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reports_settings_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = IndigoPrimary.copy(alpha = 0.12f),
                                modifier = Modifier.size(42.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Settings,
                                        contentDescription = "Settings",
                                        tint = IndigoPrimary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Committee Settings",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Theme mode, backup & admin PIN",
                                    fontSize = 12.sp,
                                    color = TextSlate500
                                )
                            }
                        }

                        Button(
                            onClick = onNavigateToSettings,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text("Open", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

