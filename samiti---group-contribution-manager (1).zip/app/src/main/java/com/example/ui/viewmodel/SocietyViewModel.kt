package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.GroupSettings
import com.example.data.model.Member
import com.example.data.model.MemberFinancialProfile
import com.example.data.model.MemberWithMonthlyStatus
import com.example.data.model.MonthlySummary
import com.example.data.model.OverallGroupFinancials
import com.example.data.model.Payment
import com.example.data.model.RecentTransaction
import com.example.data.model.SocietyNotice
import com.example.data.repository.SocietyRepository
import com.example.utils.CurrencyFormatter
import com.example.utils.DateUtils
import com.example.utils.ReminderHelper
import com.example.utils.ReportExporter
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.util.Calendar

class SocietyViewModel(
    application: Application,
    private val repository: SocietyRepository
) : AndroidViewModel(application) {

    // Current selected month & year for Monthly view & reports
    private val calendar = Calendar.getInstance()
    private val _selectedMonth = MutableStateFlow(calendar.get(Calendar.MONTH) + 1)
    val selectedMonth: StateFlow<Int> = _selectedMonth.asStateFlow()

    private val _selectedYear = MutableStateFlow(calendar.get(Calendar.YEAR))
    val selectedYear: StateFlow<Int> = _selectedYear.asStateFlow()

    // Member search and status filter
    private val _memberSearchQuery = MutableStateFlow("")
    val memberSearchQuery: StateFlow<String> = _memberSearchQuery.asStateFlow()

    private val _statusFilter = MutableStateFlow("ALL") // "ALL", "PAID", "PARTIAL", "UNPAID"
    val statusFilter: StateFlow<String> = _statusFilter.asStateFlow()

    // Admin authentication state
    private val _isAdminUnlocked = MutableStateFlow(false)
    val isAdminUnlocked: StateFlow<Boolean> = _isAdminUnlocked.asStateFlow()

    private val _showPinDialog = MutableStateFlow(false)
    val showPinDialog: StateFlow<Boolean> = _showPinDialog.asStateFlow()

    // Selected member for profile inspection
    private val _selectedMemberId = MutableStateFlow<Long?>(null)
    val selectedMemberId: StateFlow<Long?> = _selectedMemberId.asStateFlow()

    // Toast message trigger
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    // Group Settings flow
    val groupSettings: StateFlow<GroupSettings> = repository.groupSettings
        .flatMapLatest { settings ->
            MutableStateFlow(settings ?: GroupSettings())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = GroupSettings()
        )

    init {
        viewModelScope.launch {
            repository.groupSettings.collect { settings ->
                if (settings != null && (settings.groupName == "Pragati Welfare Samiti" || settings.groupName == "Samiti Welfare Fund" || settings.groupName.isBlank())) {
                    repository.updateSettings(settings.copy(groupName = "All services group"))
                }
            }
        }
    }

    // Overall Group Financials
    val overallFinancials: StateFlow<OverallGroupFinancials> = repository.getOverallFinancials()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = OverallGroupFinancials(
                totalMembers = 0,
                activeMembers = 0,
                totalCollectedAllTime = 0.0,
                totalDueAllTime = 0.0,
                currentMonthCollected = 0.0,
                currentMonthDue = 0.0,
                currentMonthPaidCount = 0,
                currentMonthUnpaidCount = 0,
                currentMonthPartialCount = 0,
                previousMonthCollected = 0.0,
                monthlyTrends = emptyList()
            )
        )

    // Monthly summary for currently selected month
    @OptIn(ExperimentalCoroutinesApi::class)
    val currentMonthSummary: StateFlow<MonthlySummary> = combine(
        _selectedMonth,
        _selectedYear
    ) { month, year -> Pair(month, year) }
        .flatMapLatest { (m, y) ->
            repository.getMonthlySummary(m, y)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = MonthlySummary(
                month = calendar.get(Calendar.MONTH) + 1,
                year = calendar.get(Calendar.YEAR),
                monthName = DateUtils.getMonthName(calendar.get(Calendar.MONTH) + 1),
                totalMembers = 0,
                totalExpected = 0.0,
                totalCollected = 0.0,
                totalDue = 0.0,
                paidCount = 0,
                partialCount = 0,
                unpaidCount = 0,
                collectionPercentage = 0f
            )
        )

    // Monthly members status with search and status filtering
    @OptIn(ExperimentalCoroutinesApi::class)
    val monthlyMembersList: StateFlow<List<MemberWithMonthlyStatus>> = combine(
        _selectedMonth,
        _selectedYear,
        _memberSearchQuery,
        _statusFilter
    ) { m, y, query, status ->
        Quadruple(m, y, query, status)
    }.flatMapLatest { (m, y, query, status) ->
        repository.getMonthlyMembersStatus(m, y).combine(MutableStateFlow(Pair(query, status))) { list, (q, s) ->
            list.filter { item ->
                val matchesQuery = q.isBlank() ||
                        item.member.name.contains(q, ignoreCase = true) ||
                        item.member.memberCode.contains(q, ignoreCase = true) ||
                        item.member.phone.contains(q, ignoreCase = true)

                val matchesStatus = when (s) {
                    "PAID" -> item.status == "PAID"
                    "PARTIAL" -> item.status == "PARTIAL"
                    "UNPAID" -> item.status == "UNPAID"
                    else -> true
                }
                matchesQuery && matchesStatus
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // All active members list
    val allActiveMembers: StateFlow<List<Member>> = repository.activeMembers
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allMembers: StateFlow<List<Member>> = repository.allMembers
        .combine(_memberSearchQuery) { members, query ->
            if (query.isBlank()) {
                members
            } else {
                members.filter {
                    it.name.contains(query, ignoreCase = true) ||
                            it.memberCode.contains(query, ignoreCase = true) ||
                            it.phone.contains(query, ignoreCase = true)
                }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Recent transactions
    val recentTransactions: StateFlow<List<RecentTransaction>> = repository.getRecentTransactions(15)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Selected member financial profile
    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedMemberProfile: StateFlow<MemberFinancialProfile?> = _selectedMemberId
        .flatMapLatest { id ->
            if (id != null) {
                repository.getMemberFinancialProfile(id)
            } else {
                MutableStateFlow(null)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    // Society Notices / Announcements for Chat & Community tab
    val notices: StateFlow<List<SocietyNotice>> = repository.allNotices
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun postNotice(
        title: String,
        content: String,
        category: String = "ANNOUNCEMENT",
        author: String = "Admin",
        isPinned: Boolean = false
    ) {
        viewModelScope.launch {
            if (title.isBlank() || content.isBlank()) {
                _userMessage.value = "Please enter both title and notice content"
                return@launch
            }
            val notice = SocietyNotice(
                title = title.trim(),
                content = content.trim(),
                category = category,
                author = author.ifBlank { "Admin" },
                timestamp = System.currentTimeMillis(),
                isPinned = isPinned
            )
            repository.addNotice(notice)
            _userMessage.value = "Notice published successfully"
        }
    }

    fun deleteNotice(notice: SocietyNotice) {
        viewModelScope.launch {
            repository.deleteNotice(notice)
            _userMessage.value = "Notice deleted"
        }
    }

    fun togglePinNotice(notice: SocietyNotice) {
        viewModelScope.launch {
            repository.updateNotice(notice.copy(isPinned = !notice.isPinned))
            _userMessage.value = if (!notice.isPinned) "Notice pinned to top" else "Notice unpinned"
        }
    }

    fun broadcastNotice(context: Context, notice: SocietyNotice) {
        val settings = groupSettings.value
        val text = ReminderHelper.generateNoticeBroadcastText(
            groupName = settings.groupName,
            title = notice.title,
            content = notice.content,
            author = notice.author,
            adminPhone = settings.adminPhone
        )
        ReminderHelper.shareText(context, text, "Broadcast Notice to Society")
    }

    fun sendCustomMemberMessage(context: Context, member: Member, message: String) {
        if (message.isBlank()) return
        ReminderHelper.sendWhatsAppReminder(context, member.phone, message)
    }

    fun selectMonthYear(month: Int, year: Int) {
        _selectedMonth.value = month
        _selectedYear.value = year
    }

    fun nextMonth() {
        if (_selectedMonth.value == 12) {
            _selectedMonth.value = 1
            _selectedYear.value += 1
        } else {
            _selectedMonth.value += 1
        }
    }

    fun prevMonth() {
        if (_selectedMonth.value == 1) {
            _selectedMonth.value = 12
            _selectedYear.value -= 1
        } else {
            _selectedMonth.value -= 1
        }
    }

    fun setSearchQuery(query: String) {
        _memberSearchQuery.value = query
    }

    fun setStatusFilter(filter: String) {
        _statusFilter.value = filter
    }

    fun selectMember(memberId: Long?) {
        _selectedMemberId.value = memberId
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    // Admin Auth
    fun requestAdminAction(onSuccess: () -> Unit) {
        val settings = groupSettings.value
        if (!settings.isPinLockEnabled || _isAdminUnlocked.value) {
            onSuccess()
        } else {
            _showPinDialog.value = true
        }
    }

    fun verifyPin(pin: String): Boolean {
        val settings = groupSettings.value
        if (pin == settings.adminPin || (!settings.isPinLockEnabled)) {
            _isAdminUnlocked.value = true
            _showPinDialog.value = false
            return true
        }
        return false
    }

    fun lockAdmin() {
        _isAdminUnlocked.value = false
    }

    fun dismissPinDialog() {
        _showPinDialog.value = false
    }

    // Member Operations
    fun saveMember(member: Member, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            if (member.id == 0L) {
                // Auto generate member code if empty
                val code = if (member.memberCode.isBlank()) {
                    "SAM-" + (100 + (allMembers.value.size + 1))
                } else member.memberCode
                repository.addMember(member.copy(memberCode = code))
                _userMessage.value = "Member '${member.name}' added successfully"
            } else {
                repository.updateMember(member)
                _userMessage.value = "Member '${member.name}' updated"
            }
            onComplete()
        }
    }

    fun deleteMember(member: Member, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteMember(member)
            if (_selectedMemberId.value == member.id) {
                _selectedMemberId.value = null
            }
            _userMessage.value = "Member '${member.name}' and payment records deleted"
            onComplete()
        }
    }

    // Payment Operations
    fun recordPayment(
        memberId: Long,
        month: Int,
        year: Int,
        expectedAmount: Double,
        paidAmount: Double,
        paymentMethod: String,
        transactionRef: String,
        notes: String,
        paymentDate: Long = System.currentTimeMillis(),
        onComplete: () -> Unit = {}
    ) {
        viewModelScope.launch {
            val payment = Payment(
                memberId = memberId,
                month = month,
                year = year,
                expectedAmount = expectedAmount,
                paidAmount = paidAmount,
                dueAmount = (expectedAmount - paidAmount).coerceAtLeast(0.0),
                paymentDate = paymentDate,
                paymentMethod = paymentMethod,
                transactionReference = transactionRef,
                notes = notes,
                status = Payment.calculateStatus(expectedAmount, paidAmount)
            )
            repository.recordPayment(payment)
            _userMessage.value = "Payment of ${CurrencyFormatter.format(paidAmount, groupSettings.value.currencySymbol)} recorded successfully"
            onComplete()
        }
    }

    fun quickMarkPaid(
        memberId: Long,
        month: Int = _selectedMonth.value,
        year: Int = _selectedYear.value,
        amount: Double,
        method: String = "Cash",
        ref: String = "",
        notes: String = "Quick marked paid"
    ) {
        viewModelScope.launch {
            repository.quickMarkPaid(
                memberId = memberId,
                month = month,
                year = year,
                amount = amount,
                paymentMethod = method,
                reference = ref,
                notes = notes
            )
            _userMessage.value = "Payment recorded successfully"
        }
    }

    fun deletePayment(paymentId: Long) {
        viewModelScope.launch {
            repository.deletePayment(paymentId)
            _userMessage.value = "Payment record removed"
        }
    }

    // Settings
    fun updateGroupSettings(settings: GroupSettings, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.updateSettings(settings)
            _userMessage.value = "Group settings saved"
            onComplete()
        }
    }

    // Reminders
    fun sendReminder(context: Context, member: Member, dueAmount: Double, type: String = "WHATSAPP") {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(_selectedMonth.value)
        val text = ReminderHelper.generateReminderText(
            member = member,
            groupName = settings.groupName,
            monthName = monthName,
            year = _selectedYear.value,
            dueAmount = dueAmount,
            currencySymbol = settings.currencySymbol,
            adminName = settings.adminName,
            adminPhone = settings.adminPhone
        )

        when (type) {
            "WHATSAPP" -> ReminderHelper.sendWhatsAppReminder(context, member.phone, text)
            "SMS" -> ReminderHelper.sendSmsReminder(context, member.phone, text)
            else -> ReminderHelper.shareText(context, text, "Send Contribution Reminder")
        }
    }

    // Reports & Exports
    fun exportMonthlyReportPdf(context: Context) {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(_selectedMonth.value)
        val year = _selectedYear.value
        val summary = currentMonthSummary.value
        val list = monthlyMembersList.value

        val headers = listOf("Code", "Member Name", "Expected", "Paid", "Due", "Status", "Date")
        val rows = list.map { item ->
            val pDate = if (item.payment != null && item.payment.paymentDate > 0)
                DateUtils.formatDisplayDate(item.payment.paymentDate)
            else "-"
            listOf(
                item.member.memberCode,
                item.member.name,
                CurrencyFormatter.format(item.effectiveExpectedAmount, settings.currencySymbol),
                CurrencyFormatter.format(item.paidAmount, settings.currencySymbol),
                CurrencyFormatter.format(item.dueAmount, settings.currencySymbol),
                item.status,
                pDate
            )
        }

        val summaryMap = mapOf(
            "Total Members" to "${summary.totalMembers}",
            "Collected" to CurrencyFormatter.format(summary.totalCollected, settings.currencySymbol),
            "Pending Dues" to CurrencyFormatter.format(summary.totalDue, settings.currencySymbol),
            "Paid Rate" to "${summary.collectionPercentage.toInt()}%"
        )

        val file = ReportExporter.generatePdfReport(
            context = context,
            settings = settings,
            reportTitle = "Monthly Collection Report",
            subtitle = "$monthName $year",
            headers = headers,
            rows = rows,
            summaryMap = summaryMap
        )

        if (file != null) {
            ReportExporter.shareFile(context, file, "application/pdf", "Share Monthly PDF Report")
        } else {
            Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportMonthlyReportCsv(context: Context) {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(_selectedMonth.value)
        val year = _selectedYear.value
        val list = monthlyMembersList.value

        val file = ReportExporter.exportMonthlyCsv(context, settings, monthName, year, list)
        if (file != null) {
            ReportExporter.shareFile(context, file, "text/csv", "Share Monthly CSV Report")
        } else {
            Toast.makeText(context, "Failed to export CSV", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportPendingDuesPdf(context: Context) {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(_selectedMonth.value)
        val year = _selectedYear.value
        val pendingList = monthlyMembersList.value.filter { it.status != "PAID" }

        val totalDue = pendingList.sumOf { it.dueAmount }
        val headers = listOf("Code", "Member Name", "Phone", "Expected", "Paid", "Due", "Status")
        val rows = pendingList.map { item ->
            listOf(
                item.member.memberCode,
                item.member.name,
                item.member.phone,
                CurrencyFormatter.format(item.effectiveExpectedAmount, settings.currencySymbol),
                CurrencyFormatter.format(item.paidAmount, settings.currencySymbol),
                CurrencyFormatter.format(item.dueAmount, settings.currencySymbol),
                item.status
            )
        }

        val summaryMap = mapOf(
            "Pending Members" to "${pendingList.size}",
            "Total Pending" to CurrencyFormatter.format(totalDue, settings.currencySymbol),
            "Period" to "$monthName $year"
        )

        val file = ReportExporter.generatePdfReport(
            context = context,
            settings = settings,
            reportTitle = "Pending Dues Report",
            subtitle = "$monthName $year",
            headers = headers,
            rows = rows,
            summaryMap = summaryMap
        )

        if (file != null) {
            ReportExporter.shareFile(context, file, "application/pdf", "Share Pending Dues PDF")
        } else {
            Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportPendingDuesCsv(context: Context) {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(_selectedMonth.value)
        val year = _selectedYear.value
        val pendingList = monthlyMembersList.value.filter { it.status != "PAID" }

        val file = ReportExporter.exportPendingDuesCsv(context, settings, monthName, year, pendingList)
        if (file != null) {
            ReportExporter.shareFile(context, file, "text/csv", "Share Pending Dues CSV")
        } else {
            Toast.makeText(context, "Failed to export CSV", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportMemberLedgerPdf(context: Context, profile: MemberFinancialProfile) {
        val settings = groupSettings.value
        val headers = listOf("Month/Year", "Expected", "Paid", "Due", "Status", "Date", "Method")
        val rows = profile.paymentHistory.map { item ->
            val pDate = if (item.paymentDate != null && item.paymentDate > 0)
                DateUtils.formatDisplayDate(item.paymentDate)
            else "-"
            listOf(
                "${item.monthName.take(3)} '${item.year.toString().takeLast(2)}",
                CurrencyFormatter.format(item.expectedAmount, settings.currencySymbol),
                CurrencyFormatter.format(item.paidAmount, settings.currencySymbol),
                CurrencyFormatter.format(item.dueAmount, settings.currencySymbol),
                item.status,
                pDate,
                item.paymentMethod ?: "-"
            )
        }

        val summaryMap = mapOf(
            "Member" to profile.member.name,
            "Total Paid" to CurrencyFormatter.format(profile.totalPaidAllTime, settings.currencySymbol),
            "Total Due" to CurrencyFormatter.format(profile.totalDueAllTime, settings.currencySymbol)
        )

        val file = ReportExporter.generatePdfReport(
            context = context,
            settings = settings,
            reportTitle = "Member Account Ledger",
            subtitle = "${profile.member.name} (${profile.member.memberCode})",
            headers = headers,
            rows = rows,
            summaryMap = summaryMap
        )

        if (file != null) {
            ReportExporter.shareFile(context, file, "application/pdf", "Share Member Ledger PDF")
        }
    }

    // Backup and Restore
    fun exportBackupJson(context: Context) {
        viewModelScope.launch {
            try {
                val json = repository.exportAllDataJson()
                val fileName = "Samiti_Backup_${System.currentTimeMillis()}.json"
                val file = File(context.cacheDir, fileName)
                file.writeText(json)
                ReportExporter.shareFile(context, file, "application/json", "Export Database Backup")
            } catch (e: Exception) {
                Toast.makeText(context, "Backup failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun restoreBackupJson(jsonString: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val success = repository.restoreAllDataJson(jsonString)
            if (success) {
                _userMessage.value = "Data successfully restored"
            } else {
                _userMessage.value = "Failed to restore: Invalid backup file format"
            }
            onResult(success)
        }
    }

    fun resetToDemoData() {
        viewModelScope.launch {
            repository.resetSampleData()
            _userMessage.value = "Sample committee data reloaded"
        }
    }

    companion object {
        fun provideFactory(application: Application): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    val db = AppDatabase.getDatabase(application)
                    val repo = SocietyRepository(
                        database = db,
                        memberDao = db.memberDao(),
                        paymentDao = db.paymentDao(),
                        groupSettingsDao = db.groupSettingsDao()
                    )
                    return SocietyViewModel(application, repo) as T
                }
            }
    }
}

data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
