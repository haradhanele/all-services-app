package com.adr.groupledger.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.adr.groupledger.data.model.carousel.CarouselContentType
import com.adr.groupledger.data.model.carousel.CarouselItem
import com.adr.groupledger.data.model.carousel.GLOBAL_GROUP_ID
import com.adr.groupledger.data.model.carousel.MediaResource
import com.adr.groupledger.data.model.carousel.MediaType
import com.adr.groupledger.data.repository.carousel.CarouselRepository
import com.adr.groupledger.data.repository.carousel.FirestoreCarouselRepository
import com.adr.groupledger.data.repository.carousel.InMemoryCarouselRepository
import com.adr.groupledger.service.storage.LogicalStoragePath
import com.adr.groupledger.service.storage.MediaFileValidator
import com.adr.groupledger.service.storage.MediaStorageService
import com.adr.groupledger.service.storage.MediaValidationResult
import com.adr.groupledger.service.storage.StorageResult
import com.adr.groupledger.service.storage.StorageServiceProvider
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

/**
 * State of media file selection and Cloudinary upload process.
 */
sealed class MediaUploadState {
    object Idle : MediaUploadState()

    data class FileSelected(
        val file: File,
        val mediaType: MediaType,
        val mimeType: String,
        val sizeBytes: Long,
        val originalName: String
    ) : MediaUploadState()

    data class Uploading(
        val percentage: Float, // 0.0f to 1.0f
        val fileName: String
    ) : MediaUploadState()

    data class Success(
        val mediaResource: MediaResource
    ) : MediaUploadState()

    data class Error(
        val userMessage: String,
        val canRetry: Boolean = true,
        val isSignaturePrerequisite: Boolean = false
    ) : MediaUploadState()
}

/**
 * ViewModel for the Application-Level Carousel Content Management system.
 * Manages global slides, promotions, festival announcements, media upload, and scheduling.
 */
class CarouselContentViewModel(
    private val carouselRepository: CarouselRepository = FirestoreCarouselRepository.getInstance(),
    private val mediaStorageService: MediaStorageService = StorageServiceProvider.getMediaStorageService()
) : ViewModel() {

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Media Upload State
    private val _mediaUploadState = MutableStateFlow<MediaUploadState>(MediaUploadState.Idle)
    val mediaUploadState: StateFlow<MediaUploadState> = _mediaUploadState.asStateFlow()

    private var uploadJob: Job? = null

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedTypeFilter = MutableStateFlow<CarouselContentType?>(null)
    val selectedTypeFilter: StateFlow<CarouselContentType?> = _selectedTypeFilter.asStateFlow()

    // Status filter: "ALL", "ACTIVE", "INACTIVE"
    private val _selectedStatusFilter = MutableStateFlow("ALL")
    val selectedStatusFilter: StateFlow<String> = _selectedStatusFilter.asStateFlow()

    // Base items stream for global carousel items (groupId = 0L)
    val allItems: StateFlow<List<CarouselItem>> = carouselRepository.getAllCarouselItems(GLOBAL_GROUP_ID)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = emptyList()
        )

    // Active, scheduled carousel items stream for consumer UI (Home Screen / Dashboard)
    val activeItems: StateFlow<List<CarouselItem>> = carouselRepository.getActiveCarouselItems(GLOBAL_GROUP_ID)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = emptyList()
        )

    // Filtered items combining search query, content type, and status
    val filteredItems: StateFlow<List<CarouselItem>> = combine(
        allItems,
        _searchQuery,
        _selectedTypeFilter,
        _selectedStatusFilter
    ) { items, query, typeFilter, statusFilter ->
        items.filter { item ->
            val matchesQuery = query.isBlank() ||
                item.title.contains(query, ignoreCase = true) ||
                item.message.contains(query, ignoreCase = true)

            val matchesType = typeFilter == null || item.contentType == typeFilter

            val matchesStatus = when (statusFilter) {
                "ACTIVE" -> item.isActive
                "INACTIVE" -> !item.isActive
                else -> true
            }

            matchesQuery && matchesType && matchesStatus
        }.sortedByDescending { it.priority }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = emptyList()
    )

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setTypeFilter(type: CarouselContentType?) {
        _selectedTypeFilter.value = type
    }

    fun setStatusFilter(status: String) {
        _selectedStatusFilter.value = status
    }

    fun toggleItemActive(item: CarouselItem) {
        viewModelScope.launch {
            val newStatus = !item.isActive
            val result = carouselRepository.setItemActiveStatus(item.id, newStatus)
            if (result.isSuccess) {
                _userMessage.value = if (newStatus) "Slide activated" else "Slide deactivated"
            } else {
                _errorMessage.value = result.exceptionOrNull()?.message ?: "Failed to update status"
            }
        }
    }

    fun deleteItem(itemId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            val result = carouselRepository.deleteCarouselItem(itemId)
            _isLoading.value = false
            if (result.isSuccess) {
                _userMessage.value = "Carousel slide deleted successfully"
            } else {
                _errorMessage.value = result.exceptionOrNull()?.message ?: "Failed to delete slide"
            }
        }
    }

    fun saveItem(item: CarouselItem, onComplete: (Boolean, String?) -> Unit) {
        if (item.title.isBlank()) {
            onComplete(false, "Title is required")
            return
        }
        if (item.message.isBlank()) {
            onComplete(false, "Message is required")
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            val result = carouselRepository.saveCarouselItem(item)
            _isLoading.value = false
            if (result.isSuccess) {
                _userMessage.value = if (item.id.isBlank()) "Slide created successfully" else "Slide updated successfully"
                onComplete(true, null)
            } else {
                val err = result.exceptionOrNull()?.message ?: "Failed to save carousel slide"
                _errorMessage.value = err
                onComplete(false, err)
            }
        }
    }

    suspend fun getItemById(id: String): CarouselItem? {
        return carouselRepository.getCarouselItemById(id)
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun clearErrorMessage() {
        _errorMessage.value = null
    }

    // =========================================================================
    // MEDIA UPLOAD OPERATIONS (PHASE 5)
    // =========================================================================

    fun onMediaFileSelected(result: MediaValidationResult.Valid) {
        _mediaUploadState.value = MediaUploadState.FileSelected(
            file = result.file,
            mediaType = result.mediaType,
            mimeType = result.mimeType,
            sizeBytes = result.sizeBytes,
            originalName = result.originalName
        )
    }

    fun onMediaFileInvalid(reason: String) {
        _mediaUploadState.value = MediaUploadState.Error(
            userMessage = reason,
            canRetry = false
        )
    }

    fun setExistingMedia(mediaResource: MediaResource?) {
        if (mediaResource != null && mediaResource.publicUrl.isNotBlank()) {
            _mediaUploadState.value = MediaUploadState.Success(mediaResource)
        } else {
            _mediaUploadState.value = MediaUploadState.Idle
        }
    }

    fun startUpload(
        contentType: CarouselContentType,
        onComplete: ((MediaResource?) -> Unit)? = null
    ) {
        val selected = _mediaUploadState.value as? MediaUploadState.FileSelected
        if (selected == null) {
            _errorMessage.value = "Please select a media file first."
            return
        }

        val logicalPath = LogicalStoragePath.buildCarouselPath(
            category = contentType.name.lowercase(),
            fileName = selected.file.name
        )

        uploadJob?.cancel()
        uploadJob = viewModelScope.launch {
            _mediaUploadState.value = MediaUploadState.Uploading(
                percentage = 0.05f,
                fileName = selected.originalName
            )

            mediaStorageService.uploadMedia(
                file = selected.file,
                logicalPath = logicalPath,
                mediaType = selected.mediaType
            ).collect { result ->
                when (result) {
                    is StorageResult.Progress -> {
                        _mediaUploadState.value = MediaUploadState.Uploading(
                            percentage = result.percentage,
                            fileName = selected.originalName
                        )
                    }
                    is StorageResult.Success -> {
                        _mediaUploadState.value = MediaUploadState.Success(result.data)
                        _userMessage.value = "Media asset successfully uploaded to Cloudinary"
                        onComplete?.invoke(result.data)
                    }
                    is StorageResult.Error -> {
                        val msg = result.message
                        val isSigReq = msg.contains("signature", ignoreCase = true) ||
                            msg.contains("backend", ignoreCase = true) ||
                            msg.contains("cloudName is empty", ignoreCase = true) ||
                            result.exception.message?.contains("signature", ignoreCase = true) == true
                        
                        _mediaUploadState.value = MediaUploadState.Error(
                            userMessage = msg,
                            canRetry = !isSigReq,
                            isSignaturePrerequisite = isSigReq
                        )
                        _errorMessage.value = msg
                        onComplete?.invoke(null)
                    }
                }
            }
        }
    }

    fun cancelUpload() {
        uploadJob?.cancel()
        uploadJob = null
        _mediaUploadState.value = MediaUploadState.Idle
        _userMessage.value = "Media upload cancelled"
    }

    fun resetUploadState() {
        uploadJob?.cancel()
        uploadJob = null
        _mediaUploadState.value = MediaUploadState.Idle
    }

    fun removeMedia(
        currentResource: MediaResource?,
        onDone: (() -> Unit)? = null
    ) {
        uploadJob?.cancel()
        uploadJob = null
        _mediaUploadState.value = MediaUploadState.Idle

        if (currentResource != null && currentResource.publicUrl.isNotBlank()) {
            viewModelScope.launch {
                try {
                    mediaStorageService.deleteMedia(currentResource)
                } catch (_: Exception) {}
                onDone?.invoke()
            }
        } else {
            onDone?.invoke()
        }
    }

    override fun onCleared() {
        super.onCleared()
        uploadJob?.cancel()
    }

    companion object {
        fun provideFactory(
            repository: CarouselRepository = FirestoreCarouselRepository.getInstance(),
            storageService: MediaStorageService = StorageServiceProvider.getMediaStorageService()
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return CarouselContentViewModel(repository, storageService) as T
            }
        }
    }
}
