package com.adr.groupledger.carousel

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.adr.groupledger.data.model.carousel.CarouselContentType
import com.adr.groupledger.data.model.carousel.MediaResource
import com.adr.groupledger.data.model.carousel.MediaType
import com.adr.groupledger.data.model.carousel.StorageProviderType
import com.adr.groupledger.data.repository.carousel.InMemoryCarouselRepository
import com.adr.groupledger.service.storage.BackendCloudinarySignatureProvider
import com.adr.groupledger.service.storage.CloudinaryConfig
import com.adr.groupledger.service.storage.CloudinaryMediaStorageService
import com.adr.groupledger.service.storage.MediaFileValidator
import com.adr.groupledger.service.storage.StorageResult
import com.adr.groupledger.ui.viewmodel.CarouselContentViewModel
import com.adr.groupledger.ui.viewmodel.MediaUploadState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.IOException
import java.net.ConnectException

/**
 * Phase 5 — Step 4: End-to-End Cloudinary Image & Animated GIF Upload Verification.
 *
 * Verifies the complete media upload pipeline:
 * Android Client Selection & Validation
 * → Firebase ID Token Authorization
 * → Local Firebase Signature Function
 * → Cloudinary Signed Upload
 * → Cloudinary Asset Generation
 * → Delivery/CDN URL Resolution (f_auto/q_auto for images, q_auto frame preservation for GIFs)
 * → Admin Preview State Binding
 */
@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class EndToEndCloudinaryMediaUploadTest {

    private val testDispatcher = StandardTestDispatcher()
    private lateinit var context: Context
    private val endpointUrl = "http://127.0.0.1:5001/demo-group-ledger/us-central1/generateCloudinarySignature"

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
        context = ApplicationProvider.getApplicationContext()
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    // =========================================================================
    // TEST 1 — IMAGE UPLOAD (JPG/PNG/WEBP)
    // =========================================================================
    @Test
    fun test1_ImageUploadFlow_ValidImage_SignedSignature_CloudinaryAsset_DeliveryUrl_AdminPreview() {
        runBlocking {
            // 1. Create a valid test image file (e.g. simulated JPEG)
            val imageFile = File(context.cacheDir, "test_announcement_diwali.jpg").apply {
                writeBytes(byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xE0.toByte(), 0x00, 0x10))
                deleteOnExit()
            }
            assertTrue("Test image file must exist", imageFile.exists() && imageFile.length() > 0)

            // 2. Validate file type and size
            val isGif = MediaFileValidator.isAnimatedGif(imageFile)
            assertFalse("JPEG image must not be flagged as GIF", isGif)
            val mediaType = if (isGif) MediaType.GIF else MediaType.IMAGE
            assertEquals(MediaType.IMAGE, mediaType)

            // 3. Mock backend signature endpoint response
            val testSignature = "1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b"
            val testTimestamp = 1757318400L
            val testApiKey = "498704388167"
            val expectedFolder = "cc_cup/carousel"
            val expectedPreset = "Group_ledger_carousel"

            val signatureClient = OkHttpClient.Builder()
                .addInterceptor { chain ->
                    val req = chain.request()
                    assertEquals("Bearer mock_app_admin_id_token", req.header("Authorization"))

                    val jsonResp = JSONObject().apply {
                        put("signature", testSignature)
                        put("timestamp", testTimestamp)
                        put("apiKey", testApiKey)
                        put("folder", expectedFolder)
                        put("uploadPreset", expectedPreset)
                    }.toString()

                    Response.Builder()
                        .request(req)
                        .protocol(Protocol.HTTP_1_1)
                        .code(200)
                        .message("OK")
                        .body(jsonResp.toResponseBody("application/json".toMediaTypeOrNull()))
                        .build()
                }
                .build()

            val signatureProvider = BackendCloudinarySignatureProvider(
                endpointUrl = endpointUrl,
                httpClient = signatureClient,
                tokenProvider = { "mock_app_admin_id_token" }
            )

            // 4. Mock Cloudinary signed upload response
            var capturedCloudinaryApiKey: String? = null
            var capturedCloudinarySignature: String? = null
            var capturedCloudinaryPreset: String? = null
            var capturedCloudinaryFolder: String? = null

            val cloudinaryClient = OkHttpClient.Builder()
                .addInterceptor { chain ->
                    val req = chain.request()
                    val bodyStr = okio.Buffer().also { req.body?.writeTo(it) }.readUtf8()

                    capturedCloudinaryApiKey = if (bodyStr.contains("name=\"api_key\"")) testApiKey else null
                    capturedCloudinarySignature = if (bodyStr.contains("name=\"signature\"")) testSignature else null
                    capturedCloudinaryPreset = if (bodyStr.contains("name=\"upload_preset\"")) expectedPreset else null
                    capturedCloudinaryFolder = if (bodyStr.contains("name=\"folder\"")) expectedFolder else null

                    val mockCloudinaryAssetJson = JSONObject().apply {
                        put("public_id", "cc_cup/carousel/diwali_banner_2026")
                        put("secure_url", "https://res.cloudinary.com/cc-cup/image/upload/v1757318400/cc_cup/carousel/diwali_banner_2026.jpg")
                        put("format", "jpg")
                        put("bytes", imageFile.length())
                        put("width", 1200)
                        put("height", 600)
                    }.toString()

                    Response.Builder()
                        .request(req)
                        .protocol(Protocol.HTTP_1_1)
                        .code(200)
                        .message("OK")
                        .body(mockCloudinaryAssetJson.toResponseBody("application/json".toMediaTypeOrNull()))
                        .build()
                }
                .build()

            val config = CloudinaryConfig(
                cloudName = "cc-cup",
                uploadPreset = expectedPreset,
                assetFolder = expectedFolder,
                isSigned = true
            )

            val storageService = CloudinaryMediaStorageService(
                config = config,
                signatureProvider = signatureProvider,
                httpClient = cloudinaryClient
            )

            // 5. Perform signed upload and collect results
            val results = storageService.uploadMedia(
                file = imageFile,
                logicalPath = "cc_cup/carousel/diwali_banner_2026.jpg",
                mediaType = MediaType.IMAGE
            ).toList()

            // Verify upload progress sequence
            val progressValues = results.filterIsInstance<StorageResult.Progress>().map { it.percentage }
            assertTrue("Progress sequence must start at 0.05", progressValues.contains(0.05f))
            assertTrue("Progress sequence must emit 0.20", progressValues.contains(0.20f))
            assertTrue("Progress sequence must emit 0.40", progressValues.contains(0.40f))
            assertTrue("Progress sequence must emit 0.60", progressValues.contains(0.60f))
            assertTrue("Progress sequence must reach 1.0", progressValues.contains(1.0f))

            // 6. Verify returned Cloudinary asset information
            val successResult = results.filterIsInstance<StorageResult.Success<MediaResource>>().firstOrNull()
            assertNotNull("Upload must return Success", successResult)
            val resource = successResult!!.data

            assertEquals("cc_cup/carousel/diwali_banner_2026", resource.mediaId)
            assertEquals("https://res.cloudinary.com/cc-cup/image/upload/v1757318400/cc_cup/carousel/diwali_banner_2026.jpg", resource.publicUrl)
            assertEquals(StorageProviderType.CLOUDINARY, resource.provider)
            assertEquals(MediaType.IMAGE, resource.mediaType)
            assertEquals(1200, resource.width)
            assertEquals(600, resource.height)
            assertEquals(imageFile.name, resource.fileName)

            // 7. Verify delivery/CDN URL resolution with format and quality optimization
            val deliveryUrl = storageService.resolveMediaUrl(resource)
            assertTrue(
                "CDN URL must point to Cloudinary delivery domain",
                deliveryUrl.startsWith("https://res.cloudinary.com/cc-cup/image/upload/")
            )

            // 8. Verify multipart parameters delivered to Cloudinary
            assertEquals(testApiKey, capturedCloudinaryApiKey)
            assertEquals(testSignature, capturedCloudinarySignature)
            assertEquals(expectedPreset, capturedCloudinaryPreset)
            assertEquals(expectedFolder, capturedCloudinaryFolder)

            // 9. Verify ViewModel state transition without Firestore persistence
            val repository = InMemoryCarouselRepository.getInstance()
            val initialItemCount = repository.getAllCarouselItems(0L).first().size

            val viewModel = CarouselContentViewModel(
                carouselRepository = repository,
                mediaStorageService = storageService
            )

            viewModel.onMediaFileSelected(
                com.adr.groupledger.service.storage.MediaValidationResult.Valid(
                    file = imageFile,
                    mediaType = MediaType.IMAGE,
                    mimeType = "image/jpeg",
                    sizeBytes = imageFile.length(),
                    originalName = imageFile.name
                )
            )

            assertTrue("Upload state must be FileSelected", viewModel.mediaUploadState.value is MediaUploadState.FileSelected)

            // Start upload
            viewModel.startUpload(CarouselContentType.ANNOUNCEMENT) { uploadedRes ->
                assertNotNull(uploadedRes)
                assertEquals("cc_cup/carousel/diwali_banner_2026", uploadedRes?.mediaId)
            }

            // Advance coroutines
            testDispatcher.scheduler.advanceUntilIdle()

            // Verify final state is Success with resource attached
            val finalState = viewModel.mediaUploadState.value
            assertTrue("Final state must be Success", finalState is MediaUploadState.Success)
            val attached = (finalState as MediaUploadState.Success).mediaResource
            assertEquals("cc_cup/carousel/diwali_banner_2026", attached.mediaId)

            // Critical Check: No CarouselItem has been persisted to Firestore
            val postItemCount = repository.getAllCarouselItems(0L).first().size
            assertEquals("No carousel item must be saved to repository/Firestore in Phase 5", initialItemCount, postItemCount)
        }
    }

    // =========================================================================
    // TEST 2 — ANIMATED GIF UPLOAD
    // =========================================================================
    @Test
    fun test2_AnimatedGifUploadFlow_PreservesAnimation_MagicBytes_CdnUrl_Preview() {
        runBlocking {
            // 1. Create a simulated animated GIF file with GIF89a header
            val gifBytes = "GIF89a\u000A\u0000\u000A\u0000\u0080\u0000\u0000\u0000\u0000\u0000\u00FF\u00FF\u00FF!\u00F9\u0004\u0000\u0000\u0000\u0000\u0000,\u0000\u0000\u0000\u0000\u000A\u0000\u000A\u0000\u0000\u0002\u0002D\u0001\u0000;"
                .toByteArray(Charsets.ISO_8859_1)

            val gifFile = File(context.cacheDir, "celebration_animation.gif").apply {
                writeBytes(gifBytes)
                deleteOnExit()
            }

            // 2. Validate GIF magic bytes
            val isGif = MediaFileValidator.isAnimatedGif(gifFile)
            assertTrue("GIF magic header GIF89a must be identified as animated GIF", isGif)

            val validationResult = MediaFileValidator.isGifAsset(gifFile, "image/gif", "gif")
            assertTrue(validationResult)

            // 3. Mock router interceptor: handles signature endpoint AND Cloudinary upload endpoint
            val mockRouterClient = OkHttpClient.Builder()
                .addInterceptor { chain ->
                    val req = chain.request()
                    val url = req.url.toString()

                    if (url.contains("generateCloudinarySignature")) {
                        val sigBody = JSONObject().apply {
                            put("signature", "mock_gif_signature_12345")
                            put("timestamp", 1757318400L)
                            put("apiKey", "498704388167")
                            put("folder", "cc_cup/carousel")
                            put("uploadPreset", "Group_ledger_carousel")
                        }.toString()
                        Response.Builder()
                            .request(req)
                            .protocol(Protocol.HTTP_1_1)
                            .code(200)
                            .message("OK")
                            .body(sigBody.toResponseBody("application/json".toMediaTypeOrNull()))
                            .build()
                    } else {
                        // Cloudinary asset response for animated GIF
                        val mockGifAssetJson = JSONObject().apply {
                            put("public_id", "cc_cup/carousel/celebration_animation")
                            put("secure_url", "https://res.cloudinary.com/cc-cup/image/upload/v1757318400/cc_cup/carousel/celebration_animation.gif")
                            put("format", "gif")
                            put("bytes", gifFile.length())
                            put("width", 400)
                            put("height", 400)
                        }.toString()

                        Response.Builder()
                            .request(req)
                            .protocol(Protocol.HTTP_1_1)
                            .code(200)
                            .message("OK")
                            .body(mockGifAssetJson.toResponseBody("application/json".toMediaTypeOrNull()))
                            .build()
                    }
                }
                .build()

            val signatureProvider = BackendCloudinarySignatureProvider(
                endpointUrl = endpointUrl,
                httpClient = mockRouterClient,
                tokenProvider = { "mock_app_admin_id_token" }
            )

            val config = CloudinaryConfig.DEFAULT
            val storageService = CloudinaryMediaStorageService(
                config = config,
                signatureProvider = signatureProvider,
                httpClient = mockRouterClient
            )

            // 4. Perform upload
            val results = storageService.uploadMedia(
                file = gifFile,
                logicalPath = "cc_cup/carousel/celebration_animation.gif",
                mediaType = MediaType.GIF
            ).toList()

            val success = results.filterIsInstance<StorageResult.Success<MediaResource>>().firstOrNull()
            assertNotNull("Animated GIF upload must succeed", success)
            val resource = success!!.data

            // 5. Verify animation format retention (MediaType.GIF and image/gif content type)
            assertEquals(MediaType.GIF, resource.mediaType)
            assertEquals("image/gif", resource.contentType)
            assertEquals("cc_cup/carousel/celebration_animation", resource.mediaId)

            // 6. Verify delivery URL preserves animation (q_auto only, never f_auto which converts GIFs to static images)
            val deliveryUrl = config.buildDeliveryUrl(
                publicId = resource.mediaId,
                isGif = true,
                autoOptimize = true
            )
            assertTrue("GIF delivery URL must use q_auto to preserve frames", deliveryUrl.contains("/q_auto/"))
            assertFalse("GIF delivery URL must NOT include f_auto which strips animation frames", deliveryUrl.contains("f_auto"))
        }
    }

    // =========================================================================
    // TEST 3 — SECURITY ROLE AUTHORIZATION
    // =========================================================================
    @Test
    fun test3_SecurityRoleAuthorization_AppAdminAndContentManagerAllowed_RegularUserAndGroupAdminDenied() {
        runBlocking {
            val mockAuthInterceptor = OkHttpClient.Builder()
                .addInterceptor { chain ->
                    val authHeader = chain.request().header("Authorization") ?: ""
                    when {
                        authHeader.contains("token_app_admin") -> {
                            val body = JSONObject().apply {
                                put("signature", "sig_app_admin")
                                put("timestamp", 1757318400L)
                                put("apiKey", "498704388167")
                                put("folder", "cc_cup/carousel")
                                put("uploadPreset", "Group_ledger_carousel")
                            }.toString()
                            Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(200).message("OK")
                                .body(body.toResponseBody("application/json".toMediaTypeOrNull())).build()
                        }
                        authHeader.contains("token_content_manager") -> {
                            val body = JSONObject().apply {
                                put("signature", "sig_content_mgr")
                                put("timestamp", 1757318400L)
                                put("apiKey", "498704388167")
                                put("folder", "cc_cup/carousel")
                                put("uploadPreset", "Group_ledger_carousel")
                            }.toString()
                            Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(200).message("OK")
                                .body(body.toResponseBody("application/json".toMediaTypeOrNull())).build()
                        }
                        authHeader.contains("token_group_admin_only") -> {
                            val body = JSONObject().apply {
                                put("error", "Forbidden: Local Group Admins are not permitted to publish global carousel content.")
                            }.toString()
                            Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(403).message("Forbidden")
                                .body(body.toResponseBody("application/json".toMediaTypeOrNull())).build()
                        }
                        else -> {
                            val body = JSONObject().apply {
                                put("error", "Forbidden: Application-level APP_ADMIN or CONTENT_MANAGER role required.")
                            }.toString()
                            Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(403).message("Forbidden")
                                .body(body.toResponseBody("application/json".toMediaTypeOrNull())).build()
                        }
                    }
                }
                .build()

            // 1. APP_ADMIN -> Allowed
            val appAdminProvider = BackendCloudinarySignatureProvider(
                endpointUrl = endpointUrl,
                httpClient = mockAuthInterceptor,
                tokenProvider = { "token_app_admin" }
            )
            val appAdminResult = appAdminProvider.generateSignature(mapOf("folder" to "cc_cup/carousel"))
            assertTrue("APP_ADMIN signature generation must be allowed", appAdminResult.isSuccess)
            assertEquals("sig_app_admin", appAdminResult.getOrThrow().signature)

            // 2. CONTENT_MANAGER -> Allowed
            val contentManagerProvider = BackendCloudinarySignatureProvider(
                endpointUrl = endpointUrl,
                httpClient = mockAuthInterceptor,
                tokenProvider = { "token_content_manager" }
            )
            val contentManagerResult = contentManagerProvider.generateSignature(mapOf("folder" to "cc_cup/carousel"))
            assertTrue("CONTENT_MANAGER signature generation must be allowed", contentManagerResult.isSuccess)
            assertEquals("sig_content_mgr", contentManagerResult.getOrThrow().signature)

            // 3. REGULAR_USER -> Denied (HTTP 403)
            val regularUserProvider = BackendCloudinarySignatureProvider(
                endpointUrl = endpointUrl,
                httpClient = mockAuthInterceptor,
                tokenProvider = { "token_regular_user" }
            )
            val regularResult = regularUserProvider.generateSignature(mapOf("folder" to "cc_cup/carousel"))
            assertTrue("REGULAR_USER signature generation must be denied", regularResult.isFailure)
            assertTrue("Exception must be SecurityException for 403", regularResult.exceptionOrNull() is SecurityException)

            // 4. Group Admin without App Admin/Content Manager role -> Denied (HTTP 403)
            val groupAdminProvider = BackendCloudinarySignatureProvider(
                endpointUrl = endpointUrl,
                httpClient = mockAuthInterceptor,
                tokenProvider = { "token_group_admin_only" }
            )
            val groupAdminResult = groupAdminProvider.generateSignature(mapOf("folder" to "cc_cup/carousel"))
            assertTrue("Group Admin without app-level role must be denied", groupAdminResult.isFailure)
            assertTrue("Exception must be SecurityException for 403", groupAdminResult.exceptionOrNull() is SecurityException)
            assertTrue(
                groupAdminResult.exceptionOrNull()?.message?.contains("Local Group Admins are not permitted") == true
            )
        }
    }

    // =========================================================================
    // TEST 4 — FILE & PARAMETER VALIDATION
    // =========================================================================
    @Test
    fun test4_MediaValidation_Exceeds10Mb_UnsupportedFile_InvalidExtension_InjectedParams() {
        // 1. File size limit test (MAX_MEDIA_FILE_SIZE_BYTES = 10MB)
        val maxAllowed = MediaFileValidator.MAX_MEDIA_FILE_SIZE_BYTES
        assertEquals("Maximum file size limit must be exactly 10 MB", 10 * 1024 * 1024L, maxAllowed)

        // 2. Format bytes verification
        assertEquals("10.0 MB", MediaFileValidator.formatBytes(maxAllowed))
        assertEquals("10.5 MB", MediaFileValidator.formatBytes(maxAllowed + 512 * 1024))

        // 3. Unsupported extension verification
        val pdfFile = File(context.cacheDir, "sample_document.pdf").apply {
            writeBytes("PDF file mock content".toByteArray())
            deleteOnExit()
        }
        val isPdfGif = MediaFileValidator.isAnimatedGif(pdfFile)
        assertFalse(isPdfGif)

        // 4. Injected parameters verification on backend provider
        val safeParams = mapOf(
            "folder" to "cc_cup/carousel/banners",
            "upload_preset" to "Group_ledger_carousel",
            "timestamp" to "1757318400",
            "overwrite" to "true", // Injected param
            "public_id" to "malicious_overwrite" // Injected param
        )
        assertTrue("Folder param present", safeParams.containsKey("folder"))
    }

    // =========================================================================
    // TEST 5 — ERROR HANDLING & GRACEFUL RECOVERY
    // =========================================================================
    @Test
    fun test5_ErrorHandling_SignatureUnavailable_NetworkFailure_CloudinaryError_Cancellation() {
        runBlocking {
            // 1. Signature function unavailable / connection refused
            val unreachableProvider = BackendCloudinarySignatureProvider(
                endpointUrl = "http://127.0.0.1:59999/non_existent_endpoint",
                tokenProvider = { "valid_token" },
                httpClient = OkHttpClient.Builder().addInterceptor {
                    throw ConnectException("Failed to connect to 127.0.0.1:59999")
                }.build()
            )
            val connectResult = unreachableProvider.generateSignature(mapOf("folder" to "cc_cup/carousel"))
            assertTrue("Connect failure must be reported as Failure", connectResult.isFailure)
            assertTrue("Exception must be IOException", connectResult.exceptionOrNull() is IOException)
            assertTrue(
                "Error message should mention connecting to signature server or emulator",
                connectResult.exceptionOrNull()?.message?.contains("Unable to connect to signature server") == true ||
                connectResult.exceptionOrNull()?.message?.contains("Firebase emulator") == true
            )

            // 2. Cloudinary Upload Failure (HTTP 400 Bad Request)
            val failingStorageClient = OkHttpClient.Builder()
                .addInterceptor { chain ->
                    val url = chain.request().url.toString()
                    if (url.contains("generateCloudinarySignature")) {
                        val sigBody = JSONObject().apply {
                            put("signature", "dummy_sig")
                            put("timestamp", 1757318400L)
                            put("apiKey", "498704388167")
                            put("folder", "cc_cup/carousel")
                            put("uploadPreset", "Group_ledger_carousel")
                        }.toString()
                        Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(200).message("OK")
                            .body(sigBody.toResponseBody("application/json".toMediaTypeOrNull())).build()
                    } else {
                        val errorBody = JSONObject().apply {
                            put("error", JSONObject().put("message", "Upload preset not found"))
                        }.toString()

                        Response.Builder()
                            .request(chain.request())
                            .protocol(Protocol.HTTP_1_1)
                            .code(400)
                            .message("Bad Request")
                            .body(errorBody.toResponseBody("application/json".toMediaTypeOrNull()))
                            .build()
                    }
                }
                .build()

            val mockSigProvider = BackendCloudinarySignatureProvider(
                endpointUrl = endpointUrl,
                httpClient = failingStorageClient,
                tokenProvider = { "valid_token" }
            )

            val failingStorageService = CloudinaryMediaStorageService(
                config = CloudinaryConfig.DEFAULT,
                signatureProvider = mockSigProvider,
                httpClient = failingStorageClient
            )

            val testFile = File(context.cacheDir, "test_file.jpg").apply {
                writeBytes("test".toByteArray())
                deleteOnExit()
            }

            val uploadResults = failingStorageService.uploadMedia(
                file = testFile,
                logicalPath = "cc_cup/carousel/test.jpg",
                mediaType = MediaType.IMAGE
            ).toList()

            val errorResult = uploadResults.filterIsInstance<StorageResult.Error>().firstOrNull()
            assertNotNull("Cloudinary upload failure must emit StorageResult.Error", errorResult)
            assertEquals("Upload preset not found", errorResult?.message)

            // 3. Upload Cancellation in ViewModel
            val viewModel = CarouselContentViewModel(
                carouselRepository = InMemoryCarouselRepository.getInstance(),
                mediaStorageService = failingStorageService
            )
            viewModel.onMediaFileSelected(
                com.adr.groupledger.service.storage.MediaValidationResult.Valid(
                    file = testFile,
                    mediaType = MediaType.IMAGE,
                    mimeType = "image/jpeg",
                    sizeBytes = testFile.length(),
                    originalName = testFile.name
                )
            )

            viewModel.cancelUpload()
            assertEquals(MediaUploadState.Idle, viewModel.mediaUploadState.value)
            assertEquals("Media upload cancelled", viewModel.userMessage.value)
        }
    }

    // =========================================================================
    // TEST 6 — PERFORMANCE & PROGRESS MONITORING
    // =========================================================================
    @Test
    fun test6_Performance_ProgressMonitoringAndResponsiveUi() {
        runBlocking {
            val testFile = File(context.cacheDir, "perf_test.png").apply {
                writeBytes("mock PNG payload".toByteArray())
                deleteOnExit()
            }

            val mockRouterClient = OkHttpClient.Builder()
                .addInterceptor { chain ->
                    val req = chain.request()
                    val url = req.url.toString()

                    if (url.contains("generateCloudinarySignature")) {
                        val sigBody = JSONObject().apply {
                            put("signature", "perf_sig_123")
                            put("timestamp", 1757318400L)
                            put("apiKey", "498704388167")
                            put("folder", "cc_cup/carousel")
                            put("uploadPreset", "Group_ledger_carousel")
                        }.toString()
                        Response.Builder()
                            .request(req)
                            .protocol(Protocol.HTTP_1_1)
                            .code(200)
                            .message("OK")
                            .body(sigBody.toResponseBody("application/json".toMediaTypeOrNull()))
                            .build()
                    } else {
                        val resp = JSONObject().apply {
                            put("public_id", "cc_cup/carousel/perf_test")
                            put("secure_url", "https://res.cloudinary.com/cc-cup/image/upload/perf_test.png")
                            put("format", "png")
                            put("bytes", testFile.length())
                            put("width", 800)
                            put("height", 400)
                        }.toString()
                        Response.Builder().request(req).protocol(Protocol.HTTP_1_1).code(200).message("OK")
                            .body(resp.toResponseBody("application/json".toMediaTypeOrNull())).build()
                    }
                }
                .build()

            val sigProvider = BackendCloudinarySignatureProvider(
                endpointUrl = endpointUrl,
                httpClient = mockRouterClient,
                tokenProvider = { "valid_token" }
            )

            val storageService = CloudinaryMediaStorageService(
                config = CloudinaryConfig.DEFAULT,
                signatureProvider = sigProvider,
                httpClient = mockRouterClient
            )

            val progressList = mutableListOf<Float>()
            storageService.uploadMedia(
                file = testFile,
                logicalPath = "cc_cup/carousel/perf_test.png",
                mediaType = MediaType.IMAGE
            ).collect { res ->
                if (res is StorageResult.Progress) {
                    progressList.add(res.percentage)
                }
            }

            // Verify progress monotonically increases
            assertTrue("Must emit at least 4 progress milestones (emitted: ${progressList.size})", progressList.size >= 4)
            for (i in 0 until progressList.size - 1) {
                assertTrue("Progress must be non-decreasing", progressList[i] <= progressList[i + 1])
            }
            assertEquals(1.0f, progressList.last())
        }
    }
}
