package com.adr.groupledger.data.model

/**
 * Report navigation tabs for Chit Fund Category-Aware Reporting.
 */
enum class ChitReportTab(val title: String) {
    OVERVIEW("Overview"),
    CYCLES("Cycle History"),
    AUCTIONS("Auctions & Bids"),
    CONTRIBUTIONS("Contributions"),
    SETTLEMENTS("Settlements & Ledger"),
    MEMBER_VIEW("Member Ledger")
}

/**
 * High-level financial and cycle overview for Chit Fund Scheme.
 */
data class ChitFundReportOverview(
    val totalChitValue: Double = 0.0,
    val totalMembers: Int = 0,
    val totalCycles: Int = 0,
    val completedCyclesCount: Int = 0,
    val currentCycleNumber: Int = 1,
    val remainingCyclesCount: Int = 0,
    val totalContributionsCollected: Double = 0.0,
    val totalAuctionDiscounts: Double = 0.0,
    val totalSettledPrizeAmount: Double = 0.0,
    val totalForemanCommission: Double = 0.0,
    val totalDividendsDistributed: Double = 0.0,
    val pendingSettlementCount: Int = 0,
    val pendingSettlementAmount: Double = 0.0,
    val isAllReconciled: Boolean = true,
    val reconciliationMessage: String = "All transactions reconciled with Group Ledger"
)

/**
 * Detailed report line item for an individual Chit cycle/round.
 */
data class ChitCycleReportItem(
    val cycle: ChitCycle,
    val cycleNumber: Int,
    val scheduledDateMillis: Long,
    val installmentAmount: Double,
    val totalPot: Double,
    val cycleStatus: ChitCycleStatus,
    val winnerMemberId: Long?,
    val winnerMemberName: String?,
    val winningBidAmount: Double?,
    val prizePayoutAmount: Double?,
    val foremanCommission: Double?,
    val dividendPerMember: Double?,
    val settlementStatus: String,
    val payoutTxnRef: String?,
    val commissionTxnRef: String?,
    val bidsCount: Int,
    val validBidsCount: Int,
    val totalCollectedForCycle: Double,
    val totalExpectedForCycle: Double,
    val isCycleReconciled: Boolean
)

/**
 * Member-specific Chit Fund financial summary and ledger position.
 */
data class ChitMemberFinancialSummary(
    val member: Member,
    val totalPaidAmount: Double = 0.0,
    val totalDueAmount: Double = 0.0,
    val totalDividendsEarned: Double = 0.0,
    val participatedAuctionsCount: Int = 0,
    val wonRounds: List<Int> = emptyList(),
    val totalPrizeReceived: Double = 0.0,
    val netFinancialPosition: Double = 0.0, // (Prize received + Dividends earned) - Total installments paid
    val paymentHistory: List<Payment> = emptyList()
)

/**
 * Chit Fund internal financial reconciliation status with Group Ledger.
 */
data class ChitReconciliationSummary(
    val isAllReconciled: Boolean,
    val totalLedgerPrizePaid: Double,
    val totalCalculatedPrizeDue: Double,
    val totalLedgerCommission: Double,
    val totalCalculatedCommission: Double,
    val totalSettledCyclesCount: Int,
    val mismatchedCycleNumbers: List<Int> = emptyList(),
    val statusMessage: String
)
