package com.adr.groupledger.ui.home.template

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.History
import androidx.compose.ui.window.Dialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adr.groupledger.data.model.ChitCycleStatus
import com.adr.groupledger.data.model.ChitFundConfig
import com.adr.groupledger.ui.components.HomeNotificationCarousel
import com.adr.groupledger.ui.components.SamitiPullToRefreshBox
import com.adr.groupledger.ui.home.HomeTemplateContext
import com.adr.groupledger.ui.home.components.ChitFundConfigDialog
import com.adr.groupledger.ui.home.components.HomeActionCarouselCard
import com.adr.groupledger.ui.home.components.HomeAnnouncementsCarousel
import com.adr.groupledger.ui.screens.demo.AuctionStatus
import com.adr.groupledger.ui.screens.demo.ChitAuctionRulesCard
import com.adr.groupledger.ui.screens.demo.ChitMemberStatusCard
import com.adr.groupledger.ui.screens.demo.ChitQuickActionsGrid
import com.adr.groupledger.ui.screens.demo.ChitRulesDialog
import com.adr.groupledger.ui.screens.demo.CompletedChitRound
import com.adr.groupledger.ui.screens.demo.MyBidsDialog
import com.adr.groupledger.ui.screens.demo.NextAuctionActionCard
import com.adr.groupledger.ui.screens.demo.PersonalMemberStatusCard
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoHeroDark
import com.adr.groupledger.ui.theme.IndigoHeroSurface
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.utils.ChitCalculationEngine
import com.adr.groupledger.utils.CurrencyFormatter
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

// Light Yellow token for completed rounds progress visualization
private val ProgressCompletedYellow = Color(0xFFFDE047)

/**
 * Level 1: Sub-category specialized template for Chit Fund / BC.
 *
 * Implements Phase D.0.24:
 * - Card width aligned with standard content width (removed redundant nested horizontal padding)
 * - Card #5 height preserved with compact stat box sizing
 * - Lifecycle Progress title row: "Chit Lifecycle Progress" and dynamic "Current: XX"
 * - Dynamic Start Date & Expected Ending Date row below progress bar
 * - Progress bar 3 states: Base (White 15%), Completed (Light Yellow), Active (Green)
 * - Active green indicator subtle pulsing/blinking animation
 * - Chit Round History #11 at bottom with latest 2 completed entries
 */
object ChitFundHomeTemplate : GroupHomeTemplate {

    override val templateId: String = "chit_fund_home"
    override val displayName: String = "Chit Fund Home Template"

    @Composable
    override fun Render(context: HomeTemplateContext) {
        val curr = context.settings.currencySymbol.ifBlank { "₹" }
        var showConfigDialog by remember { mutableStateOf(false) }
        var showRulesModal by remember { mutableStateOf(false) }
        var showMyBidsModal by remember { mutableStateOf(false) }
        var currentAuctionState by remember { mutableStateOf(AuctionStatus.UPCOMING) }
        var userSubmittedBid by remember { mutableStateOf<String?>(null) }
        var userBidTime by remember { mutableStateOf<String?>(null) }

        // 1. Resolve Chit Fund Configuration from Settings JSON & fallback fields
        val chitConfig = remember(context.settings.modulesConfigJson, context.settings.defaultContribution, context.settings.dueDayOfMonth) {
            ChitFundConfig.parseFromSettings(context.settings)
        }

        // 2. Derive Real Member Counts
        val totalMembers = context.monthSummary?.totalMembers
            ?: context.totalActiveMembersCount.takeIf { it > 0 }
            ?: context.financials.activeMembers.takeIf { it > 0 }
            ?: context.financials.totalMembers

        val paidMembers = context.monthSummary?.paidCount ?: context.financials.currentMonthPaidCount
        val partialMembers = context.monthSummary?.partialCount ?: context.financials.currentMonthPartialCount
        val pendingMembers = context.monthSummary?.unpaidCount ?: context.financials.currentMonthUnpaidCount

        // 3. Resolve Financial Metrics & Cycle Progress from Calculation Engine
        val monthlyInstallment = chitConfig.monthlyInstallment
            ?: context.settings.defaultContribution.takeIf { it > 0.0 } ?: 5000.0

        val totalMembersCalculated = chitConfig.totalMembers
            ?: totalMembers.takeIf { it > 0 }
            ?: chitConfig.totalChits
            ?: 20

        val totalChits = chitConfig.totalChits
            ?: if (totalMembersCalculated > 0) totalMembersCalculated else 20

        val currentChitNo = chitConfig.currentChitNo ?: 1

        val cycleMetrics = remember(chitConfig.cycles, totalChits, currentChitNo) {
            ChitCalculationEngine.deriveCycleMetrics(
                cycles = chitConfig.cycles,
                configuredTotalCycles = totalChits,
                currentChitNoOverride = currentChitNo
            )
        }

        val totalValue = chitConfig.totalValue
            ?: (totalMembersCalculated * monthlyInstallment)

        // Dynamic Start Date & Expected Ending Date derived from cycles / config
        val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }
        val (startDateText, expectedEndDateText) = remember(chitConfig.cycles, chitConfig.startDateMillis, totalChits) {
            if (chitConfig.cycles.isNotEmpty()) {
                val first = chitConfig.cycles.first()
                val last = chitConfig.cycles.last()
                Pair(first.scheduledDate, last.scheduledDate)
            } else {
                val startMillis = chitConfig.startDateMillis ?: System.currentTimeMillis()
                val cal = Calendar.getInstance().apply { timeInMillis = startMillis }
                val startStr = dateFormat.format(cal.time)
                cal.add(Calendar.MONTH, (totalChits - 1).coerceAtLeast(1))
                val endStr = dateFormat.format(cal.time)
                Pair(startStr, endStr)
            }
        }

        // Auction date & schedule text
        val auctionScheduleText = remember(chitConfig, context.settings) {
            val day = chitConfig.auctionScheduleDay ?: context.settings.dueDayOfMonth.takeIf { it in 1..31 } ?: 28
            val time = chitConfig.auctionTime?.ifBlank { "08:00 PM" } ?: "08:00 PM"
            "${day}th of month, $time"
        }

        val auctionTimeText = chitConfig.auctionTime?.ifBlank { "08:00 PM" } ?: "08:00 PM"

        val currentUserMonthlyStatus = context.currentUserMonthlyStatus
        val userPaid = currentUserMonthlyStatus?.status.equals("PAID", ignoreCase = true)
        var isUserInstallmentPaid by remember(userPaid) { mutableStateOf(userPaid) }
        val userDividend = 0.0
        val effectivePayable = (monthlyInstallment - userDividend).coerceAtLeast(0.0)

        SamitiPullToRefreshBox(
            isRefreshing = context.isRefreshing,
            onRefresh = { context.viewModel.refreshDashboard() },
            modifier = Modifier.fillMaxSize()
        ) {
            // Note: Outer Box in DashboardScreen already supplies standard padding(horizontal = 14.dp, vertical = 8.dp).
            // Do NOT apply redundant horizontal padding here so cards match standard content width.
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // =============================================================
                // 1. MAIN CHIT FUND CARD #5 (Native Integrated Lifecycle Progress)
                // =============================================================
                ChitFundProductionMainCard(
                    groupName = context.settings.groupName.ifBlank { "Chit Fund Group" },
                    categoryTitle = context.category.title,
                    subCategory = context.subCategory,
                    totalChitValue = "$curr${CurrencyFormatter.formatIndian(totalValue)}",
                    currentChit = cycleMetrics.currentCycleNumber,
                    totalChits = cycleMetrics.totalCycles.takeIf { it > 0 } ?: totalChits,
                    completedChits = cycleMetrics.completedCycles,
                    monthlyInstallment = "$curr${CurrencyFormatter.formatIndian(monthlyInstallment)}",
                    totalMembers = totalMembersCalculated,
                    cycleFrequency = chitConfig.frequency.ifBlank { "Monthly" },
                    startDateText = startDateText,
                    expectedEndDateText = expectedEndDateText
                )

                // =============================================================
                // 2. CAROUSEL #1 (System Alerts / Notifications Carousel)
                // =============================================================
                if (context.notifications.isNotEmpty()) {
                    HomeNotificationCarousel(notifications = context.notifications)
                }

                // =============================================================
                // 3. SERVICES & ACTIONS #2
                // =============================================================
                HomeActionCarouselCard(context = context)

                // =============================================================
                // 4. NEXT AUCTION CARD — #7
                // =============================================================
                NextAuctionActionCard(
                    chitRound = cycleMetrics.currentCycleNumber,
                    auctionDate = auctionScheduleText ?: "28 September 2026",
                    auctionTime = auctionTimeText,
                    auctionStatus = currentAuctionState,
                    onViewAuction = {
                        context.onNavigateToAuctionDetails?.invoke(cycleMetrics.currentCycleNumber)
                            ?: context.onNavigateToInbox()
                    },
                    onQuickStateChange = { currentAuctionState = it }
                )

                // =============================================================
                // 5. MEMBER PAYMENT DISTRIBUTION STATUS — #9
                // =============================================================
                ChitMemberStatusCard(
                    totalMembers = totalMembersCalculated,
                    paidCount = paidMembers,
                    partialCount = partialMembers,
                    pendingCount = pendingMembers,
                    onViewMembersList = {
                        context.onNavigateToChitCollection?.invoke(cycleMetrics.currentCycleNumber)
                            ?: context.onNavigateToMembers()
                    }
                )

                // =============================================================
                // 6. PERSONAL MEMBER STATUS CARD — #10
                // =============================================================
                PersonalMemberStatusCard(
                    isPaid = isUserInstallmentPaid,
                    monthlyInstallment = "$curr${CurrencyFormatter.formatIndian(monthlyInstallment)}",
                    dividendSavings = "$curr${CurrencyFormatter.formatIndian(userDividend)}",
                    effectivePayable = "$curr${CurrencyFormatter.formatIndian(effectivePayable)}",
                    isAuctionEligible = true,
                    onPayClick = {
                        context.onNavigateToChitMyContribution?.invoke()
                            ?: context.onNavigateToRecordPayment()
                    },
                    onToggleStatus = { isUserInstallmentPaid = !isUserInstallmentPaid }
                )

                // =============================================================
                // 7. QUICK ACTIONS GRID
                // =============================================================
                ChitQuickActionsGrid(
                    onAuctionClick = {
                        context.onNavigateToAuctionDetails?.invoke(cycleMetrics.currentCycleNumber)
                            ?: context.onNavigateToInbox()
                    },
                    onMyBidsClick = { showMyBidsModal = true },
                    onInstallmentClick = {
                        context.onNavigateToChitMyContribution?.invoke()
                            ?: context.onNavigateToRecordPayment()
                    },
                    onMembersClick = {
                        context.onNavigateToChitCollection?.invoke(cycleMetrics.currentCycleNumber)
                            ?: context.onNavigateToMembers()
                    },
                    onHistoryClick = {
                        context.onNavigateToAuctionDetails?.invoke(cycleMetrics.currentCycleNumber)
                            ?: context.onNavigateToInbox()
                    },
                    onRulesClick = { showRulesModal = true }
                )

                // =============================================================
                // 8. CAROUSEL #14 (Dynamic Home Announcements Carousel)
                // =============================================================
                HomeAnnouncementsCarousel(context = context)

                // =============================================================
                // 10. CHIT ROUND HISTORY #11 (Latest 2 rounds only)
                // =============================================================
                ChitRoundHistoryProductionCard(
                    chitConfig = chitConfig,
                    onViewAllHistory = {
                        context.onNavigateToAuctionDetails?.invoke(cycleMetrics.currentCycleNumber)
                            ?: context.onNavigateToInbox()
                    }
                )
            }
        }

        // Dedicated Interactive Dialogs
        if (showRulesModal) {
            ConfiguredAuctionRulesDetailDialog(
                chitConfig = chitConfig,
                totalValue = totalValue,
                totalMembers = totalMembersCalculated,
                currencySymbol = curr,
                onDismiss = { showRulesModal = false }
            )
        }

        if (showMyBidsModal) {
            MyBidsDialog(
                currentBid = userSubmittedBid,
                bidTime = userBidTime,
                onDismiss = { showMyBidsModal = false }
            )
        }

        // Admin Chit Scheme Configuration Dialog
        if (showConfigDialog) {
            ChitFundConfigDialog(
                currentConfig = chitConfig,
                currencySymbol = curr,
                onDismiss = { showConfigDialog = false },
                onSave = { updatedConfig ->
                    val updatedSettings = ChitFundConfig.encodeIntoSettings(context.settings, updatedConfig)
                    context.viewModel.updateGroupSettings(updatedSettings)
                    showConfigDialog = false
                }
            )
        }
    }
}

/**
 * Main Chit Fund Card (#5):
 * - Standard horizontal width matching other category cards
 * - Compact height preserved
 * - Title row: "Chit Lifecycle Progress" and dynamic "Current: XX"
 * - Segmented progress bar with Base, Completed (Light Yellow), and Active (Green blinking)
 * - Dates row: Start Date (Left) and Expected Ending Date (Right)
 * - 3 compact stat boxes
 */
@Composable
fun ChitFundProductionMainCard(
    groupName: String,
    categoryTitle: String,
    subCategory: String,
    totalChitValue: String,
    currentChit: Int,
    totalChits: Int,
    completedChits: Int,
    monthlyInstallment: String,
    totalMembers: Int,
    cycleFrequency: String,
    startDateText: String,
    expectedEndDateText: String
) {
    // Active Green indicator subtle pulsing animation (35% to 100% alpha)
    val infiniteTransition = rememberInfiniteTransition(label = "active_green_pulse")
    val activeAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "active_alpha"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("demo_chit_main_summary_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = IndigoHeroDark),
        border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.4f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            IndigoHeroSurface.copy(alpha = 0.85f),
                            IndigoHeroDark
                        )
                    )
                )
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Top Row: Group name, read-only category, and current chit badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = groupName,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                    Text(
                        text = "$categoryTitle • $subCategory",
                        fontSize = 10.5.sp,
                        color = Color.White.copy(alpha = 0.6f)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Amber500.copy(alpha = 0.2f),
                    border = BorderStroke(1.dp, Amber500.copy(alpha = 0.6f))
                ) {
                    val currentFormatted = if (currentChit < 10) "0$currentChit" else "$currentChit"
                    Text(
                        text = "Chit #$currentFormatted of $totalChits",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Amber500,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            val completionFraction = if (totalChits > 0) (completedChits.toFloat() / totalChits.toFloat()) else 0f
            val remainingChits = (totalChits - completedChits).coerceAtLeast(0)

            // Central Focus: Total Chit Value & Circular Completion Indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "TOTAL CHIT VALUE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.7f),
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = totalChitValue,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Emerald500.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "Guaranteed Pool",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Emerald500,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "$totalMembers Members • $monthlyInstallment",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.75f)
                        )
                    }
                }

                // Distinctive Circular completion indicator
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White.copy(alpha = 0.08f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(52.dp)) {
                            CircularProgressIndicator(
                                progress = { completionFraction },
                                modifier = Modifier.size(50.dp),
                                color = Amber500,
                                trackColor = Color.White.copy(alpha = 0.15f),
                                strokeWidth = 5.dp
                            )
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${(completionFraction * 100).toInt()}%",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                                Text(
                                    text = "DONE",
                                    fontSize = 7.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Amber500
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$completedChits Completed",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Emerald500
                        )
                        Text(
                            text = "$remainingChits Remaining",
                            fontSize = 8.5.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }
                }
            }

            // =================================================================
            // Integrated Chit Lifecycle Progress (Natively inside Card #5)
            // =================================================================
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                // Title Row matching previous Card #5 typography
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Chit Lifecycle Progress",
                        fontSize = 11.5.sp,
                        color = Color.White.copy(alpha = 0.8f),
                        fontWeight = FontWeight.Medium
                    )
                    val currentFormatted = if (currentChit < 10) "0$currentChit" else "$currentChit"
                    Text(
                        text = "Current: $currentFormatted",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Amber500
                    )
                }

                // Segmented Progress Bar: Base / Completed (Light Yellow) / Active (Green blinking)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    for (i in 1..totalChits) {
                        val isCompleted = i <= completedChits
                        val isCurrent = i == currentChit
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(8.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(
                                    when {
                                        isCurrent -> Emerald500.copy(alpha = activeAlpha)
                                        isCompleted -> ProgressCompletedYellow
                                        else -> Color.White.copy(alpha = 0.15f)
                                    }
                                )
                        )
                    }
                }

                // Legend & Breakdown
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(ProgressCompletedYellow))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("$completedChits Completed", fontSize = 10.sp, color = Color.White.copy(alpha = 0.75f))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(Emerald500.copy(alpha = activeAlpha))
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        val currentFormatted = if (currentChit < 10) "0$currentChit" else "$currentChit"
                        Text("#$currentFormatted Active", fontSize = 10.sp, color = Emerald500, fontWeight = FontWeight.Bold)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.25f)))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("$remainingChits Remaining", fontSize = 10.sp, color = Color.White.copy(alpha = 0.75f))
                    }
                }

                // Dates Row: Start Date (Left) and Expected Ending Date (Right)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Start Date",
                            fontSize = 10.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                        Text(
                            text = startDateText,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "Expected Ending Date",
                            fontSize = 10.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                        Text(
                            text = expectedEndDateText,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                    }
                }
            }

            HorizontalDivider(color = Color.White.copy(alpha = 0.12f), thickness = 0.8.dp)

            // 3 Key Stats Row - Compact height preserved
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ChitStatBoxCompact(
                    label = "Members",
                    value = "$totalMembers",
                    subtext = "Active participants",
                    modifier = Modifier.weight(1f)
                )
                ChitStatBoxCompact(
                    label = "Monthly Installment",
                    value = monthlyInstallment,
                    subtext = "Per member",
                    modifier = Modifier.weight(1.2f)
                )
                ChitStatBoxCompact(
                    label = "Cycle Frequency",
                    value = cycleFrequency.uppercase(),
                    subtext = "Scheduled",
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun ChitStatBoxCompact(
    label: String,
    value: String,
    subtext: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = Color.White.copy(alpha = 0.07f),
        border = BorderStroke(0.8.dp, Color.White.copy(alpha = 0.15f))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(1.dp)
        ) {
            Text(
                text = label,
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White.copy(alpha = 0.6f),
                maxLines = 1
            )
            Text(
                text = value,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1
            )
            Text(
                text = subtext,
                fontSize = 8.5.sp,
                color = Color.White.copy(alpha = 0.5f),
                maxLines = 1
            )
        }
    }
}

/**
 * Chit Round History Card (#11):
 * Preserves the exact approved visual design, displaying only the latest 2 completed rounds.
 */
@Composable
fun ChitRoundHistoryProductionCard(
    chitConfig: ChitFundConfig? = null,
    onViewAllHistory: () -> Unit
) {
    // Derive completed rounds dynamically from chitConfig if available, falling back to recent sample history
    val latestCompletedRounds = remember(chitConfig?.cycles) {
        val completedCycles = chitConfig?.cycles?.filter { it.status == ChitCycleStatus.COMPLETED }
            ?.sortedByDescending { it.cycleNumber }
            ?.take(2)

        if (!completedCycles.isNullOrEmpty()) {
            completedCycles.map { cycle ->
                val roundNo = cycle.cycleNumber
                val winner = cycle.winnerMemberName?.ifBlank { "Winner #$roundNo" } ?: "Winner #$roundNo"
                val discount = cycle.winningBidAmount?.let { CurrencyFormatter.formatIndian(it) } ?: "₹1,75,000"
                val net = cycle.winningBidAmount?.let { CurrencyFormatter.formatIndian(it) } ?: "₹8,25,000"
                val div = cycle.dividendPerMember?.let { CurrencyFormatter.formatIndian(it) } ?: "₹8,750"
                CompletedChitRound(roundNo, winner, discount, net, div, cycle.scheduledDate)
            }
        } else {
            listOf(
                CompletedChitRound(8, "Rajesh Sharma", "₹1,75,000", "₹8,25,000", "₹8,750", "28 Aug 2026"),
                CompletedChitRound(7, "Priya Mukherjee", "₹1,60,000", "₹8,40,000", "₹8,000", "28 Jul 2026")
            )
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = IndigoPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Chit Round History",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                TextButton(
                    onClick = onViewAllHistory,
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(
                        text = "View All",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                latestCompletedRounds.forEach { round ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Emerald500.copy(alpha = 0.15f),
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        val roundFmt = if (round.roundNumber < 10) "0${round.roundNumber}" else "${round.roundNumber}"
                                        Text("#$roundFmt", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                                    }
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(round.winnerName, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                                    Text("Net Payout: ${round.netDisbursed}", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = IndigoPrimary.copy(alpha = 0.12f)
                                ) {
                                    Text(
                                        text = "+${round.dividendPerMember} Div",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = IndigoPrimary,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                                Text(round.date, fontSize = 9.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Consolidated Configured Auction Rules Dialog (Phase D.0.25):
 * Displays full configured auction rules, bidding mechanism, dividend distribution,
 * floor/ceiling caps, and disbursement safeguards in an interactive modal.
 */
@Composable
fun ConfiguredAuctionRulesDetailDialog(
    chitConfig: ChitFundConfig,
    totalValue: Double,
    totalMembers: Int,
    currencySymbol: String,
    onDismiss: () -> Unit
) {
    val scheduleDay = chitConfig.auctionScheduleDay ?: 28
    val scheduleTime = chitConfig.auctionTime?.ifBlank { "08:00 PM" } ?: "08:00 PM"
    val frequency = chitConfig.frequency.ifBlank { "Monthly" }
    val totalChits = chitConfig.totalChits ?: totalMembers.coerceAtLeast(1)
    val monthlyInstallment = chitConfig.monthlyInstallment ?: (totalValue / totalChits.coerceAtLeast(1))

    val minDiscountPercent = 10
    val maxDiscountPercent = 30
    val minDiscountAmount = totalValue * (minDiscountPercent / 100.0)
    val maxDiscountAmount = totalValue * (maxDiscountPercent / 100.0)

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Header with icon, title, and close button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Gavel,
                            contentDescription = null,
                            tint = Amber500,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Configured Auction Rules",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", modifier = Modifier.size(18.dp))
                    }
                }

                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = Emerald500.copy(alpha = 0.12f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "● Transparent & Bylaw Compliant",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Emerald500
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    RuleDetailBlock(
                        number = "1",
                        title = "Auction Frequency & Schedule",
                        description = "$frequency every ${scheduleDay}th at $scheduleTime. All active participants are notified prior to window opening."
                    )
                    RuleDetailBlock(
                        number = "2",
                        title = "Pool Scheme & Contribution",
                        description = "Total Scheme Value: $currencySymbol${CurrencyFormatter.formatIndian(totalValue)} across $totalChits chits ($totalMembers members). Monthly installment is $currencySymbol${CurrencyFormatter.formatIndian(monthlyInstallment)} per member."
                    )
                    RuleDetailBlock(
                        number = "3",
                        title = "Reverse Bidding Mechanism",
                        description = "Subscribers bid the discount amount they are willing to forgo from the total chit value. The eligible member offering the highest discount wins the prize pool."
                    )
                    RuleDetailBlock(
                        number = "4",
                        title = "Floor & Ceiling Discount Caps",
                        description = "Minimum bid discount is $minDiscountPercent% ($currencySymbol${CurrencyFormatter.formatIndian(minDiscountAmount)}). Maximum discount ceiling is capped at $maxDiscountPercent% ($currencySymbol${CurrencyFormatter.formatIndian(maxDiscountAmount)}) to prevent predatory bidding."
                    )
                    RuleDetailBlock(
                        number = "5",
                        title = "Equal Dividend Distribution",
                        description = "The winning discount bid (minus 5% foreman commission) is distributed equally among all $totalMembers members as a dividend credit, reducing the subsequent month's installment."
                    )
                    RuleDetailBlock(
                        number = "6",
                        title = "One-Prize Policy & Continued Payment",
                        description = "Once a member successfully wins an auction, they are marked as Prized and cannot participate in subsequent bidding rounds. They must continue paying monthly installments until the scheme concludes."
                    )
                    RuleDetailBlock(
                        number = "7",
                        title = "Disbursement & Dual Authorization",
                        description = "Net prize payout disbursement requires dual verification and approval by the Admin and Treasurer."
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                ) {
                    Text("Got It", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun RuleDetailBlock(
    number: String,
    title: String,
    description: String
) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            text = "$number. $title",
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = IndigoPrimary
        )
        Text(
            text = description,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 15.sp
        )
    }
}

