package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.FeedbackWithVotes
import com.example.data.model.GroupChatMessage
import com.example.data.model.GroupFeedback
import com.example.data.model.GroupSettings
import com.example.data.model.InvestmentRecord
import com.example.data.model.LoanRequest
import com.example.data.model.LoanWithVotingDetails
import com.example.data.model.Member
import com.example.data.model.MemberFinancialProfile
import com.example.data.model.MemberWithMonthlyStatus
import com.example.data.model.MonthlySummary
import com.example.data.model.NotificationItem
import com.example.data.model.OverallGroupFinancials
import com.example.data.model.Payment
import com.example.data.model.PendingPaymentApprovalItem
import com.example.data.model.RecentTransaction
import com.example.data.model.SocietyNotice
import com.example.data.model.TransactionRecord
import com.example.data.repository.SocietyRepository
import com.example.utils.CurrencyFormatter
import com.example.utils.DateUtils
import com.example.utils.ReminderHelper
import com.example.utils.ReportExporter
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.util.Calendar

class SocietyViewModel(
    application: Application,
    private val repository: SocietyRepository
) : AndroidViewModel(application) {

    // Current selected month & year for Monthly view & reports
    private val calendar = Calendar.getInstance()
    private val _selectedMonth = MutableStateFlow(calendar.get(Calendar.MONTH) + 1)
    val selectedMonth: StateFlow<Int> = _selectedMonth.asStateFlow()

    private val _selectedYear = MutableStateFlow(calendar.get(Calendar.YEAR))
    val selectedYear: StateFlow<Int> = _selectedYear.asStateFlow()

    // Member search and status filter
    private val _memberSearchQuery = MutableStateFlow("")
    val memberSearchQuery: StateFlow<String> = _memberSearchQuery.asStateFlow()

    private val _statusFilter = MutableStateFlow("ALL") // "ALL", "PAID", "PARTIAL", "UNPAID", "PENDING"
    val statusFilter: StateFlow<String> = _statusFilter.asStateFlow()

    // Admin authentication state
    private val _isAdminUnlocked = MutableStateFlow(false)
    val isAdminUnlocked: StateFlow<Boolean> = _isAdminUnlocked.asStateFlow()

    private val _showPinDialog = MutableStateFlow(false)
    val showPinDialog: StateFlow<Boolean> = _showPinDialog.asStateFlow()

    private var pendingAdminAction: (() -> Unit)? = null

    // Selected member for profile inspection
    private val _selectedMemberId = MutableStateFlow<Long?>(null)
    val selectedMemberId: StateFlow<Long?> = _selectedMemberId.asStateFlow()

    // Toast message trigger
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    // Group Settings flow
    @OptIn(ExperimentalCoroutinesApi::class)
    val groupSettings: StateFlow<GroupSettings> = repository.groupSettings
        .flatMapLatest { settings ->
            MutableStateFlow(settings ?: GroupSettings())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = GroupSettings()
        )

    init {
        viewModelScope.launch {
            repository.groupSettings.collect { settings ->
                if (settings != null && (settings.groupName == "Pragati Welfare Samiti" || settings.groupName == "Samiti Welfare Fund" || settings.groupName.isBlank())) {
                    repository.updateSettings(settings.copy(groupName = "All services group"))
                }
            }
        }
    }

    // Pending payment approval items flow
    val pendingPaymentApprovals: StateFlow<List<PendingPaymentApprovalItem>> = repository.pendingPaymentApprovals
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Overall Comprehensive Financials
    val overallFinancials: StateFlow<OverallGroupFinancials> = repository.getComprehensiveFinancials()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = OverallGroupFinancials(
                totalMembers = 0,
                activeMembers = 0,
                totalCollectedAllTime = 0.0,
                totalDueAllTime = 0.0,
                currentMonthCollected = 0.0,
                currentMonthDue = 0.0,
                currentMonthPaidCount = 0,
                currentMonthUnpaidCount = 0,
                currentMonthPartialCount = 0,
                previousMonthCollected = 0.0,
                monthlyTrends = emptyList()
            )
        )

    // Monthly summary for currently selected month (Excludes pending approvals from confirmed collections)
    @OptIn(ExperimentalCoroutinesApi::class)
    val currentMonthSummary: StateFlow<MonthlySummary> = combine(
        _selectedMonth,
        _selectedYear,
        repository.allPayments,
        repository.activeMembers,
        repository.groupSettings
    ) { month, year, payments, members, settings ->
        val defExp = settings?.defaultContribution ?: 500.0
        val mPayments = payments.filter { it.month == month && it.year == year }
        val mApprovedPayments = mPayments.filter { it.isApproved }
        val totalMembers = members.size
        val totalExpected = members.sumOf { if (it.monthlyContribution > 0) it.monthlyContribution else defExp }
        val totalCollected = mApprovedPayments.sumOf { it.paidAmount }
        val totalDue = (totalExpected - totalCollected).coerceAtLeast(0.0)

        val paidCount = mApprovedPayments.count { it.status == "PAID" }
        val partialCount = mApprovedPayments.count { it.status == "PARTIAL" }
        val unpaidCount = (totalMembers - (paidCount + partialCount)).coerceAtLeast(0)
        val collectionPercentage = if (totalExpected > 0) ((totalCollected / totalExpected) * 100).toFloat() else 0f

        MonthlySummary(
            month = month,
            year = year,
            monthName = DateUtils.getMonthName(month),
            totalMembers = totalMembers,
            totalExpected = totalExpected,
            totalCollected = totalCollected,
            totalDue = totalDue,
            paidCount = paidCount,
            partialCount = partialCount,
            unpaidCount = unpaidCount,
            collectionPercentage = collectionPercentage
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = MonthlySummary(
            month = calendar.get(Calendar.MONTH) + 1,
            year = calendar.get(Calendar.YEAR),
            monthName = DateUtils.getMonthName(calendar.get(Calendar.MONTH) + 1),
            totalMembers = 0,
            totalExpected = 0.0,
            totalCollected = 0.0,
            totalDue = 0.0,
            paidCount = 0,
            partialCount = 0,
            unpaidCount = 0,
            collectionPercentage = 0f
        )
    )

    // Members with Monthly Status for the selected month
    val membersWithMonthlyStatus: StateFlow<List<MemberWithMonthlyStatus>> = combine(
        _selectedMonth,
        _selectedYear,
        repository.activeMembers,
        repository.allPayments,
        repository.groupSettings
    ) { month, year, members, payments, settings ->
        val defaultExp = settings?.defaultContribution ?: 500.0
        val mPayments = payments.filter { it.month == month && it.year == year }.associateBy { it.memberId }

        members.map { member ->
            val payment = mPayments[member.id]
            val expected = if (member.monthlyContribution > 0) member.monthlyContribution else defaultExp

            val displayStatus = when {
                payment == null -> "UNPAID"
                payment.isPendingApproval -> "PENDING_APPROVAL"
                payment.isRejected -> "REJECTED"
                else -> payment.status
            }

            val paid = if (payment != null && payment.isApproved) payment.paidAmount else 0.0
            val due = if (payment != null && payment.isApproved) payment.dueAmount else expected

            MemberWithMonthlyStatus(
                member = member,
                payment = payment,
                effectiveExpectedAmount = expected,
                paidAmount = paid,
                dueAmount = due,
                status = displayStatus
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Alias for monthlyMembersList
    val monthlyMembersList: StateFlow<List<MemberWithMonthlyStatus>> get() = membersWithMonthlyStatus

    // Filtered members list
    val filteredMembersWithStatus: StateFlow<List<MemberWithMonthlyStatus>> = combine(
        membersWithMonthlyStatus,
        _memberSearchQuery,
        _statusFilter
    ) { list, query, filter ->
        list.filter { item ->
            val matchesQuery = query.isBlank() ||
                    item.member.name.contains(query, ignoreCase = true) ||
                    item.member.memberCode.contains(query, ignoreCase = true) ||
                    item.member.phone.contains(query)

            val matchesFilter = when (filter) {
                "PAID" -> item.status == "PAID"
                "PARTIAL" -> item.status == "PARTIAL"
                "UNPAID" -> item.status == "UNPAID" || item.status == "REJECTED"
                "PENDING" -> item.status == "PENDING_APPROVAL"
                else -> true
            }

            matchesQuery && matchesFilter
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Pending Dues list
    val pendingDuesList: StateFlow<List<MemberWithMonthlyStatus>> = membersWithMonthlyStatus
        .flatMapLatest { list ->
            MutableStateFlow(list.filter { it.status in listOf("UNPAID", "PARTIAL", "REJECTED") && it.dueAmount > 0 })
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // All Members
    val allMembers: StateFlow<List<Member>> = repository.allMembers
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Active Members & Alias
    val activeMembers: StateFlow<List<Member>> = repository.activeMembers
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allActiveMembers: StateFlow<List<Member>> get() = activeMembers

    // Recent Transactions (Approved only)
    val recentTransactions: StateFlow<List<RecentTransaction>> = repository.getRecentTransactions(10)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Loans with 70% Voting Details & Alias
    val allLoansWithVotes: StateFlow<List<LoanWithVotingDetails>> = repository.loansWithVotingDetails
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val loansWithVoting: StateFlow<List<LoanWithVotingDetails>> get() = allLoansWithVotes

    // Investments (soft-deleted are filtered out in DAO)
    val allInvestments: StateFlow<List<InvestmentRecord>> = repository.allInvestments
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Feedback & Proposals with Votes & Alias
    val allFeedbacksWithVotes: StateFlow<List<FeedbackWithVotes>> = repository.feedbacksWithVotes
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val feedbacksWithVotes: StateFlow<List<FeedbackWithVotes>> get() = allFeedbacksWithVotes

    // Notifications
    val allNotifications: StateFlow<List<NotificationItem>> = repository.allNotifications
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val unreadNotificationsCount: StateFlow<Int> = repository.unreadNotificationsCount
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    // General Financial Ledger Transactions
    val allTransactions: StateFlow<List<TransactionRecord>> = repository.allTransactions
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Notices
    val notices: StateFlow<List<SocietyNotice>> = repository.notices
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Group Chat Messages
    val chatMessages: StateFlow<List<GroupChatMessage>> = repository.chatMessages
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Profile inspection flow & Alias
    @OptIn(ExperimentalCoroutinesApi::class)
    val memberProfile: StateFlow<MemberFinancialProfile?> = _selectedMemberId
        .flatMapLatest { id ->
            if (id != null) repository.getMemberFinancialProfile(id) else MutableStateFlow(null)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    val selectedMemberProfile: StateFlow<MemberFinancialProfile?> get() = memberProfile

    fun selectMember(id: Long) {
        _selectedMemberId.value = id
    }

    // -------------------------------------------------------------
    // UI State Modification Functions
    // -------------------------------------------------------------
    fun selectMonthYear(month: Int, year: Int) {
        _selectedMonth.value = month
        _selectedYear.value = year
    }

    fun prevMonth() {
        if (_selectedMonth.value == 1) {
            _selectedMonth.value = 12
            _selectedYear.value -= 1
        } else {
            _selectedMonth.value -= 1
        }
    }

    fun nextMonth() {
        if (_selectedMonth.value == 12) {
            _selectedMonth.value = 1
            _selectedYear.value += 1
        } else {
            _selectedMonth.value += 1
        }
    }

    fun setSearchQuery(query: String) {
        _memberSearchQuery.value = query
    }

    fun setStatusFilter(filter: String) {
        _statusFilter.value = filter
    }

    fun setSelectedMemberId(id: Long?) {
        _selectedMemberId.value = id
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun showToast(msg: String) {
        _userMessage.value = msg
    }

    // -------------------------------------------------------------
    // Admin Security Actions
    // -------------------------------------------------------------
    fun requestAdminAction(onUnlocked: () -> Unit) {
        if (_isAdminUnlocked.value) {
            onUnlocked()
        } else {
            pendingAdminAction = onUnlocked
            _showPinDialog.value = true
        }
    }

    fun dismissPinDialog() {
        _showPinDialog.value = false
        pendingAdminAction = null
    }

    fun verifyPin(pin: String): Boolean {
        val currentPin = groupSettings.value.adminPin
        if (pin == currentPin || (currentPin.isBlank() && pin == "1234")) {
            _isAdminUnlocked.value = true
            _showPinDialog.value = false
            pendingAdminAction?.invoke()
            pendingAdminAction = null
            return true
        }
        return false
    }

    // Current Logged-in / Selected Member Profile Identity (for self-service permission)
    private val _currentMemberId = MutableStateFlow<Long?>(null)
    val currentMemberId: StateFlow<Long?> = _currentMemberId.asStateFlow()

    fun setCurrentMemberId(id: Long?) {
        _currentMemberId.value = id
    }

    fun canEditMember(targetMemberId: Long): Boolean {
        if (_isAdminUnlocked.value) return true
        val currentId = _currentMemberId.value
        return currentId != null && currentId == targetMemberId
    }

    fun isCurrentMember(targetMemberId: Long): Boolean {
        val currentId = _currentMemberId.value
        return currentId != null && currentId == targetMemberId
    }

    fun lockAdmin() {
        _isAdminUnlocked.value = false
    }

    // -------------------------------------------------------------
    // Member Operations
    // -------------------------------------------------------------
    fun saveMember(
        id: Long = 0L,
        memberCode: String,
        name: String,
        phone: String,
        address: String,
        monthlyContribution: Double,
        photoUri: String = "",
        isActive: Boolean = true,
        notes: String = "",
        onSuccess: () -> Unit
    ) {
        val member = Member(
            id = id,
            memberCode = memberCode.trim().ifBlank { "M-${System.currentTimeMillis() % 10000}" },
            name = name.trim(),
            phone = phone.trim(),
            address = address.trim(),
            monthlyContribution = monthlyContribution,
            photoUri = photoUri,
            isActive = isActive,
            notes = notes.trim()
        )
        saveMember(member, onSuccess)
    }

    fun saveMember(member: Member, onSuccess: () -> Unit) {
        viewModelScope.launch {
            if (member.name.isBlank()) {
                _userMessage.value = "Member name cannot be empty"
                return@launch
            }

            val isAdmin = _isAdminUnlocked.value
            val isSelf = (_currentMemberId.value != null && _currentMemberId.value == member.id)

            if (member.id == 0L) {
                // Only Admin can add brand new members to the society
                if (!isAdmin) {
                    _userMessage.value = "Permission Denied: Only Admin can add new members"
                    return@launch
                }
                val newId = repository.insertMember(member)
                if (_currentMemberId.value == null) {
                    _currentMemberId.value = newId
                }
                _userMessage.value = "Member added successfully"
                onSuccess()
            } else {
                // Editing an existing member
                if (!isAdmin && !isSelf) {
                    _userMessage.value = "Permission Denied: Members can only edit their own profile"
                    return@launch
                }

                if (!isAdmin && isSelf) {
                    // Member editing own profile: keep admin-controlled fields unchanged
                    val existing = repository.getMemberById(member.id)
                    if (existing != null) {
                        val sanitized = member.copy(
                            memberCode = existing.memberCode,
                            monthlyContribution = existing.monthlyContribution,
                            isActive = existing.isActive,
                            joinDate = existing.joinDate
                        )
                        repository.updateMember(sanitized)
                        _userMessage.value = "Your profile has been updated"
                        onSuccess()
                        return@launch
                    }
                }

                repository.updateMember(member)
                _userMessage.value = "Member updated successfully"
                onSuccess()
            }
        }
    }

    fun deleteMember(member: Member, onSuccess: () -> Unit) {
        viewModelScope.launch {
            if (!_isAdminUnlocked.value) {
                _userMessage.value = "Permission Denied: Only Admin can delete members"
                return@launch
            }
            repository.deleteMember(member)
            _userMessage.value = "Member deleted successfully"
            onSuccess()
        }
    }

    // -------------------------------------------------------------
    // Payment Submission & Approval Operations
    // -------------------------------------------------------------
    fun submitPayment(
        memberId: Long,
        month: Int,
        year: Int,
        expectedAmount: Double,
        paidAmount: Double,
        paymentDate: Long,
        paymentMethod: String,
        transactionRef: String,
        notes: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val member = repository.getMemberById(memberId)
            val memberName = member?.name ?: "Member #$memberId"

            val payment = Payment(
                memberId = memberId,
                month = month,
                year = year,
                expectedAmount = expectedAmount,
                paidAmount = paidAmount,
                dueAmount = (expectedAmount - paidAmount).coerceAtLeast(0.0),
                paymentDate = paymentDate,
                paymentMethod = paymentMethod,
                transactionReference = transactionRef.trim(),
                notes = notes.trim(),
                status = "PENDING_APPROVAL",
                approvalStatus = "PENDING_APPROVAL",
                submittedAt = System.currentTimeMillis()
            )

            if (_isAdminUnlocked.value) {
                // Admin recording payment directly -> instantly approved
                repository.recordPayment(payment, groupSettings.value.adminName)
                _userMessage.value = "Payment confirmed & recorded: ₹${CurrencyFormatter.formatIndian(paidAmount)}"
            } else {
                // Member recording payment -> submitted for admin approval
                repository.submitPaymentForApproval(payment, memberName)
                _userMessage.value = "Payment submitted for Admin Approval. It will reflect in confirmed totals once verified."
            }
            onSuccess()
        }
    }

    fun recordPayment(
        memberId: Long,
        month: Int,
        year: Int,
        expectedAmount: Double,
        paidAmount: Double,
        paymentDate: Long,
        paymentMethod: String,
        transactionRef: String,
        notes: String,
        onSuccess: () -> Unit
    ) {
        submitPayment(
            memberId = memberId,
            month = month,
            year = year,
            expectedAmount = expectedAmount,
            paidAmount = paidAmount,
            paymentDate = paymentDate,
            paymentMethod = paymentMethod,
            transactionRef = transactionRef,
            notes = notes,
            onSuccess = onSuccess
        )
    }

    fun approvePayment(paymentId: Long, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            if (!_isAdminUnlocked.value) {
                requestAdminAction {
                    approvePayment(paymentId, onSuccess)
                }
                return@launch
            }
            val success = repository.approvePayment(paymentId, groupSettings.value.adminName)
            if (success) {
                _userMessage.value = "Payment verified and approved successfully!"
                onSuccess()
            } else {
                _userMessage.value = "Failed to approve payment."
            }
        }
    }

    fun rejectPayment(paymentId: Long, reason: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            if (!_isAdminUnlocked.value) {
                requestAdminAction {
                    rejectPayment(paymentId, reason, onSuccess)
                }
                return@launch
            }
            val success = repository.rejectPayment(paymentId, groupSettings.value.adminName, reason)
            if (success) {
                _userMessage.value = "Payment has been rejected."
                onSuccess()
            } else {
                _userMessage.value = "Failed to reject payment."
            }
        }
    }

    fun quickMarkPaid(
        memberId: Long,
        month: Int,
        year: Int,
        amount: Double,
        paymentMethod: String = "Cash",
        reference: String = "",
        notes: String = ""
    ) {
        viewModelScope.launch {
            if (!_isAdminUnlocked.value) {
                requestAdminAction {
                    quickMarkPaid(memberId, month, year, amount, paymentMethod, reference, notes)
                }
                return@launch
            }
            repository.quickMarkPaid(memberId, month, year, amount, paymentMethod, groupSettings.value.adminName)
            _userMessage.value = "Marked as Paid: ₹${CurrencyFormatter.formatIndian(amount)}"
        }
    }

    // -------------------------------------------------------------
    // Settings & Configuration
    // -------------------------------------------------------------
    fun updateSettings(settings: GroupSettings, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            if (!_isAdminUnlocked.value) {
                _userMessage.value = "Permission Denied: Admin authentication required"
                return@launch
            }
            repository.updateSettings(settings)
            _userMessage.value = "Settings updated successfully"
            onSuccess()
        }
    }

    fun updateGroupSettings(settings: GroupSettings, onSuccess: () -> Unit = {}) {
        updateSettings(settings, onSuccess)
    }

    fun resetToDemoData(onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            _userMessage.value = "Data reset to default"
            onSuccess()
        }
    }

    // -------------------------------------------------------------
    // Notices Operations
    // -------------------------------------------------------------
    fun postNotice(title: String, content: String, category: String, author: String, isPinned: Boolean, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            if (title.isBlank() || content.isBlank()) {
                _userMessage.value = "Title and Content are required"
                return@launch
            }
            val notice = SocietyNotice(
                title = title.trim(),
                content = content.trim(),
                category = category,
                author = if (author.isBlank()) "Admin" else author.trim(),
                isPinned = isPinned
            )
            repository.addNotice(notice)
            _userMessage.value = "Notice published successfully"
            onSuccess()
        }
    }

    fun togglePinNotice(notice: SocietyNotice) {
        viewModelScope.launch {
            repository.updateNotice(notice.copy(isPinned = !notice.isPinned))
            _userMessage.value = if (!notice.isPinned) "Notice pinned to top" else "Notice unpinned"
        }
    }

    fun deleteNotice(notice: SocietyNotice) {
        viewModelScope.launch {
            if (!_isAdminUnlocked.value) {
                _userMessage.value = "Permission Denied: Only Admin can delete notices"
                return@launch
            }
            repository.deleteNotice(notice)
            _userMessage.value = "Notice removed"
        }
    }

    fun broadcastNotice(context: Context, notice: SocietyNotice) {
        val settings = groupSettings.value
        val text = ReminderHelper.generateNoticeBroadcastText(
            groupName = settings.groupName,
            title = notice.title,
            content = notice.content,
            author = notice.author,
            adminPhone = settings.adminPhone
        )
        ReminderHelper.shareText(context, text, "Broadcast Notice")
    }

    // -------------------------------------------------------------
    // Loans & 70% Voting Actions
    // -------------------------------------------------------------
    fun submitLoanRequest(
        requesterMemberId: Long,
        requesterName: String,
        requesterPhone: String,
        amount: Double,
        purpose: String,
        reason: String,
        duration: Int,
        durationUnit: String,
        note: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            if (amount <= 0) {
                _userMessage.value = "Please enter a valid loan amount"
                return@launch
            }
            if (reason.isBlank()) {
                _userMessage.value = "Please specify reason for loan request"
                return@launch
            }
            val durationMillis = if (durationUnit == "Days") duration * 86400000L else duration * 30L * 86400000L
            val loan = LoanRequest(
                requesterMemberId = requesterMemberId,
                requesterName = requesterName,
                requesterPhone = requesterPhone,
                requestedAmount = amount,
                purpose = purpose,
                reason = reason,
                duration = duration,
                durationUnit = durationUnit,
                expectedRepaymentDate = System.currentTimeMillis() + durationMillis,
                note = note,
                votingDeadline = System.currentTimeMillis() + (48L * 3600000L),
                status = "VOTING",
                remainingAmount = amount
            )
            repository.submitLoanRequest(loan)
            _userMessage.value = "Loan request submitted for group 70% voting approval"
            onSuccess()
        }
    }

    fun castLoanVote(loanId: Long, memberId: Long, memberName: String, vote: String) {
        viewModelScope.launch {
            val success = repository.voteOnLoan(loanId, memberId, memberName, vote)
            if (success) {
                _userMessage.value = "Vote recorded ($vote)"
            } else {
                _userMessage.value = "Unable to record vote (Check voting rules / deadline)"
            }
        }
    }

    fun disburseLoan(loanId: Long, adminName: String) {
        viewModelScope.launch {
            if (!_isAdminUnlocked.value) {
                _userMessage.value = "Permission Denied: Only Admin can disburse loans"
                return@launch
            }
            val success = repository.disburseLoan(loanId, adminName)
            if (success) {
                _userMessage.value = "Loan disbursed successfully. Funds deducted from group cash balance."
            } else {
                _userMessage.value = "Disbursement failed. Ensure loan is approved."
            }
        }
    }

    fun recordLoanRepayment(loanId: Long, amount: Double, paymentMethod: String, notes: String) {
        viewModelScope.launch {
            if (amount <= 0) {
                _userMessage.value = "Please enter a valid repayment amount"
                return@launch
            }
            val success = repository.recordLoanRepayment(loanId, amount, paymentMethod, notes, groupSettings.value.adminName)
            if (success) {
                _userMessage.value = "Loan repayment of ₹${amount.toInt()} recorded. Balance updated."
            } else {
                _userMessage.value = "Failed to record loan repayment"
            }
        }
    }

    // -------------------------------------------------------------
    // Investments Actions (Including Admin Soft Delete with Confirmation)
    // -------------------------------------------------------------
    fun addInvestment(
        type: String,
        institution: String,
        name: String,
        principal: Double,
        currentValue: Double,
        notes: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            if (!_isAdminUnlocked.value) {
                _userMessage.value = "Permission Denied: Only Admin can record investments"
                return@launch
            }
            if (principal <= 0 || name.isBlank()) {
                _userMessage.value = "Please provide name and valid principal amount"
                return@launch
            }
            val inv = InvestmentRecord(
                type = type,
                institution = institution.trim(),
                name = name.trim(),
                principalAmount = principal,
                currentValue = if (currentValue > 0) currentValue else principal,
                notes = notes.trim()
            )
            repository.addInvestment(inv)
            _userMessage.value = "Investment recorded: ₹${CurrencyFormatter.formatIndian(principal)}"
            onSuccess()
        }
    }

    fun updateInvestmentValue(investment: InvestmentRecord, newValue: Double) {
        viewModelScope.launch {
            if (!_isAdminUnlocked.value) {
                _userMessage.value = "Permission Denied: Only Admin can update investments"
                return@launch
            }
            repository.updateInvestment(investment.copy(currentValue = newValue))
            _userMessage.value = "Investment valuation updated to ₹${CurrencyFormatter.formatIndian(newValue)}"
        }
    }

    fun deleteInvestment(investmentId: Long, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            if (!_isAdminUnlocked.value) {
                _userMessage.value = "Permission Denied: Only Admin can delete investments"
                return@launch
            }
            val success = repository.deleteInvestment(investmentId, groupSettings.value.adminName)
            if (success) {
                _userMessage.value = "Investment archived and removed from active portfolio."
                onSuccess()
            } else {
                _userMessage.value = "Failed to delete investment."
            }
        }
    }

    // -------------------------------------------------------------
    // Group Feedback (Suggestions, Proposals, Complaints)
    // -------------------------------------------------------------
    fun submitFeedback(
        type: String,
        memberId: Long,
        memberName: String,
        isAnonymous: Boolean,
        subject: String,
        description: String,
        requiresVoting: Boolean,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            if (subject.isBlank() || description.isBlank()) {
                _userMessage.value = "Subject and Description are required"
                return@launch
            }
            val fb = GroupFeedback(
                type = type,
                memberId = memberId,
                memberName = if (isAnonymous) "Anonymous Member" else memberName,
                isAnonymous = isAnonymous,
                subject = subject.trim(),
                description = description.trim(),
                requiresVoting = requiresVoting,
                votingThresholdPercent = 70
            )
            repository.submitFeedback(fb)
            _userMessage.value = "$type submitted successfully"
            onSuccess()
        }
    }

    fun voteOnProposal(feedbackId: Long, memberId: Long, memberName: String, vote: String) {
        viewModelScope.launch {
            repository.voteOnProposal(feedbackId, memberId, memberName, vote)
            _userMessage.value = "Proposal vote recorded ($vote)"
        }
    }

    // -------------------------------------------------------------
    // Notifications & Chat Actions
    // -------------------------------------------------------------
    fun markNotificationRead(id: Long) {
        viewModelScope.launch { repository.markNotificationRead(id) }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsRead()
            _userMessage.value = "All notifications marked as read"
        }
    }

    fun sendChatMessage(senderId: Long, senderName: String, senderRole: String, message: String, isAnnouncement: Boolean) {
        viewModelScope.launch {
            if (message.isBlank()) return@launch
            val chat = GroupChatMessage(
                senderId = senderId,
                senderName = senderName,
                senderRole = senderRole,
                message = message.trim(),
                isAnnouncement = isAnnouncement
            )
            repository.sendChatMessage(chat)
        }
    }

    // -------------------------------------------------------------
    // Reminders & Communication
    // -------------------------------------------------------------
    fun sendReminder(context: Context, member: Member, dueAmount: Double, month: Int, year: Int) {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(month)
        val text = ReminderHelper.generateReminderText(
            member = member,
            groupName = settings.groupName,
            monthName = monthName,
            year = year,
            dueAmount = dueAmount,
            currencySymbol = settings.currencySymbol,
            adminName = settings.adminName,
            adminPhone = settings.adminPhone
        )
        if (member.phone.isNotBlank()) {
            ReminderHelper.sendWhatsAppReminder(context, member.phone, text)
        } else {
            ReminderHelper.shareText(context, text, "Send Reminder")
        }
    }

    fun sendReminder(context: Context, member: Member, dueAmount: Double, channelOrMonth: String = "WHATSAPP") {
        if (channelOrMonth.equals("WHATSAPP", ignoreCase = true) || channelOrMonth.equals("SMS", ignoreCase = true) || channelOrMonth.equals("SHARE", ignoreCase = true)) {
            val settings = groupSettings.value
            val monthName = DateUtils.getMonthName(_selectedMonth.value)
            val year = _selectedYear.value
            val text = ReminderHelper.generateReminderText(
                member = member,
                groupName = settings.groupName,
                monthName = monthName,
                year = year,
                dueAmount = dueAmount,
                currencySymbol = settings.currencySymbol,
                adminName = settings.adminName,
                adminPhone = settings.adminPhone
            )
            when (channelOrMonth.uppercase()) {
                "WHATSAPP" -> {
                    if (member.phone.isNotBlank()) {
                        ReminderHelper.sendWhatsAppReminder(context, member.phone, text)
                    } else {
                        ReminderHelper.shareText(context, text, "Send Reminder")
                    }
                }
                "SMS" -> {
                    ReminderHelper.sendSmsReminder(context, member.phone, text)
                }
                else -> {
                    ReminderHelper.shareText(context, text, "Send Reminder")
                }
            }
        } else {
            val monthInt = DateUtils.parseMonthName(channelOrMonth)
            sendReminder(context, member, dueAmount, monthInt, _selectedYear.value)
        }
    }

    fun sendReminder(context: Context, member: Member, dueAmount: Double, monthName: String, year: Int) {
        val monthInt = DateUtils.parseMonthName(monthName)
        sendReminder(context, member, dueAmount, monthInt, year)
    }

    fun sendCustomMemberMessage(context: Context, member: Member, message: String) {
        if (member.phone.isNotBlank()) {
            ReminderHelper.sendWhatsAppReminder(context, member.phone, message)
        } else {
            ReminderHelper.shareText(context, message, "Send Message to ${member.name}")
        }
    }

    // -------------------------------------------------------------
    // Report Exporting (PDF / CSV)
    // -------------------------------------------------------------
    fun exportMonthlyReportPdf(context: Context, month: Int = _selectedMonth.value, year: Int = _selectedYear.value) {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(month)
        val list = membersWithMonthlyStatus.value
        val summary = currentMonthSummary.value

        val headers = listOf("Code", "Name", "Expected", "Paid", "Due", "Status")
        val rows = list.map { item ->
            listOf(
                item.member.memberCode,
                item.member.name,
                "₹${item.effectiveExpectedAmount.toInt()}",
                "₹${item.paidAmount.toInt()}",
                "₹${item.dueAmount.toInt()}",
                item.status
            )
        }
        val summaryMap = mapOf(
            "Total Expected" to "₹${summary.totalExpected.toInt()}",
            "Total Collected" to "₹${summary.totalCollected.toInt()}",
            "Total Due" to "₹${summary.totalDue.toInt()}",
            "Collection" to "${summary.collectionPercentage.toInt()}%"
        )

        val file = ReportExporter.generatePdfReport(
            context = context,
            settings = settings,
            reportTitle = "Monthly Collection Report",
            subtitle = "$monthName $year",
            headers = headers,
            rows = rows,
            summaryMap = summaryMap
        )
        if (file != null) {
            ReportExporter.shareFile(context, file, "application/pdf", "Share Monthly Report")
        } else {
            Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportPendingDuesPdf(context: Context, month: Int = _selectedMonth.value, year: Int = _selectedYear.value) {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(month)
        val list = pendingDuesList.value
        val totalDue = list.sumOf { it.dueAmount }

        val headers = listOf("Code", "Name", "Phone", "Expected", "Paid", "Due")
        val rows = list.map { item ->
            listOf(
                item.member.memberCode,
                item.member.name,
                item.member.phone,
                "₹${item.effectiveExpectedAmount.toInt()}",
                "₹${item.paidAmount.toInt()}",
                "₹${item.dueAmount.toInt()}"
            )
        }
        val summaryMap = mapOf(
            "Pending Members" to "${list.size}",
            "Total Outstanding" to "₹${totalDue.toInt()}"
        )

        val file = ReportExporter.generatePdfReport(
            context = context,
            settings = settings,
            reportTitle = "Pending Dues Report",
            subtitle = "$monthName $year",
            headers = headers,
            rows = rows,
            summaryMap = summaryMap
        )
        if (file != null) {
            ReportExporter.shareFile(context, file, "application/pdf", "Share Pending Dues")
        } else {
            Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportMemberLedgerPdf(context: Context, profile: MemberFinancialProfile) {
        val settings = groupSettings.value
        val headers = listOf("Month/Year", "Expected", "Paid", "Due", "Status", "Date")
        val rows = profile.paymentHistory.map { item ->
            listOf(
                "${item.monthName} ${item.year}",
                "₹${item.expectedAmount.toInt()}",
                "₹${item.paidAmount.toInt()}",
                "₹${item.dueAmount.toInt()}",
                item.status,
                if (item.paymentDate != null && item.paymentDate > 0) DateUtils.formatDisplayDate(item.paymentDate) else "-"
            )
        }
        val summaryMap = mapOf(
            "Member" to profile.member.name,
            "Total Paid" to "₹${profile.totalPaidAllTime.toInt()}",
            "Total Due" to "₹${profile.totalDueAllTime.toInt()}"
        )

        val file = ReportExporter.generatePdfReport(
            context = context,
            settings = settings,
            reportTitle = "Member Statement",
            subtitle = "${profile.member.name} (${profile.member.memberCode})",
            headers = headers,
            rows = rows,
            summaryMap = summaryMap
        )
        if (file != null) {
            ReportExporter.shareFile(context, file, "application/pdf", "Share Member Statement")
        } else {
            Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportMemberLedgerPdf(context: Context, memberId: Long) {
        val profile = memberProfile.value ?: return
        exportMemberLedgerPdf(context, profile)
    }

    fun exportMonthlyReportCsv(context: Context, month: Int = _selectedMonth.value, year: Int = _selectedYear.value) {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(month)
        val file = ReportExporter.exportMonthlyCsv(context, settings, monthName, year, membersWithMonthlyStatus.value)
        if (file != null) {
            ReportExporter.shareFile(context, file, "text/csv", "Share Monthly CSV")
        } else {
            Toast.makeText(context, "Failed to export CSV", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportPendingDuesCsv(context: Context, month: Int = _selectedMonth.value, year: Int = _selectedYear.value) {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(month)
        val file = ReportExporter.exportPendingDuesCsv(context, settings, monthName, year, pendingDuesList.value)
        if (file != null) {
            ReportExporter.shareFile(context, file, "text/csv", "Share Pending Dues CSV")
        } else {
            Toast.makeText(context, "Failed to export CSV", Toast.LENGTH_SHORT).show()
        }
    }

    // -------------------------------------------------------------
    // Backup & Restore
    // -------------------------------------------------------------
    fun exportBackupJson(context: Context) {
        viewModelScope.launch {
            if (!_isAdminUnlocked.value) {
                _userMessage.value = "Permission Denied: Only Admin can export system backup"
                return@launch
            }
            try {
                val jsonString = repository.exportDataAsJson()
                val file = File(context.cacheDir, "Samiti_Backup_${System.currentTimeMillis()}.json")
                file.writeText(jsonString)
                ReportExporter.shareFile(context, file, "application/json", "Share Backup File")
            } catch (e: Exception) {
                _userMessage.value = "Backup export failed: ${e.message}"
            }
        }
    }

    fun restoreBackupJson(context: Context, uri: Uri, onSuccess: (Boolean) -> Unit) {
        viewModelScope.launch {
            if (!_isAdminUnlocked.value) {
                _userMessage.value = "Permission Denied: Only Admin can restore system backup"
                return@launch
            }
            try {
                val content = context.contentResolver.openInputStream(uri)?.use { stream ->
                    stream.bufferedReader().readText()
                } ?: ""
                val success = repository.restoreDataFromJson(content)
                if (success) {
                    _userMessage.value = "Data restored successfully!"
                } else {
                    _userMessage.value = "Failed to restore data. Invalid file format."
                }
                onSuccess(success)
            } catch (e: Exception) {
                _userMessage.value = "Restore error: ${e.message}"
                onSuccess(false)
            }
        }
    }

    fun restoreBackupJson(jsonString: String, onSuccess: (Boolean) -> Unit) {
        viewModelScope.launch {
            if (!_isAdminUnlocked.value) {
                _userMessage.value = "Permission Denied: Only Admin can restore system backup"
                return@launch
            }
            try {
                val success = repository.restoreDataFromJson(jsonString)
                if (success) {
                    _userMessage.value = "Data restored successfully!"
                } else {
                    _userMessage.value = "Failed to restore data. Invalid file format."
                }
                onSuccess(success)
            } catch (e: Exception) {
                _userMessage.value = "Restore error: ${e.message}"
                onSuccess(false)
            }
        }
    }

    companion object {
        fun provideFactory(application: Application): ViewModelProvider.Factory {
            val database = AppDatabase.getDatabase(application)
            val repository = SocietyRepository(
                memberDao = database.memberDao(),
                paymentDao = database.paymentDao(),
                groupSettingsDao = database.groupSettingsDao(),
                noticeDao = database.noticeDao(),
                loanDao = database.loanDao(),
                investmentDao = database.investmentDao(),
                feedbackDao = database.feedbackDao(),
                notificationDao = database.notificationDao(),
                transactionDao = database.transactionDao(),
                auditLogDao = database.auditLogDao(),
                chatMessageDao = database.chatMessageDao()
            )
            return SocietyViewModelFactory(application, repository)
        }
    }
}

class SocietyViewModelFactory(
    private val application: Application,
    private val repository: SocietyRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SocietyViewModel::class.java)) {
            return SocietyViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
