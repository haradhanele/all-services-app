package com.adr.groupledger.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.adr.groupledger.data.model.PreAuthorizedMember
import kotlinx.coroutines.flow.Flow

@Dao
interface PreAuthorizedMemberDao {
    @Query("SELECT * FROM pre_authorized_members WHERE groupId = :groupId ORDER BY addedAt DESC")
    fun getPreAuthorizedMembersFlow(groupId: Long): Flow<List<PreAuthorizedMember>>

    @Query("SELECT * FROM pre_authorized_members WHERE groupId = :groupId ORDER BY addedAt DESC")
    suspend fun getPreAuthorizedMembersDirect(groupId: Long): List<PreAuthorizedMember>

    @Query("SELECT * FROM pre_authorized_members WHERE groupId = :groupId AND LOWER(email) = LOWER(:email) LIMIT 1")
    suspend fun findByEmailDirect(groupId: Long, email: String): PreAuthorizedMember?

    @Query("SELECT * FROM pre_authorized_members WHERE groupId = :groupId AND LOWER(email) = LOWER(:email) AND status = 'unclaimed' LIMIT 1")
    suspend fun findUnclaimedByEmailDirect(groupId: Long, email: String): PreAuthorizedMember?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(member: PreAuthorizedMember): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(members: List<PreAuthorizedMember>)

    @Update
    suspend fun update(member: PreAuthorizedMember)

    @Query("DELETE FROM pre_authorized_members WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM pre_authorized_members WHERE groupId = :groupId")
    suspend fun deleteForGroup(groupId: Long)

    @Transaction
    suspend fun syncAll(groupId: Long, list: List<PreAuthorizedMember>) {
        deleteForGroup(groupId)
        if (list.isNotEmpty()) {
            insertAll(list)
        }
    }
}
