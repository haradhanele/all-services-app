package com.adr.groupledger.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AppRegistration
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.BorderLight
import com.adr.groupledger.ui.theme.CardWhite
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.TextSlate400
import com.adr.groupledger.ui.theme.TextSlate500
import com.adr.groupledger.ui.theme.TextSlate800
import com.adr.groupledger.ui.theme.appOutlinedTextFieldColors
import com.adr.groupledger.ui.viewmodel.SocietyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileDetailsScreen(
    viewModel: SocietyViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val allGroups by viewModel.allGroups.collectAsStateWithLifecycle()
    val userMemberships by viewModel.userMemberships.collectAsStateWithLifecycle()
    val currentUserId by viewModel.currentUserId.collectAsStateWithLifecycle()

    val isSignedUpUser = currentUser?.isAccountCompleted == true || (currentUser?.email?.contains("@groupledger.org") != true && currentUser != null)

    val managedGroups = remember(allGroups, userMemberships, currentUser, currentUserId) {
        val uid = currentUser?.id ?: currentUserId
        val userPhone = currentUser?.phone?.trim().orEmpty()
        val userEmail = currentUser?.email?.trim().orEmpty()
        val userName = currentUser?.fullName?.trim().orEmpty()

        allGroups.filter { g ->
            g.createdByUserId == uid ||
            userMemberships.any { m -> m.groupId == g.id && m.role.equals("ADMIN", ignoreCase = true) } ||
            (userPhone.isNotBlank() && g.adminPhone.isNotBlank() && g.adminPhone.trim() == userPhone) ||
            (userEmail.isNotBlank() && g.contactEmail.isNotBlank() && g.contactEmail.trim().equals(userEmail, ignoreCase = true)) ||
            (userName.isNotBlank() && g.adminName.isNotBlank() && g.adminName.trim().equals(userName, ignoreCase = true))
        }.distinctBy { it.id }
    }

    val joinedGroups = remember(allGroups, userMemberships, currentUser, currentUserId, managedGroups) {
        val managedIds = managedGroups.map { it.id }.toSet()
        allGroups.filter { g ->
            g.id !in managedIds &&
            userMemberships.any { m -> m.groupId == g.id && !m.role.equals("ADMIN", ignoreCase = true) }
        }.distinctBy { it.id }
    }

    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var isSaving by remember { mutableStateOf(false) }
    var nameError by remember { mutableStateOf<String?>(null) }

    // For Guest user upgrade
    var upgradePassword by remember { mutableStateOf("") }
    var upgradeError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(currentUser) {
        currentUser?.let { user ->
            fullName = user.fullName
            email = if (user.email.contains("@groupledger.org")) "" else user.email
            phone = user.phone
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "User Profile Details",
                            fontWeight = FontWeight.Bold,
                            color = TextSlate800,
                            fontSize = 17.sp
                        )
                        Text(
                            text = if (isSignedUpUser) "Registered Account • Full Admin Rights" else "Guest Account • Joined via Code",
                            fontSize = 11.5.sp,
                            color = IndigoPrimary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextSlate800)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CardWhite
                )
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .testTag("user_profile_details_screen"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Profile Header Card with Avatar
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = IndigoPrimary,
                        modifier = Modifier.size(54.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = fullName.firstOrNull()?.uppercase() ?: "U",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = fullName.ifBlank { "User Account" },
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSlate800
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = email.ifBlank { phone.ifBlank { "No contact specified" } },
                            fontSize = 12.sp,
                            color = TextSlate500
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (isSignedUpUser) IndigoPrimary.copy(alpha = 0.12f) else Amber500.copy(alpha = 0.12f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (isSignedUpUser) Icons.Default.Shield else Icons.Default.Person,
                                    contentDescription = null,
                                    tint = if (isSignedUpUser) IndigoPrimary else Amber500,
                                    modifier = Modifier.size(11.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isSignedUpUser) "Full Administrator Account" else "Guest Member Account",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSignedUpUser) IndigoPrimary else Amber500
                                )
                            }
                        }
                    }
                }
            }

            // Informative Banner Card (matching AddEditMemberScreen style)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = IndigoPrimary.copy(alpha = 0.08f)),
                border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.25f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.AccountCircle,
                        contentDescription = null,
                        tint = IndigoPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (isSignedUpUser)
                            "You have full administrative privileges to create societies, manage members, record collections, and export financial reports."
                        else
                            "You joined using an invitation code. Upgrade to a full account anytime to create and administer your own groups.",
                        fontSize = 12.sp,
                        color = TextSlate800,
                        lineHeight = 16.sp
                    )
                }
            }

            // 1. Personal Information Section
            Text(
                text = "1. PERSONAL PROFILE INFORMATION",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = IndigoPrimary,
                letterSpacing = 0.5.sp
            )

            // Full Name
            OutlinedTextField(
                value = fullName,
                onValueChange = {
                    fullName = it
                    nameError = null
                },
                label = { Text("Full Name *") },
                placeholder = { Text("e.g. Ramesh Kumar") },
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = IndigoPrimary) },
                isError = nameError != null,
                supportingText = {
                    if (nameError != null) Text(nameError!!, color = Rose500)
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("profile_name_input"),
                shape = RoundedCornerShape(10.dp),
                colors = appOutlinedTextFieldColors()
            )

            // Email Address
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email Address") },
                placeholder = { Text("e.g. user@example.com") },
                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = IndigoPrimary) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("profile_email_input"),
                shape = RoundedCornerShape(10.dp),
                colors = appOutlinedTextFieldColors()
            )

            // Phone Number
            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Phone Number") },
                placeholder = { Text("e.g. +91 98765 43210") },
                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = IndigoPrimary) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("profile_phone_input"),
                shape = RoundedCornerShape(10.dp),
                colors = appOutlinedTextFieldColors()
            )

            // If Guest user, show password field for upgrade
            if (!isSignedUpUser) {
                Text(
                    text = "UPGRADE TO FULL ADMIN ACCOUNT",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = Amber500,
                    letterSpacing = 0.5.sp
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Amber500.copy(alpha = 0.06f)),
                    border = BorderStroke(1.dp, Amber500.copy(alpha = 0.25f))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Set a secure password to unlock full society creation and administrator capabilities.",
                            fontSize = 12.sp,
                            color = TextSlate800,
                            lineHeight = 16.sp
                        )

                        upgradeError?.let { err ->
                            Text(text = err, color = Rose500, fontSize = 11.5.sp, fontWeight = FontWeight.Medium)
                        }

                        OutlinedTextField(
                            value = upgradePassword,
                            onValueChange = {
                                upgradePassword = it
                                upgradeError = null
                            },
                            label = { Text("Create Password (min 6 characters) *") },
                            placeholder = { Text("••••••••") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = Amber500) },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("upgrade_password_input"),
                            shape = RoundedCornerShape(10.dp),
                            colors = appOutlinedTextFieldColors()
                        )
                    }
                }
            }

            // 2. Society & Role Overview Section
            Text(
                text = "2. ASSOCIATED SOCIETIES & STATS",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = IndigoPrimary,
                letterSpacing = 0.5.sp
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Active Society",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSlate400,
                                fontSize = 10.sp
                            )
                            Text(
                                text = settings.groupName,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextSlate800
                            )
                            Text(
                                text = "ID #${settings.id} • Code: ${settings.inviteCode} • ${settings.groupType.ifBlank { "Society" }}",
                                fontSize = 11.sp,
                                color = TextSlate500
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Emerald500.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "Active",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Emerald500,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Managed stat (Green)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Emerald500.copy(alpha = 0.10f),
                            border = BorderStroke(1.dp, Emerald500.copy(alpha = 0.35f)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = Emerald500, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("Managed", fontSize = 10.sp, color = Emerald500, fontWeight = FontWeight.SemiBold)
                                    Text("${managedGroups.size} Groups", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Emerald500)
                                }
                            }
                        }

                        // Joined stat (Light Yellow / Amber)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Amber500.copy(alpha = 0.14f),
                            border = BorderStroke(1.dp, Amber500.copy(alpha = 0.40f)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Groups, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("Joined", fontSize = 10.sp, color = Color(0xFFB45309), fontWeight = FontWeight.SemiBold)
                                    Text("${joinedGroups.size} Groups", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB45309))
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Save / Update Button (matching AddEditMemberScreen style)
            Button(
                onClick = {
                    if (fullName.trim().isBlank()) {
                        nameError = "Full Name is required"
                        return@Button
                    }

                    if (!isSignedUpUser && upgradePassword.isNotBlank()) {
                        if (email.isBlank() || upgradePassword.length < 6) {
                            upgradeError = "Please enter a valid email and password (minimum 6 chars)"
                            return@Button
                        }
                        isSaving = true
                        viewModel.completeGuestSignUp(
                            fullName = fullName.trim(),
                            email = email.trim(),
                            password = upgradePassword.trim(),
                            phone = phone.trim(),
                            onSuccess = {
                                isSaving = false
                                Toast.makeText(context, "Account upgraded to Full Administrator!", Toast.LENGTH_SHORT).show()
                                onNavigateBack()
                            },
                            onError = { err ->
                                isSaving = false
                                upgradeError = err
                            }
                        )
                    } else {
                        isSaving = true
                        viewModel.updateUserProfile(
                            fullName = fullName.trim(),
                            email = email.trim(),
                            phone = phone.trim(),
                            onSuccess = {
                                isSaving = false
                                Toast.makeText(context, "Profile details updated successfully!", Toast.LENGTH_SHORT).show()
                                onNavigateBack()
                            },
                            onError = {
                                isSaving = false
                                Toast.makeText(context, "Failed to update profile", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("save_profile_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                enabled = !isSaving
            ) {
                if (isSaving) {
                    CircularProgressIndicator(
                        color = Color.White,
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Saving...", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                } else {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (!isSignedUpUser && upgradePassword.isNotBlank()) "Complete Registration & Save" else "Save Profile Details",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}
