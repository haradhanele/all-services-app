package com.adr.groupledger.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.adr.groupledger.data.model.Member
import kotlinx.coroutines.flow.Flow

@Dao
interface MemberDao {
    @Query("SELECT * FROM members WHERE groupId = :groupId ORDER BY name ASC")
    fun getAllMembers(groupId: Long): Flow<List<Member>>

    @Query("SELECT * FROM members WHERE groupId = :groupId AND isActive = 1 ORDER BY name ASC")
    fun getActiveMembers(groupId: Long): Flow<List<Member>>

    @Query("SELECT * FROM members WHERE groupId = :groupId ORDER BY name ASC")
    suspend fun getAllMembersDirect(groupId: Long): List<Member>

    @Query("SELECT * FROM members WHERE id = :id")
    suspend fun getMemberById(id: Long): Member?

    @Query("SELECT * FROM members WHERE id = :id")
    fun getMemberByIdFlow(id: Long): Flow<Member?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMember(member: Member): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMembers(members: List<Member>)

    @Update
    suspend fun updateMember(member: Member)

    @Delete
    suspend fun deleteMember(member: Member)

    @Query("DELETE FROM members WHERE id = :id")
    suspend fun deleteMemberById(id: Long)

    @Query("DELETE FROM members WHERE groupId = :groupId")
    suspend fun deleteMembersForGroup(groupId: Long)

    @Query("SELECT COUNT(*) FROM members WHERE groupId = :groupId AND isActive = 1")
    fun getActiveMemberCount(groupId: Long): Flow<Int>

    @Query("SELECT COUNT(*) FROM members WHERE groupId = :groupId AND isActive = 1")
    suspend fun getActiveMemberCountDirect(groupId: Long): Int

    @Query("SELECT COUNT(*) FROM members WHERE groupId = :groupId")
    suspend fun getMemberCountDirect(groupId: Long): Int
}
