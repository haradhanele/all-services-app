const crypto = require("crypto");

/**
 * Validates and signs Cloudinary parameters for Carousel Media Uploads.
 * 
 * CRITICAL SECURITY ARCHITECTURE:
 * 1. Requires valid Firebase Authentication ID Token (Bearer token).
 * 2. Enforces Application-Level Role Authorization (APP_ADMIN or CONTENT_MANAGER).
 * 3. Rejects users whose only administrative role is Group Administrator (e.g. CC CUP admin).
 * 4. Strictly validates allowed parameters (preset: Group_ledger_carousel, folder: cc_cup/carousel*).
 * 5. Uses Cloudinary API Secret securely on server; never logs or exposes the secret.
 */

const ALLOWED_UPLOAD_PRESET = "Group_ledger_carousel";
const ALLOWED_FOLDER_PREFIX = "cc_cup/carousel";
const ALLOWED_APP_ROLES = ["APP_ADMIN", "CONTENT_MANAGER"];

/**
 * Extracts and verifies the Firebase Authentication token.
 * 
 * @param {string|undefined} authHeader - The 'Authorization' header value.
 * @param {object} adminAuth - Firebase Admin Auth instance.
 * @returns {Promise<{ uid: string, decodedToken: object }>}
 */
async function authenticateRequest(authHeader, adminAuth) {
  if (!authHeader || typeof authHeader !== "string") {
    const err = new Error("Missing Authorization header");
    err.statusCode = 401;
    throw err;
  }

  const parts = authHeader.trim().split(" ");
  if (parts.length !== 2 || parts[0].toLowerCase() !== "bearer" || !parts[1]) {
    const err = new Error("Invalid Authorization header format. Expected 'Bearer <token>'");
    err.statusCode = 401;
    throw err;
  }

  const idToken = parts[1];
  try {
    const decodedToken = await adminAuth.verifyIdToken(idToken);
    return {
      uid: decodedToken.uid,
      decodedToken
    };
  } catch (authError) {
    const err = new Error(`Authentication failed: ${authError.message}`);
    err.statusCode = 401;
    throw err;
  }
}

/**
 * Verifies application-level role authorization.
 * 
 * ARCHITECTURAL RULE:
 * A Group Administrator (e.g. GroupMembership.role == 'ADMIN') is strictly a local group admin
 * and is NOT granted global application-level permissions.
 * 
 * Only users with APP_ADMIN or CONTENT_MANAGER at the application level are allowed.
 * 
 * @param {string} uid - The verified user ID from the token.
 * @param {object} decodedToken - The decoded Firebase token.
 * @param {object|null} firestoreDb - Optional Firebase Firestore instance.
 * @returns {Promise<{ authorized: boolean, appRole: string }>}
 */
async function authorizeAppRole(uid, decodedToken, firestoreDb = null) {
  // 1. Check Custom Claims in the verified token
  const tokenAppRole = (decodedToken.appRole || (decodedToken.app_admin === true ? "APP_ADMIN" : "")).toString().trim();
  if (ALLOWED_APP_ROLES.includes(tokenAppRole)) {
    return { authorized: true, appRole: tokenAppRole };
  }

  // 2. Check Firestore application roles (app_roles or users collection)
  if (firestoreDb) {
    try {
      // Check dedicated app_roles collection
      const appRoleDoc = await firestoreDb.collection("app_roles").doc(uid).get();
      if (appRoleDoc.exists) {
        const data = appRoleDoc.data() || {};
        const firestoreRole = (data.role || data.appRole || "").toString().trim();
        if (ALLOWED_APP_ROLES.includes(firestoreRole)) {
          return { authorized: true, appRole: firestoreRole };
        }
      }

      // Check users collection for global appRole field
      const userDoc = await firestoreDb.collection("users").doc(uid).get();
      if (userDoc.exists) {
        const data = userDoc.data() || {};
        const userAppRole = (data.appRole || "").toString().trim();
        if (ALLOWED_APP_ROLES.includes(userAppRole)) {
          return { authorized: true, appRole: userAppRole };
        }
      }
    } catch (dbError) {
      console.error("Error querying user app role from Firestore:", dbError.message);
    }
  }

  // Explicitly reject: user does not have application-level permission
  const err = new Error("Forbidden: User does not possess an authorized application-level role (APP_ADMIN or CONTENT_MANAGER). Local Group Admins are not permitted.");
  err.statusCode = 403;
  throw err;
}

/**
 * Validates the incoming parameters for signature generation.
 * Prevents parameter injection or unauthorized folder/preset targets.
 * 
 * @param {object} params - The parameters requested to be signed.
 * @returns {object} Cleaned and validated parameters to sign.
 */
function validateUploadParameters(params) {
  if (!params || typeof params !== "object") {
    const err = new Error("Request body must be a JSON object");
    err.statusCode = 400;
    throw err;
  }

  const {
    folder,
    timestamp,
    upload_preset,
    uploadPreset,
    ...extraParams
  } = params;

  const effectivePreset = (upload_preset || uploadPreset || "").toString().trim();
  if (effectivePreset !== ALLOWED_UPLOAD_PRESET) {
    const err = new Error(`Invalid upload preset '${effectivePreset}'. Only '${ALLOWED_UPLOAD_PRESET}' is permitted.`);
    err.statusCode = 400;
    throw err;
  }

  const effectiveFolder = (folder || ALLOWED_FOLDER_PREFIX).toString().trim();
  if (!effectiveFolder.startsWith(ALLOWED_FOLDER_PREFIX) || effectiveFolder.includes("..")) {
    const err = new Error(`Invalid target folder '${effectiveFolder}'. Target must be under '${ALLOWED_FOLDER_PREFIX}'.`);
    err.statusCode = 400;
    throw err;
  }

  // Validate or assign timestamp (seconds since epoch)
  let effectiveTimestamp = parseInt(timestamp, 10);
  const nowInSeconds = Math.floor(Date.now() / 1000);
  if (isNaN(effectiveTimestamp) || effectiveTimestamp <= 0) {
    effectiveTimestamp = nowInSeconds;
  } else {
    // Timestamp must be reasonable (within +/- 1 hour of server time)
    if (Math.abs(effectiveTimestamp - nowInSeconds) > 3600) {
      effectiveTimestamp = nowInSeconds;
    }
  }

  // Reject dangerous or unexpected parameters
  const forbiddenParams = ["overwrite", "type", "public_id", "access_mode", "format"];
  for (const key of Object.keys(extraParams)) {
    if (forbiddenParams.includes(key.toLowerCase())) {
      const err = new Error(`Parameter '${key}' is forbidden in signed upload request.`);
      err.statusCode = 400;
      throw err;
    }
  }

  const paramsToSign = {
    folder: effectiveFolder,
    timestamp: effectiveTimestamp.toString(),
    upload_preset: effectivePreset
  };

  return {
    paramsToSign,
    timestamp: effectiveTimestamp,
    folder: effectiveFolder,
    uploadPreset: effectivePreset
  };
}

/**
 * Computes the cryptographic Cloudinary SHA-1 signature.
 * 
 * Cloudinary Algorithm:
 * 1. Sort all parameter key-value pairs alphabetically by key.
 * 2. Join as "key=val&key=val".
 * 3. Append the api_secret.
 * 4. Calculate SHA-1 hash (hexadecimal).
 * 
 * @param {object} paramsToSign - Sorted key-value pairs.
 * @param {string} apiSecret - Cloudinary API Secret.
 * @returns {string} SHA-1 signature hex string.
 */
function computeCloudinarySha1(paramsToSign, apiSecret) {
  if (!apiSecret || typeof apiSecret !== "string" || apiSecret.trim().length === 0) {
    const err = new Error("Server configuration error: CLOUDINARY_API_SECRET is not configured.");
    err.statusCode = 500;
    throw err;
  }

  const sortedKeys = Object.keys(paramsToSign).sort();
  const serialized = sortedKeys.map(k => `${k}=${paramsToSign[k]}`).join("&");
  const stringToSign = serialized + apiSecret.trim();

  return crypto.createHash("sha1").update(stringToSign).digest("hex");
}

/**
 * Resolves the Cloudinary API Secret securely.
 * Priority:
 * 1. process.env.CLOUDINARY_API_SECRET (Google Cloud Secret Manager / Environment)
 * 2. functions/.secret.local (Local Firebase Emulator only, gitignored)
 * 
 * Never hardcodes or exposes the secret.
 * 
 * @param {string|null} searchDir - Directory to search for .secret.local
 * @returns {string|null} The resolved secret or null.
 */
function resolveCloudinarySecret(searchDir = null) {
  if (process.env.CLOUDINARY_API_SECRET && process.env.CLOUDINARY_API_SECRET.trim().length > 0) {
    return process.env.CLOUDINARY_API_SECRET.trim();
  }

  try {
    const fs = require("fs");
    const path = require("path");
    const baseDir = searchDir || path.resolve(__dirname, "..");
    const localSecretPath = path.join(baseDir, ".secret.local");
    if (fs.existsSync(localSecretPath)) {
      const content = fs.readFileSync(localSecretPath, "utf8");
      for (const line of content.split(/\r?\n/)) {
        const trimmed = line.trim();
        if (trimmed.startsWith("CLOUDINARY_API_SECRET=") && !trimmed.startsWith("#")) {
          const val = trimmed.substring("CLOUDINARY_API_SECRET=".length).trim();
          if (val) return val;
        }
      }
    }
  } catch (_) {}

  return null;
}

module.exports = {
  ALLOWED_UPLOAD_PRESET,
  ALLOWED_FOLDER_PREFIX,
  ALLOWED_APP_ROLES,
  authenticateRequest,
  authorizeAppRole,
  validateUploadParameters,
  computeCloudinarySha1,
  resolveCloudinarySecret
};
