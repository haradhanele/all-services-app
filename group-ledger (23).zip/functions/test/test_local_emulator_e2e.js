const { describe, it, before, after } = require("node:test");
const assert = require("node:assert");
const http = require("http");

describe("Local Emulator End-to-End Verification", () => {
  const ENDPOINT = "http://127.0.0.1:5001/demo-group-ledger/us-central1/generateCloudinarySignature";

  function makeRequest(options, postData) {
    return new Promise((resolve, reject) => {
      const req = http.request(options, (res) => {
        let data = "";
        res.on("data", (chunk) => { data += chunk; });
        res.on("end", () => {
          let json;
          try {
            json = JSON.parse(data);
          } catch (_) {
            json = data;
          }
          resolve({ statusCode: res.statusCode, headers: res.headers, body: json });
        });
      });
      req.on("error", reject);
      if (postData) {
        req.write(typeof postData === "string" ? postData : JSON.stringify(postData));
      }
      req.end();
    });
  }

  it("1. Rejects GET requests with 405 Method Not Allowed", async () => {
    const res = await makeRequest({
      hostname: "127.0.0.1",
      port: 5001,
      path: "/demo-group-ledger/us-central1/generateCloudinarySignature",
      method: "GET"
    });
    assert.strictEqual(res.statusCode, 405);
    assert.strictEqual(res.body.error, "Method Not Allowed. Use HTTP POST.");
  });

  it("2. Rejects POST without Authorization header with 401", async () => {
    const res = await makeRequest({
      hostname: "127.0.0.1",
      port: 5001,
      path: "/demo-group-ledger/us-central1/generateCloudinarySignature",
      method: "POST",
      headers: { "Content-Type": "application/json" }
    }, {
      folder: "cc_cup/carousel/announcements",
      upload_preset: "Group_ledger_carousel"
    });
    assert.strictEqual(res.statusCode, 401);
    assert.strictEqual(res.body.error, "Missing Authorization header");
  });

  it("3. Rejects POST with invalid Bearer token with 401", async () => {
    const res = await makeRequest({
      hostname: "127.0.0.1",
      port: 5001,
      path: "/demo-group-ledger/us-central1/generateCloudinarySignature",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer not_a_valid_token"
      }
    }, {
      folder: "cc_cup/carousel/announcements",
      upload_preset: "Group_ledger_carousel"
    });
    assert.strictEqual(res.statusCode, 401);
    assert.match(res.body.error, /Authentication failed/i);
  });
});
