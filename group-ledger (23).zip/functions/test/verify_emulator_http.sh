#!/usr/bin/env bash
set -e

ENDPOINT="http://127.0.0.1:5001/demo-group-ledger/us-central1/generateCloudinarySignature"

echo "=== 1. Testing GET (Should be 405 Method Not Allowed) ==="
curl -s -o /tmp/resp1.txt -w "%{http_code}\n" -X GET "$ENDPOINT"
cat /tmp/resp1.txt
echo ""

echo "=== 2. Testing POST without Auth Header (Should be 401 Missing Auth) ==="
curl -s -o /tmp/resp2.txt -w "%{http_code}\n" -X POST \
  -H "Content-Type: application/json" \
  -d '{"folder":"cc_cup/carousel/announcements","upload_preset":"Group_ledger_carousel"}' \
  "$ENDPOINT"
cat /tmp/resp2.txt
echo ""

echo "=== 3. Testing POST with Invalid Bearer Token (Should be 401 Invalid Token) ==="
curl -s -o /tmp/resp3.txt -w "%{http_code}\n" -X POST \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer bogus_invalid_token_12345" \
  -d '{"folder":"cc_cup/carousel/announcements","upload_preset":"Group_ledger_carousel"}' \
  "$ENDPOINT"
cat /tmp/resp3.txt
echo ""

echo "=== Emulator Verification Complete ==="
