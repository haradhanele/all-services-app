const functions = require("firebase-functions");
const admin = require("firebase-admin");
const {
  authenticateRequest,
  authorizeAppRole,
  validateUploadParameters,
  computeCloudinarySha1,
  resolveCloudinarySecret
} = require("./src/signatureService");

// Initialize Firebase Admin SDK
if (!admin.apps || admin.apps.length === 0) {
  admin.initializeApp();
}

/**
 * Cloud Function: generateCloudinarySignature
 * 
 * Generates cryptographic SHA-1 upload signatures for Cloudinary Carousel uploads.
 * 
 * STRICT SECURITY CONSTRAINTS:
 * 1. Requires valid Firebase ID token in Authorization header.
 * 2. Authenticated user must have APP_ADMIN or CONTENT_MANAGER application-level role.
 * 3. Group Administrator role (GroupMembership.role == 'ADMIN') does NOT authorize app-level actions.
 * 4. Only allows preset 'Group_ledger_carousel' and folder 'cc_cup/carousel*'.
 * 5. Cloudinary API Secret is retrieved exclusively from Google Cloud Secret Manager / Environment Secrets.
 * 6. The secret is NEVER returned, NEVER logged, and NEVER distributed to clients.
 */
exports.generateCloudinarySignature = functions
  .runWith({
    secrets: ["CLOUDINARY_API_SECRET"],
    timeoutSeconds: 30,
    memory: "256MB"
  })
  .https.onRequest(async (req, res) => {
    // CORS headers
    res.set("Access-Control-Allow-Origin", "*");
    res.set("Access-Control-Allow-Headers", "Content-Type, Authorization");
    res.set("Access-Control-Allow-Methods", "POST, OPTIONS");

    if (req.method === "OPTIONS") {
      return res.status(204).send("");
    }

    if (req.method !== "POST") {
      return res.status(405).json({
        error: "Method Not Allowed. Use HTTP POST."
      });
    }

    try {
      // 1. Verify Firebase Authentication ID token
      const { uid, decodedToken } = await authenticateRequest(
        req.headers.authorization,
        admin.auth()
      );

      // 2. Authorize Application-Level Role (APP_ADMIN or CONTENT_MANAGER)
      await authorizeAppRole(
        uid,
        decodedToken,
        admin.firestore()
      );

      // 3. Validate requested upload parameters (preset, folder, timestamp)
      const {
        paramsToSign,
        timestamp,
        folder,
        uploadPreset
      } = validateUploadParameters(req.body);

      // 4. Retrieve Secret from Google Secret Manager / Environment / local .secret.local
      const apiSecret = resolveCloudinarySecret();
      if (!apiSecret) {
        console.error("CLOUDINARY_API_SECRET is not set in Secret Manager, environment, or .secret.local.");
        return res.status(500).json({
          error: "Server configuration error: Cloudinary API Secret is not configured."
        });
      }

      // 5. Generate Cryptographic SHA-1 signature
      const signature = computeCloudinarySha1(paramsToSign, apiSecret);

      const apiKey = process.env.CLOUDINARY_API_KEY || "498704388167";

      // 6. Return response matching BackendCloudinarySignatureProvider contract
      // Note: Secret is strictly omitted
      return res.status(200).json({
        signature,
        timestamp,
        apiKey,
        folder,
        uploadPreset
      });
    } catch (err) {
      const statusCode = err.statusCode || 500;
      // Do NOT log or expose sensitive data
      console.warn("Signature request rejected:", err.message);
      return res.status(statusCode).json({
        error: err.message
      });
    }
  });
