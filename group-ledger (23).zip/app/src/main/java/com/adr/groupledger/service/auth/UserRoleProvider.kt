package com.adr.groupledger.service.auth

import com.adr.groupledger.data.model.AppRole
import com.adr.groupledger.data.model.GroupRole
import kotlinx.coroutines.flow.Flow

/**
 * Provider-agnostic abstraction for resolving both Group-level roles and App-level platform roles.
 *
 * ARCHITECTURAL SEPARATION OF CONCERNS:
 * 1. Group Roles ([GroupRole]): Scoped strictly to a specific group/society (e.g. "CC CUP").
 * 2. App Roles ([AppRole]): Scoped globally across the Group Ledger application (e.g. Carousel management).
 *
 * CRITICAL PRINCIPLE:
 * Client-side role evaluation is solely for UI presentation, layout adaptation, and navigation decisions.
 * True security will be enforced at the infrastructure level using Firebase Auth UIDs, Custom Claims,
 * and Firestore/Storage Security Rules (Phase 11).
 */
interface UserRoleProvider {

    /**
     * Streams the user's role within a specific group for group-scoped UI presentation.
     */
    fun observeGroupRole(userId: Long, groupId: Long): Flow<GroupRole>

    /**
     * Inspects the user's role within a specific group on-demand.
     */
    suspend fun getGroupRole(userId: Long, groupId: Long): GroupRole

    /**
     * Streams the user's global application-level role.
     * Defaults to [AppRole.REGULAR_USER]. Group Admins do NOT automatically receive [AppRole.APP_ADMIN].
     */
    fun observeAppRole(): Flow<AppRole>

    /**
     * Inspects the user's global application-level role on-demand.
     */
    suspend fun getAppRole(): AppRole

    /**
     * Checks if the currently authenticated Firebase user possesses server-verified administrative
     * custom claims (e.g. set by a trusted server environment / Firebase Admin SDK).
     */
    suspend fun verifyServerAppAdminPrivileges(): Boolean
}

