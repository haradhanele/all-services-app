package com.adr.groupledger.service.storage

/**
 * Provides access to the application's active [MediaStorageService] implementation.
 * Ensures single-instance management while enabling clean test injection.
 */
object StorageServiceProvider {

    @Volatile
    private var customService: MediaStorageService? = null

    /**
     * Obtains the active [MediaStorageService].
     * Defaults to [CloudinaryMediaStorageService] configured with [CloudinaryConfig.DEFAULT]
     * and [BackendCloudinarySignatureProvider].
     */
    fun getMediaStorageService(): MediaStorageService {
        return customService ?: synchronized(this) {
            customService ?: CloudinaryMediaStorageService(
                config = CloudinaryConfig.DEFAULT,
                signatureProvider = BackendCloudinarySignatureProvider(
                    endpointUrl = CloudinaryConfig.DEFAULT.signatureEndpointUrl
                )
            ).also { customService = it }
        }
    }

    /**
     * Injects a custom or mock storage service (e.g. for local tests or custom endpoints).
     */
    fun setCustomMediaStorageService(service: MediaStorageService?) {
        synchronized(this) {
            customService = service
        }
    }
}
