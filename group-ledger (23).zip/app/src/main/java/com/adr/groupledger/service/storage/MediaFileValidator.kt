package com.adr.groupledger.service.storage

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.adr.groupledger.data.model.carousel.MediaType
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.Locale

/**
 * Result of validating a media file before scheduling an upload.
 */
sealed class MediaValidationResult {
    data class Valid(
        val file: File,
        val mediaType: MediaType,
        val mimeType: String,
        val sizeBytes: Long,
        val originalName: String
    ) : MediaValidationResult()

    data class Invalid(
        val userFacingReason: String,
        val technicalDetail: String? = null
    ) : MediaValidationResult()
}

/**
 * Validates selected Image and GIF assets for size, format, readability, and type integrity.
 * Enforces zero-permission local caching for streaming uploads without memory overhead.
 */
object MediaFileValidator {

    /**
     * Maximum permitted media asset size: 10 Megabytes.
     * Generous for high-res banners and multi-frame animated GIFs while preventing excessive bandwidth.
     */
    const val MAX_MEDIA_FILE_SIZE_BYTES: Long = 10 * 1024 * 1024L // 10 MB

    private val SUPPORTED_MIME_TYPES = setOf(
        "image/jpeg",
        "image/jpg",
        "image/png",
        "image/webp",
        "image/gif"
    )

    private val SUPPORTED_EXTENSIONS = setOf(
        "jpg", "jpeg", "png", "webp", "gif"
    )

    /**
     * Inspects URI, verifies size and format, streams bytes to a dedicated cache file,
     * and accurately distinguishes between animated GIF and static IMAGE.
     */
    fun validateAndPrepareMediaFile(context: Context, uri: Uri): MediaValidationResult {
        return try {
            val contentResolver = context.contentResolver

            // 1. Resolve original metadata (Name & Size) from ContentResolver
            var originalName = "upload_media_${System.currentTimeMillis()}"
            var reportedSize = 0L

            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) {
                        originalName = cursor.getString(nameIndex) ?: originalName
                    }
                    if (sizeIndex != -1) {
                        reportedSize = cursor.getLong(sizeIndex)
                    }
                }
            }

            // 2. Resolve and validate MIME Type & Extension
            val detectedMimeType = (contentResolver.getType(uri) ?: "").lowercase(Locale.ROOT)
            val extension = originalName.substringAfterLast('.', "").lowercase(Locale.ROOT)

            val isMimeSupported = detectedMimeType.isNotBlank() && SUPPORTED_MIME_TYPES.contains(detectedMimeType)
            val isExtensionSupported = extension.isNotBlank() && SUPPORTED_EXTENSIONS.contains(extension)

            if (!isMimeSupported && !isExtensionSupported) {
                return MediaValidationResult.Invalid(
                    userFacingReason = "Unsupported media format. Please select an image (JPEG, PNG, WEBP) or an animated GIF.",
                    technicalDetail = "MIME: $detectedMimeType, Extension: $extension"
                )
            }

            // Check if user accidentally selected video or other document
            if (detectedMimeType.startsWith("video/") || extension in listOf("mp4", "mov", "mkv", "avi")) {
                return MediaValidationResult.Invalid(
                    userFacingReason = "Video upload is not supported in this phase. Please select an image or animated GIF.",
                    technicalDetail = "Video type detected: $detectedMimeType"
                )
            }

            // 3. Stream URI content to a private temporary file in cacheDir
            val safeExtension = if (extension.isNotBlank()) ".$extension" else if (detectedMimeType == "image/gif") ".gif" else ".jpg"
            val sanitizedBaseName = originalName.substringBeforeLast('.')
                .replace("[^a-zA-Z0-9_]".toRegex(), "_")
                .take(30)
            val tempFile = File(context.cacheDir, "carousel_${sanitizedBaseName}_${System.currentTimeMillis()}$safeExtension")

            var totalBytesWritten = 0L
            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            if (inputStream == null) {
                return MediaValidationResult.Invalid("Unable to open the selected media file. Please try selecting again.")
            }

            inputStream.use { input ->
                FileOutputStream(tempFile).use { output ->
                    val buffer = ByteArray(8 * 1024)
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        output.write(buffer, 0, read)
                        totalBytesWritten += read

                        if (totalBytesWritten > MAX_MEDIA_FILE_SIZE_BYTES) {
                            tempFile.delete()
                            return MediaValidationResult.Invalid(
                                userFacingReason = "The selected file exceeds the maximum allowed size of 10 MB. Selected: ${formatBytes(totalBytesWritten)}."
                            )
                        }
                    }
                }
            }

            if (!tempFile.exists() || tempFile.length() == 0L) {
                return MediaValidationResult.Invalid("Selected media file is empty (0 bytes).")
            }

            // 4. Distinguish GIF vs static IMAGE
            val isGif = isGifAsset(tempFile, detectedMimeType, extension)
            val resolvedMediaType = if (isGif) MediaType.GIF else MediaType.IMAGE
            val effectiveMimeType = if (isGif) "image/gif" else detectedMimeType.ifBlank { "image/jpeg" }

            MediaValidationResult.Valid(
                file = tempFile,
                mediaType = resolvedMediaType,
                mimeType = effectiveMimeType,
                sizeBytes = tempFile.length(),
                originalName = originalName
            )

        } catch (e: Exception) {
            MediaValidationResult.Invalid(
                userFacingReason = "Failed to process selected media file: ${e.localizedMessage ?: "Unknown error"}",
                technicalDetail = e.stackTraceToString()
            )
        }
    }

    /**
     * Determines whether an asset is an animated GIF by inspecting extension, MIME type,
     * or checking magic header bytes (GIF87a / GIF89a).
     */
    fun isGifAsset(file: File, mimeType: String, extension: String): Boolean {
        if (mimeType == "image/gif" || extension.equals("gif", ignoreCase = true)) {
            return true
        }

        return try {
            if (file.length() >= 6) {
                file.inputStream().use { stream ->
                    val header = ByteArray(6)
                    val read = stream.read(header)
                    if (read >= 6) {
                        val headerStr = String(header, Charsets.US_ASCII)
                        headerStr == "GIF89a" || headerStr == "GIF87a"
                    } else false
                }
            } else false
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Determines whether an asset file is an animated GIF by inspecting magic header bytes or extension.
     */
    fun isAnimatedGif(file: File): Boolean = isGifAsset(file, "", file.extension)

    /**
     * Formats bytes into a human-readable string (e.g. "1.5 MB", "640 KB").
     */
    fun formatBytes(bytes: Long): String {
        return when {
            bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB", bytes.toDouble() / (1024 * 1024))
            bytes >= 1024 -> {
                val kb = bytes.toDouble() / 1024
                if (kb % 1.0 == 0.0) String.format(Locale.US, "%.0f KB", kb)
                else String.format(Locale.US, "%.1f KB", kb)
            }
            else -> "$bytes B"
        }
    }
}
