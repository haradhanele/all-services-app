package com.adr.groupledger.service.storage

import com.adr.groupledger.BuildConfig

/**
 * Client-safe configuration for Cloudinary media storage.
 *
 * CRITICAL SECURITY MANDATE:
 * Under NO circumstances should the Cloudinary API Secret be placed here, in BuildConfig,
 * AndroidManifest, or anywhere in the Android client application.
 */
data class CloudinaryConfig(
    val cloudName: String = "cc-cup",
    val uploadPreset: String = DEFAULT_UPLOAD_PRESET,
    val assetFolder: String = DEFAULT_ASSET_FOLDER,
    val isSigned: Boolean = true,
    val overwrite: Boolean = false,
    val apiKey: String = "", // Optional public API Key if passed alongside backend signature
    val signatureEndpointUrl: String = DEFAULT_SIGNATURE_ENDPOINT_URL
) {
    companion object {
        const val DEFAULT_UPLOAD_PRESET = "Group_ledger_carousel"
        const val DEFAULT_ASSET_FOLDER = "cc_cup/carousel"

        // Production parameters
        const val PRODUCTION_PROJECT_ID = "samiti-app-d4336"
        const val PRODUCTION_REGION = "asia-south2"
        const val PRODUCTION_SIGNATURE_ENDPOINT_URL =
            "https://asia-south2-samiti-app-d4336.cloudfunctions.net/generateCloudinarySignature"

        // Emulator connection parameters
        const val EMULATOR_HOST_ANDROID = "10.0.2.2" // Android AVD loopback bridge to host
        const val EMULATOR_HOST_LOCAL = "127.0.0.1"  // Local desktop JVM / testing
        const val EMULATOR_PORT = 5001
        const val DEMO_PROJECT_ID = "demo-group-ledger"
        const val REGION = "us-central1"
        const val FUNCTION_NAME = "generateCloudinarySignature"

        /**
         * Builds the Firebase Functions Emulator endpoint URL.
         * For standard Android emulator, defaults to 10.0.2.2.
         * For physical devices, pass the developer workstation's LAN IP.
         */
        fun buildEmulatorEndpointUrl(
            host: String = EMULATOR_HOST_ANDROID,
            port: Int = EMULATOR_PORT,
            projectId: String = DEMO_PROJECT_ID,
            region: String = REGION,
            functionName: String = FUNCTION_NAME
        ): String {
            return "http://$host:$port/$projectId/$region/$functionName"
        }

        /**
         * Builds the production Firebase Functions HTTPS endpoint URL.
         */
        fun buildProductionEndpointUrl(
            projectId: String = PRODUCTION_PROJECT_ID,
            region: String = PRODUCTION_REGION,
            functionName: String = FUNCTION_NAME
        ): String {
            return "https://$region-$projectId.cloudfunctions.net/$functionName"
        }

        /**
         * Resolves the default Cloudinary signature endpoint URL:
         * - In DEBUG builds: defaults to the local Firebase emulator (http://10.0.2.2:5001/...)
         * - In RELEASE builds: defaults to the secure production HTTPS Cloud Function
         *   (https://asia-south2-samiti-app-d4336.cloudfunctions.net/generateCloudinarySignature)
         * Injected via BuildConfig.CLOUDINARY_SIGNATURE_ENDPOINT_URL.
         */
        val DEFAULT_SIGNATURE_ENDPOINT_URL: String = try {
            val endpoint = BuildConfig.CLOUDINARY_SIGNATURE_ENDPOINT_URL
            if (endpoint.isNotBlank()) endpoint else buildEmulatorEndpointUrl()
        } catch (_: Throwable) {
            buildEmulatorEndpointUrl()
        }

        val DEFAULT = CloudinaryConfig(
            cloudName = "cc-cup",
            uploadPreset = DEFAULT_UPLOAD_PRESET,
            assetFolder = DEFAULT_ASSET_FOLDER,
            isSigned = true,
            overwrite = false,
            apiKey = "",
            signatureEndpointUrl = DEFAULT_SIGNATURE_ENDPOINT_URL
        )
    }

    /**
     * Builds a secure CDN delivery URL for a given public ID or logical path.
     * Respects media types (e.g., ensuring GIFs preserve animation frames).
     */
    fun buildDeliveryUrl(
        publicId: String,
        isGif: Boolean = false,
        autoOptimize: Boolean = true
    ): String {
        if (cloudName.isBlank()) return ""
        val cleanPublicId = publicId.trim().removePrefix("/")

        // For animated GIFs, we preserve format and animation; for images, we enable auto format & quality
        val transformation = when {
            isGif -> "q_auto"
            autoOptimize -> "f_auto,q_auto"
            else -> ""
        }

        val transformSegment = if (transformation.isNotBlank()) "$transformation/" else ""
        return "https://res.cloudinary.com/$cloudName/image/upload/$transformSegment$cleanPublicId"
    }
}
