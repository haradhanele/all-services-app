package com.adr.groupledger.data.repository.carousel

import com.adr.groupledger.data.model.carousel.CarouselActionType
import com.adr.groupledger.data.model.carousel.CarouselContentType
import com.adr.groupledger.data.model.carousel.CarouselItem
import com.adr.groupledger.data.model.carousel.GLOBAL_GROUP_ID
import com.adr.groupledger.data.model.carousel.MediaResource
import com.adr.groupledger.data.model.carousel.MediaType
import com.adr.groupledger.data.model.carousel.StorageProviderType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map

/**
 * In-memory implementation of [CarouselRepository] for the Phase 4 Content Management foundation.
 * Provides a reactive, stateful repository for managing global application carousel content
 * without requiring direct Firestore collections or modifying Firestore Security Rules.
 */
class InMemoryCarouselRepository private constructor() : CarouselRepository {

    private val _items = MutableStateFlow<List<CarouselItem>>(createInitialSampleItems())
    val itemsFlow: Flow<List<CarouselItem>> = _items.asStateFlow()

    override fun getActiveCarouselItems(groupId: Long): Flow<List<CarouselItem>> {
        return _items.map { list ->
            val now = System.currentTimeMillis()
            list.filter { item ->
                (item.groupId == groupId || item.groupId == GLOBAL_GROUP_ID) && item.isCurrentlyActive(now)
            }.sortedByDescending { it.priority }
        }
    }

    override fun getAllCarouselItems(groupId: Long): Flow<List<CarouselItem>> {
        return _items.map { list ->
            list.filter { item ->
                groupId == GLOBAL_GROUP_ID || item.groupId == groupId || item.groupId == GLOBAL_GROUP_ID
            }.sortedByDescending { it.priority }
        }
    }

    override suspend fun getCarouselItemById(id: String): CarouselItem? {
        return _items.value.find { it.id == id }
    }

    override suspend fun saveCarouselItem(item: CarouselItem): Result<String> {
        val currentList = _items.value.toMutableList()
        val finalId = if (item.id.isBlank()) "carousel_${System.currentTimeMillis()}" else item.id
        val updatedItem = item.copy(
            id = finalId,
            updatedAt = System.currentTimeMillis()
        )

        val index = currentList.indexOfFirst { it.id == finalId }
        if (index >= 0) {
            currentList[index] = updatedItem
        } else {
            currentList.add(0, updatedItem)
        }

        _items.value = currentList
        return Result.success(finalId)
    }

    override suspend fun setItemActiveStatus(itemId: String, isActive: Boolean): Result<Unit> {
        val currentList = _items.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == itemId }
        if (index >= 0) {
            currentList[index] = currentList[index].copy(
                isActive = isActive,
                updatedAt = System.currentTimeMillis()
            )
            _items.value = currentList
            return Result.success(Unit)
        }
        return Result.failure(NoSuchElementException("Carousel item not found: $itemId"))
    }

    override suspend fun deleteCarouselItem(itemId: String): Result<Unit> {
        val currentList = _items.value.toMutableList()
        val removed = currentList.removeAll { it.id == itemId }
        if (removed) {
            _items.value = currentList
            return Result.success(Unit)
        }
        return Result.failure(NoSuchElementException("Carousel item not found: $itemId"))
    }

    override suspend fun updateItemPriority(itemId: String, priority: Int): Result<Unit> {
        val currentList = _items.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == itemId }
        if (index >= 0) {
            currentList[index] = currentList[index].copy(
                priority = priority,
                updatedAt = System.currentTimeMillis()
            )
            _items.value = currentList
            return Result.success(Unit)
        }
        return Result.failure(NoSuchElementException("Carousel item not found: $itemId"))
    }

    companion object {
        @Volatile
        private var instance: InMemoryCarouselRepository? = null

        fun getInstance(): InMemoryCarouselRepository {
            return instance ?: synchronized(this) {
                instance ?: InMemoryCarouselRepository().also { instance = it }
            }
        }

        fun resetForTesting() {
            synchronized(this) {
                instance = null
            }
        }

        fun clearAllForTesting() {
            getInstance()._items.value = emptyList()
        }

        private fun createInitialSampleItems(): List<CarouselItem> {
            val now = System.currentTimeMillis()
            val oneDayMs = 86_400_000L
            val oneWeekMs = 7 * oneDayMs

            return listOf(
                CarouselItem(
                    id = "sample_diwali",
                    groupId = GLOBAL_GROUP_ID,
                    contentType = CarouselContentType.FESTIVAL,
                    title = "Diwali Festival Greetings",
                    message = "Wishing all society members and their families joy, prosperity, and light!",
                    mediaResource = MediaResource(
                        mediaId = "med_diwali",
                        mediaType = MediaType.IMAGE,
                        provider = StorageProviderType.LOCAL_ASSET,
                        logicalPath = "carousel/festival_diwali.jpg"
                    ),
                    startAt = now - oneDayMs,
                    endAt = now + (oneWeekMs * 2),
                    isActive = true,
                    priority = 10,
                    slideDurationSeconds = 6,
                    actionType = CarouselActionType.NONE,
                    createdBy = "Platform Team"
                ),
                CarouselItem(
                    id = "sample_announcement",
                    groupId = GLOBAL_GROUP_ID,
                    contentType = CarouselContentType.ANNOUNCEMENT,
                    title = "Monthly Contribution Reminder",
                    message = "Monthly deposits are due by the 10th. Please verify your member passbooks.",
                    mediaResource = MediaResource(
                        mediaId = "med_notice",
                        mediaType = MediaType.IMAGE,
                        provider = StorageProviderType.LOCAL_ASSET,
                        logicalPath = "carousel/notice_dues.jpg"
                    ),
                    startAt = 0L,
                    endAt = 0L,
                    isActive = true,
                    priority = 8,
                    slideDurationSeconds = 5,
                    actionType = CarouselActionType.INTERNAL_SCREEN,
                    actionLabel = "View Dues",
                    actionTarget = "dues",
                    createdBy = "Platform Team"
                ),
                CarouselItem(
                    id = "sample_birthday",
                    groupId = GLOBAL_GROUP_ID,
                    contentType = CarouselContentType.BIRTHDAY,
                    title = "Happy Birthday Members!",
                    message = "Warm birthday wishes from Group Ledger to all members celebrating this month!",
                    mediaResource = MediaResource(
                        mediaId = "med_bday",
                        mediaType = MediaType.GIF,
                        provider = StorageProviderType.LOCAL_ASSET,
                        logicalPath = "carousel/birthday_sparkles.gif"
                    ),
                    startAt = now - oneDayMs,
                    endAt = now + (oneWeekMs * 4),
                    isActive = true,
                    priority = 6,
                    slideDurationSeconds = 5,
                    actionType = CarouselActionType.NONE,
                    createdBy = "Automated Scheduler"
                ),
                CarouselItem(
                    id = "sample_promotion",
                    groupId = GLOBAL_GROUP_ID,
                    contentType = CarouselContentType.PROMOTION,
                    title = "New Emergency Loan Scheme",
                    message = "Explore updated 70% community voting terms for rapid emergency loans.",
                    mediaResource = MediaResource(
                        mediaId = "med_loan",
                        mediaType = MediaType.IMAGE,
                        provider = StorageProviderType.LOCAL_ASSET,
                        logicalPath = "carousel/promo_loan.jpg"
                    ),
                    startAt = 0L,
                    endAt = 0L,
                    isActive = true,
                    priority = 4,
                    slideDurationSeconds = 5,
                    actionType = CarouselActionType.INTERNAL_SCREEN,
                    actionLabel = "Explore Loans",
                    actionTarget = "loans",
                    createdBy = "Content Admin"
                ),
                CarouselItem(
                    id = "sample_offer",
                    groupId = GLOBAL_GROUP_ID,
                    contentType = CarouselContentType.OFFER,
                    title = "Early Deposit Recognition",
                    message = "Earn high community reliability rating with early monthly payments.",
                    mediaResource = MediaResource(
                        mediaId = "med_offer",
                        mediaType = MediaType.IMAGE,
                        provider = StorageProviderType.LOCAL_ASSET,
                        logicalPath = "carousel/offer_early.jpg"
                    ),
                    startAt = 0L,
                    endAt = 0L,
                    isActive = false, // Inactive example to test filtering & activation switch
                    priority = 2,
                    slideDurationSeconds = 5,
                    actionType = CarouselActionType.NONE,
                    createdBy = "Content Admin"
                )
            )
        }
    }
}
