package com.adr.groupledger.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.Payment
import com.adr.groupledger.ui.components.MonthPickerBar
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.CardWhite
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.TextSlate400
import com.adr.groupledger.ui.theme.TextSlate500
import com.adr.groupledger.ui.theme.TextSlate800
import com.adr.groupledger.ui.theme.appOutlinedTextFieldColors
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.utils.CurrencyFormatter
import com.adr.groupledger.utils.DateUtils
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordPaymentScreen(
    preselectedMemberId: Long,
    viewModel: SocietyViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val allMembers by viewModel.allMembers.collectAsStateWithLifecycle()
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val currentSelMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val currentSelYear by viewModel.selectedYear.collectAsStateWithLifecycle()
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()
    val currentUserRole by viewModel.currentUserRole.collectAsStateWithLifecycle()
    val currentMemberId by viewModel.currentMemberId.collectAsStateWithLifecycle()

    val isUserAdmin = isAdminUnlocked || currentUserRole.equals("ADMIN", ignoreCase = true)

    var selectedMember by remember { mutableStateOf<Member?>(null) }
    var memberDropdownExpanded by remember { mutableStateOf(false) }

    var paymentMonth by remember { mutableIntStateOf(currentSelMonth) }
    var paymentYear by remember { mutableIntStateOf(currentSelYear) }

    var expectedAmount by remember { mutableDoubleStateOf(settings.defaultContribution) }
    var paidAmountText by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("UPI") }
    var transactionRef by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var paymentDate by remember { mutableLongStateOf(System.currentTimeMillis()) }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Requirement 1: Enforce member selection permissions
    LaunchedEffect(allMembers, currentMemberId, isUserAdmin, preselectedMemberId) {
        if (allMembers.isNotEmpty()) {
            if (isUserAdmin) {
                val targetId = if (preselectedMemberId > 0) preselectedMemberId else (currentMemberId ?: allMembers.first().id)
                selectedMember = allMembers.find { it.id == targetId } ?: allMembers.firstOrNull()
            } else {
                val myMemberId = viewModel.resolveCurrentMemberId() ?: currentMemberId
                selectedMember = allMembers.find { it.id == myMemberId } ?: allMembers.firstOrNull()
            }
            selectedMember?.let { target ->
                val exp = if (target.monthlyContribution > 0) target.monthlyContribution else settings.defaultContribution
                expectedAmount = exp
                if (paidAmountText.isBlank()) {
                    paidAmountText = exp.toInt().toString()
                }
            }
        }
    }

    // Requirement 2: Reactive query for existing payment to manage duplicate locking & rejection re-submission
    val existingPayment by produceState<Payment?>(
        initialValue = null,
        key1 = selectedMember?.id,
        key2 = paymentMonth,
        key3 = paymentYear
    ) {
        val memId = selectedMember?.id
        if (memId != null && memId > 0) {
            viewModel.getPaymentFlow(memId, paymentMonth, paymentYear).collect {
                value = it
            }
        } else {
            value = null
        }
    }

    val isPending = existingPayment?.isPendingApproval == true
    val isApproved = existingPayment?.isApproved == true
    val isRejected = existingPayment?.isRejected == true

    // Lock for member if Pending or Approved (Req 2)
    val isLockedForMember = !isUserAdmin && (isPending || isApproved)

    // Prefill details if user is editing a rejected payment
    LaunchedEffect(existingPayment) {
        val curr = existingPayment
        if (curr != null && curr.isRejected && !isUserAdmin) {
            paidAmountText = curr.paidAmount.toInt().toString()
            paymentMethod = curr.paymentMethod.ifBlank { "UPI" }
            transactionRef = curr.transactionReference
            notes = curr.notes
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isUserAdmin) "Record & Confirm Payment" else "Submit Contribution",
                        fontWeight = FontWeight.Bold,
                        color = TextSlate800
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextSlate800)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CardWhite)
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .testTag("record_payment_screen"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Requirement 2: Contextual Status Banners (Replaces static "Waiting Review" box - Requirement 8)
            if (isPending) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Amber500.copy(alpha = 0.1f),
                    border = BorderStroke(1.dp, Amber500.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth().testTag("payment_pending_lock_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isUserAdmin) Icons.Default.HourglassTop else Icons.Default.Lock,
                            contentDescription = null,
                            tint = Amber500,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (isUserAdmin) "Payment Request Pending Review" else "Duplicate Submission Locked",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Amber500
                            )
                            Text(
                                text = if (isUserAdmin)
                                    "A payment of ₹${existingPayment?.paidAmount?.toInt()} for ${DateUtils.getMonthName(paymentMonth)} $paymentYear was submitted by ${selectedMember?.name}. You can confirm or update it below."
                                else
                                    "Your payment of ₹${existingPayment?.paidAmount?.toInt()} for ${DateUtils.getMonthName(paymentMonth)} $paymentYear is currently pending Admin verification. Duplicate submissions are locked.",
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            } else if (isApproved) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Emerald500.copy(alpha = 0.1f),
                    border = BorderStroke(1.dp, Emerald500.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth().testTag("payment_approved_lock_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Emerald500,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Month Paid & Approved",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Emerald500
                            )
                            Text(
                                text = if (isUserAdmin)
                                    "Payment of ₹${existingPayment?.paidAmount?.toInt()} is confirmed and recorded. You can adjust the entry if needed."
                                else
                                    "Your payment of ₹${existingPayment?.paidAmount?.toInt()} for ${DateUtils.getMonthName(paymentMonth)} $paymentYear is verified and approved.",
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            } else if (isRejected) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Rose500.copy(alpha = 0.1f),
                    border = BorderStroke(1.dp, Rose500.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth().testTag("payment_rejected_reset_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Replay,
                            contentDescription = null,
                            tint = Rose500,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Previous Request Rejected — Re-submission Unlocked",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Rose500
                            )
                            val reason = existingPayment?.rejectionReason.orEmpty()
                            Text(
                                text = if (reason.isNotBlank())
                                    "Admin rejection note: \"$reason\". Please correct the payment details below and re-submit for approval."
                                else
                                    "Previous request was rejected. You may edit your payment details below and re-submit for approval.",
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }

            // 1. Member Selector Dropdown (Req 1: Admin can choose any; Member locked to self)
            ExposedDropdownMenuBox(
                expanded = memberDropdownExpanded && isUserAdmin,
                onExpandedChange = {
                    if (isUserAdmin) memberDropdownExpanded = !memberDropdownExpanded
                }
            ) {
                OutlinedTextField(
                    value = selectedMember?.let { "${it.name} (${it.memberCode})" } ?: "Select Member",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(if (isUserAdmin) "Select Society Member" else "Member Account") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = IndigoPrimary) },
                    trailingIcon = {
                        if (isUserAdmin) {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = memberDropdownExpanded)
                        } else {
                            Icon(Icons.Default.Lock, contentDescription = "Locked to your account", tint = TextSlate400, modifier = Modifier.size(16.dp))
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                        .testTag("member_selector_dropdown"),
                    shape = RoundedCornerShape(10.dp),
                    colors = appOutlinedTextFieldColors()
                )

                if (isUserAdmin) {
                    ExposedDropdownMenu(
                        expanded = memberDropdownExpanded,
                        onDismissRequest = { memberDropdownExpanded = false }
                    ) {
                        allMembers.forEach { member ->
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(member.name, fontWeight = FontWeight.SemiBold, color = TextSlate800)
                                            Text(member.memberCode, style = MaterialTheme.typography.labelSmall, color = TextSlate400)
                                        }
                                        Text(
                                            "₹${CurrencyFormatter.formatIndian(if (member.monthlyContribution > 0) member.monthlyContribution else settings.defaultContribution)}/mo",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = IndigoPrimary
                                        )
                                    }
                                },
                                onClick = {
                                    selectedMember = member
                                    val exp = if (member.monthlyContribution > 0) member.monthlyContribution else settings.defaultContribution
                                    expectedAmount = exp
                                    paidAmountText = exp.toInt().toString()
                                    memberDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            // 2. Sequential Month/Period Selection (Req 3)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "Sequential Month Selection",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextSlate800
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    MonthPickerBar(
                        selectedMonth = paymentMonth,
                        selectedYear = paymentYear,
                        onPrevClick = {
                            if (paymentMonth == 1) {
                                paymentMonth = 12
                                paymentYear -= 1
                            } else {
                                paymentMonth -= 1
                            }
                        },
                        onNextClick = {
                            if (paymentMonth == 12) {
                                paymentMonth = 1
                                paymentYear += 1
                            } else {
                                paymentMonth += 1
                            }
                        },
                        onMonthYearSelected = { m, y ->
                            paymentMonth = m
                            paymentYear = y
                        }
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Chronological quick-selection chips (Last 6 sequential cycles)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val currentCal = Calendar.getInstance()
                        val currentM = currentCal.get(Calendar.MONTH) + 1
                        val currentY = currentCal.get(Calendar.YEAR)

                        for (i in 5 downTo 0) {
                            var m = currentM - i
                            var y = currentY
                            while (m <= 0) {
                                m += 12
                                y -= 1
                            }
                            val isSelected = paymentMonth == m && paymentYear == y
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) IndigoPrimary else CardWhite,
                                border = BorderStroke(1.dp, if (isSelected) IndigoPrimary else Color(0xFFE2E8F0)),
                                modifier = Modifier
                                    .clickable {
                                        paymentMonth = m
                                        paymentYear = y
                                    }
                                    .testTag("seq_month_chip_${m}_$y")
                            ) {
                                Text(
                                    text = "${DateUtils.getMonthShortName(m)} $y",
                                    fontSize = 11.5.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color.White else TextSlate800,
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }

            // 3. Amount Inputs
            val paidNum = paidAmountText.toDoubleOrNull() ?: 0.0
            val calculatedDue = (expectedAmount - paidNum).coerceAtLeast(0.0)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = expectedAmount.toInt().toString(),
                    onValueChange = {
                        val num = it.toDoubleOrNull()
                        if (num != null) expectedAmount = num
                    },
                    readOnly = !isUserAdmin || isLockedForMember,
                    label = { Text("Expected (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f).testTag("payment_expected_input"),
                    shape = RoundedCornerShape(10.dp),
                    colors = appOutlinedTextFieldColors()
                )

                OutlinedTextField(
                    value = paidAmountText,
                    onValueChange = {
                        paidAmountText = it
                        errorMessage = null
                    },
                    enabled = !isLockedForMember,
                    label = { Text("Paid Amount (₹)*") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1.3f).testTag("payment_paid_input"),
                    shape = RoundedCornerShape(10.dp),
                    colors = appOutlinedTextFieldColors()
                )
            }

            // Quick Amount Suggestion Chips (Enabled only when unlocked)
            if (!isLockedForMember) {
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val fullAmount = expectedAmount.toInt()
                    listOf(fullAmount, 500, 1000, 1500, 2000).distinct().forEach { amt ->
                        SuggestionChip(
                            onClick = { paidAmountText = amt.toString() },
                            label = { Text("₹$amt") },
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = if (paidAmountText == amt.toString()) IndigoPrimary.copy(alpha = 0.12f) else CardWhite
                            )
                        )
                    }
                }
            }

            // 4. Payment Method Chips
            Column {
                Text("Payment Method", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = TextSlate800)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("UPI", "Cash", "Bank Transfer", "Cheque").forEach { method ->
                        FilterChip(
                            selected = paymentMethod == method,
                            onClick = { if (!isLockedForMember) paymentMethod = method },
                            enabled = !isLockedForMember,
                            label = { Text(method) },
                            leadingIcon = {
                                if (paymentMethod == method) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = IndigoPrimary,
                                selectedLabelColor = CardWhite,
                                selectedLeadingIconColor = CardWhite
                            )
                        )
                    }
                }
            }

            // 5. Transaction Reference / UPI ID
            OutlinedTextField(
                value = transactionRef,
                onValueChange = { transactionRef = it },
                enabled = !isLockedForMember,
                label = { Text("UPI Txn ID / Receipt Reference (Optional)") },
                placeholder = { Text("e.g. UPI-123456789 or Cheque #00452") },
                leadingIcon = { Icon(Icons.Default.Tag, contentDescription = null, tint = IndigoPrimary) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("payment_ref_input"),
                shape = RoundedCornerShape(10.dp),
                colors = appOutlinedTextFieldColors()
            )

            // 6. Payment Date Picker
            val cal = Calendar.getInstance().apply { timeInMillis = paymentDate }
            val datePickerDialog = DatePickerDialog(
                context,
                { _, y, m, d ->
                    val selCal = Calendar.getInstance().apply { set(y, m, d, 0, 0, 0) }
                    paymentDate = selCal.timeInMillis
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
                    .clickable(enabled = !isLockedForMember) { datePickerDialog.show() },
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(13.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Payment Date", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
                            Text(DateUtils.formatDisplayDate(paymentDate), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                    if (!isLockedForMember) {
                        Text("Change", color = IndigoPrimary, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                    }
                }
            }

            // 7. Notes
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                enabled = !isLockedForMember,
                label = { Text("Notes / Remarks (Optional)") },
                placeholder = { Text("e.g. Paid via GooglePay / Monthly meeting") },
                leadingIcon = { Icon(Icons.Default.Notes, contentDescription = null, tint = IndigoPrimary) },
                maxLines = 2,
                modifier = Modifier.fillMaxWidth().testTag("payment_notes_input"),
                shape = RoundedCornerShape(10.dp),
                colors = appOutlinedTextFieldColors()
            )

            if (errorMessage != null) {
                Text(errorMessage!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            // 8. Submit / Re-submit Button (Req 2)
            Button(
                onClick = {
                    if (isLockedForMember) return@Button

                    if (selectedMember == null) {
                        errorMessage = "Please select a member"
                        return@Button
                    }
                    val paid = paidAmountText.toDoubleOrNull()
                    if (paid == null || paid <= 0) {
                        errorMessage = "Please enter a valid paid amount"
                        return@Button
                    }

                    viewModel.submitPayment(
                        memberId = selectedMember!!.id,
                        month = paymentMonth,
                        year = paymentYear,
                        expectedAmount = expectedAmount,
                        paidAmount = paid,
                        paymentMethod = paymentMethod,
                        transactionRef = transactionRef.trim(),
                        notes = notes.trim(),
                        paymentDate = paymentDate
                    ) {
                        onNavigateBack()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("save_payment_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = when {
                        isLockedForMember -> Color(0xFF94A3B8)
                        isUserAdmin -> IndigoPrimary
                        isRejected -> Rose500
                        else -> Emerald500
                    }
                ),
                enabled = !isLockedForMember
            ) {
                Icon(
                    imageVector = when {
                        isLockedForMember -> Icons.Default.Lock
                        isRejected -> Icons.Default.Replay
                        isUserAdmin -> Icons.Default.Check
                        else -> Icons.Default.Send
                    },
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = when {
                        isLockedForMember && isPending -> "Locked (Pending Approval)"
                        isLockedForMember && isApproved -> "Locked (Payment Approved)"
                        isUserAdmin && existingPayment != null -> "Update & Confirm Payment (Admin)"
                        isUserAdmin -> "Confirm & Record Payment (Admin)"
                        isRejected -> "Re-submit Payment for Approval"
                        else -> "Submit Payment for Approval"
                    },
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }
    }
}
