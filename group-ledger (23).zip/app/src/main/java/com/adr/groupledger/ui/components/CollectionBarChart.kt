package com.adr.groupledger.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adr.groupledger.data.model.MonthlyTrendPoint

// Dark Green + Emerald Theme Palette for Collection Trends Chart
private val ChartDarkGreenBg = Color(0xFF111C19)
private val ChartDarkGreenBorder = Color(0xFF1F3A33)
private val ChartCollectedEmerald = Color(0xFF10B981)
private val ChartActiveHighlightEmerald = Color(0xFF34D399)
private val ChartExpectedBar = Color(0xFF233D35)
private val ChartGridLineColor = Color(0x1F10B981) // subtle emerald grid line (alpha ~12%)
private val ChartTextLightEmerald = Color(0xFFD1FAE5) // Soft light emerald text for values
private val ChartTextMutedEmerald = Color(0xFFA7F3D0) // Light emerald for month axis labels
private val ChartLegendMuted = Color(0xFF6EE7B7) // Readable emerald legend label text

@Composable
fun CollectionBarChart(
    trends: List<MonthlyTrendPoint>,
    currencySymbol: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, ChartDarkGreenBorder, RoundedCornerShape(12.dp))
            .testTag("collection_bar_chart"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = ChartDarkGreenBg
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            // Legend
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(ChartCollectedEmerald)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = "Collected",
                    style = MaterialTheme.typography.labelSmall,
                    color = ChartLegendMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.width(14.dp))
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(ChartExpectedBar)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = "Expected",
                    style = MaterialTheme.typography.labelSmall,
                    color = ChartLegendMuted.copy(alpha = 0.8f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (trends.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No collection data recorded yet",
                        style = MaterialTheme.typography.bodySmall,
                        color = ChartTextMutedEmerald.copy(alpha = 0.7f)
                    )
                }
            } else {
                val maxVal = trends.maxOfOrNull { maxOf(it.collected, it.expected) }?.coerceAtLeast(100.0) ?: 100.0

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(124.dp)
                ) {
                    val w = size.width
                    val h = size.height
                    val bottomPadding = 32f
                    val topPadding = 16f
                    val chartHeight = h - bottomPadding - topPadding

                    val groupCount = trends.size
                    val groupWidth = w / groupCount.coerceAtLeast(1)
                    val barWidth = (groupWidth * 0.24f).coerceAtMost(18f)

                    // Draw subtle grid lines
                    for (i in 0..3) {
                        val y = topPadding + (chartHeight / 3) * i
                        drawLine(
                            color = ChartGridLineColor,
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1f
                        )
                    }

                    // Draw bars and labels
                    trends.forEachIndexed { index, point ->
                        val centerX = groupWidth * index + groupWidth / 2

                        // Expected bar (dark muted green container bar)
                        val expFraction = (point.expected / maxVal).toFloat().coerceIn(0f, 1f)
                        val expBarHeight = (chartHeight * expFraction).coerceAtLeast(3f)
                        val expY = topPadding + chartHeight - expBarHeight

                        drawRoundRect(
                            color = ChartExpectedBar,
                            topLeft = Offset(centerX - barWidth - 2f, expY),
                            size = Size(barWidth, expBarHeight),
                            cornerRadius = CornerRadius(3f, 3f)
                        )

                        // Collected bar (vibrant emerald green bar with light emerald highlight on recent/latest)
                        val colFraction = (point.collected / maxVal).toFloat().coerceIn(0f, 1f)
                        val colBarHeight = (chartHeight * colFraction).coerceAtLeast(3f)
                        val colY = topPadding + chartHeight - colBarHeight

                        val barColor = if (index == trends.size - 1 && point.collected > 0) {
                            ChartActiveHighlightEmerald
                        } else {
                            ChartCollectedEmerald
                        }

                        drawRoundRect(
                            color = barColor,
                            topLeft = Offset(centerX + 2f, colY),
                            size = Size(barWidth, colBarHeight),
                            cornerRadius = CornerRadius(3f, 3f)
                        )

                        // Draw Month Label below in soft readable light emerald (#A7F3D0)
                        drawContext.canvas.nativeCanvas.drawText(
                            point.label,
                            centerX,
                            h - 6f,
                            android.graphics.Paint().apply {
                                color = android.graphics.Color.parseColor("#A7F3D0")
                                textSize = 22f
                                textAlign = android.graphics.Paint.Align.CENTER
                                isAntiAlias = true
                            }
                        )

                        // Draw collected amount text above bar in clear light emerald (#D1FAE5)
                        if (point.collected > 0) {
                            val shortAmount = if (point.collected >= 1000) {
                                "${(point.collected / 1000).toInt()}k"
                            } else {
                                "${point.collected.toInt()}"
                            }
                            drawContext.canvas.nativeCanvas.drawText(
                                shortAmount,
                                centerX + 2f + barWidth / 2,
                                (colY - 5f).coerceAtLeast(12f),
                                android.graphics.Paint().apply {
                                    color = android.graphics.Color.parseColor("#D1FAE5")
                                    textSize = 18f
                                    textAlign = android.graphics.Paint.Align.CENTER
                                    isAntiAlias = true
                                    isFakeBoldText = true
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

