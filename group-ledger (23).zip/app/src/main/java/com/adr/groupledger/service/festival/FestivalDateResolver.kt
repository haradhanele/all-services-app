package com.adr.groupledger.service.festival

import com.adr.groupledger.data.model.festival.FestivalDateRule
import com.adr.groupledger.data.model.festival.FestivalDefinition
import java.util.Calendar
import java.util.TimeZone

/**
 * Utility responsible for resolving festival calendar dates and calculating
 * exact celebration activation windows with timezone safety.
 */
object FestivalDateResolver {

    /**
     * Resolves the month (1..12) and day (1..31) for a given festival definition in a specific year.
     *
     * @param festival The festival definition
     * @param year The 4-digit calendar year (e.g. 2026)
     * @return Pair of (month, day) if resolvable and valid, or null if unresolvable/invalid.
     */
    fun resolveDate(festival: FestivalDefinition, year: Int): Pair<Int, Int>? {
        if (year <= 0) return null

        val (month, day) = when (val rule = festival.dateRule) {
            is FestivalDateRule.FixedDate -> {
                Pair(rule.month, rule.day)
            }
            is FestivalDateRule.YearSpecificDate -> {
                rule.datesByYear[year] ?: return null
            }
        }

        // Validate month and day bounds
        if (month !in 1..12 || day !in 1..31) return null

        // Validate max days in month for that year
        val testCal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month - 1)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        val maxDays = testCal.getActualMaximum(Calendar.DAY_OF_MONTH)
        if (day > maxDays) return null

        return Pair(month, day)
    }

    /**
     * Calculates the startAt (00:00:00.000) and endAt (23:59:59.999) timestamps
     * in milliseconds for a festival's celebration window in the specified year.
     *
     * Respects [FestivalDefinition.preEventDays] and [FestivalDefinition.postEventDays].
     * Local calendar timezone is explicitly respected to prevent day-shift anomalies.
     *
     * @param festival The festival definition
     * @param year Target year
     * @param timeZone TimeZone to use (defaults to device/application default)
     * @return Pair of (startAtMs, endAtMs), or null if the date cannot be resolved.
     */
    fun calculateWindow(
        festival: FestivalDefinition,
        year: Int,
        timeZone: TimeZone = TimeZone.getDefault()
    ): Pair<Long, Long>? {
        val (month, day) = resolveDate(festival, year) ?: return null

        val startCal = Calendar.getInstance(timeZone).apply {
            clear()
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month - 1)
            set(Calendar.DAY_OF_MONTH, day)
            if (festival.preEventDays > 0) {
                add(Calendar.DAY_OF_MONTH, -festival.preEventDays)
            }
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val endCal = Calendar.getInstance(timeZone).apply {
            clear()
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month - 1)
            set(Calendar.DAY_OF_MONTH, day)
            if (festival.postEventDays > 0) {
                add(Calendar.DAY_OF_MONTH, festival.postEventDays)
            }
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }

        val startMs = startCal.timeInMillis
        val endMs = endCal.timeInMillis

        return if (startMs <= endMs) Pair(startMs, endMs) else null
    }

    /**
     * Determines whether a festival is currently within its active celebration window
     * on the reference target calendar.
     *
     * @param festival The festival definition
     * @param targetCalendar Reference calendar date (defaults to current system time)
     * @return true if enabled and within [startAt, endAt], false otherwise.
     */
    fun isFestivalActive(
        festival: FestivalDefinition,
        targetCalendar: Calendar = Calendar.getInstance()
    ): Boolean {
        if (!festival.isEnabled) return false
        val year = targetCalendar.get(Calendar.YEAR)
        val window = calculateWindow(festival, year, targetCalendar.timeZone) ?: return false
        val currentTime = targetCalendar.timeInMillis
        return currentTime in window.first..window.second
    }
}
