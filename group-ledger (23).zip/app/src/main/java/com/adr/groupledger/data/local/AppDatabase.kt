package com.adr.groupledger.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.adr.groupledger.data.model.AuditLog
import com.adr.groupledger.data.model.GroupChatMessage
import com.adr.groupledger.data.model.GroupFeedback
import com.adr.groupledger.data.model.GroupJoinRequest
import com.adr.groupledger.data.model.GroupMembership
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.InvestmentRecord
import com.adr.groupledger.data.model.LoanRequest
import com.adr.groupledger.data.model.LoanVote
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.NotificationItem
import com.adr.groupledger.data.model.Payment
import com.adr.groupledger.data.model.PreAuthorizedMember
import com.adr.groupledger.data.model.ProposalVote
import com.adr.groupledger.data.model.SocietyNotice
import com.adr.groupledger.data.model.TransactionRecord
import com.adr.groupledger.data.model.UserAccount
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

@Database(
    entities = [
        UserAccount::class,
        GroupMembership::class,
        Member::class,
        Payment::class,
        GroupSettings::class,
        SocietyNotice::class,
        LoanRequest::class,
        LoanVote::class,
        InvestmentRecord::class,
        GroupFeedback::class,
        ProposalVote::class,
        NotificationItem::class,
        TransactionRecord::class,
        AuditLog::class,
        GroupChatMessage::class,
        PreAuthorizedMember::class,
        GroupJoinRequest::class
    ],
    version = 13,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userAccountDao(): UserAccountDao
    abstract fun groupMembershipDao(): GroupMembershipDao
    abstract fun memberDao(): MemberDao
    abstract fun paymentDao(): PaymentDao
    abstract fun groupSettingsDao(): GroupSettingsDao
    abstract fun noticeDao(): NoticeDao
    abstract fun loanDao(): LoanDao
    abstract fun investmentDao(): InvestmentDao
    abstract fun feedbackDao(): FeedbackDao
    abstract fun notificationDao(): NotificationDao
    abstract fun transactionDao(): TransactionDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun chatMessageDao(): ChatMessageDao
    abstract fun preAuthorizedMemberDao(): PreAuthorizedMemberDao
    abstract fun groupJoinRequestDao(): GroupJoinRequestDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    db.execSQL("ALTER TABLE society_notices ADD COLUMN isPollEnabled INTEGER NOT NULL DEFAULT 0")
                    db.execSQL("ALTER TABLE society_notices ADD COLUMN pollOptions TEXT NOT NULL DEFAULT 'In Favor / Yes,Against / No'")
                    db.execSQL("ALTER TABLE society_notices ADD COLUMN pollExpiryDate INTEGER NOT NULL DEFAULT 0")
                    db.execSQL("ALTER TABLE society_notices ADD COLUMN pollVotesJson TEXT NOT NULL DEFAULT '{}'")
                } catch (e: Exception) {
                    // Fallback to table recreation or ignore if column already exists
                }
            }
        }

        val MIGRATION_10_11 = object : Migration(10, 11) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    db.execSQL("ALTER TABLE members ADD COLUMN dateOfBirth TEXT NOT NULL DEFAULT ''")
                } catch (e: Exception) {
                    // Fallback or ignore if column already exists
                }
            }
        }

        val MIGRATION_11_12 = object : Migration(11, 12) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    db.execSQL("ALTER TABLE group_settings ADD COLUMN ownerUid TEXT NOT NULL DEFAULT ''")
                } catch (e: Exception) {
                    // Fallback or ignore if column already exists
                }
            }
        }

        val MIGRATION_12_13 = object : Migration(12, 13) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    db.execSQL("ALTER TABLE pre_authorized_members ADD COLUMN claimedUid TEXT NOT NULL DEFAULT ''")
                } catch (e: Exception) {
                    // Fallback or ignore if column already exists
                }
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "samiti_society_database.db"
                )
                    .addMigrations(MIGRATION_9_10, MIGRATION_10_11, MIGRATION_11_12, MIGRATION_12_13)
                    .fallbackToDestructiveMigration()
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database)
                    }
                }
            }
        }

        suspend fun populateInitialData(database: AppDatabase) {
            val userDao = database.userAccountDao()
            val membershipDao = database.groupMembershipDao()
            val settingsDao = database.groupSettingsDao()
            val memberDao = database.memberDao()
            val paymentDao = database.paymentDao()
            val loanDao = database.loanDao()
            val investmentDao = database.investmentDao()
            val feedbackDao = database.feedbackDao()
            val notificationDao = database.notificationDao()
            val transactionDao = database.transactionDao()
            val chatDao = database.chatMessageDao()
            val auditDao = database.auditLogDao()

            // 1. Initial Users (Permanent Single User Accounts)
            val initialUsers = listOf(
                UserAccount(
                    id = 1,
                    email = "rajesh.admin@groupledger.org",
                    fullName = "Rajesh Sharma (Admin)",
                    phone = "+91 98310 12345",
                    passwordHash = "123456",
                    isAccountCompleted = true
                ),
                UserAccount(
                    id = 2,
                    email = "amitabh@gmail.com",
                    fullName = "Amitabh Banerjee",
                    phone = "+91 98301 23456",
                    passwordHash = "123456",
                    isAccountCompleted = true
                ),
                UserAccount(
                    id = 3,
                    email = "priya@gmail.com",
                    fullName = "Priya Chakraborty",
                    phone = "+91 98312 34567",
                    passwordHash = "123456",
                    isAccountCompleted = true
                ),
                UserAccount(
                    id = 4,
                    email = "sourav@gmail.com",
                    fullName = "Sourav Ganguly",
                    phone = "+91 98323 45678",
                    passwordHash = "123456",
                    isAccountCompleted = true
                ),
                UserAccount(
                    id = 5,
                    email = "user.e@example.com",
                    fullName = "User E",
                    phone = "+91 98345 67890",
                    passwordHash = "123456",
                    isAccountCompleted = true
                )
            )
            userDao.insertUsers(initialUsers)

            // 2. Initial Group 1 Settings
            val group1 = GroupSettings(
                id = 1,
                groupName = "All services group",
                groupSubtitle = "Community Monthly Contribution & Savings Society",
                inviteCode = "SAMITI-101",
                createdByUserId = 1,
                defaultContribution = 500.0,
                currencySymbol = "₹",
                financialYearStartMonth = 4, // April
                adminName = "Rajesh Sharma",
                adminPhone = "+91 98310 12345",
                adminPin = "1234",
                isPinLockEnabled = false,
                paymentRules = "Contribution is due by the 10th of every month. Unpaid amounts roll over as pending dues."
            )
            settingsDao.insertOrUpdate(group1)

            // 3. Initial Group Memberships for Group 1
            // User 1 is ADMIN, Users 2, 3, 4, 5 are MEMBERS
            val initialMemberships = listOf(
                GroupMembership(
                    id = 1,
                    userId = 1,
                    groupId = 1,
                    role = "ADMIN",
                    memberIdInGroup = null
                ),
                GroupMembership(
                    id = 2,
                    userId = 2,
                    groupId = 1,
                    role = "MEMBER",
                    memberIdInGroup = 1
                ),
                GroupMembership(
                    id = 3,
                    userId = 3,
                    groupId = 1,
                    role = "MEMBER",
                    memberIdInGroup = 2
                ),
                GroupMembership(
                    id = 4,
                    userId = 4,
                    groupId = 1,
                    role = "MEMBER",
                    memberIdInGroup = 3
                ),
                GroupMembership(
                    id = 5,
                    userId = 5,
                    groupId = 1,
                    role = "MEMBER",
                    memberIdInGroup = 5
                )
            )
            membershipDao.insertMemberships(initialMemberships)

            // Current calendar date
            val calendar = Calendar.getInstance()
            val currentYear = calendar.get(Calendar.YEAR)
            val currentMonth = calendar.get(Calendar.MONTH) + 1 // 1..12

            // Base join timestamp: 6 months ago
            val joinCal = Calendar.getInstance().apply {
                add(Calendar.MONTH, -5)
                set(Calendar.DAY_OF_MONTH, 1)
            }
            val joinTimestamp = joinCal.timeInMillis

            // 4. Initial Sample Members for Group 1
            val initialMembers = listOf(
                Member(
                    id = 1,
                    groupId = 1,
                    memberCode = "SAM-001",
                    name = "Amitabh Banerjee",
                    phone = "+91 98301 23456",
                    address = "Flat 3A, Block B, Green Heights",
                    joinDate = joinTimestamp,
                    monthlyContribution = 500.0,
                    isActive = true,
                    notes = "Founder member",
                    dateOfBirth = "1990-%02d-%02d".format(currentMonth, calendar.get(Calendar.DAY_OF_MONTH))
                ),
                Member(
                    id = 2,
                    groupId = 1,
                    memberCode = "SAM-002",
                    name = "Priya Chakraborty",
                    phone = "+91 98312 34567",
                    address = "Plot 12, Lake View Road",
                    joinDate = joinTimestamp,
                    monthlyContribution = 500.0,
                    isActive = true,
                    notes = "Regular payer",
                    dateOfBirth = "1994-08-20"
                ),
                Member(
                    id = 3,
                    groupId = 1,
                    memberCode = "SAM-003",
                    name = "Sourav Ganguly",
                    phone = "+91 98323 45678",
                    address = "House 45, VIP Enclave",
                    joinDate = joinTimestamp,
                    monthlyContribution = 1000.0,
                    isActive = true,
                    notes = "Patron tier contribution"
                ),
                Member(
                    id = 4,
                    groupId = 1,
                    memberCode = "SAM-004",
                    name = "Ananya Mukherjee",
                    phone = "+91 98334 56789",
                    address = "Tower 2, Apt 804, Regency Park",
                    joinDate = joinTimestamp,
                    monthlyContribution = 500.0,
                    isActive = true,
                    notes = ""
                ),
                Member(
                    id = 5,
                    groupId = 1,
                    memberCode = "SAM-005",
                    name = "Debasish Roy (User E)",
                    phone = "+91 98345 67890",
                    address = "B-14, Shantiniketan Society",
                    joinDate = joinTimestamp,
                    monthlyContribution = 500.0,
                    isActive = true,
                    notes = "User E member profile in Group 1"
                ),
                Member(
                    id = 6,
                    groupId = 1,
                    memberCode = "SAM-006",
                    name = "Sunita Sen",
                    phone = "+91 98356 78901",
                    address = "12/1 Deshapriya Park",
                    joinDate = joinTimestamp,
                    monthlyContribution = 500.0,
                    isActive = true,
                    notes = ""
                ),
                Member(
                    id = 7,
                    groupId = 1,
                    memberCode = "SAM-007",
                    name = "Vikram Aditya",
                    phone = "+91 98367 89012",
                    address = "78 Rashbehari Avenue",
                    joinDate = joinTimestamp,
                    monthlyContribution = 500.0,
                    isActive = true,
                    notes = ""
                ),
                Member(
                    id = 8,
                    groupId = 1,
                    memberCode = "SAM-008",
                    name = "Mousumi Das",
                    phone = "+91 98378 90123",
                    address = "C-5, Sunrise Apartment",
                    joinDate = joinTimestamp,
                    monthlyContribution = 750.0,
                    isActive = true,
                    notes = ""
                )
            )
            memberDao.insertMembers(initialMembers)

            // 5. Populate Group 1 Payments
            val paymentList = mutableListOf<Payment>()
            for (mOffset in -4..0) {
                val mCal = Calendar.getInstance().apply {
                    add(Calendar.MONTH, mOffset)
                }
                val mYear = mCal.get(Calendar.YEAR)
                val mMonth = mCal.get(Calendar.MONTH) + 1

                for (member in initialMembers) {
                    val exp = if (member.monthlyContribution > 0) member.monthlyContribution else 500.0

                    if (mOffset < 0) {
                        when (member.id) {
                            1L, 2L, 3L, 4L -> {
                                paymentList.add(
                                    Payment(
                                        groupId = 1,
                                        memberId = member.id,
                                        month = mMonth,
                                        year = mYear,
                                        expectedAmount = exp,
                                        paidAmount = exp,
                                        dueAmount = 0.0,
                                        paymentDate = mCal.timeInMillis + 86400000L * 5,
                                        paymentMethod = if (member.id % 2L == 0L) "UPI" else "Cash",
                                        transactionReference = if (member.id % 2L == 0L) "UPI/REF/${mYear}${mMonth}/${member.id}08" else "",
                                        notes = "Monthly deposit received on time",
                                        status = "PAID"
                                    )
                                )
                            }
                            5L -> {
                                val paid = if (mOffset == -1) 300.0 else exp
                                val due = exp - paid
                                paymentList.add(
                                    Payment(
                                        groupId = 1,
                                        memberId = member.id,
                                        month = mMonth,
                                        year = mYear,
                                        expectedAmount = exp,
                                        paidAmount = paid,
                                        dueAmount = due,
                                        paymentDate = mCal.timeInMillis + 86400000L * 8,
                                        paymentMethod = "UPI",
                                        transactionReference = "UPI/TXN/${mYear}${mMonth}55",
                                        notes = if (due > 0) "Part payment of ₹300 made" else "Paid",
                                        status = if (due > 0) "PARTIAL" else "PAID"
                                    )
                                )
                            }
                            6L, 7L, 8L -> {
                                paymentList.add(
                                    Payment(
                                        groupId = 1,
                                        memberId = member.id,
                                        month = mMonth,
                                        year = mYear,
                                        expectedAmount = exp,
                                        paidAmount = exp,
                                        dueAmount = 0.0,
                                        paymentDate = mCal.timeInMillis + 86400000L * 3,
                                        paymentMethod = "Bank Transfer",
                                        transactionReference = "IMPS/NEFT/${mYear}${mMonth}99",
                                        notes = "Verified bank transfer",
                                        status = "PAID"
                                    )
                                )
                            }
                        }
                    } else {
                        when (member.id) {
                            1L -> paymentList.add(
                                Payment(
                                    groupId = 1,
                                    memberId = member.id,
                                    month = mMonth,
                                    year = mYear,
                                    expectedAmount = exp,
                                    paidAmount = exp,
                                    dueAmount = 0.0,
                                    paymentDate = System.currentTimeMillis() - 86400000L * 2,
                                    paymentMethod = "Cash",
                                    transactionReference = "REC-CURR-01",
                                    notes = "Paid in cash to Treasurer",
                                    status = "PAID"
                                )
                            )
                            2L -> paymentList.add(
                                Payment(
                                    groupId = 1,
                                    memberId = member.id,
                                    month = mMonth,
                                    year = mYear,
                                    expectedAmount = exp,
                                    paidAmount = exp,
                                    dueAmount = 0.0,
                                    paymentDate = System.currentTimeMillis() - 86400000L,
                                    paymentMethod = "UPI",
                                    transactionReference = "UPI/GPAY/9831/11",
                                    notes = "Google Pay received",
                                    status = "PAID"
                                )
                            )
                            3L -> paymentList.add(
                                Payment(
                                    groupId = 1,
                                    memberId = member.id,
                                    month = mMonth,
                                    year = mYear,
                                    expectedAmount = exp,
                                    paidAmount = exp,
                                    dueAmount = 0.0,
                                    paymentDate = System.currentTimeMillis() - 86400000L * 3,
                                    paymentMethod = "Bank Transfer",
                                    transactionReference = "HDFC0012984",
                                    notes = "Netbanking auto-credit",
                                    status = "PAID"
                                )
                            )
                            5L -> paymentList.add(
                                Payment(
                                    groupId = 1,
                                    memberId = member.id,
                                    month = mMonth,
                                    year = mYear,
                                    expectedAmount = exp,
                                    paidAmount = 250.0,
                                    dueAmount = 250.0,
                                    paymentDate = System.currentTimeMillis() - 3600000L * 12,
                                    paymentMethod = "UPI",
                                    transactionReference = "PhonePe/88392",
                                    notes = "Remaining ₹250 promised by weekend",
                                    status = "PARTIAL"
                                )
                            )
                            4L -> paymentList.add(
                                Payment(
                                    groupId = 1,
                                    memberId = member.id,
                                    month = mMonth,
                                    year = mYear,
                                    expectedAmount = exp,
                                    paidAmount = 0.0,
                                    dueAmount = exp,
                                    paymentDate = System.currentTimeMillis(),
                                    paymentMethod = "None",
                                    transactionReference = "",
                                    notes = "Pending",
                                    status = "UNPAID"
                                )
                            )
                            6L -> paymentList.add(
                                Payment(
                                    groupId = 1,
                                    memberId = member.id,
                                    month = mMonth,
                                    year = mYear,
                                    expectedAmount = exp,
                                    paidAmount = 0.0,
                                    dueAmount = exp,
                                    paymentDate = System.currentTimeMillis(),
                                    paymentMethod = "None",
                                    transactionReference = "",
                                    notes = "Pending",
                                    status = "UNPAID"
                                )
                            )
                        }
                    }
                }
            }
            paymentDao.insertPayments(paymentList)

            // 6. Sample Group 1 Notices
            val noticeDao = database.noticeDao()
            noticeDao.insertNotice(
                SocietyNotice(
                    groupId = 1,
                    title = "📢 Monthly Samiti Contribution Due",
                    content = "Dear members, kindly clear your monthly contribution by the 10th of this month. Digital receipts are generated automatically.",
                    category = "COLLECTION",
                    author = "Treasurer",
                    timestamp = System.currentTimeMillis() - 86400000L * 2,
                    isPinned = true
                )
            )

            // 7. Sample Group 1 Loans & Voting
            val loan1 = LoanRequest(
                id = 1,
                groupId = 1,
                requesterMemberId = 4,
                requesterName = "Ananya Mukherjee",
                requesterPhone = "+91 98334 56789",
                requestedAmount = 50000.0,
                purpose = "Small Business Expansion",
                reason = "Purchasing boutique inventory for upcoming festive season sale",
                duration = 6,
                durationUnit = "Months",
                expectedRepaymentDate = System.currentTimeMillis() + (180L * 86400000L),
                note = "Will repay in equal monthly installments of ₹8,500 with standard 1% group interest.",
                createdAt = System.currentTimeMillis() - (12L * 3600000L),
                votingDeadline = System.currentTimeMillis() + (36L * 3600000L),
                status = "VOTING",
                repaidAmount = 0.0,
                remainingAmount = 50000.0
            )
            val loan2 = LoanRequest(
                id = 2,
                groupId = 1,
                requesterMemberId = 5,
                requesterName = "Debasish Roy (User E)",
                requesterPhone = "+91 98345 67890",
                requestedAmount = 30000.0,
                purpose = "Medical Emergency",
                reason = "Hospitalization bill settlement for family member",
                duration = 4,
                durationUnit = "Months",
                expectedRepaymentDate = System.currentTimeMillis() + (120L * 86400000L),
                note = "Approved by general body. Disbursed via Bank IMPS.",
                createdAt = System.currentTimeMillis() - (25L * 86400000L),
                votingDeadline = System.currentTimeMillis() - (23L * 86400000L),
                status = "ACTIVE",
                disbursedDate = System.currentTimeMillis() - (22L * 86400000L),
                disbursedBy = "Treasurer Rajesh Sharma",
                repaidAmount = 15000.0,
                remainingAmount = 15000.0
            )
            loanDao.insertLoan(loan1)
            loanDao.insertLoan(loan2)

            loanDao.insertVote(LoanVote(loanRequestId = 1, memberId = 1, memberName = "Amitabh Banerjee", vote = "APPROVE"))
            loanDao.insertVote(LoanVote(loanRequestId = 1, memberId = 2, memberName = "Priya Chakraborty", vote = "APPROVE"))
            loanDao.insertVote(LoanVote(loanRequestId = 1, memberId = 3, memberName = "Sourav Ganguly", vote = "APPROVE"))
            loanDao.insertVote(LoanVote(loanRequestId = 1, memberId = 6, memberName = "Sunita Sen", vote = "APPROVE"))

            // 8. Sample Group 1 Investments
            val investments = listOf(
                InvestmentRecord(
                    id = 1,
                    groupId = 1,
                    type = "FD",
                    institution = "State Bank of India",
                    name = "SBI 3-Year Fixed Deposit",
                    principalAmount = 250000.0,
                    currentValue = 278500.0,
                    investmentDate = System.currentTimeMillis() - (365L * 86400000L),
                    maturityDate = System.currentTimeMillis() + (730L * 86400000L),
                    expectedReturn = 7.1,
                    status = "ACTIVE",
                    notes = "Interest compounded quarterly. Certificate in locker."
                ),
                InvestmentRecord(
                    id = 2,
                    groupId = 1,
                    type = "MUTUAL_FUND",
                    institution = "Groww / Nippon India",
                    name = "Nippon India Large Cap Fund",
                    principalAmount = 150000.0,
                    currentValue = 176200.0,
                    investmentDate = System.currentTimeMillis() - (180L * 86400000L),
                    status = "ACTIVE",
                    notes = "Direct growth plan for long-term corpus appreciation."
                ),
                InvestmentRecord(
                    id = 3,
                    groupId = 1,
                    type = "STOCK",
                    institution = "Zerodha",
                    name = "NIFTY 50 BeES ETF",
                    principalAmount = 100000.0,
                    currentValue = 114800.0,
                    investmentDate = System.currentTimeMillis() - (120L * 86400000L),
                    status = "ACTIVE",
                    notes = "Index tracking ETF for safe equity allocation."
                )
            )
            investmentDao.insertInvestments(investments)

            // 9. Sample Group 1 Feedback
            val fb1 = GroupFeedback(
                id = 1,
                groupId = 1,
                type = "PROPOSAL",
                memberId = 3,
                memberName = "Sourav Ganguly",
                isAnonymous = false,
                subject = "Increase monthly contribution to ₹750 from next FY",
                description = "To grow our emergency medical reserve faster and provide higher loan limits to members.",
                createdAt = System.currentTimeMillis() - (4L * 86400000L),
                status = "DISCUSSING",
                requiresVoting = true,
                votingThresholdPercent = 70
            )
            val fb2 = GroupFeedback(
                id = 2,
                groupId = 1,
                type = "SUGGESTION",
                memberId = 2,
                memberName = "Priya Chakraborty",
                isAnonymous = false,
                subject = "Annual cultural picnic & children awards",
                description = "Let's organize an annual family get-together in December utilizing 5% of our surplus interest.",
                createdAt = System.currentTimeMillis() - (2L * 86400000L),
                status = "UNDER_REVIEW"
            )
            val fb3 = GroupFeedback(
                id = 3,
                groupId = 1,
                type = "COMPLAINT",
                memberId = 5,
                memberName = "Anonymous Member",
                isAnonymous = true,
                subject = "Delayed receipts for cash payments",
                description = "Kindly ensure receipts are updated in the app within 24 hours of cash handover.",
                createdAt = System.currentTimeMillis() - (1L * 86400000L),
                status = "RESOLVED",
                adminResponse = "Noted. We now issue real-time digital entry upon cash receipt."
            )
            feedbackDao.insertFeedback(fb1)
            feedbackDao.insertFeedback(fb2)
            feedbackDao.insertFeedback(fb3)

            feedbackDao.insertProposalVote(ProposalVote(feedbackId = 1, memberId = 1, memberName = "Amitabh Banerjee", vote = "AGREE"))
            feedbackDao.insertProposalVote(ProposalVote(feedbackId = 1, memberId = 2, memberName = "Priya Chakraborty", vote = "AGREE"))
            feedbackDao.insertProposalVote(ProposalVote(feedbackId = 1, memberId = 6, memberName = "Sunita Sen", vote = "AGREE"))

            // 10. Sample Group 1 Notifications
            val notifications = listOf(
                NotificationItem(
                    id = 1,
                    groupId = 1,
                    title = "New Group Loan Request",
                    message = "A member has requested ₹50,000 for Business. Your vote is requested.",
                    type = "LOAN_VOTING",
                    timestamp = System.currentTimeMillis() - (12L * 3600000L),
                    isRead = false,
                    relatedId = 1,
                    actionRoute = "loans"
                ),
                NotificationItem(
                    id = 2,
                    groupId = 1,
                    title = "New Proposal for Group Voting",
                    message = "Proposal: Increase monthly contribution to ₹750 from next FY.",
                    type = "PROPOSAL",
                    timestamp = System.currentTimeMillis() - (4L * 86400000L),
                    isRead = false,
                    relatedId = 1,
                    actionRoute = "feedback"
                ),
                NotificationItem(
                    id = 3,
                    groupId = 1,
                    title = "Monthly Contribution Reminder",
                    message = "Monthly contribution is due. Tap to view payment status.",
                    type = "CONTRIBUTION_REMINDER",
                    timestamp = System.currentTimeMillis() - (86400000L * 2),
                    isRead = true,
                    actionRoute = "monthly"
                ),
                NotificationItem(
                    id = 4,
                    groupId = 1,
                    title = "Investment Portfolio Growth",
                    message = "Total group investments value reached ₹5,69,500 (Gain: +₹69,500).",
                    type = "INVESTMENT_UPDATE",
                    timestamp = System.currentTimeMillis() - (86400000L * 7),
                    isRead = true,
                    actionRoute = "investments"
                )
            )
            notificationDao.insertNotifications(notifications)

            // 11. Sample Group 1 Financial Transactions
            val transactions = listOf(
                TransactionRecord(
                    id = 1,
                    groupId = 1,
                    txnNumber = "TXN-2026-001",
                    date = System.currentTimeMillis() - (86400000L * 2),
                    amount = 500.0,
                    type = "CONTRIBUTION",
                    isCredit = true,
                    description = "Monthly contribution received from Amitabh Banerjee",
                    paymentMethod = "Cash",
                    relatedMemberId = 1,
                    relatedMemberName = "Amitabh Banerjee",
                    createdBy = "Treasurer"
                ),
                TransactionRecord(
                    id = 2,
                    groupId = 1,
                    txnNumber = "TXN-2026-002",
                    date = System.currentTimeMillis() - (86400000L * 1),
                    amount = 500.0,
                    type = "CONTRIBUTION",
                    isCredit = true,
                    description = "Monthly contribution received from Priya Chakraborty",
                    paymentMethod = "UPI",
                    relatedMemberId = 2,
                    relatedMemberName = "Priya Chakraborty",
                    createdBy = "Treasurer"
                ),
                TransactionRecord(
                    id = 3,
                    groupId = 1,
                    txnNumber = "TXN-2026-003",
                    date = System.currentTimeMillis() - (86400000L * 15),
                    amount = 15000.0,
                    type = "LOAN_REPAYMENT",
                    isCredit = true,
                    description = "Loan repayment (Part 1) received from Debasish Roy",
                    paymentMethod = "UPI",
                    relatedMemberId = 5,
                    relatedMemberName = "Debasish Roy",
                    relatedLoanId = 2,
                    createdBy = "Treasurer"
                ),
                TransactionRecord(
                    id = 4,
                    groupId = 1,
                    txnNumber = "TXN-2026-004",
                    date = System.currentTimeMillis() - (86400000L * 22),
                    amount = 30000.0,
                    type = "LOAN_DISBURSEMENT",
                    isCredit = false,
                    description = "Emergency loan disbursed to Debasish Roy",
                    paymentMethod = "Bank Transfer",
                    relatedMemberId = 5,
                    relatedMemberName = "Debasish Roy",
                    relatedLoanId = 2,
                    createdBy = "Admin"
                )
            )
            transactionDao.insertTransactions(transactions)

            // 12. Sample Group 1 Chat Messages
            val chatMessages = listOf(
                GroupChatMessage(
                    id = 1,
                    groupId = 1,
                    senderId = 1,
                    senderName = "Amitabh Banerjee",
                    senderRole = "President",
                    message = "Welcome everyone to our new All services group portal! We can now track accounts, loans, and votes transparently.",
                    timestamp = System.currentTimeMillis() - (86400000L * 3),
                    isAnnouncement = true
                ),
                GroupChatMessage(
                    id = 2,
                    groupId = 1,
                    senderId = 2,
                    senderName = "Priya Chakraborty",
                    senderRole = "Member",
                    message = "Great initiative! It is very easy to see the bank balance and monthly receipts now.",
                    timestamp = System.currentTimeMillis() - (86400000L * 2)
                ),
                GroupChatMessage(
                    id = 3,
                    groupId = 1,
                    senderId = 0,
                    senderName = "Treasurer Rajesh Sharma",
                    senderRole = "Treasurer",
                    message = "Please review the active loan request from Ananya and cast your vote before the deadline expires.",
                    timestamp = System.currentTimeMillis() - (86400000L * 1),
                    isAnnouncement = false
                )
            )
            chatDao.insertMessages(chatMessages)

            // 13. Initial Audit Log
            auditDao.insertAuditLog(
                AuditLog(
                    groupId = 1,
                    actorName = "System",
                    actorRole = "System",
                    action = "INITIAL_SETUP",
                    previousValue = "None",
                    newValue = "Database initialized with Multi-Group schema v6",
                    relatedRecord = "System Initialization"
                )
            )
        }
    }
}
