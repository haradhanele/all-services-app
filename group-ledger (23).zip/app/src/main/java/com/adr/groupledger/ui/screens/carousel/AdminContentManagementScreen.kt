package com.adr.groupledger.ui.screens.carousel

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Festival
import androidx.compose.material.icons.filled.Gif
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.ViewCarousel
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.adr.groupledger.data.model.AppRole
import com.adr.groupledger.data.model.carousel.CarouselActionType
import com.adr.groupledger.data.model.carousel.CarouselContentType
import com.adr.groupledger.data.model.carousel.CarouselItem
import com.adr.groupledger.data.model.carousel.MediaType
import com.adr.groupledger.ui.theme.BorderSubtle
import com.adr.groupledger.ui.theme.CanvasBackground
import com.adr.groupledger.ui.theme.CardWhite
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoHeroDark
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.TextSlate400
import com.adr.groupledger.ui.theme.TextSlate500
import com.adr.groupledger.ui.theme.TextSlate800
import com.adr.groupledger.ui.viewmodel.CarouselContentViewModel
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminContentManagementScreen(
    societyViewModel: SocietyViewModel,
    modifier: Modifier = Modifier,
    contentViewModel: CarouselContentViewModel = viewModel(factory = CarouselContentViewModel.provideFactory()),
    onNavigateBack: () -> Unit,
    onNavigateToCreate: () -> Unit,
    onNavigateToEdit: (String) -> Unit
) {
    val appRole by societyViewModel.appRole.collectAsStateWithLifecycle()
    val activeGroupRole by societyViewModel.activeGroupRole.collectAsStateWithLifecycle()
    val items by contentViewModel.filteredItems.collectAsStateWithLifecycle()
    val allItems by contentViewModel.allItems.collectAsStateWithLifecycle()
    val isLoading by contentViewModel.isLoading.collectAsStateWithLifecycle()
    val userMessage by contentViewModel.userMessage.collectAsStateWithLifecycle()
    val errorMessage by contentViewModel.errorMessage.collectAsStateWithLifecycle()
    val searchQuery by contentViewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedTypeFilter by contentViewModel.selectedTypeFilter.collectAsStateWithLifecycle()
    val selectedStatusFilter by contentViewModel.selectedStatusFilter.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var itemToDelete by remember { mutableStateOf<CarouselItem?>(null) }
    var showRoleSimulatorDialog by remember { mutableStateOf(false) }

    LaunchedEffect(userMessage) {
        userMessage?.let {
            snackbarHostState.showSnackbar(it)
            contentViewModel.clearUserMessage()
        }
    }

    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            snackbarHostState.showSnackbar("Error: $it")
            contentViewModel.clearErrorMessage()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Content Studio",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextSlate800
                        )
                        Text(
                            text = "Platform Carousel & Promotions",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSlate500
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("admin_content_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextSlate800
                        )
                    }
                },
                actions = {
                    if (appRole.canManageCarousel) {
                        IconButton(
                            onClick = { contentViewModel.syncPromotionAutomation() },
                            modifier = Modifier.testTag("admin_sync_promotions_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalOffer,
                                contentDescription = "Sync Promotion Campaigns",
                                tint = IndigoPrimary
                            )
                        }
                        IconButton(
                            onClick = { contentViewModel.syncFestivalAutomation() },
                            modifier = Modifier.testTag("admin_sync_festivals_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Festival,
                                contentDescription = "Sync Festival Slides",
                                tint = IndigoPrimary
                            )
                        }
                    }
                    // Developer role tester button (allows testing and switching between Group Admin vs App Admin)
                    IconButton(
                        onClick = { showRoleSimulatorDialog = true },
                        modifier = Modifier.testTag("admin_role_simulator_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "App Role Simulator",
                            tint = if (appRole.canManageCarousel) IndigoPrimary else TextSlate400
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = CardWhite)
            )
        },
        floatingActionButton = {
            if (appRole.canManageCarousel) {
                ExtendedFloatingActionButton(
                    onClick = onNavigateToCreate,
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text("New Slide", fontWeight = FontWeight.Bold) },
                    containerColor = IndigoPrimary,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("create_carousel_fab")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(CanvasBackground)
        ) {
            // =========================================================================
            // ROLE SECURITY GUARD: Group Admin vs Application Admin Distinction
            // =========================================================================
            if (!appRole.canManageCarousel) {
                AccessRestrictedGuard(
                    activeGroupRole = activeGroupRole.displayName,
                    currentAppRole = appRole.displayName,
                    onSimulateAppAdmin = {
                        societyViewModel.updateAppRole(AppRole.APP_ADMIN)
                    },
                    onSimulateContentManager = {
                        societyViewModel.updateAppRole(AppRole.CONTENT_MANAGER)
                    },
                    onBack = onNavigateBack
                )
            } else {
                // =====================================================================
                // AUTHORIZED CONTENT MANAGEMENT STUDIO UI
                // =====================================================================
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 88.dp)
                ) {
                    // 1. App Role Header Badge & Scope Banner
                    item {
                        AppRoleHeaderBanner(appRole = appRole)
                    }

                    // 2. Metrics Summary Row
                    item {
                        MetricsSummaryRow(
                            total = allItems.size,
                            active = allItems.count { it.isActive },
                            scheduled = allItems.count { it.startAt > 0L || it.endAt > 0L }
                        )
                    }

                    // 3. Search Field
                    item {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { contentViewModel.setSearchQuery(it) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("carousel_search_field"),
                            placeholder = { Text("Search by title, message, or keyword...") },
                            leadingIcon = {
                                Icon(Icons.Default.Search, contentDescription = null, tint = TextSlate400)
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { contentViewModel.setSearchQuery("") }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear search", tint = TextSlate400)
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = CardWhite,
                                unfocusedContainerColor = CardWhite,
                                focusedBorderColor = IndigoPrimary,
                                unfocusedBorderColor = BorderSubtle
                            )
                        )
                    }

                    // 4. Status Filter Chips (All / Active / Inactive)
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("ALL" to "All Slides", "ACTIVE" to "Active Only", "INACTIVE" to "Inactive Only").forEach { (key, label) ->
                                val isSelected = selectedStatusFilter == key
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { contentViewModel.setStatusFilter(key) },
                                    label = { Text(label, fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = IndigoPrimary.copy(alpha = 0.12f),
                                        selectedLabelColor = IndigoPrimary
                                    )
                                )
                            }
                        }
                    }

                    // 5. Content Type Filter Chips (Horizontal Scroll)
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = selectedTypeFilter == null,
                                onClick = { contentViewModel.setTypeFilter(null) },
                                label = { Text("All Categories", fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IndigoPrimary.copy(alpha = 0.12f),
                                    selectedLabelColor = IndigoPrimary
                                )
                            )

                            CarouselContentType.entries.forEach { type ->
                                val isSelected = selectedTypeFilter == type
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        contentViewModel.setTypeFilter(if (isSelected) null else type)
                                    },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = getContentTypeIcon(type),
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    },
                                    label = { Text(type.name, fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = getContentTypeColor(type).copy(alpha = 0.15f),
                                        selectedLabelColor = getContentTypeColor(type)
                                    )
                                )
                            }
                        }
                    }

                    // 6. Carousel Items List / Empty State
                    if (items.isEmpty()) {
                        item {
                            EmptyContentState(
                                onNewSlide = onNavigateToCreate,
                                isSearching = searchQuery.isNotBlank() || selectedTypeFilter != null
                            )
                        }
                    } else {
                        items(items, key = { it.id }) { item ->
                            CarouselItemCard(
                                item = item,
                                onEdit = { onNavigateToEdit(item.id) },
                                onToggleActive = { contentViewModel.toggleItemActive(item) },
                                onDelete = { itemToDelete = item }
                            )
                        }
                    }
                }
            }

            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = IndigoPrimary)
                }
            }
        }
    }

    // Delete Confirmation Dialog
    itemToDelete?.let { item ->
        AlertDialog(
            onDismissRequest = { itemToDelete = null },
            icon = { Icon(Icons.Default.Delete, contentDescription = null, tint = Rose500) },
            title = { Text("Delete Carousel Slide?") },
            text = {
                Text("Are you sure you want to delete \"${item.title}\"? This action removes the slide from the application carousel.")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        contentViewModel.deleteItem(item.id)
                        itemToDelete = null
                    },
                    modifier = Modifier.testTag("confirm_delete_button")
                ) {
                    Text("Delete", color = Rose500, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { itemToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Role Simulator Dialog (For development & testing verification of role separation)
    if (showRoleSimulatorDialog) {
        RoleSimulatorDialog(
            currentAppRole = appRole,
            onSelectRole = { newRole ->
                societyViewModel.updateAppRole(newRole)
                showRoleSimulatorDialog = false
            },
            onDismiss = { showRoleSimulatorDialog = false }
        )
    }
}

// =========================================================================
// UI Component: Access Restricted Guard (Protects against Group Admin confusion)
// =========================================================================
@Composable
private fun AccessRestrictedGuard(
    activeGroupRole: String,
    currentAppRole: String,
    onSimulateAppAdmin: () -> Unit,
    onSimulateContentManager: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            shape = CircleShape,
            color = Color(0xFFFEE2E2),
            modifier = Modifier.size(80.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = Rose500,
                    modifier = Modifier.size(40.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Access Restricted",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = TextSlate800
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Application-Level Permissions Required",
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
            color = TextSlate500
        )

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = CardWhite),
            border = BorderStroke(1.dp, BorderSubtle)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Security Architecture Notice",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = IndigoHeroDark
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Group Administrators manage local group records (e.g. society members and dues). Global carousel promotions, festival banners, and announcements require Application Administrator or Content Manager credentials.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSlate500,
                    lineHeight = 18.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Your Group Role:", style = MaterialTheme.typography.bodySmall, color = TextSlate400)
                    Text(activeGroupRole, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = TextSlate800)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Your App Role:", style = MaterialTheme.typography.bodySmall, color = TextSlate400)
                    Text(currentAppRole, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Rose500)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Development Testing Controls
        Text(
            text = "Development Mode: Switch App Role to Test",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
            color = TextSlate500
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = onSimulateContentManager,
                modifier = Modifier.weight(1f).testTag("simulate_content_manager_button")
            ) {
                Text("Content Manager", fontSize = 12.sp)
            }
            OutlinedButton(
                onClick = onSimulateAppAdmin,
                modifier = Modifier.weight(1f).testTag("simulate_app_admin_button")
            ) {
                Text("App Admin", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedButton(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Return to More Options")
        }
    }
}

// =========================================================================
// UI Component: App Role Header Banner
// =========================================================================
@Composable
private fun AppRoleHeaderBanner(appRole: AppRole) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = IndigoHeroDark),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.15f),
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Campaign,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Application Content Studio",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
                Text(
                    text = "Authorized as: ${appRole.displayName} • Global Scope (All Groups)",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.8f)
                )
            }
        }
    }
}

// =========================================================================
// UI Component: Metrics Summary Row
// =========================================================================
@Composable
private fun MetricsSummaryRow(total: Int, active: Int, scheduled: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        MetricCard(
            label = "Total Slides",
            value = total.toString(),
            icon = Icons.Default.ViewCarousel,
            tint = IndigoPrimary,
            modifier = Modifier.weight(1f)
        )
        MetricCard(
            label = "Active Now",
            value = active.toString(),
            icon = Icons.Default.TrendingUp,
            tint = Emerald500,
            modifier = Modifier.weight(1f)
        )
        MetricCard(
            label = "Scheduled",
            value = scheduled.toString(),
            icon = Icons.Default.Festival,
            tint = Color(0xFFF59E0B),
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun MetricCard(
    label: String,
    value: String,
    icon: ImageVector,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite),
        border = BorderStroke(1.dp, BorderSubtle)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = value, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = TextSlate800)
            Text(text = label, style = MaterialTheme.typography.bodySmall, color = TextSlate500, maxLines = 1)
        }
    }
}

// =========================================================================
// UI Component: Carousel Item Card
// =========================================================================
@Composable
private fun CarouselItemCard(
    item: CarouselItem,
    onEdit: () -> Unit,
    onToggleActive: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("carousel_card_${item.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite),
        border = BorderStroke(1.dp, if (item.isActive) IndigoPrimary.copy(alpha = 0.25f) else BorderSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Content Type Badge, Priority chip, Active Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Content Type Badge
                    ContentTypeBadge(type = item.contentType)

                    // Priority Chip
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = CanvasBackground,
                        border = BorderStroke(1.dp, BorderSubtle)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("P${item.priority}", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = TextSlate800)
                        }
                    }

                    // Media Type indicator (Image / GIF)
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = CanvasBackground,
                        border = BorderStroke(1.dp, BorderSubtle)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val isGif = item.mediaResource?.mediaType == MediaType.GIF
                            Icon(
                                imageVector = if (isGif) Icons.Default.Gif else Icons.Default.Image,
                                contentDescription = null,
                                tint = if (isGif) Rose500 else IndigoPrimary,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = if (isGif) "GIF" else "IMG",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSlate500
                            )
                        }
                    }
                }

                // Active Switch
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (item.isActive) "Active" else "Off",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = if (item.isActive) Emerald500 else TextSlate400,
                        modifier = Modifier.padding(end = 6.dp)
                    )
                    Switch(
                        checked = item.isActive,
                        onCheckedChange = { onToggleActive() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Emerald500,
                            uncheckedThumbColor = Color.White,
                            uncheckedTrackColor = TextSlate400.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier.testTag("toggle_switch_${item.id}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Body: Title and Message
            Text(
                text = item.title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TextSlate800,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = item.message,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSlate500,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Schedule & CTA Info Bar
            ScheduleAndCtaBar(item = item)

            Spacer(modifier = Modifier.height(10.dp))

            // Footer Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onEdit,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("edit_button_${item.id}")
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Edit Slide", fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.testTag("delete_button_${item.id}")
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete slide", tint = Rose500)
                }
            }
        }
    }
}

// =========================================================================
// UI Component: Schedule & CTA Bar
// =========================================================================
@Composable
private fun ScheduleAndCtaBar(item: CarouselItem) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = CanvasBackground,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            // Schedule Info
            val sdf = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
            val scheduleText = if (item.startAt <= 0L && item.endAt <= 0L) {
                "Always Active (No expiration)"
            } else {
                val start = if (item.startAt > 0L) sdf.format(Date(item.startAt)) else "Now"
                val end = if (item.endAt > 0L) sdf.format(Date(item.endAt)) else "Forever"
                "Scheduled: $start → $end"
            }
            Text(
                text = scheduleText,
                style = MaterialTheme.typography.bodySmall,
                color = TextSlate500,
                fontSize = 11.sp
            )

            // CTA Info if configured
            if (item.actionType != CarouselActionType.NONE) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "CTA: \"${item.actionLabel.ifBlank { "Action" }}\" → [${item.actionType.name}: ${item.actionTarget}]",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                    color = IndigoPrimary,
                    fontSize = 11.sp
                )
            }
        }
    }
}

// =========================================================================
// UI Component: Content Type Badge
// =========================================================================
@Composable
private fun ContentTypeBadge(type: CarouselContentType) {
    val color = getContentTypeColor(type)
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = color.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = getContentTypeIcon(type),
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = type.name,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = color
            )
        }
    }
}

// =========================================================================
// UI Component: Empty State
// =========================================================================
@Composable
private fun EmptyContentState(
    onNewSlide: () -> Unit,
    isSearching: Boolean
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite),
        border = BorderStroke(1.dp, BorderSubtle)
    ) {
        Column(
            modifier = Modifier.padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                shape = CircleShape,
                color = CanvasBackground,
                modifier = Modifier.size(64.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (isSearching) Icons.Default.Search else Icons.Default.ViewCarousel,
                        contentDescription = null,
                        tint = TextSlate400,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = if (isSearching) "No matching slides found" else "No Carousel Slides Yet",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TextSlate800
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = if (isSearching) "Try adjusting your search terms or category filters." else "Create your first global celebration, announcement, festival greeting, or promotional offer.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSlate500,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            if (!isSearching) {
                Spacer(modifier = Modifier.height(18.dp))
                OutlinedButton(
                    onClick = onNewSlide,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Create New Slide")
                }
            }
        }
    }
}

// =========================================================================
// UI Component: Role Simulator Dialog (For development verification)
// =========================================================================
@Composable
private fun RoleSimulatorDialog(
    currentAppRole: AppRole,
    onSelectRole: (AppRole) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Simulate Application Role", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Verify that Group Admins (e.g. of CC CUP) remain Regular Users at the app level, while App Admins / Content Managers have Content Studio access.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSlate500
                )
                Spacer(modifier = Modifier.height(8.dp))
                AppRole.entries.forEach { role ->
                    val isSelected = currentAppRole == role
                    OutlinedButton(
                        onClick = { onSelectRole(role) },
                        modifier = Modifier.fillMaxWidth(),
                        border = BorderStroke(1.dp, if (isSelected) IndigoPrimary else BorderSubtle),
                        colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
                            containerColor = if (isSelected) IndigoPrimary.copy(alpha = 0.08f) else Color.Transparent
                        )
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(role.displayName, fontWeight = FontWeight.Bold, color = if (isSelected) IndigoPrimary else TextSlate800)
                                Text(
                                    text = if (role.canManageCarousel) "Can manage carousel" else "No carousel access",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (role.canManageCarousel) Emerald500 else TextSlate400
                                )
                            }
                            if (isSelected) {
                                Icon(Icons.Default.Star, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

// Helpers for icons and colors
fun getContentTypeColor(type: CarouselContentType): Color {
    return when (type) {
        CarouselContentType.FESTIVAL -> Color(0xFF8B5CF6)     // Purple
        CarouselContentType.CELEBRATION -> Color(0xFFF59E0B)  // Amber
        CarouselContentType.BIRTHDAY -> Color(0xFFEC4899)     // Pink
        CarouselContentType.ANNOUNCEMENT -> IndigoPrimary     // Indigo
        CarouselContentType.PROMOTION -> Emerald500           // Emerald
        CarouselContentType.OFFER -> Rose500                 // Rose
        CarouselContentType.OTHER -> Color(0xFF0EA5E9)        // Sky
    }
}

fun getContentTypeIcon(type: CarouselContentType): ImageVector {
    return when (type) {
        CarouselContentType.FESTIVAL -> Icons.Default.Festival
        CarouselContentType.CELEBRATION -> Icons.Default.Celebration
        CarouselContentType.BIRTHDAY -> Icons.Default.Cake
        CarouselContentType.ANNOUNCEMENT -> Icons.Default.Campaign
        CarouselContentType.PROMOTION -> Icons.Default.TrendingUp
        CarouselContentType.OFFER -> Icons.Default.LocalOffer
        CarouselContentType.OTHER -> Icons.Default.Info
    }
}
