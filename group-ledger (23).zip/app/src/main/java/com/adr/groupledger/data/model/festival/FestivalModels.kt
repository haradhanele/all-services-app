package com.adr.groupledger.data.model.festival

import com.adr.groupledger.data.model.carousel.CarouselActionType
import com.adr.groupledger.data.model.carousel.GLOBAL_GROUP_ID
import com.adr.groupledger.data.model.carousel.MediaResource

/**
 * Calendar rule defining how a festival date is resolved for a given year.
 *
 * Distinguishes between fixed Gregorian dates and year-variable dates (lunar, lunisolar,
 * solar-astronomical) to avoid inaccurate date approximations.
 */
sealed interface FestivalDateRule {
    /**
     * Fixed annual date on the Gregorian calendar (e.g., Republic Day on Jan 26, Christmas on Dec 25).
     * @param month 1..12 (1 = January, 12 = December)
     * @param day 1..31
     */
    data class FixedDate(val month: Int, val day: Int) : FestivalDateRule

    /**
     * Year-specific date mapping for lunisolar or shifting calendar festivals (e.g., Diwali, Eid, Holi, Durga Puja).
     * Uses explicit verified Gregorian calendar dates per year.
     * @param datesByYear Map of 4-digit year -> Pair(month: 1..12, day: 1..31)
     */
    data class YearSpecificDate(val datesByYear: Map<Int, Pair<Int, Int>>) : FestivalDateRule
}

/**
 * Immutable definition of a festival or cultural occasion.
 * Decoupled cleanly from the runtime [com.adr.groupledger.data.model.carousel.CarouselItem] entity.
 */
data class FestivalDefinition(
    val id: String,                                        // Stable identifier e.g. "DIWALI", "EID_UL_FITR", "CHRISTMAS"
    val name: String,                                      // Primary English title e.g. "Diwali"
    val displayName: String = name,                        // Display / localized title e.g. "Diwali (Festival of Lights)"
    val dateRule: FestivalDateRule,                        // FixedDate or YearSpecificDate
    val preEventDays: Int = 0,                             // Configurable advance celebration window in days (default: 0)
    val postEventDays: Int = 0,                            // Configurable post-event visibility window in days (default: 0)
    val isEnabled: Boolean = true,                         // Enable/disable toggle for automated carousel generation
    val defaultTitle: String = "Happy $name!",              // Default slide banner title
    val defaultMessage: String = "",                       // Default festive greeting text
    val defaultMediaResource: MediaResource? = null,       // Optional Cloudinary or asset media resource
    val actionType: CarouselActionType = CarouselActionType.NONE,
    val actionTarget: String = "",
    val actionLabel: String = "",
    val priority: Int = DEFAULT_FESTIVAL_PRIORITY,         // Default priority (100) ensuring co-existence with Birthday (120)
    val slideDurationSeconds: Int = 6                      // Slide presentation duration
) {
    companion object {
        const val DEFAULT_FESTIVAL_PRIORITY = 100
        const val DEFAULT_SLIDE_DURATION_SECONDS = 6
    }
}
