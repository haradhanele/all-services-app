package com.adr.groupledger.service.birthday

import java.util.Calendar

/**
 * Birthday matching utility for Home Screen Birthday Automation.
 *
 * Matching Rules:
 * 1. Matches by MONTH and DAY only; ignores the birth year.
 * 2. Leap Year Policy for February 29:
 *    - In leap years (e.g. 2024, 2028), members born on February 29 celebrate on February 29.
 *    - In non-leap years (e.g. 2025, 2026), members born on February 29 celebrate on February 28
 *      (the final day of February, ensuring they are honored within their birth month).
 * 3. Tolerant parsing:
 *    - Accepts standard ISO "YYYY-MM-DD" or slash-separated "YYYY/MM/DD".
 *    - Safely returns false or null on malformed strings, nulls, or blanks without crashing.
 */
object BirthdayMatcher {

    /**
     * Checks whether a member's Date of Birth matches the specified target calendar date.
     *
     * @param dateOfBirth String formatted as "YYYY-MM-DD"
     * @param targetCalendar Calendar representing the date to match against (defaults to now)
     * @return true if the month and day match the target date according to policy
     */
    fun isBirthdayToday(dateOfBirth: String?, targetCalendar: Calendar = Calendar.getInstance()): Boolean {
        if (dateOfBirth.isNullOrBlank()) return false
        val parts = dateOfBirth.trim().split("-", "/")
        if (parts.size != 3) return false

        val birthMonth = parts[1].toIntOrNull() ?: return false // 1..12
        val birthDay = parts[2].toIntOrNull() ?: return false   // 1..31

        if (birthMonth !in 1..12 || birthDay !in 1..31) return false

        val targetMonth = targetCalendar.get(Calendar.MONTH) + 1 // 1..12
        val targetDay = targetCalendar.get(Calendar.DAY_OF_MONTH)
        val targetYear = targetCalendar.get(Calendar.YEAR)
        val isLeapYear = isLeapYear(targetYear)

        // Special handling for February 29 (Leap Day)
        if (birthMonth == 2 && birthDay == 29) {
            return if (isLeapYear) {
                targetMonth == 2 && targetDay == 29
            } else {
                // Policy: Celebrate on February 28 in non-leap years
                targetMonth == 2 && targetDay == 28
            }
        }

        return birthMonth == targetMonth && birthDay == targetDay
    }

    /**
     * Calculates the startAt (00:00:00.000) and endAt (23:59:59.999) timestamps
     * for the celebration window in the target calendar year.
     *
     * @param dateOfBirth String formatted as "YYYY-MM-DD"
     * @param targetCalendar Calendar representing the reference date/year
     * @return Pair of (startAt, endAt) timestamps in epoch milliseconds, or null if invalid
     */
    fun calculateBirthdayWindow(
        dateOfBirth: String?,
        targetCalendar: Calendar = Calendar.getInstance()
    ): Pair<Long, Long>? {
        if (dateOfBirth.isNullOrBlank()) return null
        val parts = dateOfBirth.trim().split("-", "/")
        if (parts.size != 3) return null

        val birthMonth = parts[1].toIntOrNull() ?: return null
        val birthDay = parts[2].toIntOrNull() ?: return null

        if (birthMonth !in 1..12 || birthDay !in 1..31) return null

        val targetYear = targetCalendar.get(Calendar.YEAR)
        val isLeap = isLeapYear(targetYear)

        val effectiveMonth = birthMonth
        val effectiveDay = if (birthMonth == 2 && birthDay == 29 && !isLeap) 28 else birthDay

        val startCal = Calendar.getInstance().apply {
            set(Calendar.YEAR, targetYear)
            set(Calendar.MONTH, effectiveMonth - 1)
            set(Calendar.DAY_OF_MONTH, effectiveDay)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val endCal = Calendar.getInstance().apply {
            set(Calendar.YEAR, targetYear)
            set(Calendar.MONTH, effectiveMonth - 1)
            set(Calendar.DAY_OF_MONTH, effectiveDay)
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }

        return Pair(startCal.timeInMillis, endCal.timeInMillis)
    }

    /**
     * Checks if a year is a leap year according to the Gregorian calendar rules.
     */
    fun isLeapYear(year: Int): Boolean {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)
    }
}
