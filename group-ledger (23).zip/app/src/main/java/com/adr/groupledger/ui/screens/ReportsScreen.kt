package com.adr.groupledger.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NotificationImportant
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.ui.components.CollectionBarChart
import com.adr.groupledger.ui.components.MonthPickerBar
import com.adr.groupledger.ui.components.StatMetricCard
import com.adr.groupledger.ui.components.StatusBadge
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.StatusPaidText
import com.adr.groupledger.ui.theme.StatusUnpaidText
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.utils.CurrencyFormatter
import com.adr.groupledger.utils.DateUtils

@Composable
fun ReportsScreen(
    viewModel: SocietyViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()
    val summary by viewModel.currentMonthSummary.collectAsStateWithLifecycle()
    val membersList by viewModel.monthlyMembersList.collectAsStateWithLifecycle()
    val financials by viewModel.overallFinancials.collectAsStateWithLifecycle()
    val settings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val selectedReportType by viewModel.selectedReportType.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("reports_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 24.dp)
    ) {
            // Report Type Selector Tabs
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "MONTHLY" to "Monthly Collection",
                        "PENDING" to "Pending Dues",
                        "OVERALL" to "Overall Society Summary"
                    ).forEach { (type, label) ->
                        val isSelected = selectedReportType == type
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.setSelectedReportType(type) },
                            label = { Text(label, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                                containerColor = MaterialTheme.colorScheme.surfaceContainer,
                                labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier.testTag("report_tab_$type")
                        )
                    }
                }
            }

            // Month Picker Bar (if monthly or pending)
            if (selectedReportType != "OVERALL") {
                item {
                    MonthPickerBar(
                        selectedMonth = selectedMonth,
                        selectedYear = selectedYear,
                        onPrevClick = { viewModel.prevMonth() },
                        onNextClick = { viewModel.nextMonth() },
                        onMonthYearSelected = { m, y -> viewModel.selectMonthYear(m, y) }
                    )
                }
            }

            // Monthly Collection Trends Chart Section (Monthly Report)
            if (selectedReportType == "MONTHLY") {
                item {
                    Text(
                        text = "Monthly Collection Trends",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                item {
                    CollectionBarChart(
                        trends = financials.monthlyTrends,
                        currencySymbol = settings.currencySymbol
                    )
                }
            }

            // Summary Breakdown
            item {
                when (selectedReportType) {
                    "MONTHLY" -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            StatMetricCard(
                                title = "Total Expected",
                                value = CurrencyFormatter.format(summary.totalExpected, settings.currencySymbol),
                                subtitle = "Target Monthly Dues",
                                icon = Icons.Default.ReceiptLong,
                                accentColor = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(1f)
                            )
                            StatMetricCard(
                                title = "Collected",
                                value = CurrencyFormatter.format(summary.totalCollected, settings.currencySymbol),
                                subtitle = "${summary.collectionPercentage.toInt()}% collected",
                                icon = Icons.Default.CheckCircle,
                                accentColor = StatusPaidText,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    "PENDING" -> {
                        val pendingItems = membersList.filter { it.status != "PAID" }
                        val totalPending = pendingItems.sumOf { it.dueAmount }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            StatMetricCard(
                                title = "Pending Members",
                                value = "${pendingItems.size}",
                                subtitle = "Overdue members",
                                icon = Icons.Default.NotificationImportant,
                                accentColor = StatusUnpaidText,
                                modifier = Modifier.weight(1f)
                            )
                            StatMetricCard(
                                title = "Total Outstanding",
                                value = CurrencyFormatter.format(totalPending, settings.currencySymbol),
                                subtitle = "Unpaid balance",
                                icon = Icons.Default.ReceiptLong,
                                accentColor = StatusUnpaidText,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    "OVERALL" -> {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                StatMetricCard(
                                    title = "Total Active Members",
                                    value = "${financials.activeMembers}",
                                    subtitle = "Enrolled members",
                                    icon = Icons.Default.Assessment,
                                    accentColor = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.weight(1f)
                                )
                                StatMetricCard(
                                    title = "All-Time Collected",
                                    value = CurrencyFormatter.format(financials.totalCollectedAllTime, settings.currencySymbol),
                                    subtitle = "Total fund received",
                                    icon = Icons.Default.CheckCircle,
                                    accentColor = StatusPaidText,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            // Table Preview Header
            item {
                Text(
                    text = "Report Records Preview",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            // Items List
            val displayList = when (selectedReportType) {
                "PENDING" -> membersList.filter { it.status != "PAID" }
                else -> membersList
            }

            if (displayList.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No records found", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                items(displayList) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.member.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                                Text(
                                    "${item.member.memberCode} • Exp: ${CurrencyFormatter.format(item.effectiveExpectedAmount, settings.currencySymbol)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "Paid: ${CurrencyFormatter.format(item.paidAmount, settings.currencySymbol)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (item.paidAmount > 0) StatusPaidText else MaterialTheme.colorScheme.onSurface
                                )
                                if (item.dueAmount > 0) {
                                    Text(
                                        text = "Due: ${CurrencyFormatter.format(item.dueAmount, settings.currencySymbol)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = StatusUnpaidText
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))
                            StatusBadge(status = item.status, compact = true)
                        }
                    }
                }
            }
        }
    }
