package com.adr.groupledger.service.storage

/**
 * Encapsulates cryptographic signature data received from the secure backend.
 */
data class CloudinarySignature(
    val signature: String,
    val timestamp: Long,
    val apiKey: String,
    val folder: String,
    val uploadPreset: String
)

/**
 * Interface contract for obtaining backend-generated Cloudinary upload signatures.
 *
 * ARCHITECTURAL SECURITY PRINCIPLE:
 * Since the preset 'Group_ledger_carousel' is in SIGNED mode, generating a signature
 * requires the Cloudinary API Secret. The Android client application must NEVER possess
 * or execute logic with the API Secret.
 *
 * A future phase (e.g. Phase 5) will implement this interface using an authenticated
 * Firebase Cloud Function or backend endpoint backed by Firebase Authentication.
 */
interface CloudinarySignatureProvider {

    /**
     * Calls the secure backend with the authenticated user's Firebase token to generate
     * a signed cryptographic signature for the given upload parameters.
     */
    suspend fun generateSignature(
        paramsToSign: Map<String, String>
    ): Result<CloudinarySignature>
}
