package com.adr.groupledger.service.birthday

import android.util.Log
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.carousel.CarouselActionType
import com.adr.groupledger.data.model.carousel.CarouselContentType
import com.adr.groupledger.data.model.carousel.CarouselItem
import com.adr.groupledger.data.repository.carousel.CarouselRepository
import com.adr.groupledger.data.repository.carousel.FirestoreCarouselRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar

/**
 * Service responsible for deterministic, idempotent birthday greeting automation.
 *
 * Guarantees:
 * 1. Idempotency: Generates a deterministic document ID per (group, member, celebrationYear),
 *    preventing duplicate items even on multiple invocations.
 * 2. Group Isolation: Preserves `groupId` to ensure greetings are scoped strictly to the member's group.
 * 3. Privacy: Does NOT expose birth year, phone, email, or internal identifiers in user-facing text.
 * 4. Month+Day Matching: Celebrates based on month and day, honoring February 29 policy.
 * 5. Lifecycle Safety: Runs within coroutine background scopes, never inside Compose recomposition.
 */
class BirthdayAutomationService(
    private val carouselRepository: CarouselRepository = FirestoreCarouselRepository.getInstance()
) {
    companion object {
        private const val TAG = "BirthdayAutomation"
        const val BIRTHDAY_PRIORITY = 120
        const val SLIDE_DURATION_SECONDS = 6

        @Volatile
        private var instance: BirthdayAutomationService? = null

        fun getInstance(repository: CarouselRepository = FirestoreCarouselRepository.getInstance()): BirthdayAutomationService {
            return instance ?: synchronized(this) {
                instance ?: BirthdayAutomationService(repository).also { instance = it }
            }
        }

        /**
         * Generates a deterministic identity key for a member's birthday in a given year.
         * Format: BIRTHDAY_{groupId}_{memberId}_{year}
         */
        fun generateDeterministicId(groupId: Long, memberId: Long, year: Int): String {
            return "BIRTHDAY_${groupId}_${memberId}_$year"
        }
    }

    /**
     * Constructs a CarouselItem for a member's birthday if today is their birthday.
     *
     * @param member The member whose birthday is evaluated
     * @param targetCalendar The reference date (defaults to current system time)
     * @return CarouselItem if member's birthday matches target date, null otherwise
     */
    fun createBirthdayCarouselItem(
        member: Member,
        targetCalendar: Calendar = Calendar.getInstance()
    ): CarouselItem? {
        if (!member.isActive) return null
        if (!BirthdayMatcher.isBirthdayToday(member.dateOfBirth, targetCalendar)) return null

        val window = BirthdayMatcher.calculateBirthdayWindow(member.dateOfBirth, targetCalendar) ?: return null
        val targetYear = targetCalendar.get(Calendar.YEAR)
        val deterministicId = generateDeterministicId(member.groupId, member.id, targetYear)

        return CarouselItem(
            id = deterministicId,
            groupId = member.groupId,
            title = "Happy Birthday!",
            message = "Happy Birthday, ${member.name}! 🎂",
            actionType = CarouselActionType.NONE,
            actionTarget = "",
            actionLabel = "",
            priority = BIRTHDAY_PRIORITY,
            startAt = window.first,
            endAt = window.second,
            isActive = true,
            slideDurationSeconds = SLIDE_DURATION_SECONDS,
            contentType = CarouselContentType.BIRTHDAY,
            mediaResource = null
        )
    }

    /**
     * Evaluates a list of members for birthday greetings and persists active celebration items
     * to the carousel repository in an idempotent manner.
     *
     * @param groupId ID of the group being processed
     * @param members List of members to evaluate
     * @param targetCalendar Reference date
     * @return List of generated active CarouselItems for today
     */
    suspend fun processBirthdayAutomation(
        groupId: Long,
        members: List<Member>,
        targetCalendar: Calendar = Calendar.getInstance()
    ): List<CarouselItem> = withContext(Dispatchers.IO) {
        val targetYear = targetCalendar.get(Calendar.YEAR)
        val generatedItems = mutableListOf<CarouselItem>()

        for (member in members) {
            // Group isolation guard: only process members belonging to this group
            if (member.groupId != groupId) continue
            if (!member.isActive) continue

            if (BirthdayMatcher.isBirthdayToday(member.dateOfBirth, targetCalendar)) {
                val item = createBirthdayCarouselItem(member, targetCalendar)
                if (item != null) {
                    try {
                        val saveResult = carouselRepository.saveCarouselItem(item)
                        if (saveResult.isSuccess) {
                            generatedItems.add(item)
                            Log.d(TAG, "Successfully processed birthday automation for member: ${member.name} (id=${member.id})")
                        } else {
                            Log.w(TAG, "Failed to save birthday carousel item: ${saveResult.exceptionOrNull()?.message}")
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Exception while saving birthday carousel item for member ${member.id}: ${e.message}", e)
                    }
                }
            }
        }

        generatedItems
    }
}
