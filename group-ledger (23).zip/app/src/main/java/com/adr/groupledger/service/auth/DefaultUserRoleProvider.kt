package com.adr.groupledger.service.auth

import com.adr.groupledger.data.firebase.FirebaseService
import com.adr.groupledger.data.model.AppRole
import com.adr.groupledger.data.model.GroupRole
import com.adr.groupledger.data.repository.SocietyRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map

/**
 * Concrete implementation of [UserRoleProvider].
 *
 * ARCHITECTURAL INTEGRITY:
 * - Maps group membership data strictly to [GroupRole].
 * - Resolves global platform capabilities ([AppRole]) through secure server-side claim verification.
 * - Group Admins (e.g. creator of "CC CUP") remain [AppRole.REGULAR_USER] for app-level features
 *   unless explicitly designated via server-side credentials.
 */
class DefaultUserRoleProvider(
    private val repository: SocietyRepository,
    private val firebaseService: FirebaseService? = null
) : UserRoleProvider {

    override fun observeGroupRole(userId: Long, groupId: Long): Flow<GroupRole> {
        return repository.getMembershipFlow(userId, groupId).map { membership ->
            if (membership != null) {
                GroupRole.fromString(membership.role)
            } else {
                GroupRole.MEMBER
            }
        }
    }

    override suspend fun getGroupRole(userId: Long, groupId: Long): GroupRole {
        val membership = repository.getMembershipDirect(userId, groupId)
        return if (membership != null) {
            GroupRole.fromString(membership.role)
        } else {
            GroupRole.MEMBER
        }
    }

    override fun observeAppRole(): Flow<AppRole> = flow {
        emit(getAppRole())
    }

    override suspend fun getAppRole(): AppRole {
        val appRoleStr = firebaseService?.getServerAppRole()
        return if (!appRoleStr.isNullOrBlank()) {
            AppRole.fromString(appRoleStr)
        } else if (firebaseService?.isServerAppAdminClaimPresent() == true) {
            AppRole.APP_ADMIN
        } else {
            // Group Admins default to REGULAR_USER at the application level
            AppRole.REGULAR_USER
        }
    }

    override suspend fun verifyServerAppAdminPrivileges(): Boolean {
        return firebaseService?.isServerAppAdminClaimPresent() ?: false
    }
}

