package com.adr.groupledger.service.storage

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

/**
 * Concrete implementation of [CloudinarySignatureProvider] that delegates cryptographic signature
 * generation to a secure server-side endpoint (Firebase Cloud Function / Local Emulator).
 *
 * CRITICAL SECURITY PRINCIPLE:
 * The Cloudinary API Secret is NEVER held by this class or anywhere within the Android client.
 * In signed preset mode ('Group_ledger_carousel'), signatures MUST be requested from
 * a trusted backend with an authenticated Firebase ID token in the Authorization header:
 *   Authorization: Bearer <Firebase_ID_Token>
 */
class BackendCloudinarySignatureProvider(
    val endpointUrl: String = CloudinaryConfig.DEFAULT_SIGNATURE_ENDPOINT_URL,
    private val httpClient: OkHttpClient = defaultHttpClient,
    private val tokenProvider: (suspend () -> String?)? = null
) : CloudinarySignatureProvider {

    private val tag = "CloudinarySigProvider"

    companion object {
        val defaultHttpClient: OkHttpClient by lazy {
            OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .writeTimeout(15, TimeUnit.SECONDS)
                .build()
        }

        const val ALLOWED_FOLDER_PREFIX = "cc_cup/carousel"
        const val ALLOWED_UPLOAD_PRESET = "Group_ledger_carousel"
    }

    override suspend fun generateSignature(
        paramsToSign: Map<String, String>
    ): Result<CloudinarySignature> = withContext(Dispatchers.IO) {
        if (endpointUrl.isBlank()) {
            val message = "Backend signature endpoint is not configured. A valid server-side or emulator URL is required."
            Log.w(tag, message)
            return@withContext Result.failure(IllegalStateException(message))
        }

        // 1. Obtain Firebase ID Token from currently signed-in user
        val idToken = try {
            resolveAuthToken()
        } catch (e: Exception) {
            Log.e(tag, "Failed to resolve Firebase authentication token", e)
            return@withContext Result.failure(
                IllegalStateException("Authentication failed: Unable to obtain Firebase ID token. Please re-authenticate.", e)
            )
        }

        if (idToken.isNullOrBlank()) {
            val message = "Authentication required: No signed-in Firebase user found or token unavailable. Please sign in."
            Log.w(tag, message)
            return@withContext Result.failure(IllegalStateException(message))
        }

        // 2. Prepare payload with required and safe parameters only
        val currentTimestamp = System.currentTimeMillis() / 1000L
        val folder = paramsToSign["folder"]?.takeIf { it.isNotBlank() } ?: ALLOWED_FOLDER_PREFIX
        val uploadPreset = paramsToSign["upload_preset"]?.takeIf { it.isNotBlank() } ?: ALLOWED_UPLOAD_PRESET
        val timestamp = paramsToSign["timestamp"]?.toLongOrNull() ?: currentTimestamp

        val jsonPayload = JSONObject().apply {
            put("folder", folder)
            put("timestamp", timestamp.toString())
            put("upload_preset", uploadPreset)
        }

        try {
            val requestBody = jsonPayload.toString().toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())
            val request = Request.Builder()
                .url(endpointUrl)
                .addHeader("Authorization", "Bearer $idToken")
                .addHeader("Content-Type", "application/json; charset=utf-8")
                .post(requestBody)
                .build()

            val response = try {
                httpClient.newCall(request).execute()
            } catch (e: ConnectException) {
                val errorMsg = "Unable to connect to signature server at $endpointUrl. Ensure the Firebase emulator is running."
                Log.e(tag, errorMsg, e)
                return@withContext Result.failure(IOException(errorMsg, e))
            } catch (e: SocketTimeoutException) {
                val errorMsg = "Connection timed out while communicating with signature server at $endpointUrl."
                Log.e(tag, errorMsg, e)
                return@withContext Result.failure(IOException(errorMsg, e))
            } catch (e: UnknownHostException) {
                val errorMsg = "Unable to resolve signature server host at $endpointUrl."
                Log.e(tag, errorMsg, e)
                return@withContext Result.failure(IOException(errorMsg, e))
            } catch (e: IOException) {
                val errorMsg = "Network error contacting signature server at $endpointUrl."
                Log.e(tag, errorMsg, e)
                return@withContext Result.failure(IOException(errorMsg, e))
            }

            val responseBody = response.body?.string().orEmpty()
            val statusCode = response.code

            if (!response.isSuccessful) {
                val sanitizedError = sanitizeErrorMessage(responseBody)
                val exception: Throwable = when (statusCode) {
                    401 -> SecurityException("Authentication failed (HTTP 401): Session invalid or expired. $sanitizedError")
                    403 -> SecurityException("Authorization forbidden (HTTP 403): You do not have permission to manage carousel media. $sanitizedError")
                    400 -> IllegalArgumentException("Invalid upload parameters (HTTP 400): $sanitizedError")
                    else -> IOException("Backend signature endpoint returned HTTP $statusCode: $sanitizedError")
                }
                Log.e(tag, "Backend signature error: HTTP $statusCode: $sanitizedError")
                return@withContext Result.failure(exception)
            }

            val responseJson = try {
                JSONObject(responseBody)
            } catch (e: Exception) {
                return@withContext Result.failure(
                    IllegalStateException("Malformed response from signature endpoint: Invalid JSON payload.")
                )
            }

            val signature = responseJson.optString("signature", "")
            val respTimestamp = responseJson.optLong("timestamp", timestamp)
            val apiKey = responseJson.optString("apiKey", responseJson.optString("api_key", ""))
            val respFolder = responseJson.optString("folder", folder)
            val respUploadPreset = responseJson.optString("uploadPreset", responseJson.optString("upload_preset", uploadPreset))

            if (signature.isBlank()) {
                return@withContext Result.failure(
                    IllegalStateException("Backend signature response missing required 'signature' attribute.")
                )
            }

            Result.success(
                CloudinarySignature(
                    signature = signature,
                    timestamp = respTimestamp,
                    apiKey = apiKey,
                    folder = respFolder,
                    uploadPreset = respUploadPreset
                )
            )
        } catch (e: Exception) {
            Log.e(tag, "Unexpected failure during signature retrieval from $endpointUrl", e)
            Result.failure(e)
        }
    }

    private suspend fun resolveAuthToken(): String? {
        if (tokenProvider != null) {
            return tokenProvider.invoke()
        }
        return try {
            val auth = FirebaseAuth.getInstance()
            val user = auth.currentUser ?: return null
            val tokenResult = user.getIdToken(false).await()
            tokenResult.token
        } catch (e: Exception) {
            Log.w(tag, "resolveAuthToken failed: ${e.message}")
            null
        }
    }

    private fun sanitizeErrorMessage(rawBody: String): String {
        return try {
            val json = JSONObject(rawBody)
            val error = json.optString("error", json.optString("message", ""))
            if (error.isNotBlank()) {
                error.take(200)
            } else {
                "Request failed"
            }
        } catch (_: Exception) {
            "Request failed"
        }
    }
}
