package com.adr.groupledger.data.model

/**
 * Represents a member's role and operational privileges within a specific society or group
 * (e.g. "CC CUP", "Welfare Society").
 *
 * CRITICAL ARCHITECTURAL BOUNDARY:
 * Being an [ADMIN] of a specific group (e.g. Raj in "CC CUP") means having administrative
 * privileges for THAT group only (recording payments, approving members, managing notices).
 * It DOES NOT grant global application-level administrative access or carousel management rights.
 */
enum class GroupRole(val roleKey: String, val displayName: String) {
    ADMIN("ADMIN", "Group Administrator"),
    TREASURER("TREASURER", "Treasurer"),
    SECRETARY("SECRETARY", "Secretary"),
    MODERATOR("MODERATOR", "Moderator"),
    MEMBER("MEMBER", "Member");

    val isGroupAdmin: Boolean get() = this == ADMIN
    val hasFinancialPrivileges: Boolean get() = this == ADMIN || this == TREASURER
    val canManageGroupMembers: Boolean get() = this == ADMIN || this == SECRETARY

    companion object {
        fun fromString(role: String?): GroupRole {
            if (role.isNullOrBlank()) return MEMBER
            return entries.find {
                it.roleKey.equals(role.trim(), ignoreCase = true) ||
                it.name.equals(role.trim(), ignoreCase = true)
            } ?: when (role.trim().uppercase()) {
                "OWNER", "CREATOR" -> ADMIN
                "EDITOR" -> MODERATOR
                else -> MEMBER
            }
        }
    }
}

/**
 * Represents global platform/application-level access across Group Ledger.
 *
 * CRITICAL ARCHITECTURAL BOUNDARY:
 * Carousel/Promotion management, platform-wide banners, and global broadcast campaigns
 * are strictly application-level features governed by [AppRole].
 *
 * Group Admins default to [REGULAR_USER] at the application level unless explicitly
 * granted [CONTENT_MANAGER] or [APP_ADMIN] privileges via server-side claims or administrative grant.
 */
enum class AppRole(val roleKey: String, val displayName: String) {
    REGULAR_USER("REGULAR_USER", "Regular User"),
    CONTENT_MANAGER("CONTENT_MANAGER", "Content Manager"),
    APP_ADMIN("APP_ADMIN", "Application Administrator");

    val isAppAdmin: Boolean get() = this == APP_ADMIN
    val isContentManager: Boolean get() = this == CONTENT_MANAGER
    val canManageCarousel: Boolean get() = this == APP_ADMIN || this == CONTENT_MANAGER

    companion object {
        fun fromString(role: String?): AppRole {
            if (role.isNullOrBlank()) return REGULAR_USER
            return entries.find {
                it.roleKey.equals(role.trim(), ignoreCase = true) ||
                it.name.equals(role.trim(), ignoreCase = true)
            } ?: when (role.trim().uppercase()) {
                "SUPER_ADMIN", "ADMIN" -> APP_ADMIN
                "CONTENT_ADMIN", "EDITOR" -> CONTENT_MANAGER
                else -> REGULAR_USER
            }
        }
    }
}

