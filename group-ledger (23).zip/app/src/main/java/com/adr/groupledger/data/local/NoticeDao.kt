package com.adr.groupledger.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.adr.groupledger.data.model.SocietyNotice
import kotlinx.coroutines.flow.Flow

@Dao
interface NoticeDao {
    @Query("SELECT * FROM society_notices WHERE groupId = :groupId ORDER BY isPinned DESC, timestamp DESC")
    fun getAllNotices(groupId: Long): Flow<List<SocietyNotice>>

    @Query("SELECT * FROM society_notices WHERE groupId = :groupId ORDER BY isPinned DESC, timestamp DESC")
    suspend fun getNoticesForGroupDirect(groupId: Long): List<SocietyNotice>

    @Query("SELECT * FROM society_notices WHERE id = :id LIMIT 1")
    suspend fun getNoticeById(id: Long): SocietyNotice?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotice(notice: SocietyNotice): Long

    @Update
    suspend fun updateNotice(notice: SocietyNotice)

    @Delete
    suspend fun deleteNotice(notice: SocietyNotice)

    @Query("DELETE FROM society_notices WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM society_notices WHERE groupId = :groupId")
    suspend fun deleteNoticesForGroup(groupId: Long)
}
