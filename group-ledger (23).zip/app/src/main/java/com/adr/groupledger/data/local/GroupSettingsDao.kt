package com.adr.groupledger.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.adr.groupledger.data.model.GroupSettings
import kotlinx.coroutines.flow.Flow

@Dao
interface GroupSettingsDao {
    @Query("SELECT * FROM group_settings WHERE id = :groupId LIMIT 1")
    fun getSettingsFlow(groupId: Long): Flow<GroupSettings?>

    @Query("SELECT * FROM group_settings WHERE id = :groupId LIMIT 1")
    suspend fun getSettings(groupId: Long): GroupSettings?

    @Query("SELECT * FROM group_settings WHERE id = :groupId LIMIT 1")
    suspend fun getGroupById(groupId: Long): GroupSettings?

    @Query("SELECT * FROM group_settings WHERE inviteCode = :code COLLATE NOCASE LIMIT 1")
    suspend fun getGroupByInviteCode(code: String): GroupSettings?

    @Query("SELECT * FROM group_settings ORDER BY id ASC")
    fun getAllGroupsFlow(): Flow<List<GroupSettings>>

    @Query("SELECT * FROM group_settings ORDER BY id ASC")
    suspend fun getAllGroupsDirect(): List<GroupSettings>

    @Query("SELECT * FROM group_settings WHERE (ownerUid = :ownerUid AND ownerUid != '') OR createdByUserId = :userId ORDER BY id ASC")
    suspend fun getGroupsByOwner(ownerUid: String, userId: Long): List<GroupSettings>

    @Query("SELECT * FROM group_settings WHERE ownerUid = :ownerUid AND ownerUid != '' ORDER BY id ASC")
    suspend fun getGroupsByOwnerUid(ownerUid: String): List<GroupSettings>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(settings: GroupSettings): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGroups(groups: List<GroupSettings>)

    @Update
    suspend fun update(settings: GroupSettings)

    @Query("DELETE FROM group_settings WHERE id = :groupId")
    suspend fun deleteGroup(groupId: Long)
}
