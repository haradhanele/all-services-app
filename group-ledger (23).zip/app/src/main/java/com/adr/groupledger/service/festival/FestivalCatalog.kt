package com.adr.groupledger.service.festival

import com.adr.groupledger.data.model.festival.FestivalDateRule
import com.adr.groupledger.data.model.festival.FestivalDefinition

/**
 * Pre-configured catalog of cultural, national, and religious occasions
 * relevant to the Group Ledger application.
 *
 * Designed to be easily extensible. Uses authentic, verified Gregorian calendar
 * dates for shifting lunar and lunisolar observances rather than error-prone
 * approximations.
 */
object FestivalCatalog {

    val NEW_YEAR = FestivalDefinition(
        id = "NEW_YEAR",
        name = "New Year",
        displayName = "New Year",
        dateRule = FestivalDateRule.FixedDate(month = 1, day = 1),
        preEventDays = 0,
        postEventDays = 0,
        defaultTitle = "Happy New Year! 🎆",
        defaultMessage = "Wishing all society members a joyful, prosperous, and successful New Year!",
        priority = 105,
        slideDurationSeconds = 6
    )

    val REPUBLIC_DAY = FestivalDefinition(
        id = "REPUBLIC_DAY",
        name = "Republic Day",
        displayName = "Republic Day",
        dateRule = FestivalDateRule.FixedDate(month = 1, day = 26),
        preEventDays = 0,
        postEventDays = 0,
        defaultTitle = "Happy Republic Day! 🇮🇳",
        defaultMessage = "Celebrating the spirit of unity, freedom, and constitution. Warm wishes to all members!",
        priority = 100,
        slideDurationSeconds = 6
    )

    val HOLI = FestivalDefinition(
        id = "HOLI",
        name = "Holi",
        displayName = "Holi (Festival of Colours)",
        dateRule = FestivalDateRule.YearSpecificDate(
            mapOf(
                2024 to Pair(3, 25),
                2025 to Pair(3, 14),
                2026 to Pair(3, 4),
                2027 to Pair(3, 22),
                2028 to Pair(3, 11)
            )
        ),
        preEventDays = 0,
        postEventDays = 0,
        defaultTitle = "Happy Holi! 🎨",
        defaultMessage = "May the festival of colours bring vibrant joy, peace, and good health to you and your family.",
        priority = 100,
        slideDurationSeconds = 6
    )

    val EID_UL_FITR = FestivalDefinition(
        id = "EID_UL_FITR",
        name = "Eid-ul-Fitr",
        displayName = "Eid-ul-Fitr",
        dateRule = FestivalDateRule.YearSpecificDate(
            mapOf(
                2024 to Pair(4, 11),
                2025 to Pair(3, 31),
                2026 to Pair(3, 20),
                2027 to Pair(3, 10),
                2028 to Pair(2, 27)
            )
        ),
        preEventDays = 0,
        postEventDays = 0,
        defaultTitle = "Eid Mubarak! 🌙",
        defaultMessage = "Wishing you and your family a joyous, peaceful, and blessed Eid.",
        priority = 100,
        slideDurationSeconds = 6
    )

    val INDEPENDENCE_DAY = FestivalDefinition(
        id = "INDEPENDENCE_DAY",
        name = "Independence Day",
        displayName = "Independence Day",
        dateRule = FestivalDateRule.FixedDate(month = 8, day = 15),
        preEventDays = 0,
        postEventDays = 0,
        defaultTitle = "Happy Independence Day! 🇮🇳",
        defaultMessage = "Honoring freedom, unity, and progress. Wishing everyone a proud Independence Day!",
        priority = 100,
        slideDurationSeconds = 6
    )

    val GANDHI_JAYANTI = FestivalDefinition(
        id = "GANDHI_JAYANTI",
        name = "Gandhi Jayanti",
        displayName = "Gandhi Jayanti",
        dateRule = FestivalDateRule.FixedDate(month = 10, day = 2),
        preEventDays = 0,
        postEventDays = 0,
        defaultTitle = "Gandhi Jayanti 🕊️",
        defaultMessage = "Remembering the timeless ideals of truth, peace, and non-violence on Mahatma Gandhi's birth anniversary.",
        priority = 95,
        slideDurationSeconds = 6
    )

    val DURGA_PUJA = FestivalDefinition(
        id = "DURGA_PUJA",
        name = "Durga Puja",
        displayName = "Durga Puja & Subho Bijoya",
        dateRule = FestivalDateRule.YearSpecificDate(
            mapOf(
                2024 to Pair(10, 12),
                2025 to Pair(10, 2),
                2026 to Pair(10, 20),
                2027 to Pair(10, 9),
                2028 to Pair(9, 28)
            )
        ),
        preEventDays = 1, // Pre-event celebration active on Maha Navami eve
        postEventDays = 1, // Subho Bijoya extension
        defaultTitle = "Subho Bijoya & Happy Durga Puja! 🌸",
        defaultMessage = "Warm festive greetings and the divine blessings of Maa Durga to all members and their families.",
        priority = 105,
        slideDurationSeconds = 6
    )

    val DIWALI = FestivalDefinition(
        id = "DIWALI",
        name = "Diwali",
        displayName = "Diwali (Festival of Lights)",
        dateRule = FestivalDateRule.YearSpecificDate(
            mapOf(
                2024 to Pair(11, 1),
                2025 to Pair(10, 20),
                2026 to Pair(11, 8),
                2027 to Pair(10, 29),
                2028 to Pair(10, 17)
            )
        ),
        preEventDays = 0,
        postEventDays = 0,
        defaultTitle = "Happy Diwali! 🪔",
        defaultMessage = "May the divine festival of lights illuminate your life with health, happiness, and prosperity.",
        priority = 105,
        slideDurationSeconds = 6
    )

    val CHRISTMAS = FestivalDefinition(
        id = "CHRISTMAS",
        name = "Christmas",
        displayName = "Christmas",
        dateRule = FestivalDateRule.FixedDate(month = 12, day = 25),
        preEventDays = 0,
        postEventDays = 0,
        defaultTitle = "Merry Christmas! 🎄",
        defaultMessage = "Wishing you and your loved ones peace, warmth, joy, and goodwill this holiday season.",
        priority = 100,
        slideDurationSeconds = 6
    )

    /**
     * Complete list of predefined festivals in the catalog.
     */
    val defaultFestivals: List<FestivalDefinition> = listOf(
        NEW_YEAR,
        REPUBLIC_DAY,
        HOLI,
        EID_UL_FITR,
        INDEPENDENCE_DAY,
        GANDHI_JAYANTI,
        DURGA_PUJA,
        DIWALI,
        CHRISTMAS
    )

    /**
     * Looks up a festival definition by its stable identifier.
     */
    fun getFestivalById(id: String): FestivalDefinition? {
        return defaultFestivals.firstOrNull { it.id.equals(id.trim(), ignoreCase = true) }
    }
}
