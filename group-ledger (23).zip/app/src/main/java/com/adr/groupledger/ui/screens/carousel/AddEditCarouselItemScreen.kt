package com.adr.groupledger.ui.screens.carousel

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Gif
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.adr.groupledger.data.model.carousel.CarouselActionType
import com.adr.groupledger.data.model.carousel.CarouselContentType
import com.adr.groupledger.data.model.carousel.CarouselItem
import com.adr.groupledger.data.model.carousel.GLOBAL_GROUP_ID
import com.adr.groupledger.data.model.carousel.MediaResource
import com.adr.groupledger.data.model.carousel.MediaType
import com.adr.groupledger.data.model.carousel.StorageProviderType
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.TextButton
import androidx.compose.ui.platform.LocalContext
import coil.ImageLoader
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder
import coil.request.ImageRequest
import com.adr.groupledger.service.storage.MediaFileValidator
import com.adr.groupledger.service.storage.MediaValidationResult
import com.adr.groupledger.ui.viewmodel.MediaUploadState
import com.adr.groupledger.ui.theme.BorderSubtle
import com.adr.groupledger.ui.theme.CanvasBackground
import com.adr.groupledger.ui.theme.CardWhite
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoHeroDark
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.TextSlate400
import com.adr.groupledger.ui.theme.TextSlate500
import com.adr.groupledger.ui.theme.TextSlate800
import com.adr.groupledger.ui.viewmodel.CarouselContentViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditCarouselItemScreen(
    carouselId: String,
    modifier: Modifier = Modifier,
    contentViewModel: CarouselContentViewModel = viewModel(factory = CarouselContentViewModel.provideFactory()),
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val isEditing = carouselId.isNotBlank() && carouselId != "0"
    val isLoading by contentViewModel.isLoading.collectAsStateWithLifecycle()
    val uploadState by contentViewModel.mediaUploadState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    // ImageLoader configured with GIF decoding support (both Android P+ ImageDecoder and GifDecoder)
    val imageLoader = remember(context) {
        ImageLoader.Builder(context)
            .components {
                if (Build.VERSION.SDK_INT >= 28) {
                    add(ImageDecoderDecoder.Factory())
                } else {
                    add(GifDecoder.Factory())
                }
            }
            .build()
    }

    // Form state
    var contentType by remember { mutableStateOf(CarouselContentType.ANNOUNCEMENT) }
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var mediaType by remember { mutableStateOf(MediaType.IMAGE) }
    var mediaUrl by remember { mutableStateOf("") }
    var currentMediaResource by remember { mutableStateOf<MediaResource?>(null) }
    var isActive by remember { mutableStateOf(true) }
    var priority by remember { mutableIntStateOf(5) }
    var slideDurationSeconds by remember { mutableIntStateOf(5) }
    var actionType by remember { mutableStateOf(CarouselActionType.NONE) }
    var actionLabel by remember { mutableStateOf("") }
    var actionTarget by remember { mutableStateOf("") }

    // Modern Photo Picker (Zero-permission Android Photo Picker for Images and GIFs)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            when (val result = MediaFileValidator.validateAndPrepareMediaFile(context, uri)) {
                is MediaValidationResult.Valid -> {
                    mediaType = result.mediaType
                    contentViewModel.onMediaFileSelected(result)
                }
                is MediaValidationResult.Invalid -> {
                    contentViewModel.onMediaFileInvalid(result.userFacingReason)
                }
            }
        }
    }

    // Fallback file picker for broad device support
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            when (val result = MediaFileValidator.validateAndPrepareMediaFile(context, uri)) {
                is MediaValidationResult.Valid -> {
                    mediaType = result.mediaType
                    contentViewModel.onMediaFileSelected(result)
                }
                is MediaValidationResult.Invalid -> {
                    contentViewModel.onMediaFileInvalid(result.userFacingReason)
                }
            }
        }
    }

    // Synchronize successful upload with form state
    LaunchedEffect(uploadState) {
        when (val s = uploadState) {
            is MediaUploadState.Success -> {
                currentMediaResource = s.mediaResource
                mediaUrl = s.mediaResource.publicUrl
                mediaType = s.mediaResource.mediaType
            }
            else -> {}
        }
    }

    // Scheduling
    var isScheduleEnabled by remember { mutableStateOf(false) }
    var startAt by remember { mutableLongStateOf(0L) }
    var endAt by remember { mutableLongStateOf(0L) }

    // Errors
    var titleError by remember { mutableStateOf<String?>(null) }
    var messageError by remember { mutableStateOf<String?>(null) }

    // Load existing item if editing
    LaunchedEffect(carouselId) {
        if (isEditing) {
            contentViewModel.getItemById(carouselId)?.let { item ->
                contentType = item.contentType
                title = item.title
                message = item.message
                mediaType = item.mediaResource?.mediaType ?: MediaType.IMAGE
                mediaUrl = item.mediaResource?.publicUrl ?: ""
                currentMediaResource = item.mediaResource
                contentViewModel.setExistingMedia(item.mediaResource)
                isActive = item.isActive
                priority = item.priority
                slideDurationSeconds = item.slideDurationSeconds
                actionType = item.actionType
                actionLabel = item.actionLabel
                actionTarget = item.actionTarget
                if (item.startAt > 0L || item.endAt > 0L) {
                    isScheduleEnabled = true
                    startAt = item.startAt
                    endAt = item.endAt
                }
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = if (isEditing) "Edit Carousel Slide" else "Create Carousel Slide",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextSlate800
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("add_edit_carousel_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextSlate800
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            var hasError = false
                            if (title.isBlank()) {
                                titleError = "Title is required"
                                hasError = true
                            } else {
                                titleError = null
                            }
                            if (message.isBlank()) {
                                messageError = "Message is required"
                                hasError = true
                            } else {
                                messageError = null
                            }

                            if (!hasError) {
                                val effectiveMedia = currentMediaResource ?: if (mediaUrl.isNotBlank()) {
                                    MediaResource(
                                        mediaId = "media_${System.currentTimeMillis()}",
                                        mediaType = mediaType,
                                        provider = StorageProviderType.LOCAL_ASSET,
                                        publicUrl = mediaUrl.trim()
                                    )
                                } else null

                                val itemToSave = CarouselItem(
                                    id = if (isEditing) carouselId else "",
                                    groupId = GLOBAL_GROUP_ID,
                                    contentType = contentType,
                                    title = title.trim(),
                                    message = message.trim(),
                                    mediaResource = effectiveMedia,
                                    startAt = if (isScheduleEnabled) startAt else 0L,
                                    endAt = if (isScheduleEnabled) endAt else 0L,
                                    isActive = isActive,
                                    priority = priority,
                                    slideDurationSeconds = slideDurationSeconds,
                                    actionType = actionType,
                                    actionTarget = if (actionType != CarouselActionType.NONE) actionTarget.trim() else "",
                                    actionLabel = if (actionType != CarouselActionType.NONE) actionLabel.trim() else ""
                                )

                                contentViewModel.saveItem(itemToSave) { success, _ ->
                                    if (success) {
                                        onNavigateBack()
                                    }
                                }
                            }
                        },
                        modifier = Modifier.testTag("save_carousel_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Save Slide",
                            tint = IndigoPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = CardWhite)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(CanvasBackground)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 48.dp)
        ) {
            // =========================================================================
            // 1. Content Type Classification
            // =========================================================================
            item {
                SectionCard(title = "Content Type & Category") {
                    var expanded by remember { mutableStateOf(false) }

                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = !expanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = contentType.name,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Category") },
                            leadingIcon = {
                                Icon(
                                    imageVector = getContentTypeIcon(contentType),
                                    contentDescription = null,
                                    tint = getContentTypeColor(contentType)
                                )
                            },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .testTag("content_type_dropdown"),
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = CardWhite,
                                unfocusedContainerColor = CardWhite
                            )
                        )

                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            CarouselContentType.entries.forEach { type ->
                                DropdownMenuItem(
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = getContentTypeIcon(type),
                                                contentDescription = null,
                                                tint = getContentTypeColor(type),
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Text(type.name, fontWeight = FontWeight.SemiBold)
                                        }
                                    },
                                    onClick = {
                                        contentType = type
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // =========================================================================
            // 2. Text Content (Title & Message)
            // =========================================================================
            item {
                SectionCard(title = "Slide Content") {
                    OutlinedTextField(
                        value = title,
                        onValueChange = {
                            title = it
                            if (it.isNotBlank()) titleError = null
                        },
                        label = { Text("Slide Title *") },
                        placeholder = { Text("e.g. Diwali Greetings, Monthly Due Reminder") },
                        isError = titleError != null,
                        supportingText = {
                            titleError?.let { Text(it, color = Rose500) }
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("carousel_title_input"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = CardWhite,
                            unfocusedContainerColor = CardWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = message,
                        onValueChange = {
                            message = it
                            if (it.isNotBlank()) messageError = null
                        },
                        label = { Text("Message / Description *") },
                        placeholder = { Text("Enter the full announcement text or promotion details...") },
                        isError = messageError != null,
                        supportingText = {
                            messageError?.let { Text(it, color = Rose500) }
                        },
                        minLines = 3,
                        maxLines = 5,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("carousel_message_input"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = CardWhite,
                            unfocusedContainerColor = CardWhite
                        )
                    )
                }
            }

            // =========================================================================
            // 3. Media Asset (Image / GIF) - Phase 5 Cloudinary Media Upload
            // =========================================================================
            item {
                SectionCard(title = "Media Asset (Image / GIF)") {
                    // Media type selection
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        listOf(MediaType.IMAGE to "Static Image", MediaType.GIF to "Animated GIF").forEach { (type, label) ->
                            val isSelected = mediaType == type
                            FilterChip(
                                selected = isSelected,
                                onClick = { mediaType = type },
                                leadingIcon = {
                                    Icon(
                                        imageVector = if (type == MediaType.GIF) Icons.Default.Gif else Icons.Default.Image,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                label = { Text(label) },
                                modifier = Modifier.weight(1f),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IndigoPrimary.copy(alpha = 0.12f),
                                    selectedLabelColor = IndigoPrimary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Media Status UI according to MediaUploadState & Current Attached Resource
                    when {
                        // State A: Media already uploaded and attached (or loaded from existing slide)
                        currentMediaResource != null -> {
                            val res = currentMediaResource!!
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, Emerald500.copy(alpha = 0.5f)),
                                colors = CardDefaults.outlinedCardColors(containerColor = Emerald500.copy(alpha = 0.05f))
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.CloudDone,
                                                contentDescription = null,
                                                tint = Emerald500,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = if (res.provider == StorageProviderType.CLOUDINARY) "Cloudinary Asset Attached" else "Media Attached",
                                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                                color = Emerald500
                                            )
                                        }

                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (res.mediaType == MediaType.GIF) IndigoPrimary.copy(alpha = 0.15f) else Emerald500.copy(alpha = 0.15f)
                                        ) {
                                            Text(
                                                text = if (res.mediaType == MediaType.GIF) "ANIMATED GIF" else "IMAGE",
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                color = if (res.mediaType == MediaType.GIF) IndigoPrimary else Emerald500,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    // Preview Image / GIF with animated decoder
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(160.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        AsyncImage(
                                            model = ImageRequest.Builder(context)
                                                .data(res.publicUrl)
                                                .crossfade(true)
                                                .build(),
                                            imageLoader = imageLoader,
                                            contentDescription = "Media Preview",
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    if (res.fileName.isNotBlank()) {
                                        Text(
                                            text = "File: ${res.fileName}",
                                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                            color = TextSlate800
                                        )
                                    }
                                    if (res.fileSizeBytes > 0L) {
                                        Text(
                                            text = "Size: ${MediaFileValidator.formatBytes(res.fileSizeBytes)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSlate500
                                        )
                                    }
                                    if (res.mediaId.isNotBlank()) {
                                        Text(
                                            text = "Public ID: ${res.mediaId}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSlate400,
                                            fontSize = 11.sp
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedButton(
                                            onClick = {
                                                photoPickerLauncher.launch(
                                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                )
                                            },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Replace Media")
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                contentViewModel.removeMedia(currentMediaResource) {
                                                    currentMediaResource = null
                                                    mediaUrl = ""
                                                }
                                            },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Rose500)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Remove")
                                        }
                                    }
                                }
                            }
                        }

                        // State B: Local file selected and validated, ready to upload
                        uploadState is MediaUploadState.FileSelected -> {
                            val selected = uploadState as MediaUploadState.FileSelected
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.4f)),
                                colors = CardDefaults.outlinedCardColors(containerColor = IndigoPrimary.copy(alpha = 0.04f))
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "Ready to Upload",
                                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                            color = IndigoPrimary
                                        )

                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (selected.mediaType == MediaType.GIF) IndigoPrimary.copy(alpha = 0.15f) else TextSlate400.copy(alpha = 0.15f)
                                        ) {
                                            Text(
                                                text = if (selected.mediaType == MediaType.GIF) "ANIMATED GIF" else "IMAGE",
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                color = if (selected.mediaType == MediaType.GIF) IndigoPrimary else TextSlate800,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    // Local Preview Image / GIF with animated decoder
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(150.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        AsyncImage(
                                            model = ImageRequest.Builder(context)
                                                .data(selected.file)
                                                .crossfade(true)
                                                .build(),
                                            imageLoader = imageLoader,
                                            contentDescription = "Selected Local Media",
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text(
                                        text = selected.originalName,
                                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                        color = TextSlate800
                                    )
                                    Text(
                                        text = "Size: ${MediaFileValidator.formatBytes(selected.sizeBytes)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSlate500
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Button(
                                        onClick = {
                                            contentViewModel.startUpload(contentType) { uploaded ->
                                                if (uploaded != null) {
                                                    currentMediaResource = uploaded
                                                    mediaUrl = uploaded.publicUrl
                                                    mediaType = uploaded.mediaType
                                                }
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth().testTag("upload_to_cloudinary_button"),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                                    ) {
                                        Icon(Icons.Default.CloudUpload, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Upload to Cloudinary (Signed)")
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        TextButton(
                                            onClick = {
                                                photoPickerLauncher.launch(
                                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                )
                                            }
                                        ) {
                                            Text("Choose Different File")
                                        }

                                        TextButton(
                                            onClick = { contentViewModel.resetUploadState() },
                                            colors = ButtonDefaults.textButtonColors(contentColor = Rose500)
                                        ) {
                                            Text("Cancel")
                                        }
                                    }
                                }
                            }
                        }

                        // State C: Uploading in progress with percentage
                        uploadState is MediaUploadState.Uploading -> {
                            val uploading = uploadState as MediaUploadState.Uploading
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.3f)),
                                colors = CardDefaults.outlinedCardColors(containerColor = CardWhite)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    CircularProgressIndicator(
                                        color = IndigoPrimary,
                                        modifier = Modifier.size(36.dp),
                                        strokeWidth = 3.dp
                                    )

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Text(
                                        text = "Uploading to Cloudinary...",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        color = TextSlate800
                                    )

                                    Text(
                                        text = uploading.fileName,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSlate500
                                    )

                                    Spacer(modifier = Modifier.height(10.dp))

                                    LinearProgressIndicator(
                                        progress = { uploading.percentage },
                                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                                        color = IndigoPrimary
                                    )

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Text(
                                        text = "${(uploading.percentage * 100).toInt()}% completed",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSlate500
                                    )

                                    Spacer(modifier = Modifier.height(10.dp))

                                    OutlinedButton(
                                        onClick = { contentViewModel.cancelUpload() },
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("Cancel Upload")
                                    }
                                }
                            }
                        }

                        // State D: Upload error or backend prerequisite alert
                        uploadState is MediaUploadState.Error -> {
                            val errorState = uploadState as MediaUploadState.Error
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, Rose500.copy(alpha = 0.4f)),
                                colors = CardDefaults.outlinedCardColors(containerColor = Rose500.copy(alpha = 0.05f))
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Warning,
                                            contentDescription = null,
                                            tint = Rose500,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = if (errorState.isSignaturePrerequisite) "Backend Signature Prerequisite" else "Upload Error",
                                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                            color = Rose500
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text(
                                        text = errorState.userMessage,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSlate800
                                    )

                                    if (errorState.isSignaturePrerequisite) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "Architecture Note: Cloudinary upload preset 'Group_ledger_carousel' is configured in Signed mode. To guarantee security, API Secrets are never stored on device. A backend signature endpoint (e.g. Firebase Cloud Function) is required to sign uploads before production transfer.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSlate500,
                                            fontSize = 11.sp
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        if (errorState.canRetry) {
                                            Button(
                                                onClick = {
                                                    contentViewModel.startUpload(contentType) { uploaded ->
                                                        if (uploaded != null) {
                                                            currentMediaResource = uploaded
                                                            mediaUrl = uploaded.publicUrl
                                                            mediaType = uploaded.mediaType
                                                        }
                                                    }
                                                },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(8.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                                            ) {
                                                Text("Retry")
                                            }
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                photoPickerLauncher.launch(
                                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                )
                                            },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("Choose File")
                                        }

                                        TextButton(
                                            onClick = { contentViewModel.resetUploadState() }
                                        ) {
                                            Text("Dismiss")
                                        }
                                    }
                                }
                            }
                        }

                        // State E: Idle - Initial State with Media Picker
                        else -> {
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, BorderSubtle),
                                colors = CardDefaults.outlinedCardColors(containerColor = CanvasBackground)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = IndigoPrimary.copy(alpha = 0.1f),
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.AddPhotoAlternate,
                                                contentDescription = null,
                                                tint = IndigoPrimary,
                                                modifier = Modifier.size(24.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text(
                                        text = "Select Image or Animated GIF",
                                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                        color = TextSlate800
                                    )

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        text = "Supports JPEG, PNG, WEBP, and animated GIF (up to 10 MB).\nAnimated GIFs will retain continuous animation.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSlate500,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                        fontSize = 11.sp
                                    )

                                    Spacer(modifier = Modifier.height(14.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                photoPickerLauncher.launch(
                                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                )
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f).testTag("select_media_button"),
                                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                                        ) {
                                            Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Photo Picker")
                                        }

                                        OutlinedButton(
                                            onClick = { filePickerLauncher.launch("image/*") },
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f).testTag("browse_files_button")
                                        ) {
                                            Text("Browse Files")
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Optional direct preview URL field for testing image/GIF rendering
                    OutlinedTextField(
                        value = mediaUrl,
                        onValueChange = {
                            mediaUrl = it
                            if (it.isBlank() && currentMediaResource?.provider == StorageProviderType.LOCAL_ASSET) {
                                currentMediaResource = null
                            }
                        },
                        label = { Text("Media Public URL (Direct CDN / Preview)") },
                        placeholder = { Text("https://res.cloudinary.com/... or https://example.com/diwali.gif") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("carousel_media_url_input"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = CardWhite,
                            unfocusedContainerColor = CardWhite
                        )
                    )

                    // Image preview if URL provided and not already shown in attached card
                    if (mediaUrl.isNotBlank() && currentMediaResource == null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            AsyncImage(
                                model = ImageRequest.Builder(context)
                                    .data(mediaUrl)
                                    .crossfade(true)
                                    .build(),
                                imageLoader = imageLoader,
                                contentDescription = "Media Preview",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }
                }
            }

            // =========================================================================
            // 4. Scheduling, Priority, and Duration
            // =========================================================================
            item {
                SectionCard(title = "Display & Scheduling") {
                    // Active Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Active Status", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = TextSlate800)
                            Text("Immediately display in the carousel when active", style = MaterialTheme.typography.bodySmall, color = TextSlate500)
                        }
                        Switch(
                            checked = isActive,
                            onCheckedChange = { isActive = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Emerald500
                            ),
                            modifier = Modifier.testTag("add_edit_active_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Priority Input (Higher = Displays First)
                    OutlinedTextField(
                        value = priority.toString(),
                        onValueChange = { priority = it.toIntOrNull() ?: 0 },
                        label = { Text("Display Priority (0 - 100)") },
                        supportingText = { Text("Higher priority slides appear first in the rotation") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("carousel_priority_input"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = CardWhite,
                            unfocusedContainerColor = CardWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Slide Duration Selector
                    Text("Slide Duration", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = TextSlate800)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(3, 5, 8, 10).forEach { seconds ->
                            val isSelected = slideDurationSeconds == seconds
                            FilterChip(
                                selected = isSelected,
                                onClick = { slideDurationSeconds = seconds },
                                label = { Text("${seconds}s") },
                                modifier = Modifier.weight(1f),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IndigoPrimary.copy(alpha = 0.12f),
                                    selectedLabelColor = IndigoPrimary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Schedule Bounds (Optional specific display period)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = TextSlate500, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Schedule Date Range", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = TextSlate800)
                        }
                        Switch(
                            checked = isScheduleEnabled,
                            onCheckedChange = { isScheduleEnabled = it },
                            modifier = Modifier.testTag("add_edit_schedule_switch")
                        )
                    }

                    if (isScheduleEnabled) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Date picker and automated scheduling jobs will be expanded in the Scheduling phase. For Phase 4, the foundation parameters are persisted directly in the CarouselItem model.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSlate500,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // =========================================================================
            // 5. Call-To-Action (CTA) Settings
            // =========================================================================
            item {
                SectionCard(title = "Call-To-Action (CTA)") {
                    Text("Action Type", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = TextSlate800)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(CarouselActionType.NONE to "None", CarouselActionType.INTERNAL_SCREEN to "App Screen", CarouselActionType.EXTERNAL_URL to "Web URL").forEach { (type, label) ->
                            val isSelected = actionType == type
                            FilterChip(
                                selected = isSelected,
                                onClick = { actionType = type },
                                label = { Text(label) },
                                modifier = Modifier.weight(1f),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IndigoPrimary.copy(alpha = 0.12f),
                                    selectedLabelColor = IndigoPrimary
                                )
                            )
                        }
                    }

                    if (actionType != CarouselActionType.NONE) {
                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = actionLabel,
                            onValueChange = { actionLabel = it },
                            label = { Text("Button Label") },
                            placeholder = { Text("e.g. View Dues, Explore Loans, Learn More") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("carousel_action_label_input"),
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = CardWhite,
                                unfocusedContainerColor = CardWhite
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = actionTarget,
                            onValueChange = { actionTarget = it },
                            label = { Text(if (actionType == CarouselActionType.EXTERNAL_URL) "External Web URL" else "Internal Target Screen") },
                            placeholder = { Text(if (actionType == CarouselActionType.EXTERNAL_URL) "https://..." else "dues, loans, members") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("carousel_action_target_input"),
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = CardWhite,
                                unfocusedContainerColor = CardWhite
                            )
                        )
                    }
                }
            }

            // =========================================================================
            // 6. Action Button (Save)
            // =========================================================================
            item {
                Button(
                    onClick = {
                        var hasError = false
                        if (title.isBlank()) {
                            titleError = "Title is required"
                            hasError = true
                        } else {
                            titleError = null
                        }
                        if (message.isBlank()) {
                            messageError = "Message is required"
                            hasError = true
                        } else {
                            messageError = null
                        }

                        if (!hasError) {
                            val effectiveMedia = currentMediaResource ?: if (mediaUrl.isNotBlank()) {
                                MediaResource(
                                    mediaId = "media_${System.currentTimeMillis()}",
                                    mediaType = mediaType,
                                    provider = StorageProviderType.LOCAL_ASSET,
                                    publicUrl = mediaUrl.trim()
                                )
                            } else null

                            val itemToSave = CarouselItem(
                                id = if (isEditing) carouselId else "",
                                groupId = GLOBAL_GROUP_ID,
                                contentType = contentType,
                                title = title.trim(),
                                message = message.trim(),
                                mediaResource = effectiveMedia,
                                startAt = if (isScheduleEnabled) startAt else 0L,
                                endAt = if (isScheduleEnabled) endAt else 0L,
                                isActive = isActive,
                                priority = priority,
                                slideDurationSeconds = slideDurationSeconds,
                                actionType = actionType,
                                actionTarget = if (actionType != CarouselActionType.NONE) actionTarget.trim() else "",
                                actionLabel = if (actionType != CarouselActionType.NONE) actionLabel.trim() else ""
                            )

                            contentViewModel.saveItem(itemToSave) { success, _ ->
                                if (success) {
                                    onNavigateBack()
                                }
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("submit_carousel_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isEditing) "Update Carousel Slide" else "Publish Carousel Slide",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite),
        border = BorderStroke(1.dp, BorderSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = TextSlate800
            )
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}
