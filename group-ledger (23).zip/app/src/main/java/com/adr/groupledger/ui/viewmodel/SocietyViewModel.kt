package com.adr.groupledger.ui.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.adr.groupledger.data.firebase.FirebaseService
import com.adr.groupledger.data.local.AppDatabase
import com.adr.groupledger.data.model.AppUpdateInfo
import com.adr.groupledger.data.model.CsvImportRecord
import com.adr.groupledger.data.model.CsvImportResult
import com.adr.groupledger.data.model.FeedbackWithVotes
import com.adr.groupledger.data.model.GroupChatMessage
import com.adr.groupledger.data.model.GroupFeedback
import com.adr.groupledger.data.model.GroupJoinRequest
import com.adr.groupledger.data.model.GroupMembership
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.HomeModuleConfig
import com.adr.groupledger.data.model.InvestmentRecord
import com.adr.groupledger.data.model.LoanRequest
import com.adr.groupledger.data.model.LoanWithVotingDetails
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.MemberFinancialProfile
import com.adr.groupledger.data.model.MemberWithMonthlyStatus
import com.adr.groupledger.data.model.MonthlySummary
import com.adr.groupledger.data.model.NotificationItem
import com.adr.groupledger.data.model.OverallGroupFinancials
import com.adr.groupledger.data.model.Payment
import com.adr.groupledger.data.model.PendingPaymentApprovalItem
import com.adr.groupledger.data.model.PreAuthorizedMember
import com.adr.groupledger.data.model.RecentTransaction
import com.adr.groupledger.data.model.SocietyNotice
import com.adr.groupledger.data.model.TransactionRecord
import com.adr.groupledger.data.model.UpdateCheckStatus
import com.adr.groupledger.data.model.UserAccount
import com.adr.groupledger.data.model.AppRole
import com.adr.groupledger.data.model.GroupRole
import com.adr.groupledger.data.model.carousel.CarouselItem
import com.adr.groupledger.data.model.carousel.GLOBAL_GROUP_ID
import com.adr.groupledger.data.repository.carousel.CarouselRepository
import com.adr.groupledger.data.repository.carousel.FirestoreCarouselRepository
import com.adr.groupledger.data.repository.GroupJoinResult
import com.adr.groupledger.data.repository.SocietyRepository
import com.adr.groupledger.service.AppUpdateService
import com.adr.groupledger.service.birthday.BirthdayAutomationService
import com.adr.groupledger.service.festival.FestivalAutomationService
import com.adr.groupledger.service.promotion.PromotionAutomationService
import com.adr.groupledger.utils.CurrencyFormatter
import com.adr.groupledger.utils.DateUtils
import com.adr.groupledger.utils.ReminderHelper
import com.adr.groupledger.utils.ReportExporter
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.Calendar

@OptIn(ExperimentalCoroutinesApi::class)
class SocietyViewModel(
    application: Application,
    private val repository: SocietyRepository
) : AndroidViewModel(application) {

    // -------------------------------------------------------------
    // Authentication & Entry Session State (Real-time Firebase Auth & Cloud Firestore)
    // -------------------------------------------------------------
    private val authPrefs = application.getSharedPreferences("app_auth_session", Context.MODE_PRIVATE)

    private val _isAuthenticated = MutableStateFlow(authPrefs.getBoolean("is_authenticated", false))
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()

    private val _authLoading = MutableStateFlow(false)
    val authLoading: StateFlow<Boolean> = _authLoading.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    // Multi-Group & User Session State
    private val _currentUserId = MutableStateFlow<Long>(authPrefs.getLong("saved_user_id", 1L))
    val currentUserId: StateFlow<Long> = _currentUserId.asStateFlow()

    private val _currentGroupId = MutableStateFlow<Long>(authPrefs.getLong("saved_group_id", 1L))
    val currentGroupId: StateFlow<Long> = _currentGroupId.asStateFlow()

    // -------------------------------------------------------------
    // Pull-to-Refresh State & Actions (Source.SERVER with 2s UI Timeout)
    // -------------------------------------------------------------
    private val _isDashboardRefreshing = MutableStateFlow(false)
    val isDashboardRefreshing: StateFlow<Boolean> = _isDashboardRefreshing.asStateFlow()

    private val _isNoticeBoardRefreshing = MutableStateFlow(false)
    val isNoticeBoardRefreshing: StateFlow<Boolean> = _isNoticeBoardRefreshing.asStateFlow()

    private val _isCommunityRefreshing = MutableStateFlow(false)
    val isCommunityRefreshing: StateFlow<Boolean> = _isCommunityRefreshing.asStateFlow()

    fun refreshDashboard() {
        if (_isDashboardRefreshing.value) return
        _isDashboardRefreshing.value = true

        // 2-second visual timeout strictly for the indicator; does not cancel background fetch
        viewModelScope.launch {
            delay(2000L)
            _isDashboardRefreshing.value = false
        }

        viewModelScope.launch {
            try {
                repository.refreshDashboardFromServer(_currentGroupId.value)
            } catch (e: Exception) {
                Log.w("SocietyViewModel", "Dashboard refresh error: ${e.message}")
            } finally {
                _isDashboardRefreshing.value = false
            }
        }
    }

    fun refreshNoticeBoard() {
        if (_isNoticeBoardRefreshing.value) return
        _isNoticeBoardRefreshing.value = true

        viewModelScope.launch {
            delay(2000L)
            _isNoticeBoardRefreshing.value = false
        }

        viewModelScope.launch {
            try {
                repository.refreshNoticesFromServer(_currentGroupId.value)
            } catch (e: Exception) {
                Log.w("SocietyViewModel", "Notice board refresh error: ${e.message}")
            } finally {
                _isNoticeBoardRefreshing.value = false
            }
        }
    }

    fun refreshCommunity() {
        if (_isCommunityRefreshing.value) return
        _isCommunityRefreshing.value = true

        viewModelScope.launch {
            delay(2000L)
            _isCommunityRefreshing.value = false
        }

        viewModelScope.launch {
            try {
                repository.refreshFeedbacksFromServer(_currentGroupId.value)
            } catch (e: Exception) {
                Log.w("SocietyViewModel", "Community refresh error: ${e.message}")
            } finally {
                _isCommunityRefreshing.value = false
            }
        }
    }

    private var realtimeSyncClosable: (() -> Unit)? = null

    // -------------------------------------------------------------
    // App Update Service Integration
    // -------------------------------------------------------------
    val appUpdateService = AppUpdateService(
        context = application,
        firebaseService = repository.firebaseService,
        scope = viewModelScope
    )

    val updateStatus: StateFlow<UpdateCheckStatus> = appUpdateService.updateStatus
    val lastUpdateCheckTime: StateFlow<Long> = appUpdateService.lastCheckedTime
    val isUpdateBannerDismissed: StateFlow<Boolean> = appUpdateService.isBannerDismissed
    val currentVersionName: String = appUpdateService.currentVersionName
    val currentVersionCode: Int = appUpdateService.currentVersionCode

    fun checkForAppUpdates(isManual: Boolean = false) {
        appUpdateService.checkForUpdates(isManual)
    }

    fun downloadAndInstallUpdate(updateInfo: AppUpdateInfo) {
        appUpdateService.downloadAndInstallUpdate(updateInfo)
    }

    fun installDownloadedApk(apkFile: File) {
        appUpdateService.installApk(apkFile)
    }

    fun openUpdateDownloadInBrowser(url: String? = null) {
        appUpdateService.openDownloadInBrowser(url)
    }

    fun publishAppUpdate(updateInfo: AppUpdateInfo, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            appUpdateService.publishAppUpdate(updateInfo, onSuccess, onError)
        }
    }

    fun simulateNewUpdateForTesting() {
        appUpdateService.simulateNewUpdateForTesting()
    }

    fun dismissUpdateBanner() {
        appUpdateService.dismissUpdateBanner()
    }

    fun resetUpdateStatus() {
        appUpdateService.resetStatus()
    }

    private fun setupRealtimeSync(groupId: Long) {
        realtimeSyncClosable?.invoke()
        val fb = repository.firebaseService ?: return
        realtimeSyncClosable = fb.attachRealtimeSync(
            groupId = groupId,
            onMembersReceived = { members ->
                viewModelScope.launch { repository.syncFromFirestoreMembers(members) }
            },
            onPaymentsReceived = { payments ->
                viewModelScope.launch { repository.syncFromFirestorePayments(payments) }
            },
            onTransactionsReceived = { txs ->
                viewModelScope.launch { repository.syncFromFirestoreTransactions(txs) }
            },
            onNoticesReceived = { notices ->
                viewModelScope.launch { repository.syncFromFirestoreNotices(notices) }
            },
            onLoansReceived = { loans ->
                viewModelScope.launch { repository.syncFromFirestoreLoans(loans) }
            },
            onMessagesReceived = { msgs ->
                viewModelScope.launch { repository.syncFromFirestoreMessages(msgs) }
            },
            onGroupSettingsReceived = { settings ->
                viewModelScope.launch { repository.syncFromFirestoreGroupSettings(settings) }
            }
        )
    }

    override fun onCleared() {
        super.onCleared()
        realtimeSyncClosable?.invoke()
        appUpdateService.cleanup()
    }

    val allUsers: StateFlow<List<UserAccount>> = repository.getAllUsersFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val currentUser: StateFlow<UserAccount?> = _currentUserId
        .flatMapLatest { id -> repository.getUserByIdFlow(id) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    val userMemberships: StateFlow<List<GroupMembership>> = _currentUserId
        .flatMapLatest { id -> repository.getMembershipsForUserFlow(id) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allGroups: StateFlow<List<GroupSettings>> = repository.getAllGroupsFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Current Group Settings flow
    val groupSettings: StateFlow<GroupSettings> = _currentGroupId
        .flatMapLatest { gid ->
            repository.getGroupSettingsFlow(gid).map { it ?: GroupSettings(id = gid) }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = GroupSettings()
        )

    // Current Group Home Page Module Configurations flow
    val homeModules: StateFlow<List<HomeModuleConfig>> = groupSettings
        .map { settings ->
            HomeModuleConfig.parseModulesJson(settings.modulesConfigJson)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = HomeModuleConfig.getDefaultModules()
        )

    // Current User's Role in Active Group
    val currentUserRole: StateFlow<String> = combine(_currentUserId, _currentGroupId, userMemberships) { uid, gid, memberships ->
        memberships.find { it.groupId == gid }?.role ?: "MEMBER"
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = "ADMIN"
    )

    // Current User's Role inside the active Group (e.g. "ADMIN" of CC CUP)
    val activeGroupRole: StateFlow<GroupRole> = currentUserRole.map { roleStr ->
        GroupRole.fromString(roleStr)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = GroupRole.MEMBER
    )

    // Current User's Application-Level Role across Group Ledger (e.g. for Carousel management)
    // CRITICAL: Group Admins default to REGULAR_USER; App Admin / Content Manager requires explicit server-side grant.
    private val _appRole = MutableStateFlow<AppRole>(AppRole.REGULAR_USER)
    val appRole: StateFlow<AppRole> = _appRole.asStateFlow()

    fun updateAppRole(role: AppRole) {
        _appRole.value = role
        if (role.canManageCarousel) {
            triggerStartupAutomationIfAuthorized()
        }
    }

    /**
     * Attempts to resolve the user's server-verified AppRole from Firebase ID token claims.
     */
    private suspend fun syncAppRoleFromServer() {
        try {
            val fb = repository.firebaseService ?: return
            val serverRole = fb.getServerAppRole()
            if (!serverRole.isNullOrBlank()) {
                val resolved = AppRole.fromString(serverRole)
                _appRole.value = resolved
            } else if (fb.isServerAppAdminClaimPresent()) {
                _appRole.value = AppRole.APP_ADMIN
            }
        } catch (e: Exception) {
            Log.w("SocietyViewModel", "Failed to sync AppRole from server: ${e.message}")
        }
    }

    /**
     * Executes backend-driven carousel automations (Festival, Promotion, and Birthday)
     * ONLY if the current user possesses application-level carousel management privileges.
     */
    private fun triggerStartupAutomationIfAuthorized() {
        if (!_appRole.value.canManageCarousel) {
            Log.d("SocietyViewModel", "Startup automation write skipped: user is not authorized to manage carousel (AppRole=${_appRole.value})")
            return
        }
        viewModelScope.launch {
            try {
                festivalAutomationService.processFestivalAutomation(GLOBAL_GROUP_ID)
            } catch (e: Exception) {
                Log.e("SocietyViewModel", "Startup festival automation skipped: ${e.message}")
            }
        }
        viewModelScope.launch {
            try {
                promotionAutomationService.processPromotionAutomation(GLOBAL_GROUP_ID)
            } catch (e: Exception) {
                Log.e("SocietyViewModel", "Startup promotion automation skipped: ${e.message}")
            }
        }
        val members = allMembers.value
        val gid = _currentGroupId.value
        if (members.isNotEmpty()) {
            viewModelScope.launch {
                try {
                    birthdayAutomationService.processBirthdayAutomation(gid, members)
                } catch (e: Exception) {
                    Log.e("SocietyViewModel", "Startup birthday automation skipped: ${e.message}")
                }
            }
        }
    }

    // -------------------------------------------------------------
    // Phase 7, 8 & 9: Backend-Driven Carousel Stream with Birthday & Festival Automation
    // -------------------------------------------------------------
    private val carouselRepository: CarouselRepository = FirestoreCarouselRepository.getInstance()
    private val birthdayAutomationService = BirthdayAutomationService.getInstance(carouselRepository)
    private val festivalAutomationService = FestivalAutomationService.getInstance(carouselRepository)
    private val promotionAutomationService = PromotionAutomationService.getInstance(carouselRepository)

    fun triggerFestivalAutomationSync(groupId: Long = GLOBAL_GROUP_ID) {
        if (!_appRole.value.canManageCarousel) {
            Log.w("SocietyViewModel", "Unauthorized festival automation sync attempt: AppRole ${_appRole.value} lacks carousel management permission")
            return
        }
        viewModelScope.launch {
            try {
                festivalAutomationService.processFestivalAutomation(groupId)
            } catch (e: Exception) {
                Log.e("SocietyViewModel", "Failed to sync festival automation: ${e.message}")
            }
        }
    }

    fun triggerPromotionAutomationSync(groupId: Long = GLOBAL_GROUP_ID) {
        if (!_appRole.value.canManageCarousel) {
            Log.w("SocietyViewModel", "Unauthorized promotion automation sync attempt: AppRole ${_appRole.value} lacks carousel management permission")
            return
        }
        viewModelScope.launch {
            try {
                promotionAutomationService.processPromotionAutomation(groupId)
            } catch (e: Exception) {
                Log.e("SocietyViewModel", "Failed to sync promotion automation: ${e.message}")
            }
        }
    }

    val activeCarouselItems: StateFlow<List<CarouselItem>> = _currentGroupId
        .flatMapLatest { gid -> carouselRepository.getActiveCarouselItems(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Current selected month & year for Monthly view & reports
    private val calendar = Calendar.getInstance()
    private val _selectedMonth = MutableStateFlow(calendar.get(Calendar.MONTH) + 1)
    val selectedMonth: StateFlow<Int> = _selectedMonth.asStateFlow()

    private val _selectedYear = MutableStateFlow(calendar.get(Calendar.YEAR))
    val selectedYear: StateFlow<Int> = _selectedYear.asStateFlow()

    // Member search and status filter
    private val _memberSearchQuery = MutableStateFlow("")
    val memberSearchQuery: StateFlow<String> = _memberSearchQuery.asStateFlow()

    private val _statusFilter = MutableStateFlow("ALL") // "ALL", "PAID", "PARTIAL", "UNPAID", "PENDING"
    val statusFilter: StateFlow<String> = _statusFilter.asStateFlow()

    // Admin authentication state
    private val _isAdminUnlocked = MutableStateFlow(false)
    val isAdminUnlocked: StateFlow<Boolean> = _isAdminUnlocked.asStateFlow()

    private val _showPinDialog = MutableStateFlow(false)
    val showPinDialog: StateFlow<Boolean> = _showPinDialog.asStateFlow()

    private var pendingAdminAction: (() -> Unit)? = null

    // Selected member for profile inspection
    private val _selectedMemberId = MutableStateFlow<Long?>(null)
    val selectedMemberId: StateFlow<Long?> = _selectedMemberId.asStateFlow()

    // Toast message trigger
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    // -------------------------------------------------------------
    // Scoped Data Streams by Current Group ID
    // -------------------------------------------------------------
    val allMembers: StateFlow<List<Member>> = _currentGroupId
        .flatMapLatest { gid -> repository.getAllMembers(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val activeMembers: StateFlow<List<Member>> = _currentGroupId
        .flatMapLatest { gid -> repository.getActiveMembers(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allActiveMembers: StateFlow<List<Member>> get() = activeMembers

    init {
        viewModelScope.launch {
            _currentGroupId.collect { gid ->
                setupRealtimeSync(gid)
            }
        }
        viewModelScope.launch {
            syncAppRoleFromServer()
            if (_appRole.value.canManageCarousel) {
                triggerStartupAutomationIfAuthorized()
            } else {
                Log.d("SocietyViewModel", "Startup carousel automations bypassed: user is not authorized to manage carousel (AppRole=${_appRole.value})")
            }
        }
        viewModelScope.launch {
            allMembers.collect { members ->
                val gid = _currentGroupId.value
                if (members.isNotEmpty()) {
                    if (_appRole.value.canManageCarousel) {
                        birthdayAutomationService.processBirthdayAutomation(gid, members)
                    } else {
                        Log.d("SocietyViewModel", "Skipping birthday automation write: user is not authorized to manage carousel (AppRole=${_appRole.value})")
                    }
                }
            }
        }
        // Auto-check for updates silently on startup
        appUpdateService.checkForUpdates(isManual = false)
    }

    val allPayments: StateFlow<List<Payment>> = _currentGroupId
        .flatMapLatest { gid -> repository.getAllPayments(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val pendingPaymentApprovals: StateFlow<List<PendingPaymentApprovalItem>> = _currentGroupId
        .flatMapLatest { gid -> repository.getPendingPaymentApprovals(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val overallFinancials: StateFlow<OverallGroupFinancials> = _currentGroupId
        .flatMapLatest { gid -> repository.getComprehensiveFinancials(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = OverallGroupFinancials(
                totalMembers = 0,
                activeMembers = 0,
                totalCollectedAllTime = 0.0,
                totalDueAllTime = 0.0,
                currentMonthCollected = 0.0,
                currentMonthDue = 0.0,
                currentMonthPaidCount = 0,
                currentMonthUnpaidCount = 0,
                currentMonthPartialCount = 0,
                previousMonthCollected = 0.0,
                monthlyTrends = emptyList()
            )
        )

    val currentMonthSummary: StateFlow<MonthlySummary> = combine(
        _selectedMonth,
        _selectedYear,
        allPayments,
        activeMembers,
        groupSettings
    ) { month, year, payments, members, settings ->
        val defExp = settings.defaultContribution
        val mPayments = payments.filter { it.month == month && it.year == year }
        val mApprovedPayments = mPayments.filter { it.isApproved }
        val totalMembers = members.size
        val totalExpected = members.sumOf { if (it.monthlyContribution > 0) it.monthlyContribution else defExp }
        val totalCollected = mApprovedPayments.sumOf { it.paidAmount }
        val totalDue = (totalExpected - totalCollected).coerceAtLeast(0.0)

        val paidCount = mApprovedPayments.count { it.status == "PAID" }
        val partialCount = mApprovedPayments.count { it.status == "PARTIAL" }
        val unpaidCount = (totalMembers - (paidCount + partialCount)).coerceAtLeast(0)
        val collectionPercentage = if (totalExpected > 0) ((totalCollected / totalExpected) * 100).toFloat() else 0f

        MonthlySummary(
            month = month,
            year = year,
            monthName = DateUtils.getMonthName(month),
            totalMembers = totalMembers,
            totalExpected = totalExpected,
            totalCollected = totalCollected,
            totalDue = totalDue,
            paidCount = paidCount,
            partialCount = partialCount,
            unpaidCount = unpaidCount,
            collectionPercentage = collectionPercentage
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = MonthlySummary(
            month = calendar.get(Calendar.MONTH) + 1,
            year = calendar.get(Calendar.YEAR),
            monthName = DateUtils.getMonthName(calendar.get(Calendar.MONTH) + 1),
            totalMembers = 0,
            totalExpected = 0.0,
            totalCollected = 0.0,
            totalDue = 0.0,
            paidCount = 0,
            partialCount = 0,
            unpaidCount = 0,
            collectionPercentage = 0f
        )
    )

    val membersWithMonthlyStatus: StateFlow<List<MemberWithMonthlyStatus>> = combine(
        _selectedMonth,
        _selectedYear,
        activeMembers,
        allPayments,
        groupSettings
    ) { month, year, members, payments, settings ->
        val defaultExp = settings.defaultContribution
        val mPayments = payments.filter { it.month == month && it.year == year }.associateBy { it.memberId }

        members.map { member ->
            val payment = mPayments[member.id]
            val expected = if (member.monthlyContribution > 0) member.monthlyContribution else defaultExp

            val displayStatus = when {
                payment == null -> "UNPAID"
                payment.isPendingApproval -> "PENDING_APPROVAL"
                payment.isRejected -> "REJECTED"
                else -> payment.status
            }

            val paid = if (payment != null && payment.isApproved) payment.paidAmount else 0.0
            val due = if (payment != null && payment.isApproved) payment.dueAmount else expected

            MemberWithMonthlyStatus(
                member = member,
                payment = payment,
                effectiveExpectedAmount = expected,
                paidAmount = paid,
                dueAmount = due,
                status = displayStatus
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val monthlyMembersList: StateFlow<List<MemberWithMonthlyStatus>> get() = membersWithMonthlyStatus

    val filteredMembersWithStatus: StateFlow<List<MemberWithMonthlyStatus>> = combine(
        membersWithMonthlyStatus,
        _memberSearchQuery,
        _statusFilter
    ) { list, query, filter ->
        list.filter { item ->
            val matchesQuery = query.isBlank() ||
                    item.member.name.contains(query, ignoreCase = true) ||
                    item.member.memberCode.contains(query, ignoreCase = true) ||
                    item.member.phone.contains(query)

            val matchesFilter = when (filter) {
                "PAID" -> item.status == "PAID"
                "PARTIAL" -> item.status == "PARTIAL"
                "UNPAID" -> item.status == "UNPAID" || item.status == "REJECTED"
                "PENDING" -> item.status == "PENDING_APPROVAL"
                else -> true
            }

            matchesQuery && matchesFilter
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val pendingDuesList: StateFlow<List<MemberWithMonthlyStatus>> = membersWithMonthlyStatus
        .flatMapLatest { list ->
            MutableStateFlow(list.filter { it.status in listOf("UNPAID", "PARTIAL", "REJECTED") && it.dueAmount > 0 })
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val recentTransactions: StateFlow<List<RecentTransaction>> = _currentGroupId
        .flatMapLatest { gid -> repository.getRecentTransactions(gid, 10) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allLoansWithVotes: StateFlow<List<LoanWithVotingDetails>> = _currentGroupId
        .flatMapLatest { gid -> repository.getLoansWithVotingDetails(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val loansWithVoting: StateFlow<List<LoanWithVotingDetails>> get() = allLoansWithVotes

    val allInvestments: StateFlow<List<InvestmentRecord>> = _currentGroupId
        .flatMapLatest { gid -> repository.getAllInvestments(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allFeedbacksWithVotes: StateFlow<List<FeedbackWithVotes>> = _currentGroupId
        .flatMapLatest { gid -> repository.getFeedbacksWithVotes(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val feedbacksWithVotes: StateFlow<List<FeedbackWithVotes>> get() = allFeedbacksWithVotes

    val allNotifications: StateFlow<List<NotificationItem>> = _currentGroupId
        .flatMapLatest { gid -> repository.getAllNotifications(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val unreadNotificationsCount: StateFlow<Int> = _currentGroupId
        .flatMapLatest { gid -> repository.getUnreadNotificationsCount(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    val inboxBadgeCount: StateFlow<Int> = combine(
        unreadNotificationsCount,
        pendingPaymentApprovals,
        currentUserRole,
        _isAdminUnlocked
    ) { unread, pending, role, unlocked ->
        val isAdmin = unlocked || role.equals("ADMIN", ignoreCase = true)
        if (isAdmin) {
            (unread + pending.size).coerceAtLeast(0)
        } else {
            unread
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    val allTransactions: StateFlow<List<TransactionRecord>> = _currentGroupId
        .flatMapLatest { gid -> repository.getAllTransactions(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val notices: StateFlow<List<SocietyNotice>> = _currentGroupId
        .flatMapLatest { gid -> repository.getNotices(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val chatMessages: StateFlow<List<GroupChatMessage>> = _currentGroupId
        .flatMapLatest { gid -> repository.getChatMessages(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val memberProfile: StateFlow<MemberFinancialProfile?> = _selectedMemberId
        .flatMapLatest { id ->
            if (id != null) repository.getMemberFinancialProfile(id) else MutableStateFlow(null)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    val selectedMemberProfile: StateFlow<MemberFinancialProfile?> get() = memberProfile

    // -------------------------------------------------------------
    // Pre-Authorized Members & Join Requests Streams
    // -------------------------------------------------------------
    val preAuthorizedMembers: StateFlow<List<PreAuthorizedMember>> = _currentGroupId
        .flatMapLatest { gid -> repository.getPreAuthorizedMembersFlow(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val pendingJoinRequests: StateFlow<List<GroupJoinRequest>> = _currentGroupId
        .flatMapLatest { gid -> repository.getPendingJoinRequestsFlow(gid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val userPendingRequests: StateFlow<List<GroupJoinRequest>> = _currentUserId
        .flatMapLatest { uid -> repository.getUserPendingRequestsFlow(uid) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // -------------------------------------------------------------
    // User & Group Switching / Creation Functions
    // -------------------------------------------------------------
    fun switchUser(userId: Long) {
        _currentUserId.value = userId
        _isAdminUnlocked.value = false
        _currentMemberId.value = null
        viewModelScope.launch {
            val memberships = repository.getMembershipsForUserDirect(userId)
            if (memberships.isNotEmpty()) {
                val matching = memberships.find { it.groupId == _currentGroupId.value }
                if (matching != null) {
                    _currentMemberId.value = matching.memberIdInGroup
                } else {
                    _currentGroupId.value = memberships.first().groupId
                    _currentMemberId.value = memberships.first().memberIdInGroup
                }
            }
            _userMessage.value = "Switched user account"
        }
    }

    fun switchGroup(groupId: Long) {
        _currentGroupId.value = groupId
        authPrefs.edit().putLong("saved_group_id", groupId).apply()
        _isAdminUnlocked.value = false
        _selectedMemberId.value = null
        viewModelScope.launch {
            val membership = repository.getMembershipDirect(_currentUserId.value, groupId)
            _currentMemberId.value = membership?.memberIdInGroup
            if (membership?.role.equals("ADMIN", ignoreCase = true)) {
                _isAdminUnlocked.value = true
            }
            val group = repository.getGroupSettings(groupId)
            if (group != null) {
                _userMessage.value = "Switched to ${group.groupName}"
            }
        }
    }

    fun registerNewUserAccount(
        fullName: String,
        email: String,
        phone: String,
        onSuccess: (Long) -> Unit
    ) {
        viewModelScope.launch {
            if (fullName.isBlank() || phone.isBlank()) {
                _userMessage.value = "Full Name and Phone Number are required"
                return@launch
            }
            val existing = if (email.isNotBlank()) repository.getUserByEmail(email) else null
            if (existing != null) {
                _userMessage.value = "Account already exists with this email. Switched to existing account."
                switchUser(existing.id)
                onSuccess(existing.id)
                return@launch
            }
            val newUser = UserAccount(
                fullName = fullName.trim(),
                email = email.trim(),
                phone = phone.trim()
            )
            val newUserId = repository.createUserAccount(newUser)
            switchUser(newUserId)
            _userMessage.value = "Account created successfully!"
            onSuccess(newUserId)
        }
    }

    private val _selectedReportType = MutableStateFlow("MONTHLY")
    val selectedReportType: StateFlow<String> = _selectedReportType.asStateFlow()

    fun setSelectedReportType(type: String) {
        _selectedReportType.value = type
    }

    fun exportCurrentReportPdf(context: Context) {
        if (_selectedReportType.value == "PENDING") {
            exportPendingDuesPdf(context)
        } else {
            exportMonthlyReportPdf(context)
        }
    }

    fun exportCurrentReportCsv(context: Context) {
        if (_selectedReportType.value == "PENDING") {
            exportPendingDuesCsv(context)
        } else {
            exportMonthlyReportCsv(context)
        }
    }

    fun createNewGroup(
        groupName: String,
        groupSubtitle: String = "",
        groupType: String = "Self-Help Group",
        description: String = "",
        address: String = "",
        contactPhone: String = "",
        contactEmail: String = "",
        isContributionEnabled: Boolean = true,
        defaultContribution: Double = 500.0,
        currencySymbol: String = "₹",
        contributionFrequency: String = "MONTHLY",
        dueDayOfMonth: Int = 10,
        isLateFeeEnabled: Boolean = false,
        lateFineAmount: Double = 0.0,
        gracePeriodDays: Int = 5,
        paymentRules: String = "Contribution is due by the 10th of every month.",
        modulesConfigJson: String = "",
        inviteCode: String = "",
        adminPin: String = "1234",
        isPinLockEnabled: Boolean = false,
        onSuccess: (GroupSettings) -> Unit = {}
    ) {
        viewModelScope.launch {
            if (groupName.isBlank()) {
                _userMessage.value = "Group name cannot be empty"
                return@launch
            }
            val user = repository.getUserById(_currentUserId.value) ?: UserAccount(id = _currentUserId.value, fullName = "Admin User")
            if (!user.isAccountCompleted) {
                _userMessage.value = "Please complete the Sign-up process to create and manage your own groups."
                return@launch
            }
            val newGroup = repository.createGroup(
                groupName = groupName.trim(),
                groupSubtitle = groupSubtitle.trim(),
                groupType = groupType.trim().ifBlank { "Self-Help Group" },
                description = description.trim(),
                address = address.trim(),
                contactPhone = contactPhone.trim(),
                contactEmail = contactEmail.trim(),
                isContributionEnabled = isContributionEnabled,
                defaultContribution = defaultContribution,
                currencySymbol = currencySymbol.trim().ifBlank { "₹" },
                contributionFrequency = contributionFrequency.trim().ifBlank { "MONTHLY" },
                dueDayOfMonth = dueDayOfMonth,
                isLateFeeEnabled = isLateFeeEnabled,
                lateFineAmount = lateFineAmount,
                gracePeriodDays = gracePeriodDays,
                paymentRules = paymentRules.trim(),
                modulesConfigJson = modulesConfigJson,
                inviteCode = inviteCode.trim(),
                adminPin = adminPin.trim().ifBlank { "1234" },
                isPinLockEnabled = isPinLockEnabled,
                creatorUser = user
            )
            switchGroup(newGroup.id)
            _isAdminUnlocked.value = true
            _userMessage.value = "New group '${newGroup.groupName}' created! Invite Code: ${newGroup.inviteCode}"
            onSuccess(newGroup)
        }
    }

    fun updateSpecificGroup(
        settings: GroupSettings,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            if (settings.groupName.isBlank()) {
                _userMessage.value = "Group name cannot be empty"
                return@launch
            }
            val existing = repository.getGroupSettings(settings.id)
            val currentUid = _currentUserId.value
            val isCreator = existing != null && existing.createdByUserId == currentUid
            val isAdmin = currentUserRole.value.equals("ADMIN", ignoreCase = true)
            if (!isCreator && !isAdmin) {
                _userMessage.value = "Only the group creator can modify group settings."
                return@launch
            }
            repository.updateSettings(settings)
            _userMessage.value = "Group '${settings.groupName}' updated successfully"
            onSuccess()
        }
    }

    fun deleteGroup(
        groupId: Long,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            val all = repository.getAllGroupsDirect()
            val groupToDelete = all.find { it.id == groupId }
            val currentUid = _currentUserId.value
            val isCreator = groupToDelete != null && groupToDelete.createdByUserId == currentUid
            val isAdmin = currentUserRole.value.equals("ADMIN", ignoreCase = true)
            if (!isCreator && !isAdmin) {
                _userMessage.value = "Only the group creator can delete this group."
                return@launch
            }
            val groupName = groupToDelete?.groupName ?: "Group #$groupId"
            val currentAuthUid = repository.firebaseService?.currentFirebaseUser?.uid ?: _currentUserId.value.toString()

            val success = repository.deleteGroup(groupId, currentAuthUid)
            if (success) {
                _userMessage.value = "Group '$groupName' has been deleted."
                // If deleted group is currently active, switch to another
                if (_currentGroupId.value == groupId) {
                    val remaining = repository.getAllGroupsDirect()
                    if (remaining.isNotEmpty()) {
                        switchGroup(remaining.first().id)
                    } else {
                        val user = repository.getUserById(_currentUserId.value) ?: UserAccount(id = _currentUserId.value, fullName = "Admin User")
                        val defaultGroup = repository.createGroup(
                            groupName = "My Society",
                            creatorUser = user
                        )
                        switchGroup(defaultGroup.id)
                    }
                }
                onSuccess()
            } else {
                _userMessage.value = "Failed to delete group."
            }
        }
    }

    fun regenerateGroupInviteCode(onSuccess: (String) -> Unit = {}) {
        viewModelScope.launch {
            val currentGroup = groupSettings.value
            val currentUid = _currentUserId.value
            val isCreator = currentGroup.createdByUserId == currentUid
            val isAdmin = currentUserRole.value.equals("ADMIN", ignoreCase = true)
            if (!isCreator && !isAdmin) {
                _userMessage.value = "Only the group creator can regenerate the invitation code."
                return@launch
            }
            val user = currentUser.value?.fullName ?: currentGroup.adminName
            val newCode = repository.regenerateGroupInviteCode(currentGroup.id, user)
            if (newCode.isNotBlank()) {
                _userMessage.value = "New Invitation Code generated: $newCode"
                onSuccess(newCode)
            }
        }
    }

    fun joinGroupByInviteCode(
        inviteCode: String,
        onResult: (GroupJoinResult) -> Unit = {}
    ) {
        viewModelScope.launch {
            if (inviteCode.isBlank()) {
                _userMessage.value = "Please enter an invite code"
                onResult(GroupJoinResult.Error("Please enter an invite code"))
                return@launch
            }
            val user = repository.getUserById(_currentUserId.value)
            if (user == null) {
                _userMessage.value = "Please select or set up a user profile first."
                onResult(GroupJoinResult.Error("No active user profile"))
                return@launch
            }
            val result = repository.joinGroupByInviteCode(inviteCode.trim().uppercase(), user)
            when (result) {
                is GroupJoinResult.Success -> {
                    _userMessage.value = result.message
                    switchGroup(result.group.id)
                }
                is GroupJoinResult.AlreadyMember -> {
                    _userMessage.value = result.message
                    switchGroup(result.group.id)
                }
                is GroupJoinResult.Pending -> {
                    _userMessage.value = result.message
                }
                is GroupJoinResult.Error -> {
                    _userMessage.value = result.message
                }
            }
            onResult(result)
        }
    }

    // -------------------------------------------------------------
    // Admin Pre-Authorization & Join Request Operations
    // -------------------------------------------------------------
    fun addPreAuthorizedMember(
        name: String,
        email: String,
        phone: String = "",
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        val trimmedName = name.trim()
        val trimmedEmail = email.trim()
        val trimmedPhone = phone.trim()

        if (trimmedName.isBlank()) {
            val err = "Member name cannot be empty"
            _userMessage.value = err
            onError(err)
            return
        }
        if (trimmedEmail.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(trimmedEmail).matches()) {
            val err = "Please enter a valid email address"
            _userMessage.value = err
            onError(err)
            return
        }

        viewModelScope.launch {
            val adminName = currentUser.value?.fullName ?: groupSettings.value.adminName
            val result = repository.addPreAuthorizedMember(
                groupId = _currentGroupId.value,
                name = trimmedName,
                email = trimmedEmail,
                phone = trimmedPhone,
                adminName = adminName
            )
            if (result.isSuccess) {
                _userMessage.value = "Added $trimmedName to pre-authorized members list."
                onSuccess()
            } else {
                val err = result.exceptionOrNull()?.message ?: "Failed to add pre-authorized member."
                _userMessage.value = err
                onError(err)
            }
        }
    }

    fun deletePreAuthorizedMember(
        id: Long,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val adminName = currentUser.value?.fullName ?: groupSettings.value.adminName
            val success = repository.deletePreAuthorizedMember(id, _currentGroupId.value, adminName)
            if (success) {
                _userMessage.value = "Pre-authorized member entry removed."
                onSuccess()
            } else {
                val err = "Failed to remove entry."
                _userMessage.value = err
                onError(err)
            }
        }
    }

    fun approveJoinRequest(
        requestId: Long,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val adminName = currentUser.value?.fullName ?: groupSettings.value.adminName
            val success = repository.approveJoinRequest(requestId, adminName)
            if (success) {
                _userMessage.value = "Join request approved! Member added to group."
                onSuccess()
            } else {
                val err = "Failed to approve join request."
                _userMessage.value = err
                onError(err)
            }
        }
    }

    fun rejectJoinRequest(
        requestId: Long,
        reason: String = "",
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val adminName = currentUser.value?.fullName ?: groupSettings.value.adminName
            val success = repository.rejectJoinRequest(requestId, adminName, reason.trim())
            if (success) {
                _userMessage.value = "Join request rejected."
                onSuccess()
            } else {
                val err = "Failed to reject join request."
                _userMessage.value = err
                onError(err)
            }
        }
    }

    fun updateUserProfile(
        fullName: String,
        email: String,
        phone: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val trimmedName = fullName.trim()
        val trimmedEmail = email.trim()
        val trimmedPhone = phone.trim()

        if (trimmedName.isBlank()) {
            val err = "Name cannot be empty"
            _userMessage.value = err
            onError(err)
            return
        }

        viewModelScope.launch {
            try {
                val current = repository.getUserById(_currentUserId.value)
                if (current != null) {
                    val updated = current.copy(
                        fullName = trimmedName,
                        email = trimmedEmail.ifBlank { current.email },
                        phone = trimmedPhone.ifBlank { current.phone }
                    )
                    repository.updateUserAccount(updated)

                    // Also update corresponding Member profile name/phone in current group if present
                    val currentMember = _currentMemberId.value?.let { repository.getMemberById(it) }
                    if (currentMember != null) {
                        repository.updateMember(
                            currentMember.copy(
                                name = trimmedName,
                                phone = trimmedPhone.ifBlank { currentMember.phone }
                            )
                        )
                    }

                    _userMessage.value = "Profile updated successfully"
                    onSuccess()
                } else {
                    onError("User profile not found")
                }
            } catch (e: Exception) {
                val err = e.message ?: "Failed to update profile"
                _userMessage.value = err
                onError(err)
            }
        }
    }

    fun completeGuestSignUp(
        fullName: String,
        email: String,
        password: String,
        phone: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val trimmedName = fullName.trim()
        val trimmedEmail = email.trim()
        val trimmedPhone = phone.trim()

        if (trimmedName.isBlank()) {
            val err = "Full name cannot be empty"
            onError(err)
            return
        }
        if (trimmedEmail.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(trimmedEmail).matches()) {
            val err = "Please enter a valid email address"
            onError(err)
            return
        }
        if (password.length < 6) {
            val err = "Password must be at least 6 characters"
            onError(err)
            return
        }

        viewModelScope.launch {
            try {
                val user = repository.getUserById(_currentUserId.value)
                if (user != null) {
                    val updated = user.copy(
                        fullName = trimmedName,
                        email = trimmedEmail,
                        passwordHash = password,
                        phone = trimmedPhone,
                        isAccountCompleted = true
                    )
                    repository.updateUserAccount(updated)

                    // Also sync member name in active group if present
                    val memberId = _currentMemberId.value
                    if (memberId != null) {
                        val member = repository.getMemberById(memberId)
                        if (member != null) {
                            repository.updateMember(member.copy(name = trimmedName, phone = trimmedPhone))
                        }
                    }

                    _userMessage.value = "Account setup complete! You can now create groups."
                    onSuccess()
                } else {
                    // Create new user account and switch
                    val newUser = UserAccount(
                        fullName = trimmedName,
                        email = trimmedEmail,
                        passwordHash = password,
                        phone = trimmedPhone,
                        isAccountCompleted = true
                    )
                    val newUid = repository.createUserAccount(newUser)
                    switchUser(newUid)
                    _userMessage.value = "Account setup complete! You can now create groups."
                    onSuccess()
                }
            } catch (e: Exception) {
                onError(e.message ?: "Failed to complete account registration")
            }
        }
    }

    // -------------------------------------------------------------
    // App Entry, Sign Up & Invitation Code Authentication Logic
    // -------------------------------------------------------------
    fun clearAuthError() {
        _authError.value = null
    }

    fun signUpWithEmail(
        fullName: String,
        email: String,
        password: String,
        phone: String = "",
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val trimmedName = fullName.trim()
        val trimmedEmail = email.trim()
        val trimmedPhone = phone.trim()

        if (trimmedName.isBlank()) {
            val err = "Full name cannot be empty"
            _authError.value = err
            onError(err)
            return
        }
        if (trimmedEmail.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(trimmedEmail).matches()) {
            val err = "Please enter a valid email address"
            _authError.value = err
            onError(err)
            return
        }
        if (password.length < 6) {
            val err = "Password must be at least 6 characters"
            _authError.value = err
            onError(err)
            return
        }

        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            try {
                // Real-time Firebase Auth Sign Up
                val fb = repository.firebaseService
                if (fb != null) {
                    val fbResult = fb.signUpWithEmail(trimmedEmail, password, trimmedName, trimmedPhone)
                    if (fbResult.isFailure) {
                        val message = fbResult.exceptionOrNull()?.message ?: "Sign up failed"
                        _authLoading.value = false
                        _authError.value = message
                        onError(message)
                        return@launch
                    }
                }

                val existing = repository.getUserByEmail(trimmedEmail)
                val user = if (existing != null) {
                    val updated = existing.copy(
                        fullName = trimmedName.ifBlank { existing.fullName },
                        phone = trimmedPhone.ifBlank { existing.phone }
                    )
                    repository.updateUserAccount(updated)
                    updated
                } else {
                    val newAccount = UserAccount(
                        fullName = trimmedName,
                        email = trimmedEmail,
                        phone = trimmedPhone,
                        passwordHash = password,
                        isAccountCompleted = true
                    )
                    val newUid = repository.createUserAccount(newAccount)
                    newAccount.copy(id = newUid)
                }

                _currentUserId.value = user.id

                // Automatic Group Joining on Sign-up:
                // Match against unclaimed offline members in Firestore & Room
                val authUid = repository.firebaseService?.currentFirebaseUser?.uid ?: user.id.toString()
                val autoJoinedGroups = repository.matchAndClaimOfflineMembers(user, authUid)

                val memberships = repository.getMembershipsForUserDirect(user.id)
                val groupId = if (autoJoinedGroups.isNotEmpty()) {
                    autoJoinedGroups.first().id
                } else if (memberships.isNotEmpty()) {
                    memberships.first().groupId
                } else {
                    repository.getAllGroupsDirect().firstOrNull()?.id ?: 1L
                }

                _currentGroupId.value = groupId
                val membership = repository.getMembershipDirect(user.id, groupId)
                _currentMemberId.value = membership?.memberIdInGroup

                authPrefs.edit()
                    .putBoolean("is_authenticated", true)
                    .putLong("saved_user_id", user.id)
                    .putLong("saved_group_id", groupId)
                    .apply()

                _isAuthenticated.value = true
                _authLoading.value = false
                val welcomeMsg = if (autoJoinedGroups.isNotEmpty()) {
                    "Welcome, $trimmedName! Automatically joined ${autoJoinedGroups.size} group(s) as a registered member."
                } else {
                    "Account created successfully! Welcome, $trimmedName"
                }
                _userMessage.value = welcomeMsg
                setupRealtimeSync(groupId)
                onSuccess()
            } catch (e: Exception) {
                _authLoading.value = false
                val err = e.message ?: "Failed to create account. Please try again."
                _authError.value = err
                onError(err)
            }
        }
    }

    fun signUpWithGoogle(
        displayName: String = "Google User",
        email: String = "user@gmail.com",
        onSuccess: () -> Unit,
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            try {
                kotlinx.coroutines.delay(600)
                var user = repository.getUserByEmail(email)
                if (user == null) {
                    val newAccount = UserAccount(
                        fullName = displayName.ifBlank { "Google User" },
                        email = email,
                        phone = "+91 98300 ${10000 + (System.currentTimeMillis() % 90000)}",
                        isAccountCompleted = true
                    )
                    val newUid = repository.createUserAccount(newAccount)
                    user = newAccount.copy(id = newUid)
                }

                _currentUserId.value = user.id
                val memberships = repository.getMembershipsForUserDirect(user.id)
                val groupId = if (memberships.isNotEmpty()) {
                    memberships.first().groupId
                } else {
                    repository.getAllGroupsDirect().firstOrNull()?.id ?: 1L
                }
                _currentGroupId.value = groupId
                val membership = repository.getMembershipDirect(user.id, groupId)
                _currentMemberId.value = membership?.memberIdInGroup

                authPrefs.edit()
                    .putBoolean("is_authenticated", true)
                    .putLong("saved_user_id", user.id)
                    .putLong("saved_group_id", groupId)
                    .apply()

                _isAuthenticated.value = true
                _authLoading.value = false
                _userMessage.value = "Signed in with Google as ${user.fullName}"
                setupRealtimeSync(groupId)
                onSuccess()
            } catch (e: Exception) {
                _authLoading.value = false
                val err = e.message ?: "Google sign in failed"
                _authError.value = err
                onError(err)
            }
        }
    }

    fun signUpWithPhone(
        fullName: String,
        phone: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val trimmedName = fullName.trim()
        val trimmedPhone = phone.trim()
        if (trimmedName.isBlank()) {
            val err = "Please enter your name"
            _authError.value = err
            onError(err)
            return
        }
        if (trimmedPhone.isBlank() || trimmedPhone.length < 8) {
            val err = "Please enter a valid phone number"
            _authError.value = err
            onError(err)
            return
        }

        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            try {
                kotlinx.coroutines.delay(500)
                val email = "phone_${trimmedPhone.replace(Regex("[^0-9]"), "")}@groupledger.org"
                var user = repository.getUserByEmail(email)
                if (user == null) {
                    val newAccount = UserAccount(
                        fullName = trimmedName,
                        email = email,
                        phone = trimmedPhone,
                        isAccountCompleted = true
                    )
                    val newUid = repository.createUserAccount(newAccount)
                    user = newAccount.copy(id = newUid)
                }

                _currentUserId.value = user.id
                val memberships = repository.getMembershipsForUserDirect(user.id)
                val groupId = if (memberships.isNotEmpty()) {
                    memberships.first().groupId
                } else {
                    repository.getAllGroupsDirect().firstOrNull()?.id ?: 1L
                }
                _currentGroupId.value = groupId
                val membership = repository.getMembershipDirect(user.id, groupId)
                _currentMemberId.value = membership?.memberIdInGroup

                authPrefs.edit()
                    .putBoolean("is_authenticated", true)
                    .putLong("saved_user_id", user.id)
                    .putLong("saved_group_id", groupId)
                    .apply()

                _isAuthenticated.value = true
                _authLoading.value = false
                _userMessage.value = "Registered successfully as ${user.fullName}"
                setupRealtimeSync(groupId)
                onSuccess()
            } catch (e: Exception) {
                _authLoading.value = false
                val err = e.message ?: "Registration failed"
                _authError.value = err
                onError(err)
            }
        }
    }

    fun loginWithEmail(
        email: String,
        password: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val trimmedEmail = email.trim()

        if (trimmedEmail.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(trimmedEmail).matches()) {
            val err = "Please enter a valid email address"
            _authError.value = err
            onError(err)
            return
        }
        if (password.isBlank()) {
            val err = "Password cannot be empty"
            _authError.value = err
            onError(err)
            return
        }

        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            try {
                // Real-time Firebase Auth Sign In
                val fb = repository.firebaseService
                if (fb != null) {
                    val fbResult = fb.signInWithEmail(trimmedEmail, password)
                    if (fbResult.isFailure) {
                        val message = fbResult.exceptionOrNull()?.message ?: "Login failed"
                        _authLoading.value = false
                        _authError.value = message
                        onError(message)
                        return@launch
                    }
                }

                var user = repository.getUserByEmail(trimmedEmail)
                if (user == null) {
                    // Create account record if first time on device
                    val newAccount = UserAccount(
                        fullName = trimmedEmail.substringBefore("@").replace(".", " ")
                            .replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() },
                        email = trimmedEmail,
                        phone = "+91 98300 ${10000 + (System.currentTimeMillis() % 90000)}",
                        passwordHash = password,
                        isAccountCompleted = true
                    )
                    val newUid = repository.createUserAccount(newAccount)
                    user = newAccount.copy(id = newUid)
                }

                _currentUserId.value = user.id

                // Automatic Group Joining check on login
                val authUid = repository.firebaseService?.currentFirebaseUser?.uid ?: user.id.toString()
                val autoJoinedGroups = repository.matchAndClaimOfflineMembers(user, authUid)

                val memberships = repository.getMembershipsForUserDirect(user.id)
                val groupId = if (autoJoinedGroups.isNotEmpty()) {
                    autoJoinedGroups.first().id
                } else if (memberships.isNotEmpty()) {
                    memberships.first().groupId
                } else {
                    1L
                }
                _currentGroupId.value = groupId
                val membership = repository.getMembershipDirect(user.id, groupId)
                _currentMemberId.value = membership?.memberIdInGroup

                authPrefs.edit()
                    .putBoolean("is_authenticated", true)
                    .putLong("saved_user_id", user.id)
                    .putLong("saved_group_id", groupId)
                    .apply()

                _isAuthenticated.value = true
                _authLoading.value = false
                syncAppRoleFromServer()
                if (_appRole.value.canManageCarousel) {
                    triggerStartupAutomationIfAuthorized()
                }
                val welcomeMsg = if (autoJoinedGroups.isNotEmpty()) {
                    "Welcome back, ${user.fullName}! Linked to ${autoJoinedGroups.size} group(s)."
                } else {
                    "Welcome back, ${user.fullName}!"
                }
                _userMessage.value = welcomeMsg
                setupRealtimeSync(groupId)
                onSuccess()
            } catch (e: Exception) {
                _authLoading.value = false
                val err = e.message ?: "Login failed. Please check credentials."
                _authError.value = err
                onError(err)
            }
        }
    }

    fun sendPasswordResetEmail(
        email: String,
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val trimmed = email.trim()
        if (trimmed.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(trimmed).matches()) {
            val err = "Please enter a valid email address"
            _authError.value = err
            onError(err)
            return
        }

        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            try {
                val fb = repository.firebaseService
                if (fb != null) {
                    val fbResult = fb.sendPasswordResetEmail(trimmed)
                    _authLoading.value = false
                    if (fbResult.isSuccess) {
                        val msg = "Password reset link sent to $trimmed"
                        _userMessage.value = msg
                        onSuccess(msg)
                    } else {
                        val msg = fbResult.exceptionOrNull()?.message ?: "Failed to send reset email"
                        _authError.value = msg
                        onError(msg)
                    }
                } else {
                    _authLoading.value = false
                    val msg = "Password reset instructions sent to $trimmed"
                    _userMessage.value = msg
                    onSuccess(msg)
                }
            } catch (e: Exception) {
                _authLoading.value = false
                val err = e.message ?: "Failed to send password reset email"
                _authError.value = err
                onError(err)
            }
        }
    }

    fun joinWithInviteCodeDirect(
        inviteCode: String,
        onSuccess: (String) -> Unit,
        onPending: (String, GroupJoinRequest) -> Unit = { _, _ -> },
        onError: (String) -> Unit = {}
    ) {
        val trimmed = inviteCode.trim().uppercase()
        if (trimmed.isBlank()) {
            val err = "Please enter an invitation code"
            _authError.value = err
            onError(err)
            return
        }

        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            try {
                // Verification delay
                kotlinx.coroutines.delay(400)

                // Associate user account
                var user = repository.getUserById(_currentUserId.value)
                if (user == null) {
                    val suffix = (System.currentTimeMillis() % 1000).toString()
                    val newAccount = UserAccount(
                        fullName = "Member #$suffix",
                        email = "member$suffix@groupledger.org",
                        phone = "+91 98300 ${10000 + (System.currentTimeMillis() % 90000)}",
                        isAccountCompleted = false
                    )
                    val newUid = repository.createUserAccount(newAccount)
                    _currentUserId.value = newUid
                    user = newAccount.copy(id = newUid)
                }

                val joinResult = repository.joinGroupByInviteCode(trimmed, user)
                _authLoading.value = false

                when (joinResult) {
                    is GroupJoinResult.Success -> {
                        _currentGroupId.value = joinResult.group.id
                        val membership = repository.getMembershipDirect(user.id, joinResult.group.id)
                        _currentMemberId.value = membership?.memberIdInGroup

                        authPrefs.edit()
                            .putBoolean("is_authenticated", true)
                            .putLong("saved_user_id", user.id)
                            .putLong("saved_group_id", joinResult.group.id)
                            .apply()

                        _isAuthenticated.value = true
                        _userMessage.value = joinResult.message
                        setupRealtimeSync(joinResult.group.id)
                        onSuccess(joinResult.group.groupName)
                    }
                    is GroupJoinResult.AlreadyMember -> {
                        _currentGroupId.value = joinResult.group.id
                        val membership = repository.getMembershipDirect(user.id, joinResult.group.id)
                        _currentMemberId.value = membership?.memberIdInGroup

                        authPrefs.edit()
                            .putBoolean("is_authenticated", true)
                            .putLong("saved_user_id", user.id)
                            .putLong("saved_group_id", joinResult.group.id)
                            .apply()

                        _isAuthenticated.value = true
                        _userMessage.value = joinResult.message
                        setupRealtimeSync(joinResult.group.id)
                        onSuccess(joinResult.group.groupName)
                    }
                    is GroupJoinResult.Pending -> {
                        _userMessage.value = joinResult.message
                        onPending(joinResult.message, joinResult.request)
                    }
                    is GroupJoinResult.Error -> {
                        _authError.value = joinResult.message
                        onError(joinResult.message)
                    }
                }
            } catch (e: Exception) {
                _authLoading.value = false
                val err = e.message ?: "Invalid invitation code. Please check the code and try again."
                _authError.value = err
                onError(err)
            }
        }
    }

    fun verifyInviteCode(
        inviteCode: String,
        onSuccess: (GroupSettings) -> Unit,
        onError: (String) -> Unit
    ) {
        val trimmed = inviteCode.trim().uppercase()
        if (trimmed.isBlank()) {
            val err = "Please enter an invitation code"
            _authError.value = err
            onError(err)
            return
        }

        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            try {
                kotlinx.coroutines.delay(200)
                val group = repository.verifyInviteCode(trimmed)
                _authLoading.value = false
                if (group != null) {
                    onSuccess(group)
                } else {
                    val err = "Invalid Invitation Code"
                    _authError.value = err
                    onError(err)
                }
            } catch (e: Exception) {
                _authLoading.value = false
                val err = e.message ?: "Invalid Invitation Code"
                _authError.value = err
                onError(err)
            }
        }
    }

    fun claimAndJoinGroupByDetails(
        group: GroupSettings,
        name: String,
        contact: String,
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val cleanName = name.trim()
        val cleanContact = contact.trim()

        if (cleanName.isBlank()) {
            val err = "Please enter your name"
            _authError.value = err
            onError(err)
            return
        }
        if (cleanContact.isBlank()) {
            val err = "Please enter your phone number or email ID"
            _authError.value = err
            onError(err)
            return
        }

        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            try {
                val isEmail = cleanContact.contains("@")
                var user: UserAccount? = if (isEmail) {
                    repository.getUserByEmail(cleanContact)
                } else {
                    repository.getUserByPhone(cleanContact)
                }

                if (user == null) {
                    val currentAcc = repository.getUserById(_currentUserId.value)
                    if (currentAcc != null && (
                        currentAcc.email.equals(cleanContact, ignoreCase = true) ||
                        currentAcc.phone.equals(cleanContact, ignoreCase = true) ||
                        currentAcc.fullName.equals(cleanName, ignoreCase = true)
                    )) {
                        user = currentAcc
                    }
                }

                if (user == null) {
                    val newAccount = UserAccount(
                        fullName = cleanName,
                        email = if (isEmail) cleanContact else "member_${System.currentTimeMillis() % 100000}@groupledger.org",
                        phone = if (!isEmail) cleanContact else "",
                        isAccountCompleted = false // Guest joined via invite code until full registration
                    )
                    val newUid = repository.createUserAccount(newAccount)
                    _currentUserId.value = newUid
                    user = newAccount.copy(id = newUid)
                } else {
                    val updated = user.copy(
                        fullName = cleanName.ifBlank { user.fullName },
                        email = if (isEmail) cleanContact else user.email,
                        phone = if (!isEmail) cleanContact else user.phone
                    )
                    repository.updateUserAccount(updated)
                    _currentUserId.value = updated.id
                    user = updated
                }

                val authUid = repository.firebaseService?.currentFirebaseUser?.uid ?: user.id.toString()
                val result = repository.claimAndJoinGroupByDetails(
                    group = group,
                    user = user,
                    inputName = cleanName,
                    inputContact = cleanContact,
                    authUid = authUid
                )

                _authLoading.value = false

                when (result) {
                    is GroupJoinResult.Success -> {
                        _currentGroupId.value = group.id
                        val membership = repository.getMembershipDirect(user.id, group.id)
                        _currentMemberId.value = membership?.memberIdInGroup

                        authPrefs.edit()
                            .putBoolean("is_authenticated", true)
                            .putLong("saved_user_id", user.id)
                            .putLong("saved_group_id", group.id)
                            .apply()

                        _isAuthenticated.value = true
                        _userMessage.value = result.message
                        setupRealtimeSync(group.id)
                        onSuccess(group.groupName)
                    }
                    is GroupJoinResult.AlreadyMember -> {
                        _currentGroupId.value = group.id
                        val membership = repository.getMembershipDirect(user.id, group.id)
                        _currentMemberId.value = membership?.memberIdInGroup

                        authPrefs.edit()
                            .putBoolean("is_authenticated", true)
                            .putLong("saved_user_id", user.id)
                            .putLong("saved_group_id", group.id)
                            .apply()

                        _isAuthenticated.value = true
                        _userMessage.value = result.message
                        setupRealtimeSync(group.id)
                        onSuccess(group.groupName)
                    }
                    is GroupJoinResult.Pending -> {
                        _userMessage.value = result.message
                        onError(result.message)
                    }
                    is GroupJoinResult.Error -> {
                        _authError.value = result.message
                        onError(result.message)
                    }
                }
            } catch (e: Exception) {
                _authLoading.value = false
                val err = e.message ?: "Failed to join group."
                _authError.value = err
                onError(err)
            }
        }
    }

    fun logout() {
        repository.firebaseService?.signOut()
        realtimeSyncClosable?.invoke()
        authPrefs.edit().putBoolean("is_authenticated", false).apply()
        _isAuthenticated.value = false
        _appRole.value = AppRole.REGULAR_USER
        _userMessage.value = "Logged out successfully"
    }

    fun selectMember(id: Long) {
        _selectedMemberId.value = id
    }

    fun selectMonthYear(month: Int, year: Int) {
        _selectedMonth.value = month
        _selectedYear.value = year
    }

    fun prevMonth() {
        if (_selectedMonth.value == 1) {
            _selectedMonth.value = 12
            _selectedYear.value -= 1
        } else {
            _selectedMonth.value -= 1
        }
    }

    fun nextMonth() {
        if (_selectedMonth.value == 12) {
            _selectedMonth.value = 1
            _selectedYear.value += 1
        } else {
            _selectedMonth.value += 1
        }
    }

    fun setSearchQuery(query: String) {
        _memberSearchQuery.value = query
    }

    fun setStatusFilter(filter: String) {
        _statusFilter.value = filter
    }

    fun setSelectedMemberId(id: Long?) {
        _selectedMemberId.value = id
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun showToast(msg: String) {
        _userMessage.value = msg
    }

    // -------------------------------------------------------------
    // Admin Security Actions
    // -------------------------------------------------------------
    fun requestAdminAction(onUnlocked: () -> Unit) {
        val isRoleAdmin = currentUserRole.value == "ADMIN"
        if (_isAdminUnlocked.value || isRoleAdmin) {
            _isAdminUnlocked.value = true
            onUnlocked()
        } else {
            pendingAdminAction = onUnlocked
            _showPinDialog.value = true
        }
    }

    fun dismissPinDialog() {
        _showPinDialog.value = false
        pendingAdminAction = null
    }

    fun verifyPin(pin: String): Boolean {
        val currentPin = groupSettings.value.adminPin
        if (pin == currentPin || (currentPin.isBlank() && pin == "1234")) {
            _isAdminUnlocked.value = true
            _showPinDialog.value = false
            pendingAdminAction?.invoke()
            pendingAdminAction = null
            return true
        }
        return false
    }

    // Current Logged-in / Selected Member Profile Identity (for self-service permission)
    private val _currentMemberId = MutableStateFlow<Long?>(null)
    val currentMemberId: StateFlow<Long?> = _currentMemberId.asStateFlow()

    fun setCurrentMemberId(id: Long?) {
        _currentMemberId.value = id
    }

    fun canEditMember(targetMemberId: Long): Boolean {
        if (_isAdminUnlocked.value || currentUserRole.value == "ADMIN") return true
        val currentId = _currentMemberId.value
        return currentId != null && currentId == targetMemberId
    }

    fun isCurrentMember(targetMemberId: Long): Boolean {
        val currentId = _currentMemberId.value
        return currentId != null && currentId == targetMemberId
    }

    fun lockAdmin() {
        _isAdminUnlocked.value = false
    }

    // -------------------------------------------------------------
    // Member Operations
    // -------------------------------------------------------------
    fun saveMember(
        id: Long = 0L,
        memberCode: String,
        name: String,
        phone: String,
        address: String,
        monthlyContribution: Double,
        photoUri: String = "",
        isActive: Boolean = true,
        notes: String = "",
        onSuccess: () -> Unit
    ) {
        val member = Member(
            id = id,
            groupId = _currentGroupId.value,
            memberCode = memberCode.trim().ifBlank { "M-${System.currentTimeMillis() % 10000}" },
            name = name.trim(),
            phone = phone.trim(),
            address = address.trim(),
            monthlyContribution = monthlyContribution,
            photoUri = photoUri,
            isActive = isActive,
            notes = notes.trim()
        )
        saveMember(member, onSuccess)
    }

    fun saveMember(member: Member, onSuccess: () -> Unit) {
        viewModelScope.launch {
            if (member.name.isBlank()) {
                _userMessage.value = "Member name cannot be empty"
                return@launch
            }

            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            val isSelf = (_currentMemberId.value != null && _currentMemberId.value == member.id)

            val memberWithGroup = member.copy(groupId = _currentGroupId.value)

            if (member.id == 0L) {
                if (!isAdmin) {
                    _userMessage.value = "Permission Denied: Only Admin can add new members"
                    return@launch
                }
                val newId = repository.insertMember(memberWithGroup)
                if (_currentMemberId.value == null) {
                    _currentMemberId.value = newId
                }
                _userMessage.value = "Member added successfully"
                onSuccess()
            } else {
                if (!isAdmin && !isSelf) {
                    _userMessage.value = "Permission Denied: Members can only edit their own profile"
                    return@launch
                }

                if (!isAdmin && isSelf) {
                    val existing = repository.getMemberById(member.id)
                    if (existing != null) {
                        val sanitized = memberWithGroup.copy(
                            memberCode = existing.memberCode,
                            monthlyContribution = existing.monthlyContribution,
                            isActive = existing.isActive,
                            joinDate = existing.joinDate
                        )
                        repository.updateMember(sanitized)
                        _userMessage.value = "Your profile has been updated"
                        onSuccess()
                        return@launch
                    }
                }

                repository.updateMember(memberWithGroup)
                if (_appRole.value.canManageCarousel) {
                    birthdayAutomationService.processBirthdayAutomation(memberWithGroup.groupId, listOf(memberWithGroup))
                }
                _userMessage.value = "Member updated successfully"
                onSuccess()
            }
        }
    }

    fun updateMemberDateOfBirth(memberId: Long, dateOfBirth: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                val existing = repository.getMemberById(memberId)
                if (existing != null) {
                    val updated = existing.copy(dateOfBirth = dateOfBirth.trim())
                    repository.updateMember(updated)
                    if (_appRole.value.canManageCarousel) {
                        birthdayAutomationService.processBirthdayAutomation(updated.groupId, listOf(updated))
                    }
                    _userMessage.value = "Date of Birth updated successfully"
                    onSuccess()
                }
            } catch (e: Exception) {
                _userMessage.value = "Failed to update Date of Birth: ${e.message}"
            }
        }
    }

    fun deleteMember(member: Member, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can delete members"
                return@launch
            }
            repository.deleteMember(member)
            _userMessage.value = "Member deleted successfully"
            onSuccess()
        }
    }

    // -------------------------------------------------------------
    // Payment Submission & Approval Operations
    // -------------------------------------------------------------
    suspend fun resolveCurrentMemberId(): Long? {
        val current = _currentMemberId.value
        if (current != null && current > 0) return current
        val membership = repository.getMembershipDirect(_currentUserId.value, _currentGroupId.value)
        if (membership?.memberIdInGroup != null && membership.memberIdInGroup > 0) {
            _currentMemberId.value = membership.memberIdInGroup
            return membership.memberIdInGroup
        }
        val user = repository.getUserById(_currentUserId.value)
        if (user != null) {
            val members = repository.getAllMembersDirect(_currentGroupId.value)
            val match = members.find {
                (it.linkedUid.isNotBlank() && it.linkedUid == user.id.toString()) ||
                (it.phone.isNotBlank() && it.phone == user.phone) ||
                (user.fullName.isNotBlank() && it.name.equals(user.fullName, ignoreCase = true)) ||
                (user.email.isNotBlank() && it.email.equals(user.email, ignoreCase = true))
            }
            if (match != null) {
                _currentMemberId.value = match.id
                return match.id
            }
        }
        return null
    }

    fun getPaymentFlow(memberId: Long, month: Int, year: Int): Flow<Payment?> {
        return repository.getPaymentFlow(memberId, month, year)
    }

    suspend fun getPaymentDirect(memberId: Long, month: Int, year: Int): Payment? {
        return repository.getPayment(memberId, month, year)
    }

    fun submitPayment(
        memberId: Long,
        month: Int,
        year: Int,
        expectedAmount: Double,
        paidAmount: Double,
        paymentDate: Long,
        paymentMethod: String,
        transactionRef: String,
        notes: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val member = repository.getMemberById(memberId)
            val memberName = member?.name ?: "Member #$memberId"
            val gid = _currentGroupId.value
            val isUserAdmin = _isAdminUnlocked.value || currentUserRole.value.equals("ADMIN", ignoreCase = true)

            // Requirement 1: Regular member can ONLY submit for their own account
            val myMemberId = resolveCurrentMemberId()
            if (!isUserAdmin && (myMemberId == null || myMemberId != memberId)) {
                _userMessage.value = "Access denied: Regular members can only submit payments for their own account."
                return@launch
            }

            // Requirement 2: Duplicate Payment Request Lock & Admin Rejection Reset
            val existingPayment = repository.getPayment(memberId, month, year)
            if (!isUserAdmin && existingPayment != null) {
                if (existingPayment.isPendingApproval) {
                    _userMessage.value = "Payment for ${DateUtils.getMonthName(month)} $year is already pending approval. Duplicate submissions are locked."
                    return@launch
                }
                if (existingPayment.isApproved) {
                    _userMessage.value = "Payment for ${DateUtils.getMonthName(month)} $year has already been approved. Duplicate submissions are locked."
                    return@launch
                }
                // If rejected, re-submission is allowed!
            }

            val payment = Payment(
                groupId = gid,
                memberId = memberId,
                month = month,
                year = year,
                expectedAmount = expectedAmount,
                paidAmount = paidAmount,
                dueAmount = (expectedAmount - paidAmount).coerceAtLeast(0.0),
                paymentDate = paymentDate,
                paymentMethod = paymentMethod,
                transactionReference = transactionRef.trim(),
                notes = notes.trim(),
                status = "PENDING_APPROVAL",
                approvalStatus = "PENDING_APPROVAL",
                submittedAt = System.currentTimeMillis()
            )

            if (isUserAdmin) {
                repository.recordPayment(payment, groupSettings.value.adminName)
                _userMessage.value = "Payment confirmed & recorded: ₹${CurrencyFormatter.formatIndian(paidAmount)}"
            } else {
                repository.submitPaymentForApproval(payment, memberName)
                _userMessage.value = "Payment submitted for Admin Approval. It will reflect in confirmed totals once verified."
            }
            onSuccess()
        }
    }

    fun recordPayment(
        memberId: Long,
        month: Int,
        year: Int,
        expectedAmount: Double,
        paidAmount: Double,
        paymentDate: Long,
        paymentMethod: String,
        transactionRef: String,
        notes: String,
        onSuccess: () -> Unit
    ) {
        submitPayment(
            memberId = memberId,
            month = month,
            year = year,
            expectedAmount = expectedAmount,
            paidAmount = paidAmount,
            paymentDate = paymentDate,
            paymentMethod = paymentMethod,
            transactionRef = transactionRef,
            notes = notes,
            onSuccess = onSuccess
        )
    }

    fun approvePayment(paymentId: Long, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value.equals("ADMIN", ignoreCase = true)
            if (!isAdmin) {
                _userMessage.value = "Access denied: Only the group Admin can approve payments."
                return@launch
            }
            val success = repository.approvePayment(paymentId, groupSettings.value.adminName)
            if (success) {
                _userMessage.value = "Payment verified and approved successfully!"
                onSuccess()
            } else {
                _userMessage.value = "Failed to approve payment."
            }
        }
    }

    fun rejectPayment(paymentId: Long, reason: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value.equals("ADMIN", ignoreCase = true)
            if (!isAdmin) {
                _userMessage.value = "Access denied: Only the group Admin can reject payments."
                return@launch
            }
            val success = repository.rejectPayment(paymentId, groupSettings.value.adminName, reason)
            if (success) {
                _userMessage.value = "Payment has been rejected."
                onSuccess()
            } else {
                _userMessage.value = "Failed to reject payment."
            }
        }
    }

    fun quickMarkPaid(
        memberId: Long,
        month: Int,
        year: Int,
        amount: Double,
        paymentMethod: String = "Cash",
        reference: String = "",
        notes: String = ""
    ) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                requestAdminAction {
                    quickMarkPaid(memberId, month, year, amount, paymentMethod, reference, notes)
                }
                return@launch
            }
            repository.quickMarkPaid(
                groupId = _currentGroupId.value,
                memberId = memberId,
                month = month,
                year = year,
                amount = amount,
                paymentMethod = paymentMethod,
                adminName = groupSettings.value.adminName
            )
            _userMessage.value = "Marked as Paid: ₹${CurrencyFormatter.formatIndian(amount)}"
        }
    }

    // -------------------------------------------------------------
    // Settings & Configuration
    // -------------------------------------------------------------
    fun updateSettings(settings: GroupSettings, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Admin authentication required"
                return@launch
            }
            repository.updateSettings(settings.copy(id = _currentGroupId.value))
            _userMessage.value = "Settings updated successfully"
            onSuccess()
        }
    }

    fun updateGroupSettings(settings: GroupSettings, onSuccess: () -> Unit = {}) {
        updateSettings(settings, onSuccess)
    }

    // Module Configuration & Management
    fun saveModulesConfig(modules: List<HomeModuleConfig>, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can modify Home modules"
                return@launch
            }
            val json = HomeModuleConfig.serializeModules(modules)
            val current = groupSettings.value
            val updated = current.copy(modulesConfigJson = json)
            repository.updateSettings(updated)
            _userMessage.value = "Home module settings updated"
            onSuccess()
        }
    }

    fun toggleModule(key: String, isEnabled: Boolean) {
        val currentModules = homeModules.value.toMutableList()
        val index = currentModules.indexOfFirst { it.key == key }
        if (index != -1) {
            currentModules[index] = currentModules[index].copy(isEnabled = isEnabled)
            saveModulesConfig(currentModules)
        }
    }

    fun renameModule(key: String, newName: String) {
        val currentModules = homeModules.value.toMutableList()
        val index = currentModules.indexOfFirst { it.key == key }
        if (index != -1) {
            currentModules[index] = currentModules[index].copy(customName = newName.trim())
            saveModulesConfig(currentModules)
        }
    }

    fun moveModule(key: String, direction: Int) {
        val currentModules = homeModules.value.sortedBy { it.orderIndex }.toMutableList()
        val index = currentModules.indexOfFirst { it.key == key }
        if (index == -1) return
        val targetIndex = index + direction
        if (targetIndex in 0 until currentModules.size) {
            val item = currentModules.removeAt(index)
            currentModules.add(targetIndex, item)
            // Re-assign indices
            val reordered = currentModules.mapIndexed { idx, mod -> mod.copy(orderIndex = idx) }
            saveModulesConfig(reordered)
        }
    }

    fun addCustomModule(name: String, description: String, iconName: String, onSuccess: () -> Unit = {}) {
        if (name.isBlank()) {
            _userMessage.value = "Module name cannot be empty"
            return
        }
        val currentModules = homeModules.value.sortedBy { it.orderIndex }.toMutableList()
        val newKey = "custom_" + System.currentTimeMillis()
        val maxOrder = currentModules.maxOfOrNull { it.orderIndex } ?: 0
        val newModule = HomeModuleConfig(
            key = newKey,
            defaultName = name.trim(),
            customName = name.trim(),
            description = description.trim(),
            iconName = iconName.ifBlank { "payments" },
            isEnabled = true,
            orderIndex = maxOrder + 1,
            isCustom = true
        )
        currentModules.add(newModule)
        saveModulesConfig(currentModules) {
            _userMessage.value = "Custom module '$name' added to Home Page"
            onSuccess()
        }
    }

    fun deleteCustomModule(key: String, onSuccess: () -> Unit = {}) {
        val currentModules = homeModules.value.toMutableList()
        val item = currentModules.find { it.key == key }
        if (item != null && item.isCustom) {
            currentModules.removeAll { it.key == key }
            val reindexed = currentModules.mapIndexed { idx, mod -> mod.copy(orderIndex = idx) }
            saveModulesConfig(reindexed) {
                _userMessage.value = "Custom module removed"
                onSuccess()
            }
        }
    }

    fun resetModulesToDefault(onSuccess: () -> Unit = {}) {
        val defaults = HomeModuleConfig.getDefaultModules()
        saveModulesConfig(defaults) {
            _userMessage.value = "Home modules reset to standard order & layout"
            onSuccess()
        }
    }

    fun getModuleDisplayName(key: String, fallback: String): String {
        val mod = homeModules.value.find { it.key == key }
        return mod?.getDisplayName() ?: fallback
    }

    fun setThemeMode(mode: String) {
        viewModelScope.launch {
            val current = groupSettings.value
            val updated = current.copy(themeMode = mode)
            repository.updateSettings(updated)
            _userMessage.value = "Theme updated: $mode"
        }
    }

    fun resetToDemoData(onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            _userMessage.value = "Data reset to default"
            onSuccess()
        }
    }

    // -------------------------------------------------------------
    // Notices Operations
    // -------------------------------------------------------------
    fun postNotice(
        title: String,
        content: String,
        category: String,
        author: String = "Admin",
        isPinned: Boolean = false,
        isPollEnabled: Boolean = false,
        pollOptions: String = "In Favor / Yes,Against / No",
        pollExpiryDate: Long = 0L,
        pushAlert: Boolean = false,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            if (title.isBlank() || content.isBlank()) {
                _userMessage.value = "Title and Details are required"
                return@launch
            }
            val notice = SocietyNotice(
                groupId = _currentGroupId.value,
                title = title.trim(),
                content = content.trim(),
                category = category,
                author = if (author.isBlank()) "Admin" else author.trim(),
                isPinned = isPinned,
                isPollEnabled = isPollEnabled,
                pollOptions = pollOptions,
                pollExpiryDate = pollExpiryDate,
                pollVotesJson = "{}"
            )
            val noticeId = repository.addNotice(notice)
            if (pushAlert) {
                repository.insertNotification(
                    NotificationItem(
                        groupId = _currentGroupId.value,
                        title = "📢 Notice: ${title.trim()}",
                        message = content.trim().take(100),
                        type = "ANNOUNCEMENT",
                        relatedId = noticeId,
                        actionRoute = "inbox"
                    )
                )
            }
            _userMessage.value = "Notice published successfully"
            onSuccess()
        }
    }

    fun voteOnNotice(notice: SocietyNotice, option: String) {
        viewModelScope.launch {
            val memberId = _currentMemberId.value ?: currentUser.value?.id ?: 1L
            repository.voteOnNoticePoll(notice.id, memberId, option)
            _userMessage.value = "Vote recorded: $option"
        }
    }

    fun togglePinNotice(notice: SocietyNotice) {
        viewModelScope.launch {
            repository.updateNotice(notice.copy(isPinned = !notice.isPinned))
            _userMessage.value = if (!notice.isPinned) "Notice pinned to top" else "Notice unpinned"
        }
    }

    fun deleteNotice(notice: SocietyNotice) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can delete notices"
                return@launch
            }
            repository.deleteNotice(notice)
            _userMessage.value = "Notice removed"
        }
    }

    fun broadcastNotice(context: Context, notice: SocietyNotice) {
        val settings = groupSettings.value
        val text = ReminderHelper.generateNoticeBroadcastText(
            groupName = settings.groupName,
            title = notice.title,
            content = notice.content,
            author = notice.author,
            adminPhone = settings.adminPhone
        )
        ReminderHelper.shareText(context, text, "Broadcast Notice")
    }

    // -------------------------------------------------------------
    // Loans & 70% Voting Actions
    // -------------------------------------------------------------
    fun submitLoanRequest(
        requesterMemberId: Long,
        requesterName: String,
        requesterPhone: String,
        amount: Double,
        purpose: String,
        reason: String,
        duration: Int,
        durationUnit: String,
        note: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            if (amount <= 0) {
                _userMessage.value = "Please enter a valid loan amount"
                return@launch
            }
            if (reason.isBlank()) {
                _userMessage.value = "Please specify reason for loan request"
                return@launch
            }
            val durationMillis = if (durationUnit == "Days") duration * 86400000L else duration * 30L * 86400000L
            val loan = LoanRequest(
                groupId = _currentGroupId.value,
                requesterMemberId = requesterMemberId,
                requesterName = requesterName,
                requesterPhone = requesterPhone,
                requestedAmount = amount,
                purpose = purpose,
                reason = reason,
                duration = duration,
                durationUnit = durationUnit,
                expectedRepaymentDate = System.currentTimeMillis() + durationMillis,
                note = note,
                votingDeadline = System.currentTimeMillis() + (48L * 3600000L),
                status = "VOTING",
                remainingAmount = amount
            )
            repository.submitLoanRequest(loan)
            _userMessage.value = "Loan request submitted for group 70% voting approval"
            onSuccess()
        }
    }

    fun castLoanVote(loanId: Long, memberId: Long, memberName: String, vote: String) {
        viewModelScope.launch {
            val success = repository.voteOnLoan(loanId, memberId, memberName, vote)
            if (success) {
                _userMessage.value = "Vote recorded ($vote)"
            } else {
                _userMessage.value = "Unable to record vote (Check voting rules / deadline)"
            }
        }
    }

    fun disburseLoan(loanId: Long, adminName: String) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can disburse loans"
                return@launch
            }
            val success = repository.disburseLoan(loanId, adminName)
            if (success) {
                _userMessage.value = "Loan disbursed successfully. Funds deducted from group cash balance."
            } else {
                _userMessage.value = "Disbursement failed. Ensure loan is approved."
            }
        }
    }

    fun recordLoanRepayment(loanId: Long, amount: Double, paymentMethod: String, notes: String) {
        viewModelScope.launch {
            if (amount <= 0) {
                _userMessage.value = "Please enter a valid repayment amount"
                return@launch
            }
            val success = repository.recordLoanRepayment(loanId, amount, paymentMethod, notes, groupSettings.value.adminName)
            if (success) {
                _userMessage.value = "Loan repayment of ₹${amount.toInt()} recorded. Balance updated."
            } else {
                _userMessage.value = "Failed to record loan repayment"
            }
        }
    }

    // -------------------------------------------------------------
    // Investments Actions (Including Admin Soft Delete with Confirmation)
    // -------------------------------------------------------------
    fun addInvestment(
        type: String,
        institution: String,
        name: String,
        principal: Double,
        currentValue: Double,
        notes: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can record investments"
                return@launch
            }
            if (principal <= 0 || name.isBlank()) {
                _userMessage.value = "Please provide name and valid principal amount"
                return@launch
            }
            val inv = InvestmentRecord(
                groupId = _currentGroupId.value,
                type = type,
                institution = institution.trim(),
                name = name.trim(),
                principalAmount = principal,
                currentValue = if (currentValue > 0) currentValue else principal,
                notes = notes.trim()
            )
            repository.addInvestment(inv)
            _userMessage.value = "Investment recorded: ₹${CurrencyFormatter.formatIndian(principal)}"
            onSuccess()
        }
    }

    fun updateInvestmentValue(investment: InvestmentRecord, newValue: Double) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can update investments"
                return@launch
            }
            repository.updateInvestment(investment.copy(currentValue = newValue))
            _userMessage.value = "Investment valuation updated to ₹${CurrencyFormatter.formatIndian(newValue)}"
        }
    }

    fun deleteInvestment(investmentId: Long, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can delete investments"
                return@launch
            }
            val success = repository.deleteInvestment(investmentId, groupSettings.value.adminName)
            if (success) {
                _userMessage.value = "Investment archived and removed from active portfolio."
                onSuccess()
            } else {
                _userMessage.value = "Failed to delete investment."
            }
        }
    }

    // -------------------------------------------------------------
    // Group Feedback (Suggestions, Proposals, Complaints)
    // -------------------------------------------------------------
    fun submitFeedback(
        type: String,
        memberId: Long,
        memberName: String,
        isAnonymous: Boolean,
        subject: String,
        description: String,
        requiresVoting: Boolean,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            if (subject.isBlank() || description.isBlank()) {
                _userMessage.value = "Subject and Description are required"
                return@launch
            }
            val fb = GroupFeedback(
                groupId = _currentGroupId.value,
                type = type,
                memberId = memberId,
                memberName = if (isAnonymous) "Anonymous Member" else memberName,
                isAnonymous = isAnonymous,
                subject = subject.trim(),
                description = description.trim(),
                requiresVoting = requiresVoting,
                votingThresholdPercent = 70
            )
            repository.submitFeedback(fb)
            _userMessage.value = "$type submitted successfully"
            onSuccess()
        }
    }

    fun submitFeedback(
        type: String,
        subject: String,
        description: String,
        requiresVoting: Boolean = false,
        isAnonymous: Boolean = false,
        onSuccess: () -> Unit = {}
    ) {
        val memberId = _currentMemberId.value ?: currentUser.value?.id ?: 1L
        val memberName = currentUser.value?.fullName ?: "Member"
        submitFeedback(
            type = type,
            memberId = memberId,
            memberName = memberName,
            isAnonymous = isAnonymous,
            subject = subject,
            description = description,
            requiresVoting = requiresVoting,
            onSuccess = onSuccess
        )
    }

    fun voteOnProposal(feedbackId: Long, memberId: Long, memberName: String, vote: String) {
        viewModelScope.launch {
            repository.voteOnProposal(feedbackId, memberId, memberName, vote)
            _userMessage.value = "Vote recorded ($vote)"
        }
    }

    fun toggleSupportCommunityPost(feedbackId: Long) {
        viewModelScope.launch {
            val memberId = _currentMemberId.value ?: currentUser.value?.id ?: 1L
            val memberName = currentUser.value?.fullName ?: "Member"
            val added = repository.toggleSupportFeedback(feedbackId, memberId, memberName)
            _userMessage.value = if (added) "Supported 👍" else "Support removed"
        }
    }

    // -------------------------------------------------------------
    // Notifications & Chat Actions
    // -------------------------------------------------------------
    fun markNotificationRead(id: Long) {
        viewModelScope.launch { repository.markNotificationRead(id) }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsRead(_currentGroupId.value)
            _userMessage.value = "All notifications marked as read"
        }
    }

    fun sendChatMessage(senderId: Long, senderName: String, senderRole: String, message: String, isAnnouncement: Boolean) {
        viewModelScope.launch {
            if (message.isBlank()) return@launch
            val chat = GroupChatMessage(
                groupId = _currentGroupId.value,
                senderId = senderId,
                senderName = senderName,
                senderRole = senderRole,
                message = message.trim(),
                isAnnouncement = isAnnouncement
            )
            repository.sendChatMessage(chat)
        }
    }

    // -------------------------------------------------------------
    // Reminders & Communication
    // -------------------------------------------------------------
    fun sendReminder(context: Context, member: Member, dueAmount: Double, month: Int, year: Int) {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(month)
        val text = ReminderHelper.generateReminderText(
            member = member,
            groupName = settings.groupName,
            monthName = monthName,
            year = year,
            dueAmount = dueAmount,
            currencySymbol = settings.currencySymbol,
            adminName = settings.adminName,
            adminPhone = settings.adminPhone
        )
        if (member.phone.isNotBlank()) {
            ReminderHelper.sendWhatsAppReminder(context, member.phone, text)
        } else {
            ReminderHelper.shareText(context, text, "Send Reminder")
        }
    }

    fun sendReminder(context: Context, member: Member, dueAmount: Double, channelOrMonth: String = "WHATSAPP") {
        if (channelOrMonth.equals("WHATSAPP", ignoreCase = true) || channelOrMonth.equals("SMS", ignoreCase = true) || channelOrMonth.equals("SHARE", ignoreCase = true)) {
            val settings = groupSettings.value
            val monthName = DateUtils.getMonthName(_selectedMonth.value)
            val year = _selectedYear.value
            val text = ReminderHelper.generateReminderText(
                member = member,
                groupName = settings.groupName,
                monthName = monthName,
                year = year,
                dueAmount = dueAmount,
                currencySymbol = settings.currencySymbol,
                adminName = settings.adminName,
                adminPhone = settings.adminPhone
            )
            when (channelOrMonth.uppercase()) {
                "WHATSAPP" -> {
                    if (member.phone.isNotBlank()) {
                        ReminderHelper.sendWhatsAppReminder(context, member.phone, text)
                    } else {
                        ReminderHelper.shareText(context, text, "Send Reminder")
                    }
                }
                "SMS" -> {
                    ReminderHelper.sendSmsReminder(context, member.phone, text)
                }
                else -> {
                    ReminderHelper.shareText(context, text, "Send Reminder")
                }
            }
        } else {
            val monthInt = DateUtils.parseMonthName(channelOrMonth)
            sendReminder(context, member, dueAmount, monthInt, _selectedYear.value)
        }
    }

    fun sendReminder(context: Context, member: Member, dueAmount: Double, monthName: String, year: Int) {
        val monthInt = DateUtils.parseMonthName(monthName)
        sendReminder(context, member, dueAmount, monthInt, year)
    }

    fun sendCustomMemberMessage(context: Context, member: Member, message: String) {
        if (member.phone.isNotBlank()) {
            ReminderHelper.sendWhatsAppReminder(context, member.phone, message)
        } else {
            ReminderHelper.shareText(context, message, "Send Message to ${member.name}")
        }
    }

    // -------------------------------------------------------------
    // Report Exporting (PDF / CSV)
    // -------------------------------------------------------------
    fun exportMonthlyReportPdf(context: Context, month: Int = _selectedMonth.value, year: Int = _selectedYear.value) {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(month)
        val list = membersWithMonthlyStatus.value
        val summary = currentMonthSummary.value

        val headers = listOf("Code", "Name", "Expected", "Paid", "Due", "Status")
        val rows = list.map { item ->
            listOf(
                item.member.memberCode,
                item.member.name,
                "₹${item.effectiveExpectedAmount.toInt()}",
                "₹${item.paidAmount.toInt()}",
                "₹${item.dueAmount.toInt()}",
                item.status
            )
        }
        val summaryMap = mapOf(
            "Total Expected" to "₹${summary.totalExpected.toInt()}",
            "Total Collected" to "₹${summary.totalCollected.toInt()}",
            "Total Due" to "₹${summary.totalDue.toInt()}",
            "Collection" to "${summary.collectionPercentage.toInt()}%"
        )

        val file = ReportExporter.generatePdfReport(
            context = context,
            settings = settings,
            reportTitle = "Monthly Collection Report",
            subtitle = "$monthName $year",
            headers = headers,
            rows = rows,
            summaryMap = summaryMap
        )
        if (file != null) {
            ReportExporter.shareFile(context, file, "application/pdf", "Share Monthly Report")
        } else {
            Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportPendingDuesPdf(context: Context, month: Int = _selectedMonth.value, year: Int = _selectedYear.value) {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(month)
        val list = pendingDuesList.value
        val totalDue = list.sumOf { it.dueAmount }

        val headers = listOf("Code", "Name", "Phone", "Expected", "Paid", "Due")
        val rows = list.map { item ->
            listOf(
                item.member.memberCode,
                item.member.name,
                item.member.phone,
                "₹${item.effectiveExpectedAmount.toInt()}",
                "₹${item.paidAmount.toInt()}",
                "₹${item.dueAmount.toInt()}"
            )
        }
        val summaryMap = mapOf(
            "Pending Members" to "${list.size}",
            "Total Outstanding" to "₹${totalDue.toInt()}"
        )

        val file = ReportExporter.generatePdfReport(
            context = context,
            settings = settings,
            reportTitle = "Pending Dues Report",
            subtitle = "$monthName $year",
            headers = headers,
            rows = rows,
            summaryMap = summaryMap
        )
        if (file != null) {
            ReportExporter.shareFile(context, file, "application/pdf", "Share Pending Dues")
        } else {
            Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportMemberLedgerPdf(context: Context, profile: MemberFinancialProfile) {
        val settings = groupSettings.value
        val headers = listOf("Month/Year", "Expected", "Paid", "Due", "Status", "Date")
        val rows = profile.paymentHistory.map { item ->
            listOf(
                "${item.monthName} ${item.year}",
                "₹${item.expectedAmount.toInt()}",
                "₹${item.paidAmount.toInt()}",
                "₹${item.dueAmount.toInt()}",
                item.status,
                if (item.paymentDate != null && item.paymentDate > 0) DateUtils.formatDisplayDate(item.paymentDate) else "-"
            )
        }
        val summaryMap = mapOf(
            "Member" to profile.member.name,
            "Total Paid" to "₹${profile.totalPaidAllTime.toInt()}",
            "Total Due" to "₹${profile.totalDueAllTime.toInt()}"
        )

        val file = ReportExporter.generatePdfReport(
            context = context,
            settings = settings,
            reportTitle = "Member Statement",
            subtitle = "${profile.member.name} (${profile.member.memberCode})",
            headers = headers,
            rows = rows,
            summaryMap = summaryMap
        )
        if (file != null) {
            ReportExporter.shareFile(context, file, "application/pdf", "Share Member Statement")
        } else {
            Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportMemberLedgerPdf(context: Context, memberId: Long) {
        val profile = memberProfile.value ?: return
        exportMemberLedgerPdf(context, profile)
    }

    fun exportMonthlyReportCsv(context: Context, month: Int = _selectedMonth.value, year: Int = _selectedYear.value) {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(month)
        val file = ReportExporter.exportMonthlyCsv(context, settings, monthName, year, membersWithMonthlyStatus.value)
        if (file != null) {
            ReportExporter.shareFile(context, file, "text/csv", "Share Monthly CSV")
        } else {
            Toast.makeText(context, "Failed to export CSV", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportPendingDuesCsv(context: Context, month: Int = _selectedMonth.value, year: Int = _selectedYear.value) {
        val settings = groupSettings.value
        val monthName = DateUtils.getMonthName(month)
        val file = ReportExporter.exportPendingDuesCsv(context, settings, monthName, year, pendingDuesList.value)
        if (file != null) {
            ReportExporter.shareFile(context, file, "text/csv", "Share Pending Dues CSV")
        } else {
            Toast.makeText(context, "Failed to export CSV", Toast.LENGTH_SHORT).show()
        }
    }

    // -------------------------------------------------------------
    // Backup & Restore
    // -------------------------------------------------------------
    fun exportBackupJson(context: Context) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can export system backup"
                return@launch
            }
            try {
                val jsonString = repository.exportDataAsJson(_currentGroupId.value)
                val file = File(context.cacheDir, "GroupLedger_Backup_${_currentGroupId.value}_${System.currentTimeMillis()}.json")
                file.writeText(jsonString)
                ReportExporter.shareFile(context, file, "application/json", "Share Backup File")
            } catch (e: Exception) {
                _userMessage.value = "Backup export failed: ${e.message}"
            }
        }
    }

    fun restoreBackupJson(context: Context, uri: Uri, onSuccess: (Boolean) -> Unit) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can restore system backup"
                return@launch
            }
            try {
                val content = context.contentResolver.openInputStream(uri)?.use { stream ->
                    stream.bufferedReader().readText()
                } ?: ""
                val success = repository.restoreDataFromJson(_currentGroupId.value, content)
                if (success) {
                    _userMessage.value = "Data restored successfully!"
                } else {
                    _userMessage.value = "Failed to restore data. Invalid file format."
                }
                onSuccess(success)
            } catch (e: Exception) {
                _userMessage.value = "Restore error: ${e.message}"
                onSuccess(false)
            }
        }
    }

    fun restoreBackupJson(jsonString: String, onSuccess: (Boolean) -> Unit) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value == "ADMIN"
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can restore system backup"
                return@launch
            }
            try {
                val success = repository.restoreDataFromJson(_currentGroupId.value, jsonString)
                if (success) {
                    _userMessage.value = "Data restored successfully!"
                } else {
                    _userMessage.value = "Failed to restore data. Invalid file format."
                }
                onSuccess(success)
            } catch (e: Exception) {
                _userMessage.value = "Restore error: ${e.message}"
                onSuccess(false)
            }
        }
    }

    // -------------------------------------------------------------
    // Batch Collection & CSV Import Operations
    // -------------------------------------------------------------
    fun recordBatchPayments(payments: List<Payment>, onSuccess: (Int) -> Unit) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value.equals("ADMIN", ignoreCase = true)
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can record batch collections."
                return@launch
            }
            try {
                val count = repository.recordBatchPayments(payments, groupSettings.value.adminName)
                _userMessage.value = "Successfully recorded batch payments for $count member(s)!"
                onSuccess(count)
            } catch (e: Exception) {
                _userMessage.value = "Batch collection error: ${e.message}"
            }
        }
    }

    fun importCsvRecords(records: List<CsvImportRecord>, onResult: (CsvImportResult) -> Unit) {
        viewModelScope.launch {
            val isAdmin = _isAdminUnlocked.value || currentUserRole.value.equals("ADMIN", ignoreCase = true)
            if (!isAdmin) {
                _userMessage.value = "Permission Denied: Only Admin can import data."
                return@launch
            }
            try {
                val result = repository.importCsvRecords(_currentGroupId.value, records, groupSettings.value.adminName)
                _userMessage.value = "CSV Import Complete: ${result.paymentsRecorded} payments recorded, ${result.membersCreated} new members added."
                onResult(result)
            } catch (e: Exception) {
                _userMessage.value = "CSV import failed: ${e.message}"
                onResult(CsvImportResult(records.size, 0, 0, listOf(e.message ?: "Unknown import error")))
            }
        }
    }

    fun shareSampleCsv(context: Context) {
        try {
            val currentYear = Calendar.getInstance().get(Calendar.YEAR)
            val currentMonth = Calendar.getInstance().get(Calendar.MONTH) + 1
            val sampleContent = buildString {
                append("MemberName,Phone,Month,Year,Amount,Status\n")
                append("Amit Sharma,9876543210,$currentMonth,$currentYear,500,PAID\n")
                append("Rahul Verma,9876543211,$currentMonth,$currentYear,500,PAID\n")
                append("Priya Patel,9876543212,$currentMonth,$currentYear,250,PARTIAL\n")
                append("Vikram Singh,9876543213,$currentMonth,$currentYear,0,UNPAID\n")
            }
            val file = File(context.cacheDir, "sample_group_dues_import.csv")
            file.writeText(sampleContent)
            ReportExporter.shareFile(context, file, "text/csv", "Share Sample Import CSV")
        } catch (e: Exception) {
            _userMessage.value = "Failed to create sample CSV: ${e.message}"
        }
    }

    companion object {
        fun provideFactory(application: Application): ViewModelProvider.Factory {
            val database = AppDatabase.getDatabase(application)
            val firebaseService = FirebaseService(application)
            val repository = SocietyRepository(
                userAccountDao = database.userAccountDao(),
                groupMembershipDao = database.groupMembershipDao(),
                memberDao = database.memberDao(),
                paymentDao = database.paymentDao(),
                groupSettingsDao = database.groupSettingsDao(),
                noticeDao = database.noticeDao(),
                loanDao = database.loanDao(),
                investmentDao = database.investmentDao(),
                feedbackDao = database.feedbackDao(),
                notificationDao = database.notificationDao(),
                transactionDao = database.transactionDao(),
                auditLogDao = database.auditLogDao(),
                chatMessageDao = database.chatMessageDao(),
                preAuthorizedMemberDao = database.preAuthorizedMemberDao(),
                groupJoinRequestDao = database.groupJoinRequestDao(),
                firebaseService = firebaseService
            )
            return SocietyViewModelFactory(application, repository)
        }
    }
}

class SocietyViewModelFactory(
    private val application: Application,
    private val repository: SocietyRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SocietyViewModel::class.java)) {
            return SocietyViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
