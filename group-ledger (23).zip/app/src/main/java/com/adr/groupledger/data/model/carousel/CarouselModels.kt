package com.adr.groupledger.data.model.carousel

/**
 * Supported media types for carousel items.
 */
enum class MediaType {
    IMAGE,
    GIF,
    VIDEO
}

/**
 * Storage providers supported by the media storage abstraction.
 */
enum class StorageProviderType {
    NONE,
    FIREBASE_STORAGE,
    CLOUDINARY,
    LOCAL_ASSET
}

/**
 * Represents a stored or referenceable media asset (image, GIF, etc.).
 * Binary content is never stored in Firestore; only this metadata and a direct URL.
 */
data class MediaResource(
    val mediaId: String = "",
    val mediaType: MediaType = MediaType.IMAGE,
    val provider: StorageProviderType = StorageProviderType.NONE,
    val logicalPath: String = "",          // e.g. "carousel/festivals/diwali_banner.jpg"
    val publicUrl: String = "",            // Direct CDN or download URL for Coil image loading
    val fileName: String = "",
    val contentType: String = "image/jpeg",
    val fileSizeBytes: Long = 0L,
    val width: Int = 0,
    val height: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    /**
     * Converts media metadata to a Firestore-compatible map.
     * Binary data is strictly excluded.
     */
    fun toFirestoreMap(): Map<String, Any?> = mapOf(
        "mediaId" to mediaId,
        "mediaType" to mediaType.name,
        "provider" to provider.name,
        "logicalPath" to logicalPath,
        "publicUrl" to publicUrl,
        "fileName" to fileName,
        "contentType" to contentType,
        "fileSizeBytes" to fileSizeBytes,
        "width" to width,
        "height" to height,
        "createdAt" to createdAt,
        "updatedAt" to updatedAt
    )

    companion object {
        /**
         * Safely reconstructs [MediaResource] from Firestore document map.
         */
        fun fromFirestoreMap(map: Map<String, Any?>?): MediaResource? {
            if (map == null) return null
            return MediaResource(
                mediaId = map["mediaId"] as? String ?: "",
                mediaType = try {
                    MediaType.valueOf(map["mediaType"] as? String ?: MediaType.IMAGE.name)
                } catch (e: Exception) {
                    MediaType.IMAGE
                },
                provider = try {
                    StorageProviderType.valueOf(map["provider"] as? String ?: StorageProviderType.NONE.name)
                } catch (e: Exception) {
                    StorageProviderType.NONE
                },
                logicalPath = map["logicalPath"] as? String ?: "",
                publicUrl = map["publicUrl"] as? String ?: "",
                fileName = map["fileName"] as? String ?: "",
                contentType = map["contentType"] as? String ?: "image/jpeg",
                fileSizeBytes = (map["fileSizeBytes"] as? Number)?.toLong() ?: 0L,
                width = (map["width"] as? Number)?.toInt() ?: 0,
                height = (map["height"] as? Number)?.toInt() ?: 0,
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }
    }
}

/**
 * Functional purpose of a carousel slide.
 */
enum class CarouselContentType {
    CELEBRATION,
    FESTIVAL,
    BIRTHDAY,
    ANNOUNCEMENT,
    PROMOTION,
    OFFER,
    OTHER
}

/**
 * Call-to-action behaviors supported when tapping on a carousel item or CTA button.
 */
enum class CarouselActionType {
    NONE,
    INTERNAL_SCREEN,   // e.g. "record_payment", "dues", "members"
    INTERNAL_ROUTE,    // Deep link or parameterized navigation route
    EXTERNAL_URL       // External browser intent
}

/**
 * Constant representing global, application-wide carousel content visible across all groups.
 * In the Group Ledger architecture, groupId = 0L indicates global platform content,
 * while groupId > 0L optionally represents group-specific content.
 */
const val GLOBAL_GROUP_ID: Long = 0L

/**
 * Backend-driven data model for a carousel item.
 * Designed to be persisted directly in Firestore as the source of truth.
 */
data class CarouselItem(
    val id: String = "",
    val groupId: Long = GLOBAL_GROUP_ID,                              // 0L = Global app-level content; >0L = group-scoped
    val contentType: CarouselContentType = CarouselContentType.ANNOUNCEMENT,
    val title: String = "",
    val message: String = "",
    val mediaResource: MediaResource? = null,
    val startAt: Long = 0L,                                           // Unix timestamp (0 = active immediately)
    val endAt: Long = 0L,                                             // Unix timestamp (0 = no expiration)
    val isActive: Boolean = true,
    val priority: Int = 0,                                            // Higher priority items display first
    val slideDurationSeconds: Int = 5,                                // Custom duration per slide (default: 5s)
    val actionType: CarouselActionType = CarouselActionType.NONE,
    val actionTarget: String = "",                                    // Route name, URL, or screen identifier
    val actionLabel: String = "",                                     // Button text, e.g. "Join Meeting", "Pay Dues"
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val createdBy: String = "Admin"
) {
    /**
     * Indicates whether this slide is global application-wide content rather than scoped to a specific group.
     */
    val isGlobalContent: Boolean get() = groupId == GLOBAL_GROUP_ID

    /**
     * Determines whether the item is valid for display based on active status and schedule bounds.
     */
    fun isCurrentlyActive(currentTime: Long = System.currentTimeMillis()): Boolean {
        if (!isActive) return false
        if (startAt > 0L && currentTime < startAt) return false
        if (endAt > 0L && currentTime > endAt) return false
        return true
    }

    /**
     * Returns true if the media is an animated GIF, signaling the UI pager to pause automatic sliding.
     */
    val isAnimatedMedia: Boolean
        get() = mediaResource?.mediaType == MediaType.GIF

    /**
     * Serializes this [CarouselItem] into a Firestore-compatible document map.
     */
    fun toFirestoreMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "groupId" to groupId,
        "contentType" to contentType.name,
        "title" to title,
        "message" to message,
        "mediaResource" to mediaResource?.toFirestoreMap(),
        "startAt" to startAt,
        "endAt" to endAt,
        "isActive" to isActive,
        "priority" to priority,
        "slideDurationSeconds" to slideDurationSeconds,
        "actionType" to actionType.name,
        "actionTarget" to actionTarget,
        "actionLabel" to actionLabel,
        "createdAt" to createdAt,
        "updatedAt" to updatedAt,
        "createdBy" to createdBy
    )

    companion object {
        /**
         * Safely deserializes a Firestore document snapshot map into a strongly-typed [CarouselItem].
         */
        @Suppress("UNCHECKED_CAST")
        fun fromFirestoreMap(docId: String, map: Map<String, Any?>): CarouselItem {
            val mediaMap = map["mediaResource"] as? Map<String, Any?>
            return CarouselItem(
                id = docId.ifBlank { map["id"] as? String ?: "" },
                groupId = (map["groupId"] as? Number)?.toLong() ?: GLOBAL_GROUP_ID,
                contentType = try {
                    CarouselContentType.valueOf(map["contentType"] as? String ?: CarouselContentType.ANNOUNCEMENT.name)
                } catch (e: Exception) {
                    CarouselContentType.ANNOUNCEMENT
                },
                title = map["title"] as? String ?: "",
                message = map["message"] as? String ?: "",
                mediaResource = MediaResource.fromFirestoreMap(mediaMap),
                startAt = (map["startAt"] as? Number)?.toLong() ?: 0L,
                endAt = (map["endAt"] as? Number)?.toLong() ?: 0L,
                isActive = map["isActive"] as? Boolean ?: true,
                priority = (map["priority"] as? Number)?.toInt() ?: 0,
                slideDurationSeconds = (map["slideDurationSeconds"] as? Number)?.toInt() ?: 5,
                actionType = try {
                    CarouselActionType.valueOf(map["actionType"] as? String ?: CarouselActionType.NONE.name)
                } catch (e: Exception) {
                    CarouselActionType.NONE
                },
                actionTarget = map["actionTarget"] as? String ?: "",
                actionLabel = map["actionLabel"] as? String ?: "",
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                createdBy = map["createdBy"] as? String ?: "Admin"
            )
        }
    }
}
