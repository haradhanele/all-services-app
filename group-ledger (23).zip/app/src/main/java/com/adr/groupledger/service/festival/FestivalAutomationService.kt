package com.adr.groupledger.service.festival

import android.util.Log
import com.adr.groupledger.data.model.carousel.CarouselContentType
import com.adr.groupledger.data.model.carousel.CarouselItem
import com.adr.groupledger.data.model.carousel.GLOBAL_GROUP_ID
import com.adr.groupledger.data.model.festival.FestivalDefinition
import com.adr.groupledger.data.repository.carousel.CarouselRepository
import com.adr.groupledger.data.repository.carousel.FirestoreCarouselRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.TimeZone

/**
 * Service responsible for deterministic, idempotent festival announcement automation.
 *
 * Guarantees:
 * 1. Idempotency: Deterministic IDs (`FESTIVAL_<festivalId>_<year>` or `FESTIVAL_<groupId>_<festivalId>_<year>`)
 *    prevent duplicate documents on repeated runs.
 * 2. Scope & Global Preservation: Global festivals use `GLOBAL_GROUP_ID` (0L) to serve all groups
 *    without redundant document proliferation. Group-scoped overrides are also supported.
 * 3. Coexistence: Festival items use the existing `CarouselItem` model and priority semantics (default 100),
 *    seamlessly coexisting with member Birthday celebrations (priority 120) and general notices (< 50).
 * 4. Fault Tolerance: Invalid or unresolvable festival entries are safely ignored without disrupting other items.
 * 5. Lifecycle Safety: Executes in background IO coroutines, never directly from Compose recomposition.
 */
class FestivalAutomationService(
    private val carouselRepository: CarouselRepository = FirestoreCarouselRepository.getInstance()
) {
    companion object {
        private const val TAG = "FestivalAutomation"

        @Volatile
        private var instance: FestivalAutomationService? = null

        fun getInstance(repository: CarouselRepository = FirestoreCarouselRepository.getInstance()): FestivalAutomationService {
            return instance ?: synchronized(this) {
                instance ?: FestivalAutomationService(repository).also { instance = it }
            }
        }

        /**
         * Generates a deterministic identity key for a festival in a given calendar year.
         * Global format: FESTIVAL_<FESTIVAL_ID>_<YEAR>
         * Group format:  FESTIVAL_<GROUP_ID>_<FESTIVAL_ID>_<YEAR>
         */
        fun generateDeterministicId(festivalId: String, year: Int, groupId: Long = GLOBAL_GROUP_ID): String {
            val cleanId = festivalId.trim().uppercase().replace(" ", "_")
            return if (groupId == GLOBAL_GROUP_ID) {
                "FESTIVAL_${cleanId}_$year"
            } else {
                "FESTIVAL_${groupId}_${cleanId}_$year"
            }
        }
    }

    /**
     * Constructs a CarouselItem for a given festival definition in a specific year.
     *
     * @param festival The festival definition
     * @param year The calendar year to evaluate
     * @param groupId Target group ID (default: GLOBAL_GROUP_ID = 0L)
     * @param timeZone Timezone for calculating the activation window
     * @return CarouselItem if the festival date resolves successfully, null otherwise.
     */
    fun createFestivalCarouselItem(
        festival: FestivalDefinition,
        year: Int,
        groupId: Long = GLOBAL_GROUP_ID,
        timeZone: TimeZone = TimeZone.getDefault()
    ): CarouselItem? {
        if (!festival.isEnabled) return null

        val window = FestivalDateResolver.calculateWindow(festival, year, timeZone) ?: return null
        val deterministicId = generateDeterministicId(festival.id, year, groupId)

        return CarouselItem(
            id = deterministicId,
            groupId = groupId,
            contentType = CarouselContentType.FESTIVAL,
            title = festival.defaultTitle,
            message = festival.defaultMessage,
            mediaResource = festival.defaultMediaResource,
            startAt = window.first,
            endAt = window.second,
            isActive = festival.isEnabled,
            priority = festival.priority,
            slideDurationSeconds = festival.slideDurationSeconds,
            actionType = festival.actionType,
            actionTarget = festival.actionTarget,
            actionLabel = festival.actionLabel,
            createdBy = "FestivalAutomationService"
        )
    }

    /**
     * Evaluates a festival catalog for a target calendar year and idempotently persists
     * scheduled celebration slides into the carousel repository.
     *
     * @param groupId Group scope for items (default: GLOBAL_GROUP_ID for app-wide festivals)
     * @param targetCalendar Reference date determining the target calendar year
     * @param catalog Festival catalog to process (defaults to predefined [FestivalCatalog.defaultFestivals])
     * @return List of successfully generated/saved CarouselItems
     */
    suspend fun processFestivalAutomation(
        groupId: Long = GLOBAL_GROUP_ID,
        targetCalendar: Calendar = Calendar.getInstance(),
        catalog: List<FestivalDefinition> = FestivalCatalog.defaultFestivals
    ): List<CarouselItem> = withContext(Dispatchers.IO) {
        val targetYear = targetCalendar.get(Calendar.YEAR)
        val generatedItems = mutableListOf<CarouselItem>()

        for (festival in catalog) {
            if (!festival.isEnabled) continue

            val item = createFestivalCarouselItem(
                festival = festival,
                year = targetYear,
                groupId = groupId,
                timeZone = targetCalendar.timeZone
            ) ?: continue

            try {
                val saveResult = carouselRepository.saveCarouselItem(item)
                if (saveResult.isSuccess) {
                    generatedItems.add(item)
                    Log.d(TAG, "Successfully processed festival item: ${item.id} (groupId=$groupId)")
                } else {
                    Log.w(TAG, "Failed to save festival item ${item.id}: ${saveResult.exceptionOrNull()?.message}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Exception while saving festival item ${item.id}: ${e.message}", e)
            }
        }

        generatedItems
    }
}
