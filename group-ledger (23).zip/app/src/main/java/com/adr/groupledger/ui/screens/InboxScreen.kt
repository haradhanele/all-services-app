package com.adr.groupledger.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.adr.groupledger.ui.components.SamitiPullToRefreshBox
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.HowToVote
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.FeedbackWithVotes
import com.adr.groupledger.data.model.NotificationItem
import com.adr.groupledger.data.model.PendingPaymentApprovalItem
import com.adr.groupledger.data.model.SocietyNotice
import com.adr.groupledger.ui.components.PendingApprovalCard
import com.adr.groupledger.ui.theme.Amber500
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.theme.appOutlinedTextFieldColors
import com.adr.groupledger.ui.viewmodel.SocietyViewModel
import com.adr.groupledger.utils.DateUtils
import com.adr.groupledger.utils.ReminderHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InboxScreen(
    viewModel: SocietyViewModel,
    onNavigateToRoute: (String) -> Unit,
    onNavigateToMemberProfile: (Long) -> Unit,
    modifier: Modifier = Modifier,
    initialTab: Int = 0,
    onNavigateBack: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val notifications by viewModel.allNotifications.collectAsStateWithLifecycle()
    val unreadCount by viewModel.unreadNotificationsCount.collectAsStateWithLifecycle()
    val pendingApprovals by viewModel.pendingPaymentApprovals.collectAsStateWithLifecycle()
    val notices by viewModel.notices.collectAsStateWithLifecycle()
    val feedbacks by viewModel.feedbacksWithVotes.collectAsStateWithLifecycle()
    val groupSettings by viewModel.groupSettings.collectAsStateWithLifecycle()
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()
    val currentUserRole by viewModel.currentUserRole.collectAsStateWithLifecycle()
    val currentMemberId by viewModel.currentMemberId.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val isNoticeBoardRefreshing by viewModel.isNoticeBoardRefreshing.collectAsStateWithLifecycle()
    val isCommunityRefreshing by viewModel.isCommunityRefreshing.collectAsStateWithLifecycle()

    val isUserAdmin = isAdminUnlocked || currentUserRole.equals("ADMIN", ignoreCase = true)
    val activeVoterId = currentMemberId ?: currentUser?.id ?: 1L

    var selectedTabIndex by remember(initialTab) { mutableIntStateOf(initialTab.coerceIn(0, 2)) }

    // Dialog state for Notice Board
    var showPostNoticeDialog by remember { mutableStateOf(false) }
    var prefilledNoticeTitle by remember { mutableStateOf("") }
    var prefilledNoticeContent by remember { mutableStateOf("") }
    var prefilledNoticeCategory by remember { mutableStateOf("General") }
    var prefilledNoticeIsPoll by remember { mutableStateOf(false) }
    var prefilledNoticeOptions by remember { mutableStateOf("In Favor / Yes,Against / No") }

    // Dialog state for Community
    var showCreateCommunityDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("communication_hub_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Optional Top Navigation Bar if opened directly as a sub-screen
            if (onNavigateBack != null) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 2.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onNavigateBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Communication Hub",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = groupSettings.groupName,
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Top 3-Tab Row
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
            ) {
                SecondaryTabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = IndigoPrimary,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Tab 0: Updates
                    val updatesBadge = unreadCount + if (isUserAdmin) pendingApprovals.size else 0
                    Tab(
                        selected = selectedTabIndex == 0,
                        onClick = { selectedTabIndex = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Updates",
                                    fontWeight = if (selectedTabIndex == 0) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 13.sp,
                                    color = if (selectedTabIndex == 0) IndigoPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (updatesBadge > 0) {
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Surface(
                                        shape = CircleShape,
                                        color = if (pendingApprovals.isNotEmpty() && isUserAdmin) Amber500 else Rose500,
                                        modifier = Modifier.size(18.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = if (updatesBadge > 9) "9+" else "$updatesBadge",
                                                color = Color.White,
                                                fontSize = 9.5.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    )

                    // Tab 1: Notice Board
                    Tab(
                        selected = selectedTabIndex == 1,
                        onClick = { selectedTabIndex = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Notice Board",
                                    fontWeight = if (selectedTabIndex == 1) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 13.sp,
                                    color = if (selectedTabIndex == 1) IndigoPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (notices.isNotEmpty()) {
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "${notices.size}",
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontSize = 9.5.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    )

                    // Tab 2: Community
                    Tab(
                        selected = selectedTabIndex == 2,
                        onClick = { selectedTabIndex = 2 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Community",
                                    fontWeight = if (selectedTabIndex == 2) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 13.sp,
                                    color = if (selectedTabIndex == 2) IndigoPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (feedbacks.isNotEmpty()) {
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "${feedbacks.size}",
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontSize = 9.5.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    )
                }
            }

            // Tab View Body
            when (selectedTabIndex) {
                0 -> {
                    InboxUpdatesTab(
                        notifications = notifications,
                        pendingApprovals = pendingApprovals,
                        currencySymbol = groupSettings.currencySymbol,
                        isAdmin = isUserAdmin,
                        currentMemberId = activeVoterId,
                        unreadCount = unreadCount,
                        onMarkAllRead = { viewModel.markAllNotificationsRead() },
                        onNotificationClick = { item ->
                            viewModel.markNotificationRead(item.id)
                            item.actionRoute?.let { onNavigateToRoute(it) }
                        },
                        onApprovePayment = { paymentId ->
                            if (isAdminUnlocked) {
                                viewModel.approvePayment(paymentId)
                            } else {
                                viewModel.requestAdminAction {
                                    viewModel.approvePayment(paymentId)
                                }
                            }
                        },
                        onRejectPayment = { paymentId, reason ->
                            if (isAdminUnlocked) {
                                viewModel.rejectPayment(paymentId, reason)
                            } else {
                                viewModel.requestAdminAction {
                                    viewModel.rejectPayment(paymentId, reason)
                                }
                            }
                        }
                    )
                }
                1 -> {
                    InboxNoticeBoardTab(
                        notices = notices,
                        isAdmin = isUserAdmin,
                        activeVoterId = activeVoterId,
                        isRefreshing = isNoticeBoardRefreshing,
                        onRefresh = { viewModel.refreshNoticeBoard() },
                        onTogglePin = { notice -> viewModel.togglePinNotice(notice) },
                        onDeleteNotice = { notice -> viewModel.deleteNotice(notice) },
                        onVote = { notice, option -> viewModel.voteOnNotice(notice, option) },
                        onShareNotice = { notice ->
                            ReminderHelper.shareText(
                                context,
                                "📢 *${notice.title}*\n\n${notice.content}\n\n— *${groupSettings.groupName}*",
                                "Share Society Notice"
                            )
                        }
                    )
                }
                2 -> {
                    InboxCommunityTab(
                        feedbacks = feedbacks,
                        isAdmin = isUserAdmin,
                        isRefreshing = isCommunityRefreshing,
                        onRefresh = { viewModel.refreshCommunity() },
                        onSupport = { feedbackId -> viewModel.toggleSupportCommunityPost(feedbackId) },
                        onEscalateToNotice = { fbItem ->
                            prefilledNoticeTitle = "Decision: ${fbItem.feedback.subject}"
                            val authorLabel = if (fbItem.feedback.isAnonymous) "A member" else fbItem.feedback.memberName
                            prefilledNoticeContent = "Discussion proposal submitted by $authorLabel:\n\n${fbItem.feedback.description}"
                            prefilledNoticeCategory = "Proposal"
                            prefilledNoticeIsPoll = true
                            prefilledNoticeOptions = "In Favor / Yes,Against / No"
                            selectedTabIndex = 1
                            showPostNoticeDialog = true
                        }
                    )
                }
            }
        }

        // Floating Action Buttons based on Tab
        if (selectedTabIndex == 1 && isUserAdmin) {
            FloatingActionButton(
                onClick = {
                    prefilledNoticeTitle = ""
                    prefilledNoticeContent = ""
                    prefilledNoticeCategory = "General"
                    prefilledNoticeIsPoll = false
                    prefilledNoticeOptions = "In Favor / Yes,Against / No"
                    showPostNoticeDialog = true
                },
                containerColor = IndigoPrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .testTag("post_notice_fab")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Post Notice")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Post Notice", fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                }
            }
        } else if (selectedTabIndex == 2) {
            FloatingActionButton(
                onClick = { showCreateCommunityDialog = true },
                containerColor = IndigoPrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .testTag("create_community_post_fab")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "New Post")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("New Post", fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                }
            }
        }
    }

    // Modal / Sheet for Notice & Poll Creation
    if (showPostNoticeDialog) {
        PostNoticeDialog(
            initialTitle = prefilledNoticeTitle,
            initialContent = prefilledNoticeContent,
            initialCategory = prefilledNoticeCategory,
            initialIsPoll = prefilledNoticeIsPoll,
            initialOptions = prefilledNoticeOptions,
            onDismiss = { showPostNoticeDialog = false },
            onPost = { title, content, category, isPinned, isPollEnabled, pollOptions, pollExpiryDate, pushAlert, shareToWhatsApp ->
                viewModel.postNotice(
                    title = title,
                    content = content,
                    category = category,
                    author = if (isAdminUnlocked) "Society Admin" else "Admin",
                    isPinned = isPinned,
                    isPollEnabled = isPollEnabled,
                    pollOptions = pollOptions,
                    pollExpiryDate = pollExpiryDate,
                    pushAlert = pushAlert,
                    onSuccess = {
                        if (shareToWhatsApp) {
                            ReminderHelper.shareText(
                                context,
                                "📢 *OFFICIAL NOTICE: ${title.trim()}*\n\n${content.trim()}\n\n— *${groupSettings.groupName}*",
                                "Broadcast Notice"
                            )
                        }
                    }
                )
                showPostNoticeDialog = false
            }
        )
    }

    // Modal for Creating Community Discussion / Proposal
    if (showCreateCommunityDialog) {
        CreateCommunityPostDialog(
            onDismiss = { showCreateCommunityDialog = false },
            onSubmit = { type, subject, description, isAnonymous ->
                viewModel.submitFeedback(
                    type = type,
                    subject = subject,
                    description = description,
                    requiresVoting = type.equals("PROPOSAL", ignoreCase = true),
                    isAnonymous = isAnonymous
                )
                showCreateCommunityDialog = false
            }
        )
    }
}

// -------------------------------------------------------------
// TAB 1: UPDATES (Approvals, Transaction Logs & Notifications)
// -------------------------------------------------------------
@Composable
fun InboxUpdatesTab(
    notifications: List<NotificationItem>,
    pendingApprovals: List<PendingPaymentApprovalItem>,
    currencySymbol: String,
    isAdmin: Boolean,
    currentMemberId: Long,
    unreadCount: Int,
    onMarkAllRead: () -> Unit,
    onNotificationClick: (NotificationItem) -> Unit,
    onApprovePayment: (Long) -> Unit,
    onRejectPayment: (Long, String) -> Unit
) {
    var selectedFilter by remember { mutableStateOf("All") }

    val filteredNotifications = remember(notifications, selectedFilter) {
        when (selectedFilter) {
            "Approvals" -> notifications.filter { it.type.contains("APPROVAL", ignoreCase = true) }
            "Notices" -> notifications.filter { it.type.contains("ANNOUNCEMENT", ignoreCase = true) || it.type.contains("NOTICE", ignoreCase = true) }
            "Transactions" -> notifications.filter { it.type.contains("PAYMENT", ignoreCase = true) || it.type.contains("DUE", ignoreCase = true) }
            else -> notifications
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 1.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    val filters = listOf("All", "Approvals", "Notices", "Transactions")
                    items(filters) { f ->
                        FilterChip(
                            selected = selectedFilter == f,
                            onClick = { selectedFilter = f },
                            label = { Text(f, fontSize = 11.5.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = IndigoPrimary,
                                selectedLabelColor = Color.White,
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            border = BorderStroke(1.dp, if (selectedFilter == f) IndigoPrimary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        )
                    }
                }

                if (unreadCount > 0) {
                    TextButton(
                        onClick = onMarkAllRead,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(imageVector = Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(15.dp), tint = IndigoPrimary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Mark all read", fontSize = 11.sp, color = IndigoPrimary, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (isAdmin && pendingApprovals.isNotEmpty() && (selectedFilter == "All" || selectedFilter == "Approvals")) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.HourglassTop, contentDescription = null, tint = Amber500, modifier = Modifier.size(17.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Action Required: Pending Approvals (${pendingApprovals.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                items(pendingApprovals, key = { "approval_${it.payment.id}" }) { item ->
                    PendingApprovalCard(
                        item = item,
                        currencySymbol = currencySymbol,
                        isAdmin = true,
                        onApprove = onApprovePayment,
                        onReject = onRejectPayment
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(6.dp))
                }
            }

            if (!isAdmin) {
                val myPending = pendingApprovals.filter { it.member.id == currentMemberId }
                if (myPending.isNotEmpty()) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.HourglassTop, contentDescription = null, tint = Amber500, modifier = Modifier.size(17.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "My Submissions Under Review (${myPending.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    items(myPending, key = { "my_approval_${it.payment.id}" }) { item ->
                        PendingApprovalCard(
                            item = item,
                            currencySymbol = currencySymbol,
                            isAdmin = false,
                            onApprove = {},
                            onReject = { _, _ -> }
                        )
                    }

                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }
            }

            if (filteredNotifications.isEmpty() && pendingApprovals.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "All caught up!",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "You will see transactions, payment approvals, and society updates here.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 24.dp)
                            )
                        }
                    }
                }
            } else {
                item {
                    Text(
                        text = "Activity Logs & Notifications",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }

                items(filteredNotifications, key = { "notif_${it.id}" }) { item ->
                    InboxNotificationCardItem(
                        item = item,
                        onClick = { onNotificationClick(item) }
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 2: NOTICE BOARD & ADMIN VOTING POLL SYSTEM
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InboxNoticeBoardTab(
    notices: List<SocietyNotice>,
    isAdmin: Boolean,
    activeVoterId: Long,
    isRefreshing: Boolean = false,
    onRefresh: () -> Unit = {},
    onTogglePin: (SocietyNotice) -> Unit,
    onDeleteNotice: (SocietyNotice) -> Unit,
    onVote: (SocietyNotice, String) -> Unit,
    onShareNotice: (SocietyNotice) -> Unit
) {
    var selectedCategory by remember { mutableStateOf("All") }
    val categories = listOf("All", "General", "Meeting", "Proposal", "Rules", "Payment", "Urgent", "Events", "Achievement")

    val filteredNotices = remember(notices, selectedCategory) {
        val sorted = notices.sortedWith(
            compareByDescending<SocietyNotice> { it.isPinned }
                .thenByDescending { it.timestamp }
        )
        if (selectedCategory == "All") sorted
        else sorted.filter { it.category.equals(selectedCategory, ignoreCase = true) }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 1.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
        ) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(categories) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 11.5.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = IndigoPrimary,
                            selectedLabelColor = Color.White,
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        border = BorderStroke(1.dp, if (selectedCategory == cat) IndigoPrimary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    )
                }
            }
        }

        SamitiPullToRefreshBox(
            isRefreshing = isRefreshing,
            onRefresh = onRefresh,
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
        ) {
            if (filteredNotices.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.Campaign,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (selectedCategory == "All") "No notices posted yet" else "No $selectedCategory notices",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isAdmin) "Tap '+ Post Notice' below to publish an official society announcement or voting poll."
                            else "Official society announcements and decisions by Admin will be displayed here.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 86.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredNotices, key = { it.id }) { notice ->
                        NoticeCard(
                            notice = notice,
                            isAdmin = isAdmin,
                            activeVoterId = activeVoterId,
                            onTogglePin = { onTogglePin(notice) },
                            onDelete = { onDeleteNotice(notice) },
                            onVote = { option -> onVote(notice, option) },
                            onShare = { onShareNotice(notice) }
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// NOTICE CARD WITH INTERACTIVE VOTING PROGRESS BARS
// -------------------------------------------------------------
@Composable
fun NoticeCard(
    notice: SocietyNotice,
    isAdmin: Boolean,
    activeVoterId: Long,
    onTogglePin: () -> Unit,
    onDelete: () -> Unit,
    onVote: (String) -> Unit,
    onShare: () -> Unit
) {
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("notice_card_${notice.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            1.dp,
            if (notice.isPinned) IndigoPrimary.copy(alpha = 0.6f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (notice.isPinned) 2.dp else 1.dp)
    ) {
        Column(modifier = Modifier.padding(15.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CategoryPill(category = notice.category)

                    if (notice.isPinned) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = IndigoPrimary.copy(alpha = 0.15f),
                            border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.35f))
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Icon(Icons.Default.PushPin, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(11.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("PINNED", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                            }
                        }
                    }
                }

                Text(
                    text = DateUtils.formatDate(notice.timestamp),
                    fontSize = 11.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = notice.title,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = notice.content,
                fontSize = 13.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 19.sp
            )

            if (notice.isPollEnabled) {
                Spacer(modifier = Modifier.height(12.dp))
                NoticePollWidget(
                    notice = notice,
                    activeVoterId = activeVoterId,
                    onVote = onVote
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Issued by ${notice.author}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = onShare, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Share, contentDescription = "Share", tint = IndigoPrimary, modifier = Modifier.size(16.dp))
                    }
                    if (isAdmin) {
                        IconButton(onClick = onTogglePin, modifier = Modifier.size(32.dp)) {
                            Icon(
                                imageVector = if (notice.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                                contentDescription = "Pin",
                                tint = if (notice.isPinned) IndigoPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        IconButton(onClick = { showDeleteConfirm = true }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Rose500, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Notice", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface) },
            text = {
                Text(
                    text = "Are you sure you want to permanently remove '${notice.title}'?",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.5.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDelete()
                        showDeleteConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Rose500)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        )
    }
}

// -------------------------------------------------------------
// NOTICE POLL WIDGET WITH PROGRESS BARS & ONE-TAP VOTING
// -------------------------------------------------------------
@Composable
fun NoticePollWidget(
    notice: SocietyNotice,
    activeVoterId: Long,
    onVote: (String) -> Unit
) {
    val votesMap = remember(notice.pollVotesJson) { notice.getVotesMap() }
    val totalVotes = votesMap.size
    val userVotedOption = votesMap[activeVoterId.toString()]
    val isExpired = notice.isPollExpired()
    val optionsList = remember(notice.pollOptions) { notice.getOptionsList() }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.HowToVote,
                        contentDescription = null,
                        tint = IndigoPrimary,
                        modifier = Modifier.size(17.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Official Voting Poll",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = if (isExpired) Rose500.copy(alpha = 0.15f) else Emerald500.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = if (isExpired) "Closed" else "Active Vote",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isExpired) Rose500 else Emerald500,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "$totalVotes member vote${if (totalVotes == 1) "" else "s"} cast",
                    fontSize = 11.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (notice.pollExpiryDate > 0L) {
                    Text(
                        text = if (isExpired) "Ended ${DateUtils.formatDate(notice.pollExpiryDate)}" else "Expires: ${DateUtils.formatDate(notice.pollExpiryDate)}",
                        fontSize = 11.sp,
                        color = if (isExpired) Rose500 else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                optionsList.forEach { option ->
                    val optionCount = votesMap.values.count { it.equals(option, ignoreCase = true) }
                    val fraction = if (totalVotes > 0) (optionCount.toFloat() / totalVotes.toFloat()) else 0f
                    val percentage = (fraction * 100f).toInt()
                    val isMyVote = userVotedOption.equals(option, ignoreCase = true)

                    val animatedProgress by animateFloatAsState(
                        targetValue = fraction,
                        label = "pollProgress"
                    )

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isMyVote) IndigoPrimary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(
                            1.dp,
                            if (isMyVote) IndigoPrimary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(enabled = !isExpired) {
                                onVote(option)
                            }
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Icon(
                                        imageVector = if (isMyVote) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
                                        contentDescription = null,
                                        tint = if (isMyVote) IndigoPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = option,
                                        fontWeight = if (isMyVote) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (isMyVote) {
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = IndigoPrimary,
                                            modifier = Modifier.padding(end = 6.dp)
                                        ) {
                                            Text(
                                                text = "Your Vote",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = "$percentage% ($optionCount)",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            LinearProgressIndicator(
                                progress = { animatedProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = if (isMyVote) IndigoPrimary else MaterialTheme.colorScheme.primary.copy(alpha = 0.75f),
                                trackColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            )
                        }
                    }
                }
            }

            if (!isExpired && userVotedOption == null) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Tap any option above to cast your vote (one vote per member).",
                    fontSize = 11.sp,
                    color = IndigoPrimary,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 3: COMMUNITY (Discussions, Suggestions, Complaints)
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InboxCommunityTab(
    feedbacks: List<FeedbackWithVotes>,
    isAdmin: Boolean,
    isRefreshing: Boolean = false,
    onRefresh: () -> Unit = {},
    onSupport: (Long) -> Unit,
    onEscalateToNotice: (FeedbackWithVotes) -> Unit
) {
    var selectedCategory by remember { mutableStateOf("All") }
    val categories = listOf("All", "General", "Suggestion", "Proposal", "Complaint", "Request", "Achievement")

    val filteredFeedbacks = remember(feedbacks, selectedCategory) {
        val sorted = feedbacks.sortedByDescending { it.feedback.createdAt }
        if (selectedCategory == "All") sorted
        else sorted.filter { it.feedback.type.equals(selectedCategory, ignoreCase = true) }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 1.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
        ) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(categories) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 11.5.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = IndigoPrimary,
                            selectedLabelColor = Color.White,
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        border = BorderStroke(1.dp, if (selectedCategory == cat) IndigoPrimary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    )
                }
            }
        }

        SamitiPullToRefreshBox(
            isRefreshing = isRefreshing,
            onRefresh = onRefresh,
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
        ) {
            if (filteredFeedbacks.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.Forum,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(52.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (selectedCategory == "All") "No community discussions yet" else "No $selectedCategory posts yet",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Share suggestions, proposals, or questions with society members. Tap '+ New Post' to start.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 86.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredFeedbacks, key = { it.feedback.id }) { item ->
                        CommunityPostCard(
                            item = item,
                            isAdmin = isAdmin,
                            onSupport = { onSupport(item.feedback.id) },
                            onEscalateToNotice = { onEscalateToNotice(item) }
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// COMMUNITY POST CARD
// -------------------------------------------------------------
@Composable
fun CommunityPostCard(
    item: FeedbackWithVotes,
    isAdmin: Boolean,
    onSupport: () -> Unit,
    onEscalateToNotice: () -> Unit
) {
    val fb = item.feedback

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("community_post_${fb.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(15.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CategoryPill(category = fb.type)

                Text(
                    text = DateUtils.formatDate(fb.createdAt),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = if (fb.isAnonymous) MaterialTheme.colorScheme.surfaceVariant else IndigoPrimary.copy(alpha = 0.15f),
                    modifier = Modifier.size(28.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        if (fb.isAnonymous) {
                            Icon(
                                Icons.Default.VisibilityOff,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(15.dp)
                            )
                        } else {
                            Text(
                                text = fb.memberName.take(1).uppercase(),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = IndigoPrimary
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = if (fb.isAnonymous) "Anonymous Member" else fb.memberName,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = fb.subject,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = fb.description,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 18.sp
            )

            if (fb.adminResponse.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = IndigoPrimary.copy(alpha = 0.08f),
                    border = BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.25f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "Admin Response:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = IndigoPrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = fb.adminResponse,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onSupport,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(34.dp),
                    border = BorderStroke(1.dp, if (item.agreeCount > 0) IndigoPrimary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                ) {
                    Icon(
                        imageVector = if (item.agreeCount > 0) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                        contentDescription = "Support",
                        tint = if (item.agreeCount > 0) IndigoPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (item.agreeCount > 0) "${item.agreeCount} Support" else "Support",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (item.agreeCount > 0) IndigoPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when (fb.status) {
                            "ACCEPTED", "RESOLVED" -> Emerald500.copy(alpha = 0.15f)
                            "REJECTED" -> Rose500.copy(alpha = 0.15f)
                            "DISCUSSING", "UNDER_REVIEW" -> Amber500.copy(alpha = 0.15f)
                            else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                        }
                    ) {
                        Text(
                            text = fb.status.replace("_", " "),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (fb.status) {
                                "ACCEPTED", "RESOLVED" -> Emerald500
                                "REJECTED" -> Rose500
                                "DISCUSSING", "UNDER_REVIEW" -> Amber500
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    if (isAdmin) {
                        Button(
                            onClick = onEscalateToNotice,
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(34.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                        ) {
                            Icon(Icons.Default.HowToVote, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Escalate to Poll", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// HELPER PILL FOR CATEGORIES (Soft-tinted Modern Design)
// -------------------------------------------------------------
@Composable
fun CategoryPill(category: String) {
    val norm = category.uppercase().trim()
    val (bgColor, textColor, icon) = when (norm) {
        "URGENT", "COMPLAINT" -> Triple(Rose500.copy(alpha = 0.14f), Rose500, Icons.Default.ReportProblem)
        "PAYMENT" -> Triple(Emerald500.copy(alpha = 0.14f), Emerald500, Icons.Default.Payments)
        "MEETING", "EVENT", "EVENTS" -> Triple(Color(0xFF06B6D4).copy(alpha = 0.14f), Color(0xFF0891B2), Icons.Default.Event)
        "PROPOSAL" -> Triple(Color(0xFF8B5CF6).copy(alpha = 0.14f), Color(0xFF7C3AED), Icons.Default.CheckCircle)
        "SUGGESTION" -> Triple(Amber500.copy(alpha = 0.14f), Amber500, Icons.Default.Lightbulb)
        "RULES" -> Triple(Amber500.copy(alpha = 0.14f), Amber500, Icons.Default.Warning)
        "ACHIEVEMENT" -> Triple(Color(0xFF10B981).copy(alpha = 0.14f), Color(0xFF059669), Icons.Default.EmojiEvents)
        "REQUEST" -> Triple(Color(0xFF3B82F6).copy(alpha = 0.14f), Color(0xFF2563EB), Icons.Default.HelpOutline)
        else -> Triple(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), MaterialTheme.colorScheme.onSurfaceVariant, Icons.Default.Campaign)
    }

    Surface(
        shape = RoundedCornerShape(6.dp),
        color = bgColor
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = textColor, modifier = Modifier.size(12.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = norm,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                color = textColor
            )
        }
    }
}

// -------------------------------------------------------------
// INBOX NOTIFICATION CARD ITEM
// -------------------------------------------------------------
@Composable
private fun InboxNotificationCardItem(
    item: NotificationItem,
    onClick: () -> Unit
) {
    val isUnread = !item.isRead
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("notification_item_${item.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            1.dp,
            if (isUnread) IndigoPrimary.copy(alpha = 0.45f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isUnread) 1.5.dp else 0.5.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = when {
                    item.type.contains("APPROVAL", ignoreCase = true) -> Amber500.copy(alpha = 0.15f)
                    item.type.contains("PAYMENT", ignoreCase = true) -> Emerald500.copy(alpha = 0.15f)
                    item.type.contains("LOAN", ignoreCase = true) -> Amber500.copy(alpha = 0.15f)
                    item.type.contains("DUE", ignoreCase = true) -> Rose500.copy(alpha = 0.15f)
                    else -> IndigoPrimary.copy(alpha = 0.15f)
                },
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = when {
                            item.type.contains("APPROVAL", ignoreCase = true) -> Icons.Default.HourglassTop
                            item.type.contains("PAYMENT", ignoreCase = true) -> Icons.Default.Payments
                            item.type.contains("LOAN", ignoreCase = true) -> Icons.Default.Handshake
                            item.type.contains("DUE", ignoreCase = true) -> Icons.Default.Warning
                            else -> Icons.Default.Campaign
                        },
                        contentDescription = null,
                        tint = when {
                            item.type.contains("APPROVAL", ignoreCase = true) -> Amber500
                            item.type.contains("PAYMENT", ignoreCase = true) -> Emerald500
                            item.type.contains("LOAN", ignoreCase = true) -> Amber500
                            item.type.contains("DUE", ignoreCase = true) -> Rose500
                            else -> IndigoPrimary
                        },
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = item.title,
                        fontWeight = if (isUnread) FontWeight.Bold else FontWeight.SemiBold,
                        fontSize = 13.5.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = DateUtils.formatDate(item.timestamp),
                        fontSize = 10.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = item.message,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 16.sp
                )
            }

            if (isUnread) {
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(IndigoPrimary)
                )
            }
        }
    }
}

// -------------------------------------------------------------
// POST NOTICE & ADMIN VOTING POLL CREATION MODAL
// -------------------------------------------------------------
@Composable
fun PostNoticeDialog(
    initialTitle: String = "",
    initialContent: String = "",
    initialCategory: String = "General",
    initialIsPoll: Boolean = false,
    initialOptions: String = "In Favor / Yes,Against / No",
    onDismiss: () -> Unit,
    onPost: (
        title: String,
        content: String,
        category: String,
        isPinned: Boolean,
        isPollEnabled: Boolean,
        pollOptions: String,
        pollExpiryDate: Long,
        pushAlert: Boolean,
        shareToWhatsApp: Boolean
    ) -> Unit
) {
    var title by remember { mutableStateOf(initialTitle) }
    var content by remember { mutableStateOf(initialContent) }
    var category by remember { mutableStateOf(initialCategory) }
    var isPinned by remember { mutableStateOf(false) }
    var pushAlert by remember { mutableStateOf(false) }
    var shareToWhatsApp by remember { mutableStateOf(false) }

    var isPollEnabled by remember { mutableStateOf(initialIsPoll) }
    var pollChoicePreset by remember { mutableStateOf(if (initialOptions.contains("Against")) "In Favor / Against" else "Yes / No") }
    var customOption1 by remember { mutableStateOf("") }
    var customOption2 by remember { mutableStateOf("") }
    var useCustomOptions by remember { mutableStateOf(false) }
    var expiryDays by remember { mutableIntStateOf(0) }

    val noticeCategories = listOf("General", "Meeting", "Proposal", "Rules", "Payment", "Urgent", "Events", "Achievement")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Campaign, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isPollEnabled) "Post Notice & Voting Poll" else "Post Society Notice",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Notice Title / Subject") },
                        placeholder = { Text("e.g. Monthly General Meeting") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = appOutlinedTextFieldColors()
                    )
                }

                item {
                    OutlinedTextField(
                        value = content,
                        onValueChange = { content = it },
                        label = { Text("Announcement Details") },
                        placeholder = { Text("Enter full details or proposal for society members...") },
                        minLines = 3,
                        maxLines = 5,
                        modifier = Modifier.fillMaxWidth(),
                        colors = appOutlinedTextFieldColors()
                    )
                }

                item {
                    Text("Category:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(noticeCategories) { cat ->
                            FilterChip(
                                selected = category.equals(cat, ignoreCase = true),
                                onClick = { category = cat },
                                label = { Text(cat, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IndigoPrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }

                item {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.PushPin, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Pin to Top (📌)", fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurface)
                                }
                                Switch(
                                    checked = isPinned,
                                    onCheckedChange = { isPinned = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = IndigoPrimary)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Notifications, contentDescription = null, tint = Amber500, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Push Alert to Members (🔔)", fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurface)
                                }
                                Switch(
                                    checked = pushAlert,
                                    onCheckedChange = { pushAlert = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Amber500)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Share, contentDescription = null, tint = Emerald500, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Share to WhatsApp", fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurface)
                                }
                                Switch(
                                    checked = shareToWhatsApp,
                                    onCheckedChange = { shareToWhatsApp = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Emerald500)
                                )
                            }
                        }
                    }
                }

                item {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isPollEnabled) IndigoPrimary.copy(alpha = 0.09f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        border = BorderStroke(1.dp, if (isPollEnabled) IndigoPrimary.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.HowToVote, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Column {
                                        Text("Create Decision Voting Poll", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                                        Text("Allow members to vote on this notice", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                Switch(
                                    checked = isPollEnabled,
                                    onCheckedChange = { isPollEnabled = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = IndigoPrimary)
                                )
                            }

                            AnimatedVisibility(visible = isPollEnabled) {
                                Column(modifier = Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Voting Options:", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)

                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        listOf("In Favor / Against", "Yes / No", "Custom").forEach { preset ->
                                            FilterChip(
                                                selected = if (preset == "Custom") useCustomOptions else (!useCustomOptions && pollChoicePreset == preset),
                                                onClick = {
                                                    if (preset == "Custom") {
                                                        useCustomOptions = true
                                                    } else {
                                                        useCustomOptions = false
                                                        pollChoicePreset = preset
                                                    }
                                                },
                                                label = { Text(preset, fontSize = 10.5.sp) },
                                                colors = FilterChipDefaults.filterChipColors(
                                                    selectedContainerColor = IndigoPrimary,
                                                    selectedLabelColor = Color.White
                                                )
                                            )
                                        }
                                    }

                                    if (useCustomOptions) {
                                        OutlinedTextField(
                                            value = customOption1,
                                            onValueChange = { customOption1 = it },
                                            placeholder = { Text("Option 1 (e.g. Option A)") },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = appOutlinedTextFieldColors()
                                        )
                                        OutlinedTextField(
                                            value = customOption2,
                                            onValueChange = { customOption2 = it },
                                            placeholder = { Text("Option 2 (e.g. Option B)") },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = appOutlinedTextFieldColors()
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("Voting Expiry:", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        val durations = listOf(0 to "No Expiry", 1 to "24h", 3 to "3 Days", 7 to "7 Days", 14 to "14 Days")
                                        durations.forEach { (d, label) ->
                                            FilterChip(
                                                selected = expiryDays == d,
                                                onClick = { expiryDays = d },
                                                label = { Text(label, fontSize = 10.5.sp) },
                                                colors = FilterChipDefaults.filterChipColors(
                                                    selectedContainerColor = IndigoPrimary,
                                                    selectedLabelColor = Color.White
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && content.isNotBlank()) {
                        val computedOptions = if (!isPollEnabled) {
                            "In Favor / Yes,Against / No"
                        } else if (useCustomOptions) {
                            val opt1 = customOption1.trim().ifBlank { "Option 1" }
                            val opt2 = customOption2.trim().ifBlank { "Option 2" }
                            "$opt1,$opt2"
                        } else if (pollChoicePreset == "Yes / No") {
                            "Yes,No"
                        } else {
                            "In Favor / Yes,Against / No"
                        }

                        val computedExpiry = if (isPollEnabled && expiryDays > 0) {
                            System.currentTimeMillis() + (expiryDays.toLong() * 24L * 60L * 60L * 1000L)
                        } else {
                            0L
                        }

                        onPost(
                            title,
                            content,
                            category,
                            isPinned,
                            isPollEnabled,
                            computedOptions,
                            computedExpiry,
                            pushAlert,
                            shareToWhatsApp
                        )
                    }
                },
                enabled = title.isNotBlank() && content.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
            ) {
                Text(if (isPollEnabled) "Publish Poll" else "Publish Notice", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    )
}

// -------------------------------------------------------------
// CREATE COMMUNITY POST MODAL
// -------------------------------------------------------------
@Composable
fun CreateCommunityPostDialog(
    onDismiss: () -> Unit,
    onSubmit: (type: String, subject: String, description: String, isAnonymous: Boolean) -> Unit
) {
    var type by remember { mutableStateOf("SUGGESTION") }
    var subject by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var isAnonymous by remember { mutableStateOf(false) }

    val postTypes = listOf("SUGGESTION", "PROPOSAL", "COMPLAINT", "REQUEST", "GENERAL", "ACHIEVEMENT")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Forum, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("New Community Post", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = MaterialTheme.colorScheme.onSurface)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text("Select Post Category:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(postTypes) { t ->
                            FilterChip(
                                selected = type == t,
                                onClick = { type = t },
                                label = { Text(t, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IndigoPrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = subject,
                        onValueChange = { subject = it },
                        label = { Text("Subject / Topic") },
                        placeholder = { Text("e.g. Proposal for digital receipt printer") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = appOutlinedTextFieldColors()
                    )
                }

                item {
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Discussion Details / Description") },
                        placeholder = { Text("Provide more context, suggestions, or concerns...") },
                        minLines = 3,
                        maxLines = 5,
                        modifier = Modifier.fillMaxWidth(),
                        colors = appOutlinedTextFieldColors()
                    )
                }

                item {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.VisibilityOff, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("Post Anonymously", fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurface)
                                    Text("Hide identity (recommended for complaints)", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Switch(
                                checked = isAnonymous,
                                onCheckedChange = { isAnonymous = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = IndigoPrimary)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (subject.isNotBlank() && description.isNotBlank()) {
                        onSubmit(type, subject.trim(), description.trim(), isAnonymous)
                    }
                },
                enabled = subject.isNotBlank() && description.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
            ) {
                Text("Submit Post", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    )
}
