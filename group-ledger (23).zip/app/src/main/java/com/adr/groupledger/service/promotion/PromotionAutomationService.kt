package com.adr.groupledger.service.promotion

import android.util.Log
import com.adr.groupledger.data.model.carousel.CarouselActionType
import com.adr.groupledger.data.model.carousel.CarouselContentType
import com.adr.groupledger.data.model.carousel.CarouselItem
import com.adr.groupledger.data.model.carousel.GLOBAL_GROUP_ID
import com.adr.groupledger.data.model.promotion.PromotionCampaignDefinition
import com.adr.groupledger.data.repository.carousel.CarouselRepository
import com.adr.groupledger.data.repository.carousel.FirestoreCarouselRepository
import com.adr.groupledger.ui.components.isSafeExternalUrl
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.TimeZone

/**
 * Service responsible for deterministic, idempotent promotion, offer, and CTA campaign automation.
 *
 * Guarantees:
 * 1. Consistent Deterministic ID:
 *    Uses strictly ONE format: `PROMO_<groupId>_<campaignKey>_<cycleKey>`
 *    Global scope example: `PROMO_0_ANNUAL_MAINTENANCE_OFFER_2026`
 *    Group-scoped example: `PROMO_101_TOURNAMENT_ENTRY_2026`
 * 2. Idempotency & Duplicate Prevention:
 *    Re-running promotion synchronization with identical deterministic IDs updates/reuses
 *    the existing record and never creates duplicate items in the repository/Firestore.
 * 3. Scope Separation:
 *    Global promotions use `GLOBAL_GROUP_ID` (0L) to serve all groups without duplication.
 *    Group-specific promotions use the concrete `groupId`.
 * 4. Priority Hierarchy:
 *    Defaults to priority 50. Harmoniously coexists with Birthday (120) and Festival (100–105)
 *    so celebrations take natural precedence on the Home Carousel.
 * 5. Safe CTA Handling:
 *    Strictly verifies `EXTERNAL_URL` against `isSafeExternalUrl` (HTTP/HTTPS only).
 *    Rejects unsafe schemes like `javascript:`, `file:`, `content:`, and `intent:`.
 * 6. Media Integrity:
 *    Uses existing Cloudinary / `MediaResource` architecture with graceful text-only fallback.
 * 7. Single Unified Architecture:
 *    Saves standard [CarouselItem]s with `CarouselContentType.PROMOTION` directly into the existing
 *    [CarouselRepository] for consumption by the existing [com.adr.groupledger.ui.components.HomeScreenCarousel].
 */
class PromotionAutomationService(
    private val carouselRepository: CarouselRepository = FirestoreCarouselRepository.getInstance()
) {
    companion object {
        private const val TAG = "PromotionAutomation"

        @Volatile
        private var instance: PromotionAutomationService? = null

        fun getInstance(repository: CarouselRepository = FirestoreCarouselRepository.getInstance()): PromotionAutomationService {
            return instance ?: synchronized(this) {
                instance ?: PromotionAutomationService(repository).also { instance = it }
            }
        }

        /**
         * Generates the deterministic identity key for a promotion campaign.
         * Format: PROMO_<groupId>_<campaignKey>_<cycleKey>
         *
         * Examples:
         * - Global scope (groupId = 0L): PROMO_0_ANNUAL_MAINTENANCE_OFFER_2026
         * - Group-scoped (groupId = 101L): PROMO_101_EARLY_BIRD_PAYMENT_2026
         */
        fun generateDeterministicId(campaignKey: String, cycleKey: String, groupId: Long = GLOBAL_GROUP_ID): String {
            val cleanKey = campaignKey.trim().uppercase().replace("[^A-Z0-9_]".toRegex(), "_")
            val cleanCycle = cycleKey.trim().uppercase().replace("[^A-Z0-9_]".toRegex(), "_")
            return "PROMO_${groupId}_${cleanKey}_${cleanCycle}"
        }

        /**
         * Validates that an action configuration is safe and consistent.
         * Returns sanitized action target or empty string if invalid.
         */
        fun validateAction(actionType: CarouselActionType, actionTarget: String): Pair<CarouselActionType, String> {
            val trimmedTarget = actionTarget.trim()
            return when (actionType) {
                CarouselActionType.NONE -> CarouselActionType.NONE to ""
                CarouselActionType.INTERNAL_SCREEN,
                CarouselActionType.INTERNAL_ROUTE -> {
                    if (trimmedTarget.isNotBlank()) actionType to trimmedTarget
                    else CarouselActionType.NONE to ""
                }
                CarouselActionType.EXTERNAL_URL -> {
                    if (isSafeExternalUrl(trimmedTarget)) {
                        CarouselActionType.EXTERNAL_URL to trimmedTarget
                    } else {
                        Log.w(TAG, "Unsafe external URL rejected in promotion: '$trimmedTarget'")
                        CarouselActionType.NONE to ""
                    }
                }
            }
        }
    }

    /**
     * Constructs a runtime [CarouselItem] from a [PromotionCampaignDefinition] for a given cycle/year.
     *
     * @param campaign The promotion definition.
     * @param cycleKey The scheduling cycle identifier (typically 4-digit year, e.g. "2026", or "Q1_2026").
     * @param groupId Group scope for the item (defaults to campaign.targetGroupId).
     * @param timeZone Timezone for calculating the activation window.
     * @return [CarouselItem] ready for Firestore persistence, or null if configuration is invalid.
     */
    fun createPromotionCarouselItem(
        campaign: PromotionCampaignDefinition,
        cycleKey: String,
        groupId: Long = campaign.targetGroupId,
        timeZone: TimeZone = TimeZone.getDefault()
    ): CarouselItem? {
        if (!campaign.isEnabled) return null
        if (campaign.id.isBlank() || campaign.title.isBlank() || campaign.message.isBlank()) return null
        if (campaign.startMonth !in 1..12 || campaign.startDay !in 1..31) return null

        // Parse year from cycleKey if possible, otherwise default to current calendar year
        val year = cycleKey.filter { it.isDigit() }.toIntOrNull() ?: Calendar.getInstance(timeZone).get(Calendar.YEAR)

        val cal = Calendar.getInstance(timeZone).apply {
            clear()
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, campaign.startMonth - 1)
            set(Calendar.DAY_OF_MONTH, campaign.startDay)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val startAt = cal.timeInMillis

        // Add duration days for endAt (end of the final day: 23:59:59.999)
        cal.add(Calendar.DAY_OF_MONTH, campaign.durationDays)
        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 59)
        cal.set(Calendar.MILLISECOND, 999)
        val endAt = cal.timeInMillis

        val deterministicId = generateDeterministicId(campaign.id, cycleKey, groupId)
        val (safeActionType, safeActionTarget) = validateAction(campaign.actionType, campaign.actionTarget)

        val formattedMessage = if (campaign.subtitle.isNotBlank()) {
            "${campaign.subtitle} • ${campaign.message}"
        } else {
            campaign.message
        }

        return CarouselItem(
            id = deterministicId,
            groupId = groupId,
            contentType = CarouselContentType.PROMOTION,
            title = campaign.title,
            message = formattedMessage,
            mediaResource = campaign.mediaResource,
            startAt = startAt,
            endAt = endAt,
            isActive = campaign.isEnabled,
            priority = campaign.priority,
            slideDurationSeconds = campaign.slideDurationSeconds,
            actionType = safeActionType,
            actionTarget = safeActionTarget,
            actionLabel = campaign.actionLabel,
            createdBy = "PromotionAutomationService"
        )
    }

    /**
     * Evaluates a promotion catalog for a target calendar year/cycle and idempotently persists
     * scheduled promotional slides into the carousel repository.
     *
     * @param groupId Group scope for items (default: GLOBAL_GROUP_ID for app-wide promotions).
     * @param cycleKey Reference cycle or year string (e.g. "2026").
     * @param catalog Promotion catalog to process (defaults to predefined [PromotionCatalog.defaultPromotions]).
     * @return List of successfully generated/saved CarouselItems.
     */
    suspend fun processPromotionAutomation(
        groupId: Long = GLOBAL_GROUP_ID,
        cycleKey: String = Calendar.getInstance().get(Calendar.YEAR).toString(),
        catalog: List<PromotionCampaignDefinition> = PromotionCatalog.defaultPromotions
    ): List<CarouselItem> = withContext(Dispatchers.IO) {
        val generatedItems = mutableListOf<CarouselItem>()

        for (campaign in catalog) {
            if (!campaign.isEnabled) continue

            val item = createPromotionCarouselItem(
                campaign = campaign,
                cycleKey = cycleKey,
                groupId = groupId
            ) ?: continue

            try {
                val saveResult = carouselRepository.saveCarouselItem(item)
                if (saveResult.isSuccess) {
                    generatedItems.add(item)
                    Log.d(TAG, "Successfully processed promotion item: ${item.id} (groupId=$groupId)")
                } else {
                    Log.w(TAG, "Failed to save promotion item ${item.id}: ${saveResult.exceptionOrNull()?.message}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Exception while saving promotion item ${item.id}: ${e.message}", e)
            }
        }

        generatedItems
    }
}

/**
 * Standard pre-configured promotional catalog templates for Group Ledger.
 */
object PromotionCatalog {
    val ANNUAL_MAINTENANCE_OFFER = PromotionCampaignDefinition(
        id = "ANNUAL_MAINTENANCE_OFFER",
        title = "Annual Maintenance Rebate",
        subtitle = "Save 10% On Advance Payments",
        message = "Pay your annual society maintenance dues in full before March 31 and receive an instant 10% credit.",
        badgeText = "SAVE 10%",
        actionType = CarouselActionType.INTERNAL_SCREEN,
        actionLabel = "Pay Dues",
        actionTarget = "dues",
        priority = PromotionCampaignDefinition.DEFAULT_PROMOTION_PRIORITY,
        durationDays = 90,
        startMonth = 1,
        startDay = 1
    )

    val SPORTS_TOURNAMENT_OFFER = PromotionCampaignDefinition(
        id = "COMMUNITY_SPORTS_TOURNAMENT",
        title = "Society Sports Championship",
        subtitle = "Early Bird Registration Open",
        message = "Register your team for the annual badminton and cricket tournament. Early entries receive a free club jersey.",
        badgeText = "REGISTRATION",
        actionType = CarouselActionType.EXTERNAL_URL,
        actionLabel = "Register Online",
        actionTarget = "https://groupledger.app/events/sports-2026",
        priority = PromotionCampaignDefinition.DEFAULT_PROMOTION_PRIORITY,
        durationDays = 45,
        startMonth = 2,
        startDay = 1
    )

    val GREEN_CAMPUS_INITIATIVE = PromotionCampaignDefinition(
        id = "GREEN_CAMPUS_INITIATIVE",
        title = "Eco-Drive Solar Rebate",
        subtitle = "Zero Installation Charge",
        message = "Support green energy in our community. Inquire about rooftop solar installation with approved subsidy.",
        badgeText = "ECO OFFER",
        actionType = CarouselActionType.INTERNAL_SCREEN,
        actionLabel = "Learn More",
        actionTarget = "announcements",
        priority = PromotionCampaignDefinition.DEFAULT_PROMOTION_PRIORITY,
        durationDays = 60,
        startMonth = 4,
        startDay = 1
    )

    val defaultPromotions: List<PromotionCampaignDefinition> = listOf(
        ANNUAL_MAINTENANCE_OFFER,
        SPORTS_TOURNAMENT_OFFER,
        GREEN_CAMPUS_INITIATIVE
    )
}
