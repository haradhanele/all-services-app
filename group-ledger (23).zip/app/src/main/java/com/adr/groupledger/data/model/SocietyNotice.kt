package com.adr.groupledger.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "society_notices")
data class SocietyNotice(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val groupId: Long = 1,
    val title: String,
    val content: String,
    val category: String = "General", // General, Meeting, Proposal, Rules, Payment, Urgent, Events, Achievement
    val author: String = "Admin",
    val timestamp: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false,
    val isPollEnabled: Boolean = false,
    val pollOptions: String = "In Favor / Yes,Against / No", // comma-separated options
    val pollExpiryDate: Long = 0L, // 0 means no expiry, or unix timestamp
    val pollVotesJson: String = "{}" // JSON map of memberId -> option
) {
    fun getOptionsList(): List<String> {
        return pollOptions.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }

    fun isPollExpired(): Boolean {
        return isPollEnabled && pollExpiryDate > 0L && System.currentTimeMillis() > pollExpiryDate
    }

    fun getVotesMap(): Map<String, String> {
        return try {
            val obj = org.json.JSONObject(pollVotesJson)
            val map = mutableMapOf<String, String>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                map[k] = obj.getString(k)
            }
            map
        } catch (e: Exception) {
            emptyMap()
        }
    }
}

