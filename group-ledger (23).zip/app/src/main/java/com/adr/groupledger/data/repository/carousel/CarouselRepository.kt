package com.adr.groupledger.data.repository.carousel

import com.adr.groupledger.data.model.carousel.CarouselItem
import com.adr.groupledger.data.model.carousel.GLOBAL_GROUP_ID
import kotlinx.coroutines.flow.Flow

/**
 * Repository interface for managing backend-driven carousel content.
 * Cloud Firestore serves as the direct source of truth without local Room database overhead.
 */
interface CarouselRepository {

    /**
     * Streams active, scheduled carousel items for a specific group or globally (groupId = 0L),
     * sorted by priority. Consumed by the Home Screen Dynamic Carousel.
     */
    fun getActiveCarouselItems(groupId: Long = GLOBAL_GROUP_ID): Flow<List<CarouselItem>>

    /**
     * Streams all carousel items for a group or globally (including inactive or scheduled ones).
     * Consumed by Admin Content Management.
     */
    fun getAllCarouselItems(groupId: Long = GLOBAL_GROUP_ID): Flow<List<CarouselItem>>

    /**
     * Fetches a single carousel item by its Firestore document ID.
     */
    suspend fun getCarouselItemById(id: String): CarouselItem?

    /**
     * Creates or updates a carousel item directly in Firestore.
     * Returns the Firestore document ID on success.
     */
    suspend fun saveCarouselItem(item: CarouselItem): Result<String>

    /**
     * Toggles the active status of a carousel item.
     */
    suspend fun setItemActiveStatus(itemId: String, isActive: Boolean): Result<Unit>

    /**
     * Deletes a carousel item document from Firestore.
     */
    suspend fun deleteCarouselItem(itemId: String): Result<Unit>

    /**
     * Updates display priority / ordering weight of a carousel item.
     */
    suspend fun updateItemPriority(itemId: String, priority: Int): Result<Unit>
}
