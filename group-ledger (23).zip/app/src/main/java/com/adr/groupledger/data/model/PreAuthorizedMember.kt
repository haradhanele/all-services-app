package com.adr.groupledger.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "pre_authorized_members",
    indices = [
        Index(value = ["groupId", "email"])
    ]
)
data class PreAuthorizedMember(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val groupId: Long,
    val name: String,
    val email: String,
    val phone: String = "",
    val status: String = "unclaimed", // "unclaimed", "claimed"
    val addedAt: Long = System.currentTimeMillis(),
    val claimedAt: Long? = null,
    val claimedUserId: Long? = null,
    val claimedUid: String = ""
) {
    val isClaimed: Boolean get() = status.equals("claimed", ignoreCase = true)
}
