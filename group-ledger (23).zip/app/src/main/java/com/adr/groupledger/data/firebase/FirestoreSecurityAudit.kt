package com.adr.groupledger.data.firebase

/**
 * Production Security Audit Specification for Cloud Firestore.
 *
 * Defines the 13 canonical Firestore collection paths, scoping constraints,
 * and multi-tenant isolation rules required for production security rule enforcement.
 */
object FirestoreSecurityAudit {

    enum class AccessScope {
        USER_SCOPED,
        GROUP_SCOPED,
        GLOBAL_APP
    }

    enum class RoleRequirement {
        PUBLIC,
        AUTHENTICATED_USER,
        GROUP_MEMBER,
        GROUP_ADMIN,
        GROUP_OWNER,
        APP_ADMIN
    }

    enum class CanonicalPath(
        val template: String,
        val scope: AccessScope,
        val isSubcollection: Boolean,
        val readRequirement: RoleRequirement,
        val writeRequirement: RoleRequirement,
        val description: String
    ) {
        USERS(
            template = "users/{userId}",
            scope = AccessScope.USER_SCOPED,
            isSubcollection = false,
            readRequirement = RoleRequirement.AUTHENTICATED_USER,
            writeRequirement = RoleRequirement.AUTHENTICATED_USER,
            description = "User account profile and authentication metadata"
        ),
        GROUPS(
            template = "groups/{groupId}",
            scope = AccessScope.GROUP_SCOPED,
            isSubcollection = false,
            readRequirement = RoleRequirement.AUTHENTICATED_USER,
            writeRequirement = RoleRequirement.GROUP_ADMIN,
            description = "Group configuration, settings, rules, and owner UID"
        ),
        GROUP_MEMBERS(
            template = "groups/{groupId}/members/{memberId}",
            scope = AccessScope.GROUP_SCOPED,
            isSubcollection = true,
            readRequirement = RoleRequirement.GROUP_MEMBER,
            writeRequirement = RoleRequirement.GROUP_ADMIN,
            description = "Group membership directory with roles and linked UIDs"
        ),
        GROUP_PAYMENTS(
            template = "groups/{groupId}/payments/{paymentId}",
            scope = AccessScope.GROUP_SCOPED,
            isSubcollection = true,
            readRequirement = RoleRequirement.GROUP_MEMBER,
            writeRequirement = RoleRequirement.GROUP_MEMBER,
            description = "Monthly contribution payments, dues, and approval state"
        ),
        GROUP_TRANSACTIONS(
            template = "groups/{groupId}/transactions/{transactionId}",
            scope = AccessScope.GROUP_SCOPED,
            isSubcollection = true,
            readRequirement = RoleRequirement.GROUP_MEMBER,
            writeRequirement = RoleRequirement.GROUP_ADMIN,
            description = "Financial ledger transactions (credit/debit)"
        ),
        GROUP_NOTICES(
            template = "groups/{groupId}/notices/{noticeId}",
            scope = AccessScope.GROUP_SCOPED,
            isSubcollection = true,
            readRequirement = RoleRequirement.GROUP_MEMBER,
            writeRequirement = RoleRequirement.GROUP_MEMBER,
            description = "Society notice board bulletins and poll voting"
        ),
        GROUP_LOANS(
            template = "groups/{groupId}/loans/{loanId}",
            scope = AccessScope.GROUP_SCOPED,
            isSubcollection = true,
            readRequirement = RoleRequirement.GROUP_MEMBER,
            writeRequirement = RoleRequirement.GROUP_MEMBER,
            description = "Member loan requests, voting, disbursals, and repayments"
        ),
        GROUP_MESSAGES(
            template = "groups/{groupId}/messages/{messageId}",
            scope = AccessScope.GROUP_SCOPED,
            isSubcollection = true,
            readRequirement = RoleRequirement.GROUP_MEMBER,
            writeRequirement = RoleRequirement.GROUP_MEMBER,
            description = "Real-time group chat messages and announcements"
        ),
        GROUP_PRE_AUTH(
            template = "groups/{groupId}/preAuthorizedMembers/{preAuthId}",
            scope = AccessScope.GROUP_SCOPED,
            isSubcollection = true,
            readRequirement = RoleRequirement.AUTHENTICATED_USER,
            writeRequirement = RoleRequirement.AUTHENTICATED_USER,
            description = "Roster for atomic member pre-authorization claiming"
        ),
        GROUP_PENDING_REQUESTS(
            template = "groups/{groupId}/pendingRequests/{requestId}",
            scope = AccessScope.GROUP_SCOPED,
            isSubcollection = true,
            readRequirement = RoleRequirement.AUTHENTICATED_USER,
            writeRequirement = RoleRequirement.AUTHENTICATED_USER,
            description = "Pending join requests submitted by invite code applicants"
        ),
        GROUP_FEEDBACKS(
            template = "groups/{groupId}/feedbacks/{feedbackId}",
            scope = AccessScope.GROUP_SCOPED,
            isSubcollection = true,
            readRequirement = RoleRequirement.GROUP_MEMBER,
            writeRequirement = RoleRequirement.GROUP_MEMBER,
            description = "Member feedback, grievances, and admin responses"
        ),
        CAROUSEL_ITEMS(
            template = "carousel_items/{itemId}",
            scope = AccessScope.GLOBAL_APP,
            isSubcollection = false,
            readRequirement = RoleRequirement.PUBLIC,
            writeRequirement = RoleRequirement.APP_ADMIN,
            description = "Promotional hero banners and festival notices"
        ),
        APP_CONFIG(
            template = "app_config/{configId}",
            scope = AccessScope.GLOBAL_APP,
            isSubcollection = false,
            readRequirement = RoleRequirement.PUBLIC,
            writeRequirement = RoleRequirement.APP_ADMIN,
            description = "App version info and mandatory update metadata"
        );

        fun regex(): Regex {
            val pattern = "^" + template
                .replace("{userId}", "([^/]+)")
                .replace("{groupId}", "([^/]+)")
                .replace("{memberId}", "([^/]+)")
                .replace("{paymentId}", "([^/]+)")
                .replace("{transactionId}", "([^/]+)")
                .replace("{noticeId}", "([^/]+)")
                .replace("{loanId}", "([^/]+)")
                .replace("{messageId}", "([^/]+)")
                .replace("{preAuthId}", "([^/]+)")
                .replace("{requestId}", "([^/]+)")
                .replace("{feedbackId}", "([^/]+)")
                .replace("{itemId}", "([^/]+)")
                .replace("{configId}", "([^/]+)") + "$"
            return Regex(pattern)
        }
    }

    /**
     * Total number of canonical paths strictly defined and audited.
     */
    const val CANONICAL_PATH_COUNT = 13

    /**
     * Validates an entity Long ID (must be strictly positive).
     */
    fun isValidId(id: Long): Boolean = id > 0L

    /**
     * Validates an entity String ID (must be non-blank).
     */
    fun isValidId(id: String?): Boolean = !id.isNullOrBlank()

    /**
     * Validates that both the parent groupId and child entityId are valid positive numbers.
     */
    fun validateGroupScoping(groupId: Long, entityId: Long): Boolean =
        isValidId(groupId) && isValidId(entityId)

    /**
     * Checks if a raw Firestore document path strictly conforms to one of the 13 canonical paths.
     */
    fun isCanonicalPath(rawPath: String): Boolean {
        val clean = rawPath.trim().removePrefix("/")
        return CanonicalPath.values().any { it.regex().matches(clean) }
    }

    /**
     * Resolves which canonical path a raw Firestore document path matches, or null if non-canonical.
     */
    fun findMatchingCanonicalPath(rawPath: String): CanonicalPath? {
        val clean = rawPath.trim().removePrefix("/")
        return CanonicalPath.values().firstOrNull { it.regex().matches(clean) }
    }

    /**
     * Builds a concrete document path for a canonical path definition.
     */
    fun buildPath(canonical: CanonicalPath, vararg segments: Any): String {
        require(segments.isNotEmpty()) { "Path segments cannot be empty" }
        return when (canonical) {
            CanonicalPath.USERS -> "users/${segments[0]}"
            CanonicalPath.GROUPS -> "groups/${segments[0]}"
            CanonicalPath.GROUP_MEMBERS -> "groups/${segments[0]}/members/${segments[1]}"
            CanonicalPath.GROUP_PAYMENTS -> "groups/${segments[0]}/payments/${segments[1]}"
            CanonicalPath.GROUP_TRANSACTIONS -> "groups/${segments[0]}/transactions/${segments[1]}"
            CanonicalPath.GROUP_NOTICES -> "groups/${segments[0]}/notices/${segments[1]}"
            CanonicalPath.GROUP_LOANS -> "groups/${segments[0]}/loans/${segments[1]}"
            CanonicalPath.GROUP_MESSAGES -> "groups/${segments[0]}/messages/${segments[1]}"
            CanonicalPath.GROUP_PRE_AUTH -> "groups/${segments[0]}/preAuthorizedMembers/${segments[1]}"
            CanonicalPath.GROUP_PENDING_REQUESTS -> "groups/${segments[0]}/pendingRequests/${segments[1]}"
            CanonicalPath.GROUP_FEEDBACKS -> "groups/${segments[0]}/feedbacks/${segments[1]}"
            CanonicalPath.CAROUSEL_ITEMS -> "carousel_items/${segments[0]}"
            CanonicalPath.APP_CONFIG -> "app_config/${segments[0]}"
        }
    }

    /**
     * Returns all 13 canonical path templates.
     */
    fun getAllCanonicalTemplates(): List<String> =
        CanonicalPath.values().map { it.template }

    /**
     * Returns the complete list of group subcollection names.
     */
    fun getAllGroupSubcollections(): List<String> = listOf(
        "members",
        "payments",
        "transactions",
        "notices",
        "loans",
        "messages",
        "preAuthorizedMembers",
        "pendingRequests",
        "feedbacks"
    )
}
