package com.adr.groupledger.service.storage

import com.adr.groupledger.data.model.carousel.MediaResource
import com.adr.groupledger.data.model.carousel.MediaType
import com.adr.groupledger.data.model.carousel.StorageProviderType
import kotlinx.coroutines.flow.Flow
import java.io.File

/**
 * Encapsulates the states of a media storage operation (upload, deletion, download).
 */
sealed class StorageResult<out T> {
    data class Success<T>(val data: T) : StorageResult<T>()
    data class Progress(val percentage: Float) : StorageResult<Nothing>()
    data class Error(val exception: Throwable, val message: String) : StorageResult<Nothing>()
}

/**
 * Provider-agnostic abstraction for media storage operations.
 * Concrete adapters (Firebase Cloud Storage, Cloudinary, etc.) will implement this interface.
 * UI, ViewModel, and Repository layers only communicate through this interface.
 */
interface MediaStorageService {

    /**
     * Identifies the underlying active storage provider.
     */
    val providerType: StorageProviderType

    /**
     * Uploads a media file (Image or GIF) to the designated logical path.
     * Emits Progress updates followed by Success containing the stored MediaResource metadata.
     */
    fun uploadMedia(
        file: File,
        logicalPath: String,
        mediaType: MediaType,
        customMetadata: Map<String, String> = emptyMap()
    ): Flow<StorageResult<MediaResource>>

    /**
     * Deletes media by its stored reference/path.
     */
    suspend fun deleteMedia(mediaResource: MediaResource): StorageResult<Boolean>

    /**
     * Resolves a public, authenticated, or temporary direct URL for media caching/display.
     */
    suspend fun resolveMediaUrl(mediaResource: MediaResource): String
}

/**
 * Utility for constructing standardized, provider-independent logical paths.
 * The concrete storage adapter will translate this into its own bucket/folder hierarchy.
 */
object LogicalStoragePath {

    private const val ROOT_CAROUSEL = "carousel"

    fun buildCarouselPath(category: String, fileName: String): String {
        val sanitizedCategory = category.trim().lowercase().replace("\\s+".toRegex(), "_")
        val sanitizedFileName = fileName.trim().replace("\\s+".toRegex(), "_")
        return "$ROOT_CAROUSEL/$sanitizedCategory/$sanitizedFileName"
    }

    fun buildBirthdayPath(userId: String, fileName: String): String {
        return "$ROOT_CAROUSEL/birthdays/${userId.trim()}_$fileName"
    }
}
