package com.adr.groupledger.data.model.promotion

import com.adr.groupledger.data.model.carousel.CarouselActionType
import com.adr.groupledger.data.model.carousel.GLOBAL_GROUP_ID
import com.adr.groupledger.data.model.carousel.MediaResource

/**
 * Immutable definition of a promotion, special offer, or call-to-action campaign.
 * Decoupled cleanly from runtime [com.adr.groupledger.data.model.carousel.CarouselItem] entities.
 *
 * Designed to support both global platform-wide campaigns (groupId = GLOBAL_GROUP_ID = 0L)
 * and group-specific promotional offers (groupId > 0L).
 */
data class PromotionCampaignDefinition(
    val id: String,                                        // Campaign identifier e.g. "ANNUAL_MAINTENANCE_OFFER", "EARLY_BIRD_PAYMENT"
    val title: String,                                     // Promotion title / headline
    val subtitle: String = "",                             // Optional promotional subtitle
    val message: String,                                   // Detailed campaign message / value proposition
    val badgeText: String = "OFFER",                       // Badge text e.g. "LIMITED OFFER", "SPECIAL DISCOUNT", "REBATE"
    val mediaResource: MediaResource? = null,              // Optional Cloudinary / CDN media resource
    val actionType: CarouselActionType = CarouselActionType.NONE,
    val actionLabel: String = "",                          // Button label e.g. "Claim Offer", "Pay Now", "Register"
    val actionTarget: String = "",                         // Screen destination, route, or validated HTTP/HTTPS URL
    val priority: Int = DEFAULT_PROMOTION_PRIORITY,        // Default priority (50) ensuring Birthday (120) & Festival (100) take precedence
    val slideDurationSeconds: Int = DEFAULT_SLIDE_DURATION_SECONDS,
    val isEnabled: Boolean = true,
    val targetGroupId: Long = GLOBAL_GROUP_ID,             // 0L = Global app-level promotion; >0L = group-scoped
    val durationDays: Int = 30,                            // Default active duration in days from start date
    val startMonth: Int = 1,                               // 1..12 calendar month
    val startDay: Int = 1                                  // 1..31 day of month
) {
    companion object {
        const val DEFAULT_PROMOTION_PRIORITY = 50
        const val DEFAULT_SLIDE_DURATION_SECONDS = 5
    }
}
