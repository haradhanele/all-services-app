package com.adr.groupledger.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.adr.groupledger.data.model.GroupFeedback
import com.adr.groupledger.data.model.ProposalVote
import kotlinx.coroutines.flow.Flow

@Dao
interface FeedbackDao {
    @Query("SELECT * FROM group_feedbacks WHERE groupId = :groupId ORDER BY createdAt DESC")
    fun getAllFeedbacksFlow(groupId: Long): Flow<List<GroupFeedback>>

    @Query("SELECT * FROM group_feedbacks WHERE groupId = :groupId AND type = :type ORDER BY createdAt DESC")
    fun getFeedbacksByTypeFlow(groupId: Long, type: String): Flow<List<GroupFeedback>>

    @Query("SELECT * FROM group_feedbacks WHERE id = :id")
    suspend fun getFeedbackById(id: Long): GroupFeedback?

    @Query("SELECT * FROM group_feedbacks WHERE id = :id")
    fun getFeedbackByIdFlow(id: Long): Flow<GroupFeedback?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFeedback(feedback: GroupFeedback): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFeedbacks(feedbacks: List<GroupFeedback>)

    @Update
    suspend fun updateFeedback(feedback: GroupFeedback)

    @Query("DELETE FROM group_feedbacks WHERE id = :id")
    suspend fun deleteFeedbackById(id: Long)

    @Query("DELETE FROM group_feedbacks WHERE groupId = :groupId")
    suspend fun deleteFeedbacksForGroup(groupId: Long)

    // Proposal votes
    @Query("SELECT * FROM proposal_votes WHERE feedbackId = :feedbackId")
    fun getVotesForProposalFlow(feedbackId: Long): Flow<List<ProposalVote>>

    @Query("SELECT * FROM proposal_votes WHERE feedbackId = :feedbackId")
    suspend fun getVotesForProposal(feedbackId: Long): List<ProposalVote>

    @Query("SELECT * FROM proposal_votes WHERE feedbackId = :feedbackId AND memberId = :memberId LIMIT 1")
    suspend fun getUserVote(feedbackId: Long, memberId: Long): ProposalVote?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProposalVote(vote: ProposalVote): Long

    @Query("DELETE FROM proposal_votes WHERE feedbackId = :feedbackId AND memberId = :memberId")
    suspend fun deleteProposalVote(feedbackId: Long, memberId: Long)
}
