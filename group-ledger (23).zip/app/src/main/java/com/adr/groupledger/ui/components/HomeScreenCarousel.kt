package com.adr.groupledger.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder
import coil.request.ImageRequest
import com.adr.groupledger.data.model.carousel.CarouselActionType
import com.adr.groupledger.data.model.carousel.CarouselContentType
import com.adr.groupledger.data.model.carousel.CarouselItem
import com.adr.groupledger.data.model.carousel.MediaType
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

private const val TAG = "HomeScreenCarousel"
private const val DEFAULT_SLIDE_DURATION_SECONDS = 5

/**
 * Phase 7: Backend-Driven Dynamic Home Screen Carousel.
 *
 * Displays active [CarouselItem]s streamed directly from Firestore via CarouselRepository / ViewModel.
 *
 * ARCHITECTURAL FEATURES:
 * 1. Read-Only Consumer: Exposes zero administrative or mutating controls.
 * 2. Real-Time & Scheduled: Renders only active items respecting startAt, endAt, and isActive.
 * 3. Media Agnostic: Seamlessly presents static images, animated GIFs (with preserved playback), and text-only fallbacks.
 * 4. Safe CTA Actions: Handles NONE, INTERNAL_SCREEN, INTERNAL_ROUTE, and safely validated EXTERNAL_URL schemes.
 * 5. Lifecycle-Aware Auto-Slide: Automatically advances slides per slideDurationSeconds, pausing during user touch/drag.
 * 6. Empty-Safe: Completely hidden if no active carousel items exist, leaving the rest of the Home Screen intact.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreenCarousel(
    items: List<CarouselItem>,
    modifier: Modifier = Modifier,
    onNavigateToRoute: (String) -> Unit = {},
    onNavigateToScreen: (String) -> Unit = {},
    onItemClick: ((CarouselItem) -> Unit)? = null
) {
    val currentTime = System.currentTimeMillis()
    // 1. Filter currently active items and order strictly by descending priority
    val activeItems = remember(items, currentTime) {
        items.filter { it.isCurrentlyActive(currentTime) }
            .sortedByDescending { it.priority }
    }

    // 2. Empty State: Never render a broken or empty container
    if (activeItems.isEmpty()) {
        return
    }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // 3. Coil ImageLoader with animated GIF support (API 28+ ImageDecoder and GifDecoder)
    val imageLoader = remember(context) {
        ImageLoader.Builder(context)
            .components {
                if (Build.VERSION.SDK_INT >= 28) {
                    add(ImageDecoderDecoder.Factory())
                } else {
                    add(GifDecoder.Factory())
                }
            }
            .crossfade(true)
            .build()
    }

    // 4. Horizontal Pager State
    val pagerState = rememberPagerState(
        initialPage = 0,
        pageCount = { activeItems.size }
    )

    // User interaction tracking to pause auto-advancement
    var isUserInteracting by remember { mutableStateOf(false) }

    // 5. Lifecycle-aware Auto-Advancement Coroutine
    LaunchedEffect(pagerState.currentPage, activeItems, isUserInteracting, pagerState.isScrollInProgress) {
        if (activeItems.size > 1 && !isUserInteracting && !pagerState.isScrollInProgress) {
            val currentSlide = activeItems.getOrNull(pagerState.currentPage)
            val durationSec = currentSlide?.slideDurationSeconds?.takeIf { it > 0 } ?: DEFAULT_SLIDE_DURATION_SECONDS
            
            // Wait for the slide duration before advancing
            delay(durationSec * 1000L)
            
            if (isActive && !isUserInteracting && !pagerState.isScrollInProgress && activeItems.size > 1) {
                val nextPage = (pagerState.currentPage + 1) % activeItems.size
                pagerState.animateScrollToPage(
                    page = nextPage,
                    animationSpec = tween(durationMillis = 600)
                )
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("home_screen_carousel")
    ) {
        // Main Pager Container
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .clip(RoundedCornerShape(16.dp))
                .pointerInput(Unit) {
                    detectTapGestures(
                        onPress = {
                            isUserInteracting = true
                            tryAwaitRelease()
                            isUserInteracting = false
                        }
                    )
                }
        ) {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("home_carousel_pager"),
                key = { pageIndex ->
                    activeItems.getOrNull(pageIndex)?.id ?: pageIndex.toString()
                }
            ) { pageIndex ->
                val slide = activeItems.getOrNull(pageIndex)
                if (slide != null) {
                    CarouselSlideItem(
                        slide = slide,
                        imageLoader = imageLoader,
                        onSlideClick = {
                            if (onItemClick != null) {
                                onItemClick(slide)
                            } else {
                                handleCarouselAction(
                                    context = context,
                                    item = slide,
                                    onNavigateToRoute = onNavigateToRoute,
                                    onNavigateToScreen = onNavigateToScreen
                                )
                            }
                        },
                        onCtaClick = {
                            handleCarouselAction(
                                context = context,
                                item = slide,
                                onNavigateToRoute = onNavigateToRoute,
                                onNavigateToScreen = onNavigateToScreen
                            )
                        }
                    )
                }
            }
        }

        // Indicators (rendered when more than 1 slide exists)
        if (activeItems.size > 1) {
            Spacer(modifier = Modifier.height(8.dp))
            CarouselPageIndicators(
                pagerState = pagerState,
                pageCount = activeItems.size,
                onSelectPage = { targetPage ->
                    coroutineScope.launch {
                        pagerState.animateScrollToPage(targetPage)
                    }
                },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }
    }
}

/**
 * Individual Carousel Slide Card.
 * Renders media (Image / Animated GIF) or text-only fallback with high-contrast text overlay.
 */
@Composable
private fun CarouselSlideItem(
    slide: CarouselItem,
    imageLoader: ImageLoader,
    onSlideClick: () -> Unit,
    onCtaClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val hasMedia = slide.mediaResource != null && slide.mediaResource.publicUrl.isNotBlank()
    val badgeInfo = getContentTypeBadgeInfo(slide.contentType)

    Card(
        modifier = modifier
            .fillMaxSize()
            .clickable(onClick = onSlideClick)
            .testTag("home_carousel_card_${slide.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            if (hasMedia) {
                // Media Layer (Image or Animated GIF via Coil)
                AsyncImage(
                    model = ImageRequest.Builder(context)
                        .data(slide.mediaResource!!.publicUrl)
                        .crossfade(true)
                        .build(),
                    imageLoader = imageLoader,
                    contentDescription = slide.title.ifBlank { "Announcement banner" },
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("home_carousel_image_${slide.id}"),
                    contentScale = ContentScale.Crop
                )

                // High-contrast Gradient Scrim
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Black.copy(alpha = 0.25f),
                                    Color.Black.copy(alpha = 0.50f),
                                    Color.Black.copy(alpha = 0.88f)
                                )
                            )
                        )
                )
            } else {
                // Text-Only Fallback Background
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                colors = badgeInfo.gradientColors
                            )
                        )
                )
            }

            // Slide Content Layout
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Row: Content Type Badge + Animated GIF indicator
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Content Type Badge
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = badgeInfo.badgeColor.copy(alpha = 0.92f)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = badgeInfo.icon,
                                contentDescription = badgeInfo.label,
                                tint = Color.White,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = badgeInfo.label,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 10.sp
                                ),
                                color = Color.White
                            )
                        }
                    }

                    // Optional GIF Pill Indicator
                    if (slide.isAnimatedMedia) {
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.20f)
                        ) {
                            Text(
                                text = "GIF",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                // Bottom Area: Title, Message & CTA
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = slide.title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        ),
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    if (slide.message.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = slide.message,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            ),
                            color = Color.White.copy(alpha = 0.90f),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Call-to-Action (CTA) Button
                    if (slide.actionType != CarouselActionType.NONE) {
                        val ctaLabel = slide.actionLabel.ifBlank {
                            when (slide.actionType) {
                                CarouselActionType.EXTERNAL_URL -> "Visit Link"
                                CarouselActionType.INTERNAL_SCREEN,
                                CarouselActionType.INTERNAL_ROUTE -> "View Details"
                                else -> "Open"
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Button(
                                onClick = onCtaClick,
                                modifier = Modifier
                                    .height(34.dp)
                                    .testTag("home_carousel_cta_${slide.id}"),
                                shape = RoundedCornerShape(18.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = badgeInfo.ctaButtonColor,
                                    contentColor = Color.White
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                            ) {
                                Text(
                                    text = ctaLabel,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = if (slide.actionType == CarouselActionType.EXTERNAL_URL) {
                                        Icons.Default.OpenInNew
                                    } else {
                                        Icons.AutoMirrored.Filled.ArrowForward
                                    },
                                    contentDescription = null,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Clickable Page Indicator Dots with animated expansion for the selected page.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CarouselPageIndicators(
    pagerState: PagerState,
    pageCount: Int,
    onSelectPage: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (page in 0 until pageCount) {
            val isSelected = pagerState.currentPage == page

            val width by animateDpAsState(
                targetValue = if (isSelected) 18.dp else 6.dp,
                animationSpec = tween(durationMillis = 300),
                label = "indicatorWidth"
            )
            val color by animateColorAsState(
                targetValue = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                animationSpec = tween(durationMillis = 300),
                label = "indicatorColor"
            )

            Box(
                modifier = Modifier
                    .size(width = width, height = 6.dp)
                    .clip(CircleShape)
                    .background(color)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        role = Role.Tab,
                        onClick = { onSelectPage(page) }
                    )
                    .semantics {
                        contentDescription = "Slide ${page + 1} of $pageCount"
                    }
                    .testTag("home_carousel_indicator_$page")
            )
        }
    }
}

/**
 * Handles Call-To-Action (CTA) navigation with strict URL validation for external links.
 */
fun handleCarouselAction(
    context: Context,
    item: CarouselItem,
    onNavigateToRoute: (String) -> Unit,
    onNavigateToScreen: (String) -> Unit
) {
    when (item.actionType) {
        CarouselActionType.NONE -> {
            // No action
        }
        CarouselActionType.INTERNAL_SCREEN -> {
            val target = item.actionTarget.trim()
            if (target.isNotEmpty()) {
                onNavigateToScreen(target)
            }
        }
        CarouselActionType.INTERNAL_ROUTE -> {
            val target = item.actionTarget.trim()
            if (target.isNotEmpty()) {
                onNavigateToRoute(target)
            }
        }
        CarouselActionType.EXTERNAL_URL -> {
            val url = item.actionTarget.trim()
            if (isSafeExternalUrl(url)) {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to launch browser intent for URL: $url", e)
                }
            } else {
                Log.w(TAG, "Blocked unsafe or unsupported external URL: $url")
            }
        }
    }
}

/**
 * Validates that an external URL strictly begins with https:// or http:// and contains a valid host.
 * Protects against arbitrary intent actions or unsafe schemes (e.g. javascript:, file:, content:).
 */
fun isSafeExternalUrl(url: String): Boolean {
    val trimmed = url.trim()
    if (trimmed.isEmpty()) return false
    val lower = trimmed.lowercase()
    if (!lower.startsWith("https://") && !lower.startsWith("http://")) {
        return false
    }
    return try {
        val uri = Uri.parse(trimmed)
        val scheme = uri.scheme?.lowercase()
        (scheme == "https" || scheme == "http") && !uri.host.isNullOrBlank()
    } catch (e: Exception) {
        false
    }
}

/**
 * Content type visual styling metadata.
 */
private data class ContentTypeBadgeInfo(
    val label: String,
    val icon: ImageVector,
    val badgeColor: Color,
    val ctaButtonColor: Color,
    val gradientColors: List<Color>
)

private fun getContentTypeBadgeInfo(contentType: CarouselContentType): ContentTypeBadgeInfo {
    return when (contentType) {
        CarouselContentType.CELEBRATION -> ContentTypeBadgeInfo(
            label = "Celebration",
            icon = Icons.Default.EmojiEvents,
            badgeColor = Color(0xFFD97706),
            ctaButtonColor = Color(0xFFB45309),
            gradientColors = listOf(Color(0xFF78350F), Color(0xFFB45309), Color(0xFFD97706))
        )
        CarouselContentType.FESTIVAL -> ContentTypeBadgeInfo(
            label = "Festival Greeting",
            icon = Icons.Default.AutoAwesome,
            badgeColor = Color(0xFFE11D48),
            ctaButtonColor = Color(0xFFBE123C),
            gradientColors = listOf(Color(0xFF881337), Color(0xFFBE123C), Color(0xFFE11D48))
        )
        CarouselContentType.BIRTHDAY -> ContentTypeBadgeInfo(
            label = "Birthday Wishes",
            icon = Icons.Default.Cake,
            badgeColor = Color(0xFF7C3AED),
            ctaButtonColor = Color(0xFF6D28D9),
            gradientColors = listOf(Color(0xFF4C1D95), Color(0xFF6D28D9), Color(0xFF7C3AED))
        )
        CarouselContentType.ANNOUNCEMENT -> ContentTypeBadgeInfo(
            label = "Announcement",
            icon = Icons.Default.Campaign,
            badgeColor = Color(0xFF059669),
            ctaButtonColor = Color(0xFF047857),
            gradientColors = listOf(Color(0xFF064E3B), Color(0xFF047857), Color(0xFF059669))
        )
        CarouselContentType.PROMOTION,
        CarouselContentType.OFFER -> ContentTypeBadgeInfo(
            label = "Special Offer",
            icon = Icons.Default.LocalOffer,
            badgeColor = Color(0xFFEA580C),
            ctaButtonColor = Color(0xFFC2410C),
            gradientColors = listOf(Color(0xFF7C2D12), Color(0xFFC2410C), Color(0xFFEA580C))
        )
        CarouselContentType.OTHER -> ContentTypeBadgeInfo(
            label = "Update",
            icon = Icons.Default.Info,
            badgeColor = Color(0xFF2563EB),
            ctaButtonColor = Color(0xFF1D4ED8),
            gradientColors = listOf(Color(0xFF1E3A8A), Color(0xFF1D4ED8), Color(0xFF2563EB))
        )
    }
}
