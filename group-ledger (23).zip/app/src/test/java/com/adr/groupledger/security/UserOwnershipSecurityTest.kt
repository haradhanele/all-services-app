package com.adr.groupledger.security

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.adr.groupledger.data.firebase.FirebaseService
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.UserAccount
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Phase 11 — Task 5: UID vs Numeric ID Ownership Validation Test Suite
 *
 * Verifies:
 * 1. Group documents must strictly carry valid, non-blank Firebase Auth UIDs (ownerUid / creatorUid).
 * 2. Ownership checks compare Firebase auth.uid string accurately against the group's ownerUid.
 * 3. A foreign auth.uid is rejected as an unauthorized owner.
 * 4. Conversion/mapping between numeric userId and string auth.uid maintains consistency without data loss.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class UserOwnershipSecurityTest {

    private lateinit var context: Context
    private lateinit var firebaseService: FirebaseService

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        firebaseService = FirebaseService(context)
    }

    @Test
    fun test1_GroupDocuments_MustStrictlyCarryValidNonBlankAuthUid() = runBlocking {
        val validUid = "firebase_auth_owner_101"
        val group = GroupSettings(
            id = 501L,
            groupName = "Verified Owner Group",
            inviteCode = "OWN501",
            createdByUserId = 101L,
            ownerUid = validUid
        )

        // Verify that ownerUid and creatorUid alias are strictly non-blank and identical
        assertTrue("Group ownerUid must not be blank", group.ownerUid.isNotBlank())
        assertEquals("Group creatorUid alias must equal ownerUid", validUid, group.creatorUid)
        assertEquals("Group ownerUid must strictly match assigned UID", validUid, group.ownerUid)

        // Attempting to provision a group with blank ownerUid and invalid createdByUserId must be rejected
        val invalidGroup = GroupSettings(
            id = 502L,
            groupName = "Invalid Group",
            inviteCode = "INV502",
            createdByUserId = 0L,
            ownerUid = ""
        )
        val adminMember = Member(
            id = 1L,
            groupId = 502L,
            name = "Admin"
        )
        val provisionResult = firebaseService.provisionGroupSequentially(invalidGroup, adminMember)
        assertFalse("Provisioning group with blank ownerUid and non-positive creator ID must be rejected", provisionResult)
    }

    @Test
    fun test2_OwnershipCheck_ComparesAuthUidAccuratelyAgainstGroupOwnerUid() {
        val legitimateOwnerUid = "usr_google_auth_987654"
        val group = GroupSettings(
            id = 701L,
            groupName = "Precision Ownership Society",
            inviteCode = "PRC701",
            createdByUserId = 77L,
            ownerUid = legitimateOwnerUid
        )

        // Exact match check
        val isOwner = firebaseService.verifyGroupOwnership(group, legitimateOwnerUid)
        assertTrue("Authenticated user with matching auth.uid must be verified as owner", isOwner)

        // Whitespace-padded authUid should also resolve correctly after trimming
        val paddedAuthUid = "  $legitimateOwnerUid  "
        val isOwnerPadded = firebaseService.verifyGroupOwnership(group, paddedAuthUid)
        assertTrue("Trimmed auth.uid matching ownerUid must verify as legitimate owner", isOwnerPadded)
    }

    @Test
    fun test3_ForeignAuthUid_StrictlyRejectedAsUnauthorizedOwner() {
        val legitimateOwnerUid = "owner_uid_legit_111"
        val foreignIntruderUid = "intruder_uid_foreign_999"

        val group = GroupSettings(
            id = 801L,
            groupName = "Secure Multi-Tenant Group",
            inviteCode = "TEN801",
            createdByUserId = 11L,
            ownerUid = legitimateOwnerUid
        )

        // Verify foreign intruder is rejected
        val isIntruderOwner = firebaseService.verifyGroupOwnership(group, foreignIntruderUid)
        assertFalse("Foreign auth.uid must be rejected as an unauthorized owner", isIntruderOwner)

        // Null and blank UIDs must be rejected
        assertFalse("Null auth.uid must be rejected", firebaseService.verifyGroupOwnership(group, null))
        assertFalse("Empty auth.uid must be rejected", firebaseService.verifyGroupOwnership(group, ""))
        assertFalse("Blank whitespace-only auth.uid must be rejected", firebaseService.verifyGroupOwnership(group, "   "))
    }

    @Test
    fun test4_ConversionMapping_BetweenNumericUserIdAndStringAuthUid_MaintainsConsistency() {
        val numericId = 42L
        val stringAuthUid = "firebase_auth_user_42"

        val user = UserAccount(
            id = numericId,
            fullName = "Multi-Format User",
            email = "user42@example.com"
        )

        val group = GroupSettings(
            id = 901L,
            groupName = "Bimodal Identity Group",
            inviteCode = "BIM901",
            createdByUserId = user.id,
            ownerUid = stringAuthUid
        )

        // Verify consistency across representations
        assertEquals("Numeric creator ID must match user.id", numericId, group.createdByUserId)
        assertEquals("String ownerUid must match stringAuthUid", stringAuthUid, group.ownerUid)
        assertNotEquals("String auth.uid must not be inadvertently coerced to a blank value", "", group.ownerUid)

        // Verify numeric fallback mapping consistency:
        // If a system queries by stringified numeric user id "42" alongside the numericUserId argument
        val verifiedByNumericMapping = firebaseService.verifyGroupOwnership(
            group = group,
            authUid = numericId.toString(),
            numericUserId = numericId
        )
        assertTrue("Numeric ID conversion to string representation must maintain verified ownership consistency", verifiedByNumericMapping)

        // Mismatched numeric userId must be rejected
        val mismatchedNumeric = firebaseService.verifyGroupOwnership(
            group = group,
            authUid = "999",
            numericUserId = 999L
        )
        assertFalse("Mismatched numeric ID must be rejected as owner", mismatchedNumeric)
    }

    @Test
    fun test5_DocumentPayloadCarriesBothOwnerUidAndNumericCreatorId() {
        val authUid = "auth_uid_payload_test"
        val numericId = 123L
        val group = GroupSettings(
            id = 1001L,
            groupName = "Payload Test Group",
            createdByUserId = numericId,
            ownerUid = authUid
        )

        // Build simulated Firestore map representation as done in FirebaseService.saveGroup
        val payload = hashMapOf(
            "id" to group.id,
            "groupName" to group.groupName,
            "createdByUserId" to group.createdByUserId,
            "ownerUid" to group.ownerUid,
            "creatorUid" to group.creatorUid
        )

        assertEquals("Payload must contain correct numeric createdByUserId", numericId, payload["createdByUserId"])
        assertEquals("Payload must contain string ownerUid", authUid, payload["ownerUid"])
        assertEquals("Payload must contain string creatorUid for backward/rule compatibility", authUid, payload["creatorUid"])
    }
}
