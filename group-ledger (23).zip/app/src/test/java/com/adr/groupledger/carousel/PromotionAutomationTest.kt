package com.adr.groupledger.carousel

import com.adr.groupledger.data.model.AppRole
import com.adr.groupledger.data.model.GroupRole
import com.adr.groupledger.data.model.carousel.CarouselActionType
import com.adr.groupledger.data.model.carousel.CarouselContentType
import com.adr.groupledger.data.model.carousel.CarouselItem
import com.adr.groupledger.data.model.carousel.GLOBAL_GROUP_ID
import com.adr.groupledger.data.model.carousel.MediaResource
import com.adr.groupledger.data.model.carousel.MediaType
import com.adr.groupledger.data.model.promotion.PromotionCampaignDefinition
import com.adr.groupledger.data.repository.carousel.InMemoryCarouselRepository
import com.adr.groupledger.service.birthday.BirthdayAutomationService
import com.adr.groupledger.service.festival.FestivalAutomationService
import com.adr.groupledger.service.promotion.PromotionAutomationService
import com.adr.groupledger.service.promotion.PromotionCatalog
import com.adr.groupledger.ui.components.isSafeExternalUrl
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.Calendar
import java.util.TimeZone

/**
 * Comprehensive verification test suite for Phase 10: Promotion / Offer / CTA Automation.
 *
 * Verifies:
 * 1.  Deterministic promotion ID convention strictly: PROMO_<groupId>_<campaignKey>_<cycleKey>
 * 2.  Global scope uses GLOBAL_GROUP_ID (0L): e.g. PROMO_0_ANNUAL_MAINTENANCE_OFFER_2026
 * 3.  Group scope uses concrete groupId: e.g. PROMO_101_EARLY_BIRD_PAYMENT_2026
 * 4.  Idempotency: Re-running promotion synchronization does not duplicate items.
 * 5.  Safe URL validation: Rejects unsafe schemes (javascript:, file:, content:, intent:) and permits only http, https.
 * 6.  CTA Action validation: Correctly handles NONE, INTERNAL_SCREEN, INTERNAL_ROUTE, EXTERNAL_URL.
 * 7.  Role Isolation: Group Admin alone CANNOT manage carousel content (canManageCarousel = false).
 * 8.  Role Authorization: APP_ADMIN and CONTENT_MANAGER can manage carousel content (canManageCarousel = true).
 * 9.  Priority ordering: Birthday (120) > Festival (100) > Promotion (50) > Routine Announcements (30).
 * 10. Carousel co-existence: Birthday, Festival, and Promotion items coexist in the single carousel stream without interference.
 * 11. Media compatibility: MediaResource is preserved and text-only fallback works properly.
 * 12. Active scheduling window: startAt is 00:00:00.000, endAt is 23:59:59.999.
 * 13. Disabled campaign is not generated.
 * 14. Invalid campaign definition is safely ignored.
 * 15. Timezone stability: startAt and endAt calculate consistently without drift.
 */
@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class PromotionAutomationTest {

    private lateinit var repository: InMemoryCarouselRepository
    private lateinit var promotionService: PromotionAutomationService
    private lateinit var festivalService: FestivalAutomationService

    @Before
    fun setUp() {
        InMemoryCarouselRepository.clearAllForTesting()
        repository = InMemoryCarouselRepository.getInstance()
        promotionService = PromotionAutomationService(repository)
        festivalService = FestivalAutomationService(repository)
    }

    @Test
    fun testDeterministicIdFormat_GlobalScope() {
        val id = PromotionAutomationService.generateDeterministicId(
            campaignKey = "annual_maintenance_offer",
            cycleKey = "2026",
            groupId = GLOBAL_GROUP_ID
        )
        assertEquals("PROMO_0_ANNUAL_MAINTENANCE_OFFER_2026", id)
    }

    @Test
    fun testDeterministicIdFormat_GroupScoped() {
        val id = PromotionAutomationService.generateDeterministicId(
            campaignKey = "early_bird_payment",
            cycleKey = "2026",
            groupId = 101L
        )
        assertEquals("PROMO_101_EARLY_BIRD_PAYMENT_2026", id)
    }

    @Test
    fun testSafeUrlValidation_RejectsUnsafeSchemes() {
        assertFalse(isSafeExternalUrl("javascript:alert(1)"))
        assertFalse(isSafeExternalUrl("file:///android_asset/secret.txt"))
        assertFalse(isSafeExternalUrl("content://media/external/images/media/1"))
        assertFalse(isSafeExternalUrl("intent://host/#Intent;action=android.intent.action.VIEW;end"))
        assertFalse(isSafeExternalUrl("data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg=="))
        assertFalse(isSafeExternalUrl(""))
        assertFalse(isSafeExternalUrl("ftp://ftp.example.com/file.zip"))
        assertFalse(isSafeExternalUrl("not-a-url"))

        // Safe schemes: http and https with valid host
        assertTrue(isSafeExternalUrl("https://groupledger.app/offers"))
        assertTrue(isSafeExternalUrl("http://society-portal.org/dues"))
        assertTrue(isSafeExternalUrl("https://subdomain.example.com/pay?amount=100"))
    }

    @Test
    fun testPromotionAutomationService_ValidateAction() {
        // Safe external URL
        val (type1, target1) = PromotionAutomationService.validateAction(
            CarouselActionType.EXTERNAL_URL,
            "https://groupledger.app/promo"
        )
        assertEquals(CarouselActionType.EXTERNAL_URL, type1)
        assertEquals("https://groupledger.app/promo", target1)

        // Unsafe external URL falls back to NONE
        val (type2, target2) = PromotionAutomationService.validateAction(
            CarouselActionType.EXTERNAL_URL,
            "javascript:void(0)"
        )
        assertEquals(CarouselActionType.NONE, type2)
        assertEquals("", target2)

        // Internal screen
        val (type3, target3) = PromotionAutomationService.validateAction(
            CarouselActionType.INTERNAL_SCREEN,
            "dues"
        )
        assertEquals(CarouselActionType.INTERNAL_SCREEN, type3)
        assertEquals("dues", target3)

        // Internal route
        val (type4, target4) = PromotionAutomationService.validateAction(
            CarouselActionType.INTERNAL_ROUTE,
            "payments/history"
        )
        assertEquals(CarouselActionType.INTERNAL_ROUTE, type4)
        assertEquals("payments/history", target4)
    }

    @Test
    fun testRoleArchitecture_StrictIsolation() {
        // Group Admin alone does NOT have carousel management privileges
        val groupAdminRole = GroupRole.ADMIN
        val regularUserAppRole = AppRole.REGULAR_USER
        assertFalse("Group Admin with default AppRole.REGULAR_USER must not have carousel access", regularUserAppRole.canManageCarousel)

        // Only authorized App Roles have management privileges
        assertTrue("APP_ADMIN must have carousel management privileges", AppRole.APP_ADMIN.canManageCarousel)
        assertTrue("CONTENT_MANAGER must have carousel management privileges", AppRole.CONTENT_MANAGER.canManageCarousel)
        assertFalse("REGULAR_USER must be denied carousel management privileges", AppRole.REGULAR_USER.canManageCarousel)
    }

    @Test
    fun testPromotionAutomation_IdempotencyAndNoDuplicates() = runTest {
        // Run promotion sync once
        val run1 = promotionService.processPromotionAutomation(
            groupId = GLOBAL_GROUP_ID,
            cycleKey = "2026",
            catalog = PromotionCatalog.defaultPromotions
        )
        assertTrue(run1.isNotEmpty())
        val countAfterRun1 = repository.getAllCarouselItems(GLOBAL_GROUP_ID).first().size

        // Run promotion sync a second time
        val run2 = promotionService.processPromotionAutomation(
            groupId = GLOBAL_GROUP_ID,
            cycleKey = "2026",
            catalog = PromotionCatalog.defaultPromotions
        )
        val countAfterRun2 = repository.getAllCarouselItems(GLOBAL_GROUP_ID).first().size

        // Exactly identical count: duplicate prevention guaranteed by deterministic IDs
        assertEquals("Subsequent sync must not create duplicate promotion items", countAfterRun1, countAfterRun2)
    }

    @Test
    fun testPromotionItemAttributesAndSchedulingWindow() {
        val testTz = TimeZone.getTimeZone("UTC")
        val promoDef = PromotionCampaignDefinition(
            id = "SUMMER_FEE_DISCOUNT",
            title = "Summer Fee Rebate",
            subtitle = "Special 5% Off",
            message = "Early payment discount for Q2 society maintenance",
            badgeText = "DISCOUNT",
            actionType = CarouselActionType.INTERNAL_SCREEN,
            actionLabel = "Pay Now",
            actionTarget = "dues",
            priority = 50,
            durationDays = 30,
            startMonth = 4,
            startDay = 1
        )

        val item = promotionService.createPromotionCarouselItem(
            campaign = promoDef,
            cycleKey = "2026",
            groupId = GLOBAL_GROUP_ID,
            timeZone = testTz
        )

        assertNotNull(item)
        assertEquals("PROMO_0_SUMMER_FEE_DISCOUNT_2026", item?.id)
        assertEquals(GLOBAL_GROUP_ID, item?.groupId)
        assertEquals(CarouselContentType.PROMOTION, item?.contentType)
        assertEquals("Summer Fee Rebate", item?.title)
        assertEquals("Special 5% Off • Early payment discount for Q2 society maintenance", item?.message)
        assertEquals(50, item?.priority)
        assertEquals(CarouselActionType.INTERNAL_SCREEN, item?.actionType)
        assertEquals("dues", item?.actionTarget)
        assertEquals("Pay Now", item?.actionLabel)

        // Verify startAt is at 00:00:00.000 on April 1, 2026 UTC
        val startCal = Calendar.getInstance(testTz).apply { timeInMillis = item!!.startAt }
        assertEquals(2026, startCal.get(Calendar.YEAR))
        assertEquals(Calendar.APRIL, startCal.get(Calendar.MONTH))
        assertEquals(1, startCal.get(Calendar.DAY_OF_MONTH))
        assertEquals(0, startCal.get(Calendar.HOUR_OF_DAY))
        assertEquals(0, startCal.get(Calendar.MINUTE))
        assertEquals(0, startCal.get(Calendar.SECOND))
        assertEquals(0, startCal.get(Calendar.MILLISECOND))

        // Verify endAt is at 23:59:59.999 after 30 days
        val endCal = Calendar.getInstance(testTz).apply { timeInMillis = item!!.endAt }
        assertEquals(2026, endCal.get(Calendar.YEAR))
        assertEquals(Calendar.MAY, endCal.get(Calendar.MONTH))
        assertEquals(1, endCal.get(Calendar.DAY_OF_MONTH))
        assertEquals(23, endCal.get(Calendar.HOUR_OF_DAY))
        assertEquals(59, endCal.get(Calendar.MINUTE))
        assertEquals(59, endCal.get(Calendar.SECOND))
        assertEquals(999, endCal.get(Calendar.MILLISECOND))
    }

    @Test
    fun testPromotionDisabledOrInvalidIgnored() {
        val disabledPromo = PromotionCampaignDefinition(
            id = "DISABLED_PROMO",
            title = "Inactive Promotion",
            message = "Should not be created",
            isEnabled = false
        )
        assertNull(promotionService.createPromotionCarouselItem(disabledPromo, "2026"))

        val invalidMonthPromo = PromotionCampaignDefinition(
            id = "INVALID_MONTH",
            title = "Invalid Month",
            message = "Month 13 is invalid",
            startMonth = 13
        )
        assertNull(promotionService.createPromotionCarouselItem(invalidMonthPromo, "2026"))

        val blankTitlePromo = PromotionCampaignDefinition(
            id = "BLANK_TITLE",
            title = "",
            message = "Blank title"
        )
        assertNull(promotionService.createPromotionCarouselItem(blankTitlePromo, "2026"))
    }

    @Test
    fun testPriorityHierarchyAndCoexistence() = runTest {
        val now = System.currentTimeMillis()

        // 1. Birthday item (Priority 120)
        val birthdayItem = CarouselItem(
            id = "BIRTHDAY_101_5",
            groupId = 101L,
            contentType = CarouselContentType.BIRTHDAY,
            title = "Happy Birthday, Alice!",
            message = "Wishing Alice a fantastic day!",
            startAt = now - 1000,
            endAt = now + 100000,
            priority = 120,
            isActive = true
        )

        // 2. Festival item (Priority 100)
        val festivalItem = CarouselItem(
            id = "FESTIVAL_DIWALI_2026",
            groupId = GLOBAL_GROUP_ID,
            contentType = CarouselContentType.FESTIVAL,
            title = "Happy Diwali!",
            message = "Wishing you peace and prosperity",
            startAt = now - 1000,
            endAt = now + 100000,
            priority = 100,
            isActive = true
        )

        // 3. Promotion item (Priority 50)
        val promoItem = CarouselItem(
            id = "PROMO_0_ANNUAL_MAINTENANCE_OFFER_2026",
            groupId = GLOBAL_GROUP_ID,
            contentType = CarouselContentType.PROMOTION,
            title = "Annual Maintenance Rebate",
            message = "Save 10% on early payment",
            startAt = now - 1000,
            endAt = now + 100000,
            priority = 50,
            isActive = true
        )

        // 4. Routine Announcement item (Priority 30)
        val announcementItem = CarouselItem(
            id = "ANNOUNCEMENT_PARKING_RULE",
            groupId = 101L,
            contentType = CarouselContentType.ANNOUNCEMENT,
            title = "Parking Guidelines",
            message = "Please park in designated bays",
            startAt = now - 1000,
            endAt = now + 100000,
            priority = 30,
            isActive = true
        )

        // Save all to repository
        repository.saveCarouselItem(birthdayItem)
        repository.saveCarouselItem(festivalItem)
        repository.saveCarouselItem(promoItem)
        repository.saveCarouselItem(announcementItem)

        // Retrieve active items for group 101 (which receives both group-scoped and GLOBAL items)
        val activeItems = repository.getActiveCarouselItems(101L).first()
        val sortedByPriority = activeItems.sortedByDescending { it.priority }

        assertEquals(4, sortedByPriority.size)
        // 1st: Birthday (120)
        assertEquals("BIRTHDAY_101_5", sortedByPriority[0].id)
        assertEquals(CarouselContentType.BIRTHDAY, sortedByPriority[0].contentType)
        // 2nd: Festival (100)
        assertEquals("FESTIVAL_DIWALI_2026", sortedByPriority[1].id)
        assertEquals(CarouselContentType.FESTIVAL, sortedByPriority[1].contentType)
        // 3rd: Promotion (50)
        assertEquals("PROMO_0_ANNUAL_MAINTENANCE_OFFER_2026", sortedByPriority[2].id)
        assertEquals(CarouselContentType.PROMOTION, sortedByPriority[2].contentType)
        // 4th: Announcement (30)
        assertEquals("ANNOUNCEMENT_PARKING_RULE", sortedByPriority[3].id)
        assertEquals(CarouselContentType.ANNOUNCEMENT, sortedByPriority[3].contentType)
    }

    @Test
    fun testMediaResourceCompatibility() {
        val promoWithMedia = PromotionCampaignDefinition(
            id = "SUMMER_TOURNAMENT",
            title = "Badminton Tournament",
            message = "Register now",
            mediaResource = MediaResource(
                mediaId = "promo_badminton_2026",
                logicalPath = "carousel/promotions/badminton.png",
                publicUrl = "https://res.cloudinary.com/demo/image/upload/badminton.png",
                mediaType = MediaType.IMAGE,
                width = 1200,
                height = 630
            )
        )

        val item = promotionService.createPromotionCarouselItem(promoWithMedia, "2026")
        assertNotNull(item)
        assertNotNull(item?.mediaResource)
        assertEquals("promo_badminton_2026", item?.mediaResource?.mediaId)
        assertEquals(MediaType.IMAGE, item?.mediaResource?.mediaType)
    }
}
