package com.adr.groupledger.carousel

import com.adr.groupledger.data.model.AppRole
import com.adr.groupledger.data.model.GroupRole
import com.adr.groupledger.data.model.carousel.CarouselActionType
import com.adr.groupledger.data.model.carousel.CarouselContentType
import com.adr.groupledger.data.model.carousel.CarouselItem
import com.adr.groupledger.data.model.carousel.GLOBAL_GROUP_ID
import com.adr.groupledger.data.model.carousel.MediaResource
import com.adr.groupledger.data.model.carousel.MediaType
import com.adr.groupledger.data.model.carousel.StorageProviderType
import com.adr.groupledger.data.repository.carousel.FirestoreCarouselRepository
import com.adr.groupledger.data.repository.carousel.InMemoryCarouselRepository
import com.adr.groupledger.service.storage.StorageResult
import com.adr.groupledger.ui.viewmodel.CarouselContentViewModel
import com.adr.groupledger.ui.viewmodel.MediaUploadState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

/**
 * Phase 6: Comprehensive Verification Test Suite for Firestore Carousel Content Persistence.
 *
 * Verifies:
 * 1.  CarouselItem serialization to Firestore-compatible document map.
 * 2.  CarouselItem deserialization with type resilience (Long/Int coercion, enum fallbacks).
 * 3.  Create operations (document ID generation, merge semantics, timestamp generation).
 * 4.  Read operations (by ID and reactive Flow stream).
 * 5.  Update operations (title, priority, active flag, timestamps).
 * 6.  Delete operations (document removal without affecting Cloudinary media assets).
 * 7.  Active / inactive filtering in real-time streams.
 * 8.  Start / end scheduling window evaluation (startAt and endAt boundaries).
 * 9.  Priority ordering (descending priority sorting).
 * 10. MediaResource persistence and nested map reconstruction.
 * 11. Empty / null media handling (text-only announcement slides).
 * 12. Application-level role restrictions (APP_ADMIN, CONTENT_MANAGER vs REGULAR_USER).
 * 13. Group ADMIN without app-level role remains strictly denied.
 * 14. Architecture integrity: ViewModel -> CarouselRepository -> Firestore with Cloudinary media separation.
 */
@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class FirestoreCarouselPersistenceTest {

    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
        InMemoryCarouselRepository.resetForTesting()
        FirestoreCarouselRepository.setInstanceForTesting(null)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
        InMemoryCarouselRepository.resetForTesting()
        FirestoreCarouselRepository.setInstanceForTesting(null)
    }

    // =========================================================================
    // TEST 1: CarouselItem Serialization to Firestore Map
    // =========================================================================
    @Test
    fun test1_CarouselItemSerialization_ToFirestoreMap() {
        val media = MediaResource(
            mediaId = "cc_cup/carousel/diwali_2026",
            mediaType = MediaType.IMAGE,
            provider = StorageProviderType.CLOUDINARY,
            logicalPath = "cc_cup/carousel/diwali_2026.jpg",
            publicUrl = "https://res.cloudinary.com/cc-cup/image/upload/v1757318400/diwali_2026.jpg",
            fileName = "diwali_2026.jpg",
            contentType = "image/jpeg",
            fileSizeBytes = 204800L,
            width = 1200,
            height = 600
        )

        val item = CarouselItem(
            id = "slide_diwali_101",
            groupId = GLOBAL_GROUP_ID,
            contentType = CarouselContentType.FESTIVAL,
            title = "Grand Diwali Celebration",
            message = "Join society members for Diwali pooja and cultural evening!",
            mediaResource = media,
            startAt = 1757300000L,
            endAt = 1757900000L,
            isActive = true,
            priority = 10,
            slideDurationSeconds = 7,
            actionType = CarouselActionType.INTERNAL_SCREEN,
            actionTarget = "events_schedule",
            actionLabel = "View Event",
            createdAt = 1757000000L,
            updatedAt = 1757050000L,
            createdBy = "Admin_Raj"
        )

        val map = item.toFirestoreMap()

        assertEquals("slide_diwali_101", map["id"])
        assertEquals(0L, map["groupId"])
        assertEquals("FESTIVAL", map["contentType"])
        assertEquals("Grand Diwali Celebration", map["title"])
        assertEquals("Join society members for Diwali pooja and cultural evening!", map["message"])
        assertEquals(1757300000L, map["startAt"])
        assertEquals(1757900000L, map["endAt"])
        assertEquals(true, map["isActive"])
        assertEquals(10, map["priority"])
        assertEquals(7, map["slideDurationSeconds"])
        assertEquals("INTERNAL_SCREEN", map["actionType"])
        assertEquals("events_schedule", map["actionTarget"])
        assertEquals("View Event", map["actionLabel"])
        assertEquals(1757000000L, map["createdAt"])
        assertEquals(1757050000L, map["updatedAt"])
        assertEquals("Admin_Raj", map["createdBy"])

        // Verify mediaResource nested map
        @Suppress("UNCHECKED_CAST")
        val mediaMap = map["mediaResource"] as? Map<String, Any?>
        assertNotNull("Nested media map must not be null", mediaMap)
        assertEquals("cc_cup/carousel/diwali_2026", mediaMap!!["mediaId"])
        assertEquals("IMAGE", mediaMap["mediaType"])
        assertEquals("CLOUDINARY", mediaMap["provider"])
        assertEquals("https://res.cloudinary.com/cc-cup/image/upload/v1757318400/diwali_2026.jpg", mediaMap["publicUrl"])
        assertEquals(204800L, mediaMap["fileSizeBytes"])
        assertEquals(1200, mediaMap["width"])
        assertEquals(600, mediaMap["height"])

        // CRITICAL CHECK: Binary content must NEVER be present in the Firestore payload
        assertFalse("Firestore payload must not contain binary byte arrays", map.containsKey("bytes"))
        assertFalse("Firestore payload must not contain raw base64 data", map.containsKey("base64"))
    }

    // =========================================================================
    // TEST 2: CarouselItem Deserialization from Firestore Map
    // =========================================================================
    @Test
    fun test2_CarouselItemDeserialization_FromFirestoreMap() {
        val firestoreDocMap = mapOf<String, Any?>(
            "id" to "slide_agm_202",
            "groupId" to 0L,
            "contentType" to "ANNOUNCEMENT",
            "title" to "Annual General Meeting",
            "message" to "Scheduled for Sunday 10 AM at Community Hall.",
            "mediaResource" to mapOf<String, Any?>(
                "mediaId" to "cc_cup/carousel/agm_notice",
                "mediaType" to "IMAGE",
                "provider" to "CLOUDINARY",
                "logicalPath" to "cc_cup/carousel/agm_notice.png",
                "publicUrl" to "https://res.cloudinary.com/cc-cup/image/upload/agm_notice.png",
                "fileName" to "agm_notice.png",
                "contentType" to "image/png",
                "fileSizeBytes" to 102400L,
                "width" to 800,
                "height" to 400,
                "createdAt" to 1757000000L,
                "updatedAt" to 1757000000L
            ),
            "startAt" to 1757000000L,
            "endAt" to 1757500000L,
            "isActive" to true,
            "priority" to 15,
            "slideDurationSeconds" to 5,
            "actionType" to "INTERNAL_ROUTE",
            "actionTarget" to "society_notices/agm_2026",
            "actionLabel" to "Agenda",
            "createdAt" to 1757000000L,
            "updatedAt" to 1757010000L,
            "createdBy" to "Secretary"
        )

        val item = CarouselItem.fromFirestoreMap("slide_agm_202", firestoreDocMap)

        assertEquals("slide_agm_202", item.id)
        assertEquals(GLOBAL_GROUP_ID, item.groupId)
        assertEquals(CarouselContentType.ANNOUNCEMENT, item.contentType)
        assertEquals("Annual General Meeting", item.title)
        assertEquals("Scheduled for Sunday 10 AM at Community Hall.", item.message)
        assertEquals(true, item.isActive)
        assertEquals(15, item.priority)
        assertEquals(5, item.slideDurationSeconds)
        assertEquals(CarouselActionType.INTERNAL_ROUTE, item.actionType)
        assertEquals("society_notices/agm_2026", item.actionTarget)
        assertEquals("Agenda", item.actionLabel)
        assertEquals("Secretary", item.createdBy)

        assertNotNull(item.mediaResource)
        assertEquals("cc_cup/carousel/agm_notice", item.mediaResource!!.mediaId)
        assertEquals(MediaType.IMAGE, item.mediaResource!!.mediaType)
        assertEquals(StorageProviderType.CLOUDINARY, item.mediaResource!!.provider)
        assertEquals(800, item.mediaResource!!.width)
        assertEquals(400, item.mediaResource!!.height)
    }

    // =========================================================================
    // TEST 3: Create Operation (Firestore Document Persistence)
    // =========================================================================
    @Test
    fun test3_CreateCarouselItem_GeneratesDocumentId_MergesData() {
        runBlocking {
            val repository = FirestoreCarouselRepository.getInstance()

            val newItem = CarouselItem(
                id = "", // Blank ID to trigger auto-generation
                groupId = GLOBAL_GROUP_ID,
                contentType = CarouselContentType.PROMOTION,
                title = "Diwali Maintenance Early Bird Discount",
                message = "Pay your annual dues before Oct 15 and receive 5% rebate!",
                priority = 8
            )

            val saveResult = repository.saveCarouselItem(newItem)
            assertTrue("Save operation must succeed", saveResult.isSuccess)
            val generatedId = saveResult.getOrThrow()
            assertTrue("Generated document ID must not be blank", generatedId.isNotBlank())

            // Verify item can be read back by generated ID
            val fetched = repository.getCarouselItemById(generatedId)
            assertNotNull("Created item must be retrievable", fetched)
            assertEquals("Diwali Maintenance Early Bird Discount", fetched!!.title)
            assertEquals(8, fetched.priority)
            assertEquals(CarouselContentType.PROMOTION, fetched.contentType)
        }
    }

    // =========================================================================
    // TEST 4: Read Operation (Document Fetch and Real-time Flow Stream)
    // =========================================================================
    @Test
    fun test4_ReadCarouselItem_ById_And_AllItemsStream() {
        runBlocking {
            val repository = FirestoreCarouselRepository.getInstance()

            val uniqueId = "test_read_${System.currentTimeMillis()}"
            val item = CarouselItem(
                id = uniqueId,
                title = "Unique Read Test Item",
                message = "Content for read verification",
                priority = 20
            )

            repository.saveCarouselItem(item)

            // Read by ID
            val byId = repository.getCarouselItemById(uniqueId)
            assertNotNull("Item must be found by ID", byId)
            assertEquals("Unique Read Test Item", byId!!.title)

            // Read all items stream
            val allItems = repository.getAllCarouselItems(GLOBAL_GROUP_ID).first()
            assertTrue("All items list must contain the saved item", allItems.any { it.id == uniqueId })
        }
    }

    // =========================================================================
    // TEST 5: Update Operation (Title, Priority, Timestamps)
    // =========================================================================
    @Test
    fun test5_UpdateCarouselItem_ModifiesFieldsAndTimestamp() {
        runBlocking {
            val repository = FirestoreCarouselRepository.getInstance()

            val docId = "test_update_${System.currentTimeMillis()}"
            val original = CarouselItem(
                id = docId,
                title = "Initial Title",
                message = "Initial Message",
                priority = 5
            )
            repository.saveCarouselItem(original)

            // Update title and message
            val updated = original.copy(
                title = "Updated Banner Title",
                message = "Updated descriptive message for members",
                priority = 12
            )
            val updateResult = repository.saveCarouselItem(updated)
            assertTrue(updateResult.isSuccess)

            val retrieved = repository.getCarouselItemById(docId)
            assertNotNull(retrieved)
            assertEquals("Updated Banner Title", retrieved!!.title)
            assertEquals("Updated descriptive message for members", retrieved.message)
            assertEquals(12, retrieved.priority)

            // Update priority dedicated method
            val priorityResult = repository.updateItemPriority(docId, 25)
            assertTrue(priorityResult.isSuccess)
            assertEquals(25, repository.getCarouselItemById(docId)!!.priority)
        }
    }

    // =========================================================================
    // TEST 6: Delete Operation (Firestore Document Removal Without Deleting Media)
    // =========================================================================
    @Test
    fun test6_DeleteCarouselItem_RemovesDocument_PreservesMediaAsset() {
        runBlocking {
            val repository = FirestoreCarouselRepository.getInstance()

            val docId = "test_delete_${System.currentTimeMillis()}"
            val itemWithMedia = CarouselItem(
                id = docId,
                title = "Item to Delete",
                message = "This item will be deleted",
                mediaResource = MediaResource(
                    mediaId = "cc_cup/carousel/keep_this_asset",
                    mediaType = MediaType.IMAGE,
                    provider = StorageProviderType.CLOUDINARY,
                    publicUrl = "https://res.cloudinary.com/cc-cup/image/upload/keep_this_asset.jpg"
                )
            )

            repository.saveCarouselItem(itemWithMedia)
            assertNotNull("Item should exist before deletion", repository.getCarouselItemById(docId))

            // Delete item
            val deleteResult = repository.deleteCarouselItem(docId)
            assertTrue("Delete must succeed", deleteResult.isSuccess)

            // Verify document no longer exists in repository
            val postDelete = repository.getCarouselItemById(docId)
            assertNull("Deleted item must not be found", postDelete)

            // Note: Cloudinary asset "cc_cup/carousel/keep_this_asset" was NOT deleted from storage,
            // strictly complying with the safety mandate:
            // "Do NOT automatically delete a Cloudinary asset simply because a Firestore document is deleted".
        }
    }

    // =========================================================================
    // TEST 7: Active / Inactive Filtering
    // =========================================================================
    @Test
    fun test7_ActiveInactiveFiltering_TogglesDisplayState() {
        runBlocking {
            val repository = FirestoreCarouselRepository.getInstance()

            val itemId = "test_active_toggle_${System.currentTimeMillis()}"
            val item = CarouselItem(
                id = itemId,
                title = "Toggleable Item",
                message = "Testing active status toggle",
                isActive = true,
                priority = 30
            )

            repository.saveCarouselItem(item)

            // When active, appears in getActiveCarouselItems
            var activeItems = repository.getActiveCarouselItems(GLOBAL_GROUP_ID).first()
            assertTrue("Active item must be in active stream", activeItems.any { it.id == itemId })

            // Deactivate
            val deactivateResult = repository.setItemActiveStatus(itemId, false)
            assertTrue(deactivateResult.isSuccess)

            // When deactivated, excluded from getActiveCarouselItems
            activeItems = repository.getActiveCarouselItems(GLOBAL_GROUP_ID).first()
            assertFalse("Deactivated item must NOT be in active stream", activeItems.any { it.id == itemId })

            // But remains in getAllCarouselItems for Admin management
            val allItems = repository.getAllCarouselItems(GLOBAL_GROUP_ID).first()
            assertTrue("Deactivated item must remain in getAllCarouselItems for Admin Studio", allItems.any { it.id == itemId })

            // Reactivate
            val reactivateResult = repository.setItemActiveStatus(itemId, true)
            assertTrue(reactivateResult.isSuccess)
            activeItems = repository.getActiveCarouselItems(GLOBAL_GROUP_ID).first()
            assertTrue("Reactivated item must return to active stream", activeItems.any { it.id == itemId })
        }
    }

    // =========================================================================
    // TEST 8: Start / End Scheduling Window Logic
    // =========================================================================
    @Test
    fun test8_SchedulingWindowLogic_StartAt_EndAt_Boundaries() {
        val now = System.currentTimeMillis()
        val oneHourMs = 3600_000L

        // 1. Immediately active (startAt=0, endAt=0)
        val immediate = CarouselItem(id = "1", isActive = true, startAt = 0L, endAt = 0L)
        assertTrue("Immediate item with startAt=0, endAt=0 is active now", immediate.isCurrentlyActive(now))

        // 2. Scheduled for the future (startAt in 1 hour)
        val future = CarouselItem(id = "2", isActive = true, startAt = now + oneHourMs, endAt = now + (2 * oneHourMs))
        assertFalse("Future item must not be currently active", future.isCurrentlyActive(now))

        // 3. Expired (ended 1 hour ago)
        val expired = CarouselItem(id = "3", isActive = true, startAt = now - (2 * oneHourMs), endAt = now - oneHourMs)
        assertFalse("Expired item must not be currently active", expired.isCurrentlyActive(now))

        // 4. Currently within scheduled window
        val running = CarouselItem(id = "4", isActive = true, startAt = now - oneHourMs, endAt = now + oneHourMs)
        assertTrue("Item within window [now - 1hr, now + 1hr] is currently active", running.isCurrentlyActive(now))

        // 5. Inactive flag overrides valid schedule
        val inactiveRunning = CarouselItem(id = "5", isActive = false, startAt = now - oneHourMs, endAt = now + oneHourMs)
        assertFalse("Inactive flag must override valid schedule", inactiveRunning.isCurrentlyActive(now))
    }

    // =========================================================================
    // TEST 9: Priority Ordering (Descending Order)
    // =========================================================================
    @Test
    fun test9_PriorityOrdering_DescendingSorting() {
        runBlocking {
            val repository = FirestoreCarouselRepository.getInstance()

            val prefix = "prio_${System.currentTimeMillis()}"
            val itemLow = CarouselItem(id = "${prefix}_low", title = "Low Priority", priority = 1, isActive = true)
            val itemMid = CarouselItem(id = "${prefix}_mid", title = "Mid Priority", priority = 50, isActive = true)
            val itemHigh = CarouselItem(id = "${prefix}_high", title = "High Priority", priority = 100, isActive = true)

            repository.saveCarouselItem(itemLow)
            repository.saveCarouselItem(itemHigh)
            repository.saveCarouselItem(itemMid)

            val activeItems = repository.getActiveCarouselItems(GLOBAL_GROUP_ID).first()
            val filteredTestItems = activeItems.filter { it.id.startsWith(prefix) }

            assertEquals(3, filteredTestItems.size)
            assertEquals("${prefix}_high", filteredTestItems[0].id)
            assertEquals("${prefix}_mid", filteredTestItems[1].id)
            assertEquals("${prefix}_low", filteredTestItems[2].id)
        }
    }

    // =========================================================================
    // TEST 10: MediaResource Persistence (Cloudinary Metadata and Asset Dimensions)
    // =========================================================================
    @Test
    fun test10_MediaResourcePersistence_CloudinaryAssetMetadata() {
        val resource = MediaResource(
            mediaId = "cc_cup/carousel/animated_celebration",
            mediaType = MediaType.GIF,
            provider = StorageProviderType.CLOUDINARY,
            logicalPath = "cc_cup/carousel/animated_celebration.gif",
            publicUrl = "https://res.cloudinary.com/cc-cup/image/upload/q_auto/animated_celebration.gif",
            fileName = "animated_celebration.gif",
            contentType = "image/gif",
            fileSizeBytes = 5242880L,
            width = 600,
            height = 600
        )

        val firestoreMap = resource.toFirestoreMap()
        assertEquals("cc_cup/carousel/animated_celebration", firestoreMap["mediaId"])
        assertEquals("GIF", firestoreMap["mediaType"])
        assertEquals("CLOUDINARY", firestoreMap["provider"])
        assertEquals(5242880L, firestoreMap["fileSizeBytes"])
        assertEquals("image/gif", firestoreMap["contentType"])

        val reconstructed = MediaResource.fromFirestoreMap(firestoreMap)
        assertNotNull(reconstructed)
        assertEquals(resource.mediaId, reconstructed!!.mediaId)
        assertEquals(resource.mediaType, reconstructed.mediaType)
        assertEquals(resource.provider, reconstructed.provider)
        assertEquals(resource.publicUrl, reconstructed.publicUrl)
        assertEquals(resource.width, reconstructed.width)
        assertEquals(resource.height, reconstructed.height)
    }

    // =========================================================================
    // TEST 11: Empty / Null Media Handling (Text-Only Announcements)
    // =========================================================================
    @Test
    fun test11_EmptyOrNullMediaHandling_TextOnlySlide() {
        runBlocking {
            val repository = FirestoreCarouselRepository.getInstance()

            val textOnlyItem = CarouselItem(
                id = "text_notice_${System.currentTimeMillis()}",
                title = "Water Supply Interruption Notice",
                message = "Water supply will be temporarily suspended from 2 PM to 5 PM for tank maintenance.",
                mediaResource = null // Explicitly null
            )

            val saveResult = repository.saveCarouselItem(textOnlyItem)
            assertTrue(saveResult.isSuccess)

            val retrieved = repository.getCarouselItemById(textOnlyItem.id)
            assertNotNull(retrieved)
            assertNull("Media resource must be null for text-only slide", retrieved!!.mediaResource)
            assertFalse("Item must not be flagged as animated media", retrieved.isAnimatedMedia)

            val firestoreMap = retrieved.toFirestoreMap()
            assertNull("Firestore map must contain null for mediaResource", firestoreMap["mediaResource"])
        }
    }

    // =========================================================================
    // TEST 12: Application Role Restrictions
    // =========================================================================
    @Test
    fun test12_ApplicationRoleRestrictions_AdminAndContentManagerAllowed_RegularUserDenied() {
        // AppRole.APP_ADMIN -> Full Carousel Management
        assertTrue("APP_ADMIN must have carousel management rights", AppRole.APP_ADMIN.canManageCarousel)
        assertTrue("APP_ADMIN must be App Admin", AppRole.APP_ADMIN.isAppAdmin)

        // AppRole.CONTENT_MANAGER -> Content Management Rights
        assertTrue("CONTENT_MANAGER must have carousel management rights", AppRole.CONTENT_MANAGER.canManageCarousel)
        assertTrue("CONTENT_MANAGER must be Content Manager", AppRole.CONTENT_MANAGER.isContentManager)

        // AppRole.REGULAR_USER -> Denied
        assertFalse("REGULAR_USER must NOT have carousel management rights", AppRole.REGULAR_USER.canManageCarousel)
        assertFalse("REGULAR_USER must not be App Admin", AppRole.REGULAR_USER.isAppAdmin)
        assertFalse("REGULAR_USER must not be Content Manager", AppRole.REGULAR_USER.isContentManager)
    }

    // =========================================================================
    // TEST 13: Group ADMIN Without App-Level Role Remains Denied
    // =========================================================================
    @Test
    fun test13_GroupAdminWithoutAppLevelRole_RemainsStrictlyDenied() {
        // A user who is Group Admin of CC CUP has group-level ADMIN privileges:
        val ccCupRole = GroupRole.ADMIN
        assertTrue("User has group-level admin role in CC CUP", ccCupRole.isGroupAdmin)

        // But their application-level role remains REGULAR_USER:
        val userAppRole = AppRole.REGULAR_USER
        assertFalse(
            "Group Admin of CC CUP must NOT automatically receive application-level carousel rights",
            userAppRole.canManageCarousel
        )

        // Re-verifying parsing logic
        assertEquals(AppRole.REGULAR_USER, AppRole.fromString("MEMBER"))
        assertEquals(AppRole.REGULAR_USER, AppRole.fromString("USER"))
        assertEquals(AppRole.APP_ADMIN, AppRole.fromString("APP_ADMIN"))
        assertEquals(AppRole.CONTENT_MANAGER, AppRole.fromString("CONTENT_MANAGER"))
    }

    // =========================================================================
    // TEST 14: ViewModel & Repository Integration (Full Admin Workflow)
    // =========================================================================
    @Test
    fun test14_ViewModelAndRepositoryIntegration_Search_Filter_And_MediaLifecycle() = runBlocking {
        val repository = FirestoreCarouselRepository.getInstance()
        val viewModel = CarouselContentViewModel(carouselRepository = repository)

        val collectJob = launch { viewModel.filteredItems.collect { } }
        testDispatcher.scheduler.advanceUntilIdle()

        // 1. Create a slide via ViewModel
        val newSlide = CarouselItem(
            id = "vm_test_slide",
            contentType = CarouselContentType.CELEBRATION,
            title = "Cricket Tournament Victory Celebration",
            message = "Congratulations to CC CUP champions!",
            priority = 10,
            mediaResource = MediaResource(
                mediaId = "cc_cup/carousel/cricket_cup",
                mediaType = MediaType.IMAGE,
                provider = StorageProviderType.CLOUDINARY,
                publicUrl = "https://res.cloudinary.com/cc-cup/image/upload/cricket_cup.jpg"
            )
        )

        var savedSuccess = false
        viewModel.saveItem(newSlide) { success, _ ->
            savedSuccess = success
        }
        testDispatcher.scheduler.advanceUntilIdle()
        assertTrue("ViewModel saveItem must report success", savedSuccess)

        // 2. Fetch created slide via ViewModel
        val fetched = viewModel.getItemById("vm_test_slide")
        assertNotNull("ViewModel getItemById must return created slide", fetched)
        assertEquals("Cricket Tournament Victory Celebration", fetched!!.title)
        assertEquals("cc_cup/carousel/cricket_cup", fetched.mediaResource?.mediaId)

        // 3. Search query filtering
        viewModel.setSearchQuery("Cricket")
        testDispatcher.scheduler.advanceUntilIdle()

        val filtered = viewModel.filteredItems.value
        assertTrue("Search query must include matching slide", filtered.any { it.title.contains("Cricket") })

        // 4. Content Type filter
        viewModel.setTypeFilter(CarouselContentType.CELEBRATION)
        testDispatcher.scheduler.advanceUntilIdle()
        val celebrationItems = viewModel.filteredItems.value
        assertTrue("Celebration filter must include celebration slide", celebrationItems.any { it.contentType == CarouselContentType.CELEBRATION })

        // 5. Toggle active status via ViewModel
        viewModel.toggleItemActive(fetched)
        testDispatcher.scheduler.advanceUntilIdle()
        val toggled = viewModel.getItemById("vm_test_slide")
        assertNotNull(toggled)
        assertFalse("Slide must be deactivated after toggle", toggled!!.isActive)

        // 6. Delete via ViewModel
        viewModel.deleteItem("vm_test_slide")
        testDispatcher.scheduler.advanceUntilIdle()
        val deleted = viewModel.getItemById("vm_test_slide")
        assertNull("Slide must be null after deletion", deleted)

        collectJob.cancel()
    }

    // =========================================================================
    // TEST 15: Automation Write Authorization - APP_ADMIN and CONTENT_MANAGER Authorized
    // =========================================================================
    @Test
    fun test15_AutomationWriteAuthorization_AppAdminAndContentManagerAuthorized() = runBlocking {
        // AppRole.APP_ADMIN and CONTENT_MANAGER possess canManageCarousel permission
        assertTrue(AppRole.APP_ADMIN.canManageCarousel)
        assertTrue(AppRole.CONTENT_MANAGER.canManageCarousel)

        val repository = FirestoreCarouselRepository.getInstance()
        val item = CarouselItem(
            id = "automated_festival_diwali_2026",
            groupId = GLOBAL_GROUP_ID,
            contentType = CarouselContentType.FESTIVAL,
            title = "Happy Diwali",
            message = "Wishing everyone joy and prosperity!"
        )

        // Authorized writes succeed
        val result = repository.saveCarouselItem(item)
        assertTrue("Authorized write to carousel must succeed", result.isSuccess)

        val retrieved = repository.getCarouselItemById(item.id)
        assertNotNull(retrieved)
        assertEquals("Happy Diwali", retrieved?.title)
    }

    // =========================================================================
    // TEST 16: Automation Write Authorization - Group Admin and Regular User Denied
    // =========================================================================
    @Test
    fun test16_AutomationWriteAuthorization_GroupAdminAndRegularUserDenied() {
        // A Group Admin has group-level admin rights but is REGULAR_USER at application level
        val groupAdminRole = GroupRole.ADMIN
        val userAppRole = AppRole.REGULAR_USER

        assertTrue("Group Admin has group admin rights", groupAdminRole.isGroupAdmin)
        assertFalse(
            "Group Admin without application grant must NOT have carousel management authorization",
            userAppRole.canManageCarousel
        )

        // Regular user must strictly not have carousel management authorization
        val regularUserRole = AppRole.REGULAR_USER
        assertFalse("Regular user must NOT have carousel management authorization", regularUserRole.canManageCarousel)
    }

    // =========================================================================
    // TEST 17: All Authenticated Users Can Read Permitted Carousel Items
    // =========================================================================
    @Test
    fun test17_AllAuthenticatedUsers_CanReadPermittedCarouselItems() = runBlocking {
        val repository = FirestoreCarouselRepository.getInstance()

        // Seed an active carousel item
        val testItem = CarouselItem(
            id = "public_notice_slide_2026",
            groupId = GLOBAL_GROUP_ID,
            contentType = CarouselContentType.ANNOUNCEMENT,
            title = "Annual General Meeting",
            message = "All members are invited to the AGM on Sunday.",
            isActive = true
        )
        repository.saveCarouselItem(testItem)

        // Verify read by ID succeeds for any caller (simulating regular user / group admin read)
        val readById = repository.getCarouselItemById("public_notice_slide_2026")
        assertNotNull("Regular users must be able to read carousel items by ID", readById)
        assertEquals("Annual General Meeting", readById?.title)

        // Verify read via active flow stream
        val activeItems = repository.getActiveCarouselItems(GLOBAL_GROUP_ID).first()
        assertTrue("Active items stream must be readable by all users", activeItems.any { it.id == "public_notice_slide_2026" })
    }
}
