package com.adr.groupledger.carousel

import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.carousel.CarouselActionType
import com.adr.groupledger.data.model.carousel.CarouselContentType
import com.adr.groupledger.data.repository.carousel.InMemoryCarouselRepository
import com.adr.groupledger.service.birthday.BirthdayAutomationService
import com.adr.groupledger.service.birthday.BirthdayMatcher
import com.adr.groupledger.utils.DateUtils
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.Calendar

/**
 * Comprehensive verification test suite for Phase 8: Birthday Automation + Member Date of Birth.
 *
 * Verifies:
 * 1.  Month + Day matching (ignoring year).
 * 2.  Birthday mismatch handling.
 * 3.  Leap Year Policy: Feb 29 matches on Feb 29 in leap years.
 * 4.  Leap Year Policy: Feb 29 matches on Feb 28 in non-leap years.
 * 5.  Tolerant DOB parsing (slashes, whitespace, ISO format).
 * 6.  Malformed/empty DOB handling without crashing.
 * 7.  Birthday celebration window calculation (00:00:00.000 to 23:59:59.999).
 * 8.  Deterministic identity generation strategy (BIRTHDAY_{groupId}_{memberId}_{year}).
 * 9.  Group isolation (only members of the specified group are processed).
 * 10. Inactive member filtering (inactive members do not receive birthday cards).
 * 11. Birthday CarouselItem properties (priority 120, slideDuration 6s, content type BIRTHDAY).
 * 12. Privacy guarantee: No birth year or full DOB in greeting message or title.
 * 13. Idempotency: Multiple automation runs do not produce duplicate items.
 * 14. DateUtils display formatting for DOB and celebration dates.
 */
@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class BirthdayAutomationTest {

    private lateinit var repository: InMemoryCarouselRepository
    private lateinit var birthdayService: BirthdayAutomationService

    @Before
    fun setUp() {
        InMemoryCarouselRepository.clearAllForTesting()
        repository = InMemoryCarouselRepository.getInstance()
        birthdayService = BirthdayAutomationService(repository)
    }

    @Test
    fun testMonthAndDayMatchingIgnoresYear() {
        // Target date: October 15, 2026
        val targetCal = Calendar.getInstance().apply {
            set(2026, Calendar.OCTOBER, 15, 14, 30, 0)
        }

        // DOB from 1990: should match
        assertTrue(BirthdayMatcher.isBirthdayToday("1990-10-15", targetCal))
        // DOB from 2005: should match
        assertTrue(BirthdayMatcher.isBirthdayToday("2005-10-15", targetCal))
        // DOB from 1982: should match
        assertTrue(BirthdayMatcher.isBirthdayToday("1982-10-15", targetCal))
    }

    @Test
    fun testBirthdayMismatchReturnsFalse() {
        // Target date: October 15, 2026
        val targetCal = Calendar.getInstance().apply {
            set(2026, Calendar.OCTOBER, 15, 12, 0, 0)
        }

        // Different day
        assertFalse(BirthdayMatcher.isBirthdayToday("1990-10-16", targetCal))
        // Different month
        assertFalse(BirthdayMatcher.isBirthdayToday("1990-11-15", targetCal))
        // Completely different date
        assertFalse(BirthdayMatcher.isBirthdayToday("1990-01-01", targetCal))
    }

    @Test
    fun testLeapYearFeb29MatchesOnFeb29InLeapYear() {
        // Leap year: 2024
        val leapYearFeb29 = Calendar.getInstance().apply {
            set(2024, Calendar.FEBRUARY, 29, 10, 0, 0)
        }
        val leapYearFeb28 = Calendar.getInstance().apply {
            set(2024, Calendar.FEBRUARY, 28, 10, 0, 0)
        }

        // On Feb 29 in leap year: matches
        assertTrue(BirthdayMatcher.isBirthdayToday("2000-02-29", leapYearFeb29))
        // On Feb 28 in leap year: does NOT match (celebration is on Feb 29)
        assertFalse(BirthdayMatcher.isBirthdayToday("2000-02-29", leapYearFeb28))
    }

    @Test
    fun testNonLeapYearFeb29MatchesOnFeb28() {
        // Non-leap year: 2025
        val nonLeapFeb28 = Calendar.getInstance().apply {
            set(2025, Calendar.FEBRUARY, 28, 10, 0, 0)
        }
        val nonLeapMarch1 = Calendar.getInstance().apply {
            set(2025, Calendar.MARCH, 1, 10, 0, 0)
        }

        // Policy: In non-leap years, Feb 29 birthdays celebrate on Feb 28
        assertTrue(BirthdayMatcher.isBirthdayToday("2000-02-29", nonLeapFeb28))
        // Does not leak to March 1
        assertFalse(BirthdayMatcher.isBirthdayToday("2000-02-29", nonLeapMarch1))
    }

    @Test
    fun testTolerantDobParsingHandlesSlashesAndWhitespace() {
        val targetCal = Calendar.getInstance().apply {
            set(2026, Calendar.JULY, 4, 12, 0, 0)
        }

        // Slash-separated
        assertTrue(BirthdayMatcher.isBirthdayToday("1988/07/04", targetCal))
        // Extra leading/trailing whitespace
        assertTrue(BirthdayMatcher.isBirthdayToday("  1988-07-04  ", targetCal))
    }

    @Test
    fun testMalformedAndEmptyDobDoesNotCrash() {
        val targetCal = Calendar.getInstance()

        assertFalse(BirthdayMatcher.isBirthdayToday(null, targetCal))
        assertFalse(BirthdayMatcher.isBirthdayToday("", targetCal))
        assertFalse(BirthdayMatcher.isBirthdayToday("   ", targetCal))
        assertFalse(BirthdayMatcher.isBirthdayToday("invalid-date", targetCal))
        assertFalse(BirthdayMatcher.isBirthdayToday("1990-99-99", targetCal))
        assertFalse(BirthdayMatcher.isBirthdayToday("1990", targetCal))
    }

    @Test
    fun testCalculateBirthdayWindowStartAndEndTimestamps() {
        val targetCal = Calendar.getInstance().apply {
            set(2026, Calendar.AUGUST, 20, 15, 0, 0)
        }

        val window = BirthdayMatcher.calculateBirthdayWindow("1995-08-20", targetCal)
        assertNotNull(window)

        val (startAt, endAt) = window!!

        val startCal = Calendar.getInstance().apply { timeInMillis = startAt }
        assertEquals(2026, startCal.get(Calendar.YEAR))
        assertEquals(Calendar.AUGUST, startCal.get(Calendar.MONTH))
        assertEquals(20, startCal.get(Calendar.DAY_OF_MONTH))
        assertEquals(0, startCal.get(Calendar.HOUR_OF_DAY))
        assertEquals(0, startCal.get(Calendar.MINUTE))
        assertEquals(0, startCal.get(Calendar.SECOND))
        assertEquals(0, startCal.get(Calendar.MILLISECOND))

        val endCal = Calendar.getInstance().apply { timeInMillis = endAt }
        assertEquals(2026, endCal.get(Calendar.YEAR))
        assertEquals(Calendar.AUGUST, endCal.get(Calendar.MONTH))
        assertEquals(20, endCal.get(Calendar.DAY_OF_MONTH))
        assertEquals(23, endCal.get(Calendar.HOUR_OF_DAY))
        assertEquals(59, endCal.get(Calendar.MINUTE))
        assertEquals(59, endCal.get(Calendar.SECOND))
        assertEquals(999, endCal.get(Calendar.MILLISECOND))
    }

    @Test
    fun testDeterministicIdentityStrategy() {
        val id = BirthdayAutomationService.generateDeterministicId(groupId = 1L, memberId = 42L, year = 2026)
        assertEquals("BIRTHDAY_1_42_2026", id)
    }

    @Test
    fun testGroupIsolationOnlyProcessesTargetGroupMembers() = runTest {
        val targetCal = Calendar.getInstance().apply {
            set(2026, Calendar.MAY, 10, 10, 0, 0)
        }

        val memberGroup1 = Member(
            id = 101,
            groupId = 1,
            name = "Aarav Group1",
            dateOfBirth = "1992-05-10",
            isActive = true
        )
        val memberGroup2 = Member(
            id = 202,
            groupId = 2,
            name = "Rohan Group2",
            dateOfBirth = "1994-05-10",
            isActive = true
        )

        // Process for Group 1 only
        val items = birthdayService.processBirthdayAutomation(
            groupId = 1L,
            members = listOf(memberGroup1, memberGroup2),
            targetCalendar = targetCal
        )

        assertEquals(1, items.size)
        assertEquals("BIRTHDAY_1_101_2026", items[0].id)
        assertEquals(1L, items[0].groupId)

        // Verify repository isolation
        val group1Items = repository.getAllCarouselItems(1L).first()
        val group2Items = repository.getAllCarouselItems(2L).first()

        assertEquals(1, group1Items.size)
        assertEquals(0, group2Items.size)
    }

    @Test
    fun testInactiveMembersAreSkipped() = runTest {
        val targetCal = Calendar.getInstance().apply {
            set(2026, Calendar.MAY, 10, 10, 0, 0)
        }

        val inactiveMember = Member(
            id = 105,
            groupId = 1,
            name = "Inactive Member",
            dateOfBirth = "1990-05-10",
            isActive = false
        )

        val items = birthdayService.processBirthdayAutomation(
            groupId = 1L,
            members = listOf(inactiveMember),
            targetCalendar = targetCal
        )

        assertTrue(items.isEmpty())
    }

    @Test
    fun testBirthdayCarouselItemContentAndStyling() {
        val targetCal = Calendar.getInstance().apply {
            set(2026, Calendar.NOVEMBER, 5, 11, 0, 0)
        }

        val member = Member(
            id = 55,
            groupId = 1,
            name = "Priya Chakraborty",
            dateOfBirth = "1995-11-05",
            isActive = true
        )

        val item = birthdayService.createBirthdayCarouselItem(member, targetCal)
        assertNotNull(item)

        assertEquals("BIRTHDAY_1_55_2026", item!!.id)
        assertEquals("Happy Birthday!", item.title)
        assertEquals("Happy Birthday, Priya Chakraborty! 🎂", item.message)
        assertEquals(CarouselContentType.BIRTHDAY, item.contentType)
        assertEquals(120, item.priority)
        assertEquals(6, item.slideDurationSeconds)
        assertEquals(CarouselActionType.NONE, item.actionType)
        assertNull(item.mediaResource)
    }

    @Test
    fun testPrivacyGuaranteeNoBirthYearOrFullDobInMessage() {
        val targetCal = Calendar.getInstance().apply {
            set(2026, Calendar.DECEMBER, 25, 9, 0, 0)
        }

        val member = Member(
            id = 77,
            groupId = 1,
            name = "Debasish Roy",
            phone = "+91 98765 43210",
            email = "debasish@example.com",
            dateOfBirth = "1980-12-25",
            isActive = true
        )

        val item = birthdayService.createBirthdayCarouselItem(member, targetCal)
        assertNotNull(item)

        // Privacy assertion: Year of birth (1980) must NOT appear in user-facing message or title
        assertFalse(item!!.message.contains("1980"))
        assertFalse(item.title.contains("1980"))
        assertFalse(item.message.contains("1980-12-25"))
        assertFalse(item.message.contains("98765"))
        assertFalse(item.message.contains("example.com"))

        // Must purely celebrate the member
        assertEquals("Happy Birthday, Debasish Roy! 🎂", item.message)
    }

    @Test
    fun testIdempotencyOnRepeatedExecution() = runTest {
        val targetCal = Calendar.getInstance().apply {
            set(2026, Calendar.JUNE, 18, 12, 0, 0)
        }

        val member = Member(
            id = 99,
            groupId = 1,
            name = "Ananya Mukherjee",
            dateOfBirth = "1993-06-18",
            isActive = true
        )

        // First execution
        val run1 = birthdayService.processBirthdayAutomation(1L, listOf(member), targetCal)
        assertEquals(1, run1.size)

        // Second execution (e.g. app restart or background sync retry)
        val run2 = birthdayService.processBirthdayAutomation(1L, listOf(member), targetCal)
        assertEquals(1, run2.size)

        // Verify repository only holds 1 single item for this member/year
        val allItems = repository.getAllCarouselItems(1L).first()
        assertEquals(1, allItems.size)
        assertEquals("BIRTHDAY_1_99_2026", allItems[0].id)
    }

    @Test
    fun testDateUtilsDisplayFormatting() {
        // Full DOB formatting
        assertEquals("15 Oct 1990", DateUtils.formatDobDisplay("1990-10-15"))
        assertEquals("20 Aug 1994", DateUtils.formatDobDisplay("1994/08/20"))
        assertEquals("-", DateUtils.formatDobDisplay(null))
        assertEquals("-", DateUtils.formatDobDisplay(""))

        // Birthday display (month + day without year)
        assertEquals("15 October", DateUtils.formatBirthdayDisplay("1990-10-15"))
        assertEquals("20 August", DateUtils.formatBirthdayDisplay("1994-08-20"))
    }
}
