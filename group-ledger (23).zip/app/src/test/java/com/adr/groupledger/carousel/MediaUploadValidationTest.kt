package com.adr.groupledger.carousel

import com.adr.groupledger.data.model.carousel.MediaType
import com.adr.groupledger.service.storage.BackendCloudinarySignatureProvider
import com.adr.groupledger.service.storage.CloudinaryConfig
import com.adr.groupledger.service.storage.MediaFileValidator
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class MediaUploadValidationTest {

    @Test
    fun testCloudinaryConfigSafetyDefaults() {
        val config = CloudinaryConfig.DEFAULT
        assertEquals("cc-cup", config.cloudName)
        assertEquals("Group_ledger_carousel", config.uploadPreset)
        assertEquals("cc_cup/carousel", config.assetFolder)
        assertTrue("Preset must be signed", config.isSigned)
        assertFalse("Overwrite must be false", config.overwrite)
    }

    @Test
    fun testBackendSignatureProviderRequiresConfiguredEndpoint() = runBlocking {
        // Without endpoint configured, it must return Failure indicating the prerequisite
        val emptyEndpointProvider = BackendCloudinarySignatureProvider(endpointUrl = "")
        val result = emptyEndpointProvider.generateSignature(
            paramsToSign = mapOf(
                "timestamp" to "1700000000",
                "upload_preset" to "Group_ledger_carousel"
            )
        )

        assertTrue("Must fail when backend endpoint is not set", result.isFailure)
        val exception = result.exceptionOrNull()
        assertNotNull(exception)
        assertTrue(
            "Exception message must mention signature endpoint",
            exception?.message?.contains("endpoint") == true || exception?.message?.contains("prerequisite") == true
        )
    }

    @Test
    fun testMediaFileValidatorFormatBytes() {
        assertEquals("0 B", MediaFileValidator.formatBytes(0L))
        assertEquals("500 B", MediaFileValidator.formatBytes(500L))
        assertEquals("1.5 KB", MediaFileValidator.formatBytes(1536L))
        assertEquals("2.0 MB", MediaFileValidator.formatBytes(2 * 1024 * 1024L))
    }

    @Test
    fun testGifHeaderMagicByteDetection() {
        val tempGif = File.createTempFile("test_sample", ".gif").apply {
            writeBytes("GIF89a\u0001\u0000\u0001\u0000".toByteArray(Charsets.ISO_8859_1))
            deleteOnExit()
        }

        val tempPng = File.createTempFile("test_sample", ".png").apply {
            writeBytes(byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A))
            deleteOnExit()
        }

        assertTrue("GIF file with GIF89a header must be detected as GIF", MediaFileValidator.isAnimatedGif(tempGif))
        assertFalse("PNG file must not be detected as GIF", MediaFileValidator.isAnimatedGif(tempPng))
    }
}
