package com.adr.groupledger.security

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.adr.groupledger.data.firebase.FirebaseService
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.Member
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Phase 11 — Task 4: Group Creation Ordering & Sequential Provisioning Test Suite
 *
 * Verifies:
 * 1. Sequential execution guarantee (parent group path is created before or atomically with initial member).
 * 2. Member record strictly carries the newly created group's unique `groupId`.
 * 3. No unscoped member records (`groupId == 0L` or unassigned) can be provisioned into a newly created group.
 * 4. No unscoped group records (`groupId == 0L`) can be provisioned.
 * 5. Parent group path and member subcollection path structure multi-tenant isolation contracts.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class GroupCreationOrderingTest {

    private lateinit var context: Context
    private lateinit var firebaseService: FirebaseService

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        firebaseService = FirebaseService(context)
    }

    @Test
    fun test1_SequentialExecutionOrdering_ParentGroupBeforeInitialMember() = runBlocking {
        val groupId = 888L
        val memberId = 1L

        val group = GroupSettings(
            id = groupId,
            groupName = "Samiti Cooperative",
            inviteCode = "SAM888"
        )
        val adminMember = Member(
            id = memberId,
            groupId = groupId,
            memberCode = "ADM-01",
            name = "Group Creator",
            email = "creator@example.com"
        )

        // Verify document path relationship
        val parentPath = "groups/$groupId"
        val memberPath = "groups/$groupId/members/$memberId"

        assertTrue("Member path must be a direct child subcollection of parent group path",
            memberPath.startsWith("$parentPath/members/"))

        // Track sequential write order simulation
        val executionLog = mutableListOf<String>()
        val onGroupWrite = { executionLog.add("PARENT_GROUP_WRITTEN") }
        val onMemberWrite = { executionLog.add("MEMBER_WRITTEN") }

        // Simulate sequential provisioning contract
        onGroupWrite()
        onMemberWrite()

        assertEquals("Parent group must be written first in sequence", "PARENT_GROUP_WRITTEN", executionLog[0])
        assertEquals("Initial member must be written after parent group", "MEMBER_WRITTEN", executionLog[1])

        // Verify execution via FirebaseService sequential helper executes safely
        val result = firebaseService.provisionGroupSequentially(group, adminMember)
        // With uninitialized/mocked Firestore in tests, it safely logs and returns false or handles gracefully
        assertFalse("Unconfigured test Firestore returns false without crashing", result)
    }

    @Test
    fun test2_MemberRecordStrictlyCarriesNewlyCreatedGroupId() = runBlocking {
        val newGroupId = 777L
        val foreignGroupId = 999L

        val group = GroupSettings(
            id = newGroupId,
            groupName = "Society A"
        )

        // Member matching newGroupId
        val validMember = Member(
            id = 10L,
            groupId = newGroupId,
            name = "Admin Alice"
        )

        // Member with mismatched/foreign groupId
        val mismatchedMember = Member(
            id = 11L,
            groupId = foreignGroupId,
            name = "Admin Bob"
        )

        assertEquals("Valid member must have identical groupId as newly created group",
            group.id, validMember.groupId)
        assertNotEquals("Mismatched member has foreign groupId",
            group.id, mismatchedMember.groupId)

        // Provisioning mismatched member must be rejected
        val provisionResult = firebaseService.provisionGroupSequentially(group, mismatchedMember)
        assertFalse("Provisioning a member with mismatched groupId must be strictly rejected", provisionResult)
    }

    @Test
    fun test3_UnscopedMemberRecordRejected() = runBlocking {
        val groupId = 555L
        val group = GroupSettings(
            id = groupId,
            groupName = "Verified Group"
        )

        // Unscoped member: groupId == 0L
        val unscopedMember = Member(
            id = 1L,
            groupId = 0L,
            name = "Unscoped Member"
        )

        val resultUnscoped = firebaseService.provisionGroupSequentially(group, unscopedMember)
        assertFalse("Member with groupId == 0L must be rejected from provisioning", resultUnscoped)

        // Member with id == 0L
        val unassignedIdMember = Member(
            id = 0L,
            groupId = groupId,
            name = "Unassigned Member ID"
        )
        val resultUnassignedId = firebaseService.provisionGroupSequentially(group, unassignedIdMember)
        // Since member.id <= 0L, saveMember rejects it
        assertFalse("Member with id <= 0L cannot be saved to Firestore", resultUnassignedId)
    }

    @Test
    fun test4_UnscopedGroupRejected() = runBlocking {
        // Group with id == 0L (not yet committed to DB)
        val unscopedGroup = GroupSettings(
            id = 0L,
            groupName = "Unscoped Group"
        )
        val member = Member(
            id = 1L,
            groupId = 0L,
            name = "Creator"
        )

        val result = firebaseService.provisionGroupSequentially(unscopedGroup, member)
        assertFalse("Group with id == 0L must be rejected from provisioning", result)
    }

    @Test
    fun test5_FirestorePathStructureMultiTenantIsolation() {
        val groupAId = 101L
        val groupBId = 202L
        val memberId = 1L

        val groupAParent = "groups/$groupAId"
        val groupAMember = "groups/$groupAId/members/$memberId"

        val groupBParent = "groups/$groupBId"
        val groupBMember = "groups/$groupBId/members/$memberId"

        assertNotEquals("Different groups must have distinct parent paths", groupAParent, groupBParent)
        assertNotEquals("Members in different groups must be completely isolated", groupAMember, groupBMember)

        assertTrue(groupAMember.startsWith(groupAParent))
        assertTrue(groupBMember.startsWith(groupBParent))
        assertFalse(groupAMember.startsWith(groupBParent))
    }
}
