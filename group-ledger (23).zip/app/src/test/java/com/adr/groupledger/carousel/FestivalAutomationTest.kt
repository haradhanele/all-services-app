package com.adr.groupledger.carousel

import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.carousel.CarouselContentType
import com.adr.groupledger.data.model.carousel.CarouselItem
import com.adr.groupledger.data.model.carousel.GLOBAL_GROUP_ID
import com.adr.groupledger.data.model.carousel.MediaResource
import com.adr.groupledger.data.model.carousel.MediaType
import com.adr.groupledger.data.model.festival.FestivalDateRule
import com.adr.groupledger.data.model.festival.FestivalDefinition
import com.adr.groupledger.data.repository.carousel.InMemoryCarouselRepository
import com.adr.groupledger.service.birthday.BirthdayAutomationService
import com.adr.groupledger.service.festival.FestivalAutomationService
import com.adr.groupledger.service.festival.FestivalCatalog
import com.adr.groupledger.service.festival.FestivalDateResolver
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.Calendar
import java.util.TimeZone

/**
 * Comprehensive verification test suite for Phase 9: Festival Automation.
 *
 * Verifies:
 * 1.  Festival definition loads correctly from catalog.
 * 2.  Fixed-date festival resolves correctly (e.g. Christmas, Republic Day, Independence Day).
 * 3.  Year-specific festival date resolves correctly (e.g. Diwali, Eid-ul-Fitr, Holi, Durga Puja).
 * 4.  Invalid festival configuration is safely ignored (e.g. month out of bounds, unmapped years).
 * 5.  Timezone consistency: activation dates do not shift unexpectedly across timezones.
 * 6.  Festival activation startAt is set to 00:00:00.000 on start date.
 * 7.  Festival activation endAt is set to 23:59:59.999 on end date.
 * 8.  Pre-event and post-event windows calculation (e.g. Durga Puja with pre/post windows).
 * 9.  Festival is active only during its configured window.
 * 10. Future festival does not appear early.
 * 11. Expired festival does not appear.
 * 12. Deterministic festival ID generation (FESTIVAL_<festivalId>_<year>).
 * 13. Idempotency: Re-running festival automation does not create duplicates.
 * 14. Same festival in different years remains distinct.
 * 15. Multiple festivals can coexist without collisions.
 * 16. Festival priority ordering works (Birthday 120 > Festival 100/105 > Notice 40).
 * 17. Festival CarouselItem uses existing CarouselItem model with CarouselContentType.FESTIVAL.
 * 18. Festival media uses existing MediaResource architecture or safe text-only fallback.
 * 19. Birthday and Festival items coexist harmoniously in the same stream.
 * 20. Global festival content uses GLOBAL_GROUP_ID (0L) and group isolation is respected.
 */
@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class FestivalAutomationTest {

    private lateinit var repository: InMemoryCarouselRepository
    private lateinit var festivalService: FestivalAutomationService

    @Before
    fun setUp() {
        InMemoryCarouselRepository.clearAllForTesting()
        repository = InMemoryCarouselRepository.getInstance()
        festivalService = FestivalAutomationService(repository)
    }

    @Test
    fun testFestivalCatalogLoadsAllStandardFestivals() {
        val catalog = FestivalCatalog.defaultFestivals
        assertTrue("Catalog must contain multiple predefined festivals", catalog.size >= 8)

        val diwali = FestivalCatalog.getFestivalById("DIWALI")
        assertNotNull(diwali)
        assertEquals("Diwali", diwali?.name)

        val eid = FestivalCatalog.getFestivalById("EID_UL_FITR")
        assertNotNull(eid)
        assertEquals("Eid-ul-Fitr", eid?.name)

        val christmas = FestivalCatalog.getFestivalById("CHRISTMAS")
        assertNotNull(christmas)
        assertEquals("Christmas", christmas?.name)

        val independenceDay = FestivalCatalog.getFestivalById("INDEPENDENCE_DAY")
        assertNotNull(independenceDay)
        assertEquals("Independence Day", independenceDay?.name)
    }

    @Test
    fun testFixedDateFestivalResolvesCorrectly() {
        // Christmas is fixed on Dec 25
        val christmas = FestivalCatalog.CHRISTMAS
        val date2025 = FestivalDateResolver.resolveDate(christmas, 2025)
        assertNotNull(date2025)
        assertEquals(12, date2025?.first)
        assertEquals(25, date2025?.second)

        val date2026 = FestivalDateResolver.resolveDate(christmas, 2026)
        assertNotNull(date2026)
        assertEquals(12, date2026?.first)
        assertEquals(25, date2026?.second)

        // Republic Day is fixed on Jan 26
        val republicDay = FestivalCatalog.REPUBLIC_DAY
        val repDate = FestivalDateResolver.resolveDate(republicDay, 2026)
        assertNotNull(repDate)
        assertEquals(1, repDate?.first)
        assertEquals(26, repDate?.second)
    }

    @Test
    fun testYearSpecificFestivalDateResolvesCorrectly() {
        // Diwali dates across years
        val diwali = FestivalCatalog.DIWALI
        val diwali2024 = FestivalDateResolver.resolveDate(diwali, 2024)
        assertEquals(Pair(11, 1), diwali2024) // Nov 1, 2024

        val diwali2025 = FestivalDateResolver.resolveDate(diwali, 2025)
        assertEquals(Pair(10, 20), diwali2025) // Oct 20, 2025

        val diwali2026 = FestivalDateResolver.resolveDate(diwali, 2026)
        assertEquals(Pair(11, 8), diwali2026) // Nov 8, 2026

        // Eid-ul-Fitr dates across years
        val eid = FestivalCatalog.EID_UL_FITR
        val eid2025 = FestivalDateResolver.resolveDate(eid, 2025)
        assertEquals(Pair(3, 31), eid2025) // March 31, 2025

        val eid2026 = FestivalDateResolver.resolveDate(eid, 2026)
        assertEquals(Pair(3, 20), eid2026) // March 20, 2026

        // Holi dates across years
        val holi = FestivalCatalog.HOLI
        val holi2026 = FestivalDateResolver.resolveDate(holi, 2026)
        assertEquals(Pair(3, 4), holi2026) // March 4, 2026
    }

    @Test
    fun testInvalidFestivalConfigurationSafelyIgnored() {
        // Invalid month
        val invalidMonth = FestivalDefinition(
            id = "INVALID_MONTH",
            name = "Invalid Month",
            dateRule = FestivalDateRule.FixedDate(month = 13, day = 10)
        )
        assertNull(FestivalDateResolver.resolveDate(invalidMonth, 2026))
        assertNull(FestivalDateResolver.calculateWindow(invalidMonth, 2026))

        // Invalid day (e.g. Feb 31)
        val invalidDay = FestivalDefinition(
            id = "INVALID_DAY",
            name = "Invalid Day",
            dateRule = FestivalDateRule.FixedDate(month = 2, day = 31)
        )
        assertNull(FestivalDateResolver.resolveDate(invalidDay, 2026))

        // Negative or zero year
        assertNull(FestivalDateResolver.resolveDate(FestivalCatalog.CHRISTMAS, 0))
        assertNull(FestivalDateResolver.resolveDate(FestivalCatalog.CHRISTMAS, -1))

        // Year-specific festival queried for an unmapped year
        val unmappedYear = FestivalDateResolver.resolveDate(FestivalCatalog.DIWALI, 2099)
        assertNull(unmappedYear)
    }

    @Test
    fun testTimezoneConsistencyPreservesCalendarDate() {
        val christmas = FestivalCatalog.CHRISTMAS
        val kolkataTz = TimeZone.getTimeZone("Asia/Kolkata")
        val utcTz = TimeZone.getTimeZone("UTC")
        val nyTz = TimeZone.getTimeZone("America/New_York")

        val windowKolkata = FestivalDateResolver.calculateWindow(christmas, 2026, kolkataTz)
        assertNotNull(windowKolkata)
        val windowUtc = FestivalDateResolver.calculateWindow(christmas, 2026, utcTz)
        assertNotNull(windowUtc)
        val windowNy = FestivalDateResolver.calculateWindow(christmas, 2026, nyTz)
        assertNotNull(windowNy)

        // In Kolkata TZ, verify start time maps to 00:00:00 on Dec 25
        val kolkataCal = Calendar.getInstance(kolkataTz).apply { timeInMillis = windowKolkata!!.first }
        assertEquals(2026, kolkataCal.get(Calendar.YEAR))
        assertEquals(Calendar.DECEMBER, kolkataCal.get(Calendar.MONTH))
        assertEquals(25, kolkataCal.get(Calendar.DAY_OF_MONTH))
        assertEquals(0, kolkataCal.get(Calendar.HOUR_OF_DAY))
        assertEquals(0, kolkataCal.get(Calendar.MINUTE))
        assertEquals(0, kolkataCal.get(Calendar.SECOND))
        assertEquals(0, kolkataCal.get(Calendar.MILLISECOND))

        // In Kolkata TZ, verify end time maps to 23:59:59.999 on Dec 25
        val kolkataEndCal = Calendar.getInstance(kolkataTz).apply { timeInMillis = windowKolkata!!.second }
        assertEquals(2026, kolkataEndCal.get(Calendar.YEAR))
        assertEquals(Calendar.DECEMBER, kolkataEndCal.get(Calendar.MONTH))
        assertEquals(25, kolkataEndCal.get(Calendar.DAY_OF_MONTH))
        assertEquals(23, kolkataEndCal.get(Calendar.HOUR_OF_DAY))
        assertEquals(59, kolkataEndCal.get(Calendar.MINUTE))
        assertEquals(59, kolkataEndCal.get(Calendar.SECOND))
        assertEquals(999, kolkataEndCal.get(Calendar.MILLISECOND))
    }

    @Test
    fun testPreAndPostEventWindowCalculation() {
        // Durga Puja has preEventDays = 1, postEventDays = 1
        // In 2026, date is Oct 20.
        // startAt should be Oct 19 00:00:00.000
        // endAt should be Oct 21 23:59:59.999
        val durgaPuja = FestivalCatalog.DURGA_PUJA
        val tz = TimeZone.getTimeZone("Asia/Kolkata")
        val window = FestivalDateResolver.calculateWindow(durgaPuja, 2026, tz)
        assertNotNull(window)

        val startCal = Calendar.getInstance(tz).apply { timeInMillis = window!!.first }
        assertEquals(2026, startCal.get(Calendar.YEAR))
        assertEquals(Calendar.OCTOBER, startCal.get(Calendar.MONTH))
        assertEquals(19, startCal.get(Calendar.DAY_OF_MONTH)) // Oct 20 - 1 day

        val endCal = Calendar.getInstance(tz).apply { timeInMillis = window!!.second }
        assertEquals(2026, endCal.get(Calendar.YEAR))
        assertEquals(Calendar.OCTOBER, endCal.get(Calendar.MONTH))
        assertEquals(21, endCal.get(Calendar.DAY_OF_MONTH)) // Oct 20 + 1 day
    }

    @Test
    fun testFestivalActiveOnlyDuringConfiguredWindow() {
        val diwali = FestivalCatalog.DIWALI // In 2026: Nov 8 (no pre/post window)
        val tz = TimeZone.getDefault()

        // 1. Before festival: Nov 7, 2026 at 23:50
        val beforeCal = Calendar.getInstance(tz).apply {
            set(2026, Calendar.NOVEMBER, 7, 23, 50, 0)
        }
        assertFalse("Festival should not be active before start date", FestivalDateResolver.isFestivalActive(diwali, beforeCal))

        // 2. On festival: Nov 8, 2026 at 12:00 noon
        val duringCal = Calendar.getInstance(tz).apply {
            set(2026, Calendar.NOVEMBER, 8, 12, 0, 0)
        }
        assertTrue("Festival should be active during festival date", FestivalDateResolver.isFestivalActive(diwali, duringCal))

        // 3. After festival: Nov 9, 2026 at 00:05
        val afterCal = Calendar.getInstance(tz).apply {
            set(2026, Calendar.NOVEMBER, 9, 0, 5, 0)
        }
        assertFalse("Festival should not be active after end date", FestivalDateResolver.isFestivalActive(diwali, afterCal))
    }

    @Test
    fun testDeterministicFestivalIdGeneration() {
        // Global ID format: FESTIVAL_<id>_<year>
        val globalId = FestivalAutomationService.generateDeterministicId("diwali", 2026, GLOBAL_GROUP_ID)
        assertEquals("FESTIVAL_DIWALI_2026", globalId)

        val eidId = FestivalAutomationService.generateDeterministicId("eid_ul_fitr", 2026, GLOBAL_GROUP_ID)
        assertEquals("FESTIVAL_EID_UL_FITR_2026", eidId)

        // Group-scoped ID format: FESTIVAL_<groupId>_<id>_<year>
        val groupId = 101L
        val groupScopedId = FestivalAutomationService.generateDeterministicId("diwali", 2026, groupId)
        assertEquals("FESTIVAL_101_DIWALI_2026", groupScopedId)
    }

    @Test
    fun testFestivalCarouselItemModelProperties() {
        val diwali = FestivalCatalog.DIWALI
        val item = festivalService.createFestivalCarouselItem(
            festival = diwali,
            year = 2026,
            groupId = GLOBAL_GROUP_ID
        )

        assertNotNull(item)
        assertEquals("FESTIVAL_DIWALI_2026", item?.id)
        assertEquals(GLOBAL_GROUP_ID, item?.groupId)
        assertEquals(CarouselContentType.FESTIVAL, item?.contentType)
        assertEquals("Happy Diwali! 🪔", item?.title)
        assertTrue(item?.message?.contains("lights") == true)
        assertEquals(105, item?.priority)
        assertEquals(6, item?.slideDurationSeconds)
        assertTrue(item?.isActive == true)
        assertEquals("FestivalAutomationService", item?.createdBy)
    }

    @Test
    fun testAutomationIsIdempotentAndDoesNotDuplicate() = runTest {
        val testCal = Calendar.getInstance().apply {
            set(2026, Calendar.NOVEMBER, 8, 10, 0, 0)
        }

        // Run automation 1st time
        val run1 = festivalService.processFestivalAutomation(
            groupId = GLOBAL_GROUP_ID,
            targetCalendar = testCal
        )
        assertTrue(run1.isNotEmpty())
        val countAfterRun1 = repository.getAllCarouselItems(GLOBAL_GROUP_ID).first().size

        // Run automation 2nd time (same year & group)
        val run2 = festivalService.processFestivalAutomation(
            groupId = GLOBAL_GROUP_ID,
            targetCalendar = testCal
        )
        val countAfterRun2 = repository.getAllCarouselItems(GLOBAL_GROUP_ID).first().size

        // Count must remain strictly identical
        assertEquals("Running automation multiple times must not create duplicate items", countAfterRun1, countAfterRun2)
    }

    @Test
    fun testSameFestivalInDifferentYearsRemainsDistinct() = runTest {
        val cal2025 = Calendar.getInstance().apply { set(2025, Calendar.OCTOBER, 20, 10, 0, 0) }
        val cal2026 = Calendar.getInstance().apply { set(2026, Calendar.NOVEMBER, 8, 10, 0, 0) }

        festivalService.processFestivalAutomation(GLOBAL_GROUP_ID, cal2025)
        festivalService.processFestivalAutomation(GLOBAL_GROUP_ID, cal2026)

        val item2025 = repository.getCarouselItemById("FESTIVAL_DIWALI_2025")
        val item2026 = repository.getCarouselItemById("FESTIVAL_DIWALI_2026")

        assertNotNull(item2025)
        assertNotNull(item2026)
        assertEquals("FESTIVAL_DIWALI_2025", item2025?.id)
        assertEquals("FESTIVAL_DIWALI_2026", item2026?.id)
    }

    @Test
    fun testBirthdayAndFestivalContentHarmoniousCoexistence() = runTest {
        val groupId = 200L
        val birthdayService = BirthdayAutomationService(repository)

        // Create birthday member on Oct 20
        val birthdayMember = Member(
            id = 501L,
            groupId = groupId,
            name = "Rohan Sen",
            phone = "9876543210",
            email = "rohan@example.com",
            dateOfBirth = "1992-10-20",
            isActive = true
        )

        // Target calendar: Oct 20, 2025 (matches Rohan's birthday and Diwali in 2025)
        val celebrationCal = Calendar.getInstance().apply {
            set(2025, Calendar.OCTOBER, 20, 12, 0, 0)
        }

        // Process both Birthday and Festival automation
        birthdayService.processBirthdayAutomation(groupId, listOf(birthdayMember), celebrationCal)
        festivalService.processFestivalAutomation(GLOBAL_GROUP_ID, celebrationCal)

        // Query all items for group 200 (includes global items + group items)
        val allItems = repository.getAllCarouselItems(groupId).first()

        // Both birthday and festival items must be present
        val birthdaySlide = allItems.firstOrNull { it.contentType == CarouselContentType.BIRTHDAY }
        val festivalSlide = allItems.firstOrNull { it.contentType == CarouselContentType.FESTIVAL && it.id.contains("DIWALI") }

        assertNotNull("Birthday slide must be present", birthdaySlide)
        assertNotNull("Festival slide must be present", festivalSlide)

        // Verify both are active within the celebration date window
        assertTrue("Birthday slide should be active during celebration date", birthdaySlide!!.isCurrentlyActive(celebrationCal.timeInMillis))
        assertTrue("Festival slide should be active during celebration date", festivalSlide!!.isCurrentlyActive(celebrationCal.timeInMillis))

        // Verify priority ordering: Birthday (120) > Diwali Festival (105)
        assertTrue("Birthday priority (120) should exceed Festival priority (105)", birthdaySlide.priority > festivalSlide.priority)
        val birthdayIndex = allItems.indexOf(birthdaySlide)
        val festivalIndex = allItems.indexOf(festivalSlide)
        assertTrue("Birthday slide (priority 120) should appear before Festival (priority 105)", birthdayIndex < festivalIndex)
    }

    @Test
    fun testFestivalMediaUsesMediaResourceArchitectureWithSafeFallback() {
        // Safe text-only festival (defaultMediaResource is null)
        val defaultDiwali = FestivalCatalog.DIWALI
        val textOnlyItem = festivalService.createFestivalCarouselItem(defaultDiwali, 2026)
        assertNotNull(textOnlyItem)
        assertNull(textOnlyItem?.mediaResource)

        // Festival with explicit MediaResource
        val customMedia = MediaResource(
            mediaId = "festival_diwali_2026",
            logicalPath = "carousel/festival/festival_diwali.jpg",
            publicUrl = "https://res.cloudinary.com/demo/image/upload/festival_diwali.jpg",
            mediaType = MediaType.IMAGE,
            width = 1200,
            height = 630
        )
        val festivalWithMedia = defaultDiwali.copy(defaultMediaResource = customMedia)
        val mediaItem = festivalService.createFestivalCarouselItem(festivalWithMedia, 2026)
        assertNotNull(mediaItem)
        assertNotNull(mediaItem?.mediaResource)
        assertEquals("festival_diwali_2026", mediaItem?.mediaResource?.mediaId)
        assertEquals(MediaType.IMAGE, mediaItem?.mediaResource?.mediaType)
    }

    @Test
    fun testFutureAndExpiredFestivalDoNotAppearInActiveStream() = runTest {
        // Today is June 15, 2026
        val testCal = Calendar.getInstance().apply {
            set(2026, Calendar.JUNE, 15, 12, 0, 0)
        }

        // Process all 2026 festivals (New Year in Jan is expired, Independence Day in Aug is future)
        festivalService.processFestivalAutomation(GLOBAL_GROUP_ID, testCal)

        // Retrieve active items on June 15, 2026
        val activeItems = repository.getActiveCarouselItems(GLOBAL_GROUP_ID).first()

        // Neither expired New Year nor future Independence Day should be in active items
        val newYearActive = activeItems.any { it.id == "FESTIVAL_NEW_YEAR_2026" }
        val indDayActive = activeItems.any { it.id == "FESTIVAL_INDEPENDENCE_DAY_2026" }

        assertFalse("Expired New Year 2026 must not appear in active carousel on June 15", newYearActive)
        assertFalse("Future Independence Day 2026 must not appear in active carousel on June 15", indDayActive)
    }
}
