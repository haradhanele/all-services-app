package com.adr.groupledger.carousel

import com.adr.groupledger.service.storage.BackendCloudinarySignatureProvider
import com.adr.groupledger.service.storage.CloudinaryConfig
import kotlinx.coroutines.runBlocking
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.IOException
import java.net.ConnectException

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class BackendCloudinarySignatureProviderTest {

    private val testEndpoint = "http://127.0.0.1:5001/demo-group-ledger/us-central1/generateCloudinarySignature"

    @Test
    fun testMissingAuthUserFailsWithAuthenticationRequired() = runBlocking {
        // tokenProvider returns null indicating no signed-in Firebase user
        val provider = BackendCloudinarySignatureProvider(
            endpointUrl = testEndpoint,
            tokenProvider = { null }
        )

        val result = provider.generateSignature(
            mapOf("folder" to "cc_cup/carousel", "upload_preset" to "Group_ledger_carousel")
        )

        assertTrue("Must fail when no Firebase user is signed in", result.isFailure)
        val exception = result.exceptionOrNull()
        assertNotNull(exception)
        assertTrue(
            "Exception should state authentication required",
            exception?.message?.contains("Authentication required") == true
        )
    }

    @Test
    fun testSuccessfulSignatureResponseParsingAndHeaderAttachment() = runBlocking {
        val fakeIdToken = "firebase_jwt_id_token_xyz_12345"
        val expectedSig = "9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0b"
        val expectedTimestamp = 1757318400L

        var capturedAuthHeader: String? = null
        var capturedContentType: String? = null
        var capturedBodyString: String? = null

        val mockHttpClient = OkHttpClient.Builder()
            .addInterceptor { chain ->
                val request = chain.request()
                capturedAuthHeader = request.header("Authorization")
                capturedContentType = request.header("Content-Type")

                val buffer = okio.Buffer()
                request.body?.writeTo(buffer)
                capturedBodyString = buffer.readUtf8()

                val mockResponseBody = JSONObject().apply {
                    put("signature", expectedSig)
                    put("timestamp", expectedTimestamp)
                    put("apiKey", "498704388167")
                    put("folder", "cc_cup/carousel/announcements")
                    put("uploadPreset", "Group_ledger_carousel")
                }.toString()

                Response.Builder()
                    .request(request)
                    .protocol(Protocol.HTTP_1_1)
                    .code(200)
                    .message("OK")
                    .body(mockResponseBody.toResponseBody("application/json".toMediaTypeOrNull()))
                    .build()
            }
            .build()

        val provider = BackendCloudinarySignatureProvider(
            endpointUrl = testEndpoint,
            httpClient = mockHttpClient,
            tokenProvider = { fakeIdToken }
        )

        val result = provider.generateSignature(
            mapOf(
                "folder" to "cc_cup/carousel/announcements",
                "upload_preset" to "Group_ledger_carousel"
            )
        )

        // 1. Verify headers
        assertEquals("Bearer $fakeIdToken", capturedAuthHeader)
        assertTrue(capturedContentType?.contains("application/json") == true)

        // 2. Verify body contains expected safe parameters
        assertNotNull(capturedBodyString)
        val bodyJson = JSONObject(capturedBodyString!!)
        assertEquals("cc_cup/carousel/announcements", bodyJson.getString("folder"))
        assertEquals("Group_ledger_carousel", bodyJson.getString("upload_preset"))
        assertTrue(bodyJson.has("timestamp"))

        // 3. Verify returned signature object
        assertTrue("Request should succeed", result.isSuccess)
        val sigData = result.getOrThrow()
        assertEquals(expectedSig, sigData.signature)
        assertEquals(expectedTimestamp, sigData.timestamp)
        assertEquals("498704388167", sigData.apiKey)
        assertEquals("cc_cup/carousel/announcements", sigData.folder)
        assertEquals("Group_ledger_carousel", sigData.uploadPreset)
    }

    @Test
    fun testHttp401UnauthorizedThrowsSecurityException() = runBlocking {
        val mockHttpClient = OkHttpClient.Builder()
            .addInterceptor { chain ->
                Response.Builder()
                    .request(chain.request())
                    .protocol(Protocol.HTTP_1_1)
                    .code(401)
                    .message("Unauthorized")
                    .body("""{"error":"Authentication failed: Token is expired"}""".toResponseBody("application/json".toMediaTypeOrNull()))
                    .build()
            }
            .build()

        val provider = BackendCloudinarySignatureProvider(
            endpointUrl = testEndpoint,
            httpClient = mockHttpClient,
            tokenProvider = { "expired_token_123" }
        )

        val result = provider.generateSignature(
            mapOf("folder" to "cc_cup/carousel", "upload_preset" to "Group_ledger_carousel")
        )

        assertTrue(result.isFailure)
        val exception = result.exceptionOrNull()
        assertTrue("Must be SecurityException", exception is SecurityException)
        assertTrue(exception?.message?.contains("401") == true)
    }

    @Test
    fun testHttp403ForbiddenThrowsSecurityException() = runBlocking {
        val mockHttpClient = OkHttpClient.Builder()
            .addInterceptor { chain ->
                Response.Builder()
                    .request(chain.request())
                    .protocol(Protocol.HTTP_1_1)
                    .code(403)
                    .message("Forbidden")
                    .body("""{"error":"Forbidden: User does not have application-level permission"}""".toResponseBody("application/json".toMediaTypeOrNull()))
                    .build()
            }
            .build()

        val provider = BackendCloudinarySignatureProvider(
            endpointUrl = testEndpoint,
            httpClient = mockHttpClient,
            tokenProvider = { "regular_user_token" }
        )

        val result = provider.generateSignature(
            mapOf("folder" to "cc_cup/carousel", "upload_preset" to "Group_ledger_carousel")
        )

        assertTrue(result.isFailure)
        val exception = result.exceptionOrNull()
        assertTrue("Must be SecurityException", exception is SecurityException)
        assertTrue(exception?.message?.contains("403") == true)
    }

    @Test
    fun testHttp400BadRequestThrowsIllegalArgumentException() = runBlocking {
        val mockHttpClient = OkHttpClient.Builder()
            .addInterceptor { chain ->
                Response.Builder()
                    .request(chain.request())
                    .protocol(Protocol.HTTP_1_1)
                    .code(400)
                    .message("Bad Request")
                    .body("""{"error":"Invalid target folder"}""".toResponseBody("application/json".toMediaTypeOrNull()))
                    .build()
            }
            .build()

        val provider = BackendCloudinarySignatureProvider(
            endpointUrl = testEndpoint,
            httpClient = mockHttpClient,
            tokenProvider = { "admin_token" }
        )

        val result = provider.generateSignature(
            mapOf("folder" to "invalid_folder", "upload_preset" to "Group_ledger_carousel")
        )

        assertTrue(result.isFailure)
        val exception = result.exceptionOrNull()
        assertTrue("Must be IllegalArgumentException", exception is IllegalArgumentException)
        assertTrue(exception?.message?.contains("400") == true)
    }

    @Test
    fun testConnectExceptionThrowsDescriptiveIOException() = runBlocking {
        val mockHttpClient = OkHttpClient.Builder()
            .addInterceptor { _ ->
                throw ConnectException("Failed to connect to 127.0.0.1:5001")
            }
            .build()

        val provider = BackendCloudinarySignatureProvider(
            endpointUrl = testEndpoint,
            httpClient = mockHttpClient,
            tokenProvider = { "admin_token" }
        )

        val result = provider.generateSignature(
            mapOf("folder" to "cc_cup/carousel", "upload_preset" to "Group_ledger_carousel")
        )

        assertTrue(result.isFailure)
        val exception = result.exceptionOrNull()
        assertTrue("Must be IOException", exception is IOException)
        assertTrue(
            "Message should mention emulator connection",
            exception?.message?.contains("emulator") == true || exception?.message?.contains("connect") == true
        )
    }

    @Test
    fun testCloudinaryConfigEmulatorUrlConstruction() {
        val defaultUrl = CloudinaryConfig.DEFAULT_SIGNATURE_ENDPOINT_URL
        assertEquals(
            "http://10.0.2.2:5001/demo-group-ledger/us-central1/generateCloudinarySignature",
            defaultUrl
        )

        val customHostUrl = CloudinaryConfig.buildEmulatorEndpointUrl(host = "192.168.1.100")
        assertEquals(
            "http://192.168.1.100:5001/demo-group-ledger/us-central1/generateCloudinarySignature",
            customHostUrl
        )
    }

    @Test
    fun testCloudinaryConfigProductionUrlConstruction() {
        val prodUrl = CloudinaryConfig.buildProductionEndpointUrl()
        assertEquals(
            "https://asia-south2-samiti-app-d4336.cloudfunctions.net/generateCloudinarySignature",
            prodUrl
        )
        assertTrue(prodUrl.startsWith("https://"))
        assertFalse(prodUrl.contains("10.0.2.2"))
        assertFalse(prodUrl.contains("localhost"))
        assertFalse(prodUrl.contains("127.0.0.1"))
        assertFalse(prodUrl.contains("demo-group-ledger"))
    }

    @Test
    fun testCustomEndpointInjectionStillWorks() {
        val customUrl = "https://custom-domain.org/api/signature"
        val provider = BackendCloudinarySignatureProvider(
            endpointUrl = customUrl
        )
        assertEquals(customUrl, provider.endpointUrl)
    }
}
