package com.adr.groupledger.security

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.adr.groupledger.data.firebase.FirebaseService
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.PreAuthorizedMember
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/**
 * Phase 11 — Task 6: Member Claiming Race Condition Prevention Test Suite
 *
 * Verifies:
 * 1. Unclaimed pre-authorized member can be successfully claimed.
 * 2. An already claimed member (`status == "CLAIMED"` or `"claimed"`) strictly rejects subsequent claim attempts.
 * 3. Concurrency validation ensures state mutation cannot occur twice for the same pre-auth record.
 * 4. Claim payload strictly records claimant's Firebase UID and positive groupId.
 * 5. Atomic provisioning activates the member record with linked Firebase UID.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MemberClaimingConcurrencyTest {

    private lateinit var context: Context
    private lateinit var firebaseService: FirebaseService

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        firebaseService = FirebaseService(context)
    }

    @Test
    fun test1_UnclaimedPreAuthorizedMember_CanBeSuccessfullyClaimed() = runBlocking {
        val groupId = 301L
        val preAuthId = 101L
        val claimantUid = "firebase_auth_user_alpha"
        val claimantUserId = 42L

        val unclaimedMember = PreAuthorizedMember(
            id = preAuthId,
            groupId = groupId,
            name = "Ramesh Kumar",
            email = "ramesh@example.com",
            phone = "+91 9876543210",
            status = "unclaimed",
            addedAt = System.currentTimeMillis(),
            claimedAt = null,
            claimedUserId = null,
            claimedUid = ""
        )

        // 1. Eligibility validation check
        val eligibility = firebaseService.validateClaimEligibility(
            record = unclaimedMember,
            claimantAuthUid = claimantUid,
            targetGroupId = groupId
        )
        assertTrue("Unclaimed pre-authorized member must be eligible for claim", eligibility.isSuccess)

        // 2. Claim execution
        val memberToProvision = Member(
            id = 501L,
            groupId = groupId,
            memberCode = "MBR-501",
            name = unclaimedMember.name,
            email = unclaimedMember.email,
            phone = unclaimedMember.phone
        )

        val claimResult = firebaseService.claimPreAuthorizedMember(
            groupId = groupId,
            preAuthId = preAuthId,
            claimantAuthUid = claimantUid,
            claimantUserId = claimantUserId,
            memberToProvision = memberToProvision
        )

        assertTrue("Claiming unclaimed member must succeed", claimResult.isSuccess)
        val claimed = claimResult.getOrThrow()

        assertEquals("Status must be updated to CLAIMED", "CLAIMED", claimed.status)
        assertEquals("Claimed UID must match claimant's Firebase UID", claimantUid, claimed.claimedUid)
        assertEquals("Claimed user ID must match claimant's numeric ID", claimantUserId, claimed.claimedUserId)
        assertNotNull("Claimed timestamp must be recorded", claimed.claimedAt)
        assertTrue("Claimed timestamp must be positive", (claimed.claimedAt ?: 0L) > 0L)
    }

    @Test
    fun test2_AlreadyClaimedMember_StrictlyRejectsSubsequentClaimAttempts() {
        val groupId = 302L
        val preAuthId = 102L

        // Pre-authorized record already claimed previously by user Alpha
        val alreadyClaimedMember = PreAuthorizedMember(
            id = preAuthId,
            groupId = groupId,
            name = "Suresh Patel",
            email = "suresh@example.com",
            status = "CLAIMED",
            claimedAt = System.currentTimeMillis() - 60_000L,
            claimedUserId = 88L,
            claimedUid = "firebase_auth_user_alpha"
        )

        // Second user Beta attempts to claim the same record
        val intruderClaimantUid = "firebase_auth_user_beta"
        val eligibilityResult = firebaseService.validateClaimEligibility(
            record = alreadyClaimedMember,
            claimantAuthUid = intruderClaimantUid,
            targetGroupId = groupId
        )

        assertTrue("Subsequent claim attempt on already claimed member must fail", eligibilityResult.isFailure)
        val exception = eligibilityResult.exceptionOrNull()
        assertTrue("Exception must indicate member is already claimed", exception is IllegalStateException)
        assertEquals("Member already claimed", exception?.message)

        // Also verify case-insensitive "claimed" status rejection
        val lowercaseClaimedMember = alreadyClaimedMember.copy(status = "claimed")
        val eligibilityLowercase = firebaseService.validateClaimEligibility(
            record = lowercaseClaimedMember,
            claimantAuthUid = intruderClaimantUid,
            targetGroupId = groupId
        )
        assertTrue("Lowercase 'claimed' status must also be rejected", eligibilityLowercase.isFailure)
    }

    @Test
    fun test3_ConcurrencyValidation_EnsuresStateMutationCannotOccurTwiceForSamePreAuthRecord() = runBlocking {
        val groupId = 303L
        val preAuthId = 103L

        // Simulated atomic slot representing the Firestore document state protected by transaction
        val stateSlot = AtomicReference<PreAuthorizedMember>(
            PreAuthorizedMember(
                id = preAuthId,
                groupId = groupId,
                name = "Priya Sharma",
                email = "priya@example.com",
                status = "unclaimed",
                claimedAt = null,
                claimedUserId = null,
                claimedUid = ""
            )
        )

        val successCount = AtomicInteger(0)
        val rejectedCount = AtomicInteger(0)

        // 10 concurrent claimants firing simultaneously
        val concurrentClaimants = (1..10).map { "auth_user_concurrent_$it" }

        val jobs = concurrentClaimants.map { claimantUid ->
            async(Dispatchers.Default) {
                // Simulate atomic compare-and-swap / transaction behavior:
                // Read current state
                var claimedSuccessfully = false
                while (true) {
                    val current = stateSlot.get()
                    val eligibility = firebaseService.validateClaimEligibility(current, claimantUid, groupId)
                    if (eligibility.isFailure) {
                        rejectedCount.incrementAndGet()
                        break
                    }
                    val updated = current.copy(
                        status = "CLAIMED",
                        claimedAt = System.currentTimeMillis(),
                        claimedUserId = claimantUid.hashCode().toLong(),
                        claimedUid = claimantUid
                    )
                    // Atomic write inside transaction boundary
                    if (stateSlot.compareAndSet(current, updated)) {
                        successCount.incrementAndGet()
                        claimedSuccessfully = true
                        break
                    }
                }
                claimedSuccessfully
            }
        }

        jobs.awaitAll()

        // Invariant: Exactly 1 claim succeeds, exactly 9 claims are rejected
        assertEquals("Exactly one concurrent claim must succeed", 1, successCount.get())
        assertEquals("Remaining 9 concurrent claims must be rejected", 9, rejectedCount.get())

        val finalState = stateSlot.get()
        assertEquals("Final status must be CLAIMED", "CLAIMED", finalState.status)
        assertTrue("Final state must carry a valid non-empty claimant UID", finalState.claimedUid.isNotBlank())
        assertNotNull("Final state must have non-null claimedAt", finalState.claimedAt)
    }

    @Test
    fun test4_ClaimPayload_StrictlyRecordsClaimantsFirebaseUidAndPositiveGroupId() = runBlocking {
        val validGroupId = 304L
        val preAuthId = 104L
        val validClaimantUid = "firebase_valid_claimant_777"

        // 1. Rejection of non-positive / invalid groupId
        val invalidGroupResult = firebaseService.claimPreAuthorizedMember(
            groupId = 0L,
            preAuthId = preAuthId,
            claimantAuthUid = validClaimantUid
        )
        assertTrue("Group ID <= 0 must be rejected", invalidGroupResult.isFailure)
        assertTrue("Must throw IllegalArgumentException for groupId <= 0",
            invalidGroupResult.exceptionOrNull() is IllegalArgumentException)

        // 2. Rejection of non-positive / invalid preAuthId
        val invalidPreAuthResult = firebaseService.claimPreAuthorizedMember(
            groupId = validGroupId,
            preAuthId = 0L,
            claimantAuthUid = validClaimantUid
        )
        assertTrue("PreAuthId <= 0 must be rejected", invalidPreAuthResult.isFailure)
        assertTrue("Must throw IllegalArgumentException for preAuthId <= 0",
            invalidPreAuthResult.exceptionOrNull() is IllegalArgumentException)

        // 3. Rejection of blank claimant Auth UID
        val blankUidResult = firebaseService.claimPreAuthorizedMember(
            groupId = validGroupId,
            preAuthId = preAuthId,
            claimantAuthUid = "   "
        )
        assertTrue("Blank claimant Auth UID must be rejected", blankUidResult.isFailure)
        assertTrue("Must throw IllegalArgumentException for blank claimant UID",
            blankUidResult.exceptionOrNull() is IllegalArgumentException)

        // 4. Valid payload records positive groupId and claimant Auth UID
        val successClaim = firebaseService.claimPreAuthorizedMember(
            groupId = validGroupId,
            preAuthId = preAuthId,
            claimantAuthUid = validClaimantUid,
            claimantUserId = 777L
        )
        assertTrue("Valid claim parameters must succeed", successClaim.isSuccess)
        val record = successClaim.getOrThrow()
        assertEquals("Claim record must retain positive groupId", validGroupId, record.groupId)
        assertEquals("Claim record must retain claimant Auth UID", validClaimantUid, record.claimedUid)
        assertEquals("Claim record must retain claimant numeric ID", 777L, record.claimedUserId)
    }

    @Test
    fun test5_AtomicProvisioning_ActivatesMemberWithLinkedUid() = runBlocking {
        val groupId = 305L
        val preAuthId = 105L
        val claimantAuthUid = "auth_member_activation_55"

        val member = Member(
            id = 801L,
            groupId = groupId,
            memberCode = "MBR-801",
            name = "Anita Desai",
            email = "anita@example.com",
            phone = "+91 9988776655",
            isActive = true,
            isClaimed = true,
            linkedUid = claimantAuthUid
        )

        val claimResult = firebaseService.claimPreAuthorizedMember(
            groupId = groupId,
            preAuthId = preAuthId,
            claimantAuthUid = claimantAuthUid,
            claimantUserId = 55L,
            memberToProvision = member
        )

        assertTrue("Atomic claim with member provisioning must succeed", claimResult.isSuccess)
        val claimedRecord = claimResult.getOrThrow()
        assertEquals("Claimed record must have status CLAIMED", "CLAIMED", claimedRecord.status)
        assertEquals("Claimed record must store claimant UID", claimantAuthUid, claimedRecord.claimedUid)

        // Verify member properties
        assertEquals("Provisioned member must be active", true, member.isActive)
        assertEquals("Provisioned member must be claimed", true, member.isClaimed)
        assertEquals("Provisioned member linkedUid must match claimantAuthUid", claimantAuthUid, member.linkedUid)
        assertEquals("Provisioned member groupId must match target group", groupId, member.groupId)
    }
}
