package com.adr.groupledger.carousel

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.adr.groupledger.data.model.carousel.CarouselActionType
import com.adr.groupledger.data.model.carousel.CarouselContentType
import com.adr.groupledger.data.model.carousel.CarouselItem
import com.adr.groupledger.data.model.carousel.GLOBAL_GROUP_ID
import com.adr.groupledger.data.model.carousel.MediaResource
import com.adr.groupledger.data.model.carousel.MediaType
import com.adr.groupledger.data.model.carousel.StorageProviderType
import com.adr.groupledger.data.repository.carousel.InMemoryCarouselRepository
import com.adr.groupledger.ui.components.handleCarouselAction
import com.adr.groupledger.ui.components.isSafeExternalUrl
import com.adr.groupledger.ui.viewmodel.CarouselContentViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Phase 7: Comprehensive Verification Test Suite for Home Screen Backend-Driven Carousel.
 *
 * Verifies all 20 required Phase 7 functional and architectural capabilities:
 * 1.  Home Screen loads active carousel items.
 * 2.  Inactive carousel items do NOT appear.
 * 3.  Expired carousel items do NOT appear.
 * 4.  Future scheduled carousel items do NOT appear.
 * 5.  Carousel items appear in descending priority order.
 * 6.  Carousel items with image URLs configure media resource correctly.
 * 7.  Carousel items with GIF URLs are identified as animated GIF media.
 * 8.  Carousel items without media display clean text-only fallback.
 * 9.  Auto-slide uses configured slideDurationSeconds.
 * 10. Auto-slide falls back to 5 seconds when slideDurationSeconds is <= 0.
 * 11. Auto-slide pause state flags during user touch interaction.
 * 12. Auto-slide resume state flags after interaction ends.
 * 13. Auto-slide handles animated GIF slides appropriately.
 * 14. Pager page forward transition semantics.
 * 15. Pager page reverse transition semantics.
 * 16. Page indicators reflect current active slide index.
 * 17. Indicator click calculates target page correctly.
 * 18. Internal navigation CTA dispatches to internal screen / route.
 * 19. External URL CTA validates safe schemes (https/http) and rejects unsafe schemes (javascript, file).
 * 20. Empty carousel state returns safely without breaking the container or layout.
 */
@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class HomeScreenCarouselTest {

    private val testDispatcher = StandardTestDispatcher()
    private lateinit var repository: InMemoryCarouselRepository
    private lateinit var context: Context

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
        context = ApplicationProvider.getApplicationContext()
        repository = InMemoryCarouselRepository.getInstance()
        InMemoryCarouselRepository.clearAllForTesting()
    }

    @After
    fun tearDown() {
        InMemoryCarouselRepository.clearAllForTesting()
        Dispatchers.resetMain()
    }

    // -------------------------------------------------------------
    // Test 1: Home Screen loads active carousel items
    // -------------------------------------------------------------
    @Test
    fun test1_homeScreenLoadsActiveCarouselItems() = runTest {
        val now = System.currentTimeMillis()
        val activeItem = CarouselItem(
            id = "slide_active_1",
            title = "Grand Annual General Meeting",
            message = "Join us this Sunday at 10 AM",
            contentType = CarouselContentType.ANNOUNCEMENT,
            isActive = true,
            startAt = now - 10000L,
            endAt = now + 100000L
        )
        repository.saveCarouselItem(activeItem)

        val activeList = repository.getActiveCarouselItems(GLOBAL_GROUP_ID).first()
        assertEquals(1, activeList.size)
        assertEquals("slide_active_1", activeList[0].id)
        assertEquals("Grand Annual General Meeting", activeList[0].title)
    }

    // -------------------------------------------------------------
    // Test 2: Inactive carousel items do NOT appear
    // -------------------------------------------------------------
    @Test
    fun test2_inactiveCarouselItemsDoNotAppear() = runTest {
        val now = System.currentTimeMillis()
        val inactiveItem = CarouselItem(
            id = "slide_inactive_1",
            title = "Archived Promotion",
            message = "This promotion is turned off",
            contentType = CarouselContentType.PROMOTION,
            isActive = false,
            startAt = now - 10000L,
            endAt = now + 100000L
        )
        repository.saveCarouselItem(inactiveItem)

        val activeList = repository.getActiveCarouselItems(GLOBAL_GROUP_ID).first()
        assertTrue("Inactive item must NOT be returned in active items stream", activeList.isEmpty())
    }

    // -------------------------------------------------------------
    // Test 3: Expired carousel items do NOT appear
    // -------------------------------------------------------------
    @Test
    fun test3_expiredCarouselItemsDoNotAppear() = runTest {
        val now = System.currentTimeMillis()
        val expiredItem = CarouselItem(
            id = "slide_expired_1",
            title = "Past Festival Celebration",
            message = "Event finished yesterday",
            contentType = CarouselContentType.FESTIVAL,
            isActive = true,
            startAt = now - 200000L,
            endAt = now - 50000L // Expired
        )
        repository.saveCarouselItem(expiredItem)

        val activeList = repository.getActiveCarouselItems(GLOBAL_GROUP_ID).first()
        assertTrue("Expired item must NOT be returned in active items stream", activeList.isEmpty())
        assertFalse(expiredItem.isCurrentlyActive(now))
    }

    // -------------------------------------------------------------
    // Test 4: Future scheduled carousel items do NOT appear
    // -------------------------------------------------------------
    @Test
    fun test4_futureScheduledCarouselItemsDoNotAppear() = runTest {
        val now = System.currentTimeMillis()
        val futureItem = CarouselItem(
            id = "slide_future_1",
            title = "Upcoming Independence Day",
            message = "Celebrations start next week",
            contentType = CarouselContentType.CELEBRATION,
            isActive = true,
            startAt = now + 500000L, // Future
            endAt = now + 1000000L
        )
        repository.saveCarouselItem(futureItem)

        val activeList = repository.getActiveCarouselItems(GLOBAL_GROUP_ID).first()
        assertTrue("Future scheduled item must NOT appear", activeList.isEmpty())
        assertFalse(futureItem.isCurrentlyActive(now))
    }

    // -------------------------------------------------------------
    // Test 5: Carousel items appear in descending priority order
    // -------------------------------------------------------------
    @Test
    fun test5_carouselItemsAppearInDescendingPriorityOrder() = runTest {
        val now = System.currentTimeMillis()
        val lowPriorityItem = CarouselItem(
            id = "slide_low",
            title = "Low Priority Notice",
            priority = 10,
            isActive = true,
            startAt = now - 1000L,
            endAt = now + 10000L
        )
        val highPriorityItem = CarouselItem(
            id = "slide_high",
            title = "Urgent Festival Announcement",
            priority = 100,
            isActive = true,
            startAt = now - 1000L,
            endAt = now + 10000L
        )
        val mediumPriorityItem = CarouselItem(
            id = "slide_medium",
            title = "Standard Monthly Update",
            priority = 50,
            isActive = true,
            startAt = now - 1000L,
            endAt = now + 10000L
        )

        repository.saveCarouselItem(lowPriorityItem)
        repository.saveCarouselItem(highPriorityItem)
        repository.saveCarouselItem(mediumPriorityItem)

        val activeList = repository.getActiveCarouselItems(GLOBAL_GROUP_ID).first()
        assertEquals(3, activeList.size)
        assertEquals("slide_high", activeList[0].id)
        assertEquals(100, activeList[0].priority)
        assertEquals("slide_medium", activeList[1].id)
        assertEquals(50, activeList[1].priority)
        assertEquals("slide_low", activeList[2].id)
        assertEquals(10, activeList[2].priority)
    }

    // -------------------------------------------------------------
    // Test 6: Carousel items with image URLs display images correctly
    // -------------------------------------------------------------
    @Test
    fun test6_carouselItemsWithImageUrlsConfiguredCorrectly() {
        val imageItem = CarouselItem(
            id = "slide_img_1",
            title = "Diwali Greetings",
            message = "Wishing all members peace and prosperity",
            mediaResource = MediaResource(
                mediaId = "carousel/diwali_banner",
                publicUrl = "https://res.cloudinary.com/demo/image/upload/v1/carousel/diwali_banner.jpg",
                mediaType = MediaType.IMAGE,
                provider = StorageProviderType.CLOUDINARY,
                width = 1200,
                height = 630
            )
        )
        assertNotNull(imageItem.mediaResource)
        assertEquals(MediaType.IMAGE, imageItem.mediaResource?.mediaType)
        assertTrue(imageItem.mediaResource?.publicUrl?.startsWith("https://") == true)
        assertFalse(imageItem.isAnimatedMedia)
    }

    // -------------------------------------------------------------
    // Test 7: Carousel items with GIF URLs display animated GIFs correctly
    // -------------------------------------------------------------
    @Test
    fun test7_carouselItemsWithGifUrlsDisplayAnimatedGifsCorrectly() {
        val gifItem = CarouselItem(
            id = "slide_gif_1",
            title = "Happy New Year Celebration!",
            message = "Countdown to 2027",
            mediaResource = MediaResource(
                mediaId = "carousel/fireworks",
                publicUrl = "https://res.cloudinary.com/demo/image/upload/v1/carousel/fireworks.gif",
                mediaType = MediaType.GIF,
                contentType = "image/gif",
                provider = StorageProviderType.CLOUDINARY
            )
        )
        assertNotNull(gifItem.mediaResource)
        assertEquals(MediaType.GIF, gifItem.mediaResource?.mediaType)
        assertTrue(gifItem.isAnimatedMedia)
    }

    // -------------------------------------------------------------
    // Test 8: Carousel items without media display clean fallback content
    // -------------------------------------------------------------
    @Test
    fun test8_carouselItemsWithoutMediaDisplayCleanFallbackContent() {
        val textOnlyItem = CarouselItem(
            id = "slide_text_1",
            title = "Urgent Water Maintenance Notice",
            message = "Water supply will be interrupted tomorrow between 9 AM and 1 PM for maintenance work.",
            contentType = CarouselContentType.ANNOUNCEMENT,
            mediaResource = null
        )
        assertNull(textOnlyItem.mediaResource)
        assertEquals("Urgent Water Maintenance Notice", textOnlyItem.title)
        assertFalse(textOnlyItem.message.isBlank())
    }

    // -------------------------------------------------------------
    // Test 9: Auto-slide advances correctly using configured slide duration
    // -------------------------------------------------------------
    @Test
    fun test9_autoSlideAdvancesUsingConfiguredSlideDuration() {
        val customDurationItem = CarouselItem(
            id = "slide_dur_1",
            title = "Custom Duration Slide",
            slideDurationSeconds = 8
        )
        assertEquals(8, customDurationItem.slideDurationSeconds)
        val calculatedDuration = customDurationItem.slideDurationSeconds.takeIf { it > 0 } ?: 5
        assertEquals(8, calculatedDuration)
    }

    // -------------------------------------------------------------
    // Test 10: Auto-slide falls back to 5 seconds when duration is omitted or zero
    // -------------------------------------------------------------
    @Test
    fun test10_autoSlideFallsBackTo5SecondsWhenDurationIsOmittedOrZero() {
        val defaultItem = CarouselItem(
            id = "slide_zero_dur",
            title = "Default Duration Slide",
            slideDurationSeconds = 0
        )
        val calculatedDuration = defaultItem.slideDurationSeconds.takeIf { it > 0 } ?: 5
        assertEquals(5, calculatedDuration)

        val negativeItem = CarouselItem(
            id = "slide_neg_dur",
            title = "Negative Duration Slide",
            slideDurationSeconds = -3
        )
        val fallbackDuration = negativeItem.slideDurationSeconds.takeIf { it > 0 } ?: 5
        assertEquals(5, fallbackDuration)
    }

    // -------------------------------------------------------------
    // Test 11: Auto-slide pauses during user touch interaction
    // -------------------------------------------------------------
    @Test
    fun test11_autoSlidePausesDuringUserTouchInteraction() {
        var isUserInteracting = false
        val activeCount = 3

        // Simulate touch down
        isUserInteracting = true
        val shouldAdvance = activeCount > 1 && !isUserInteracting
        assertFalse("Auto-advance must pause when user is interacting", shouldAdvance)
    }

    // -------------------------------------------------------------
    // Test 12: Auto-slide resumes after user touch interaction ends
    // -------------------------------------------------------------
    @Test
    fun test12_autoSlideResumesAfterUserTouchInteractionEnds() {
        var isUserInteracting = true
        // User releases touch
        isUserInteracting = false
        val activeCount = 3
        val shouldAdvance = activeCount > 1 && !isUserInteracting
        assertTrue("Auto-advance must resume when user interaction completes", shouldAdvance)
    }

    // -------------------------------------------------------------
    // Test 13: Auto-slide handles animated GIFs correctly
    // -------------------------------------------------------------
    @Test
    fun test13_autoSlideHandlesAnimatedGifsCorrectly() {
        val gifItem = CarouselItem(
            id = "slide_gif_test",
            title = "Celebration GIF",
            slideDurationSeconds = 7,
            mediaResource = MediaResource(
                mediaId = "gif_1",
                publicUrl = "https://example.com/banner.gif",
                mediaType = MediaType.GIF
            )
        )
        assertTrue(gifItem.isAnimatedMedia)
        assertEquals(7, gifItem.slideDurationSeconds)
    }

    // -------------------------------------------------------------
    // Test 14: Swipe gesture advances to next slide
    // -------------------------------------------------------------
    @Test
    fun test14_swipeGestureAdvancesToNextSlide() {
        val totalSlides = 4
        var currentPage = 1
        // Forward swipe
        val nextPage = (currentPage + 1) % totalSlides
        assertEquals(2, nextPage)

        // Forward swipe at the last slide wraps to first
        currentPage = 3
        val wrappedPage = (currentPage + 1) % totalSlides
        assertEquals(0, wrappedPage)
    }

    // -------------------------------------------------------------
    // Test 15: Swipe gesture returns to previous slide
    // -------------------------------------------------------------
    @Test
    fun test15_swipeGestureReturnsToPreviousSlide() {
        val totalSlides = 4
        var currentPage = 2
        val prevPage = (currentPage - 1 + totalSlides) % totalSlides
        assertEquals(1, prevPage)

        // Previous slide from index 0 wraps to last
        currentPage = 0
        val wrappedPrev = (currentPage - 1 + totalSlides) % totalSlides
        assertEquals(3, wrappedPrev)
    }

    // -------------------------------------------------------------
    // Test 16: Dot indicators correctly reflect the active slide
    // -------------------------------------------------------------
    @Test
    fun test16_dotIndicatorsCorrectlyReflectActiveSlide() {
        val totalSlides = 3
        val currentPage = 1
        for (page in 0 until totalSlides) {
            val isSelected = (page == currentPage)
            if (page == 1) {
                assertTrue("Page 1 must be selected", isSelected)
            } else {
                assertFalse("Page $page must not be selected", isSelected)
            }
        }
    }

    // -------------------------------------------------------------
    // Test 17: Tapping a dot indicator jumps to the selected slide
    // -------------------------------------------------------------
    @Test
    fun test17_tappingDotIndicatorJumpsToSelectedSlide() {
        val targetPage = 2
        var activePage = 0
        val onSelectPage: (Int) -> Unit = { page -> activePage = page }
        onSelectPage(targetPage)
        assertEquals(2, activePage)
    }

    // -------------------------------------------------------------
    // Test 18: Internal navigation CTA opens the correct screen
    // -------------------------------------------------------------
    @Test
    fun test18_internalNavigationCtaOpensCorrectScreen() {
        var navigatedScreen: String? = null
        var navigatedRoute: String? = null

        val screenItem = CarouselItem(
            id = "slide_cta_screen",
            title = "Pay Monthly Dues Online",
            actionType = CarouselActionType.INTERNAL_SCREEN,
            actionTarget = "record_payment",
            actionLabel = "Pay Now"
        )

        handleCarouselAction(
            context = context,
            item = screenItem,
            onNavigateToRoute = { navigatedRoute = it },
            onNavigateToScreen = { navigatedScreen = it }
        )

        assertEquals("record_payment", navigatedScreen)
        assertNull(navigatedRoute)

        // Internal route test
        val routeItem = CarouselItem(
            id = "slide_cta_route",
            title = "View Dues Register",
            actionType = CarouselActionType.INTERNAL_ROUTE,
            actionTarget = "dues_summary",
            actionLabel = "View Register"
        )

        handleCarouselAction(
            context = context,
            item = routeItem,
            onNavigateToRoute = { navigatedRoute = it },
            onNavigateToScreen = { navigatedScreen = it }
        )

        assertEquals("dues_summary", navigatedRoute)
    }

    // -------------------------------------------------------------
    // Test 19: External URL CTA opens the browser safely
    // -------------------------------------------------------------
    @Test
    fun test19_externalUrlCtaOpensBrowserSafely() {
        // Safe HTTPS URL
        assertTrue(isSafeExternalUrl("https://example.com/festival_offer"))
        assertTrue(isSafeExternalUrl("http://example.com/announcement"))

        // Block unsafe, local, or script schemes
        assertFalse(isSafeExternalUrl("javascript:alert('attack')"))
        assertFalse(isSafeExternalUrl("file:///data/system/users"))
        assertFalse(isSafeExternalUrl("content://media/external/images"))
        assertFalse(isSafeExternalUrl("intent://run_activity"))
        assertFalse(isSafeExternalUrl("ftp://files.example.com"))
        assertFalse(isSafeExternalUrl(""))
        assertFalse(isSafeExternalUrl("   "))
        assertFalse(isSafeExternalUrl("https://")) // No host
    }

    // -------------------------------------------------------------
    // Test 20: Empty carousel state does not break or misalign Home Screen
    // -------------------------------------------------------------
    @Test
    fun test20_emptyCarouselStateDoesNotBreakHomeScreen() = runTest {
        val activeList = repository.getActiveCarouselItems(GLOBAL_GROUP_ID).first()
        assertTrue(activeList.isEmpty())

        val now = System.currentTimeMillis()
        val filtered = activeList.filter { it.isCurrentlyActive(now) }
        assertTrue(filtered.isEmpty())
        // Empty state verifies cleanly without throwing or crashing
    }
}
