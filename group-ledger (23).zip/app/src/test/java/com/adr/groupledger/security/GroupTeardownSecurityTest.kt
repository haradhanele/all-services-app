package com.adr.groupledger.security

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.adr.groupledger.data.firebase.FirebaseService
import com.adr.groupledger.data.local.AppDatabase
import com.adr.groupledger.data.model.GroupJoinRequest
import com.adr.groupledger.data.model.GroupMembership
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.data.model.Member
import com.adr.groupledger.data.model.Payment
import com.adr.groupledger.data.model.PreAuthorizedMember
import com.adr.groupledger.data.model.SocietyNotice
import com.adr.groupledger.data.model.UserAccount
import com.adr.groupledger.data.repository.SocietyRepository
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Phase 11 — Task 7: Member Deletion, Group Leave & Complete Group Cascading Teardown Test Suite
 *
 * Verifies:
 * 1. Cascading deletion paths target all expected subcollections and parent document.
 * 2. Non-owners attempting group deletion are strictly rejected with SecurityException.
 * 3. Verified owner successfully executes deletion flow.
 * 4. Local Room cascading teardown cleanly deletes all related records while preserving other groups.
 * 5. Member removal cleans up member record and associations without affecting parent group integrity.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class GroupTeardownSecurityTest {

    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var firebaseService: FirebaseService
    private lateinit var repository: SocietyRepository

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        firebaseService = FirebaseService(context)
        repository = SocietyRepository(
            userAccountDao = db.userAccountDao(),
            groupMembershipDao = db.groupMembershipDao(),
            memberDao = db.memberDao(),
            paymentDao = db.paymentDao(),
            groupSettingsDao = db.groupSettingsDao(),
            noticeDao = db.noticeDao(),
            loanDao = db.loanDao(),
            investmentDao = db.investmentDao(),
            feedbackDao = db.feedbackDao(),
            notificationDao = db.notificationDao(),
            transactionDao = db.transactionDao(),
            auditLogDao = db.auditLogDao(),
            chatMessageDao = db.chatMessageDao(),
            preAuthorizedMemberDao = db.preAuthorizedMemberDao(),
            groupJoinRequestDao = db.groupJoinRequestDao(),
            firebaseService = firebaseService
        )
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun test1_CascadingTeardown_TargetsAllExpectedSubcollectionsAndParentDocument() {
        val groupId = 901L

        // 1. Verify all required subcollections are targeted
        val targetSubcollections = firebaseService.getGroupTeardownTargetSubcollections()
        val expectedSubcollections = listOf(
            "members",
            "transactions",
            "payments",
            "loans",
            "notices",
            "pendingRequests",
            "preAuthorizedMembers"
        )
        for (expected in expectedSubcollections) {
            assertTrue(
                "Cascading teardown must target subcollection '$expected'",
                targetSubcollections.contains(expected)
            )
        }

        // 2. Verify path formatting
        val expectedDocPath = "groups/$groupId"
        assertEquals("Parent document path must resolve correctly", expectedDocPath, firebaseService.getGroupTeardownDocumentPath(groupId))

        for (subcol in expectedSubcollections) {
            val expectedPath = "groups/$groupId/$subcol"
            assertEquals("Subcollection path for '$subcol' must resolve correctly",
                expectedPath, firebaseService.getGroupSubcollectionPath(groupId, subcol))
        }
    }

    @Test
    fun test2_NonOwnerAttemptingGroupDeletion_StrictlyRejected() = runBlocking {
        val groupId = 902L
        val realOwnerUid = "auth_owner_true_902"
        val intruderUid = "auth_intruder_fake_999"

        val group = GroupSettings(
            id = groupId,
            groupName = "Secure Group Alpha",
            ownerUid = realOwnerUid,
            createdByUserId = 1001L
        )

        // Non-owner validation check
        val authResult = firebaseService.verifyGroupDeletionAuthorization(group, intruderUid)
        assertTrue("Deletion authorization for non-owner must fail", authResult.isFailure)
        assertTrue(
            "Exception must be SecurityException",
            authResult.exceptionOrNull() is SecurityException
        )

        // Blank requester UID rejection
        val blankResult = firebaseService.verifyGroupDeletionAuthorization(group, "   ")
        assertTrue("Blank requester UID must be rejected", blankResult.isFailure)

        // Non-positive groupId rejection
        val invalidGroup = group.copy(id = 0L)
        val invalidResult = firebaseService.verifyGroupDeletionAuthorization(invalidGroup, realOwnerUid)
        assertTrue("Invalid groupId <= 0 must be rejected", invalidResult.isFailure)
    }

    @Test
    fun test3_VerifiedOwner_SuccessfullyExecutesDeletionFlow() = runBlocking {
        val groupId = 903L
        val ownerUid = "auth_owner_verified_903"

        val group = GroupSettings(
            id = groupId,
            groupName = "Verified Society",
            ownerUid = ownerUid,
            createdByUserId = 1003L
        )

        // 1. Owner authorization check succeeds
        val authResult = firebaseService.verifyGroupDeletionAuthorization(group, ownerUid)
        assertTrue("Verified owner authorization must succeed", authResult.isSuccess)

        // 2. Numeric ID string mapping also succeeds
        val numericMappingResult = firebaseService.verifyGroupDeletionAuthorization(group, "1003")
        assertTrue("Creator numeric ID string authorization must succeed", numericMappingResult.isSuccess)

        // 3. Execution of deleteGroupCompletely
        val deleteResult = firebaseService.deleteGroupCompletely(groupId, ownerUid)
        assertTrue("Owner deleteGroupCompletely must succeed", deleteResult.isSuccess)
    }

    @Test
    fun test4_LocalRoomCascadingTeardown_DeletesAllRelatedRecords() = runBlocking {
        val targetGroupId = 904L
        val otherGroupId = 905L
        val ownerUid = "owner_uid_904"

        // Insert target group
        db.groupSettingsDao().insertOrUpdate(
            GroupSettings(
                id = targetGroupId,
                groupName = "Target Group For Deletion",
                ownerUid = ownerUid,
                createdByUserId = 401L
            )
        )
        // Insert other group
        db.groupSettingsDao().insertOrUpdate(
            GroupSettings(
                id = otherGroupId,
                groupName = "Preserved Group",
                ownerUid = "other_owner_905",
                createdByUserId = 402L
            )
        )

        // Insert target group related records
        db.memberDao().insertMember(Member(id = 10L, groupId = targetGroupId, name = "Target Member"))
        db.paymentDao().insertPayment(Payment(id = 10L, groupId = targetGroupId, memberId = 10L, expectedAmount = 500.0, paidAmount = 500.0, month = 1, year = 2026))
        db.noticeDao().insertNotice(SocietyNotice(id = 10L, groupId = targetGroupId, title = "Notice 1", content = "Desc"))
        db.preAuthorizedMemberDao().insertOrUpdate(PreAuthorizedMember(id = 10L, groupId = targetGroupId, name = "PreAuth 1", email = "p1@test.com"))
        db.groupJoinRequestDao().insert(GroupJoinRequest(id = 10L, groupId = targetGroupId, groupName = "Target Group", userId = 100L, name = "User 1", email = "u1@test.com"))
        db.groupMembershipDao().insertMembership(GroupMembership(id = 10L, userId = 100L, groupId = targetGroupId, role = "MEMBER"))

        // Insert other group related records
        db.memberDao().insertMember(Member(id = 20L, groupId = otherGroupId, name = "Other Member"))
        db.paymentDao().insertPayment(Payment(id = 20L, groupId = otherGroupId, memberId = 20L, expectedAmount = 700.0, paidAmount = 700.0, month = 1, year = 2026))
        db.noticeDao().insertNotice(SocietyNotice(id = 20L, groupId = otherGroupId, title = "Other Notice", content = "Desc"))
        db.preAuthorizedMemberDao().insertOrUpdate(PreAuthorizedMember(id = 20L, groupId = otherGroupId, name = "PreAuth 2", email = "p2@test.com"))
        db.groupJoinRequestDao().insert(GroupJoinRequest(id = 20L, groupId = otherGroupId, groupName = "Other Group", userId = 200L, name = "User 2", email = "u2@test.com"))
        db.groupMembershipDao().insertMembership(GroupMembership(id = 20L, userId = 200L, groupId = otherGroupId, role = "MEMBER"))

        // Execute cascading teardown by verified owner
        val deleteSuccess = repository.deleteGroup(targetGroupId, ownerUid)
        assertTrue("deleteGroup must return true on success", deleteSuccess)

        // Verify target group records are completely wiped
        assertNull("Target group settings must be deleted", db.groupSettingsDao().getGroupById(targetGroupId))
        assertEquals("Target group members must be deleted", 0, db.memberDao().getMembersForGroupSync(targetGroupId).size)
        assertEquals("Target group payments must be deleted", 0, db.paymentDao().getAllPaymentsDirect(targetGroupId).size)
        assertEquals("Target group notices must be deleted", 0, db.noticeDao().getNoticesForGroupDirect(targetGroupId).size)
        assertEquals("Target group pre-auth members must be deleted", 0, db.preAuthorizedMemberDao().getPreAuthorizedMembersDirect(targetGroupId).size)
        assertEquals("Target group join requests must be deleted", 0, db.groupJoinRequestDao().getPendingRequestsDirect(targetGroupId).size)
        assertEquals("Target group memberships must be deleted", 0, db.groupMembershipDao().getMembershipsForGroup(targetGroupId).size)

        // Verify other group records remain intact (Multi-Tenant Isolation)
        assertNotNull("Other group settings must remain intact", db.groupSettingsDao().getGroupById(otherGroupId))
        assertEquals("Other group members must remain intact", 1, db.memberDao().getMembersForGroupSync(otherGroupId).size)
        assertEquals("Other group payments must remain intact", 1, db.paymentDao().getAllPaymentsDirect(otherGroupId).size)
        assertEquals("Other group notices must remain intact", 1, db.noticeDao().getNoticesForGroupDirect(otherGroupId).size)
        assertEquals("Other group pre-auth members must remain intact", 1, db.preAuthorizedMemberDao().getPreAuthorizedMembersDirect(otherGroupId).size)
        assertEquals("Other group memberships must remain intact", 1, db.groupMembershipDao().getMembershipsForGroup(otherGroupId).size)
    }

    @Test
    fun test5_MemberRemoval_CleansUpGroupSubcollectionWithoutAffectingParentGroupIntegrity() = runBlocking {
        val groupId = 906L
        val memberAuthUid = "auth_member_uid_906"
        val memberUserId = 555L

        // Insert group
        val group = GroupSettings(
            id = groupId,
            groupName = "Member Removal Test Group",
            ownerUid = "owner_uid_906",
            createdByUserId = 101L
        )
        db.groupSettingsDao().insertOrUpdate(group)

        // Insert user and member
        db.userAccountDao().insertUser(
            UserAccount(
                id = memberUserId,
                fullName = "Member User",
                email = "member@example.com"
            )
        )
        val member = Member(
            id = 301L,
            groupId = groupId,
            name = "Member User",
            email = "member@example.com",
            linkedUid = memberAuthUid
        )
        db.memberDao().insertMember(member)
        db.groupMembershipDao().insertMembership(
            GroupMembership(id = 301L, userId = memberUserId, groupId = groupId, role = "MEMBER")
        )
        db.groupJoinRequestDao().insert(
            GroupJoinRequest(id = 301L, groupId = groupId, groupName = group.groupName, userId = memberUserId, name = "Member User", email = "member@example.com")
        )

        // Remove member via repository
        repository.deleteMember(member)

        // Member local records should be deleted
        assertNull("Member must be deleted from member table", db.memberDao().getMemberById(member.id))
        assertNull("Membership must be deleted", db.groupMembershipDao().getMembershipDirect(memberUserId, groupId))
        assertNull("Join request must be deleted", db.groupJoinRequestDao().getRequestForUserAndGroup(memberUserId, groupId))

        // Parent group document MUST remain intact
        val parentGroup = db.groupSettingsDao().getGroupById(groupId)
        assertNotNull("Parent group must remain intact after individual member deletion", parentGroup)
        assertEquals("Parent group name must be unchanged", "Member Removal Test Group", parentGroup?.groupName)

        // Verify Firebase removeMemberFromGroup executes cleanly
        val removeResult = firebaseService.removeMemberFromGroup(groupId, member.id, memberAuthUid)
        assertTrue("removeMemberFromGroup must succeed", removeResult.isSuccess)
    }
}
