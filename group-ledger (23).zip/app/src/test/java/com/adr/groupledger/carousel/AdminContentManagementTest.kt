package com.adr.groupledger.carousel

import com.adr.groupledger.data.model.AppRole
import com.adr.groupledger.data.model.GroupRole
import com.adr.groupledger.data.model.carousel.CarouselActionType
import com.adr.groupledger.data.model.carousel.CarouselContentType
import com.adr.groupledger.data.model.carousel.CarouselItem
import com.adr.groupledger.data.model.carousel.GLOBAL_GROUP_ID
import com.adr.groupledger.data.repository.carousel.InMemoryCarouselRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AdminContentManagementTest {

    @Test
    fun testGroupAdminIsNotAppAdmin() {
        // A user who is Group Admin of CC CUP has GroupRole.ADMIN
        val groupAdminRole = GroupRole.ADMIN
        assertTrue("Group Admin must have group-level admin privileges", groupAdminRole.isGroupAdmin)

        // But their AppRole defaults to REGULAR_USER
        val defaultAppRole = AppRole.REGULAR_USER
        assertFalse("Group Admin must not automatically receive carousel management privileges", defaultAppRole.canManageCarousel)
        assertFalse("Group Admin must not be App Admin", defaultAppRole.isAppAdmin)
        assertFalse("Group Admin must not be Content Manager", defaultAppRole.isContentManager)

        // Only explicitly granted AppRoles have carousel management access
        assertTrue("APP_ADMIN can manage carousel", AppRole.APP_ADMIN.canManageCarousel)
        assertTrue("CONTENT_MANAGER can manage carousel", AppRole.CONTENT_MANAGER.canManageCarousel)
    }

    @Test
    fun testGlobalGroupIdSemantics() {
        assertEquals("GLOBAL_GROUP_ID must be 0L", 0L, GLOBAL_GROUP_ID)

        val globalItem = CarouselItem(
            id = "global_1",
            groupId = GLOBAL_GROUP_ID,
            title = "Global Notice",
            message = "Notice for all groups"
        )
        assertTrue("Item with groupId=0L is global content", globalItem.isGlobalContent)

        val groupItem = CarouselItem(
            id = "group_101",
            groupId = 101L, // Specific to group 101 (e.g. CC CUP)
            title = "CC CUP Notice",
            message = "Notice only for CC CUP"
        )
        assertFalse("Item with groupId > 0L is not global content", groupItem.isGlobalContent)
    }

    @Test
    fun testInMemoryRepositoryCRUD() = runBlocking {
        val repository = InMemoryCarouselRepository.getInstance()

        // 1. Verify initial sample items contain required content types
        val initialItems = repository.getAllCarouselItems(GLOBAL_GROUP_ID).first()
        assertTrue("Initial items should not be empty", initialItems.isNotEmpty())

        val contentTypes = initialItems.map { it.contentType }.toSet()
        assertTrue("Must support FESTIVAL", contentTypes.contains(CarouselContentType.FESTIVAL))
        assertTrue("Must support ANNOUNCEMENT", contentTypes.contains(CarouselContentType.ANNOUNCEMENT))
        assertTrue("Must support BIRTHDAY", contentTypes.contains(CarouselContentType.BIRTHDAY))
        assertTrue("Must support PROMOTION", contentTypes.contains(CarouselContentType.PROMOTION))
        assertTrue("Must support OFFER", contentTypes.contains(CarouselContentType.OFFER))

        // 2. Create new item
        val newItem = CarouselItem(
            id = "",
            groupId = GLOBAL_GROUP_ID,
            contentType = CarouselContentType.CELEBRATION,
            title = "Annual Gathering 2026",
            message = "Join us for our yearly celebration",
            priority = 15,
            isActive = true,
            actionType = CarouselActionType.INTERNAL_SCREEN,
            actionLabel = "View Event",
            actionTarget = "events"
        )
        val saveResult = repository.saveCarouselItem(newItem)
        assertTrue("Save must succeed", saveResult.isSuccess)
        val savedId = saveResult.getOrNull()
        assertNotNull("Saved ID should not be null", savedId)

        // 3. Read back
        val fetchedItem = repository.getCarouselItemById(savedId!!)
        assertNotNull("Item should be retrievable by ID", fetchedItem)
        assertEquals("Annual Gathering 2026", fetchedItem?.title)
        assertEquals(CarouselContentType.CELEBRATION, fetchedItem?.contentType)
        assertEquals(15, fetchedItem?.priority)

        // 4. Update item priority
        val priorityResult = repository.updateItemPriority(savedId, 25)
        assertTrue("Priority update must succeed", priorityResult.isSuccess)
        val updatedItem = repository.getCarouselItemById(savedId)
        assertEquals(25, updatedItem?.priority)

        // 5. Toggle active status
        val toggleResult = repository.setItemActiveStatus(savedId, false)
        assertTrue("Status toggle must succeed", toggleResult.isSuccess)
        val toggledItem = repository.getCarouselItemById(savedId)
        assertFalse("Item should now be inactive", toggledItem?.isActive ?: true)

        // 6. Delete item
        val deleteResult = repository.deleteCarouselItem(savedId)
        assertTrue("Delete must succeed", deleteResult.isSuccess)
        val afterDelete = repository.getCarouselItemById(savedId)
        assertNull("Item should be null after deletion", afterDelete)
    }
}
