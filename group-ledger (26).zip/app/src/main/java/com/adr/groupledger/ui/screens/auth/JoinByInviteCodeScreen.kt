package com.adr.groupledger.ui.screens.auth

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adr.groupledger.data.model.GroupSettings
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500
import com.adr.groupledger.ui.viewmodel.SocietyViewModel

/**
 * Screen: Multi-step "Join by Invitation Code" Flow
 * Step 1: Input & verify Invitation Code. Displays verified group name with green checkmark (✔).
 * Step 2: Dynamically reveals "Enter your Name" and "Enter Phone Number or Email ID".
 * Matches against pre-added members and claims profile to navigate directly to Dashboard.
 */
@Composable
fun JoinByInviteCodeScreen(
    viewModel: SocietyViewModel,
    onNavigateBack: () -> Unit,
    onJoinSuccess: (groupName: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()

    val authLoading by viewModel.authLoading.collectAsStateWithLifecycle()
    val authError by viewModel.authError.collectAsStateWithLifecycle()

    var inviteCode by remember { mutableStateOf("") }
    var verifiedGroup by remember { mutableStateOf<GroupSettings?>(null) }
    var inlineError by remember { mutableStateOf<String?>(null) }

    // Step 2 Form Fields
    var memberName by remember { mutableStateOf("") }
    var memberContact by remember { mutableStateOf("") }
    var nameError by remember { mutableStateOf<String?>(null) }
    var contactError by remember { mutableStateOf<String?>(null) }

    // Automatically clear errors upon entering or exiting Invite Code screen
    DisposableEffect(Unit) {
        viewModel.clearAuthError()
        viewModel.clearError()
        inlineError = null
        onDispose {
            viewModel.clearAuthError()
            viewModel.clearError()
        }
    }

    fun verifyCode() {
        val trimmed = inviteCode.trim().uppercase()
        if (trimmed.isBlank()) {
            inlineError = "Invalid Invitation Code"
            return
        }
        inlineError = null
        focusManager.clearFocus()
        viewModel.verifyInviteCode(
            inviteCode = trimmed,
            onSuccess = { group ->
                verifiedGroup = group
                inlineError = null
            },
            onError = { err ->
                inlineError = "Invalid Invitation Code"
            }
        )
    }

    fun submitJoinDetails() {
        var hasErr = false
        if (memberName.trim().isBlank()) {
            nameError = "Please enter your name"
            hasErr = true
        } else {
            nameError = null
        }

        if (memberContact.trim().isBlank()) {
            contactError = "Please enter your phone number or email ID"
            hasErr = true
        } else {
            contactError = null
        }

        if (hasErr) return

        val group = verifiedGroup ?: return
        focusManager.clearFocus()
        inlineError = null

        viewModel.claimAndJoinGroupByDetails(
            group = group,
            name = memberName,
            contact = memberContact,
            onSuccess = { groupName ->
                onJoinSuccess(groupName)
            },
            onError = { err ->
                inlineError = err
            }
        )
    }

    val bgGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF090D16),
            Color(0xFF0F172A),
            Color(0xFF131C31)
        )
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(bgGradient)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        // Top App Bar with Back Button
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            IconButton(
                onClick = onNavigateBack,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color(0xFF1E293B).copy(alpha = 0.6f))
                    .testTag("invite_code_back_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color(0xFFF8FAFC)
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 24.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Key Icon Badge
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(60.dp)
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF312E81), Color(0xFF4338CA))
                            ),
                            RoundedCornerShape(18.dp)
                        )
                        .border(
                            1.dp,
                            Color(0xFF6366F1).copy(alpha = 0.4f),
                            RoundedCornerShape(18.dp)
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.VpnKey,
                        contentDescription = "Invitation Code",
                        tint = Color(0xFFA5B4FC),
                        modifier = Modifier.size(30.dp)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Title
                Text(
                    text = if (verifiedGroup == null) "Join Your Group" else "Verify Member Profile",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFF8FAFC)
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Description
                Text(
                    text = if (verifiedGroup == null)
                        "Enter the invitation code provided by your group admin to continue."
                    else
                        "Group found! Enter your registered details below to claim your member profile and enter the dashboard.",
                    fontSize = 14.sp,
                    color = Color(0xFF94A3B8),
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(24.dp))

                // -------------------------------------------------------------
                // Step 1: Invitation Code Input Box
                // -------------------------------------------------------------
                Text(
                    text = "Invitation Code",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFFE2E8F0)
                )

                Spacer(modifier = Modifier.height(8.dp))

                if (verifiedGroup == null) {
                    val hasError = inlineError != null || authError != null
                    OutlinedTextField(
                        value = inviteCode,
                        onValueChange = {
                            inviteCode = it.uppercase()
                            inlineError = null
                            viewModel.clearAuthError()
                        },
                        placeholder = {
                            Text(
                                "e.g. GRP-1001",
                                color = Color(0xFF64748B),
                                fontFamily = FontFamily.Monospace
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.VpnKey,
                                contentDescription = null,
                                tint = if (hasError) Rose500 else Color(0xFF818CF8)
                            )
                        },
                        trailingIcon = {
                            if (hasError) {
                                // If code is wrong: show pencil icon for correction
                                IconButton(onClick = {
                                    inlineError = null
                                    viewModel.clearAuthError()
                                }) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Correct Code",
                                        tint = Rose500
                                    )
                                }
                            } else if (inviteCode.isNotEmpty()) {
                                IconButton(onClick = {
                                    inviteCode = ""
                                    inlineError = null
                                }) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Clear",
                                        tint = Color(0xFF94A3B8)
                                    )
                                }
                            }
                        },
                        textStyle = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            color = Color(0xFFF8FAFC)
                        ),
                        isError = hasError,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Characters,
                            keyboardType = KeyboardType.Ascii,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = { verifyCode() }
                        ),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF161F36),
                            unfocusedContainerColor = Color(0xFF131B2E),
                            focusedBorderColor = IndigoPrimary,
                            unfocusedBorderColor = Color(0xFF334155),
                            errorBorderColor = Rose500,
                            focusedTextColor = Color(0xFFF8FAFC),
                            unfocusedTextColor = Color(0xFFF8FAFC)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("invite_code_input")
                    )
                } else {
                    // Valid Code Verified Box with Group Name & Clear Green Checkmark (✔) on the right side
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xFF064E3B).copy(alpha = 0.4f),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF10B981)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("verified_group_card")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(38.dp)
                                        .background(Color(0xFF065F46), RoundedCornerShape(10.dp))
                                        .border(1.dp, Color(0xFF10B981).copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Groups,
                                        contentDescription = null,
                                        tint = Color(0xFFA7F3D0),
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = verifiedGroup!!.groupName,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFECFDF5)
                                    )
                                    Text(
                                        text = "Code: ${verifiedGroup!!.inviteCode} • Verified ✔",
                                        fontSize = 12.sp,
                                        color = Color(0xFF6EE7B7),
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            // Green tick icon on right side (green ঠিক, no pencil icon)
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(Color(0xFF10B981), CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Code Verified",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }

                // Error Message Box
                val displayError = inlineError ?: authError
                if (displayError != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF4C0519).copy(alpha = 0.8f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Rose500.copy(alpha = 0.6f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = "Error",
                                tint = Rose500,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = displayError,
                                fontSize = 13.sp,
                                color = Color(0xFFFFE4E6),
                                lineHeight = 18.sp
                            )
                        }
                    }
                }

                // -------------------------------------------------------------
                // Step 2: Dynamically Revealed Input Fields
                // -------------------------------------------------------------
                AnimatedVisibility(
                    visible = verifiedGroup != null,
                    enter = fadeIn() + slideInVertically()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 22.dp)
                    ) {
                        // Section Header
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFF1E293B).copy(alpha = 0.6f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Groups,
                                    contentDescription = null,
                                    tint = Color(0xFF818CF8),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Member Verification Details",
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFE2E8F0)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Field 1: Enter your Name
                        Text(
                            text = "Enter your Name",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFE2E8F0)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = memberName,
                            onValueChange = {
                                memberName = it
                                nameError = null
                                inlineError = null
                            },
                            placeholder = { Text("e.g. Rahul Sharma", color = Color(0xFF64748B)) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = if (nameError != null) Rose500 else Color(0xFF818CF8)
                                )
                            },
                            isError = nameError != null,
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.Words,
                                imeAction = ImeAction.Next
                            ),
                            keyboardActions = KeyboardActions(
                                onNext = { focusManager.clearFocus() }
                            ),
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF161F36),
                                unfocusedContainerColor = Color(0xFF131B2E),
                                focusedBorderColor = IndigoPrimary,
                                unfocusedBorderColor = Color(0xFF334155),
                                errorBorderColor = Rose500,
                                focusedTextColor = Color(0xFFF8FAFC),
                                unfocusedTextColor = Color(0xFFF8FAFC)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("join_member_name_input")
                        )
                        if (nameError != null) {
                            Text(
                                text = nameError!!,
                                color = Rose500,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(start = 6.dp, top = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // Field 2: Enter Phone Number or Email ID
                        Text(
                            text = "Enter Phone Number or Email ID",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFE2E8F0)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = memberContact,
                            onValueChange = {
                                memberContact = it
                                contactError = null
                                inlineError = null
                            },
                            placeholder = { Text("e.g. 9830012345 or user@email.com", color = Color(0xFF64748B)) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Phone,
                                    contentDescription = null,
                                    tint = if (contactError != null) Rose500 else Color(0xFF818CF8)
                                )
                            },
                            isError = contactError != null,
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Email,
                                imeAction = ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(
                                onDone = { submitJoinDetails() }
                            ),
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF161F36),
                                unfocusedContainerColor = Color(0xFF131B2E),
                                focusedBorderColor = IndigoPrimary,
                                unfocusedBorderColor = Color(0xFF334155),
                                errorBorderColor = Rose500,
                                focusedTextColor = Color(0xFFF8FAFC),
                                unfocusedTextColor = Color(0xFFF8FAFC)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("join_member_contact_input")
                        )
                        if (contactError != null) {
                            Text(
                                text = contactError!!,
                                color = Rose500,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(start = 6.dp, top = 4.dp)
                            )
                        }
                    }
                }
            }

            // -------------------------------------------------------------
            // Primary Action Button
            // -------------------------------------------------------------
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
            ) {
                Button(
                    onClick = {
                        if (verifiedGroup == null) {
                            verifyCode()
                        } else {
                            submitJoinDetails()
                        }
                    },
                    enabled = !authLoading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .shadow(
                            elevation = 8.dp,
                            shape = RoundedCornerShape(14.dp),
                            spotColor = IndigoPrimary.copy(alpha = 0.5f)
                        )
                        .testTag("invite_code_submit_btn"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (verifiedGroup != null) Color(0xFF059669) else IndigoPrimary,
                        contentColor = Color.White,
                        disabledContainerColor = if (verifiedGroup != null) Color(0xFF059669) else IndigoPrimary,
                        disabledContentColor = Color.White
                    )
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        if (authLoading) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (verifiedGroup == null) "Verifying Code..." else "Joining Group...",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        } else {
                            Text(
                                text = if (verifiedGroup == null) "Verify Invitation Code" else "Claim Profile & Join Group",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
