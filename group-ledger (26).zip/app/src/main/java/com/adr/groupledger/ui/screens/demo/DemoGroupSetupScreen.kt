package com.adr.groupledger.ui.screens.demo

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Rule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adr.groupledger.ui.theme.Emerald500
import com.adr.groupledger.ui.theme.IndigoPrimary
import com.adr.groupledger.ui.theme.Rose500

/**
 * Modern, standalone DEMO Group Setup & Multi-Category Settings Page.
 * Pure UI/UX demonstration without altering any production databases or logic.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DemoGroupSetupScreen(
    onNavigateBack: () -> Unit = {},
    onFinishDemo: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var state by remember { mutableStateOf(DemoGroupSetupState()) }
    var showSuccessDialog by remember { mutableStateOf(false) }
    var nameError by remember { mutableStateOf<String?>(null) }

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Group Setup (Demo)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${state.currentStep.stepNumber} of 5 • ${state.currentStep.title}",
                            fontSize = 11.5.sp,
                            color = IndigoPrimary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (state.currentStep.stepNumber > 1) {
                                val prevStep = SetupStep.entries[state.currentStep.stepNumber - 2]
                                state = state.copy(currentStep = prevStep)
                            } else {
                                onNavigateBack()
                            }
                        },
                        modifier = Modifier.testTag("demo_setup_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                actions = {
                    if (state.isMinimumRequiredComplete) {
                        TextButton(
                            onClick = { showSuccessDialog = true },
                            modifier = Modifier.testTag("demo_complete_later_top_btn")
                        ) {
                            Text(
                                text = "Complete Later",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = IndigoPrimary
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            DemoSetupBottomBar(
                currentStep = state.currentStep,
                isMinimumRequiredComplete = state.isMinimumRequiredComplete,
                onSaveAndContinue = {
                    if (state.currentStep == SetupStep.BASIC_INFO && state.groupName.trim().isBlank()) {
                        nameError = "Please enter your group name."
                    } else {
                        nameError = null
                        if (state.currentStep.stepNumber < 5) {
                            val nextStep = SetupStep.entries[state.currentStep.stepNumber]
                            state = state.copy(currentStep = nextStep)
                        } else {
                            showSuccessDialog = true
                        }
                    }
                },
                onCompleteLater = {
                    showSuccessDialog = true
                },
                onCreateEarly = {
                    if (state.groupName.trim().isBlank()) {
                        nameError = "Please enter your group name."
                    } else {
                        showSuccessDialog = true
                    }
                }
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Setup Progress Header Card
            SetupProgressHeader(
                progressPercent = state.progressPercentage,
                currentStep = state.currentStep,
                onStepClick = { targetStep ->
                    state = state.copy(currentStep = targetStep)
                }
            )

            // Step Content Animated Container
            AnimatedContent(
                targetState = state.currentStep,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "step_transition"
            ) { currentStep ->
                when (currentStep) {
                    SetupStep.BASIC_INFO -> Step1BasicInformation(
                        state = state,
                        nameError = nameError,
                        onStateChange = { updated ->
                            state = updated
                            if (updated.groupName.isNotBlank()) nameError = null
                        }
                    )
                    SetupStep.MONEY_COLLECTION -> Step2MoneyCollection(
                        state = state,
                        onStateChange = { state = it }
                    )
                    SetupStep.FEATURES_SERVICES -> Step3FeaturesServices(
                        state = state,
                        onStateChange = { state = it }
                    )
                    SetupStep.GROUP_RULES -> Step4GroupRules(
                        state = state,
                        onStateChange = { state = it }
                    )
                    SetupStep.ADVANCED -> Step5AdvancedSettings(
                        state = state,
                        onStateChange = { state = it }
                    )
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }

    if (showSuccessDialog) {
        DemoGroupCreatedDialog(
            groupName = state.groupName.ifBlank { "All Services Group" },
            progressPercent = state.progressPercentage,
            inviteCode = state.demoInviteCode,
            onContinueSetup = {
                showSuccessDialog = false
                if (state.currentStep.stepNumber < 5) {
                    val nextStep = SetupStep.entries[state.currentStep.stepNumber]
                    state = state.copy(currentStep = nextStep)
                }
            },
            onGoToGroup = {
                showSuccessDialog = false
                onFinishDemo()
            },
            onDismiss = { showSuccessDialog = false }
        )
    }
}

/**
 * STEP 1: Basic Information
 */
@Composable
private fun Step1BasicInformation(
    state: DemoGroupSetupState,
    nameError: String?,
    onStateChange: (DemoGroupSetupState) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Step Title Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "1 of 5 • Basic Information",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = IndigoPrimary
                )
                Text(
                    text = "Tell us a little about your group to get started.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Required Group Name Input
        OutlinedTextField(
            value = state.groupName,
            onValueChange = { onStateChange(state.copy(groupName = it)) },
            label = { Text("Group Name *") },
            placeholder = { Text("e.g. All Services Group, Puja Committee...") },
            isError = nameError != null,
            supportingText = {
                if (nameError != null) {
                    Text(text = nameError, color = Rose500, fontSize = 11.sp)
                } else {
                    Text(text = "Required • The primary name displayed to all members", fontSize = 11.sp)
                }
            },
            leadingIcon = {
                Icon(Icons.Default.Groups, contentDescription = null, tint = IndigoPrimary)
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("demo_group_name_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = IndigoPrimary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
            )
        )

        // 10 Categories Header & Selection
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Select Group Category *",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = IndigoPrimary.copy(alpha = 0.10f)
                ) {
                    Text(
                        text = "${GroupCategory.entries.size} Types Available",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = IndigoPrimary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            GroupCategory.entries.forEach { category ->
                val isSelected = category == state.selectedCategory
                CategoryCard(
                    category = category,
                    isSelected = isSelected,
                    onClick = {
                        val newDefaults = category.defaultFeatures
                        val newSub = category.defaultSubCategories.firstOrNull() ?: "Other"
                        onStateChange(
                            state.copy(
                                selectedCategory = category,
                                selectedSubCategory = newSub,
                                collectionType = category.defaultContributionType,
                                contributionAmount = category.defaultAmount,
                                enabledFeatures = newDefaults
                            )
                        )
                    }
                )
            }
        }

        // Sub-Category Chip Selector (Dynamic for selected category)
        SubCategorySelector(
            subCategories = state.selectedCategory.defaultSubCategories,
            selectedSubCategory = state.selectedSubCategory,
            onSelectSubCategory = { onStateChange(state.copy(selectedSubCategory = it)) }
        )

        // Optional Fields Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Optional Details (Can be added later)",
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                OutlinedTextField(
                    value = state.tagline,
                    onValueChange = { onStateChange(state.copy(tagline = it)) },
                    label = { Text("Tagline / Subtitle (Optional)") },
                    placeholder = { Text("e.g. Together We Grow") },
                    leadingIcon = { Icon(Icons.Default.Tag, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = state.description,
                    onValueChange = { onStateChange(state.copy(description = it)) },
                    label = { Text("Short Description / About (Optional)") },
                    placeholder = { Text("Describe the purpose of your group...") },
                    leadingIcon = { Icon(Icons.Default.Description, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = state.location,
                    onValueChange = { onStateChange(state.copy(location = it)) },
                    label = { Text("Location / City (Optional)") },
                    placeholder = { Text("e.g. Kolkata, India") },
                    leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = state.contactPhone,
                        onValueChange = { onStateChange(state.copy(contactPhone = it)) },
                        label = { Text("Contact Phone") },
                        placeholder = { Text("+91...") },
                        leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = state.contactEmail,
                        onValueChange = { onStateChange(state.copy(contactEmail = it)) },
                        label = { Text("Contact Email") },
                        placeholder = { Text("info@...") },
                        leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Change Later Helper Notice
        ChangeLaterNotice("ℹ️ You can change these details anytime from Group Settings.")
    }
}

/**
 * STEP 2: Money & Collection (Category Aware)
 */
@Composable
private fun Step2MoneyCollection(
    state: DemoGroupSetupState,
    onStateChange: (DemoGroupSetupState) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Step Title Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "2 of 5 • Money & Collection",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = IndigoPrimary
                )
                Text(
                    text = "Tailored for ${state.selectedCategory.title} (${state.selectedSubCategory}).",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Dynamic Category Financial Form
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Financial Collection Setup",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                // Category Aware Field Options
                when (state.selectedCategory) {
                    GroupCategory.PUJA_FESTIVAL -> {
                        OutlinedTextField(
                            value = state.contributionAmount,
                            onValueChange = { onStateChange(state.copy(contributionAmount = it)) },
                            label = { Text("Standard Chanda / Subscription (₹)") },
                            placeholder = { Text("e.g. 1000") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            leadingIcon = { Text("₹", fontWeight = FontWeight.Bold, color = IndigoPrimary, modifier = Modifier.padding(start = 12.dp)) },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = state.targetBudget,
                            onValueChange = { onStateChange(state.copy(targetBudget = it)) },
                            label = { Text("Estimated Festival Budget (Optional)") },
                            placeholder = { Text("e.g. 500000") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    GroupCategory.SAVINGS_CREDIT_CHIT -> {
                        OutlinedTextField(
                            value = state.contributionAmount,
                            onValueChange = { onStateChange(state.copy(contributionAmount = it)) },
                            label = { Text("Monthly Mandatory Savings / Share (₹)") },
                            placeholder = { Text("e.g. 1000") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            leadingIcon = { Text("₹", fontWeight = FontWeight.Bold, color = IndigoPrimary, modifier = Modifier.padding(start = 12.dp)) },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = state.loanInterestRate,
                            onValueChange = { onStateChange(state.copy(loanInterestRate = it)) },
                            label = { Text("Default Loan Interest Rate (%)") },
                            placeholder = { Text("e.g. 2.0% per month") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    GroupCategory.HOUSING_APARTMENT -> {
                        OutlinedTextField(
                            value = state.contributionAmount,
                            onValueChange = { onStateChange(state.copy(contributionAmount = it)) },
                            label = { Text("Monthly Maintenance Amount (₹/flat)") },
                            placeholder = { Text("e.g. 1500") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            leadingIcon = { Text("₹", fontWeight = FontWeight.Bold, color = IndigoPrimary, modifier = Modifier.padding(start = 12.dp)) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    GroupCategory.BUSINESS_PARTNERSHIP -> {
                        OutlinedTextField(
                            value = state.contributionAmount,
                            onValueChange = { onStateChange(state.copy(contributionAmount = it)) },
                            label = { Text("Partner Equity Contribution (₹)") },
                            placeholder = { Text("e.g. 10000") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            leadingIcon = { Text("₹", fontWeight = FontWeight.Bold, color = IndigoPrimary, modifier = Modifier.padding(start = 12.dp)) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    else -> {
                        OutlinedTextField(
                            value = state.contributionAmount,
                            onValueChange = { onStateChange(state.copy(contributionAmount = it)) },
                            label = { Text("Regular Contribution Amount (₹)") },
                            placeholder = { Text("e.g. 500") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            leadingIcon = { Text("₹", fontWeight = FontWeight.Bold, color = IndigoPrimary, modifier = Modifier.padding(start = 12.dp)) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // Collection Frequency & Due Day
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = state.collectionFrequency,
                        onValueChange = { onStateChange(state.copy(collectionFrequency = it)) },
                        label = { Text("Frequency") },
                        placeholder = { Text("Monthly") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = state.dueDateDay,
                        onValueChange = { onStateChange(state.copy(dueDateDay = it)) },
                        label = { Text("Due Day of Month") },
                        placeholder = { Text("10th") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Late fee / Grace period
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = state.gracePeriodDays,
                        onValueChange = { onStateChange(state.copy(gracePeriodDays = it)) },
                        label = { Text("Grace Period (Days)") },
                        placeholder = { Text("5") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = state.lateFeeAmount,
                        onValueChange = { onStateChange(state.copy(lateFeeAmount = it)) },
                        label = { Text("Late Fee / Fine (₹)") },
                        placeholder = { Text("50") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Optional Toggles
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Allow Voluntary Donations", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                        Text("Members can donate extra amounts", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = state.allowDonations,
                        onCheckedChange = { onStateChange(state.copy(allowDonations = it)) },
                        colors = SwitchDefaults.colors(checkedTrackColor = IndigoPrimary)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Allow Partial Payments", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                        Text("Accept installments towards monthly due", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = state.allowPartialPayments,
                        onCheckedChange = { onStateChange(state.copy(allowPartialPayments = it)) },
                        colors = SwitchDefaults.colors(checkedTrackColor = IndigoPrimary)
                    )
                }
            }
        }

        // Historical Data Protection Demo Notice
        HistoricalRuleNotice(
            currentAmountText = "₹${state.contributionAmount.ifBlank { "500" }} / ${state.collectionFrequency.lowercase()}",
            newAmountText = "₹1,000 / ${state.collectionFrequency.lowercase()}",
            startDateText = "Next billing cycle"
        )
    }
}

/**
 * STEP 3: Features & Services
 */
@Composable
private fun Step3FeaturesServices(
    state: DemoGroupSetupState,
    onStateChange: (DemoGroupSetupState) -> Unit
) {
    val recommendedList = state.selectedCategory.defaultFeatures

    fun toggleFeature(featureId: String, enable: Boolean) {
        val updated = if (enable) {
            state.enabledFeatures + featureId
        } else {
            state.enabledFeatures - featureId
        }
        onStateChange(state.copy(enabledFeatures = updated))
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Step Title Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "3 of 5 • Features & Services",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = IndigoPrimary
                )
                Text(
                    text = "Smart defaults recommended for ${state.selectedCategory.title}.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Section 1: CORE
        Text(
            text = "1. CORE ESSENTIALS (Always Active)",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = IndigoPrimary,
            letterSpacing = 0.5.sp
        )

        FeatureToggleItem(
            title = "Members Directory",
            description = "Member profiles, phone numbers, join dates & account balances",
            isEnabled = true,
            isCore = true,
            onToggle = {}
        )

        FeatureToggleItem(
            title = "Money Collection & Receipts",
            description = "Record monthly dues, donations and auto-generate receipts",
            isEnabled = true,
            isCore = true,
            onToggle = {}
        )

        FeatureToggleItem(
            title = "Expenses & Income Ledger",
            description = "Double-entry balance sheet, category breakdowns and bill vouchers",
            isEnabled = true,
            isCore = true,
            onToggle = {}
        )

        FeatureToggleItem(
            title = "Financial Statements & PDF Reports",
            description = "Export monthly audit summaries, dues reports and CSV data",
            isEnabled = true,
            isCore = true,
            onToggle = {}
        )

        // Section 2: GROUP FEATURES
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "2. GROUP ACTIVITIES & COMMUNICATION",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = IndigoPrimary,
            letterSpacing = 0.5.sp
        )

        val groupFeatures = listOf(
            Triple("meetings", "Meetings & Minutes", "Schedule committee meetings, write minutes and track attendance"),
            Triple("notice", "Notice Board & Announcements", "Broadcast digital notices with instant notification alerts"),
            Triple("events", "Festival & Event Management", "Track event budgets, participant rosters and vendor bills"),
            Triple("suggestions", "Member Suggestions & Box", "Collect constructive ideas and community improvements"),
            Triple("complaints", "Complaints & Helpdesk", "Resolve maintenance issues with ticket status tracking"),
            Triple("attendance", "Roll Call & Attendance", "Mark attendance during club meetings and practice sessions"),
            Triple("voting", "Voting & Resolution Proposals", "Democratic polls with secret ballot or transparent count")
        )

        groupFeatures.forEach { (id, title, desc) ->
            FeatureToggleItem(
                title = title,
                description = desc,
                isEnabled = state.enabledFeatures.contains(id),
                isRecommended = recommendedList.contains(id),
                onToggle = { toggleFeature(id, it) }
            )
        }

        // Section 3: FINANCIAL FEATURES
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "3. ADVANCED FINANCIAL MODULES",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = IndigoPrimary,
            letterSpacing = 0.5.sp
        )

        val financialFeatures = listOf(
            Triple("savings", "Member Savings Scheme", "Individual savings accounts, monthly compounding and withdrawals"),
            Triple("loans", "Internal Member Loans", "Loan applications, interest amortization and EMI tracking"),
            Triple("investment", "Fixed Deposits & Joint Investments", "Track bank FDs, mutual funds and property assets"),
            Triple("auction_chit", "Chit Fund / Auction BC", "Monthly auction bids, prize distribution and commission calculations"),
            Triple("member_assistance", "Emergency Welfare & Grants", "Medical relief funds and bereavement aid disbursement")
        )

        financialFeatures.forEach { (id, title, desc) ->
            FeatureToggleItem(
                title = title,
                description = desc,
                isEnabled = state.enabledFeatures.contains(id),
                isRecommended = recommendedList.contains(id),
                onToggle = { toggleFeature(id, it) }
            )
        }

        ChangeLaterNotice("You can turn any feature on or off anytime as your group grows.")
    }
}

/**
 * STEP 4: Group Rules & Permissions
 */
@Composable
private fun Step4GroupRules(
    state: DemoGroupSetupState,
    onStateChange: (DemoGroupSetupState) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Step Title Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "4 of 5 • Group Rules & Permissions",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = IndigoPrimary
                )
                Text(
                    text = "Set clear boundaries in simple, plain language.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Expense Approval Rule Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Expense Governance & Approvals",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Require Approval for Expenses", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                        Text("Bills require verification before payout", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = state.expenseApprovalRequired,
                        onCheckedChange = { onStateChange(state.copy(expenseApprovalRequired = it)) },
                        colors = SwitchDefaults.colors(checkedTrackColor = IndigoPrimary)
                    )
                }

                if (state.expenseApprovalRequired) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = state.expenseApprovalThreshold,
                            onValueChange = { onStateChange(state.copy(expenseApprovalThreshold = it)) },
                            label = { Text("Approval Limit (₹)") },
                            placeholder = { Text("2000") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = state.whoCanApproveExpense,
                            onValueChange = { onStateChange(state.copy(whoCanApproveExpense = it)) },
                            label = { Text("Who Approves?") },
                            placeholder = { Text("President & Treasurer") },
                            singleLine = true,
                            modifier = Modifier.weight(1.2f)
                        )
                    }
                }
            }
        }

        // Member Roles & Permissions Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Operational Roles & Permissions",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                OutlinedTextField(
                    value = state.whoCanAddCollection,
                    onValueChange = { onStateChange(state.copy(whoCanAddCollection = it)) },
                    label = { Text("Who can record money collections?") },
                    placeholder = { Text("All Admins & Appointed Collectors") },
                    leadingIcon = { Icon(Icons.Default.AccountBalance, contentDescription = null, tint = IndigoPrimary) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = state.whoCanAddExpense,
                    onValueChange = { onStateChange(state.copy(whoCanAddExpense = it)) },
                    label = { Text("Who can record expense entries?") },
                    placeholder = { Text("Admins & Cashiers") },
                    leadingIcon = { Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = IndigoPrimary) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = state.whoCanEditTransactions,
                    onValueChange = { onStateChange(state.copy(whoCanEditTransactions = it)) },
                    label = { Text("Who can edit/delete historical transactions?") },
                    placeholder = { Text("Super Admin Only (Audit Logged)") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = IndigoPrimary) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        ChangeLaterNotice("Permissions can be customized for specific committee members at any time.")
    }
}

/**
 * STEP 5: Advanced Settings
 */
@Composable
private fun Step5AdvancedSettings(
    state: DemoGroupSetupState,
    onStateChange: (DemoGroupSetupState) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Step Title Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "5 of 5 • Advanced Settings",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = IndigoPrimary
                )
                Text(
                    text = "Optional fine-tuning. Most groups can use the standard defaults.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Accordion 1: Notification & Reminders
        AdvancedSectionAccordion(
            title = "Automated Notifications & Reminders",
            subtitle = "SMS, WhatsApp and In-app due payment alerts",
            icon = Icons.Default.Notifications,
            initiallyExpanded = true
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Auto WhatsApp Dues Reminder", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                    Text("Send polite payment reminders 3 days before due date", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(
                    checked = state.autoSendWhatsAppReminders,
                    onCheckedChange = { onStateChange(state.copy(autoSendWhatsAppReminders = it)) },
                    colors = SwitchDefaults.colors(checkedTrackColor = IndigoPrimary)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("SMS Receipts on Collection", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                    Text("Instant SMS receipt to donor/member", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(
                    checked = state.autoSendSmsReminders,
                    onCheckedChange = { onStateChange(state.copy(autoSendSmsReminders = it)) },
                    colors = SwitchDefaults.colors(checkedTrackColor = IndigoPrimary)
                )
            }
        }

        // Accordion 2: Accounting & Fiscal Year
        AdvancedSectionAccordion(
            title = "Ledger & Fiscal Year Settings",
            subtitle = "Financial year cycle, currency format & decimal rounding",
            icon = Icons.Default.Tune
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = state.fiscalYearStart,
                    onValueChange = { onStateChange(state.copy(fiscalYearStart = it)) },
                    label = { Text("Fiscal Year Starts") },
                    placeholder = { Text("April 1st") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )

                OutlinedTextField(
                    value = state.currencySymbol,
                    onValueChange = { onStateChange(state.copy(currencySymbol = it)) },
                    label = { Text("Currency Symbol") },
                    placeholder = { Text("₹ INR") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Accordion 3: Privacy & Security
        AdvancedSectionAccordion(
            title = "Privacy, Security & Audit Logs",
            subtitle = "Member visibility mode and tamper-proof action logs",
            icon = Icons.Default.Security
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Enable Tamper-Proof Audit Log", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                    Text("Record exact timestamp and admin for every edit", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(
                    checked = state.enableAuditLog,
                    onCheckedChange = { onStateChange(state.copy(enableAuditLog = it)) },
                    colors = SwitchDefaults.colors(checkedTrackColor = IndigoPrimary)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Allow Self-Service Statement Downloads", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                    Text("Members can download their personal tax and dues receipts", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(
                    checked = state.allowMemberSelfDownloadStatements,
                    onCheckedChange = { onStateChange(state.copy(allowMemberSelfDownloadStatements = it)) },
                    colors = SwitchDefaults.colors(checkedTrackColor = IndigoPrimary)
                )
            }
        }

        ChangeLaterNotice("Your group setup is 100% complete! You can review or tweak settings whenever needed.")
    }
}

/**
 * Bottom Action Bar:
 * Provides Save & Continue, Complete Later, and Early Creation actions.
 */
@Composable
private fun DemoSetupBottomBar(
    currentStep: SetupStep,
    isMinimumRequiredComplete: Boolean,
    onSaveAndContinue: () -> Unit,
    onCompleteLater: () -> Unit,
    onCreateEarly: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        shadowElevation = 8.dp
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Secondary / Complete Later button
                if (isMinimumRequiredComplete) {
                    OutlinedButton(
                        onClick = onCompleteLater,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .testTag("demo_complete_later_bottom_btn")
                    ) {
                        Text(
                            text = "Complete Later",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                // Primary Save & Continue button
                Button(
                    onClick = onSaveAndContinue,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                    modifier = Modifier
                        .weight(if (isMinimumRequiredComplete) 1.2f else 1f)
                        .height(46.dp)
                        .testTag("demo_save_continue_btn")
                ) {
                    Text(
                        text = if (currentStep == SetupStep.ADVANCED) "Complete Setup 🎉" else "Save & Continue",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = if (currentStep == SetupStep.ADVANCED) Icons.Default.Check else Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // Early Creation Shortcut helper banner
            if (currentStep.stepNumber in 2..4 && isMinimumRequiredComplete) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onCreateEarly() }
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Ready now? ",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Create Group & Continue Later →",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary
                    )
                }
            }
        }
    }
}
