package com.adr.groupledger.ui.screens.demo

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Diversity1
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.FamilyRestroom
import androidx.compose.material.icons.filled.Festival
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.ui.graphics.vector.ImageVector

enum class GroupCategory(
    val id: String,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val defaultSubCategories: List<String>,
    val defaultFeatures: Set<String>,
    val defaultContributionType: String,
    val defaultAmount: String
) {
    COMMUNITY_FUND(
        id = "community_fund",
        title = "Community Fund",
        description = "Regular contributions for community initiatives & member support",
        icon = Icons.Default.Groups,
        defaultSubCategories = listOf(
            "Monthly Collection Group",
            "Member Support Group",
            "Emergency Fund",
            "Local Community Fund",
            "Other"
        ),
        defaultFeatures = setOf("members", "collection", "expenses", "income", "reports", "meetings", "notice", "member_assistance"),
        defaultContributionType = "Monthly Collection",
        defaultAmount = "500"
    ),
    PUJA_FESTIVAL(
        id = "puja_festival",
        title = "Puja / Festival Committee",
        description = "Chanda, donations, festival events & public pandal expenses",
        icon = Icons.Default.Festival,
        defaultSubCategories = listOf(
            "Puja Committee",
            "Festival Committee",
            "Temple / Religious Committee",
            "Donation Fund",
            "Other"
        ),
        defaultFeatures = setOf("members", "collection", "expenses", "income", "reports", "events", "notice", "suggestions"),
        defaultContributionType = "Chanda / Subscription",
        defaultAmount = "1000"
    ),
    SPORTS_CULTURAL(
        id = "sports_cultural",
        title = "Sports & Cultural Club",
        description = "Sports tournaments, cultural programs, club activities & equipment",
        icon = Icons.Default.SportsSoccer,
        defaultSubCategories = listOf(
            "Sports Club",
            "Cultural Club",
            "Youth Club",
            "Recreation Club",
            "Other"
        ),
        defaultFeatures = setOf("members", "collection", "expenses", "income", "reports", "events", "attendance", "notice"),
        defaultContributionType = "Membership Fee",
        defaultAmount = "300"
    ),
    SAVINGS_CREDIT_CHIT(
        id = "savings_credit_chit",
        title = "Savings, Credit & Chit Fund",
        description = "Self-Help Groups (SHG), savings schemes, loans & chit funds",
        icon = Icons.Default.Savings,
        defaultSubCategories = listOf(
            "Self-Help Group (SHG)",
            "Savings Group",
            "Savings & Credit Group",
            "Member Loan Group",
            "Chit Fund / BC",
            "Other"
        ),
        defaultFeatures = setOf("members", "collection", "expenses", "income", "reports", "savings", "loans", "interest", "penalty"),
        defaultContributionType = "Monthly Savings",
        defaultAmount = "1000"
    ),
    EVENTS_TRIPS(
        id = "events_trips",
        title = "Events, Trips, Picnic & Mess Pool",
        description = "Shared trip budgets, mess accounts, weddings & group reunions",
        icon = Icons.Default.Event,
        defaultSubCategories = listOf(
            "Trip / Tour",
            "Picnic",
            "Mess",
            "Wedding / Function",
            "Reunion",
            "Other"
        ),
        defaultFeatures = setOf("members", "collection", "expenses", "income", "reports", "events", "voting"),
        defaultContributionType = "Trip Pool / Budget",
        defaultAmount = "2000"
    ),
    FAMILY_FRIENDS(
        id = "family_friends",
        title = "Family, Friends & Shared Pool",
        description = "Personal family funds, friendly expense splits & joint savings",
        icon = Icons.Default.FamilyRestroom,
        defaultSubCategories = listOf(
            "Family Fund",
            "Friends Group",
            "Shared Expense",
            "Joint Fund",
            "Emergency Pool",
            "Other"
        ),
        defaultFeatures = setOf("members", "collection", "expenses", "income", "reports", "suggestions"),
        defaultContributionType = "Flexible Contribution",
        defaultAmount = "500"
    ),
    WELFARE_NGO(
        id = "welfare_ngo",
        title = "Welfare & NGO",
        description = "Charitable causes, medical aid, disaster relief & public welfare",
        icon = Icons.Default.VolunteerActivism,
        defaultSubCategories = listOf(
            "Welfare Society",
            "NGO",
            "Charity Group",
            "Donation Fund",
            "Medical Aid",
            "Emergency Relief",
            "Other"
        ),
        defaultFeatures = setOf("members", "collection", "expenses", "income", "reports", "notice", "member_assistance"),
        defaultContributionType = "Voluntary Donation",
        defaultAmount = "500"
    ),
    HOUSING_APARTMENT(
        id = "housing_apartment",
        title = "Housing Society / Apartment",
        description = "Apartment maintenance, security, development fund & resident dues",
        icon = Icons.Default.Apartment,
        defaultSubCategories = listOf(
            "Apartment Society",
            "Housing Society",
            "Maintenance Committee",
            "Common Development Fund",
            "Other"
        ),
        defaultFeatures = setOf("members", "collection", "expenses", "income", "reports", "notice", "complaints", "meetings", "penalty"),
        defaultContributionType = "Monthly Maintenance",
        defaultAmount = "1500"
    ),
    BUSINESS_PARTNERSHIP(
        id = "business_partnership",
        title = "Business & Partnership",
        description = "Joint ventures, small enterprises, capital investments & profit shares",
        icon = Icons.Default.BusinessCenter,
        defaultSubCategories = listOf(
            "Business Partnership",
            "Joint Business",
            "Joint Investment",
            "Profit Sharing",
            "Small Enterprise",
            "Other"
        ),
        defaultFeatures = setOf("members", "collection", "expenses", "income", "reports", "investment", "voting"),
        defaultContributionType = "Capital / Equity Share",
        defaultAmount = "5000"
    ),
    OTHER_GROUPS(
        id = "other_groups",
        title = "Other Groups",
        description = "Custom committees, clubs, associations & custom ledgers",
        icon = Icons.Default.Diversity1,
        defaultSubCategories = listOf(
            "Custom Group",
            "Association",
            "Committee",
            "Special Interest Club",
            "Other"
        ),
        defaultFeatures = setOf("members", "collection", "expenses", "income", "reports"),
        defaultContributionType = "General Contribution",
        defaultAmount = "500"
    )
}

enum class SetupStep(val stepNumber: Int, val title: String, val shortName: String) {
    BASIC_INFO(1, "Basic Information", "Basic"),
    MONEY_COLLECTION(2, "Money & Collection", "Money"),
    FEATURES_SERVICES(3, "Features & Services", "Features"),
    GROUP_RULES(4, "Group Rules & Permissions", "Rules"),
    ADVANCED(5, "Advanced Settings", "Advanced")
}

data class DemoFeatureItem(
    val id: String,
    val name: String,
    val description: String,
    val category: FeatureCategory,
    val isCore: Boolean = false
)

enum class FeatureCategory(val title: String) {
    CORE("Core Accounting"),
    GROUP("Group Features"),
    FINANCIAL("Financial Features")
}

data class DemoGroupSetupState(
    // Step 1: Basic
    val groupName: String = "All Services Group",
    val selectedCategory: GroupCategory = GroupCategory.COMMUNITY_FUND,
    val selectedSubCategory: String = "Monthly Collection Group",
    val tagline: String = "United Community & Shared Growth",
    val description: String = "A neighborhood community fund for mutual support, celebrations and emergency aid.",
    val location: String = "Sector 4, Green Valley",
    val contactPhone: String = "+91 98765 43210",
    val contactEmail: String = "contact@allservicesgroup.org",

    // Step 2: Money & Collection
    val collectionType: String = "Monthly Collection",
    val collectionFrequency: String = "Monthly",
    val contributionAmount: String = "500",
    val dueDateDay: String = "10",
    val gracePeriodDays: String = "5",
    val lateFeeAmount: String = "50",
    val allowDonations: Boolean = true,
    val allowPartialPayments: Boolean = true,
    val targetBudget: String = "50000",

    // Step 3: Features
    val enabledFeatures: Set<String> = setOf(
        "members", "collection", "expenses", "income", "reports",
        "meetings", "notice", "member_assistance", "savings"
    ),

    // Step 4: Rules & Permissions
    val contributionMode: String = "Fixed Amount",
    val expenseApprovalRequired: Boolean = true,
    val expenseApprovalThreshold: String = "2000",
    val whoCanApproveExpense: String = "Admin & Treasurer",
    val whoCanAddCollection: String = "All Admins & Collectors",
    val whoCanAddExpense: String = "All Admins",
    val whoCanEditTransactions: String = "Admin Only",
    val loanApprovalRequired: Boolean = true,
    val loanInterestRate: String = "2.0%",

    // Step 5: Advanced
    val fiscalYearStart: String = "April",
    val currencySymbol: String = "₹ (INR)",
    val enableAuditLog: Boolean = true,
    val autoSendSmsReminders: Boolean = true,
    val autoSendWhatsAppReminders: Boolean = true,
    val allowMemberSelfDownloadStatements: Boolean = true,
    val memberPrivacyMode: String = "Standard (Show dues to group)",

    // Navigation & Progress
    val currentStep: SetupStep = SetupStep.BASIC_INFO,
    val isGroupCreatedEarly: Boolean = false,
    val demoInviteCode: String = "JQ5W3"
) {
    /**
     * Calculates section-based progress in 0%, 20%, 40%, 60%, 80%, 100% states.
     */
    val progressPercentage: Int
        get() {
            var completedSections = 0
            // Section 1: Basic Info (Name + Category)
            if (groupName.isNotBlank()) completedSections += 1
            // Section 2: Money & Collection
            if (contributionAmount.isNotBlank() && collectionFrequency.isNotBlank()) completedSections += 1
            // Section 3: Features & Services
            if (enabledFeatures.isNotEmpty()) completedSections += 1
            // Section 4: Rules & Permissions
            if (whoCanAddCollection.isNotBlank() && whoCanAddExpense.isNotBlank()) completedSections += 1
            // Section 5: Advanced
            if (fiscalYearStart.isNotBlank() && currencySymbol.isNotBlank()) completedSections += 1

            return (completedSections * 20).coerceIn(0, 100)
        }

    val isMinimumRequiredComplete: Boolean
        get() = groupName.trim().isNotBlank()
}
